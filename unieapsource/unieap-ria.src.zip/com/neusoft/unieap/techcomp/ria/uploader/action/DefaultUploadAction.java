/*     */ package com.neusoft.unieap.techcomp.ria.uploader.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.core.fs.EAPFileHelper;
/*     */ import com.neusoft.unieap.core.fs.EAPFileManager;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URLEncoder;
/*     */ import java.util.List;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.CheckedOutputStream;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.struts2.interceptor.ServletRequestAware;
/*     */ import org.apache.struts2.interceptor.ServletResponseAware;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class DefaultUploadAction extends ActionSupport
/*     */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = 1361693436093292238L;
/*     */   private EAPFileManager eapFileManager;
/*     */   private String maxSize;
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */ 
/*     */   @Inject("struts.multipart.maxSize")
/*     */   public void setMaxSize(String paramString)
/*     */   {
/*  45 */     this.maxSize = paramString;
/*     */   }
/*     */ 
/*     */   public String getMaxSize() {
/*  49 */     return this.maxSize;
/*     */   }
/*     */ 
/*     */   public EAPFileManager getEapFileManager() {
/*  53 */     if (this.eapFileManager == null) this.eapFileManager = ((EAPFileManager)BeanUtil.getBean("eapFileManager"));
/*  54 */     return this.eapFileManager;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
/*  62 */     this.request = paramHttpServletRequest;
/*     */   }
/*     */ 
/*     */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/*  66 */     this.response = paramHttpServletResponse;
/*     */   }
/*     */ 
/*     */   public String getFileMaxSize() {
/*     */     try {
/*  71 */       PrintWriter localPrintWriter = this.response.getWriter();
/*  72 */       localPrintWriter.write(getMaxSize());
/*  73 */       localPrintWriter.close();
/*     */     } catch (IOException localIOException) {
/*  75 */       localIOException.printStackTrace();
/*     */     }
/*     */ 
/*  78 */     return "none";
/*     */   }
/*     */ 
/*     */   private boolean isValidPath(String paramString)
/*     */   {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   public String upload()
/*     */   {
/*     */     try {
/*  94 */       String str1 = this.request.getParameter("path");
/*  95 */       if (!isValidPath(str1)) str1 = "/";
/*     */ 
/*  97 */       List localList = (List)this.request.getAttribute("UNIEAP_FILEATTACHMENT");
/*  98 */       if (localList != null)
/*  99 */         for (FileAttachment localFileAttachment : localList) {
/* 100 */           String str2 = str1 + localFileAttachment.getFileName();
/*     */ 
/* 102 */           InputStream localInputStream = localFileAttachment.getInputStream();
/* 103 */           getEapFileManager().getEAPFileHelper().writeFile(localInputStream, str2, true);
/*     */         }
/*     */     }
/*     */     catch (Exception localException) {
/* 107 */       localException.printStackTrace();
/*     */     } finally {
/* 109 */       return "none";
/*     */     }
/*     */   }
/*     */ 
/*     */   public String delete()
/*     */   {
/*     */     try {
/* 116 */       String str1 = this.request.getParameter("path");
/* 117 */       if (!isValidPath(str1)) str1 = "/";
/*     */ 
/* 119 */       String str2 = this.request.getParameter("name");
/* 120 */       str2 = new String(str2.getBytes("iso-8859-1"), "utf-8");
/* 121 */       String[] arrayOfString1 = str2.split(",");
/* 122 */       for (String str3 : arrayOfString1) {
/* 123 */         String str4 = str1 + str3;
/* 124 */         getEapFileManager().deleteFile(str4);
/*     */       }
/*     */     } catch (Exception localException) {
/* 127 */       localException.printStackTrace();
/*     */     } finally {
/* 129 */       return "none";
/*     */     }
/*     */   }
/*     */ 
/*     */   public String download()
/*     */   {
/*     */     try {
/* 136 */       String str1 = this.request.getParameter("path");
/* 137 */       if (!isValidPath(str1)) str1 = "/";
/*     */ 
/* 139 */       String str2 = this.request.getParameter("name");
/* 140 */       str2 = new String(str2.getBytes("iso-8859-1"), "utf-8");
/* 141 */       String[] arrayOfString1 = str2.split(",");
/*     */       Object localObject1;
/*     */       Object localObject2;
/*     */       Object localObject3;
/* 143 */       if (arrayOfString1.length == 1)
/*     */       {
/* 145 */         localObject1 = str1 + arrayOfString1[0];
/* 146 */         localObject2 = getEapFileManager().openFile((String)localObject1);
/*     */ 
/* 148 */         if (localObject2 != null)
/*     */         {
/* 150 */           this.response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode(arrayOfString1[0], "UTF-8"));
/*     */ 
/* 152 */           localObject3 = this.response.getOutputStream();
/*     */           int i;
/* 155 */           while ((i = ((InputStream)localObject2).read()) != -1)
/*     */           {
/* 157 */             ((OutputStream)localObject3).write(i);
/*     */           }
/* 159 */           ((OutputStream)localObject3).flush();
/*     */ 
/* 161 */           ((InputStream)localObject2).close();
/* 162 */           ((OutputStream)localObject3).close();
/*     */         }
/*     */       }
/*     */       else {
/* 166 */         this.response.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode("attachment.zip", "UTF-8"));
/*     */ 
/* 169 */         localObject1 = this.response.getOutputStream();
/* 170 */         localObject2 = new CheckedOutputStream((OutputStream)localObject1, new CRC32());
/* 171 */         localObject3 = new ZipOutputStream((OutputStream)localObject2);
/*     */ 
/* 173 */         for (String str3 : arrayOfString1) {
/* 174 */           String str4 = str1 + str3;
/* 175 */           InputStream localInputStream = getEapFileManager().openFile(str4);
/*     */ 
/* 177 */           if (localInputStream != null) {
/* 178 */             ZipEntry localZipEntry = new ZipEntry(str3);
/* 179 */             ((ZipOutputStream)localObject3).putNextEntry(localZipEntry);
/*     */ 
/* 182 */             byte[] arrayOfByte = new byte[1024];
/*     */             int m;
/* 183 */             while ((m = localInputStream.read(arrayOfByte, 0, 1024)) != -1) {
/* 184 */               ((ZipOutputStream)localObject3).write(arrayOfByte, 0, m);
/*     */             }
/* 186 */             localInputStream.close();
/*     */           }
/*     */         }
/*     */ 
/* 190 */         ((ZipOutputStream)localObject3).close();
/* 191 */         ((OutputStream)localObject1).close();
/*     */       }
/*     */     } catch (Exception localException) {
/* 194 */       localException.printStackTrace();
/*     */     } finally {
/* 196 */       return "none";
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.uploader.action.DefaultUploadAction
 * JD-Core Version:    0.6.2
 */