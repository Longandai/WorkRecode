/*     */ package com.neusoft.unieap.techcomp.ria.pojo;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.RowImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class PojoEntity
/*     */ {
/*  19 */   private int status = 2;
/*  20 */   private boolean selected = false;
/*  21 */   private Object pojoObj = null;
/*  22 */   private Object orignPojoObj = null;
/*     */   private Row row;
/*     */ 
/*     */   public PojoEntity()
/*     */   {
/*     */   }
/*     */ 
/*     */   public PojoEntity(Object paramObject)
/*     */   {
/*  35 */     this.pojoObj = paramObject;
/*     */   }
/*     */ 
/*     */   public void setPojoObj(Object paramObject)
/*     */     throws Exception
/*     */   {
/*  58 */     this.pojoObj = paramObject;
/*  59 */     if (paramObject != null) {
/*  60 */       this.row = PojoUtil.createRow(paramObject);
/*  61 */       if (this.status != 2) {
/*  62 */         this.row.setRowStatus(this.status);
/*     */       }
/*  64 */       if (this.selected)
/*  65 */         this.row.setSelected(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setOrignPojoObj(Object paramObject)
/*     */   {
/*  76 */     this.orignPojoObj = paramObject;
/*     */   }
/*     */ 
/*     */   public void setStatus(int paramInt)
/*     */   {
/*  84 */     this.status = paramInt;
/*     */   }
/*     */ 
/*     */   public boolean isDataModified()
/*     */   {
/*  92 */     return this.status == 3;
/*     */   }
/*     */ 
/*     */   public boolean isDirty(String paramString)
/*     */   {
/* 100 */     Object localObject1 = PojoUtil.getValue(this.pojoObj, paramString);
/* 101 */     if (this.orignPojoObj != null) {
/* 102 */       Object localObject2 = PojoUtil.getValue(this.orignPojoObj, paramString);
/* 103 */       return !localObject1.equals(localObject2);
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public List getModifyColName()
/*     */   {
/* 111 */     ArrayList localArrayList = new ArrayList();
/* 112 */     JSONObject localJSONObject = ((RowImpl)this.row).getJSONObject();
/* 113 */     if (localJSONObject.containsKey("_o")) {
/* 114 */       localArrayList.addAll(localJSONObject.getJSONObject("_o").keySet());
/*     */     }
/* 116 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public boolean isNotModified()
/*     */   {
/* 124 */     return this.status == 2;
/*     */   }
/*     */ 
/*     */   public boolean isNewModified()
/*     */   {
/* 133 */     return this.status == 1;
/*     */   }
/*     */ 
/*     */   public Object getPojoObj()
/*     */   {
/* 141 */     return this.pojoObj;
/*     */   }
/*     */ 
/*     */   public Object getOrignPojoObj()
/*     */   {
/* 149 */     return this.orignPojoObj;
/*     */   }
/*     */ 
/*     */   public boolean isSelected()
/*     */   {
/* 158 */     return this.selected;
/*     */   }
/*     */ 
/*     */   public void setSelected(boolean paramBoolean)
/*     */   {
/* 167 */     this.selected = paramBoolean;
/*     */   }
/*     */ 
/*     */   public void setRow(Row paramRow)
/*     */   {
/* 176 */     this.row = paramRow;
/*     */   }
/*     */ 
/*     */   public void setItemValue(String paramString, Object paramObject)
/*     */   {
/* 186 */     this.row.setItemValue(paramString, paramObject);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.pojo.PojoEntity
 * JD-Core Version:    0.6.2
 */