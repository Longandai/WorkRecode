/*     */ package com.neusoft.unieap.techcomp.ria.pojo;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PojoList
/*     */ {
/*  11 */   private List primary = new ArrayList();
/*  12 */   private List delete = new ArrayList();
/*  13 */   private String pojoClassName = null;
/*     */ 
/*     */   public PojoList(String paramString)
/*     */   {
/*  20 */     this.pojoClassName = paramString;
/*     */   }
/*     */ 
/*     */   public String getPojoClassName()
/*     */   {
/*  29 */     return this.pojoClassName;
/*     */   }
/*     */ 
/*     */   public void setPojoClassName(String paramString)
/*     */   {
/*  38 */     this.pojoClassName = paramString;
/*     */   }
/*     */ 
/*     */   public List getPojoList()
/*     */   {
/*  47 */     return this.primary;
/*     */   }
/*     */ 
/*     */   public void addPojo(PojoEntity paramPojoEntity)
/*     */   {
/*  55 */     this.primary.add(paramPojoEntity);
/*     */   }
/*     */ 
/*     */   public void addDeletePojo(PojoEntity paramPojoEntity)
/*     */   {
/*  63 */     if (!paramPojoEntity.isNewModified())
/*  64 */       this.delete.add(paramPojoEntity);
/*     */   }
/*     */ 
/*     */   public List getModifiedPojo()
/*     */   {
/*  74 */     ArrayList localArrayList = new ArrayList();
/*  75 */     int i = 0; for (int j = this.primary.size(); i < j; i++) {
/*  76 */       PojoEntity localPojoEntity = (PojoEntity)this.primary.get(i);
/*  77 */       if (localPojoEntity.isDataModified()) {
/*  78 */         localArrayList.add(localPojoEntity);
/*     */       }
/*     */     }
/*  81 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getDeletedPojo()
/*     */   {
/*  90 */     return this.delete;
/*     */   }
/*     */ 
/*     */   public List getInsertedPojo()
/*     */   {
/*  99 */     ArrayList localArrayList = new ArrayList();
/* 100 */     int i = 0; for (int j = this.primary.size(); i < j; i++) {
/* 101 */       PojoEntity localPojoEntity = (PojoEntity)this.primary.get(i);
/* 102 */       if (localPojoEntity.isNewModified()) {
/* 103 */         localArrayList.add(localPojoEntity);
/*     */       }
/*     */     }
/* 106 */     return localArrayList;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.pojo.PojoList
 * JD-Core Version:    0.6.2
 */