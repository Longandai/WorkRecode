package com.neusoft.unieap.techcomp.ria.query.bo;

import java.io.Serializable;
import java.util.List;

public abstract interface QueryBO extends Serializable
{
  public abstract List getQueryData(List paramList, String paramString1, int paramInt1, int paramInt2, String paramString2);

  public abstract Object[] composeQueryCondition(List paramList);

  public abstract int getRecordCount(List paramList, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.bo.QueryBO
 * JD-Core Version:    0.6.2
 */