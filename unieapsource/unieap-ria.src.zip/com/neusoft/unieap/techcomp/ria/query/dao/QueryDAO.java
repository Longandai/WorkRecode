package com.neusoft.unieap.techcomp.ria.query.dao;

import java.io.Serializable;
import java.util.List;

public abstract interface QueryDAO extends Serializable
{
  public abstract List getQueryAllData(String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3);

  public abstract List getQeurySegmentData(String paramString1, String paramString2, Object[] paramArrayOfObject, int paramInt1, int paramInt2, String paramString3);

  public abstract int getRecordCount(String paramString1, String paramString2, Object[] paramArrayOfObject);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.dao.QueryDAO
 * JD-Core Version:    0.6.2
 */