/*    */ package com.neusoft.unieap.techcomp.ria.query.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.query.dao.QueryDAO;
/*    */ import java.util.List;
/*    */ 
/*    */ public class QueryDAOImpl extends BaseHibernateDAO
/*    */   implements QueryDAO
/*    */ {
/*    */   private static final long serialVersionUID = -2789328028836243964L;
/*    */ 
/*    */   public List getQeurySegmentData(String paramString1, String paramString2, Object[] paramArrayOfObject, int paramInt1, int paramInt2, String paramString3)
/*    */   {
/* 17 */     String str = getQuerySql(paramString1, paramString2, paramString3);
/* 18 */     return queryObjects(str, paramArrayOfObject, paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   public List getQueryAllData(String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3)
/*    */   {
/* 24 */     String str = getQuerySql(paramString1, paramString2, paramString3);
/* 25 */     return queryObjects(str, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public int getRecordCount(String paramString1, String paramString2, Object[] paramArrayOfObject)
/*    */   {
/* 31 */     if (((paramString1 == null) || ("".equals(paramString1.trim()))) && ((paramString2 == null) || ("".equals(paramString2.trim())))) {
/* 32 */       return 0;
/*    */     }
/* 34 */     String str = "select count(*) from " + paramString1 + " where " + paramString2;
/* 35 */     Long localLong = (Long)queryObject(str, paramArrayOfObject);
/* 36 */     return localLong.intValue();
/*    */   }
/*    */ 
/*    */   private String getQuerySql(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 41 */     StringBuffer localStringBuffer = new StringBuffer();
/* 42 */     localStringBuffer.append(" from " + paramString1 + " where " + paramString2);
/* 43 */     if ((paramString3 != null) && (!paramString3.equals(""))) {
/* 44 */       localStringBuffer.append(" ORDER BY " + paramString3);
/*    */     }
/* 46 */     return localStringBuffer.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.dao.impl.QueryDAOImpl
 * JD-Core Version:    0.6.2
 */