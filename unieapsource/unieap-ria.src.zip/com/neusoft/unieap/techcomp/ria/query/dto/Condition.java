/*    */ package com.neusoft.unieap.techcomp.ria.query.dto;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Condition
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 3440547338326528449L;
/* 13 */   private String column = null;
/*    */ 
/* 15 */   private String operation = null;
/*    */ 
/* 17 */   private Object value = null;
/*    */   private int dataType;
/*    */ 
/*    */   public String getColumn()
/*    */   {
/* 25 */     return this.column;
/*    */   }
/*    */ 
/*    */   public void setColumn(String paramString)
/*    */   {
/* 32 */     this.column = paramString;
/*    */   }
/*    */ 
/*    */   public String getOperation()
/*    */   {
/* 39 */     return this.operation;
/*    */   }
/*    */ 
/*    */   public void setOperation(String paramString)
/*    */   {
/* 46 */     this.operation = paramString;
/*    */   }
/*    */ 
/*    */   public Object getValue()
/*    */   {
/* 53 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(Object paramObject)
/*    */   {
/* 60 */     this.value = paramObject;
/*    */   }
/*    */ 
/*    */   public int getDataType()
/*    */   {
/* 67 */     return this.dataType;
/*    */   }
/*    */ 
/*    */   public void setDataType(int paramInt)
/*    */   {
/* 74 */     this.dataType = paramInt;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.dto.Condition
 * JD-Core Version:    0.6.2
 */