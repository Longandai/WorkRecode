/*    */ package com.neusoft.unieap.techcomp.ria.query.action;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*    */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*    */ import com.neusoft.unieap.techcomp.ria.query.bo.QueryBO;
/*    */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*    */ import java.util.List;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class QueryAction extends BaseProcessor
/*    */ {
/*    */   private static final long serialVersionUID = -8890919133354548490L;
/* 16 */   public final String TRUE = "true";
/*    */   private static final String QUERYSTORE = "_queryResultStore";
/*    */   private static final String ENTITYCLASS = "_entityClass";
/*    */   private static final String CONDITIONSTORE = "_conditionStore";
/*    */   public static final int NOPAGESIZE = 2000000;
/* 23 */   private QueryBO queryConditonBO = null;
/*    */ 
/*    */   public final QueryBO getQueryConditonBO() {
/* 26 */     return this.queryConditonBO;
/*    */   }
/*    */ 
/*    */   public final void setQueryConditonBO(QueryBO paramQueryBO) {
/* 30 */     this.queryConditonBO = paramQueryBO;
/*    */   }
/*    */ 
/*    */   public void doQuery()
/*    */     throws Exception
/*    */   {
/* 39 */     ViewContext localViewContext = generateContext();
/* 40 */     String str1 = localViewContext.getString("_entityClass");
/* 41 */     String str2 = localViewContext.getString("_queryResultStore");
/*    */ 
/* 43 */     Class.forName(str1);
/*    */ 
/* 45 */     String str3 = str1;
/* 46 */     List localList1 = localViewContext.getQueryConditions();
/*    */ 
/* 48 */     DataCenter localDataCenter1 = localViewContext.getDataCenter();
/* 49 */     DataStore localDataStore1 = localDataCenter1.getDataStore(str2);
/*    */ 
/* 52 */     DataCenter localDataCenter2 = DataCenterFactory.getInstance().createDataCenter();
/*    */ 
/* 54 */     int i = 0;
/* 55 */     int j = 0;
/* 56 */     if (localDataStore1 != null) {
/* 57 */       DataStore localDataStore2 = localViewContext.getQueryConditionStore();
/* 58 */       String str4 = null;
/* 59 */       if (localDataStore2 != null) {
/* 60 */         str4 = localDataStore2.getOrder();
/*    */       }
/* 62 */       i = localDataStore1.getPageNumber();
/* 63 */       j = localDataStore1.getPageSize();
/* 64 */       List localList2 = this.queryConditonBO.getQueryData(localList1, str3, i, j, str4);
/* 65 */       localDataStore1 = PojoUtil.toDataStore(localList2, localDataStore1);
/*    */ 
/* 67 */       int k = 0;
/* 68 */       if (j < 2000000) {
/* 69 */         k = this.queryConditonBO.getRecordCount(localList1, str3);
/*    */       }
/* 71 */       localDataStore1.setStoreName(str2);
/* 72 */       localDataStore1.setRecordCount(k);
/*    */ 
/* 74 */       localDataCenter2.addDataStore(localDataStore1);
/* 75 */       localDataCenter2.setDetail("true");
/* 76 */       super.write(localDataCenter2);
/*    */     }
/*    */     else;
/*    */   }
/*    */ 
/*    */   public void getConditionDataStore()
/*    */     throws Exception
/*    */   {
/* 87 */     String str = getRequest().getParameter("_entityClass");
/* 88 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 89 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 90 */     DataStore localDataStore = localDataCenterFactory.createDataStore("_conditionStore");
/* 91 */     localDataStore.setRowSetName(str);
/* 92 */     localDataCenter.addDataStore(localDataStore);
/* 93 */     super.write(localDataCenter);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.action.QueryAction
 * JD-Core Version:    0.6.2
 */