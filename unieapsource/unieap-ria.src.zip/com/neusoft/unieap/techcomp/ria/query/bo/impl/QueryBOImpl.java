/*    */ package com.neusoft.unieap.techcomp.ria.query.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.query.bo.QueryBO;
/*    */ import com.neusoft.unieap.techcomp.ria.query.dao.QueryDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.util.QueryConverterUtil;
/*    */ import java.util.List;
/*    */ 
/*    */ public class QueryBOImpl
/*    */   implements QueryBO
/*    */ {
/*    */   private static final long serialVersionUID = 3463230858744544571L;
/*    */   public static final int NOPAGESIZE = 2000000;
/* 15 */   private QueryDAO queryDAO = null;
/*    */ 
/*    */   public final QueryDAO getQueryDAO() {
/* 18 */     return this.queryDAO;
/*    */   }
/*    */ 
/*    */   public final void setQueryDAO(QueryDAO paramQueryDAO) {
/* 22 */     this.queryDAO = paramQueryDAO;
/*    */   }
/*    */ 
/*    */   public List getQueryData(List paramList, String paramString1, int paramInt1, int paramInt2, String paramString2)
/*    */   {
/* 27 */     List localList = null;
/* 28 */     Object[] arrayOfObject1 = composeQueryCondition(paramList);
/* 29 */     String str = null;
/* 30 */     Object[] arrayOfObject2 = (Object[])null;
/* 31 */     if ((arrayOfObject1 != null) && (arrayOfObject1.length == 2)) {
/* 32 */       str = arrayOfObject1[0].toString();
/* 33 */       arrayOfObject2 = (Object[])arrayOfObject1[1];
/*    */     }
/*    */ 
/* 36 */     if ((str == null) || (str.length() == 0)) {
/* 37 */       str = " 1 = 1 ";
/*    */     }
/* 39 */     if (paramInt2 > 2000000)
/* 40 */       localList = this.queryDAO.getQueryAllData(paramString1, str, arrayOfObject2, paramString2);
/*    */     else {
/* 42 */       localList = this.queryDAO.getQeurySegmentData(paramString1, str, arrayOfObject2, paramInt1, paramInt2, paramString2);
/*    */     }
/* 44 */     return localList;
/*    */   }
/*    */ 
/*    */   public Object[] composeQueryCondition(List paramList)
/*    */   {
/* 49 */     return QueryConverterUtil.getInstance().getQueryCondition(paramList);
/*    */   }
/*    */ 
/*    */   public int getRecordCount(List paramList, String paramString)
/*    */   {
/* 54 */     int i = 0;
/* 55 */     Object[] arrayOfObject1 = composeQueryCondition(paramList);
/* 56 */     String str = null;
/* 57 */     Object[] arrayOfObject2 = (Object[])null;
/* 58 */     if ((arrayOfObject1 != null) && (arrayOfObject1.length == 2)) {
/* 59 */       str = arrayOfObject1[0].toString();
/* 60 */       arrayOfObject2 = (Object[])arrayOfObject1[1];
/*    */     }
/*    */ 
/* 63 */     if ((str == null) || (str.length() == 0)) {
/* 64 */       str = " 1 = 1 ";
/*    */     }
/*    */ 
/* 67 */     i = this.queryDAO.getRecordCount(paramString, str, arrayOfObject2);
/*    */ 
/* 69 */     return i;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.query.bo.impl.QueryBOImpl
 * JD-Core Version:    0.6.2
 */