/*    */ package com.neusoft.unieap.techcomp.ria;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class RIAException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = -8848447322989646387L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 14 */     return true;
/*    */   }
/*    */ 
/*    */   public RIAException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 23 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public RIAException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 37 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.RIAException
 * JD-Core Version:    0.6.2
 */