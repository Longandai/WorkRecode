/*     */ package com.neusoft.unieap.techcomp.ria.ext.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*     */ import com.neusoft.unieap.core.common.form.Form;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.bo.ExtInfoBO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.dao.ExtInfoDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ @ModelFile("extInfoBO.bo")
/*     */ public class ExtInfoBOImpl
/*     */   implements ExtInfoBO
/*     */ {
/*     */   private ExtInfoDAO extInfoDAO;
/*     */   private EAPCacheManager eapCacheManager;
/*     */ 
/*     */   public void setExtInfoDAO(ExtInfoDAO paramExtInfoDAO)
/*     */   {
/*  37 */     this.extInfoDAO = paramExtInfoDAO;
/*     */   }
/*     */ 
/*     */   public ExtInfoDAO getExtInfoDAO() {
/*  41 */     return this.extInfoDAO;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/*  45 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public List getExtAttrDefinesByObjType(String paramString)
/*     */   {
/*  52 */     List localList = (List)this.eapCacheManager.get(paramString, 
/*  53 */       "extAttrDefines");
/*  54 */     if (localList != null)
/*  55 */       return localList;
/*  56 */     localList = this.extInfoDAO.getExtAttrDefinesByObjType(paramString);
/*     */ 
/*  58 */     this.eapCacheManager.put(paramString, localList, "extAttrDefines");
/*  59 */     return localList;
/*     */   }
/*     */ 
/*     */   public ExtAttrDefine getExtAttrDefineByAttrName(String paramString1, String paramString2)
/*     */   {
/*  66 */     List localList = getExtAttrDefinesByObjType(paramString1);
/*     */ 
/*  68 */     for (int i = 0; i < localList.size(); i++) {
/*  69 */       ExtAttrDefine localExtAttrDefine = (ExtAttrDefine)localList.get(i);
/*  70 */       if (localExtAttrDefine.getAttrName().equals(paramString2))
/*  71 */         return localExtAttrDefine;
/*     */     }
/*  73 */     return null;
/*     */   }
/*     */ 
/*     */   public void deleteExtInfo(String paramString1, String paramString2)
/*     */   {
/*  80 */     List localList = getExtAttrDefinesByObjType(paramString2);
/*  81 */     if (localList.size() > 0)
/*  82 */       this.extInfoDAO.deleteExtInfo(localList, paramString1);
/*     */   }
/*     */ 
/*     */   public Map getExtInfo(String paramString1, String paramString2)
/*     */   {
/*  89 */     List localList = getExtAttrDefinesByObjType(paramString2);
/*  90 */     if (localList.size() == 0)
/*  91 */       return null;
/*  92 */     Map localMap = this.extInfoDAO.getExtInfo(localList, paramString1);
/*  93 */     return localMap;
/*     */   }
/*     */ 
/*     */   public BOContext getExtInfoHTML(String paramString)
/*     */   {
/* 100 */     return getExtInfoHTML(paramString, paramString);
/*     */   }
/*     */ 
/*     */   public BOContext getExtInfoHTML(String paramString1, String paramString2)
/*     */   {
/* 107 */     List localList = getExtAttrDefinesByObjType(paramString1);
/* 108 */     if (localList.size() == 0)
/* 109 */       return null;
/* 110 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 111 */     StringBuffer localStringBuffer = new StringBuffer();
/* 112 */     localStringBuffer.append("<div dojoType='unieap.form.Form' id='" + paramString1 + 
/* 113 */       "ExtForm' jsId='" + paramString1 + 
/* 114 */       "ExtForm' binding='{store:\"" + paramString1 + "ExtInfoDS\"}' enctype=\"multipart/form-data\">\n");
/* 115 */     localStringBuffer
/* 116 */       .append("<table id='" + 
/* 117 */       paramString1 + 
/* 118 */       "ExtForm_tableLayout' width='100%' style='table-layout:fixed;'>\n");
/* 119 */     localStringBuffer.append("<colgroup>\n");
/* 120 */     localStringBuffer.append("<col width='13%'></col>\n");
/* 121 */     localStringBuffer.append("<col width='20%'></col>\n");
/* 122 */     localStringBuffer.append("<col width='13%'></col>\n");
/* 123 */     localStringBuffer.append("<col width='20%'></col>\n");
/* 124 */     localStringBuffer.append("<col width='13%'></col>\n");
/* 125 */     localStringBuffer.append("<col width='20%'></col>\n");
/* 126 */     localStringBuffer.append("</colgroup>\n");
/* 127 */     localStringBuffer.append("<tbody>\n");
/*     */ 
/* 138 */     int m = 0;
/*     */ 
/* 143 */     HashMap localHashMap = new HashMap();
/* 144 */     ArrayList localArrayList = new ArrayList();
/*     */     ExtAttrDefine localExtAttrDefine;
/* 145 */     for (int n = 0; n < localList.size(); n++) {
/* 146 */       localExtAttrDefine = (ExtAttrDefine)localList.get(n);
/* 147 */       String str1 = localExtAttrDefine.getAttrName();
/* 148 */       String str8 = str1 + "_" + paramString1 + "ExtForm";
/* 149 */       String str5 = localExtAttrDefine.getDisplayStyle();
/* 150 */       String str3 = localExtAttrDefine.getControlType();
/*     */ 
/* 152 */       if ((str5 != null) && (str5.equals("none"))) {
/* 153 */         localStringBuffer.append("<div dojoType='" + str3 + "' id='" + str8 + 
/* 154 */           "' display=\"none\" binding=\"{name:'" + str1 + 
/* 155 */           "'}\"></div>\n");
/* 156 */         localHashMap.put(str1, str8);
/*     */       }
/*     */       else {
/* 159 */         int i = localExtAttrDefine.getRowSpan().intValue();
/* 160 */         int j = localExtAttrDefine.getValueColSpan().intValue();
/* 161 */         int k = localExtAttrDefine.getLabelColSpan().intValue();
/* 162 */         String str2 = localExtAttrDefine.getLabel();
/* 163 */         Integer localInteger1 = localExtAttrDefine.getMaxLength();
/* 164 */         Integer localInteger2 = localExtAttrDefine.getMinLength();
/* 165 */         String str6 = localExtAttrDefine.getReadOnly();
/*     */         String str4;
/* 166 */         if ((localExtAttrDefine.getRequired() != null) && 
/* 167 */           (localExtAttrDefine.getRequired().equals("T")))
/* 168 */           str4 = "true";
/*     */         else
/* 170 */           str4 = "false";
/* 171 */         if ((localExtAttrDefine.getReadOnly() != null) && 
/* 172 */           (localExtAttrDefine.getReadOnly().equals("T")))
/* 173 */           str6 = "true";
/*     */         else
/* 175 */           str6 = "false";
/* 176 */         if (m % 6 == 0) {
/* 177 */           if (m == 0) {
/* 178 */             localStringBuffer.append("<tr>\n");
/*     */           } else {
/* 180 */             localStringBuffer.append("</tr>\n");
/* 181 */             localStringBuffer.append("<tr>\n");
/*     */           }
/*     */         }
/* 184 */         m = m + j + k;
/* 185 */         localStringBuffer.append("<td colSpan='" + k + "' rowSpan='" + i + 
/* 186 */           "'>\n");
/* 187 */         localStringBuffer.append("<label id='" + str8 + "_label'>" + str2 + 
/* 188 */           "</label>\n");
/* 189 */         localStringBuffer.append("</td>\n");
/* 190 */         localStringBuffer.append("<td colSpan='" + j + "' rowSpan='" + i + 
/* 191 */           "'>\n");
/* 192 */         localStringBuffer.append("<div dojoType='" + str3 + "' id='" + str8 + 
/* 193 */           "' required='" + str4 + "' readOnly='" + str6 + 
/* 194 */           "' width='100%' binding=\"{name:'" + str1 + "'}\"");
/* 195 */         if ((localInteger1 != null) && (localInteger1.intValue() > 0)) {
/* 196 */           localStringBuffer.append(" maxLength='" + localInteger1 + "'");
/*     */         }
/* 198 */         if ((localInteger2 != null) && (localInteger2.intValue() > 0)) {
/* 199 */           localStringBuffer.append(" minLength='" + localInteger2 + "'");
/*     */         }
/* 201 */         if (str3.equals("unieap.form.FileInput")) {
/* 202 */           String str7 = localExtAttrDefine.getFileInputFilter();
/* 203 */           if (str7 != null) {
/* 204 */             localStringBuffer.append(" fileFilter='" + str7 + "'");
/*     */           }
/*     */         }
/* 207 */         if (str3.equals("unieap.form.ComboBox")) {
/* 208 */           if (str5 == null)
/* 209 */             str5 = "list";
/* 210 */           localStringBuffer.append(" dataProvider=\"{store:'" + 
/* 211 */             localExtAttrDefine.getCodeType() + 
/* 212 */             "'}\" popup=\"{displayStyle:'" + str5 + 
/* 213 */             "',height:'300px'}\"");
/*     */         }
/* 215 */         if (str3.equals("unieap.form.TextBoxWithIcon")) {
/* 216 */           localArrayList.add(localExtAttrDefine);
/* 217 */           localStringBuffer.append(" iconClass='" + localExtAttrDefine.getIconClass() + 
/* 218 */             "' onIconClick=\"" + paramString2 + 
/* 219 */             ".showExtAttrXDialog('" + str1 + "XDialog')\"");
/* 220 */           localHashMap.put(str1, str8);
/*     */         }
/* 222 */         localStringBuffer.append("></div>\n");
/* 223 */         localStringBuffer.append("</td>\n");
/*     */       }
/*     */     }
/* 225 */     n = 0;
/* 226 */     if (m % 6 != 0)
/* 227 */       n = 6 - m % 6;
/* 228 */     if (n != 0) {
/* 229 */       for (int i1 = 0; i1 < n; i1++) {
/* 230 */         localStringBuffer.append("<td></td>\n");
/*     */       }
/*     */     }
/* 233 */     localStringBuffer.append("</tr>\n");
/*     */ 
/* 235 */     localStringBuffer.append("</tbody>\n");
/* 236 */     localStringBuffer.append("</table>\n");
/* 237 */     localStringBuffer.append("</div>\n");
/*     */ 
/* 239 */     HttpServletRequest localHttpServletRequest = ServletActionContext.getRequest();
/* 240 */     String str9 = localHttpServletRequest.getContextPath();
/*     */ 
/* 242 */     for (int i2 = 0; i2 < localArrayList.size(); i2++) {
/* 243 */       localExtAttrDefine = (ExtAttrDefine)localArrayList.get(i2);
/* 244 */       Integer localInteger3 = localExtAttrDefine.getDialogWidth();
/* 245 */       Integer localInteger4 = localExtAttrDefine.getDialogHeight();
/* 246 */       localStringBuffer.append("<div dojoType='unieap.xdialog.Dialog' id='" + 
/* 247 */         localExtAttrDefine.getAttrName() + "XDialog' title='" + 
/* 248 */         localExtAttrDefine.getLabel() + "' url='" + str9 + 
/* 249 */         "/patch/" + localExtAttrDefine.getAttrName() + 
/* 250 */         "_entry.action' onComplete=\"" + paramString2 + 
/* 251 */         ".extAttrXDialogComplete\"");
/* 252 */       if (localInteger3 != null)
/* 253 */         localStringBuffer.append(" width='" + localInteger3 + "px'");
/* 254 */       if (localInteger4 != null)
/* 255 */         localStringBuffer.append(" height='" + localInteger4 + "px'");
/* 256 */       localStringBuffer.append("></div>\n");
/*     */     }
/*     */ 
/* 259 */     if ((localHashMap != null) && (localHashMap.size() > 0))
/* 260 */       localBOContextImpl.put("dialogMaps", localHashMap);
/* 261 */     localBOContextImpl.put("extInfoHTML", localStringBuffer.toString());
/*     */ 
/* 263 */     return localBOContextImpl;
/*     */   }
/*     */ 
/*     */   public boolean isExistExtInfo(String paramString)
/*     */   {
/* 270 */     List localList = getExtAttrDefinesByObjType(paramString);
/* 271 */     if (localList.size() > 0)
/* 272 */       return true;
/* 273 */     return false;
/*     */   }
/*     */ 
/*     */   public void saveExtInfo(String paramString1, String paramString2, Map paramMap)
/*     */   {
/* 280 */     List localList = getExtAttrDefinesByObjType(paramString2);
/* 281 */     if (localList.size() == 0)
/* 282 */       return;
/* 283 */     paramMap.put("id", paramString1);
/* 284 */     this.extInfoDAO.saveExtInfo(localList, paramMap);
/*     */   }
/*     */ 
/*     */   public void updateExtInfo(String paramString1, String paramString2, Map paramMap)
/*     */   {
/* 291 */     List localList = getExtAttrDefinesByObjType(paramString2);
/* 292 */     if (localList.size() == 0)
/* 293 */       return;
/* 294 */     paramMap.put("id", paramString1);
/* 295 */     Map localMap = this.extInfoDAO.getExtInfo(localList, paramString1);
/* 296 */     if (localMap != null)
/* 297 */       this.extInfoDAO.updateExtInfo(localList, paramMap);
/*     */     else
/* 299 */       this.extInfoDAO.saveExtInfo(localList, paramMap);
/*     */   }
/*     */ 
/*     */   public void saveExtInfoWithBlob(String paramString1, String paramString2, Map paramMap, Form paramForm, String paramString3)
/*     */   {
/* 306 */     String[] arrayOfString = paramString3.split(",");
/* 307 */     int i = 0;
/* 308 */     if (paramForm.getFiles() != null) {
/* 309 */       i = paramForm.getFiles().size();
/*     */     }
/* 311 */     for (int j = 0; j < i; j++) {
/* 312 */       ExtAttrDefine localExtAttrDefine = getExtAttrDefineByAttrName(paramString2, arrayOfString[j]);
/* 313 */       FileAttachment localFileAttachment = (FileAttachment)paramForm.getFiles().get(j);
/* 314 */       if (localFileAttachment.getSize() / 1024L > localExtAttrDefine.getFileInputSize().intValue()) {
/* 315 */         if (localExtAttrDefine.getFileInputSize().intValue() >= 1024) {
/* 316 */           throw new UniEAPBusinessException("EAPTECHORG0012", new Object[] { localExtAttrDefine.getFileInputSize().intValue() / 1024 + "MB" });
/*     */         }
/* 318 */         throw new UniEAPBusinessException("EAPTECHORG0012", new Object[] { localExtAttrDefine.getFileInputSize() + "KB" });
/* 319 */       }byte[] arrayOfByte = localFileAttachment.getBytes();
/* 320 */       paramMap.put(arrayOfString[j], arrayOfByte);
/*     */     }
/*     */ 
/* 323 */     saveExtInfo(paramString1, paramString2, paramMap);
/*     */   }
/*     */ 
/*     */   public void updateExtInfoWithBlob(String paramString1, String paramString2, Map paramMap, Form paramForm, String paramString3)
/*     */   {
/* 330 */     String[] arrayOfString = paramString3.split(",");
/* 331 */     int i = 0;
/* 332 */     if (paramForm.getFiles() != null) {
/* 333 */       i = paramForm.getFiles().size();
/*     */     }
/* 335 */     for (int j = 0; j < i; j++) {
/* 336 */       ExtAttrDefine localExtAttrDefine = getExtAttrDefineByAttrName(paramString2, arrayOfString[j]);
/* 337 */       FileAttachment localFileAttachment = (FileAttachment)paramForm.getFiles().get(j);
/* 338 */       if (localFileAttachment.getSize() / 1024L > localExtAttrDefine.getFileInputSize().intValue()) {
/* 339 */         if (localExtAttrDefine.getFileInputSize().intValue() >= 1024) {
/* 340 */           throw new UniEAPBusinessException("EAPTECHORG0012", new Object[] { localExtAttrDefine.getFileInputSize().intValue() / 1024 + "MB" });
/*     */         }
/* 342 */         throw new UniEAPBusinessException("EAPTECHORG0012", new Object[] { localExtAttrDefine.getFileInputSize() + "KB" });
/*     */       }
/* 344 */       byte[] arrayOfByte = localFileAttachment.getBytes();
/* 345 */       paramMap.put(arrayOfString[j], arrayOfByte);
/*     */     }
/*     */ 
/* 348 */     updateExtInfo(paramString1, paramString2, paramMap);
/*     */   }
/*     */ 
/*     */   public Map getAllExtInfoByObjType(String paramString)
/*     */   {
/* 355 */     List localList = getExtAttrDefinesByObjType(paramString);
/* 356 */     if (localList.size() == 0)
/* 357 */       return null;
/* 358 */     return this.extInfoDAO.getAllExtInfoByObjType(localList, paramString);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ext.bo.impl.ExtInfoBOImpl
 * JD-Core Version:    0.6.2
 */