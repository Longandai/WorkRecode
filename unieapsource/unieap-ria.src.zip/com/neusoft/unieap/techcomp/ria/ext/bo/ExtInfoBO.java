package com.neusoft.unieap.techcomp.ria.ext.bo;

import com.neusoft.unieap.core.common.bo.context.BOContext;
import com.neusoft.unieap.core.common.form.Form;
import com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine;
import java.util.List;
import java.util.Map;

public abstract interface ExtInfoBO
{
  public abstract List getExtAttrDefinesByObjType(String paramString);

  public abstract ExtAttrDefine getExtAttrDefineByAttrName(String paramString1, String paramString2);

  public abstract BOContext getExtInfoHTML(String paramString);

  public abstract BOContext getExtInfoHTML(String paramString1, String paramString2);

  public abstract void saveExtInfo(String paramString1, String paramString2, Map paramMap);

  public abstract void updateExtInfo(String paramString1, String paramString2, Map paramMap);

  public abstract void deleteExtInfo(String paramString1, String paramString2);

  public abstract Map getExtInfo(String paramString1, String paramString2);

  public abstract boolean isExistExtInfo(String paramString);

  public abstract void saveExtInfoWithBlob(String paramString1, String paramString2, Map paramMap, Form paramForm, String paramString3);

  public abstract void updateExtInfoWithBlob(String paramString1, String paramString2, Map paramMap, Form paramForm, String paramString3);

  public abstract Map getAllExtInfoByObjType(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ext.bo.ExtInfoBO
 * JD-Core Version:    0.6.2
 */