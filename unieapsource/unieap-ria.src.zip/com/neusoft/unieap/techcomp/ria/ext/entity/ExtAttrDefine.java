/*     */ package com.neusoft.unieap.techcomp.ria.ext.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ 
/*     */ @ModelFile("extAttrDefine.entity")
/*     */ public class ExtAttrDefine
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String controlType;
/*     */   private String readOnly;
/*     */   private Integer maxLength;
/*     */   private Integer minLength;
/*     */   private Integer decimalPrecision;
/*     */   private String attrName;
/*     */   private String objType;
/*     */   private Integer rowSpan;
/*     */   private String required;
/*     */   private Integer sort;
/*     */   private String codeType;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String fileInputFilter;
/*     */   private Integer fileInputSize;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String iconClass;
/*     */   private String columnName;
/*     */   private String columnType;
/*     */   private String tableName;
/*     */   private Integer labelColSpan;
/*     */   private Integer valueColSpan;
/*     */   private String displayStyle;
/*     */   private Map pojoContext;
/*     */   private Integer dialogWidth;
/*     */   private Integer dialogHeight;
/*     */   private String label;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/* 156 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 160 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setControlType(String paramString) {
/* 164 */     this.controlType = paramString;
/*     */   }
/*     */ 
/*     */   public String getControlType() {
/* 168 */     return this.controlType;
/*     */   }
/*     */ 
/*     */   public void setReadOnly(String paramString) {
/* 172 */     this.readOnly = paramString;
/*     */   }
/*     */ 
/*     */   public String getReadOnly() {
/* 176 */     return this.readOnly;
/*     */   }
/*     */ 
/*     */   public void setMaxLength(Integer paramInteger) {
/* 180 */     this.maxLength = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getMaxLength() {
/* 184 */     return this.maxLength;
/*     */   }
/*     */ 
/*     */   public void setMinLength(Integer paramInteger) {
/* 188 */     this.minLength = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getMinLength() {
/* 192 */     return this.minLength;
/*     */   }
/*     */ 
/*     */   public void setDecimalPrecision(Integer paramInteger) {
/* 196 */     this.decimalPrecision = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getDecimalPrecision() {
/* 200 */     return this.decimalPrecision;
/*     */   }
/*     */ 
/*     */   public void setAttrName(String paramString) {
/* 204 */     this.attrName = paramString;
/*     */   }
/*     */ 
/*     */   public String getAttrName() {
/* 208 */     return this.attrName;
/*     */   }
/*     */ 
/*     */   public void setObjType(String paramString) {
/* 212 */     this.objType = paramString;
/*     */   }
/*     */ 
/*     */   public String getObjType() {
/* 216 */     return this.objType;
/*     */   }
/*     */ 
/*     */   public void setRowSpan(Integer paramInteger) {
/* 220 */     this.rowSpan = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getRowSpan() {
/* 224 */     return this.rowSpan;
/*     */   }
/*     */ 
/*     */   public void setRequired(String paramString) {
/* 228 */     this.required = paramString;
/*     */   }
/*     */ 
/*     */   public String getRequired() {
/* 232 */     return this.required;
/*     */   }
/*     */ 
/*     */   public void setSort(Integer paramInteger) {
/* 236 */     this.sort = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getSort() {
/* 240 */     return this.sort;
/*     */   }
/*     */ 
/*     */   public void setCodeType(String paramString) {
/* 244 */     this.codeType = paramString;
/*     */   }
/*     */ 
/*     */   public String getCodeType() {
/* 248 */     return this.codeType;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 252 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/* 256 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/* 260 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/* 264 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setFileInputFilter(String paramString) {
/* 268 */     this.fileInputFilter = paramString;
/*     */   }
/*     */ 
/*     */   public String getFileInputFilter() {
/* 272 */     return this.fileInputFilter;
/*     */   }
/*     */ 
/*     */   public void setFileInputSize(Integer paramInteger) {
/* 276 */     this.fileInputSize = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getFileInputSize() {
/* 280 */     return this.fileInputSize;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 284 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/* 288 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/* 292 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/* 296 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setIconClass(String paramString) {
/* 300 */     this.iconClass = paramString;
/*     */   }
/*     */ 
/*     */   public String getIconClass() {
/* 304 */     return this.iconClass;
/*     */   }
/*     */ 
/*     */   public void setColumnName(String paramString) {
/* 308 */     this.columnName = paramString;
/*     */   }
/*     */ 
/*     */   public String getColumnName() {
/* 312 */     return this.columnName;
/*     */   }
/*     */ 
/*     */   public void setColumnType(String paramString) {
/* 316 */     this.columnType = paramString;
/*     */   }
/*     */ 
/*     */   public String getColumnType() {
/* 320 */     return this.columnType;
/*     */   }
/*     */ 
/*     */   public void setTableName(String paramString) {
/* 324 */     this.tableName = paramString;
/*     */   }
/*     */ 
/*     */   public String getTableName() {
/* 328 */     return this.tableName;
/*     */   }
/*     */ 
/*     */   public void setLabelColSpan(Integer paramInteger) {
/* 332 */     this.labelColSpan = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getLabelColSpan() {
/* 336 */     return this.labelColSpan;
/*     */   }
/*     */ 
/*     */   public void setValueColSpan(Integer paramInteger) {
/* 340 */     this.valueColSpan = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getValueColSpan() {
/* 344 */     return this.valueColSpan;
/*     */   }
/*     */ 
/*     */   public void setDisplayStyle(String paramString) {
/* 348 */     this.displayStyle = paramString;
/*     */   }
/*     */ 
/*     */   public String getDisplayStyle() {
/* 352 */     return this.displayStyle;
/*     */   }
/*     */ 
/*     */   public void setDialogWidth(Integer paramInteger) {
/* 356 */     this.dialogWidth = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getDialogWidth() {
/* 360 */     return this.dialogWidth;
/*     */   }
/*     */ 
/*     */   public void setDialogHeight(Integer paramInteger) {
/* 364 */     this.dialogHeight = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getDialogHeight() {
/* 368 */     return this.dialogHeight;
/*     */   }
/*     */ 
/*     */   public void setLabel(String paramString) {
/* 372 */     this.label = paramString;
/*     */   }
/*     */ 
/*     */   public String getLabel() {
/* 376 */     return this.label;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine
 * JD-Core Version:    0.6.2
 */