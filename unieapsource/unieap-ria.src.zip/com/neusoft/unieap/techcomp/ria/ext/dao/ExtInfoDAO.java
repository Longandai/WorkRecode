package com.neusoft.unieap.techcomp.ria.ext.dao;

import java.util.List;
import java.util.Map;

public abstract interface ExtInfoDAO
{
  public abstract List getExtAttrDefinesByObjType(String paramString);

  public abstract Map getExtInfo(List paramList, String paramString);

  public abstract void saveExtInfo(List paramList, Map paramMap);

  public abstract void updateExtInfo(List paramList, Map paramMap);

  public abstract void deleteExtInfo(List paramList, String paramString);

  public abstract Map getAllExtInfoByObjType(List paramList, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ext.dao.ExtInfoDAO
 * JD-Core Version:    0.6.2
 */