/*     */ package com.neusoft.unieap.techcomp.ria.ext.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.dao.ExtInfoDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine;
/*     */ import java.sql.SQLException;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.dialect.Dialect;
/*     */ import org.hibernate.dialect.MySQL5Dialect;
/*     */ import org.hibernate.dialect.Oracle9Dialect;
/*     */ import org.hibernate.dialect.OracleDialect;
/*     */ import org.hibernate.dialect.SQLServerDialect;
/*     */ import org.hibernate.impl.SessionFactoryImpl;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("extInfoCommonDAO.dao")
/*     */ public class ExtInfoDAOImpl extends BaseHibernateDAO
/*     */   implements ExtInfoDAO
/*     */ {
/*     */   public List getExtAttrDefinesByObjType(String paramString)
/*     */   {
/*  40 */     String str = "from ExtAttrDefine extAttrDefine where extAttrDefine.objType = ? order by extAttrDefine.sort";
/*  41 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public Map getExtInfo(List paramList, final String paramString)
/*     */   {
/*  48 */     if ((paramList == null) || (paramList.size() == 0))
/*  49 */       return null;
/*  50 */     String str1 = ((ExtAttrDefine)paramList.get(0))
/*  51 */       .getTableName();
/*  52 */     StringBuffer localStringBuffer = new StringBuffer();
/*  53 */     localStringBuffer.append("select id,");
/*     */     ExtAttrDefine localExtAttrDefine;
/*  55 */     for (int i = 0; i < paramList.size(); i++) {
/*  56 */       localExtAttrDefine = (ExtAttrDefine)paramList.get(i);
/*     */ 
/*  58 */       if (localExtAttrDefine.getControlType().equalsIgnoreCase(
/*  59 */         "unieap.form.FileInput")) {
/*  60 */         if (i == paramList.size() - 1)
/*  61 */           localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
/*     */       }
/*     */       else
/*     */       {
/*  65 */         localStringBuffer.append(localExtAttrDefine.getColumnName());
/*  66 */         if (i < paramList.size() - 1)
/*  67 */           localStringBuffer.append(","); 
/*     */       }
/*     */     }
/*  69 */     localStringBuffer.append(" from " + str1 + " where id = ?");
/*  70 */     final String str2 = localStringBuffer.toString();
/*  71 */     List localList = (List)getHibernateTemplate().execute(
/*  72 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  75 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(str2);
/*  76 */         localSQLQuery.setParameter(0, paramString);
/*  77 */         return localSQLQuery.list();
/*     */       }
/*     */     });
/*  81 */     if (localList.size() == 0)
/*  82 */       return null;
/*  83 */     HashMap localHashMap = new HashMap();
/*     */ 
/*  85 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/*  86 */       .getDialect();
/*     */ 
/*  88 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*  89 */     for (int j = 0; j < paramList.size(); j++) {
/*  90 */       localExtAttrDefine = (ExtAttrDefine)paramList.get(j);
/*     */ 
/*  93 */       if (!localExtAttrDefine.getControlType().equalsIgnoreCase(
/*  94 */         "unieap.form.FileInput")) {
/*  95 */         Object localObject = ((Object[])localList.get(0))[(j + 1)];
/*  96 */         if (((localDialect instanceof SQLServerDialect)) && (localObject != null) && 
/*  97 */           (!(localObject instanceof java.sql.Date)) && 
/*  98 */           ("Date".equals(localExtAttrDefine.getColumnType()))) {
/*  99 */           String str3 = (String)localObject;
/*     */           try {
/* 101 */             localHashMap.put(localExtAttrDefine.getAttrName(), new java.sql.Date(
/* 102 */               localSimpleDateFormat.parse(str3).getTime()));
/*     */           } catch (ParseException localParseException) {
/* 104 */             localParseException.printStackTrace();
/*     */           }
/*     */         } else {
/* 107 */           localHashMap.put(localExtAttrDefine.getAttrName(), localObject);
/*     */         }
/*     */       }
/*     */     }
/* 111 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public void saveExtInfo(List paramList, Map paramMap)
/*     */   {
/* 118 */     if ((paramList == null) || (paramList.size() == 0) || 
/* 119 */       (paramMap == null))
/* 120 */       return;
/* 121 */     StringBuffer localStringBuffer = new StringBuffer();
/*     */ 
/* 123 */     String str1 = null;
/* 124 */     String str2 = null;
/* 125 */     final ArrayList localArrayList1 = new ArrayList();
/* 126 */     localArrayList1.add(paramMap.get("id"));
/* 127 */     localStringBuffer.append("insert into ");
/*     */     ExtAttrDefine localExtAttrDefine;
/* 128 */     for (int i = 0; i < paramList.size(); i++) {
/* 129 */       localExtAttrDefine = (ExtAttrDefine)paramList.get(i);
/* 130 */       if (i == 0) {
/* 131 */         str1 = localExtAttrDefine.getTableName();
/* 132 */         localStringBuffer.append(str1);
/* 133 */         localStringBuffer.append("(id,");
/*     */       }
/* 135 */       localStringBuffer.append(localExtAttrDefine.getColumnName());
/* 136 */       if (i < paramList.size() - 1) {
/* 137 */         localStringBuffer.append(",");
/*     */       }
/*     */     }
/* 140 */     localStringBuffer.append(")");
/* 141 */     localStringBuffer.append(" values");
/* 142 */     localStringBuffer.append("(?,");
/*     */ 
/* 144 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/* 145 */       .getDialect();
/* 146 */     ArrayList localArrayList2 = new ArrayList();
/* 147 */     for (int j = 0; j < paramList.size(); j++) {
/* 148 */       localExtAttrDefine = (ExtAttrDefine)paramList.get(j);
/* 149 */       str2 = localExtAttrDefine.getAttrName();
/* 150 */       if (localExtAttrDefine.getColumnType().equals("Date")) {
/* 151 */         if ((paramMap.get(str2) != null) && 
/* 152 */           (!paramMap.get(str2).equals(""))) {
/* 153 */           localObject = new java.sql.Date(Long.parseLong(paramMap.get(str2)
/* 154 */             .toString()));
/* 155 */           localArrayList1.add(((java.sql.Date)localObject).toString());
/*     */         }
/* 157 */         else if ((localDialect instanceof MySQL5Dialect)) {
/* 158 */           localArrayList1.add(null);
/* 159 */         } else if ((localDialect instanceof SQLServerDialect)) {
/* 160 */           localArrayList2.add(String.valueOf(localArrayList1.size()));
/* 161 */           localArrayList1.add(null);
/*     */         }
/*     */         else {
/* 164 */           localArrayList1.add("");
/*     */         }
/*     */ 
/* 167 */         if (((localDialect instanceof OracleDialect)) || 
/* 168 */           ((localDialect instanceof Oracle9Dialect)))
/* 169 */           localStringBuffer.append("to_date(?,'YYYY-MM-DD')");
/*     */         else
/* 171 */           localStringBuffer.append("?");
/*     */       } else {
/* 173 */         if (paramMap.get(str2) != null)
/* 174 */           localArrayList1.add(paramMap.get(str2));
/* 175 */         else if (((localDialect instanceof OracleDialect)) || 
/* 176 */           ((localDialect instanceof Oracle9Dialect)))
/* 177 */           localArrayList1.add("");
/*     */         else
/* 179 */           localArrayList1.add(null);
/* 180 */         localStringBuffer.append("?");
/*     */       }
/* 182 */       if (j < paramList.size() - 1) {
/* 183 */         localStringBuffer.append(",");
/*     */       }
/*     */     }
/* 186 */     localStringBuffer.append(")");
/* 187 */     final ArrayList localArrayList3 = localArrayList2;
/* 188 */     Object localObject = localStringBuffer.toString();
/*     */ 
/* 190 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 193 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(this.val$sql);
/* 194 */         for (int i = 0; i < localArrayList1.size(); i++) {
/* 195 */           if (localArrayList3.contains(String.valueOf(i)))
/* 196 */             localSQLQuery.setString(i, null);
/*     */           else {
/* 198 */             localSQLQuery.setParameter(i, localArrayList1.get(i));
/*     */           }
/*     */         }
/* 201 */         return Integer.valueOf(localSQLQuery.executeUpdate());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void updateExtInfo(List paramList, Map paramMap)
/*     */   {
/* 210 */     if ((paramList == null) || (paramList.size() == 0) || 
/* 211 */       (paramMap == null))
/* 212 */       return;
/* 213 */     StringBuffer localStringBuffer = new StringBuffer();
/*     */ 
/* 215 */     String str1 = null;
/* 216 */     String str2 = null;
/* 217 */     final ArrayList localArrayList1 = new ArrayList();
/* 218 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/* 219 */       .getDialect();
/* 220 */     ArrayList localArrayList2 = new ArrayList();
/* 221 */     for (int i = 0; i < paramList.size(); i++) {
/* 222 */       ExtAttrDefine localExtAttrDefine = (ExtAttrDefine)paramList.get(i);
/* 223 */       if (i == 0) {
/* 224 */         str1 = localExtAttrDefine.getTableName();
/* 225 */         localStringBuffer.append("update " + str1);
/* 226 */         localStringBuffer.append(" set ");
/*     */       }
/* 228 */       str2 = localExtAttrDefine.getAttrName();
/* 229 */       localStringBuffer.append(localExtAttrDefine.getColumnName());
/* 230 */       localStringBuffer.append("=");
/* 231 */       if (localExtAttrDefine.getColumnType().equals("Date")) {
/* 232 */         if ((paramMap.get(str2) != null) && 
/* 233 */           (!paramMap.get(str2).equals(""))) {
/* 234 */           localObject = new java.sql.Date(Long.parseLong(paramMap.get(str2)
/* 235 */             .toString()));
/* 236 */           localArrayList1.add(((java.sql.Date)localObject).toString());
/*     */         }
/* 238 */         else if ((localDialect instanceof MySQL5Dialect)) {
/* 239 */           localArrayList1.add(null);
/* 240 */         } else if ((localDialect instanceof SQLServerDialect)) {
/* 241 */           localArrayList2.add(String.valueOf(localArrayList1.size()));
/* 242 */           localArrayList1.add(null);
/*     */         }
/*     */         else {
/* 245 */           localArrayList1.add("");
/*     */         }
/* 247 */         if (((localDialect instanceof OracleDialect)) || 
/* 248 */           ((localDialect instanceof Oracle9Dialect)))
/* 249 */           localStringBuffer.append("to_date(?,'YYYY-MM-DD')");
/*     */         else
/* 251 */           localStringBuffer.append("?");
/*     */       } else {
/* 253 */         if (paramMap.get(str2) != null)
/* 254 */           localArrayList1.add(paramMap.get(str2));
/* 255 */         else if (((localDialect instanceof OracleDialect)) || 
/* 256 */           ((localDialect instanceof Oracle9Dialect)))
/* 257 */           localArrayList1.add("");
/*     */         else
/* 259 */           localArrayList1.add(null);
/* 260 */         localStringBuffer.append("?");
/*     */       }
/* 262 */       if (i < paramList.size() - 1) {
/* 263 */         localStringBuffer.append(",");
/*     */       }
/*     */     }
/* 266 */     localStringBuffer.append(" where id = ?");
/* 267 */     localArrayList1.add(paramMap.get("id"));
/*     */ 
/* 269 */     final ArrayList localArrayList3 = localArrayList2;
/* 270 */     Object localObject = localStringBuffer.toString();
/*     */ 
/* 272 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 275 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(this.val$sql);
/* 276 */         for (int i = 0; i < localArrayList1.size(); i++) {
/* 277 */           if (localArrayList3.contains(String.valueOf(i)))
/* 278 */             localSQLQuery.setString(i, null);
/*     */           else {
/* 280 */             localSQLQuery.setParameter(i, localArrayList1.get(i));
/*     */           }
/*     */         }
/* 283 */         return Integer.valueOf(localSQLQuery.executeUpdate());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void deleteExtInfo(List paramList, final String paramString)
/*     */   {
/* 292 */     if ((paramList == null) || (paramList.size() == 0))
/* 293 */       return;
/* 294 */     String str1 = ((ExtAttrDefine)paramList.get(0))
/* 295 */       .getTableName();
/* 296 */     final String str2 = "delete from " + str1 + " where id = ?";
/* 297 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 300 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(str2);
/* 301 */         localSQLQuery.setParameter(0, paramString);
/* 302 */         return Integer.valueOf(localSQLQuery.executeUpdate());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Map getAllExtInfoByObjType(List paramList, String paramString)
/*     */   {
/* 311 */     if ((paramList == null) || (paramList.size() == 0))
/* 312 */       return null;
/* 313 */     String str1 = ((ExtAttrDefine)paramList.get(0))
/* 314 */       .getTableName();
/* 315 */     StringBuffer localStringBuffer = new StringBuffer();
/* 316 */     localStringBuffer.append("select id,");
/*     */     ExtAttrDefine localExtAttrDefine;
/* 318 */     for (int i = 0; i < paramList.size(); i++) {
/* 319 */       localExtAttrDefine = (ExtAttrDefine)paramList.get(i);
/*     */ 
/* 321 */       if (localExtAttrDefine.getControlType().equalsIgnoreCase(
/* 322 */         "unieap.form.FileInput")) {
/* 323 */         if (i == paramList.size() - 1)
/* 324 */           localStringBuffer.deleteCharAt(localStringBuffer.length() - 1);
/*     */       }
/*     */       else
/*     */       {
/* 328 */         localStringBuffer.append(localExtAttrDefine.getColumnName());
/* 329 */         if (i < paramList.size() - 1)
/* 330 */           localStringBuffer.append(","); 
/*     */       }
/*     */     }
/* 332 */     localStringBuffer.append(" from " + str1);
/* 333 */     final String str2 = localStringBuffer.toString();
/* 334 */     List localList = (List)getHibernateTemplate().execute(
/* 335 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 338 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(str2);
/* 339 */         return localSQLQuery.list();
/*     */       }
/*     */     });
/* 343 */     HashMap localHashMap1 = new HashMap();
/* 344 */     if (localList.size() == 0) {
/* 345 */       return localHashMap1;
/*     */     }
/* 347 */     HashMap localHashMap2 = new HashMap();
/* 348 */     String str3 = null;
/* 349 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/* 350 */       .getDialect();
/* 351 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
/*     */ 
/* 353 */     for (int j = 0; j < localList.size(); j++) {
/* 354 */       str3 = (String)((Object[])localList.get(j))[0];
/* 355 */       localHashMap1 = new HashMap();
/* 356 */       for (int k = 0; k < paramList.size(); k++) {
/* 357 */         localExtAttrDefine = (ExtAttrDefine)paramList.get(k);
/*     */ 
/* 359 */         if (!localExtAttrDefine.getControlType().equalsIgnoreCase("unieap.form.FileInput")) {
/* 360 */           Object localObject = ((Object[])localList.get(j))[(k + 1)];
/* 361 */           if (((localDialect instanceof SQLServerDialect)) && (localObject != null) && 
/* 362 */             (!(localObject instanceof java.sql.Date)) && 
/* 363 */             ("Date".equals(localExtAttrDefine.getColumnType()))) {
/* 364 */             String str4 = (String)localObject;
/*     */             try {
/* 366 */               localHashMap1.put(localExtAttrDefine.getAttrName(), new java.sql.Date(
/* 367 */                 localSimpleDateFormat.parse(str4).getTime()));
/*     */             } catch (ParseException localParseException) {
/* 369 */               localParseException.printStackTrace();
/*     */             }
/*     */           } else {
/* 372 */             localHashMap1.put(localExtAttrDefine.getAttrName(), localObject);
/*     */           }
/*     */         }
/*     */       }
/* 376 */       localHashMap2.put(str3, localHashMap1);
/*     */     }
/*     */ 
/* 379 */     return localHashMap2;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ext.dao.impl.ExtInfoDAOImpl
 * JD-Core Version:    0.6.2
 */