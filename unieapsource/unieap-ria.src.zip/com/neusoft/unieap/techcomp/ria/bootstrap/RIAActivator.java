/*    */ package com.neusoft.unieap.techcomp.ria.bootstrap;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.model.DCActivator;
/*    */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.ICacheUpdater;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.activator.CodelistActivator;
/*    */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ import org.apache.log4j.Level;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class RIAActivator extends DCActivator
/*    */ {
/*    */   private MenuBO menuBO;
/*    */   private CodelistActivator codeList;
/*    */   private CacheSynchronizeManager cacheSynchronizeManager;
/*    */   private ICacheUpdater menuCacheUpdater;
/*    */ 
/*    */   public void setMenuCacheUpdater(ICacheUpdater paramICacheUpdater)
/*    */   {
/* 22 */     this.menuCacheUpdater = paramICacheUpdater;
/*    */   }
/*    */ 
/*    */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*    */   {
/* 27 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*    */   }
/*    */ 
/*    */   public void setCodeList(CodelistActivator paramCodelistActivator) {
/* 31 */     this.codeList = paramCodelistActivator;
/*    */   }
/*    */ 
/*    */   public void setMenuBO(MenuBO paramMenuBO) {
/* 35 */     this.menuBO = paramMenuBO;
/*    */   }
/*    */ 
/*    */   public void shutdown()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void startup() throws Exception
/*    */   {
/* 45 */     Logger localLogger = Logger.getLogger(PropertyUtils.class);
/* 46 */     Level localLevel = localLogger.getEffectiveLevel();
/* 47 */     int i = 5000;
/* 48 */     if (localLevel.toInt() <= i)
/*    */     {
/* 50 */       localLogger.setLevel(Level.DEBUG);
/* 51 */       LocalizedTextUtil localLocalizedTextUtil = LocalizedTextUtil.getLocalizedTextUtil(getClass());
/* 52 */       localLogger.info(localLocalizedTextUtil.findText("TRACEDISABLED"));
/*    */     }
/*    */ 
/* 56 */     this.menuBO.initCache();
/*    */ 
/* 58 */     this.cacheSynchronizeManager.registerCacheUpdater("menu", this.menuCacheUpdater);
/*    */ 
/* 61 */     this.codeList.startup();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.bootstrap.RIAActivator
 * JD-Core Version:    0.6.2
 */