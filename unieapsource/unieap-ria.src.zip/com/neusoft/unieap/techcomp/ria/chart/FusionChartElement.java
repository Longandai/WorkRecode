/*    */ package com.neusoft.unieap.techcomp.ria.chart;
/*    */ 
/*    */ public class FusionChartElement
/*    */ {
/*    */   private String label;
/*    */   private String value;
/*    */ 
/*    */   public String getLabel()
/*    */   {
/* 10 */     return this.label;
/*    */   }
/*    */ 
/*    */   public void setLabel(String paramString) {
/* 14 */     this.label = paramString;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 18 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String paramString) {
/* 22 */     this.value = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.chart.FusionChartElement
 * JD-Core Version:    0.6.2
 */