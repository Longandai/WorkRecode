package com.neusoft.unieap.techcomp.ria.multilanguage.bo;

import com.neusoft.unieap.core.common.bo.context.BOContext;
import java.util.List;

public abstract interface MultiLanguageBO
{
  public abstract BOContext getMultiLanguageHTML(String paramString1, String paramString2, String paramString3, Object paramObject);

  public abstract void saveMultiLanguageData(List paramList, String paramString1, String paramString2);

  public abstract BOContext getMulitLanguageConfig(Object paramObject);

  public abstract String generateFormList(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.multilanguage.bo.MultiLanguageBO
 * JD-Core Version:    0.6.2
 */