/*     */ package com.neusoft.unieap.techcomp.ria.multilanguage.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.techcomp.ria.multilanguage.dao.MultiLanguageDAO;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SQLQuery;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.persister.entity.AbstractEntityPersister;
/*     */ import org.hibernate.type.ManyToOneType;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("multiLanguageDAO.dao")
/*     */ public class MultiLanguageDAOImpl extends BaseHibernateDAO
/*     */   implements MultiLanguageDAO
/*     */ {
/*     */   public Map getVLClassMetaData(String paramString)
/*     */   {
/*  41 */     Map localMap = getSessionFactory().getAllClassMetadata();
/*  42 */     if (localMap != null) {
/*  43 */       Collection localCollection = localMap.values();
/*  44 */       Iterator localIterator = localCollection.iterator();
/*  45 */       while (localIterator.hasNext()) {
/*  46 */         AbstractEntityPersister localAbstractEntityPersister = 
/*  47 */           (AbstractEntityPersister)localIterator
/*  47 */           .next();
/*  48 */         if (paramString.equals(localAbstractEntityPersister.getEntityName())) {
/*  49 */           HashMap localHashMap = new HashMap();
/*  50 */           localHashMap.put("tableName", localAbstractEntityPersister.getTableName());
/*  51 */           localHashMap.put("primaryKey", localAbstractEntityPersister
/*  52 */             .getIdentifierPropertyName());
/*  53 */           return localHashMap;
/*     */         }
/*     */       }
/*     */     }
/*  57 */     return null;
/*     */   }
/*     */ 
/*     */   public Map getMLClassMetaData(String paramString)
/*     */   {
/*  65 */     Map localMap = getSessionFactory().getAllClassMetadata();
/*  66 */     if (localMap != null) {
/*  67 */       Collection localCollection = localMap.values();
/*  68 */       Iterator localIterator = localCollection.iterator();
/*  69 */       while (localIterator.hasNext()) {
/*  70 */         AbstractEntityPersister localAbstractEntityPersister = (AbstractEntityPersister)localIterator.next();
/*  71 */         if (paramString.equals(localAbstractEntityPersister.getTableName())) {
/*  72 */           HashMap localHashMap = new HashMap();
/*  73 */           localHashMap.put("rowsetName", localAbstractEntityPersister.getEntityName());
/*  74 */           localHashMap.put("primaryKey", localAbstractEntityPersister
/*  75 */             .getIdentifierPropertyName());
/*  76 */           for (String str : localAbstractEntityPersister.getPropertyNames()) {
/*  77 */             if ((localAbstractEntityPersister.getPropertyType(str) instanceof ManyToOneType)) {
/*  78 */               localHashMap.put("foreignKey", str);
/*  79 */               localHashMap.put("foreignColumn", localAbstractEntityPersister.getPropertyColumnNames(str)[0]);
/*  80 */               break;
/*     */             }
/*     */           }
/*  83 */           return localHashMap;
/*     */         }
/*     */       }
/*     */     }
/*  87 */     return null;
/*     */   }
/*     */ 
/*     */   public Map getBTClassMetaData(String paramString)
/*     */   {
/*  95 */     Map localMap = getSessionFactory().getAllClassMetadata();
/*  96 */     if (localMap != null) {
/*  97 */       Collection localCollection = localMap.values();
/*  98 */       Iterator localIterator = localCollection.iterator();
/*  99 */       while (localIterator.hasNext()) {
/* 100 */         AbstractEntityPersister localAbstractEntityPersister = (AbstractEntityPersister)localIterator.next();
/* 101 */         if (paramString.equals(localAbstractEntityPersister.getTableName())) {
/* 102 */           HashMap localHashMap = new HashMap();
/* 103 */           localHashMap.put("rowsetName", localAbstractEntityPersister.getEntityName());
/* 104 */           localHashMap.put("primaryKey", localAbstractEntityPersister
/* 105 */             .getIdentifierPropertyName());
/* 106 */           return localHashMap;
/*     */         }
/*     */       }
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   public QueryResult getMultiLanguageData(String paramString, Object paramObject, List paramList)
/*     */   {
/* 167 */     Map localMap = getMLClassMetaData(paramString);
/* 168 */     String str1 = String.valueOf(localMap.get("foreignColumn"));
/* 169 */     String str2 = "select * from " + paramString + " t where t." + str1 + " = ?";
/* 170 */     QueryResult localQueryResult = query(str2, new Object[] { paramObject });
/* 171 */     List localList = localQueryResult.getResult();
/* 172 */     if (localList == null) {
/* 173 */       return null;
/*     */     }
/* 175 */     ArrayList localArrayList = new ArrayList();
/* 176 */     Object localObject = null;
/* 177 */     for (int i = 0; i < paramList.size(); i++) {
/* 178 */       String str3 = String.valueOf(paramList.get(i));
/* 179 */       if (str3 != null) {
/* 180 */         for (int j = 0; j < localList.size(); j++) {
/*     */           try {
/* 182 */             localObject = PropertyUtils.getProperty(localList.get(j), "LANGUAGE");
/* 183 */             if (localObject == null)
/* 184 */               localObject = PropertyUtils.getProperty(localList.get(j), "language");
/*     */           }
/*     */           catch (Exception localException) {
/* 187 */             localObject = null;
/*     */           }
/* 189 */           if (str3.equals(String.valueOf(localObject))) {
/* 190 */             localArrayList.add(localList.get(j));
/* 191 */             break;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 196 */     if (localArrayList.size() > 0) {
/* 197 */       localQueryResult.setResult(localArrayList);
/*     */     }
/* 199 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public void saveMultiLanguageData(List paramList, Object paramObject, String paramString)
/*     */   {
/* 207 */     int i = paramList.size();
/* 208 */     Map localMap1 = getMLClassMetaData(paramString);
/* 209 */     Map localMap2 = getBTClassMetaData(paramString.substring(0, paramString.length() - 3));
/* 210 */     String str1 = String.valueOf(localMap1.get("rowsetName"));
/* 211 */     String str2 = String.valueOf(localMap1.get("primaryKey"));
/* 212 */     String str3 = String.valueOf(localMap1.get("foreignKey"));
/* 213 */     String str4 = String.valueOf(localMap2.get("rowsetName"));
/* 214 */     String str5 = String.valueOf(localMap2.get("primaryKey"));
/*     */     try {
/* 216 */       Object localObject1 = Class.forName(str4).newInstance();
/* 217 */       PropertyUtils.setProperty(localObject1, str5, paramObject);
/* 218 */       Object localObject2 = null;
/* 219 */       for (int j = 0; j < i; j++) {
/* 220 */         Object localObject3 = paramList.get(j);
/* 221 */         Object localObject4 = Class.forName(str1).newInstance();
/* 222 */         PropertyDescriptor[] arrayOfPropertyDescriptor1 = PropertyUtils.getPropertyDescriptors(localObject4);
/* 223 */         if (arrayOfPropertyDescriptor1 != null) {
/* 224 */           for (PropertyDescriptor localPropertyDescriptor : arrayOfPropertyDescriptor1) {
/* 225 */             String str6 = localPropertyDescriptor.getName();
/* 226 */             if ((!str2.equals(str6)) && (!"class".equals(str6)))
/*     */             {
/* 229 */               if (str3.equals(localPropertyDescriptor.getName())) {
/* 230 */                 PropertyUtils.setProperty(localObject4, str6, localObject1);
/*     */               } else {
/*     */                 try {
/* 233 */                   localObject2 = PropertyUtils.getProperty(localObject3, str6);
/*     */                 } catch (Exception localException1) {
/* 235 */                   localObject2 = null;
/*     */                 }
/* 237 */                 PropertyUtils.setProperty(localObject4, str6, localObject2);
/*     */               }
/*     */             }
/*     */           }
/* 240 */           addObject(localObject4);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException2)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delMultiLanguageData(final Object paramObject, String paramString)
/*     */   {
/* 273 */     String str1 = String.valueOf(getMLClassMetaData(paramString).get("foreignColumn"));
/* 274 */     final String str2 = "delete from " + paramString + " t where t." + str1 + " = ?";
/* 275 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 278 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(str2);
/* 279 */         localSQLQuery.setParameter(0, paramObject);
/* 280 */         localSQLQuery.executeUpdate();
/* 281 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.multilanguage.dao.impl.MultiLanguageDAOImpl
 * JD-Core Version:    0.6.2
 */