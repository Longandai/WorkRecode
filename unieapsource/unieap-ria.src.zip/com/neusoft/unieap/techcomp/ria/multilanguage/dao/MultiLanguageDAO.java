package com.neusoft.unieap.techcomp.ria.multilanguage.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import java.util.List;
import java.util.Map;

public abstract interface MultiLanguageDAO
{
  public abstract Map getVLClassMetaData(String paramString);

  public abstract Map getMLClassMetaData(String paramString);

  public abstract QueryResult getMultiLanguageData(String paramString, Object paramObject, List paramList);

  public abstract void saveMultiLanguageData(List paramList, Object paramObject, String paramString);

  public abstract void delMultiLanguageData(Object paramObject, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.multilanguage.dao.MultiLanguageDAO
 * JD-Core Version:    0.6.2
 */