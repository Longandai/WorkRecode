/*    */ package com.neusoft.unieap.techcomp.ria.multilanguage.util;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*    */ import java.math.BigDecimal;
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class CodeComparator
/*    */   implements Comparator<Code>
/*    */ {
/*    */   public int compare(Code paramCode1, Code paramCode2)
/*    */   {
/* 10 */     if (paramCode1.getCodeOrder() == null) {
/* 11 */       return 1;
/*    */     }
/* 13 */     return paramCode1.getCodeOrder().compareTo(paramCode2.getCodeOrder());
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.multilanguage.util.CodeComparator
 * JD-Core Version:    0.6.2
 */