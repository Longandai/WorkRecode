/*     */ package com.neusoft.unieap.techcomp.ria.multilanguage.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.core.variability.VarManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import com.neusoft.unieap.techcomp.ria.multilanguage.bo.MultiLanguageBO;
/*     */ import com.neusoft.unieap.techcomp.ria.multilanguage.dao.MultiLanguageDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.multilanguage.util.CodeComparator;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ @ModelFile("multiLanguageBO.bo")
/*     */ public class MultiLanguageBOImpl
/*     */   implements MultiLanguageBO
/*     */ {
/*     */   private MultiLanguageDAO multiLanguageDAO;
/*     */   private CodeListManager codeListManager;
/*     */ 
/*     */   public void setMultiLanguageDAO(MultiLanguageDAO paramMultiLanguageDAO)
/*     */   {
/*  42 */     this.multiLanguageDAO = paramMultiLanguageDAO;
/*     */   }
/*     */ 
/*     */   public void setCodeListManager(CodeListManager paramCodeListManager) {
/*  46 */     this.codeListManager = paramCodeListManager;
/*     */   }
/*     */ 
/*     */   public BOContext getMultiLanguageHTML(String paramString1, String paramString2, String paramString3, Object paramObject)
/*     */   {
/*  54 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/*     */ 
/*  56 */     localBOContextImpl.put("language", GlobalService.getUserI18nContext().getLocale().toString());
/*     */ 
/*  58 */     localBOContextImpl.put("supportLanguage", ((VarManager)BeanUtil.getBean("variability_varManager_bo")).getValue("supportLanguage"));
/*     */ 
/*  60 */     CodeList localCodeList = this.codeListManager.getCodeList("core_language");
/*  61 */     Code localCode = null;
/*  62 */     ArrayList localArrayList1 = new ArrayList();
/*  63 */     ArrayList localArrayList2 = new ArrayList();
/*  64 */     StringBuilder localStringBuilder1 = new StringBuilder();
/*  65 */     List localList = localCodeList.getSoleCodeList();
/*  66 */     CodeComparator localCodeComparator = new CodeComparator();
/*  67 */     Collections.sort(localList, localCodeComparator);
/*     */     Object localObject1;
/*  68 */     for (int i = 0; i < localList.size(); i++) {
/*  69 */       localCode = (Code)localList.get(i);
/*  70 */       localObject1 = new HashMap();
/*  71 */       ((Map)localObject1).put("ID", localCode.getCodeValue());
/*  72 */       ((Map)localObject1).put("CODENAME", localCode.getCodeName());
/*  73 */       ((Map)localObject1).put("CODEVALUE", localCode.getCodeValue());
/*  74 */       ((Map)localObject1).put("PARENTID", localCode.getParent());
/*  75 */       localStringBuilder1.append(localCode.getCodeName());
/*  76 */       if (i != localList.size() - 1) {
/*  77 */         localStringBuilder1.append(",");
/*     */       }
/*  79 */       localArrayList2.add(localCode.getCodeValue());
/*  80 */       localArrayList1.add(localObject1);
/*     */     }
/*  82 */     localBOContextImpl.put("codelist", localArrayList1);
/*     */ 
/*  84 */     if (paramString1 != null) {
/*  85 */       StringBuilder localStringBuilder2 = new StringBuilder();
/*  86 */       localStringBuilder2.append(generateComboBox(paramString1));
/*  87 */       localStringBuilder2.append("<div id ='ml_formList_div'>\n");
/*  88 */       localStringBuilder2.append(generateFormList(paramString2, paramString3));
/*  89 */       localStringBuilder2.append("</div>\n");
/*  90 */       localStringBuilder2.append(generateButton());
/*  91 */       localBOContextImpl.put("multilanguageHTML", localStringBuilder2.toString());
/*     */ 
/*  93 */       if (paramObject != null) {
/*  94 */         localObject1 = this.multiLanguageDAO.getVLClassMetaData(paramObject.getClass().getCanonicalName());
/*  95 */         Object localObject2 = null;
/*     */         try {
/*  97 */           localObject2 = PropertyUtils.getProperty(paramObject, String.valueOf(((Map)localObject1).get("primaryKey")));
/*     */         } catch (Exception localException) {
/*     */         }
/* 100 */         String str1 = null;
/* 101 */         if (localObject2 != null) {
/* 102 */           String str2 = String.valueOf(((Map)localObject1).get("tableName"));
/* 103 */           str1 = str2.substring(0, str2.length() - 2) + "TL";
/* 104 */           localBOContextImpl.put("tableName", str1);
/* 105 */           localBOContextImpl.put("multilanguageData", this.multiLanguageDAO.getMultiLanguageData(str1, localObject2, localArrayList2));
/* 106 */           localBOContextImpl.put("fid", localObject2);
/*     */         } else {
/* 108 */           localBOContextImpl.put("codeNames", localStringBuilder1.toString());
/*     */         }
/*     */       }
/*     */     }
/* 112 */     return localBOContextImpl;
/*     */   }
/*     */ 
/*     */   private String generateComboBox(String paramString)
/*     */   {
/* 122 */     StringBuilder localStringBuilder = new StringBuilder();
/* 123 */     JSONObject localJSONObject = JSONObject.fromObject(paramString);
/* 124 */     int i = localJSONObject.size();
/* 125 */     int j = 0;
/* 126 */     Iterator localIterator = localJSONObject.keys();
/* 127 */     localStringBuilder.append("<table id='combobox1_tableLayout' width='100%' style='table-layout:fixed;'>\n");
/* 128 */     localStringBuilder.append("<colgroup>\n");
/* 129 */     localStringBuilder.append(" <col width='20%'></col>\n");
/* 130 */     localStringBuilder.append(" <col width='80%'></col>\n");
/* 131 */     localStringBuilder.append(" </colgroup>\n");
/* 132 */     localStringBuilder.append(" <tbody>\n");
/* 133 */     localStringBuilder.append(" <tr>\n");
/* 134 */     localStringBuilder.append(" <td colSpan='1' rowSpan='1'>\n");
/* 135 */     localStringBuilder.append("<label>属性名称<label/>\n");
/* 136 */     localStringBuilder.append(" </td>\n");
/* 137 */     localStringBuilder.append(" <td colSpan='1' rowSpan='1'>\n");
/* 138 */     localStringBuilder.append("<div dojoType='unieap.form.ComboBox' id='ml_comboBox' width='100%' onChange='multiLanguage.onChange' dataProvider=\"{customItem:[");
/* 139 */     while (localIterator.hasNext()) {
/* 140 */       String str = String.valueOf(localIterator.next());
/* 141 */       localStringBuilder.append("{CODEVALUE:");
/* 142 */       localStringBuilder.append("'" + str + "'");
/* 143 */       localStringBuilder.append(",CODENAME:");
/* 144 */       localStringBuilder.append("'" + localJSONObject.getString(str) + "'}");
/* 145 */       if (j != i - 1) {
/* 146 */         localStringBuilder.append(",");
/*     */       }
/* 148 */       j++;
/*     */     }
/* 150 */     localStringBuilder.append("]}\"></div>\n");
/* 151 */     localStringBuilder.append(" </td>\n");
/* 152 */     localStringBuilder.append(" </tr>\n");
/* 153 */     localStringBuilder.append(" </tbody>\n");
/* 154 */     localStringBuilder.append(" </table>\n");
/* 155 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public String generateFormList(String paramString1, String paramString2)
/*     */   {
/* 165 */     StringBuilder localStringBuilder = new StringBuilder();
/* 166 */     localStringBuilder.append("<div style='display:block;height:10px;width:100%'></div>");
/* 167 */     localStringBuilder.append("<hr></hr>\n");
/* 168 */     localStringBuilder.append("<div style='display:block;height:15px;width:100%'></div>");
/* 169 */     localStringBuilder.append("<div dojoType='unieapx.form.FormList' id='ml_formList' binding=\"{store:'mlDS'}\">\n");
/* 170 */     localStringBuilder.append("<table id='form1_tableLayout' width='100%' style='table-layout:fixed;'>\n");
/* 171 */     localStringBuilder.append("<colgroup>\n");
/* 172 */     localStringBuilder.append(" <col width='20%'></col>\n");
/* 173 */     localStringBuilder.append(" <col width='80%'></col>\n");
/* 174 */     localStringBuilder.append(" </colgroup>\n");
/* 175 */     localStringBuilder.append(" <tbody>\n");
/* 176 */     localStringBuilder.append(" <tr id='form1_0_tr'>\n");
/* 177 */     localStringBuilder.append(" <td id='td0' colSpan='1' rowSpan='1'>\n");
/* 178 */     localStringBuilder.append("<div dojoType='unieap.form.InlineEditBox' id='language' showUnderLine='false' disabled='true' width='100%' binding=\"{name:'language'}\" decoder=\"{store:'codelist'}\"></div>\n");
/* 179 */     localStringBuilder.append(" </td>\n");
/* 180 */     localStringBuilder.append(" <td id='td1' colSpan='1' rowSpan='1'>\n");
/* 181 */     localStringBuilder.append("<div dojoType='" + paramString2 + "' id='attr' width='100%' binding=\"{name:'" + paramString1 + "'}\"></div>\n");
/* 182 */     localStringBuilder.append(" </td>\n");
/* 183 */     localStringBuilder.append(" </tr>\n");
/* 184 */     localStringBuilder.append(" </tbody>\n");
/* 185 */     localStringBuilder.append(" </table>\n");
/* 186 */     localStringBuilder.append(" </div>\n");
/* 187 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   private String generateButton()
/*     */   {
/* 195 */     StringBuilder localStringBuilder = new StringBuilder();
/* 196 */     localStringBuilder.append("<div style='padding-top:20px;'>\n");
/* 197 */     localStringBuilder.append("<table id='ToolBar1' width='100%' style='table-layout:fixed;'>\n");
/* 198 */     localStringBuilder.append("<colgroup>\n");
/* 199 */     localStringBuilder.append("<col></col>\n");
/* 200 */     localStringBuilder.append("<col></col>\n");
/* 201 */     localStringBuilder.append("<col></col>\n");
/* 202 */     localStringBuilder.append("<col></col>\n");
/* 203 */     localStringBuilder.append("<col width='105px'></col>\n");
/* 204 */     localStringBuilder.append("<col width='105px'></col>\n");
/* 205 */     localStringBuilder.append("</colgroup>\n");
/* 206 */     localStringBuilder.append("<tbody>\n");
/* 207 */     localStringBuilder.append("<tr height='30px'>\n");
/* 208 */     localStringBuilder.append("<td></td><td></td><td></td><td></td>\n");
/* 209 */     localStringBuilder.append("<td>\n");
/* 210 */     localStringBuilder.append("<div dojoType='unieap.form.Button' iconClass='buttonSepTrue' id='okButton' label='保存' width='100px' onClick='multiLanguage.saveData'></div>\n");
/* 211 */     localStringBuilder.append("</td>\n");
/* 212 */     localStringBuilder.append("<td>\n");
/* 213 */     localStringBuilder.append("<div dojoType='unieap.form.Button' iconClass='buttonSepFalse' id='cancelButton' label='关闭' width='100px' onClick='multiLanguage.closeDialog'></div>\n");
/* 214 */     localStringBuilder.append("</td>\n");
/* 215 */     localStringBuilder.append("</tr>\n");
/* 216 */     localStringBuilder.append("</tbody>\n");
/* 217 */     localStringBuilder.append("</table>\n");
/* 218 */     localStringBuilder.append("</div>\n");
/* 219 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public void saveMultiLanguageData(List paramList, String paramString1, String paramString2)
/*     */   {
/* 227 */     if (paramList != null) {
/* 228 */       Object localObject1 = paramList.get(0);
/* 229 */       Object localObject2 = null;
/* 230 */       Map localMap = this.multiLanguageDAO.getVLClassMetaData(localObject1.getClass().getCanonicalName());
/* 231 */       Class localClass = null;
/*     */       try {
/* 233 */         localClass = PropertyUtils.getPropertyType(paramList.get(0), String.valueOf(localMap.get("primaryKey")));
/*     */       } catch (Exception localException1) {
/* 235 */         localException1.printStackTrace();
/*     */       }
/* 237 */       if (localClass != null) {
/*     */         try {
/* 239 */           localObject2 = localClass.getConstructor(
/* 240 */             new Class[] { String.class }).newInstance(
/* 241 */             new Object[] { paramString1 });
/*     */         } catch (Exception localException2) {
/* 243 */           localException2.printStackTrace();
/*     */         }
/*     */       }
/* 246 */       if (localObject2 == null) {
/* 247 */         localObject2 = paramString1;
/*     */       }
/* 249 */       this.multiLanguageDAO.delMultiLanguageData(localObject2, paramString2);
/* 250 */       this.multiLanguageDAO.saveMultiLanguageData(paramList, localObject2, paramString2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BOContext getMulitLanguageConfig(Object paramObject)
/*     */   {
/* 259 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/*     */ 
/* 261 */     localBOContextImpl.put("supportLanguage", ((VarManager)BeanUtil.getBean("variability_varManager_bo")).getValue("supportLanguage"));
/* 262 */     if (paramObject != null) {
/* 263 */       Map localMap = this.multiLanguageDAO.getVLClassMetaData(paramObject.getClass().getCanonicalName());
/* 264 */       Object localObject = null;
/*     */       try {
/* 266 */         localObject = PropertyUtils.getProperty(paramObject, String.valueOf(localMap.get("primaryKey")));
/*     */       } catch (Exception localException) {
/* 268 */         localException.printStackTrace();
/*     */       }
/* 270 */       if (localObject != null)
/* 271 */         localBOContextImpl.put("hasData", Boolean.valueOf(true));
/*     */       else {
/* 273 */         localBOContextImpl.put("hasData", Boolean.valueOf(false));
/*     */       }
/*     */     }
/* 276 */     return localBOContextImpl;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.multilanguage.bo.impl.MultiLanguageBOImpl
 * JD-Core Version:    0.6.2
 */