package com.neusoft.unieap.techcomp.ria.bo.unittest;

public abstract interface TestDaylightSavingTimeBO
{
  public abstract long testCSTChangeToGMT(String paramString);

  public abstract long testGMTChangeToCST(String paramString);

  public abstract long testCSTChangeToGMTForJapan(String paramString);

  public abstract long testCSTChangeToGMTForAmerica(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.bo.unittest.TestDaylightSavingTimeBO
 * JD-Core Version:    0.6.2
 */