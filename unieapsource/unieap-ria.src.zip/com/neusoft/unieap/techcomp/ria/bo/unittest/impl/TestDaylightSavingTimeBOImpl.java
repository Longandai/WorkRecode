/*    */ package com.neusoft.unieap.techcomp.ria.bo.unittest.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*    */ import com.neusoft.unieap.core.i18n.GlobalService;
/*    */ import com.neusoft.unieap.techcomp.ria.bo.unittest.TestDaylightSavingTimeBO;
/*    */ import com.neusoft.unieap.techcomp.ria.util.GMT;
/*    */ import java.text.ParseException;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ @ModelFile("unittest/testDaylightSavingTimeBO.bo")
/*    */ public class TestDaylightSavingTimeBOImpl
/*    */   implements TestDaylightSavingTimeBO
/*    */ {
/*    */   public long testCSTChangeToGMT(String paramString)
/*    */   {
/* 24 */     Date localDate = getDateFromString(paramString);
/* 25 */     long l1 = localDate.getTime();
/* 26 */     long l2 = GMT.fromCSTToGMT(localDate);
/* 27 */     return (l1 - l2) / 3600000L;
/*    */   }
/*    */ 
/*    */   private Date getDateFromString(String paramString)
/*    */   {
/* 40 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 41 */     Date localDate = null;
/*    */     try {
/* 43 */       localDate = localSimpleDateFormat.parse(paramString);
/*    */     } catch (ParseException localParseException) {
/* 45 */       localParseException.printStackTrace();
/*    */     }
/* 47 */     return localDate;
/*    */   }
/*    */ 
/*    */   public long testGMTChangeToCST(String paramString) {
/* 51 */     Date localDate1 = getDateFromString(paramString);
/* 52 */     long l = localDate1.getTime();
/* 53 */     Date localDate2 = GMT.fromGMTToCST(localDate1.getTime());
/* 54 */     return (l - localDate2.getTime()) / 3600000L;
/*    */   }
/*    */ 
/*    */   public long testCSTChangeToGMTForJapan(String paramString) {
/* 58 */     TimeZone localTimeZone1 = GlobalService.getDefaultI18nContext()
/* 59 */       .getTimeZone();
/*    */ 
/* 61 */     TimeZone localTimeZone2 = TimeZone.getTimeZone("GMT+9");
/*    */ 
/* 63 */     GlobalService.getDefaultI18nContext().setTimeZone(localTimeZone2);
/* 64 */     Date localDate = getDateFromString(paramString);
/* 65 */     long l1 = localDate.getTime();
/* 66 */     long l2 = GMT.fromCSTToGMT(localDate);
/*    */ 
/* 68 */     GlobalService.getDefaultI18nContext().setTimeZone(localTimeZone1);
/* 69 */     return (l1 - l2) / 3600000L;
/*    */   }
/*    */ 
/*    */   public long testCSTChangeToGMTForAmerica(String paramString) {
/* 73 */     TimeZone localTimeZone1 = GlobalService.getDefaultI18nContext()
/* 74 */       .getTimeZone();
/*    */ 
/* 76 */     TimeZone localTimeZone2 = TimeZone.getTimeZone("GMT-5");
/*    */ 
/* 78 */     GlobalService.getDefaultI18nContext().setTimeZone(localTimeZone2);
/* 79 */     Date localDate = getDateFromString(paramString);
/* 80 */     long l1 = localDate.getTime();
/* 81 */     long l2 = GMT.fromCSTToGMT(localDate);
/*    */ 
/* 83 */     GlobalService.getDefaultI18nContext().setTimeZone(localTimeZone1);
/* 84 */     return (l1 - l2) / 3600000L;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.bo.unittest.impl.TestDaylightSavingTimeBOImpl
 * JD-Core Version:    0.6.2
 */