package com.neusoft.unieap.techcomp.ria.skin.bo;

public abstract interface SkinBO
{
  public abstract String getSkin(String paramString);

  public abstract void setSkin(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.skin.bo.SkinBO
 * JD-Core Version:    0.6.2
 */