/*    */ package com.neusoft.unieap.techcomp.ria.skin.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*    */ import com.neusoft.unieap.techcomp.ria.skin.bo.SkinBO;
/*    */ import com.neusoft.unieap.techcomp.ria.skin.dao.SkinDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.skin.entity.RiaCustom;
/*    */ import java.io.File;
/*    */ import javax.servlet.ServletContext;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ @ModelFile("skinBO.bo")
/*    */ public class SkinBOImpl
/*    */   implements SkinBO
/*    */ {
/*    */   private SkinDAO skinDao;
/*    */ 
/*    */   public SkinDAO getSkinDao()
/*    */   {
/* 27 */     return this.skinDao;
/*    */   }
/*    */   public void setSkinDao(SkinDAO skinDao) {
/* 30 */     this.skinDao = skinDao;
/*    */   }
/*    */ 
/*    */   public String getSkin(String appName)
/*    */   {
/* 43 */     User user = UniEAPContextHolder.getContext().getCurrentUser();
/* 44 */     String userId = user.getId();
/* 45 */     String skin = null;
/* 46 */     RiaCustom custom = this.skinDao.getSkin(userId, appName);
/* 47 */     if (custom != null) {
/* 48 */       skin = JSONObject.fromObject(custom.getContent()).getString("skin");
/* 49 */       String prjPath = I18nGlobalContext.getInstance().getServletContext()
/* 50 */         .getRealPath(File.separator);
/* 51 */       prjPath = prjPath + File.separator;
/* 52 */       prjPath = prjPath + "techcomp" + File.separator + "ria" + File.separator + 
/* 53 */         "unieap" + File.separator + "themes" + File.separator + skin;
/* 54 */       File skinPath = new File(prjPath);
/* 55 */       if (skinPath.exists()) {
/* 56 */         UniEAPContextHolder.getContext().addCustomProperty(user.getAccount() + "_defaultSkin", skin);
/* 57 */         return skin;
/*    */       }
/* 59 */       return "skinPathUndefined";
/*    */     }
/*    */ 
/* 62 */     return skin;
/*    */   }
/*    */ 
/*    */   public void setSkin(String appName, String skinValue)
/*    */   {
/* 69 */     RiaCustom custom = new RiaCustom();
/* 70 */     User user = UniEAPContextHolder.getContext().getCurrentUser();
/* 71 */     String userId = user.getId();
/* 72 */     RiaCustom skin = this.skinDao.getSkin(userId, custom.getPath());
/* 73 */     JSONObject json = new JSONObject();
/* 74 */     json.put("skin", skinValue);
/* 75 */     if (skin == null) {
/* 76 */       custom.setUserId(userId);
/* 77 */       custom.setCmpId("skin");
/* 78 */       custom.setPath(appName);
/* 79 */       custom.setContent(json.toString());
/* 80 */       this.skinDao.saveSkin(custom);
/*    */     } else {
/* 82 */       skin.setContent(json.toString());
/* 83 */       this.skinDao.updateSkin(skin);
/*    */     }
/* 85 */     UniEAPContextHolder.getContext().addCustomProperty(user.getAccount() + "_defaultSkin", skinValue);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.skin.bo.impl.SkinBOImpl
 * JD-Core Version:    0.6.2
 */