package com.neusoft.unieap.techcomp.ria.skin.dao;

import com.neusoft.unieap.techcomp.ria.skin.entity.RiaCustom;

public abstract interface SkinDAO
{
  public abstract RiaCustom getSkin(String paramString1, String paramString2);

  public abstract void saveSkin(RiaCustom paramRiaCustom);

  public abstract void updateSkin(RiaCustom paramRiaCustom);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.skin.dao.SkinDAO
 * JD-Core Version:    0.6.2
 */