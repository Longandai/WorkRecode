/*    */ package com.neusoft.unieap.techcomp.ria.skin.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.skin.dao.SkinDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.skin.entity.RiaCustom;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("skinDAO.dao")
/*    */ public class SkinDAOImpl extends BaseHibernateDAO
/*    */   implements SkinDAO
/*    */ {
/*    */   public RiaCustom getSkin(String paramString1, String paramString2)
/*    */   {
/* 29 */     String str = "from RiaCustom c where c.userId = ? and c.cmpId = 'skin'";
/* 30 */     List localList = getHibernateTemplate().find(str, paramString1);
/* 31 */     if (localList.isEmpty()) {
/* 32 */       return null;
/*    */     }
/* 34 */     return (RiaCustom)localList.get(0);
/*    */   }
/*    */ 
/*    */   public void saveSkin(RiaCustom paramRiaCustom)
/*    */   {
/* 39 */     getHibernateTemplate().save(paramRiaCustom);
/*    */   }
/*    */ 
/*    */   public void updateSkin(RiaCustom paramRiaCustom)
/*    */   {
/* 44 */     getHibernateTemplate().update(paramRiaCustom);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.skin.dao.impl.SkinDAOImpl
 * JD-Core Version:    0.6.2
 */