/*    */ package com.neusoft.unieap.techcomp.ria.trace.action;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.bo.TraceMessageBO;
/*    */ import com.neusoft.unieap.core.exception.bo.TraceMessageBOFactory;
/*    */ import com.neusoft.unieap.core.exception.entity.TraceMessage;
/*    */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*    */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*    */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TraceMessageProcessor extends BaseProcessor
/*    */ {
/*    */   private static final long serialVersionUID = 6196404467633838159L;
/*    */   private static final String TRACE_MESSAGE_STORE = "traceMessageStore";
/*    */ 
/*    */   public void getStackInfoByTraceId()
/*    */     throws Exception
/*    */   {
/* 23 */     String str = super.generateContext().getString("id");
/* 24 */     TraceMessageBO localTraceMessageBO = TraceMessageBOFactory.getTraceMessageBo();
/* 25 */     TraceMessage localTraceMessage = localTraceMessageBO.getTraceMessageById(str);
/* 26 */     ArrayList localArrayList = new ArrayList();
/* 27 */     localArrayList.add(localTraceMessage);
/* 28 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore("traceMessageStore");
/* 29 */     localDataStore = PojoUtil.toDataStore(localArrayList, localDataStore);
/* 30 */     DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/* 31 */     localDataCenter.addDataStore(localDataStore);
/* 32 */     write(localDataCenter);
/*    */   }
/*    */ 
/*    */   public void deleteTraceMessages() throws Exception {
/* 36 */     String str = super.generateContext().getString("ids");
/* 37 */     if (str == null)
/* 38 */       return;
/* 39 */     String[] arrayOfString = str.split(",");
/* 40 */     ArrayList localArrayList = new ArrayList();
/* 41 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 42 */       localArrayList.add(arrayOfString[i]);
/*    */     }
/* 44 */     TraceMessageBO localTraceMessageBO = TraceMessageBOFactory.getTraceMessageBo();
/* 45 */     localTraceMessageBO.deleteTraceMessages(localArrayList);
/* 46 */     DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/* 47 */     write(localDataCenter);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.trace.action.TraceMessageProcessor
 * JD-Core Version:    0.6.2
 */