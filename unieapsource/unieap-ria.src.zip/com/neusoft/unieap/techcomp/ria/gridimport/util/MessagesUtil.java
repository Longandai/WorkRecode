/*     */ package com.neusoft.unieap.techcomp.ria.gridimport.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Map;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.hibernate.validator.engine.ConstraintViolationImpl;
/*     */ 
/*     */ public class MessagesUtil
/*     */ {
/*     */   public static String getString(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/*  19 */     if ("{javax.validation.constraints.DecimalMax.message}".equals(paramString2)) {
/*  20 */       return "最大值应小于或等于" + paramString3;
/*     */     }
/*  22 */     if ("{javax.validation.constraints.DecimalMin.message}"
/*  22 */       .equals(paramString2))
/*  23 */       return "最小值应大于或等于" + paramString3;
/*  24 */     if ("{javax.validation.constraints.Digits.message}".equals(paramString2))
/*  25 */       return "数字整数部分不超过" + paramString3 + "位，小数部分不超过" + paramString4 + "位";
/*  26 */     if ("{javax.validation.constraints.Future.message}".equals(paramString2))
/*  27 */       return "日期不符合将来时段";
/*  28 */     if ("{javax.validation.constraints.Max.message}".equals(paramString2))
/*  29 */       return "最大值应小于或等于" + paramString3;
/*  30 */     if ("{javax.validation.constraints.Min.message}".equals(paramString2))
/*  31 */       return "最小值应大于或等于" + paramString3;
/*  32 */     if ("{javax.validation.constraints.NotNull.message}".equals(paramString2))
/*  33 */       return "值不允许为空";
/*  34 */     if ("{javax.validation.constraints.Past.message}".equals(paramString2))
/*  35 */       return "日期不符合过去时段";
/*  36 */     if ("{javax.validation.constraints.Pattern.message}".equals(paramString2)) {
/*  37 */       return "不符合正则表达式:" + paramString3;
/*     */     }
/*  39 */     if ("{org.hibernate.validator.constraints.Email.message}"
/*  39 */       .equals(paramString2)) {
/*  40 */       return "不符合emial地址格式";
/*     */     }
/*  42 */     if ("{org.hibernate.validator.constraints.Length.message}"
/*  42 */       .equals(paramString2)) {
/*  43 */       return "值长度在" + paramString3 + "与" + paramString4 + "之间";
/*     */     }
/*  45 */     if ("{org.hibernate.validator.constraints.Range.message}"
/*  45 */       .equals(paramString2)) {
/*  46 */       return "值大小应在" + paramString3 + "与" + paramString4 + "之间";
/*     */     }
/*  48 */     I18nGlobalContext localI18nGlobalContext = I18nGlobalContext.getInstance();
/*  49 */     if ((localI18nGlobalContext != null) && (localI18nGlobalContext.isI18nKey(paramString2))) {
/*  50 */       return localI18nGlobalContext.getValue(paramString2);
/*     */     }
/*  52 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public static String getExceptionMessage(ConstraintViolationImpl paramConstraintViolationImpl)
/*     */   {
/*  57 */     String str1 = paramConstraintViolationImpl.getConstraintDescriptor().getAnnotation()
/*  58 */       .annotationType().getCanonicalName();
/*  59 */     String str2 = paramConstraintViolationImpl.getMessageTemplate();
/*     */ 
/*  61 */     if (str1
/*  61 */       .equalsIgnoreCase("javax.validation.constraints.DecimalMax")) {
/*  62 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  63 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  65 */     if (str1
/*  65 */       .equalsIgnoreCase("javax.validation.constraints.DecimalMin")) {
/*  66 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  67 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  69 */     if (str1
/*  69 */       .equalsIgnoreCase("javax.validation.constraints.Digits")) {
/*  70 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  71 */         .getAttributes().get("integer").toString(), paramConstraintViolationImpl
/*  72 */         .getConstraintDescriptor().getAttributes().get("fraction")
/*  73 */         .toString());
/*     */     }
/*  75 */     if (str1
/*  75 */       .equalsIgnoreCase("javax.validation.constraints.Future")) {
/*  76 */       return getString(paramConstraintViolationImpl.getMessage(), str2, null, null);
/*     */     }
/*  78 */     if (str1
/*  78 */       .equalsIgnoreCase("javax.validation.constraints.Max")) {
/*  79 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  80 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  82 */     if (str1
/*  82 */       .equalsIgnoreCase("javax.validation.constraints.Min")) {
/*  83 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  84 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  86 */     if (str1
/*  86 */       .equalsIgnoreCase("javax.validation.constraints.NotNull")) {
/*  87 */       return getString(paramConstraintViolationImpl.getMessage(), str2, null, null);
/*     */     }
/*  89 */     if (str1
/*  89 */       .equalsIgnoreCase("javax.validation.constraints.Past")) {
/*  90 */       return getString(paramConstraintViolationImpl.getMessage(), str2, null, null);
/*     */     }
/*  92 */     if (str1
/*  92 */       .equalsIgnoreCase("javax.validation.constraints.Pattern")) {
/*  93 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/*  94 */         .getAttributes().get("regexp").toString(), null);
/*     */     }
/*  96 */     if (str1
/*  96 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Email")) {
/*  97 */       return getString(paramConstraintViolationImpl.getMessage(), str2, null, null);
/*     */     }
/*  99 */     if (str1
/*  99 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Length")) {
/* 100 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/* 101 */         .getAttributes().get("min").toString(), paramConstraintViolationImpl
/* 102 */         .getConstraintDescriptor().getAttributes().get("max")
/* 103 */         .toString());
/*     */     }
/* 105 */     if (str1
/* 105 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Range")) {
/* 106 */       return getString(paramConstraintViolationImpl.getMessage(), str2, paramConstraintViolationImpl.getConstraintDescriptor()
/* 107 */         .getAttributes().get("min").toString(), paramConstraintViolationImpl
/* 108 */         .getConstraintDescriptor().getAttributes().get("max")
/* 109 */         .toString());
/*     */     }
/* 111 */     return "需要校验的对象不符合校验规则！";
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.util.MessagesUtil
 * JD-Core Version:    0.6.2
 */