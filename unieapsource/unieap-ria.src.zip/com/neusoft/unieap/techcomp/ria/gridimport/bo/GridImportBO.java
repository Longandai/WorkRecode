package com.neusoft.unieap.techcomp.ria.gridimport.bo;

import com.neusoft.unieap.core.common.bo.context.BOContext;
import com.neusoft.unieap.core.common.form.Form;

public abstract interface GridImportBO
{
  public abstract BOContext getSheets(Form paramForm);

  public abstract BOContext getDataByFileUrl(Form paramForm, String paramString);

  public abstract BOContext getImportMessage(Form paramForm, String paramString1, String paramString2, String paramString3);

  public abstract BOContext validationModifed(String paramString);

  public abstract void saveImportConfig(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract String getImportConfig(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.bo.GridImportBO
 * JD-Core Version:    0.6.2
 */