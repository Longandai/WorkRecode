/*    */ package com.neusoft.unieap.techcomp.ria.gridimport.util;
/*    */ 
/*    */ import java.sql.Date;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Locale;
/*    */ import net.sf.json.JsonConfig;
/*    */ import net.sf.json.processors.JsonValueProcessor;
/*    */ 
/*    */ public class JsonDateValueProcessor
/*    */   implements JsonValueProcessor
/*    */ {
/* 11 */   private String format = "yyyy-MM-dd";
/*    */ 
/*    */   public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig) {
/* 14 */     return process(paramObject);
/*    */   }
/*    */ 
/*    */   public Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig) {
/* 18 */     return process(paramObject);
/*    */   }
/*    */ 
/*    */   private Object process(Object paramObject)
/*    */   {
/* 23 */     if ((paramObject instanceof Date)) {
/* 24 */       SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(this.format, Locale.UK);
/* 25 */       return localSimpleDateFormat.format(paramObject);
/*    */     }
/* 27 */     return paramObject == null ? "" : paramObject.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.util.JsonDateValueProcessor
 * JD-Core Version:    0.6.2
 */