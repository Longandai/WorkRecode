/*      */ package com.neusoft.unieap.techcomp.ria.gridimport.bo.impl;
/*      */ 
/*      */ import com.neusoft.unieap.core.annotation.ModelFile;
/*      */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*      */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*      */ import com.neusoft.unieap.core.common.form.Form;
/*      */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*      */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*      */ import com.neusoft.unieap.core.util.BeanUtil;
/*      */ import com.neusoft.unieap.core.validation.BeanValidator;
/*      */ import com.neusoft.unieap.core.validation.BeanValidatorFactory;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.ErrorMessage;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.ImportData;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.bo.GridImportBO;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.dao.GridImportDAO;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.entity.GridImportConfig;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.util.JsonDateValueProcessor;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.util.MessagesUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.gridimport.validation.GridImportValidation;
/*      */ import com.neusoft.unieap.techcomp.ria.util.GMT;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.math.BigDecimal;
/*      */ import java.text.DecimalFormat;
/*      */ import java.text.Format;
/*      */ import java.text.ParseException;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import javax.validation.Validator;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONObject;
/*      */ import net.sf.json.JsonConfig;
/*      */ import org.apache.commons.beanutils.PropertyUtils;
/*      */ import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
/*      */ import org.apache.poi.ss.usermodel.Cell;
/*      */ import org.apache.poi.ss.usermodel.CreationHelper;
/*      */ import org.apache.poi.ss.usermodel.DateUtil;
/*      */ import org.apache.poi.ss.usermodel.FormulaEvaluator;
/*      */ import org.apache.poi.ss.usermodel.RichTextString;
/*      */ import org.apache.poi.ss.usermodel.Row;
/*      */ import org.apache.poi.ss.usermodel.Sheet;
/*      */ import org.apache.poi.ss.usermodel.Workbook;
/*      */ import org.apache.poi.ss.usermodel.WorkbookFactory;
/*      */ import org.apache.poi.ss.util.NumberToTextConverter;
/*      */ import org.hibernate.validator.engine.ConstraintViolationImpl;
/*      */ 
/*      */ @ModelFile("gridImportBO.bo")
/*      */ public class GridImportBOImpl
/*      */   implements GridImportBO
/*      */ {
/*      */   private GridImportDAO gridImportDAO;
/*      */ 
/*      */   public void setGridImportDAO(GridImportDAO paramGridImportDAO)
/*      */   {
/*   72 */     this.gridImportDAO = paramGridImportDAO;
/*      */   }
/*      */ 
/*      */   public InputStream getFormFileInputStream(Form paramForm) {
/*   76 */     List localList = paramForm.getFiles();
/*   77 */     InputStream localInputStream = null;
/*   78 */     if ((localList == null) || (localList.size() == 0)) {
/*   79 */       throw new UniEAPBusinessException("EAPTECHRIA1007");
/*      */     }
/*   81 */     long l = ((FileAttachment)localList.get(0)).getSize();
/*   82 */     if (l == 0L) {
/*   83 */       throw new UniEAPBusinessException("EAPTECHRIA1008");
/*      */     }
/*   85 */     localInputStream = ((FileAttachment)localList.get(0)).getInputStream();
/*   86 */     return localInputStream;
/*      */   }
/*      */ 
/*      */   public BOContext getImportMessage(Form paramForm, String paramString1, String paramString2, String paramString3)
/*      */   {
/*   94 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/*   95 */     new ArrayList();
/*   96 */     new ArrayList();
/*      */ 
/*   98 */     if ((paramString2 == null) || (paramString2.equals("")) || (paramString2.equals("null"))) {
/*   99 */       throw new UniEAPBusinessException("EAPTECHRIA1022");
/*      */     }
/*      */ 
/*  103 */     HashMap localHashMap = new HashMap();
/*      */ 
/*  105 */     InputStream localInputStream = getFormFileInputStream(paramForm);
/*  106 */     Workbook localWorkbook = null;
/*      */     try {
/*  108 */       localWorkbook = WorkbookFactory.create(localInputStream);
/*      */     } catch (IOException localIOException) {
/*  110 */       throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */     } catch (InvalidFormatException localInvalidFormatException) {
/*  112 */       throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */     }
/*  114 */     if (localWorkbook != null) {
/*  115 */       Sheet localSheet = localWorkbook.getSheetAt(Integer.parseInt(paramString2));
/*  116 */       if (localSheet.getLastRowNum() == 0) {
/*  117 */         throw new UniEAPBusinessException("EAPTECHRIA1021");
/*      */       }
/*  119 */       int i = localSheet.getLastRowNum() + 1;
/*  120 */       int j = 0;
/*  121 */       int k = 0;
/*      */       Object localObject1;
/*      */       int n;
/*      */       int i3;
/*      */       Cell localCell;
/*      */       String str2;
/*  123 */       if ((paramString3 == null) || (paramString3.equals(""))) {
/*  124 */         localObject1 = new HashMap();
/*  125 */         JSONArray localJSONArray = JSONArray.fromObject(paramString1);
/*      */         Object localObject2;
/*  126 */         for (n = 0; n < localJSONArray.size(); n++) {
/*  127 */           localObject2 = localJSONArray.getJSONObject(n);
/*  128 */           String str1 = ((JSONObject)localObject2).getString("label");
/*  129 */           ((Map)localObject1).put(str1, ((JSONObject)localObject2).getString("name"));
/*      */         }
/*  131 */         for (n = 0; n < i; n++) {
/*  132 */           localObject2 = localSheet.getRow(n);
/*  133 */           if (localObject2 != null)
/*      */           {
/*  136 */             int i2 = ((Row)localObject2).getLastCellNum();
/*  137 */             for (i3 = 0; i3 < i2; i3++) {
/*  138 */               localCell = ((Row)localObject2).getCell(i3);
/*  139 */               if (localCell != null) {
/*  140 */                 localCell.setCellType(1);
/*  141 */                 if (localCell.getStringCellValue() != null) {
/*  142 */                   str2 = localCell.getStringCellValue()
/*  143 */                     .toString();
/*      */                   try {
/*  145 */                     if (j == 0)
/*      */                     {
/*  147 */                       if (!((String)((Map)localObject1).get(str2))
/*  147 */                         .equals("")) {
/*  148 */                         j = 1;
/*  149 */                         localBOContextImpl.put("labelRow", Integer.valueOf(n + 1));
/*  150 */                         localBOContextImpl.put("labelCell", Integer.valueOf(i3 + 1));
/*  151 */                         localBOContextImpl.put("labelEndCell", Integer.valueOf(i2));
/*  152 */                         localBOContextImpl.put("dataStartRow", Integer.valueOf(n + 2));
/*  153 */                         localBOContextImpl.put("dataEndRow", Integer.valueOf(i));
/*      */                       }
/*      */                     }
/*  155 */                     if (j == 0) continue;
/*  156 */                     localHashMap.put(String.valueOf(k), 
/*  157 */                       str2);
/*  158 */                     k++;
/*      */                   }
/*      */                   catch (Exception localException)
/*      */                   {
/*      */                   }
/*      */                 }
/*  164 */                 else if (j != 0) {
/*  165 */                   localHashMap.put(String.valueOf(k), "");
/*  166 */                   k++;
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*  171 */             if (j != 0) break;
/*      */           }
/*      */         }
/*      */       }
/*      */       else {
/*  176 */         localObject1 = JSONObject.fromObject(paramString3);
/*  177 */         int m = Integer.parseInt(((JSONObject)localObject1)
/*  178 */           .getString("labelRowSpinner")) - 1;
/*  179 */         n = Integer.parseInt(((JSONObject)localObject1)
/*  180 */           .getString("labelStartCellSpinner")) - 1;
/*  181 */         int i1 = Integer.parseInt(((JSONObject)localObject1)
/*  182 */           .getString("labelEndCellSpinner")) - 1;
/*      */ 
/*  184 */         Row localRow = localSheet.getRow(m);
/*  185 */         if (localRow == null) {
/*  186 */           throw new UniEAPBusinessException("EAPTECHRIA1019");
/*      */         }
/*  188 */         for (i3 = n; i3 <= i1; i3++) {
/*  189 */           localCell = localRow.getCell(i3);
/*  190 */           if (localCell != null) {
/*  191 */             str2 = null;
/*      */             Object localObject3;
/*  192 */             if (localCell.getCellType() == 0) {
/*  193 */               if (DateUtil.isCellDateFormatted(localCell)) {
/*  194 */                 localObject3 = localCell.getDateCellValue();
/*  195 */                 str2 = String.valueOf(((java.util.Date)localObject3).toLocaleString());
/*      */               } else {
/*  197 */                 str2 = NumberToTextConverter.toText(localCell.getNumericCellValue());
/*      */               }
/*      */             }
/*  200 */             localCell.setCellType(1);
/*  201 */             if (localCell.getStringCellValue() != null) {
/*  202 */               localObject3 = str2 == null ? localCell.getStringCellValue() : str2;
/*  203 */               localHashMap.put(String.valueOf(k), localObject3);
/*  204 */               k++;
/*      */             }
/*  206 */             else if (j != 0) {
/*  207 */               localHashMap.put(String.valueOf(k), "");
/*  208 */               k++;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*  213 */         localBOContextImpl.put("dataStartRow", Integer.valueOf(m + 2));
/*  214 */         localBOContextImpl.put("dataEndRow", Integer.valueOf(i));
/*      */       }
/*      */     }
/*  217 */     localBOContextImpl.put("excelLabels", localHashMap);
/*  218 */     return localBOContextImpl;
/*      */   }
/*      */ 
/*      */   public BOContext getSheets(Form paramForm)
/*      */   {
/*  225 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/*  226 */     List localList = paramForm.getFiles();
/*  227 */     if ((localList == null) || (localList.size() == 0)) {
/*  228 */       throw new UniEAPBusinessException("EAPTECHRIA1007");
/*      */     }
/*  230 */     long l = ((FileAttachment)localList.get(0)).getSize();
/*  231 */     if (l == 0L) {
/*  232 */       throw new UniEAPBusinessException("EAPTECHRIA1008");
/*      */     }
/*  234 */     InputStream localInputStream = null;
/*  235 */     localInputStream = ((FileAttachment)localList.get(0)).getInputStream();
/*  236 */     Workbook localWorkbook = null;
/*      */     try {
/*  238 */       localWorkbook = WorkbookFactory.create(localInputStream);
/*      */     } catch (IOException localIOException) {
/*  240 */       throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */     } catch (InvalidFormatException localInvalidFormatException) {
/*  242 */       throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */     }
/*  244 */     if (localWorkbook != null) {
/*  245 */       for (int i = 0; i < localWorkbook.getNumberOfSheets(); i++) {
/*  246 */         localBOContextImpl.put(i, localWorkbook.getSheetAt(i).getSheetName());
/*      */       }
/*      */     }
/*  249 */     return localBOContextImpl;
/*      */   }
/*      */ 
/*      */   public BOContext getDataByFileUrl(Form paramForm, String paramString)
/*      */   {
/*  256 */     JSONObject localJSONObject1 = JSONObject.fromObject(paramString);
/*  257 */     String str1 = localJSONObject1.getString("rowSetName");
/*  258 */     String str2 = localJSONObject1.getString("sheetId");
/*  259 */     String str3 = localJSONObject1.getString("customBeanName");
/*  260 */     String str4 = localJSONObject1.getString("uniqueCells");
/*  261 */     String str5 = localJSONObject1.getString("orginRowSet");
/*  262 */     String str6 = localJSONObject1.getString("dataTypeCells");
/*  263 */     int i = localJSONObject1.getInt("import_maxLength");
/*  264 */     boolean bool1 = localJSONObject1.getBoolean("entityValidation");
/*  265 */     boolean bool2 = localJSONObject1.getBoolean("advanceFlag");
/*  266 */     Object localObject1 = bool2 ? localJSONObject1.getString("configNum") : 
/*  267 */       null;
/*  268 */     Object localObject2 = bool2 ? localJSONObject1
/*  269 */       .getString("advanceConfig") : null;
/*      */ 
/*  271 */     ImportData localImportData = new ImportData();
/*  272 */     ArrayList localArrayList1 = new ArrayList();
/*  273 */     ArrayList localArrayList2 = new ArrayList();
/*  274 */     ArrayList localArrayList3 = new ArrayList();
/*      */ 
/*  276 */     if ((str2 == null) || (str2.equals("")) || (str2.equals("null"))) {
/*  277 */       throw new UniEAPBusinessException("EAPTECHRIA1022");
/*      */     }
/*  279 */     InputStream localInputStream = getFormFileInputStream(paramForm);
/*      */ 
/*  281 */     String[] arrayOfString1 = (String[])null;
/*  282 */     if ((str4 != null) && (!str4.equals("null"))) {
/*  283 */       localJSONArray1 = JSONArray.fromObject(str4);
/*  284 */       if (localJSONArray1 != null) {
/*  285 */         arrayOfString1 = new String[localJSONArray1.size()];
/*  286 */         for (int j = 0; j < localJSONArray1.size(); j++) {
/*  287 */           arrayOfString1[j] = localJSONArray1.getString(j);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  293 */     JSONArray localJSONArray1 = JSONArray.fromObject(str5);
/*  294 */     HashMap localHashMap1 = new HashMap();
/*      */ 
/*  297 */     HashMap localHashMap2 = new HashMap();
/*      */ 
/*  299 */     HashMap localHashMap3 = new HashMap();
/*  300 */     HashMap localHashMap4 = new HashMap();
/*  301 */     Object localObject3 = new HashMap();
/*  302 */     Object localObject4 = new ArrayList();
/*  303 */     Object localObject5 = new HashMap();
/*  304 */     JSONArray localJSONArray2 = JSONArray.fromObject(str6);
/*  305 */     for (int k = 0; k < localJSONArray2.size(); k++) {
/*  306 */       JSONObject localJSONObject2 = localJSONArray2.getJSONObject(k);
/*  307 */       String str7 = localJSONObject2.getString("label");
/*  308 */       String str8 = localJSONObject2.getString("decoder");
/*  309 */       localHashMap3.put(localJSONObject2.getString("name"), str8);
/*  310 */       ((List)localObject4).add(str7);
/*  311 */       ((Map)localObject3).put(str7, localJSONObject2.getString("name"));
/*  312 */       ((Map)localObject5).put(str7, localJSONObject2.get("dataType"));
/*  313 */       localHashMap4.put(str7, localJSONObject2.getString("format"));
/*      */     }
/*      */ 
/*  316 */     k = 0;
/*  317 */     int m = 0;
/*  318 */     int n = 0;
/*  319 */     int i1 = 1;
/*  320 */     int i2 = 0;
/*      */ 
/*  323 */     JSONObject localJSONObject3 = null;
/*  324 */     int i3 = 0;
/*      */     Object localObject6;
/*      */     Object localObject9;
/*  325 */     if ((localObject1 != null) && (!localObject1.equals("")) && (localObject2 != null) && 
/*  326 */       (!localObject2.equals(""))) {
/*  327 */       i3 = 1;
/*  328 */       localJSONObject3 = JSONObject.fromObject(localObject1);
/*  329 */       localObject6 = new HashMap();
/*  330 */       localObject8 = new ArrayList();
/*  331 */       HashMap localHashMap5 = new HashMap();
/*  332 */       k = localJSONObject3.getInt("labelRowSpinner") - 1;
/*  333 */       m = localJSONObject3
/*  334 */         .getInt("labelStartCellSpinner") - 1;
/*  335 */       n = localJSONObject3.getInt("labelEndCellSpinner") - 1;
/*  336 */       i1 = localJSONObject3.getInt("dataStartRowSpinner") - 1;
/*  337 */       i2 = localJSONObject3.getInt("dataEndRowSpinner") - 1;
/*      */ 
/*  339 */       localObject9 = JSONArray.fromObject(localObject2);
/*  340 */       for (int i5 = 0; i5 < ((JSONArray)localObject9).size(); i5++) {
/*  341 */         JSONObject localJSONObject4 = ((JSONArray)localObject9).getJSONObject(i5);
/*  342 */         Object localObject10 = localJSONObject4.get("excelLabel");
/*  343 */         if ((localObject10 != null) && (!localObject10.equals("")) && 
/*  344 */           (!localObject10.toString().equals("null"))) {
/*  345 */           ((Map)localObject6).put(localObject10.toString(), (String)((Map)localObject3).get(localJSONObject4
/*  346 */             .getString("gridLabel")));
/*  347 */           ((List)localObject8).add(localObject10.toString());
/*  348 */           localHashMap5.put(localObject10.toString(), ((Map)localObject5)
/*  349 */             .get(localJSONObject4.getString("gridLabel")));
/*      */         }
/*      */       }
/*  352 */       localObject4 = localObject8;
/*  353 */       localObject3 = localObject6;
/*  354 */       localObject5 = localHashMap5;
/*      */     }
/*      */     try {
/*  357 */       localObject6 = null;
/*      */       try {
/*  359 */         localObject6 = WorkbookFactory.create(localInputStream);
/*      */       } catch (InvalidFormatException localInvalidFormatException) {
/*  361 */         throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */       } catch (IOException localIOException6) {
/*  363 */         throw new UniEAPBusinessException("EAPTECHRIA1009");
/*      */       }
/*  365 */       if (localObject6 != null) {
/*  366 */         localObject8 = ((Workbook)localObject6).getSheetAt(Integer.parseInt(str2));
/*  367 */         int i4 = ((Sheet)localObject8).getLastRowNum();
/*  368 */         if ((i3 == 0) && (i4 == 0)) {
/*  369 */           throw new UniEAPBusinessException("EAPTECHRIA1021");
/*      */         }
/*  371 */         if ((i3 != 0) && (i1 > i2)) {
/*  372 */           throw new UniEAPBusinessException("EAPTECHRIA1021");
/*      */         }
/*  374 */         if ((i3 == 0) && (i4 > i)) {
/*  375 */           throw new UniEAPBusinessException("EAPTECHRIA1020");
/*      */         }
/*  377 */         if ((i3 != 0) && (i2 > i))
/*  378 */           throw new UniEAPBusinessException("EAPTECHRIA1020");
/*      */         int i6;
/*      */         String[] arrayOfString2;
/*      */         try
/*      */         {
/*  384 */           localObject9 = ((Sheet)localObject8).getRow(k);
/*  385 */           i6 = i3 != 0 ? n - 
/*  386 */             m : ((Row)localObject9).getLastCellNum();
/*  387 */           arrayOfString2 = new String[i6 + 1];
/*      */         } catch (Exception localException1) {
/*  389 */           throw new UniEAPBusinessException("EAPTECHRIA1010");
/*      */         }
/*  391 */         if ((i3 == 0) && (((Sheet)localObject8).getLastRowNum() == 0)) {
/*  392 */           throw new UniEAPBusinessException("EAPTECHRIA1021");
/*      */         }
/*  394 */         if ((i3 == 0) && (((List)localObject4).size() != i6))
/*      */         {
/*  396 */           throw new UniEAPBusinessException("EAPTECHRIA1023");
/*      */         }
/*      */ 
/*  400 */         int i7 = i3 != 0 ? n : ((Row)localObject9)
/*  401 */           .getLastCellNum() - 1;
/*      */         Object localObject11;
/*      */         Object localObject12;
/*  402 */         for (int i8 = m; i8 <= i7; i8++) {
/*  403 */           Cell localCell1 = ((Row)localObject9).getCell(i8);
/*  404 */           if (localCell1 != null) {
/*  405 */             localCell1.setCellType(1);
/*  406 */             if (localCell1.getStringCellValue() != null) {
/*  407 */               i10 = i8 - m;
/*  408 */               localObject11 = localCell1.getStringCellValue()
/*  409 */                 .toString();
/*  410 */               if (i3 == 0) {
/*  411 */                 if (((String)((List)localObject4).get(i10)).equals(
/*  412 */                   localObject11))
/*  413 */                   arrayOfString2[i10] = localObject11;
/*      */                 else
/*  415 */                   throw new UniEAPBusinessException(
/*  416 */                     "EAPTECHRIA1023");
/*      */               }
/*      */               else {
/*  419 */                 localObject12 = getValueFormMap((Map)localObject3, 
/*  420 */                   (String)localObject11);
/*  421 */                 if (localObject12 != null)
/*  422 */                   arrayOfString2[i10] = localObject11;
/*      */               }
/*      */             }
/*      */             else {
/*  426 */               throw new UniEAPBusinessException("EAPTECHRIA1016");
/*      */             }
/*      */           }
/*  429 */           else if (i3 == 0) {
/*  430 */             throw new UniEAPBusinessException("EAPTECHRIA1016");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  436 */         JsonConfig localJsonConfig = new JsonConfig();
/*  437 */         localJsonConfig.registerJsonValueProcessor(java.sql.Date.class, 
/*  438 */           new JsonDateValueProcessor());
/*      */ 
/*  440 */         int i9 = i3 != 0 ? i2 + 1 : ((Sheet)localObject8)
/*  441 */           .getLastRowNum() + 1;
/*  442 */         for (int i10 = i1; i10 < i9; i10++) {
/*  443 */           localObject11 = Class.forName(str1).newInstance();
/*  444 */           localObject12 = ((Sheet)localObject8).getRow(i10);
/*      */ 
/*  446 */           int i11 = i10 - i1;
/*  447 */           if (localObject12 == null) {
/*  448 */             throw new UniEAPBusinessException("EAPTECHRIA1018");
/*      */           }
/*  450 */           int i12 = 1;
/*  451 */           int i13 = 0;
/*  452 */           for (int i14 = m; i14 <= i6; i14++) {
/*  453 */             i12 = 1;
/*  454 */             Cell localCell2 = ((Row)localObject12).getCell(i14);
/*  455 */             String str9 = "";
/*  456 */             int i15 = i14 - m;
/*  457 */             String str10 = arrayOfString2[i15];
/*  458 */             String str11 = getValueFormMap((Map)localObject3, 
/*  459 */               str10);
/*  460 */             if (str11 != null)
/*      */             {
/*      */               Object localObject13;
/*      */               Object localObject14;
/*      */               Object localObject15;
/*      */               Object localObject16;
/*      */               Object localObject17;
/*  461 */               if (localCell2 != null) {
/*  462 */                 localObject13 = getCellValue(localCell2, 
/*  463 */                   ((Map)localObject5).get(str10)
/*  464 */                   .toString());
/*  465 */                 str9 = (String)((List)localObject13).get(0);
/*  466 */                 if ((i13 == 0) && (!"".equals(str9))) {
/*  467 */                   i13 = 1;
/*      */                 }
/*  469 */                 if ((((String)((List)localObject13).get(2)).equals("true")) && 
/*  470 */                   (!str9.equals("")))
/*      */                 {
/*  472 */                   if (((Map)localObject5).get(str10)
/*  472 */                     .toString().equals("date")) {
/*  473 */                     localObject14 = (String)localHashMap4.get(str10);
/*  474 */                     localObject15 = new SimpleDateFormat(
/*  475 */                       !((String)localObject14).equals("") ? localObject14 : "yyyy-MM-dd");
/*      */                     try
/*      */                     {
/*  478 */                       localObject16 = (java.util.Date)((Format)localObject15).parseObject(str9);
/*      */                     } catch (ParseException localParseException1) {
/*  480 */                       i12 = 0;
/*  481 */                       localObject17 = new ErrorMessage();
/*  482 */                       ((ErrorMessage)localObject17)
/*  483 */                         .setRowNum(i11);
/*  484 */                       ((ErrorMessage)localObject17).setCellName(str11);
/*  485 */                       ((ErrorMessage)localObject17)
/*  486 */                         .setOriginalValue(str9);
/*  487 */                       ((ErrorMessage)localObject17).setMessage("数据类型错误");
/*  488 */                       localArrayList2.add(localObject17);
/*  489 */                       continue;
/*      */                     }
/*  491 */                     str9 = String.valueOf(Long.valueOf(((java.util.Date)localObject16)
/*  492 */                       .getTime()));
/*      */                   }
/*      */                 }
/*  494 */                 if ((((Map)localObject5).get(str10).toString().equals("number")) && (!((String)localHashMap4.get(str10)).equals(""))) {
/*  495 */                   localObject14 = new DecimalFormat((String)localHashMap4.get(str10));
/*      */                   try {
/*  497 */                     str9 = ((DecimalFormat)localObject14).parse(str9).toString();
/*  498 */                     if ((str9 != null) && (
/*  499 */                       (str9.contains("\n")) || (str9.contains("\r")))) {
/*  500 */                       str9 = str9.replace("\n", " ");
/*  501 */                       str9 = str9.replace("\r", " ");
/*      */                     }
/*      */                   }
/*      */                   catch (ParseException localParseException2) {
/*  505 */                     i12 = 0;
/*  506 */                     localObject15 = new ErrorMessage();
/*  507 */                     ((ErrorMessage)localObject15).setRowNum(i11);
/*  508 */                     ((ErrorMessage)localObject15).setCellName(str11);
/*  509 */                     ((ErrorMessage)localObject15).setOriginalValue(str9);
/*  510 */                     ((ErrorMessage)localObject15).setMessage("数据类型错误");
/*  511 */                     localArrayList2.add(localObject15);
/*  512 */                     continue;
/*      */                   }
/*      */                 }
/*  515 */                 if (((String)((List)localObject13).get(1)).equals("true")) {
/*  516 */                   i12 = 0;
/*  517 */                   localObject14 = new ErrorMessage();
/*  518 */                   ((ErrorMessage)localObject14).setRowNum(i11);
/*  519 */                   ((ErrorMessage)localObject14).setCellName(str11);
/*  520 */                   ((ErrorMessage)localObject14).setOriginalValue(str9);
/*  521 */                   ((ErrorMessage)localObject14).setMessage("数据类型错误");
/*  522 */                   localArrayList2.add(localObject14);
/*  523 */                   continue;
/*      */                 }
/*      */               }
/*      */               try
/*      */               {
/*  528 */                 localObject13 = (String)localHashMap3.get(str11);
/*  529 */                 localObject14 = Boolean.valueOf(false);
/*  530 */                 if ((!((String)localObject13).equals("{}")) && (str9 != null) && (!str9.equals(""))) {
/*  531 */                   localObject15 = JSONObject.fromObject(localObject13);
/*  532 */                   localObject16 = ((JSONObject)localObject15).getString("valueAttr");
/*  533 */                   localObject17 = ((JSONObject)localObject15).getString("displayAttr");
/*  534 */                   JSONArray localJSONArray3 = ((JSONObject)localObject15).getJSONArray("store");
/*  535 */                   for (int i16 = 0; i16 < localJSONArray3.size(); i16++) {
/*  536 */                     JSONObject localJSONObject5 = localJSONArray3.getJSONObject(i16);
/*  537 */                     if (localJSONObject5.getString((String)localObject16).equalsIgnoreCase(str9)) {
/*  538 */                       localObject14 = Boolean.valueOf(true);
/*      */                     }
/*  540 */                     if (localJSONObject5.getString((String)localObject17).equalsIgnoreCase(str9)) {
/*  541 */                       str9 = localJSONObject5.getString((String)localObject16);
/*  542 */                       localObject14 = Boolean.valueOf(true);
/*      */                     }
/*      */                   }
/*  545 */                   if (!((Boolean)localObject14).booleanValue()) {
/*  546 */                     i12 = 0;
/*  547 */                     ErrorMessage localErrorMessage = new ErrorMessage();
/*  548 */                     localErrorMessage.setRowNum(i11);
/*  549 */                     localErrorMessage.setCellName(str11);
/*  550 */                     localErrorMessage.setOriginalValue(str9);
/*  551 */                     localErrorMessage.setMessage("代码表数据错误");
/*  552 */                     localArrayList2.add(localErrorMessage);
/*  553 */                     doSetProperty(localObject11, "", str11);
/*      */                   }
/*      */                 }
/*      */ 
/*  557 */                 if (i12 != 0)
/*  558 */                   doSetProperty(localObject11, str9, str11);
/*      */               }
/*      */               catch (Exception localException2) {
/*  561 */                 i12 = 0;
/*  562 */                 localObject13 = new ErrorMessage();
/*  563 */                 ((ErrorMessage)localObject13).setRowNum(i11);
/*  564 */                 ((ErrorMessage)localObject13).setCellName(str11);
/*  565 */                 ((ErrorMessage)localObject13).setOriginalValue(str9);
/*  566 */                 ((ErrorMessage)localObject13).setMessage("数据类型错误");
/*  567 */                 localArrayList2.add(localObject13);
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  572 */           if (i13 != 0)
/*      */           {
/*  574 */             i14 = uniqueValidate(arrayOfString1, localObject11, localJSONArray1);
/*  575 */             if (i14 != -1) {
/*  576 */               if (localHashMap1.containsValue(i14)) {
/*  577 */                 throw new UniEAPBusinessException(
/*  578 */                   "EAPTECHRIA1017");
/*      */               }
/*  580 */               localHashMap2.put(String.valueOf(i11), 
/*  581 */                 "cover");
/*  582 */               localHashMap1.put(
/*  583 */                 String.valueOf(i11), i14);
/*      */             } else {
/*  585 */               localHashMap2.put(String.valueOf(i11), 
/*  586 */                 "add");
/*      */             }
/*  588 */             localArrayList1.addAll(localArrayList2);
/*  589 */             localArrayList3.add(localObject11);
/*      */           }
/*      */         }
/*      */       }
/*      */     } catch (InstantiationException localInstantiationException) {
/*  594 */       localInstantiationException.printStackTrace();
/*      */ 
/*  600 */       if (localInputStream != null)
/*      */         try {
/*  602 */           localInputStream.close();
/*      */         } catch (IOException localIOException1) {
/*  604 */           localIOException1.printStackTrace();
/*      */         }
/*      */     }
/*      */     catch (ClassNotFoundException localClassNotFoundException)
/*      */     {
/*  596 */       localClassNotFoundException.printStackTrace();
/*      */ 
/*  600 */       if (localInputStream != null)
/*      */         try {
/*  602 */           localInputStream.close();
/*      */         } catch (IOException localIOException2) {
/*  604 */           localIOException2.printStackTrace();
/*      */         }
/*      */     }
/*      */     catch (IllegalAccessException localIllegalAccessException)
/*      */     {
/*  598 */       localIllegalAccessException.printStackTrace();
/*      */ 
/*  600 */       if (localInputStream != null)
/*      */         try {
/*  602 */           localInputStream.close();
/*      */         } catch (IOException localIOException3) {
/*  604 */           localIOException3.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*  600 */       if (localInputStream != null) {
/*      */         try {
/*  602 */           localInputStream.close();
/*      */         } catch (IOException localIOException4) {
/*  604 */           localIOException4.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  609 */     localImportData.setPojoList(localArrayList3);
/*  610 */     localImportData.setErrorMessageList(localArrayList1);
/*  611 */     localImportData.setStateMap(localHashMap2);
/*  612 */     localImportData.setExcelToOrginId(localHashMap1);
/*  613 */     localImportData.setValidationContinue(true);
/*      */ 
/*  615 */     Object localObject7 = null;
/*  616 */     localObject7 = BeanUtil.getBean(str3);
/*  617 */     localImportData = ((GridImportValidation)localObject7).beforeValidate(localImportData);
/*  618 */     if (localImportData.getValidationContinue()) {
/*  619 */       if (bool1) {
/*  620 */         validation(localImportData, (Map)localObject3);
/*      */       }
/*  622 */       localImportData = ((GridImportValidation)localObject7).afterValidate(localImportData);
/*      */     }
/*      */ 
/*  625 */     localImportData.getErrorMessageList().iterator();
/*      */ 
/*  632 */     Object localObject8 = new BOContextImpl();
/*  633 */     ((BOContext)localObject8).put("pojoList", localImportData.getPojoList());
/*  634 */     ((BOContext)localObject8).put("errorMessageList", localImportData.getErrorMessageList());
/*  635 */     ((BOContext)localObject8).put("stateMap", localImportData.getStateMap());
/*  636 */     ((BOContext)localObject8).put("excelToOrginId", localImportData.getExcelToOrginId());
/*  637 */     return localObject8;
/*      */   }
/*      */ 
/*      */   public BOContext validationModifed(String paramString)
/*      */   {
/*  644 */     JSONObject localJSONObject1 = JSONObject.fromObject(paramString);
/*  645 */     String str1 = localJSONObject1.getString("rowSetName");
/*  646 */     String str2 = localJSONObject1.getString("newRowSet");
/*  647 */     String str3 = localJSONObject1.getString("customBeanName");
/*  648 */     String str4 = localJSONObject1.getString("uniqueCells");
/*  649 */     String str5 = localJSONObject1.getString("orginRowSet");
/*  650 */     String str6 = localJSONObject1.getString("dataTypeCells");
/*  651 */     boolean bool = localJSONObject1.getBoolean("entityValidation");
/*      */ 
/*  653 */     ImportData localImportData = new ImportData();
/*  654 */     ArrayList localArrayList1 = new ArrayList();
/*  655 */     ArrayList localArrayList2 = new ArrayList();
/*      */ 
/*  658 */     String[] arrayOfString = (String[])null;
/*  659 */     if ((str4 != null) && (!str4.equals("null"))) {
/*  660 */       localJSONArray1 = JSONArray.fromObject(str4);
/*  661 */       if (localJSONArray1 != null) {
/*  662 */         arrayOfString = new String[localJSONArray1.size()];
/*  663 */         for (int i = 0; i < localJSONArray1.size(); i++) {
/*  664 */           arrayOfString[i] = localJSONArray1.getString(i);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  670 */     JSONArray localJSONArray1 = JSONArray.fromObject(str5);
/*  671 */     HashMap localHashMap1 = new HashMap();
/*      */ 
/*  674 */     HashMap localHashMap2 = new HashMap();
/*      */ 
/*  676 */     HashMap localHashMap3 = new HashMap();
/*  677 */     HashMap localHashMap4 = new HashMap();
/*  678 */     ArrayList localArrayList3 = new ArrayList();
/*  679 */     HashMap localHashMap5 = new HashMap();
/*  680 */     JSONArray localJSONArray2 = JSONArray.fromObject(str6);
/*  681 */     for (int j = 0; j < localJSONArray2.size(); j++) {
/*  682 */       localObject1 = localJSONArray2.getJSONObject(j);
/*  683 */       String str7 = ((JSONObject)localObject1).getString("label");
/*  684 */       localArrayList3.add(str7);
/*  685 */       String str8 = ((JSONObject)localObject1).getString("decoder");
/*  686 */       localHashMap3.put(((JSONObject)localObject1).getString("name"), str8);
/*  687 */       localHashMap4.put(str7, ((JSONObject)localObject1).getString("name"));
/*  688 */       localHashMap5.put(str7, ((JSONObject)localObject1).get("dataType"));
/*      */     }
/*      */ 
/*  692 */     JsonConfig localJsonConfig = new JsonConfig();
/*  693 */     localJsonConfig.registerJsonValueProcessor(java.util.Date.class, 
/*  694 */       new JsonDateValueProcessor());
/*  695 */     Object localObject1 = JSONArray.fromObject(str2);
/*  696 */     int k = ((JSONArray)localObject1).size();
/*  697 */     for (int m = 0; m < k; m++) {
/*      */       try
/*      */       {
/*  700 */         localObject3 = Class.forName(str1).newInstance();
/*      */ 
/*  702 */         JSONObject localJSONObject2 = 
/*  703 */           JSONObject.fromObject(((JSONArray)localObject1).get(m));
/*  704 */         localObject4 = localHashMap4.values().iterator();
/*  705 */         while (((Iterator)localObject4).hasNext()) {
/*  706 */           String str9 = ((Iterator)localObject4).next().toString();
/*  707 */           String str10 = null;
/*  708 */           if (localJSONObject2.containsKey(str9)) {
/*  709 */             str10 = localJSONObject2.getString(str9);
/*      */           }
/*      */           try
/*      */           {
/*  713 */             localObject5 = (String)localHashMap3.get(str9);
/*  714 */             if ((!((String)localObject5).equals("{}")) && (str10 != null) && (!str10.equals(""))) {
/*  715 */               JSONObject localJSONObject3 = JSONObject.fromObject(localObject5);
/*  716 */               String str11 = localJSONObject3.getString("valueAttr");
/*  717 */               String str12 = localJSONObject3.getString("displayAttr");
/*  718 */               JSONArray localJSONArray3 = localJSONObject3.getJSONArray("store");
/*  719 */               for (int i1 = 0; i1 < localJSONArray3.size(); i1++) {
/*  720 */                 JSONObject localJSONObject4 = localJSONArray3.getJSONObject(i1);
/*  721 */                 if (localJSONObject4.getString(str12).equalsIgnoreCase(str10)) {
/*  722 */                   str10 = localJSONObject4.getString(str11);
/*      */                 }
/*      */               }
/*      */             }
/*      */ 
/*  727 */             doSetProperty(localObject3, str10, str9);
/*      */           }
/*      */           catch (Exception localException) {
/*  730 */             Object localObject5 = new ErrorMessage();
/*  731 */             ((ErrorMessage)localObject5).setRowNum(m);
/*  732 */             ((ErrorMessage)localObject5).setCellName(str9);
/*  733 */             ((ErrorMessage)localObject5).setOriginalValue(str9);
/*  734 */             ((ErrorMessage)localObject5).setMessage("数据类型错误");
/*  735 */             localArrayList1.add(localObject5);
/*      */           }
/*      */         }
/*      */ 
/*  739 */         int n = uniqueValidate(arrayOfString, localObject3, localJSONArray1);
/*  740 */         if (n != -1) {
/*  741 */           if (localHashMap1.containsValue(String.valueOf(n))) {
/*  742 */             throw new UniEAPBusinessException("EAPTECHRIA1017");
/*      */           }
/*  744 */           localHashMap2.put(String.valueOf(m), "cover");
/*  745 */           localHashMap1.put(String.valueOf(m), String.valueOf(n));
/*      */         } else {
/*  747 */           localHashMap2.put(String.valueOf(m), "add");
/*      */         }
/*  749 */         localArrayList2.add(localObject3);
/*      */       } catch (InstantiationException localInstantiationException) {
/*  751 */         localInstantiationException.printStackTrace();
/*      */       } catch (IllegalAccessException localIllegalAccessException) {
/*  753 */         localIllegalAccessException.printStackTrace();
/*      */       } catch (ClassNotFoundException localClassNotFoundException) {
/*  755 */         localClassNotFoundException.printStackTrace();
/*      */       }
/*      */     }
/*      */ 
/*  759 */     localImportData.setPojoList(localArrayList2);
/*  760 */     localImportData.setErrorMessageList(localArrayList1);
/*  761 */     localImportData.setStateMap(localHashMap2);
/*  762 */     localImportData.setExcelToOrginId(localHashMap1);
/*  763 */     localImportData.setValidationContinue(true);
/*      */ 
/*  765 */     Object localObject2 = null;
/*  766 */     localObject2 = BeanUtil.getBean(str3);
/*  767 */     localImportData = ((GridImportValidation)localObject2).beforeValidate(localImportData);
/*  768 */     if (localImportData.getValidationContinue()) {
/*  769 */       if (bool) {
/*  770 */         validation(localImportData, localHashMap4);
/*      */       }
/*  772 */       localImportData = ((GridImportValidation)localObject2).afterValidate(localImportData);
/*      */     }
/*      */ 
/*  776 */     Object localObject3 = localHashMap1.values().iterator();
/*  777 */     ArrayList localArrayList4 = new ArrayList();
/*  778 */     while (((Iterator)localObject3).hasNext()) {
/*  779 */       localArrayList4.add(((Iterator)localObject3).next());
/*      */     }
/*      */ 
/*  782 */     Object localObject4 = new BOContextImpl();
/*  783 */     ((BOContext)localObject4).put("pojoList", localImportData.getPojoList());
/*  784 */     ((BOContext)localObject4).put("errorMessageList", localImportData.getErrorMessageList());
/*  785 */     ((BOContext)localObject4).put("stateMap", localImportData.getStateMap());
/*  786 */     ((BOContext)localObject4).put("excelToOrginId", localImportData.getExcelToOrginId());
/*  787 */     return localObject4;
/*      */   }
/*      */ 
/*      */   public ImportData validation(ImportData paramImportData, Map<String, String> paramMap)
/*      */   {
/*  794 */     List localList1 = paramImportData.getPojoList();
/*  795 */     List localList2 = paramImportData.getErrorMessageList();
/*  796 */     Collection localCollection = paramMap.values();
/*  797 */     Iterator localIterator1 = localList1.iterator();
/*  798 */     int i = 0;
/*  799 */     while (localIterator1.hasNext()) {
/*  800 */       Object localObject1 = localIterator1.next();
/*  801 */       Set localSet = BeanValidatorFactory.getBeanValidator().getValidator()
/*  802 */         .validate(localObject1, new Class[0]);
/*  803 */       Iterator localIterator2 = localSet.iterator();
/*  804 */       while (localIterator2.hasNext()) {
/*  805 */         ConstraintViolationImpl localConstraintViolationImpl = 
/*  806 */           (ConstraintViolationImpl)localIterator2
/*  806 */           .next();
/*  807 */         String str = localConstraintViolationImpl.getPropertyPath().toString();
/*  808 */         if (localCollection.contains(str)) {
/*  809 */           ErrorMessage localErrorMessage = new ErrorMessage();
/*  810 */           localErrorMessage.setRowNum(i);
/*  811 */           localErrorMessage.setCellName(str);
/*  812 */           localErrorMessage.setMessage(MessagesUtil.getExceptionMessage(localConstraintViolationImpl));
/*      */           try {
/*  814 */             Class localClass = PropertyUtils.getPropertyType(localObject1, str);
/*  815 */             Object localObject2 = PropertyUtils.getProperty(localObject1, str);
/*  816 */             if ((localClass == java.util.Date.class) || 
/*  817 */               (localClass.getSuperclass() == java.util.Date.class)) {
/*  818 */               localObject2 = new SimpleDateFormat(
/*  819 */                 "yyyy-MM-dd HH:mm:ss").format(localObject2);
/*      */             }
/*  821 */             localErrorMessage.setOriginalValue(localObject2.toString());
/*      */           } catch (Exception localException) {
/*  823 */             localErrorMessage.setOriginalValue("");
/*      */           }
/*  825 */           localList2.add(localErrorMessage);
/*      */         }
/*      */       }
/*  828 */       i++;
/*      */     }
/*  830 */     return paramImportData;
/*      */   }
/*      */ 
/*      */   public int uniqueValidate(String[] paramArrayOfString, Object paramObject, JSONArray paramJSONArray)
/*      */   {
/*  838 */     if ((paramJSONArray != null) && (paramArrayOfString != null)) {
/*  839 */       for (int i = 0; i < paramJSONArray.size(); i++) {
/*  840 */         JSONObject localJSONObject = paramJSONArray.getJSONObject(i);
/*  841 */         for (int j = 0; j < paramArrayOfString.length; j++) {
/*  842 */           Object localObject1 = localJSONObject.get(paramArrayOfString[j]);
/*      */           try {
/*  844 */             Object localObject2 = PropertyUtils.getProperty(paramObject, 
/*  845 */               paramArrayOfString[j]);
/*  846 */             if ((localObject2 == null) || 
/*  847 */               (localObject1 == null))
/*      */               break;
/*  848 */             if (localObject1.toString().equals(
/*  849 */               localObject2.toString()));
/*      */           }
/*      */           catch (IllegalAccessException localIllegalAccessException)
/*      */           {
/*  854 */             localIllegalAccessException.printStackTrace();
/*      */           } catch (InvocationTargetException localInvocationTargetException) {
/*  856 */             localInvocationTargetException.printStackTrace();
/*      */           } catch (NoSuchMethodException localNoSuchMethodException) {
/*  858 */             localNoSuchMethodException.printStackTrace();
/*      */           }
/*  860 */           if (j == paramArrayOfString.length - 1) {
/*  861 */             return i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  866 */     return -1;
/*      */   }
/*      */ 
/*      */   public void doSetProperty(Object paramObject, String paramString1, String paramString2) throws Exception
/*      */   {
/*  871 */     if ((paramString1 == null) || (paramString1.equals("null")) || (paramString1.equals(""))) {
/*  872 */       return;
/*      */     }
/*      */ 
/*  875 */     if (paramString2.indexOf(".") > 0) {
/*  876 */       localObject1 = paramString2.substring(0, paramString2.indexOf("."));
/*      */ 
/*  878 */       Object localObject2 = PropertyUtils.getProperty(paramObject, (String)localObject1);
/*  879 */       if (localObject2 == null) {
/*  880 */         localObject2 = PropertyUtils.getPropertyType(paramObject, (String)localObject1).newInstance();
/*  881 */         PropertyUtils.setProperty(paramObject, (String)localObject1, localObject2);
/*      */       }
/*  883 */       doSetProperty(localObject2, paramString1, paramString2.substring(paramString2.indexOf(".") + 1));
/*      */     }
/*  885 */     Object localObject1 = PropertyUtils.getPropertyType(paramObject, paramString2);
/*  886 */     if (localObject1 == String.class)
/*  887 */       PropertyUtils.setProperty(paramObject, paramString2, paramString1);
/*  888 */     else if (localObject1 == Integer.TYPE)
/*  889 */       PropertyUtils.setProperty(paramObject, paramString2, 
/*  890 */         Integer.valueOf(Integer.parseInt(paramString1)));
/*  891 */     else if (localObject1 == Byte.TYPE)
/*  892 */       PropertyUtils.setProperty(paramObject, paramString2, Byte.valueOf(Byte.parseByte(paramString1)));
/*  893 */     else if (localObject1 == Long.TYPE)
/*  894 */       PropertyUtils.setProperty(paramObject, paramString2, Long.valueOf(Long.parseLong(paramString1)));
/*  895 */     else if (localObject1 == Short.TYPE)
/*  896 */       PropertyUtils.setProperty(paramObject, paramString2, 
/*  897 */         Short.valueOf(Short.parseShort(paramString1)));
/*  898 */     else if (localObject1 == Double.TYPE)
/*  899 */       PropertyUtils.setProperty(paramObject, paramString2, 
/*  900 */         Double.valueOf(Double.parseDouble(paramString1)));
/*  901 */     else if (localObject1 == Float.TYPE)
/*  902 */       PropertyUtils.setProperty(paramObject, paramString2, 
/*  903 */         Double.valueOf(Double.parseDouble(paramString1)));
/*  904 */     else if (localObject1 == Byte.TYPE)
/*  905 */       PropertyUtils.setProperty(paramObject, paramString2, Byte.valueOf(Byte.parseByte(paramString1)));
/*  906 */     else if ((localObject1 == Boolean.TYPE) || (localObject1 == Boolean.class))
/*  907 */       PropertyUtils.setProperty(paramObject, paramString2, 
/*  908 */         Boolean.valueOf(Boolean.parseBoolean(paramString1)));
/*  909 */     else if ((localObject1 == java.util.Date.class) || (((Class)localObject1).getSuperclass() == java.util.Date.class))
/*  910 */       PropertyUtils.setProperty(paramObject, paramString2, ((Class)localObject1).getConstructor(
/*  911 */         new Class[] { Long.TYPE }).newInstance(
/*  912 */         new Object[] { 
/*  913 */         Long.valueOf(GMT.fromGMTToCST(
/*  913 */         Long.valueOf(paramString1).longValue()).getTime()) }));
/*  914 */     else if (((Class)localObject1).getSuperclass() == Number.class)
/*  915 */       if (localObject1 == Integer.class)
/*  916 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  917 */           Integer.valueOf(Integer.parseInt(paramString1)));
/*  918 */       else if (localObject1 == Byte.class)
/*  919 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  920 */           Byte.valueOf(Byte.parseByte(paramString1)));
/*  921 */       else if (localObject1 == Long.class)
/*  922 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  923 */           Long.valueOf(Long.parseLong(paramString1)));
/*  924 */       else if (localObject1 == Short.class)
/*  925 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  926 */           Short.valueOf(Short.parseShort(paramString1)));
/*  927 */       else if (localObject1 == Double.class)
/*  928 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  929 */           Double.valueOf(Double.parseDouble(paramString1)));
/*  930 */       else if (localObject1 == Float.class)
/*  931 */         PropertyUtils.setProperty(paramObject, paramString2, 
/*  932 */           Float.valueOf(Float.parseFloat(paramString1)));
/*  933 */       else if (localObject1 == BigDecimal.class)
/*  934 */         PropertyUtils.setProperty(paramObject, paramString2, new BigDecimal(
/*  935 */           paramString1));
/*      */   }
/*      */ 
/*      */   public List<String> getCellValue(Cell paramCell, String paramString)
/*      */   {
/*  942 */     ArrayList localArrayList = new ArrayList();
/*  943 */     String str2 = "false";
/*  944 */     boolean bool = false;
/*      */     String str1;
/*  945 */     switch (paramCell.getCellType()) {
/*      */     case 3:
/*  947 */       str1 = "";
/*  948 */       break;
/*      */     case 4:
/*  950 */       str1 = String.valueOf(paramCell.getBooleanCellValue());
/*  951 */       break;
/*      */     case 5:
/*  954 */       str1 = "";
/*  955 */       break;
/*      */     case 2:
/*  957 */       Workbook localWorkbook = paramCell.getSheet().getWorkbook();
/*  958 */       CreationHelper localCreationHelper = localWorkbook.getCreationHelper();
/*  959 */       FormulaEvaluator localFormulaEvaluator = localCreationHelper.createFormulaEvaluator();
/*  960 */       str1 = (String)getCellValue(localFormulaEvaluator.evaluateInCell(paramCell), "").get(0);
/*  961 */       break;
/*      */     case 0:
/*  963 */       if ((DateUtil.isCellDateFormatted(paramCell)) || (paramString.equals("date"))) {
/*  964 */         java.util.Date localDate = paramCell.getDateCellValue();
/*  965 */         str1 = String.valueOf(localDate.getTime());
/*      */       } else {
/*  967 */         if (paramString.equals("date")) {
/*  968 */           str2 = "true";
/*      */         }
/*  970 */         str1 = NumberToTextConverter.toText(paramCell.getNumericCellValue());
/*      */       }
/*  972 */       break;
/*      */     case 1:
/*  974 */       str1 = paramCell.getRichStringCellValue().getString();
/*  975 */       bool = true;
/*  976 */       break;
/*      */     default:
/*  979 */       str1 = "";
/*      */     }
/*  981 */     localArrayList.add(str1.trim());
/*  982 */     localArrayList.add(str2);
/*  983 */     localArrayList.add(String.valueOf(bool));
/*  984 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   public String getValueFormMap(Map<String, String> paramMap, String paramString)
/*      */   {
/*      */     try {
/*  990 */       return (String)paramMap.get(paramString); } catch (Exception localException) {
/*      */     }
/*  992 */     return null;
/*      */   }
/*      */ 
/*      */   public void saveImportConfig(String paramString1, String paramString2, String paramString3, String paramString4)
/*      */   {
/*  997 */     GridImportConfig localGridImportConfig = new GridImportConfig();
/*  998 */     localGridImportConfig.setCmpId(paramString4);
/*  999 */     localGridImportConfig.setContent(paramString1);
/* 1000 */     localGridImportConfig.setPath(paramString2);
/* 1001 */     localGridImportConfig.setUserId(paramString3);
/* 1002 */     this.gridImportDAO.saveImportConfig(localGridImportConfig);
/*      */   }
/*      */ 
/*      */   public String getImportConfig(String paramString1, String paramString2, String paramString3) {
/* 1006 */     return this.gridImportDAO.getImportConfig(paramString1, paramString2, paramString3);
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.bo.impl.GridImportBOImpl
 * JD-Core Version:    0.6.2
 */