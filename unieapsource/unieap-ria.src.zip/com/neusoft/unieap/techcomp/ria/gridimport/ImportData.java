/*    */ package com.neusoft.unieap.techcomp.ria.gridimport;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ImportData
/*    */ {
/*    */   private List<Object> pojoList;
/*    */   private List<ErrorMessage> errorMessageList;
/* 16 */   Map<String, String> stateMap = new HashMap();
/* 17 */   Map<String, String> excelToOrginId = new HashMap();
/*    */   private boolean validationContinue;
/*    */ 
/*    */   public List<Object> getPojoList()
/*    */   {
/* 34 */     return this.pojoList;
/*    */   }
/*    */   public void setPojoList(List<Object> paramList) {
/* 37 */     this.pojoList = paramList;
/*    */   }
/*    */   public List<ErrorMessage> getErrorMessageList() {
/* 40 */     return this.errorMessageList;
/*    */   }
/*    */   public void setErrorMessageList(List<ErrorMessage> paramList) {
/* 43 */     this.errorMessageList = paramList;
/*    */   }
/*    */   public Map<String, String> getStateMap() {
/* 46 */     return this.stateMap;
/*    */   }
/*    */   public void setStateMap(Map<String, String> paramMap) {
/* 49 */     this.stateMap = paramMap;
/*    */   }
/*    */   public boolean getValidationContinue() {
/* 52 */     return this.validationContinue;
/*    */   }
/*    */   public void setValidationContinue(boolean paramBoolean) {
/* 55 */     this.validationContinue = paramBoolean;
/*    */   }
/*    */   public Map<String, String> getExcelToOrginId() {
/* 58 */     return this.excelToOrginId;
/*    */   }
/*    */   public void setExcelToOrginId(Map<String, String> paramMap) {
/* 61 */     this.excelToOrginId = paramMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.ImportData
 * JD-Core Version:    0.6.2
 */