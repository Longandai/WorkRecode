/*    */ package com.neusoft.unieap.techcomp.ria.gridimport.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.gridimport.dao.GridImportDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.gridimport.entity.GridImportConfig;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("gridImportDAO.dao")
/*    */ public class GridImportDAOImpl extends BaseHibernateDAO
/*    */   implements GridImportDAO
/*    */ {
/*    */   public String getImportConfig(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 21 */     String str = "select importConfig.content from GridImportConfig importConfig where importConfig.userId = ? and importConfig.cmpId = ? and importConfig.path = ?";
/* 22 */     List localList = getHibernateTemplate().find(str, new Object[] { paramString2, paramString3, paramString1 });
/* 23 */     if (localList.size() == 0) {
/* 24 */       return "";
/*    */     }
/* 26 */     return String.valueOf(localList.get(0));
/*    */   }
/*    */ 
/*    */   public void saveImportConfig(GridImportConfig paramGridImportConfig) {
/* 30 */     String str = "select importConfig.id from GridImportConfig importConfig where importConfig.userId = ? and importConfig.cmpId = ? and importConfig.path = ?";
/* 31 */     List localList = getHibernateTemplate().find(str, new Object[] { paramGridImportConfig.getUserId(), paramGridImportConfig.getCmpId(), paramGridImportConfig.getPath() });
/* 32 */     if (localList.size() > 0) {
/* 33 */       paramGridImportConfig.setId(String.valueOf(localList.get(0)));
/* 34 */       getHibernateTemplate().update(paramGridImportConfig);
/*    */     } else {
/* 36 */       getHibernateTemplate().save(paramGridImportConfig);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.dao.impl.GridImportDAOImpl
 * JD-Core Version:    0.6.2
 */