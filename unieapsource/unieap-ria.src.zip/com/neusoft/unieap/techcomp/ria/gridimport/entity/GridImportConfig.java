/*    */ package com.neusoft.unieap.techcomp.ria.gridimport.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("gridImportConfig.entity")
/*    */ public class GridImportConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String userId;
/*    */   private String path;
/*    */   private String cmpId;
/*    */   private String content;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 36 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 40 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setUserId(String paramString) {
/* 44 */     this.userId = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 48 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setPath(String paramString) {
/* 52 */     this.path = paramString;
/*    */   }
/*    */ 
/*    */   public String getPath() {
/* 56 */     return this.path;
/*    */   }
/*    */ 
/*    */   public void setCmpId(String paramString) {
/* 60 */     this.cmpId = paramString;
/*    */   }
/*    */ 
/*    */   public String getCmpId() {
/* 64 */     return this.cmpId;
/*    */   }
/*    */ 
/*    */   public void setContent(String paramString) {
/* 68 */     this.content = paramString;
/*    */   }
/*    */ 
/*    */   public String getContent() {
/* 72 */     return this.content;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.entity.GridImportConfig
 * JD-Core Version:    0.6.2
 */