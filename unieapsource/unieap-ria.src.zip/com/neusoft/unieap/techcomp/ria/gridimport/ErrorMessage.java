/*    */ package com.neusoft.unieap.techcomp.ria.gridimport;
/*    */ 
/*    */ public class ErrorMessage
/*    */ {
/*    */   private int rowNum;
/*    */   private String cellName;
/*    */   private String message;
/*    */   private String originalValue;
/*    */ 
/*    */   public String getCellName()
/*    */   {
/* 25 */     return this.cellName;
/*    */   }
/*    */   public void setCellName(String paramString) {
/* 28 */     this.cellName = paramString;
/*    */   }
/*    */   public int getRowNum() {
/* 31 */     return this.rowNum;
/*    */   }
/*    */   public void setRowNum(int paramInt) {
/* 34 */     this.rowNum = paramInt;
/*    */   }
/*    */   public String getMessage() {
/* 37 */     return this.message;
/*    */   }
/*    */   public void setMessage(String paramString) {
/* 40 */     this.message = paramString;
/*    */   }
/*    */   public String getOriginalValue() {
/* 43 */     return this.originalValue;
/*    */   }
/*    */   public void setOriginalValue(String paramString) {
/* 46 */     this.originalValue = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.ErrorMessage
 * JD-Core Version:    0.6.2
 */