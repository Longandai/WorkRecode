/*    */ package com.neusoft.unieap.techcomp.ria.gridimport.validation.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.gridimport.ImportData;
/*    */ import com.neusoft.unieap.techcomp.ria.gridimport.validation.GridImportValidation;
/*    */ 
/*    */ public class DefaultImportValidationImpl
/*    */   implements GridImportValidation
/*    */ {
/*    */   public ImportData afterValidate(ImportData paramImportData)
/*    */   {
/*  9 */     return paramImportData;
/*    */   }
/*    */ 
/*    */   public ImportData beforeValidate(ImportData paramImportData) {
/* 13 */     return paramImportData;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.validation.impl.DefaultImportValidationImpl
 * JD-Core Version:    0.6.2
 */