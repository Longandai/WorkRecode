package com.neusoft.unieap.techcomp.ria.gridimport.dao;

import com.neusoft.unieap.techcomp.ria.gridimport.entity.GridImportConfig;

public abstract interface GridImportDAO
{
  public abstract void saveImportConfig(GridImportConfig paramGridImportConfig);

  public abstract String getImportConfig(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.dao.GridImportDAO
 * JD-Core Version:    0.6.2
 */