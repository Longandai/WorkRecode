package com.neusoft.unieap.techcomp.ria.gridimport.validation;

import com.neusoft.unieap.techcomp.ria.gridimport.ImportData;

public abstract interface GridImportValidation
{
  public abstract ImportData beforeValidate(ImportData paramImportData);

  public abstract ImportData afterValidate(ImportData paramImportData);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.gridimport.validation.GridImportValidation
 * JD-Core Version:    0.6.2
 */