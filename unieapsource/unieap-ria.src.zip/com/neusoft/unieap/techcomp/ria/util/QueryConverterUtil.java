/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.query.dto.Condition;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class QueryConverterUtil
/*     */ {
/*  19 */   private static QueryConverterUtil instance = null;
/*     */ 
/*  33 */   public static Properties props = new Properties();
/*     */ 
/*  35 */   static { props.setProperty("M", "LIKE");
/*  36 */     props.setProperty("LM", "LIKE");
/*  37 */     props.setProperty("RM", "LIKE");
/*  38 */     props.setProperty("NM", "NOT LIKE");
/*  39 */     props.setProperty("NLM", "NOT LIKE");
/*  40 */     props.setProperty("NRM", "NOT LIKE");
/*     */ 
/*  42 */     props.setProperty("E", "=");
/*  43 */     props.setProperty("NE", "!=");
/*  44 */     props.setProperty("G", ">");
/*  45 */     props.setProperty("S", "<");
/*  46 */     props.setProperty("GE", ">=");
/*  47 */     props.setProperty("SE", "<=");
/*     */   }
/*     */ 
/*     */   public static synchronized QueryConverterUtil getInstance()
/*     */   {
/*  25 */     if (instance == null) {
/*  26 */       instance = new QueryConverterUtil();
/*     */     }
/*  28 */     return instance;
/*     */   }
/*     */ 
/*     */   public final Object[] getQueryCondition(List paramList)
/*     */   {
/*  55 */     if ((paramList == null) || (paramList.size() == 0)) {
/*  56 */       return null;
/*     */     }
/*  58 */     Condition localCondition = null;
/*  59 */     StringBuffer localStringBuffer = new StringBuffer();
/*  60 */     Object[] arrayOfObject1 = new Object[paramList.size()];
/*  61 */     for (int i = 0; i < paramList.size(); i++) {
/*  62 */       if (i > 0) {
/*  63 */         localStringBuffer.append(" AND ");
/*     */       }
/*  65 */       localCondition = (Condition)paramList.get(i);
/*  66 */       localStringBuffer.append(localCondition.getColumn());
/*  67 */       localStringBuffer.append(" ");
/*  68 */       localStringBuffer.append(getOption(localCondition.getOperation()));
/*  69 */       localStringBuffer.append(" ? ");
/*  70 */       arrayOfObject1[i] = getValue(localCondition.getOperation(), localCondition.getValue(), localCondition.getDataType());
/*     */     }
/*  72 */     Object[] arrayOfObject2 = new Object[2];
/*  73 */     arrayOfObject2[0] = localStringBuffer.toString();
/*  74 */     arrayOfObject2[1] = arrayOfObject1;
/*  75 */     return arrayOfObject2;
/*     */   }
/*     */ 
/*     */   private final String getOption(String paramString)
/*     */   {
/*  84 */     String str = props.getProperty(paramString);
/*  85 */     if (str == null) {
/*  86 */       throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/*  88 */     return str;
/*     */   }
/*     */ 
/*     */   private final Object getValue(String paramString, Object paramObject, int paramInt)
/*     */   {
/*  98 */     Object localObject = null;
/*  99 */     if (paramString.indexOf("M") != -1) {
/* 100 */       if (paramString.equalsIgnoreCase("M"))
/* 101 */         localObject = "%" + paramObject + "%";
/* 102 */       else if (paramString.equalsIgnoreCase("LM"))
/* 103 */         localObject = paramObject + "%";
/* 104 */       else if (paramString.equalsIgnoreCase("RM"))
/* 105 */         localObject = "%" + paramObject;
/* 106 */       else if (paramString.equalsIgnoreCase("NM"))
/* 107 */         localObject = "%" + paramObject + "%";
/* 108 */       else if (paramString.equalsIgnoreCase("NLM"))
/* 109 */         localObject = paramObject + "%";
/* 110 */       else if (paramString.equalsIgnoreCase("NRM"))
/* 111 */         localObject = "%" + paramObject;
/*     */       else
/* 113 */         throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/* 115 */     else if (props.getProperty(paramString) != null) {
/* 116 */       if (paramObject != null) {
/* 117 */         if (paramInt == 12)
/* 118 */           localObject = (String)paramObject;
/* 119 */         else if (paramInt == 91)
/* 120 */           localObject = new Date(((Long)paramObject).longValue());
/* 121 */         else if (paramInt == 93)
/* 122 */           localObject = new Date(((Long)paramObject).longValue());
/* 123 */         else if (paramInt == 92)
/* 124 */           localObject = new Time(((Long)paramObject).longValue());
/* 125 */         else if (paramInt == 4)
/* 126 */           localObject = Integer.valueOf(indexof((String)paramObject));
/* 127 */         else if (paramInt == 8)
/* 128 */           localObject = Double.valueOf(dealPoint((String)paramObject));
/* 129 */         else if (paramInt == 3)
/* 130 */           localObject = new BigDecimal(dealPoint((String)paramObject));
/* 131 */         else if (paramInt == 6)
/* 132 */           localObject = Float.valueOf(dealPoint((String)paramObject));
/* 133 */         else if (paramInt == -5)
/* 134 */           localObject = Long.valueOf(indexof((String)paramObject));
/* 135 */         else if (paramInt == 16)
/* 136 */           localObject = Boolean.valueOf((String)paramObject);
/*     */       }
/*     */     }
/*     */     else {
/* 140 */       throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/* 142 */     return localObject;
/*     */   }
/*     */ 
/*     */   public String indexof(String paramString)
/*     */   {
/* 150 */     int i = paramString.indexOf(".");
/* 151 */     if (i == -1)
/* 152 */       return paramString;
/* 153 */     if (i == 0)
/* 154 */       return "0";
/* 155 */     return paramString.substring(0, i);
/*     */   }
/*     */ 
/*     */   public String dealPoint(String paramString)
/*     */   {
/* 164 */     int i = 1;
/* 165 */     char[] arrayOfChar1 = paramString.toCharArray();
/* 166 */     char[] arrayOfChar2 = new char[arrayOfChar1.length];
/* 167 */     int j = 0;
/* 168 */     for (int k = 0; k < arrayOfChar1.length; k++) {
/* 169 */       if (arrayOfChar1[k] == '.') {
/* 170 */         if (i != 0) {
/* 171 */           i = 0;
/*     */         }
/*     */       }
/*     */       else
/* 175 */         arrayOfChar2[(j++)] = arrayOfChar1[k];
/*     */     }
/* 177 */     return String.valueOf(arrayOfChar2);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.QueryConverterUtil
 * JD-Core Version:    0.6.2
 */