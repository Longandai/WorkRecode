/*      */ package com.neusoft.unieap.techcomp.ria.util;
/*      */ 
/*      */ import com.neusoft.unieap.core.codelist.usertype.CodeType;
/*      */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.impl.RowImpl;
/*      */ import com.neusoft.unieap.techcomp.ria.pojo.PojoEntity;
/*      */ import com.neusoft.unieap.techcomp.ria.pojo.PojoList;
/*      */ import com.neusoft.unieap.techcomp.ria.util.proxy.ProxyObjHandler;
/*      */ import com.neusoft.unieap.techcomp.ria.util.proxy.ProxyObjHandlerFactory;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import net.sf.json.JSONObject;
/*      */ import org.apache.commons.beanutils.PropertyUtils;
/*      */ import org.apache.commons.lang.ClassUtils;
/*      */ import org.hibernate.Hibernate;
/*      */ import org.hibernate.proxy.HibernateProxy;
/*      */ import org.hibernate.proxy.LazyInitializer;
/*      */ import org.slf4j.Logger;
/*      */ import org.slf4j.LoggerFactory;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ 
/*      */ public class PojoUtil
/*      */ {
/*   52 */   private static final Map pojoEntiyProperty = new ConcurrentHashMap();
/*      */ 
/*   54 */   private static ProxyObjHandler pojoProxyHandler = ProxyObjHandlerFactory.getHandler();
/*      */ 
/*   57 */   private static final Logger logger = LoggerFactory.getLogger(PojoUtil.class);
/*      */ 
/*  392 */   private static Map clazzMapping = new HashMap();
/*      */ 
/*  394 */   static { clazzMapping.put(Integer.TYPE, Integer.class);
/*  395 */     clazzMapping.put(Float.TYPE, Float.class);
/*  396 */     clazzMapping.put(Double.TYPE, Double.class);
/*  397 */     clazzMapping.put(Long.TYPE, Long.class);
/*  398 */     clazzMapping.put(Boolean.TYPE, Boolean.class);
/*  399 */     clazzMapping.put(Byte.TYPE, Byte.class);
/*  400 */     clazzMapping.put(BigDecimal.class, BigDecimal.class);
/*      */   }
/*      */ 
/*      */   public static PojoList toPojoList(DataStore paramDataStore)
/*      */   {
/*   66 */     String str = paramDataStore.getRowSetName();
/*   67 */     PojoList localPojoList = new PojoList(str);
/*      */     try {
/*   69 */       List localList = paramDataStore.getRowSet().getRows();
/*   70 */       int i = 0;
/*      */       Row localRow;
/*   70 */       for (int j = localList.size(); i < j; i++) {
/*   71 */         localRow = (Row)localList.get(i);
/*   72 */         localPojoList.addPojo(createPojoEntity(str, localRow));
/*      */       }
/*   74 */       localList = paramDataStore.getRowSet().getFilterRows();
/*   75 */       i = 0; for (j = localList.size(); i < j; i++) {
/*   76 */         localRow = (Row)localList.get(i);
/*   77 */         localPojoList.addPojo(createPojoEntity(str, localRow));
/*      */       }
/*   79 */       localList = paramDataStore.getRowSet().getDeleteRows();
/*   80 */       i = 0; for (j = localList.size(); i < j; i++) {
/*   81 */         localRow = (Row)localList.get(i);
/*   82 */         localPojoList.addDeletePojo(createPojoEntity(str, 
/*   83 */           localRow));
/*      */       }
/*      */     } catch (Exception localException) {
/*   86 */       localException.printStackTrace();
/*      */     }
/*   88 */     return localPojoList;
/*      */   }
/*      */ 
/*      */   public static PojoEntity createPojoEntity(String paramString, Row paramRow)
/*      */     throws Exception
/*      */   {
/*  103 */     JSONObject localJSONObject = ((RowImpl)paramRow).getJSONObject();
/*  104 */     Object localObject1 = Class.forName(paramString).newInstance();
/*  105 */     PojoEntity localPojoEntity = new PojoEntity(localObject1);
/*      */ 
/*  108 */     localPojoEntity.setRow(paramRow);
/*  109 */     Map localMap = null;
/*  110 */     Iterator localIterator = localJSONObject.entrySet().iterator();
/*      */ 
/*  114 */     Set localSet = getKeySetValueIsNull(localJSONObject.entrySet());
/*      */     Map.Entry localEntry;
/*      */     String str;
/*      */     Object localObject2;
/*  115 */     while (localIterator.hasNext()) {
/*  116 */       localEntry = (Map.Entry)localIterator.next();
/*  117 */       str = (String)localEntry.getKey();
/*      */ 
/*  119 */       localObject2 = localEntry.getValue();
/*      */ 
/*  121 */       if (!localSet.contains(str))
/*      */       {
/*  125 */         if ("_t".equals(str)) {
/*  126 */           localPojoEntity.setStatus(Integer.parseInt(localObject2.toString()));
/*      */         }
/*  129 */         else if ("_s".equals(str)) {
/*  130 */           localPojoEntity.setSelected("true".equals(localObject2));
/*      */         }
/*  133 */         else if ("_o".equals(str)) {
/*  134 */           localMap = (Map)localObject2;
/*      */         }
/*      */         else {
/*  137 */           if (((localObject2 instanceof JSONObject)) && 
/*  138 */             (((JSONObject)localObject2).isNullObject())) {
/*  139 */             localObject2 = null;
/*      */           }
/*      */ 
/*  142 */           setProperty(localPojoEntity.getPojoObj(), str, localObject2);
/*      */         }
/*      */       }
/*      */     }
/*  144 */     if (localMap != null) {
/*  145 */       Object localObject3 = depthClone(localPojoEntity.getPojoObj());
/*  146 */       localPojoEntity.setOrignPojoObj(localObject3);
/*  147 */       localIterator = localMap.entrySet().iterator();
/*  148 */       while (localIterator.hasNext()) {
/*  149 */         localEntry = (Map.Entry)localIterator.next();
/*  150 */         str = (String)localEntry.getKey();
/*  151 */         localObject2 = localEntry.getValue();
/*      */ 
/*  153 */         if (!localSet.contains(str))
/*      */         {
/*  157 */           if (((localObject2 instanceof JSONObject)) && 
/*  158 */             (((JSONObject)localObject2).isNullObject())) {
/*  159 */             localObject2 = null;
/*      */           }
/*      */ 
/*  162 */           setProperty(localObject3, str, localObject2);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  170 */     return localPojoEntity;
/*      */   }
/*      */ 
/*      */   private static Field getMatchField(String paramString, Field[] paramArrayOfField)
/*      */   {
/*  240 */     int i = paramArrayOfField.length;
/*  241 */     for (int j = 0; j < i; j++) {
/*  242 */       Field localField = paramArrayOfField[j];
/*  243 */       if (paramString.equals(localField.getName())) {
/*  244 */         return localField;
/*      */       }
/*      */     }
/*  247 */     return null;
/*      */   }
/*      */ 
/*      */   public static Object depthClone(Object paramObject)
/*      */   {
/*  278 */     if (!(paramObject instanceof Serializable)) {
/*  279 */       throw new RIAException(
/*  280 */         "EAPTECH008007", 
/*  281 */         new Object[] { paramObject.getClass().getName() });
/*      */     }
/*  283 */     Object localObject = null;
/*      */     try {
/*  285 */       ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  286 */       ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(localByteArrayOutputStream);
/*  287 */       localObjectOutputStream.writeObject(paramObject);
/*  288 */       ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(localByteArrayOutputStream
/*  289 */         .toByteArray());
/*  290 */       ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
/*  291 */       localObject = localObjectInputStream.readObject();
/*      */     } catch (Exception localException) {
/*  293 */       localException.printStackTrace();
/*      */     }
/*  295 */     return localObject;
/*      */   }
/*      */ 
/*      */   public static void setProperty(Object paramObject1, String paramString, Object paramObject2)
/*      */     throws Exception
/*      */   {
/*  311 */     Class localClass1 = paramObject1.getClass();
/*  312 */     Set localSet = getEntityProperties(localClass1);
/*  313 */     if (!localSet.contains(paramString)) {
/*  314 */       return;
/*      */     }
/*  316 */     Object localObject1 = paramObject1;
/*  317 */     String str = paramString;
/*      */     Object localObject3;
/*  318 */     if (paramString.indexOf(".") > 0) {
/*  319 */       localObject2 = paramString.split("\\.");
/*  320 */       for (int i = 0; i < localObject2.length - 1; i++)
/*      */       {
/*  322 */         localObject3 = 
/*  323 */           PropertyUtils.getProperty(localObject1, localObject2[i]);
/*  324 */         if (localObject3 == null)
/*      */         {
/*  326 */           Class localClass3 = 
/*  327 */             BeanUtils.getPropertyDescriptor(localObject1.getClass(), localObject2[i])
/*  328 */             .getPropertyType();
/*  329 */           localObject3 = localClass3.newInstance();
/*  330 */           PropertyUtils.setProperty(localObject1, localObject2[i], localObject3);
/*      */         }
/*  332 */         localObject1 = localObject3;
/*      */       }
/*  334 */       str = localObject2[(localObject2.length - 1)];
/*      */     }
/*  336 */     Object localObject2 = localObject1.getClass(); Class localClass2 = null;
/*  337 */     while (localObject2 != Object.class) {
/*      */       try {
/*  339 */         localObject3 = ((Class)localObject2).getDeclaredField(str);
/*  340 */         localClass2 = ((Field)localObject3).getType();
/*      */       }
/*      */       catch (Exception localException) {
/*  343 */         localObject2 = ((Class)localObject2).getSuperclass();
/*      */       }
/*      */     }
/*  346 */     if (localClass2 == null) {
/*  347 */       return;
/*      */     }
/*  349 */     if ((localClass2 == Date.class) || (localClass2.getSuperclass() == Date.class)) {
/*  350 */       if ((paramObject2 != null) && (!"".equals(paramObject2.toString())))
/*  351 */         paramObject2 = localClass2.getConstructor(new Class[] { Long.TYPE })
/*  352 */           .newInstance(
/*  353 */           new Object[] { 
/*  355 */           Long.valueOf(GMT.fromGMTToCST(
/*  354 */           Long.valueOf(paramObject2.toString())
/*  355 */           .longValue()).getTime()) });
/*      */       else {
/*  357 */         paramObject2 = null;
/*      */       }
/*      */ 
/*      */     }
/*  361 */     else if (localClass2.isPrimitive()) {
/*  362 */       if ((paramObject2 == null) || ("".equals(paramObject2.toString()))) {
/*  363 */         return;
/*      */       }
/*  365 */       paramObject2 = getPrimitiveConstructor(localClass2).getConstructor(
/*  366 */         new Class[] { String.class }).newInstance(
/*  367 */         new Object[] { paramObject2.toString() });
/*      */     }
/*  370 */     else if (isCodeType(localClass2)) {
/*  371 */       if ((paramObject2 != null) && (!"".equals(paramObject2.toString()))) {
/*  372 */         localObject3 = localClass2.getMethod("getInstance", new Class[] { 
/*  373 */           Class.class, String.class });
/*  374 */         paramObject2 = ((Method)localObject3).invoke(null, new Object[] { localClass2, 
/*  375 */           paramObject2.toString() });
/*      */       } else {
/*  377 */         paramObject2 = null;
/*      */       }
/*      */ 
/*      */     }
/*  381 */     else if (clazzMapping.containsValue(localClass2)) {
/*  382 */       if ((paramObject2 != null) && (!"".equals(paramObject2.toString())))
/*  383 */         paramObject2 = localClass2.getConstructor(new Class[] { String.class })
/*  384 */           .newInstance(new Object[] { paramObject2.toString() });
/*      */       else {
/*  386 */         paramObject2 = null;
/*      */       }
/*      */     }
/*  389 */     PropertyUtils.setProperty(localObject1, str, paramObject2);
/*      */   }
/*      */ 
/*      */   private static Class getPrimitiveConstructor(Class paramClass)
/*      */   {
/*  405 */     Class localClass = (Class)clazzMapping.get(paramClass);
/*  406 */     if (localClass != null)
/*  407 */       return localClass;
/*  408 */     throw new RuntimeException("do not support class " + paramClass);
/*      */   }
/*      */ 
/*      */   public static Set getEntityProperties(Class paramClass)
/*      */     throws Exception
/*      */   {
/*  419 */     if (pojoEntiyProperty.containsKey(paramClass)) {
/*  420 */       return (Set)pojoEntiyProperty.get(paramClass);
/*      */     }
/*  422 */     Set localSet1 = Collections.synchronizedSet(new HashSet());
/*  423 */     pojoEntiyProperty.put(paramClass, localSet1);
/*  424 */     HashSet localHashSet1 = new HashSet();
/*  425 */     Method[] arrayOfMethod = paramClass.getMethods();
/*  426 */     int i = 0; for (int j = arrayOfMethod.length; i < j; i++) {
/*  427 */       String str1 = arrayOfMethod[i].getName();
/*  428 */       localHashSet1.add(str1);
/*      */     }
/*  430 */     ArrayList localArrayList = new ArrayList();
/*  431 */     Class localClass1 = paramClass;
/*      */ 
/*  433 */     while ((localClass1 != null) && (localClass1 != Object.class)) {
/*  434 */       localArrayList.add(localClass1.getDeclaredFields());
/*  435 */       localClass1 = localClass1.getSuperclass();
/*      */     }
/*  437 */     for (int k = 0; k < localArrayList.size(); k++) {
/*  438 */       Field[] arrayOfField = (Field[])localArrayList.get(k);
/*  439 */       int m = 0; for (int n = arrayOfField.length; m < n; m++) {
/*  440 */         String str2 = arrayOfField[m].getName();
/*  441 */         String str3 = getStandardBeanName(str2);
/*      */ 
/*  443 */         if ((localHashSet1.contains("get".concat(str3))) || 
/*  444 */           (localHashSet1
/*  444 */           .contains("is".concat(str3)))) {
/*  445 */           Class localClass2 = arrayOfField[m].getType();
/*  446 */           String str4 = localClass2.getName();
/*      */ 
/*  448 */           if ((!str4.startsWith("java.")) && 
/*  449 */             (!localClass2.isPrimitive()) && 
/*  450 */             (!isCodeType(localClass2))) {
/*  451 */             Set localSet2 = getEntityProperties(localClass2);
/*  452 */             HashSet localHashSet2 = new HashSet();
/*  453 */             for (Iterator localIterator = localSet2.iterator(); localIterator
/*  454 */               .hasNext(); )
/*      */             {
/*  455 */               String str5 = (String)localIterator.next();
/*  456 */               localHashSet2.add(str2.concat(".").concat(str5));
/*      */             }
/*  458 */             localSet1.addAll(localHashSet2);
/*      */           }
/*  461 */           else if (!isCollectionOrMap(localClass2)) {
/*  462 */             localSet1.add(str2);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  468 */     return localSet1;
/*      */   }
/*      */ 
/*      */   public static boolean isCollectionOrMap(Class paramClass)
/*      */   {
/*  478 */     if ((paramClass == Collection.class) || (paramClass == Map.class)) {
/*  479 */       return true;
/*      */     }
/*  481 */     Class[] arrayOfClass = paramClass.getInterfaces();
/*  482 */     if (arrayOfClass != null) {
/*  483 */       for (int i = 0; i < arrayOfClass.length; i++) {
/*  484 */         if (isCollectionOrMap(arrayOfClass[i])) {
/*  485 */           return true;
/*      */         }
/*      */       }
/*      */     }
/*  489 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isCodeType(Class paramClass)
/*      */   {
/*  499 */     List localList = ClassUtils.getAllInterfaces(paramClass);
/*  500 */     if ((localList != null) && (localList.contains(CodeType.class))) {
/*  501 */       return true;
/*      */     }
/*  503 */     return false;
/*      */   }
/*      */ 
/*      */   public static String getStandardBeanName(String paramString)
/*      */   {
/*  513 */     if (paramString.length() > 1) {
/*  514 */       int i = paramString.charAt(1);
/*  515 */       if ((65 <= i) && (i <= 90)) {
/*  516 */         return paramString;
/*      */       }
/*      */     }
/*  519 */     return String.valueOf(paramString.charAt(0)).toUpperCase().concat(
/*  520 */       paramString.substring(1));
/*      */   }
/*      */ 
/*      */   public static DataStore toDataStore(List paramList)
/*      */   {
/*  531 */     if (paramList == null) {
/*  532 */       return null;
/*      */     }
/*  534 */     String str = "";
/*  535 */     for (int i = 0; i < paramList.size(); i++) {
/*  536 */       if (paramList.get(i) != null) {
/*  537 */         str = paramList.get(i).getClass().getName();
/*  538 */         break;
/*      */       }
/*      */     }
/*  541 */     DataStoreImpl localDataStoreImpl = new DataStoreImpl(str);
/*  542 */     localDataStoreImpl.setRowSetName(str);
/*  543 */     assemblePojoToDataStore(paramList, localDataStoreImpl);
/*  544 */     return localDataStoreImpl;
/*      */   }
/*      */ 
/*      */   public static DataStore toDataStore(List paramList, DataStore paramDataStore)
/*      */   {
/*  556 */     DataStore localDataStore = getQueryDataStore(paramDataStore);
/*  557 */     String str1 = localDataStore.getRowSetName();
/*  558 */     Object localObject = null;
/*  559 */     if ((str1 == null) || (str1.trim().equals(""))) {
/*  560 */       if (paramList == null) {
/*  561 */         return null;
/*      */       }
/*  563 */       String str2 = "";
/*  564 */       for (int j = 0; j < paramList.size(); j++) {
/*  565 */         if (paramList.get(j) != null) {
/*  566 */           str2 = paramList.get(j).getClass().getName();
/*  567 */           localObject = paramList.get(j);
/*  568 */           break;
/*      */         }
/*      */       }
/*  571 */       localDataStore.setRowSetName(str2);
/*      */     }
/*      */ 
/*  574 */     if ((paramList.size() > 0) && (localObject != null) && ((localObject instanceof Map))) {
/*  575 */       localDataStore.setRowSetName("");
/*  576 */       for (int i = 0; i < paramList.size(); i++) {
/*  577 */         Iterator localIterator = ((Map)paramList.get(i)).entrySet().iterator();
/*  578 */         RowImpl localRowImpl = new RowImpl();
/*  579 */         while (localIterator.hasNext()) {
/*  580 */           Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  581 */           localRowImpl.setItemValue((String)localEntry.getKey(), localEntry.getValue());
/*      */         }
/*  583 */         localDataStore.getRowSet().addRow(localRowImpl);
/*      */       }
/*  585 */       return localDataStore;
/*      */     }
/*  587 */     assemblePojoToDataStore(paramList, localDataStore);
/*  588 */     return localDataStore;
/*      */   }
/*      */ 
/*      */   public static DataStore toDataStore4SQL(List paramList, DataStore paramDataStore)
/*      */   {
/*  601 */     DataStore localDataStore = getQueryDataStore(paramDataStore);
/*  602 */     String str1 = localDataStore.getRowSetName();
/*  603 */     Object localObject = null;
/*  604 */     if ((str1 == null) || (str1.trim().equals(""))) {
/*  605 */       if (paramList == null) {
/*  606 */         return null;
/*      */       }
/*  608 */       String str2 = "";
/*  609 */       for (int j = 0; j < paramList.size(); j++) {
/*  610 */         if (paramList.get(j) != null) {
/*  611 */           str2 = paramList.get(j).getClass().getName();
/*  612 */           localObject = paramList.get(j);
/*  613 */           break;
/*      */         }
/*      */       }
/*  616 */       localDataStore.setRowSetName(str2);
/*      */     }
/*      */ 
/*  619 */     if ((paramList.size() > 0) && (localObject != null) && ((localObject instanceof Map))) {
/*  620 */       localDataStore.setRowSetName("");
/*  621 */       for (int i = 0; i < paramList.size(); i++) {
/*  622 */         Iterator localIterator = ((Map)paramList.get(i)).entrySet().iterator();
/*  623 */         RowImpl localRowImpl = new RowImpl();
/*  624 */         while (localIterator.hasNext()) {
/*  625 */           Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  626 */           localRowImpl.setItemValue(
/*  627 */             HSUtil.getJavaName((String)localEntry.getKey()), localEntry
/*  628 */             .getValue());
/*      */         }
/*  630 */         localDataStore.getRowSet().addRow(localRowImpl);
/*      */       }
/*  632 */       return localDataStore;
/*      */     }
/*  634 */     assemblePojoToDataStore(paramList, localDataStore);
/*  635 */     return localDataStore;
/*      */   }
/*      */ 
/*      */   public static DataStore toDataStore(Map paramMap, DataStore paramDataStore)
/*      */   {
/*  646 */     DataStore localDataStore = getQueryDataStore(paramDataStore);
/*  647 */     localDataStore.setRowSetName("");
/*  648 */     Iterator localIterator = paramMap.entrySet().iterator();
/*  649 */     RowImpl localRowImpl = new RowImpl();
/*  650 */     while (localIterator.hasNext()) {
/*  651 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  652 */       localRowImpl.setItemValue((String)localEntry.getKey(), localEntry.getValue());
/*      */     }
/*  654 */     localDataStore.getRowSet().addRow(localRowImpl);
/*  655 */     return localDataStore;
/*      */   }
/*      */ 
/*      */   public static DataStore getQueryDataStore(DataStore paramDataStore)
/*      */   {
/*  665 */     DataStore localDataStore = (DataStore)paramDataStore.clone();
/*  666 */     localDataStore.getRowSet().clear();
/*  667 */     return localDataStore;
/*      */   }
/*      */ 
/*      */   private static void assemblePojoToDataStore(List paramList, DataStore paramDataStore)
/*      */   {
/*  674 */     Object localObject = null;
/*      */     try {
/*  676 */       int i = 0; for (int j = paramList.size(); i < j; i++) {
/*  677 */         localObject = paramList.get(i);
/*  678 */         paramDataStore.getRowSet().addRow(createRow(localObject));
/*      */       }
/*      */     } catch (Exception localException) {
/*  681 */       localException.printStackTrace();
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void assembleStatistics(DataStore paramDataStore, Object[] paramArrayOfObject)
/*      */   {
/*  693 */     if ((paramArrayOfObject == null) || (paramArrayOfObject.length == 0) || 
/*  694 */       (paramArrayOfObject[0] == null))
/*  695 */       return;
/*  696 */     int i = Integer.parseInt(paramArrayOfObject[0].toString());
/*  697 */     paramDataStore.setRecordCount(i);
/*  698 */     int j = 1;
/*      */     Iterator localIterator2;
/*  699 */     for (Iterator localIterator1 = paramDataStore.getStatisticsPatterns().entrySet()
/*  700 */       .iterator(); 
/*  700 */       localIterator1.hasNext(); 
/*  704 */       localIterator2.hasNext())
/*      */     {
/*  701 */       Map.Entry localEntry = (Map.Entry)localIterator1.next();
/*  702 */       String str1 = (String)localEntry.getKey();
/*  703 */       Set localSet = (Set)localEntry.getValue();
/*  704 */       localIterator2 = localSet.iterator(); continue;
/*  705 */       String str2 = (String)localIterator2.next();
/*  706 */       Number localNumber = (Number)paramArrayOfObject[j];
/*  707 */       paramDataStore.addStatistics(str1, str2, localNumber);
/*  708 */       j++;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Row createRow(Object paramObject)
/*      */     throws Exception
/*      */   {
/*  721 */     RowImpl localRowImpl = new RowImpl();
/*  722 */     Set localSet = null;
/*      */ 
/*  724 */     if ((pojoProxyHandler != null) && (pojoProxyHandler.isProxy(paramObject)))
/*  725 */       localSet = pojoProxyHandler.getEntityProperties(paramObject);
/*      */     else {
/*  727 */       localSet = getEntityProperties(paramObject.getClass());
/*      */     }
/*      */ 
/*  732 */     for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); )
/*      */     {
/*      */       String str1;
/*  733 */       String str2 = str1 = (String)localIterator.next();
/*  734 */       Object localObject1 = paramObject;
/*  735 */       if (str1.indexOf(".") > 0) {
/*  736 */         String[] arrayOfString = str1.split("\\.");
/*  737 */         for (int i = 0; i < arrayOfString.length - 1; i++) {
/*  738 */           localObject1 = PropertyUtils.getProperty(localObject1, arrayOfString[i]);
/*  739 */           if (localObject1 == null)
/*      */             break;
/*  741 */           if (((localObject1 instanceof HibernateProxy)) && 
/*  742 */             (Hibernate.isInitialized(localObject1))) {
/*  743 */             localObject1 = ((HibernateProxy)localObject1)
/*  744 */               .getHibernateLazyInitializer()
/*  745 */               .getImplementation();
/*      */           }
/*      */         }
/*  748 */         str2 = arrayOfString[(arrayOfString.length - 1)];
/*      */       }
/*  750 */       if (localObject1 != null) {
/*  751 */         Object localObject2 = null;
/*  752 */         if ((localObject1 instanceof HibernateProxy)) {
/*  753 */           localObject2 = ((HibernateProxy)localObject1)
/*  754 */             .getHibernateLazyInitializer().getIdentifier();
/*      */         } else {
/*  756 */           localObject2 = PropertyUtils.getProperty(localObject1, str2);
/*      */ 
/*  758 */           if ((localObject2 != null) && ((localObject2 instanceof CodeType))) {
/*  759 */             localObject2 = ((CodeType)localObject2).getCode();
/*      */           }
/*      */         }
/*  762 */         localRowImpl.setItemValue(str1, localObject2);
/*      */       }
/*      */     }
/*      */ 
/*  766 */     return localRowImpl;
/*      */   }
/*      */ 
/*      */   public static Object getValue(Object paramObject, String paramString)
/*      */   {
/*  777 */     if (paramObject == null) {
/*  778 */       return null;
/*      */     }
/*  780 */     Object localObject = paramObject;
/*  781 */     String str = paramString;
/*      */     try {
/*  783 */       if (paramString.indexOf(".") > 0) {
/*  784 */         String[] arrayOfString = paramString.split("\\.");
/*  785 */         for (int i = 0; i < arrayOfString.length - 1; i++) {
/*  786 */           localObject = PropertyUtils.getProperty(localObject, arrayOfString[i]);
/*  787 */           if (localObject == null) {
/*  788 */             return null;
/*      */           }
/*      */         }
/*  791 */         str = arrayOfString[(arrayOfString.length - 1)];
/*      */       }
/*  793 */       return PropertyUtils.getProperty(localObject, str); } catch (Exception localException) {
/*      */     }
/*  795 */     return null;
/*      */   }
/*      */ 
/*      */   public static Set getKeySetValueIsNull(Set paramSet)
/*      */   {
/*  806 */     Iterator localIterator1 = paramSet.iterator();
/*  807 */     Map.Entry localEntry = null;
/*  808 */     String str1 = null;
/*  809 */     Object localObject1 = null;
/*  810 */     HashSet localHashSet1 = new HashSet();
/*  811 */     HashSet localHashSet2 = new HashSet();
/*      */ 
/*  813 */     while (localIterator1.hasNext()) {
/*  814 */       localEntry = (Map.Entry)localIterator1.next();
/*  815 */       str1 = (String)localEntry.getKey();
/*  816 */       localObject1 = localEntry.getValue();
/*  817 */       if (str1.indexOf(".") > 0) {
/*  818 */         localObject2 = str1.substring(0, str1.lastIndexOf("."));
/*  819 */         if (!localHashSet1.contains(localObject2))
/*      */         {
/*  822 */           if (((localObject1 instanceof JSONObject)) && 
/*  823 */             (((JSONObject)localObject1).isNullObject()))
/*  824 */             localHashSet2.add(str1);
/*      */           else {
/*  826 */             localHashSet1.add(localObject2);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  832 */     Object localObject2 = localHashSet1.iterator();
/*  833 */     while (((Iterator)localObject2).hasNext()) {
/*  834 */       String str2 = (String)((Iterator)localObject2).next();
/*  835 */       Iterator localIterator2 = localHashSet2.iterator();
/*  836 */       HashSet localHashSet3 = new HashSet();
/*  837 */       while (localIterator2.hasNext()) {
/*  838 */         String str3 = (String)localIterator2.next();
/*  839 */         String str4 = str3.substring(0, 
/*  840 */           str3.lastIndexOf("."));
/*  841 */         if (str4.endsWith(str2)) {
/*  842 */           localHashSet3.add(str3);
/*      */         }
/*      */       }
/*  845 */       if (!localHashSet3.isEmpty()) {
/*  846 */         localHashSet2.removeAll(localHashSet3);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  851 */     return localHashSet2;
/*      */   }
/*      */ 
/*      */   public static Map createMap(Row paramRow)
/*      */   {
/*  861 */     HashMap localHashMap = new HashMap();
/*  862 */     JSONObject localJSONObject = ((RowImpl)paramRow).getJSONObject();
/*  863 */     Set localSet1 = localJSONObject.entrySet();
/*  864 */     Iterator localIterator = localSet1.iterator();
/*      */ 
/*  868 */     Set localSet2 = getKeySetValueIsNull(localSet1);
/*  869 */     while (localIterator.hasNext()) {
/*  870 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  871 */       String str = (String)localEntry.getKey();
/*  872 */       Object localObject = localEntry.getValue();
/*      */ 
/*  874 */       if (!localSet2.contains(str))
/*      */       {
/*  877 */         if (!"_t".equals(str))
/*      */         {
/*  880 */           if (!"_s".equals(str))
/*      */           {
/*  883 */             if (!"_o".equals(str))
/*      */             {
/*  886 */               if (((localObject instanceof JSONObject)) && 
/*  887 */                 (((JSONObject)localObject).isNullObject())) {
/*  888 */                 localObject = null;
/*      */               }
/*      */ 
/*  891 */               if (localObject == null)
/*  892 */                 localHashMap.put(str, null);
/*      */               else
/*  894 */                 localHashMap.put(str, localObject.toString()); 
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  897 */     return localHashMap;
/*      */   }
/*      */ 
/*      */   public static boolean compareObj(Object paramObject1, Object paramObject2, String paramString)
/*      */   {
/*  911 */     if ((paramObject1 == null) && (paramObject2 == null)) {
/*  912 */       return true;
/*      */     }
/*  914 */     if ((paramObject1 == null) || (paramObject2 == null)) {
/*  915 */       return false;
/*      */     }
/*  917 */     if (!paramObject1.getClass().getName().equals(paramObject2.getClass().getName())) {
/*  918 */       return false;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  946 */       Object localObject1 = PropertyUtils.getProperty(paramObject1, paramString);
/*  947 */       Object localObject2 = PropertyUtils.getProperty(paramObject2, paramString);
/*  948 */       if ((localObject1 == null) || (localObject2 == null)) {
/*  949 */         if ((localObject1 != null) || (localObject2 != null)) {
/*  950 */           return false;
/*      */         }
/*      */       }
/*  953 */       else if (!localObject1.equals(localObject2))
/*  954 */         return false;
/*      */     }
/*      */     catch (Exception localException)
/*      */     {
/*  958 */       return false;
/*      */     }
/*  960 */     return true;
/*      */   }
/*      */ 
/*      */   public static boolean compareObj(Object paramObject1, Object paramObject2)
/*      */     throws Exception
/*      */   {
/*  973 */     Set localSet = null;
/*  974 */     if (!paramObject1.getClass().getName().equals(paramObject2.getClass().getName()))
/*  975 */       return false;
/*      */     Object localObject1;
/* 1010 */     if ((pojoProxyHandler != null) && (pojoProxyHandler.isProxy(paramObject1))) {
/* 1011 */       localSet = pojoProxyHandler.getEntityProperties(paramObject1);
/* 1012 */       localObject1 = pojoProxyHandler.getEntityProperties(paramObject2);
/* 1013 */       if (localSet.size() != ((Set)localObject1).size())
/* 1014 */         return false;
/*      */     }
/*      */     else {
/* 1017 */       localSet = getEntityProperties(paramObject1.getClass());
/*      */     }
/*      */ 
/* 1022 */     for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/* 1023 */       String str = localObject1 = (String)localIterator.next();
/* 1024 */       Object localObject2 = paramObject1;
/* 1025 */       Object localObject3 = paramObject2;
/* 1026 */       if (((String)localObject1).indexOf(".") > 0) {
/* 1027 */         String[] arrayOfString = ((String)localObject1).split("\\.");
/* 1028 */         for (int i = 0; i < arrayOfString.length - 1; i++) {
/* 1029 */           localObject2 = 
/* 1030 */             PropertyUtils.getProperty(localObject2, arrayOfString[i]);
/* 1031 */           localObject3 = 
/* 1032 */             PropertyUtils.getProperty(localObject3, arrayOfString[i]);
/* 1033 */           if ((localObject2 == null) || (localObject3 == null)) {
/* 1034 */             if ((localObject2 == null) && (localObject3 == null)) break;
/* 1035 */             return false;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1040 */         str = arrayOfString[(arrayOfString.length - 1)];
/*      */       }
/* 1042 */       if ((localObject2 != null) && (localObject3 != null)) {
/* 1043 */         Object localObject4 = PropertyUtils.getProperty(localObject2, str);
/* 1044 */         Object localObject5 = PropertyUtils.getProperty(localObject3, str);
/* 1045 */         if (localObject4 == null) {
/* 1046 */           if (localObject5 != null) {
/* 1047 */             return false;
/*      */           }
/*      */         }
/* 1050 */         else if (!localObject4.equals(localObject5)) {
/* 1051 */           return false;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1057 */     return true;
/*      */   }
/*      */ 
/*      */   public static void cancelModidiedProperties(Object paramObject1, Object paramObject2)
/*      */     throws Exception
/*      */   {
/* 1072 */     if ((paramObject1 == null) || (paramObject2 == null)) {
/* 1073 */       return;
/*      */     }
/* 1075 */     Set localSet = null;
/* 1076 */     if (!paramObject1.getClass().getName().equals(paramObject2.getClass().getName())) {
/* 1077 */       return;
/*      */     }
/* 1079 */     if ((pojoProxyHandler != null) && (pojoProxyHandler.isProxy(paramObject1)))
/* 1080 */       localSet = pojoProxyHandler.getEntityProperties(paramObject1);
/*      */     else {
/* 1082 */       localSet = getEntityProperties(paramObject1.getClass());
/*      */     }
/*      */ 
/* 1087 */     for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); )
/*      */     {
/*      */       String str1;
/* 1088 */       String str2 = str1 = (String)localIterator.next();
/* 1089 */       Object localObject1 = paramObject1;
/* 1090 */       Object localObject2 = paramObject2;
/* 1091 */       if (str1.indexOf(".") > 0) {
/* 1092 */         String[] arrayOfString = str1.split("\\.");
/* 1093 */         for (int i = 0; i < arrayOfString.length - 1; i++) {
/* 1094 */           localObject1 = 
/* 1095 */             PropertyUtils.getProperty(localObject1, arrayOfString[i]);
/* 1096 */           localObject2 = 
/* 1097 */             PropertyUtils.getProperty(localObject2, arrayOfString[i]);
/* 1098 */           if ((localObject1 == null) || (localObject2 == null)) {
/* 1099 */             if ((localObject1 == null) && (localObject2 == null))
/*      */             {
/*      */               break;
/*      */             }
/*      */ 
/* 1104 */             PropertyUtils.setProperty(paramObject2, arrayOfString[i], localObject1);
/*      */ 
/* 1106 */             break;
/*      */           }
/*      */         }
/* 1109 */         str2 = arrayOfString[(arrayOfString.length - 1)];
/*      */       }
/* 1111 */       if ((localObject1 != null) && (localObject2 != null)) {
/* 1112 */         Object localObject3 = PropertyUtils.getProperty(localObject1, str2);
/* 1113 */         Object localObject4 = PropertyUtils.getProperty(localObject2, str2);
/* 1114 */         if (localObject3 == null) {
/* 1115 */           if (localObject4 != null)
/*      */           {
/* 1117 */             PropertyUtils.setProperty(localObject2, str2, null);
/*      */           }
/*      */         }
/* 1120 */         else if (!localObject3.equals(localObject4))
/*      */         {
/* 1122 */           PropertyUtils.setProperty(localObject2, str2, localObject3);
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List getModidiedProperties(Object paramObject1, Object paramObject2, Map paramMap)
/*      */     throws Exception
/*      */   {
/* 1142 */     Set localSet = null;
/* 1143 */     if (!paramObject1.getClass().getName().equals(paramObject2.getClass().getName())) {
/* 1144 */       return null;
/*      */     }
/* 1146 */     ArrayList localArrayList = new ArrayList();
/* 1147 */     if ((pojoProxyHandler != null) && (pojoProxyHandler.isProxy(paramObject1)))
/* 1148 */       localSet = pojoProxyHandler.getEntityProperties(paramObject1);
/*      */     else {
/* 1150 */       localSet = getEntityProperties(paramObject1.getClass());
/*      */     }
/*      */ 
/* 1155 */     for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); )
/*      */     {
/*      */       String str1;
/* 1156 */       String str2 = str1 = (String)localIterator.next();
/* 1157 */       Object localObject1 = paramObject1;
/* 1158 */       Object localObject2 = paramObject2;
/* 1159 */       int i = 0;
/* 1160 */       if (str1.indexOf(".") > 0) {
/* 1161 */         String[] arrayOfString = str1.split("\\.");
/* 1162 */         for (int j = 0; j < arrayOfString.length - 1; j++) {
/* 1163 */           localObject1 = 
/* 1164 */             PropertyUtils.getProperty(localObject1, arrayOfString[j]);
/* 1165 */           localObject2 = 
/* 1166 */             PropertyUtils.getProperty(localObject2, arrayOfString[j]);
/* 1167 */           if ((localObject1 == null) || (localObject2 == null)) {
/* 1168 */             if ((localObject1 == null) && (localObject2 == null)) break;
/* 1169 */             localArrayList.add(str1);
/* 1170 */             i = 1;
/*      */ 
/* 1172 */             break;
/*      */           }
/*      */         }
/* 1175 */         str2 = arrayOfString[(arrayOfString.length - 1)];
/*      */       }
/* 1177 */       if ((localObject1 != null) && (localObject2 != null) && (i == 0)) {
/* 1178 */         Object localObject3 = PropertyUtils.getProperty(localObject1, str2);
/* 1179 */         Object localObject4 = PropertyUtils.getProperty(localObject2, str2);
/* 1180 */         if (localObject3 == null) {
/* 1181 */           if (localObject4 != null) {
/* 1182 */             localArrayList.add(str1);
/*      */           }
/*      */         }
/* 1185 */         else if (!localObject3.equals(localObject4)) {
/* 1186 */           localArrayList.add(str1);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1191 */     return localArrayList;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.PojoUtil
 * JD-Core Version:    0.6.2
 */