/*    */ package com.neusoft.unieap.techcomp.ria.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MetaDataUtil
/*    */ {
/*    */   public static List<Column> getMetaDataInfo(List paramList)
/*    */   {
/* 14 */     Object localObject = UniEAPContextHolder.getContext().getCustomProperty(
/* 15 */       "metaData");
/* 16 */     if (localObject == null) {
/* 17 */       return null;
/*    */     }
/* 19 */     return (List)((Map)localObject).get(
/* 20 */       Integer.valueOf(paramList
/* 20 */       .hashCode()));
/*    */   }
/*    */ 
/*    */   public static void addMetaDataInfo(Integer paramInteger, List<Column> paramList)
/*    */   {
/* 25 */     Object localObject = (Map)
/* 26 */       UniEAPContextHolder.getContext().getCustomProperty("metaData");
/* 27 */     if (localObject == null) {
/* 28 */       localObject = new HashMap();
/* 29 */       UniEAPContextHolder.getContext().addCustomProperty("metaData", 
/* 30 */         localObject);
/*    */     }
/* 32 */     ((Map)localObject).put(paramInteger, paramList);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.MetaDataUtil
 * JD-Core Version:    0.6.2
 */