/*      */ package com.neusoft.unieap.techcomp.ria.util;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigInteger;
/*      */ 
/*      */ public class Base64
/*      */ {
/*      */   private static final int DEFAULT_BUFFER_RESIZE_FACTOR = 2;
/*      */   private static final int DEFAULT_BUFFER_SIZE = 8192;
/*      */   static final int CHUNK_SIZE = 76;
/*   82 */   static final byte[] CHUNK_SEPARATOR = { 13, 10 };
/*      */ 
/*   92 */   private static final byte[] STANDARD_ENCODE_TABLE = { 65, 66, 67, 68, 
/*   93 */     69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 
/*   94 */     82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
/*   95 */     101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 
/*   96 */     114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 
/*   97 */     52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*  104 */   private static final byte[] URL_SAFE_ENCODE_TABLE = { 65, 66, 67, 68, 
/*  105 */     69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 
/*  106 */     82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
/*  107 */     101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 
/*  108 */     114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 
/*  109 */     52, 53, 54, 55, 56, 57, 45, 95 };
/*      */   private static final byte PAD = 61;
/*  130 */   private static final byte[] DECODE_TABLE = { -1, -1, -1, -1, -1, -1, -1, 
/*  131 */     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
/*  132 */     -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
/*  133 */     -1, -1, 62, -1, 62, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 
/*  134 */     -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 
/*  135 */     12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, 
/*  136 */     -1, 63, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 
/*  137 */     40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51 };
/*      */   private static final int MASK_6BITS = 63;
/*      */   private static final int MASK_8BITS = 255;
/*      */   private final byte[] encodeTable;
/*      */   private final int lineLength;
/*      */   private final byte[] lineSeparator;
/*      */   private final int decodeSize;
/*      */   private final int encodeSize;
/*      */   private byte[] buffer;
/*      */   private int pos;
/*      */   private int readPos;
/*      */   private int currentLinePos;
/*      */   private int modulus;
/*      */   private boolean eof;
/*      */   private int x;
/*      */ 
/*      */   public Base64()
/*      */   {
/*  239 */     this(false);
/*      */   }
/*      */ 
/*      */   public Base64(boolean paramBoolean)
/*      */   {
/*  260 */     this(76, CHUNK_SEPARATOR, paramBoolean);
/*      */   }
/*      */ 
/*      */   public Base64(int paramInt)
/*      */   {
/*  286 */     this(paramInt, CHUNK_SEPARATOR);
/*      */   }
/*      */ 
/*      */   public Base64(int paramInt, byte[] paramArrayOfByte)
/*      */   {
/*  318 */     this(paramInt, paramArrayOfByte, false);
/*      */   }
/*      */ 
/*      */   public Base64(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean)
/*      */   {
/*  354 */     if (paramArrayOfByte == null) {
/*  355 */       paramInt = 0;
/*  356 */       paramArrayOfByte = CHUNK_SEPARATOR;
/*      */     }
/*  358 */     this.lineLength = (paramInt > 0 ? paramInt / 4 * 4 : 0);
/*  359 */     this.lineSeparator = new byte[paramArrayOfByte.length];
/*  360 */     System.arraycopy(paramArrayOfByte, 0, this.lineSeparator, 0, 
/*  361 */       paramArrayOfByte.length);
/*  362 */     if (paramInt > 0)
/*  363 */       this.encodeSize = (4 + paramArrayOfByte.length);
/*      */     else {
/*  365 */       this.encodeSize = 4;
/*      */     }
/*  367 */     this.decodeSize = (this.encodeSize - 1);
/*  368 */     if (containsBase64Byte(paramArrayOfByte)) {
/*  369 */       String str = newStringUtf8(paramArrayOfByte);
/*  370 */       throw new IllegalArgumentException(
/*  371 */         "lineSeperator must not contain base64 characters: [" + str + 
/*  372 */         "]");
/*      */     }
/*  374 */     this.encodeTable = (paramBoolean ? URL_SAFE_ENCODE_TABLE : STANDARD_ENCODE_TABLE);
/*      */   }
/*      */ 
/*      */   private static String newStringUtf8(byte[] paramArrayOfByte) {
/*  378 */     if (paramArrayOfByte == null)
/*  379 */       return null;
/*      */     try
/*      */     {
/*  382 */       return new String(paramArrayOfByte, "UTF-8"); } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/*      */     }
/*  384 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean isUrlSafe()
/*      */   {
/*  395 */     return this.encodeTable == URL_SAFE_ENCODE_TABLE;
/*      */   }
/*      */ 
/*      */   boolean hasData()
/*      */   {
/*  404 */     return this.buffer != null;
/*      */   }
/*      */ 
/*      */   int avail()
/*      */   {
/*  413 */     return this.buffer != null ? this.pos - this.readPos : 0;
/*      */   }
/*      */ 
/*      */   private void resizeBuffer()
/*      */   {
/*  418 */     if (this.buffer == null) {
/*  419 */       this.buffer = new byte[8192];
/*  420 */       this.pos = 0;
/*  421 */       this.readPos = 0;
/*      */     } else {
/*  423 */       byte[] arrayOfByte = new byte[this.buffer.length * 2];
/*  424 */       System.arraycopy(this.buffer, 0, arrayOfByte, 0, this.buffer.length);
/*  425 */       this.buffer = arrayOfByte;
/*      */     }
/*      */   }
/*      */ 
/*      */   int readResults(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */   {
/*  445 */     if (this.buffer != null) {
/*  446 */       int i = Math.min(avail(), paramInt2);
/*  447 */       if (this.buffer != paramArrayOfByte) {
/*  448 */         System.arraycopy(this.buffer, this.readPos, paramArrayOfByte, paramInt1, i);
/*  449 */         this.readPos += i;
/*  450 */         if (this.readPos >= this.pos) {
/*  451 */           this.buffer = null;
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/*  456 */         this.buffer = null;
/*      */       }
/*  458 */       return i;
/*      */     }
/*  460 */     return this.eof ? -1 : 0;
/*      */   }
/*      */ 
/*      */   void setInitialBuffer(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */   {
/*  478 */     if ((paramArrayOfByte != null) && (paramArrayOfByte.length == paramInt2)) {
/*  479 */       this.buffer = paramArrayOfByte;
/*  480 */       this.pos = paramInt1;
/*  481 */       this.readPos = paramInt1;
/*      */     }
/*      */   }
/*      */ 
/*      */   void encode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */   {
/*  506 */     if (this.eof) {
/*  507 */       return;
/*      */     }
/*      */ 
/*  511 */     if (paramInt2 < 0) {
/*  512 */       this.eof = true;
/*  513 */       if ((this.buffer == null) || (this.buffer.length - this.pos < this.encodeSize)) {
/*  514 */         resizeBuffer();
/*      */       }
/*  516 */       switch (this.modulus) {
/*      */       case 1:
/*  518 */         this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 2 & 0x3F)];
/*  519 */         this.buffer[(this.pos++)] = this.encodeTable[(this.x << 4 & 0x3F)];
/*      */ 
/*  521 */         if (this.encodeTable == STANDARD_ENCODE_TABLE) {
/*  522 */           this.buffer[(this.pos++)] = 61;
/*  523 */           this.buffer[(this.pos++)] = 61;
/*      */         }
/*  525 */         break;
/*      */       case 2:
/*  528 */         this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 10 & 0x3F)];
/*  529 */         this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 4 & 0x3F)];
/*  530 */         this.buffer[(this.pos++)] = this.encodeTable[(this.x << 2 & 0x3F)];
/*      */ 
/*  532 */         if (this.encodeTable == STANDARD_ENCODE_TABLE) {
/*  533 */           this.buffer[(this.pos++)] = 61;
/*      */         }
/*      */         break;
/*      */       }
/*  537 */       if ((this.lineLength > 0) && (this.pos > 0)) {
/*  538 */         System.arraycopy(this.lineSeparator, 0, this.buffer, this.pos, 
/*  539 */           this.lineSeparator.length);
/*  540 */         this.pos += this.lineSeparator.length;
/*      */       }
/*      */     } else {
/*  543 */       for (int i = 0; i < paramInt2; i++) {
/*  544 */         if ((this.buffer == null) || (this.buffer.length - this.pos < this.encodeSize)) {
/*  545 */           resizeBuffer();
/*      */         }
/*  547 */         this.modulus = (++this.modulus % 3);
/*  548 */         int j = paramArrayOfByte[(paramInt1++)];
/*  549 */         if (j < 0) {
/*  550 */           j += 256;
/*      */         }
/*  552 */         this.x = ((this.x << 8) + j);
/*  553 */         if (this.modulus == 0) {
/*  554 */           this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 18 & 0x3F)];
/*  555 */           this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 12 & 0x3F)];
/*  556 */           this.buffer[(this.pos++)] = this.encodeTable[(this.x >> 6 & 0x3F)];
/*  557 */           this.buffer[(this.pos++)] = this.encodeTable[(this.x & 0x3F)];
/*  558 */           this.currentLinePos += 4;
/*  559 */           if ((this.lineLength > 0) && (this.lineLength <= this.currentLinePos)) {
/*  560 */             System.arraycopy(this.lineSeparator, 0, this.buffer, this.pos, 
/*  561 */               this.lineSeparator.length);
/*  562 */             this.pos += this.lineSeparator.length;
/*  563 */             this.currentLinePos = 0;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*      */   {
/*  598 */     if (this.eof) {
/*  599 */       return;
/*      */     }
/*  601 */     if (paramInt2 < 0) {
/*  602 */       this.eof = true;
/*      */     }
/*  604 */     for (int i = 0; i < paramInt2; i++) {
/*  605 */       if ((this.buffer == null) || (this.buffer.length - this.pos < this.decodeSize)) {
/*  606 */         resizeBuffer();
/*      */       }
/*  608 */       int j = paramArrayOfByte[(paramInt1++)];
/*  609 */       if (j == 61)
/*      */       {
/*  611 */         this.eof = true;
/*  612 */         break;
/*      */       }
/*  614 */       if ((j >= 0) && (j < DECODE_TABLE.length)) {
/*  615 */         int k = DECODE_TABLE[j];
/*  616 */         if (k >= 0) {
/*  617 */           this.modulus = (++this.modulus % 4);
/*  618 */           this.x = ((this.x << 6) + k);
/*  619 */           if (this.modulus == 0) {
/*  620 */             this.buffer[(this.pos++)] = ((byte)(this.x >> 16 & 0xFF));
/*  621 */             this.buffer[(this.pos++)] = ((byte)(this.x >> 8 & 0xFF));
/*  622 */             this.buffer[(this.pos++)] = ((byte)(this.x & 0xFF));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  632 */     if ((this.eof) && (this.modulus != 0)) {
/*  633 */       this.x <<= 6;
/*  634 */       switch (this.modulus) {
/*      */       case 2:
/*  636 */         this.x <<= 6;
/*  637 */         this.buffer[(this.pos++)] = ((byte)(this.x >> 16 & 0xFF));
/*  638 */         break;
/*      */       case 3:
/*  640 */         this.buffer[(this.pos++)] = ((byte)(this.x >> 16 & 0xFF));
/*  641 */         this.buffer[(this.pos++)] = ((byte)(this.x >> 8 & 0xFF));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean isBase64(byte paramByte)
/*      */   {
/*  658 */     return (paramByte == 61) || ((paramByte >= 0) && (paramByte < DECODE_TABLE.length) && 
/*  658 */       (DECODE_TABLE[paramByte] != -1));
/*      */   }
/*      */ 
/*      */   public static boolean isArrayByteBase64(byte[] paramArrayOfByte)
/*      */   {
/*  672 */     for (int i = 0; i < paramArrayOfByte.length; i++) {
/*  673 */       if ((!isBase64(paramArrayOfByte[i])) && (!isWhiteSpace(paramArrayOfByte[i]))) {
/*  674 */         return false;
/*      */       }
/*      */     }
/*  677 */     return true;
/*      */   }
/*      */ 
/*      */   private static boolean containsBase64Byte(byte[] paramArrayOfByte)
/*      */   {
/*  690 */     for (int i = 0; i < paramArrayOfByte.length; i++) {
/*  691 */       if (isBase64(paramArrayOfByte[i])) {
/*  692 */         return true;
/*      */       }
/*      */     }
/*  695 */     return false;
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64(byte[] paramArrayOfByte)
/*      */   {
/*  708 */     return encodeBase64(paramArrayOfByte, false);
/*      */   }
/*      */ 
/*      */   public static String encodeBase64String(byte[] paramArrayOfByte)
/*      */   {
/*  721 */     return newStringUtf8(encodeBase64(paramArrayOfByte, true));
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64URLSafe(byte[] paramArrayOfByte)
/*      */   {
/*  736 */     return encodeBase64(paramArrayOfByte, false, true);
/*      */   }
/*      */ 
/*      */   public static String encodeBase64URLSafeString(byte[] paramArrayOfByte)
/*      */   {
/*  750 */     return newStringUtf8(encodeBase64(paramArrayOfByte, false, true));
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64Chunked(byte[] paramArrayOfByte)
/*      */   {
/*  762 */     return encodeBase64(paramArrayOfByte, true);
/*      */   }
/*      */ 
/*      */   public Object decode(Object paramObject)
/*      */     throws IllegalArgumentException
/*      */   {
/*  779 */     if ((paramObject instanceof byte[]))
/*  780 */       return decode((byte[])paramObject);
/*  781 */     if ((paramObject instanceof String)) {
/*  782 */       return decode((String)paramObject);
/*      */     }
/*  784 */     throw new IllegalArgumentException(
/*  785 */       "Parameter supplied to Base64 decode is not a byte[] or a String");
/*      */   }
/*      */ 
/*      */   public byte[] decode(String paramString)
/*      */   {
/*  798 */     return decode(getBytesUtf8(paramString));
/*      */   }
/*      */ 
/*      */   private byte[] getBytesUtf8(String paramString) {
/*  802 */     if (paramString == null)
/*  803 */       return null;
/*      */     try
/*      */     {
/*  806 */       return paramString.getBytes("UTF-8"); } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/*      */     }
/*  808 */     return null;
/*      */   }
/*      */ 
/*      */   public byte[] decode(byte[] paramArrayOfByte)
/*      */   {
/*  820 */     reset();
/*  821 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/*  822 */       return paramArrayOfByte;
/*      */     }
/*  824 */     long l = paramArrayOfByte.length * 3 / 4;
/*  825 */     byte[] arrayOfByte1 = new byte[(int)l];
/*  826 */     setInitialBuffer(arrayOfByte1, 0, arrayOfByte1.length);
/*  827 */     decode(paramArrayOfByte, 0, paramArrayOfByte.length);
/*  828 */     decode(paramArrayOfByte, 0, -1);
/*      */ 
/*  836 */     byte[] arrayOfByte2 = new byte[this.pos];
/*  837 */     readResults(arrayOfByte2, 0, arrayOfByte2.length);
/*  838 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64(byte[] paramArrayOfByte, boolean paramBoolean)
/*      */   {
/*  856 */     return encodeBase64(paramArrayOfByte, paramBoolean, false);
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64(byte[] paramArrayOfByte, boolean paramBoolean1, boolean paramBoolean2)
/*      */   {
/*  879 */     return encodeBase64(paramArrayOfByte, paramBoolean1, paramBoolean2, 2147483647);
/*      */   }
/*      */ 
/*      */   public static byte[] encodeBase64(byte[] paramArrayOfByte, boolean paramBoolean1, boolean paramBoolean2, int paramInt)
/*      */   {
/*  904 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/*  905 */       return paramArrayOfByte;
/*      */     }
/*      */ 
/*  908 */     long l = getEncodeLength(paramArrayOfByte, 76, CHUNK_SEPARATOR);
/*  909 */     if (l > paramInt) {
/*  910 */       throw new IllegalArgumentException(
/*  911 */         "Input array too big, the output array would be bigger (" + 
/*  912 */         l + ") than the specified maxium size of " + 
/*  913 */         paramInt);
/*      */     }
/*      */ 
/*  916 */     Base64 localBase64 = paramBoolean1 ? new Base64(paramBoolean2) : new Base64(0, 
/*  917 */       CHUNK_SEPARATOR, paramBoolean2);
/*  918 */     return localBase64.encode(paramArrayOfByte);
/*      */   }
/*      */ 
/*      */   public static byte[] decodeBase64(String paramString)
/*      */   {
/*  930 */     return new Base64().decode(paramString);
/*      */   }
/*      */ 
/*      */   public static byte[] decodeBase64(byte[] paramArrayOfByte)
/*      */   {
/*  941 */     return new Base64().decode(paramArrayOfByte);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   static byte[] discardWhitespace(byte[] paramArrayOfByte)
/*      */   {
/*  954 */     byte[] arrayOfByte1 = new byte[paramArrayOfByte.length];
/*  955 */     int i = 0;
/*  956 */     for (int j = 0; j < paramArrayOfByte.length; j++) {
/*  957 */       switch (paramArrayOfByte[j]) {
/*      */       case 9:
/*      */       case 10:
/*      */       case 13:
/*      */       case 32:
/*  962 */         break;
/*      */       default:
/*  964 */         arrayOfByte1[(i++)] = paramArrayOfByte[j];
/*      */       }
/*      */     }
/*  967 */     byte[] arrayOfByte2 = new byte[i];
/*  968 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i);
/*  969 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */   private static boolean isWhiteSpace(byte paramByte)
/*      */   {
/*  980 */     switch (paramByte) {
/*      */     case 9:
/*      */     case 10:
/*      */     case 13:
/*      */     case 32:
/*  985 */       return true;
/*      */     }
/*  987 */     return false;
/*      */   }
/*      */ 
/*      */   public Object encode(Object paramObject)
/*      */     throws IllegalArgumentException
/*      */   {
/* 1006 */     if (!(paramObject instanceof byte[])) {
/* 1007 */       throw new IllegalArgumentException(
/* 1008 */         "Parameter supplied to Base64 encode is not a byte[]");
/*      */     }
/* 1010 */     return encode((byte[])paramObject);
/*      */   }
/*      */ 
/*      */   public String encodeToString(byte[] paramArrayOfByte)
/*      */   {
/* 1023 */     return newStringUtf8(encode(paramArrayOfByte));
/*      */   }
/*      */ 
/*      */   public byte[] encode(byte[] paramArrayOfByte)
/*      */   {
/* 1035 */     reset();
/* 1036 */     if ((paramArrayOfByte == null) || (paramArrayOfByte.length == 0)) {
/* 1037 */       return paramArrayOfByte;
/*      */     }
/* 1039 */     long l = getEncodeLength(paramArrayOfByte, this.lineLength, this.lineSeparator);
/* 1040 */     Object localObject = new byte[(int)l];
/* 1041 */     setInitialBuffer((byte[])localObject, 0, localObject.length);
/* 1042 */     encode(paramArrayOfByte, 0, paramArrayOfByte.length);
/* 1043 */     encode(paramArrayOfByte, 0, -1);
/*      */ 
/* 1045 */     if (this.buffer != localObject) {
/* 1046 */       readResults((byte[])localObject, 0, localObject.length);
/*      */     }
/*      */ 
/* 1050 */     if ((isUrlSafe()) && (this.pos < localObject.length)) {
/* 1051 */       byte[] arrayOfByte = new byte[this.pos];
/* 1052 */       System.arraycopy(localObject, 0, arrayOfByte, 0, this.pos);
/* 1053 */       localObject = arrayOfByte;
/*      */     }
/* 1055 */     return localObject;
/*      */   }
/*      */ 
/*      */   private static long getEncodeLength(byte[] paramArrayOfByte1, int paramInt, byte[] paramArrayOfByte2)
/*      */   {
/* 1077 */     paramInt = paramInt / 4 * 4;
/*      */ 
/* 1079 */     long l1 = paramArrayOfByte1.length * 4 / 3;
/* 1080 */     long l2 = l1 % 4L;
/* 1081 */     if (l2 != 0L) {
/* 1082 */       l1 += 4L - l2;
/*      */     }
/* 1084 */     if (paramInt > 0) {
/* 1085 */       int i = l1 % paramInt == 0L ? 1 : 0;
/* 1086 */       l1 += l1 / paramInt * paramArrayOfByte2.length;
/* 1087 */       if (i == 0) {
/* 1088 */         l1 += paramArrayOfByte2.length;
/*      */       }
/*      */     }
/* 1091 */     return l1;
/*      */   }
/*      */ 
/*      */   public static BigInteger decodeInteger(byte[] paramArrayOfByte)
/*      */   {
/* 1105 */     return new BigInteger(1, decodeBase64(paramArrayOfByte));
/*      */   }
/*      */ 
/*      */   public static byte[] encodeInteger(BigInteger paramBigInteger)
/*      */   {
/* 1120 */     if (paramBigInteger == null) {
/* 1121 */       throw new NullPointerException(
/* 1122 */         "encodeInteger called with null parameter");
/*      */     }
/* 1124 */     return encodeBase64(toIntegerBytes(paramBigInteger), false);
/*      */   }
/*      */ 
/*      */   static byte[] toIntegerBytes(BigInteger paramBigInteger)
/*      */   {
/* 1136 */     int i = paramBigInteger.bitLength();
/*      */ 
/* 1138 */     i = i + 7 >> 3 << 3;
/* 1139 */     byte[] arrayOfByte1 = paramBigInteger.toByteArray();
/*      */ 
/* 1141 */     if ((paramBigInteger.bitLength() % 8 != 0) && 
/* 1142 */       (paramBigInteger.bitLength() / 8 + 1 == i / 8)) {
/* 1143 */       return arrayOfByte1;
/*      */     }
/*      */ 
/* 1146 */     int j = 0;
/* 1147 */     int k = arrayOfByte1.length;
/*      */ 
/* 1150 */     if (paramBigInteger.bitLength() % 8 == 0) {
/* 1151 */       j = 1;
/* 1152 */       k--;
/*      */     }
/* 1154 */     int m = i / 8 - k;
/* 1155 */     byte[] arrayOfByte2 = new byte[i / 8];
/* 1156 */     System.arraycopy(arrayOfByte1, j, arrayOfByte2, m, k);
/* 1157 */     return arrayOfByte2;
/*      */   }
/*      */ 
/*      */   private void reset()
/*      */   {
/* 1164 */     this.buffer = null;
/* 1165 */     this.pos = 0;
/* 1166 */     this.readPos = 0;
/* 1167 */     this.currentLinePos = 0;
/* 1168 */     this.modulus = 0;
/* 1169 */     this.eof = false;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.Base64
 * JD-Core Version:    0.6.2
 */