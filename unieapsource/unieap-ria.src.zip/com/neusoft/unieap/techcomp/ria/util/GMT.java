/*    */ package com.neusoft.unieap.techcomp.ria.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*    */ import com.neusoft.unieap.core.i18n.GlobalService;
/*    */ import java.util.Calendar;
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ import java.util.TimeZone;
/*    */ 
/*    */ public class GMT
/*    */ {
/*    */   public static final Date fromGMTToCST(long paramLong)
/*    */   {
/*    */     try
/*    */     {
/* 22 */       TimeZone localTimeZone = GlobalService.getDefaultI18nContext().getTimeZone();
/* 23 */       Locale localLocale = GlobalService.getDefaultI18nContext().getLocale();
/* 24 */       Calendar localCalendar1 = Calendar.getInstance(localTimeZone, localLocale);
/* 25 */       localCalendar1.setTimeInMillis(paramLong);
/* 26 */       Calendar localCalendar2 = Calendar.getInstance();
/* 27 */       localCalendar2.set(1, localCalendar1.get(1));
/* 28 */       localCalendar2.set(2, localCalendar1.get(2));
/* 29 */       localCalendar2.set(5, localCalendar1.get(5));
/* 30 */       localCalendar2.set(11, localCalendar1.get(11));
/* 31 */       localCalendar2.set(12, localCalendar1.get(12));
/* 32 */       localCalendar2.set(13, localCalendar1.get(13));
/* 33 */       localCalendar2.set(14, localCalendar1.get(14));
/* 34 */       return localCalendar2.getTime();
/*    */     } catch (Exception localException) {
/* 36 */       localException.printStackTrace();
/* 37 */     }return null;
/*    */   }
/*    */ 
/*    */   public static final long fromCSTToGMT(Date paramDate)
/*    */   {
/*    */     try
/*    */     {
/* 47 */       Calendar localCalendar1 = Calendar.getInstance();
/* 48 */       localCalendar1.setTime(paramDate);
/* 49 */       TimeZone localTimeZone = GlobalService.getDefaultI18nContext().getTimeZone();
/* 50 */       Locale localLocale = GlobalService.getDefaultI18nContext().getLocale();
/* 51 */       Calendar localCalendar2 = Calendar.getInstance(localTimeZone, localLocale);
/* 52 */       localCalendar2.set(1, localCalendar1.get(1));
/* 53 */       localCalendar2.set(2, localCalendar1.get(2));
/* 54 */       localCalendar2.set(5, localCalendar1.get(5));
/* 55 */       localCalendar2.set(11, localCalendar1.get(11));
/* 56 */       localCalendar2.set(12, localCalendar1.get(12));
/* 57 */       localCalendar2.set(13, localCalendar1.get(13));
/* 58 */       localCalendar2.set(14, localCalendar1.get(14));
/* 59 */       return localCalendar2.getTime().getTime();
/*    */     } catch (Exception localException) {
/* 61 */       localException.printStackTrace();
/* 62 */     }return paramDate.getTime();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.GMT
 * JD-Core Version:    0.6.2
 */