/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.Property;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DTO2EntityUtil
/*     */ {
/*     */   public static Map<String, Object> parseDTO2Entity(Object paramObject)
/*     */   {
/*  20 */     HashMap localHashMap = new HashMap();
/*     */ 
/*  22 */     if (paramObject != null)
/*     */     {
/*  27 */       Object localObject1 = new HashMap();
/*     */       Object localObject2;
/*  29 */       for (localObject2 : paramObject.getClass().getDeclaredFields()) {
/*  30 */         if (((Field)localObject2).isAnnotationPresent(Property.class)) {
/*  31 */           Property localProperty = (Property)((Field)localObject2).getAnnotation(Property.class);
/*  32 */           String str = localProperty.clazz();
/*  33 */           localObject1 = putField((Map)localObject1, str, (Field)localObject2);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*  40 */       for (Iterator localIterator = ((Map)localObject1).keySet().iterator(); localIterator.hasNext(); ) { localObject2 = (String)localIterator.next();
/*  41 */         List localList = (List)((Map)localObject1).get(localObject2);
/*  42 */         ??? = null;
/*     */         try {
/*  44 */           ??? = getEntityObject(paramObject, (String)localObject2, localList);
/*  45 */           localHashMap.put(???.getClass().getSimpleName(), ???);
/*     */         } catch (Exception localException) {
/*  47 */           localException.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  52 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private static Object getEntityObject(Object paramObject, String paramString, List<Field> paramList)
/*     */     throws Exception
/*     */   {
/*  62 */     return initEntityObject(paramObject, paramString, "", paramList);
/*     */   }
/*     */ 
/*     */   private static Object initEntityObject(Object paramObject, String paramString1, String paramString2, List<Field> paramList)
/*     */     throws Exception
/*     */   {
/*  73 */     Object localObject1 = Class.forName(paramString1).newInstance();
/*     */ 
/*  75 */     Map localMap = toFieldMap(paramString2, paramList);
/*     */ 
/*  77 */     for (Field localField1 : localObject1.getClass().getDeclaredFields()) {
/*  78 */       List localList = (List)localMap.get(localField1.getName());
/*     */ 
/*  80 */       if ((localList != null) && (localList.size() > 0)) {
/*  81 */         Object localObject2 = null;
/*     */ 
/*  83 */         if (!isCascadeField(paramString2, (Field)localList.get(0)))
/*     */         {
/*  85 */           Field localField2 = (Field)localList.get(0);
/*     */ 
/*  90 */           if (!localField2.isAccessible())
/*  91 */             localField2.setAccessible(true);
/*     */           try
/*     */           {
/*  94 */             localObject2 = localField2.get(paramObject);
/*     */           } catch (Exception localException2) {
/*  96 */             localException2.printStackTrace();
/*  97 */             continue;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 102 */           localObject2 = initEntityObject(paramObject, localField1.getType().getName(), localField1.getName() + ".", localList);
/*     */         }
/*     */ 
/* 108 */         if (!localField1.isAccessible())
/* 109 */           localField1.setAccessible(true);
/*     */         try
/*     */         {
/* 112 */           localField1.set(localObject1, localObject2);
/*     */         } catch (Exception localException1) {
/* 114 */           localException1.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 119 */     return localObject1;
/*     */   }
/*     */ 
/*     */   private static Map<String, List<Field>> toFieldMap(String paramString, List<Field> paramList)
/*     */   {
/* 130 */     Object localObject = new HashMap();
/*     */ 
/* 132 */     for (Field localField : paramList) {
/* 133 */       Property localProperty = (Property)localField.getAnnotation(Property.class);
/* 134 */       String str1 = getBareName(paramString, localProperty.name());
/* 135 */       String str2 = str1;
/* 136 */       if (str1.contains(".")) {
/* 137 */         str2 = str1.split("\\.")[0];
/*     */       }
/* 139 */       localObject = putField((Map)localObject, str2, localField);
/*     */     }
/*     */ 
/* 142 */     return localObject;
/*     */   }
/*     */ 
/*     */   private static String getBareName(String paramString1, String paramString2)
/*     */   {
/* 151 */     String str = paramString2;
/*     */ 
/* 153 */     if (paramString2.startsWith(paramString1)) {
/* 154 */       str = paramString2.substring(paramString1.length(), paramString2.length());
/*     */     }
/*     */ 
/* 157 */     return str;
/*     */   }
/*     */ 
/*     */   private static Map<String, List<Field>> putField(Map<String, List<Field>> paramMap, String paramString, Field paramField)
/*     */   {
/* 168 */     Map<String, List<Field>> localMap = paramMap;
/*     */ 
/* 170 */     Object localObject = (List)paramMap.get(paramString);
/* 171 */     if (localObject == null) {
/* 172 */       localObject = new LinkedList();
/* 173 */       paramMap.put(paramString, localObject);
/*     */     }
/*     */ 
/* 176 */     ((List)localObject).add(paramField);
/*     */ 
/* 178 */     return localMap;
/*     */   }
/*     */ 
/*     */   private static boolean isCascadeField(String paramString, Field paramField)
/*     */   {
/* 187 */     boolean bool = false;
/*     */ 
/* 189 */     Property localProperty = (Property)paramField.getAnnotation(Property.class);
/* 190 */     String str = getBareName(paramString, localProperty.name());
/* 191 */     bool = str.contains(".");
/*     */ 
/* 193 */     return bool;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.DTO2EntityUtil
 * JD-Core Version:    0.6.2
 */