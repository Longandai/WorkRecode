package com.neusoft.unieap.techcomp.ria.util.proxy;

import java.util.Set;

public abstract interface ProxyObjHandler
{
  public abstract String getIdentifierName(Object paramObject);

  public abstract boolean isProxy(Object paramObject);

  public abstract Set getEntityProperties(Object paramObject);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.proxy.ProxyObjHandler
 * JD-Core Version:    0.6.2
 */