/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.StringWriter;
/*     */ 
/*     */ public class HSUtil
/*     */ {
/*  67 */   private static final char[] vowelList = { 'A', 'E', 'I', 'O', 'U' };
/*     */ 
/*     */   public static String getStringFromStream(InputStream paramInputStream)
/*     */     throws IOException
/*     */   {
/*  20 */     if (paramInputStream == null)
/*  21 */       return null;
/*     */     try {
/*  23 */       InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream);
/*  24 */       char[] arrayOfChar = new char[1024];
/*  25 */       StringWriter localStringWriter = new StringWriter();
/*     */       int i;
/*  27 */       while ((i = localInputStreamReader.read(arrayOfChar)) != -1) {
/*  28 */         localStringWriter.write(arrayOfChar, 0, i);
/*     */       }
/*  30 */       return localStringWriter.toString();
/*     */     } finally {
/*  32 */       if (paramInputStream != null)
/*  33 */         paramInputStream.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String firstLetterUpper(String paramString) {
/*  38 */     if (paramString == null)
/*  39 */       return null;
/*  40 */     if (paramString.length() == 0) {
/*  41 */       return paramString;
/*     */     }
/*  43 */     return paramString.substring(0, 1).toUpperCase() + paramString.substring(1, paramString.length());
/*     */   }
/*     */ 
/*     */   public static String firstLetterLower(String paramString)
/*     */   {
/*  48 */     if (paramString == null)
/*  49 */       return null;
/*  50 */     if (paramString.length() == 0) {
/*  51 */       return paramString;
/*     */     }
/*  53 */     return paramString.substring(0, 1).toLowerCase() + paramString.substring(1, paramString.length());
/*     */   }
/*     */ 
/*     */   public static String getClassPart(String paramString)
/*     */   {
/*  58 */     if (paramString == null)
/*  59 */       return null;
/*  60 */     int i = paramString.lastIndexOf(".");
/*  61 */     if (i == -1) {
/*  62 */       return paramString;
/*     */     }
/*  64 */     return paramString.substring(i + 1, paramString.length());
/*     */   }
/*     */ 
/*     */   public static String getJavaNameCap(String paramString)
/*     */   {
/*  70 */     if ((paramString.indexOf("_") < 0) && (paramString.indexOf("-") < 0)) {
/*  71 */       return firstLetterUpper(paramString);
/*     */     }
/*  73 */     StringBuffer localStringBuffer = new StringBuffer();
/*  74 */     int i = 1;
/*  75 */     char[] arrayOfChar = paramString.toCharArray();
/*  76 */     for (int j = 0; j < arrayOfChar.length; j++)
/*  77 */       if ((arrayOfChar[j] == '_') || (arrayOfChar[j] == '-')) {
/*  78 */         i = 1;
/*  79 */       } else if (i != 0) {
/*  80 */         localStringBuffer.append(Character.toUpperCase(arrayOfChar[j]));
/*  81 */         i = 0;
/*     */       } else {
/*  83 */         localStringBuffer.append(Character.toLowerCase(arrayOfChar[j]));
/*     */       }
/*  85 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getJavaName(String paramString)
/*     */   {
/*  90 */     if (paramString == null)
/*  91 */       return null;
/*  92 */     if (paramString.toUpperCase().equals(paramString)) {
/*  93 */       paramString = paramString.toLowerCase();
/*     */     }
/*  95 */     return firstLetterLower(getJavaNameCap(paramString));
/*     */   }
/*     */ 
/*     */   public static String getPluralName(String paramString) {
/*  99 */     if (paramString == null)
/* 100 */       return null;
/* 101 */     if (paramString.endsWith("s")) {
/* 102 */       return paramString + "es";
/*     */     }
/* 104 */     return paramString + "s";
/*     */   }
/*     */ 
/*     */   public static String getStaticName(String paramString) {
/* 108 */     int i = 0;
/* 109 */     if (paramString == null)
/* 110 */       return null;
/* 111 */     if (paramString.toUpperCase().equals(paramString)) {
/* 112 */       return paramString;
/*     */     }
/* 114 */     StringBuffer localStringBuffer = new StringBuffer();
/* 115 */     for (int j = 0; j < paramString.toCharArray().length; j++) {
/* 116 */       char c = paramString.toCharArray()[j];
/* 117 */       if (Character.isLetterOrDigit(c)) {
/* 118 */         if ((c == ' ') || (c == '-')) {
/* 119 */           localStringBuffer.append("_");
/* 120 */           i = 1;
/* 121 */         } else if ((Character.isUpperCase(c)) || (j == 0)) {
/* 122 */           if ((localStringBuffer.length() > 0) && (i == 0))
/* 123 */             localStringBuffer.append("_");
/* 124 */           localStringBuffer.append(Character.toUpperCase(c));
/* 125 */           i = 0;
/*     */         } else {
/* 127 */           localStringBuffer.append(Character.toUpperCase(c));
/* 128 */           i = 0;
/*     */         }
/* 130 */       } else if (((Character.isWhitespace(c)) || (c == '.') || (c == '-') || 
/* 131 */         (c == '_')) && 
/* 132 */         (i == 0)) {
/* 133 */         localStringBuffer.append("_");
/* 134 */         i = 1;
/*     */       }
/*     */     }
/*     */ 
/* 138 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String stringReplace(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 154 */     StringBuffer localStringBuffer1 = new StringBuffer(paramString1);
/* 155 */     StringBuffer localStringBuffer2 = new StringBuffer(paramString1.length() + 50);
/* 156 */     char[] arrayOfChar1 = paramString2.toCharArray();
/* 157 */     char[] arrayOfChar2 = paramString3.toCharArray();
/* 158 */     char[] arrayOfChar3 = new char[arrayOfChar1.length];
/*     */ 
/* 160 */     for (int i = 0; i < localStringBuffer1.length(); i++)
/*     */     {
/* 162 */       if (i + arrayOfChar3.length > localStringBuffer1.length()) {
/* 163 */         localStringBuffer2.append(localStringBuffer1.charAt(i));
/*     */       } else {
/* 165 */         localStringBuffer1.getChars(i, i + arrayOfChar3.length, arrayOfChar3, 0);
/* 166 */         if (aEquals(arrayOfChar3, arrayOfChar1)) {
/* 167 */           localStringBuffer2.append(arrayOfChar2);
/* 168 */           i = i + arrayOfChar3.length - 1;
/*     */         } else {
/* 170 */           localStringBuffer2.append(localStringBuffer1.charAt(i));
/*     */         }
/*     */       }
/*     */     }
/* 174 */     return localStringBuffer2.toString();
/*     */   }
/*     */ 
/*     */   private static boolean aEquals(char[] paramArrayOfChar1, char[] paramArrayOfChar2) {
/* 178 */     if (paramArrayOfChar1.length != paramArrayOfChar2.length) {
/* 179 */       return false;
/*     */     }
/* 181 */     for (int i = 0; i < paramArrayOfChar1.length; i++) {
/* 182 */       if (paramArrayOfChar1[i] != paramArrayOfChar2[i]) {
/* 183 */         return false;
/*     */       }
/*     */     }
/* 186 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.HSUtil
 * JD-Core Version:    0.6.2
 */