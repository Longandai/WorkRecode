/*      */ package com.neusoft.unieap.techcomp.ria.util;
/*      */ 
/*      */ import com.neusoft.unieap.core.exception.UniEAPSystemException;
/*      */ import com.neusoft.unieap.techcomp.ria.context.util.ContextUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONObject;
/*      */ import org.apache.commons.beanutils.PropertyUtils;
/*      */ import org.hibernate.EntityMode;
/*      */ import org.hibernate.collection.AbstractPersistentCollection;
/*      */ import org.hibernate.engine.EntityEntry;
/*      */ import org.hibernate.engine.PersistenceContext;
/*      */ import org.hibernate.engine.Status;
/*      */ import org.hibernate.impl.SessionImpl;
/*      */ import org.hibernate.intercept.LazyPropertyInitializer;
/*      */ import org.hibernate.persister.entity.EntityPersister;
/*      */ import org.hibernate.tuple.StandardProperty;
/*      */ import org.hibernate.tuple.entity.EntityMetamodel;
/*      */ import org.hibernate.tuple.entity.EntityTuplizer;
/*      */ import org.hibernate.type.CollectionType;
/*      */ import org.hibernate.type.ComponentType;
/*      */ import org.hibernate.type.Type;
/*      */ import org.hibernate.util.IdentityMap;
/*      */ import org.springframework.beans.BeanUtils;
/*      */ 
/*      */ public class PojoContextUtil
/*      */ {
/*   45 */   private static final Map pojoEntiyProperty = new ConcurrentHashMap();
/*      */ 
/*      */   public static List createPojoList() {
/*   48 */     com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = new com.neusoft.unieap.techcomp.ria.context.util.ArrayList();
/*   49 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   public static Object getOldValue(Object paramObject, String paramString)
/*      */   {
/*   70 */     Map localMap1 = ContextUtil.getPojoContext();
/*   71 */     if (localMap1.containsKey(paramObject)) {
/*   72 */       Map localMap2 = (Map)localMap1.get(paramObject);
/*   73 */       Object localObject = localMap2.get("origin_data_info");
/*   74 */       if ((localObject instanceof EntityEntry))
/*      */       {
/*   76 */         HashMap localHashMap1 = new HashMap();
/*   77 */         HashMap localHashMap2 = new HashMap();
/*   78 */         EntityEntry localEntityEntry = (EntityEntry)localObject;
/*      */ 
/*   80 */         generatePropertiesWithEntityEntry(localEntityEntry, paramObject, 
/*   82 */           (SessionImpl)localMap2
/*   82 */           .get("origin_data_session"), 
/*   83 */           localMap1, localHashMap1, localHashMap2, 
/*   84 */           new HashMap(), "");
/*   85 */         if (localHashMap1.containsKey(paramString))
/*   86 */           return localHashMap1.get(paramString);
/*      */       }
/*      */       else
/*      */       {
/*   90 */         return PojoUtil.getValue(localObject, paramString);
/*      */       }
/*      */     }
/*   93 */     return null;
/*      */   }
/*      */ 
/*      */   private static void generatePropertiesWithEntityEntry(EntityEntry paramEntityEntry, Object paramObject, SessionImpl paramSessionImpl, Map paramMap1, Map<String, Object> paramMap2, Map<String, Object> paramMap3, Map paramMap4, String paramString)
/*      */   {
/*  113 */     EntityPersister localEntityPersister = paramEntityEntry.getPersister();
/*      */ 
/*  116 */     paramMap4.put(paramObject, paramObject);
/*      */ 
/*  118 */     String str1 = paramEntityEntry.getPersister().getIdentifierPropertyName();
/*  119 */     String str2 = str1;
/*  120 */     if (paramString.length() > 0) {
/*  121 */       str2 = paramString + "." + str1;
/*      */     }
/*  123 */     paramMap2.put(str2, paramEntityEntry.getId());
/*      */     try {
/*  125 */       paramMap3.put(str2, PropertyUtils.getProperty(paramObject, 
/*  126 */         str1));
/*      */     } catch (IllegalAccessException localIllegalAccessException) {
/*  128 */       localIllegalAccessException.printStackTrace();
/*      */     } catch (InvocationTargetException localInvocationTargetException) {
/*  130 */       localInvocationTargetException.printStackTrace();
/*      */     } catch (NoSuchMethodException localNoSuchMethodException) {
/*  132 */       localNoSuchMethodException.printStackTrace();
/*      */     }
/*  134 */     generateProperties(paramEntityEntry.getLoadedState(), localEntityPersister.getPropertyValues(
/*  135 */       paramObject, paramSessionImpl.getEntityMode()), localEntityPersister.getEntityMetamodel()
/*  136 */       .getProperties(), paramSessionImpl, paramMap2, 
/*  137 */       paramMap3, paramMap1, paramMap4, paramString);
/*      */ 
/*  139 */     paramMap4.remove(paramObject);
/*      */   }
/*      */ 
/*      */   private static void generateProperties(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, StandardProperty[] paramArrayOfStandardProperty, SessionImpl paramSessionImpl, Map<String, Object> paramMap1, Map<String, Object> paramMap2, Map paramMap3, Map paramMap4, String paramString)
/*      */   {
/*  159 */     int i = paramArrayOfStandardProperty.length;
/*  160 */     for (int j = 0; j < i; j++) {
/*  161 */       StandardProperty localStandardProperty = paramArrayOfStandardProperty[j];
/*  162 */       String str1 = localStandardProperty.getName();
/*  163 */       if (paramString.length() > 0) {
/*  164 */         str1 = paramString + "." + str1;
/*      */       }
/*  166 */       Type localType = localStandardProperty.getType();
/*  167 */       Object localObject1 = paramArrayOfObject1[j];
/*  168 */       Object localObject2 = paramArrayOfObject2[j];
/*      */       Object localObject3;
/*  169 */       if (localType.isComponentType())
/*      */       {
/*  171 */         localObject3 = paramSessionImpl.getEntityMode();
/*  172 */         String[] arrayOfString = ((ComponentType)localType)
/*  173 */           .getPropertyNames();
/*  174 */         Object localObject4 = (Object[])null;
/*  175 */         Object localObject5 = (Object[])null;
/*  176 */         if (localObject1 != null)
/*  177 */           localObject4 = ((ComponentType)localType).getPropertyValues(localObject1, 
/*  178 */             (EntityMode)localObject3);
/*      */         else {
/*  180 */           localObject4 = new String[arrayOfString.length];
/*      */         }
/*  182 */         if (localObject2 != null)
/*  183 */           localObject5 = ((ComponentType)localType).getPropertyValues(localObject2, 
/*  184 */             (EntityMode)localObject3);
/*      */         else {
/*  186 */           localObject5 = new String[arrayOfString.length];
/*      */         }
/*  188 */         for (int k = 0; k < localObject4.length; k++) {
/*  189 */           String str2 = arrayOfString[k];
/*  190 */           if (str1.length() > 0) {
/*  191 */             str2 = str1 + "." + str2;
/*      */           }
/*  193 */           paramMap2.put(str2, localObject5[k]);
/*  194 */           paramMap1.put(str2, localObject4[k]);
/*      */         }
/*      */       } else {
/*  197 */         if ((!localType.isCollectionType()) || (isInstrumented(localObject2)))
/*      */         {
/*  199 */           if ((localType.isAssociationType()) && (!isInstrumented(localObject1))) {
/*  200 */             if (paramMap4.containsKey(localObject1))
/*      */             {
/*      */               continue;
/*      */             }
/*  204 */             localObject3 = (Map)paramMap3.get(localObject1);
/*  205 */             generatePropertiesWithEntityEntry(
/*  207 */               (EntityEntry)((Map)localObject3)
/*  207 */               .get("origin_data_info"), localObject1, 
/*  209 */               (SessionImpl)((Map)localObject3)
/*  209 */               .get("origin_data_session"), 
/*  210 */               paramMap3, paramMap1, paramMap2, 
/*  211 */               paramMap4, str1);
/*      */           }
/*      */         }
/*  213 */         paramMap2.put(str1, localObject2);
/*  214 */         paramMap1.put(str1, localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelAllPojoDeleted(List paramList)
/*      */   {
/*  226 */     if (paramList == null)
/*      */       return;
/*      */     Object localObject1;
/*      */     Object localObject2;
/*  229 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  230 */       localObject1 = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList;
/*  231 */       localObject2 = ((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localObject1).getDeletedObjects();
/*  232 */       if (((List)localObject2).size() > 0) {
/*  233 */         Iterator localIterator = ((List)localObject2).iterator();
/*  234 */         while (localIterator.hasNext()) {
/*  235 */           Object localObject3 = localIterator.next();
/*  236 */           localIterator.remove();
/*  237 */           ((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localObject1)._add(localObject3);
/*      */         }
/*      */       }
/*      */     } else {
/*  241 */       for (localObject2 = paramList.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject1 = ((Iterator)localObject2).next();
/*  242 */         cancelDeleted(localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelDeleted(Object paramObject)
/*      */   {
/*  254 */     Map localMap1 = ContextUtil.getPojoContext();
/*  255 */     if (localMap1.containsKey(paramObject)) {
/*  256 */       Map localMap2 = (Map)localMap1.get(paramObject);
/*  257 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/*  258 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/*  258 */         .get("origin_data_context");
/*  259 */       if (localArrayList == null) {
/*  260 */         return;
/*      */       }
/*  262 */       List localList = localArrayList.getDeletedObjects();
/*  263 */       if (localList.size() > 0) {
/*  264 */         Iterator localIterator = localList.iterator();
/*  265 */         while (localIterator.hasNext()) {
/*  266 */           Object localObject = localIterator.next();
/*  267 */           if (localObject == paramObject) {
/*  268 */             localIterator.remove();
/*      */ 
/*  270 */             localArrayList._add(localObject);
/*  271 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelAllPojoInserted(List paramList)
/*      */   {
/*  285 */     if (paramList == null)
/*      */       return;
/*      */     Object localObject1;
/*      */     Object localObject2;
/*  288 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  289 */       localObject1 = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList;
/*  290 */       localObject2 = ((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localObject1).getNewObjects();
/*  291 */       Map localMap = ContextUtil.getPojoContext();
/*  292 */       if (((List)localObject2).size() > 0) {
/*  293 */         Iterator localIterator = ((List)localObject2).iterator();
/*  294 */         while (localIterator.hasNext()) {
/*  295 */           Object localObject3 = localIterator.next();
/*      */ 
/*  297 */           Object localObject4 = localMap.get(localObject3);
/*  298 */           if ((localObject4 instanceof Map)) {
/*  299 */             ((HashMap)localObject4)
/*  300 */               .remove("origin_data_context");
/*  301 */             ((HashMap)localObject4)
/*  302 */               .remove("origin_data_dataStore");
/*  303 */             ((HashMap)localObject4)
/*  304 */               .remove("origin_data_dataStore_index");
/*      */           }
/*      */ 
/*  307 */           localIterator.remove();
/*      */         }
/*      */       }
/*      */     } else {
/*  311 */       for (localObject2 = paramList.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject1 = ((Iterator)localObject2).next();
/*  312 */         cancelInserted(localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelInserted(Object paramObject)
/*      */   {
/*  324 */     Map localMap1 = ContextUtil.getPojoContext();
/*  325 */     if (localMap1.containsKey(paramObject)) {
/*  326 */       Map localMap2 = (Map)localMap1.get(paramObject);
/*  327 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/*  328 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/*  328 */         .get("origin_data_context");
/*  329 */       if (localArrayList == null) {
/*  330 */         return;
/*      */       }
/*  332 */       List localList = localArrayList.getNewObjects();
/*  333 */       if (localList.size() > 0) {
/*  334 */         Iterator localIterator = localList.iterator();
/*  335 */         while (localIterator.hasNext()) {
/*  336 */           Object localObject = localIterator.next();
/*  337 */           if (localObject == paramObject) {
/*  338 */             localIterator.remove();
/*  339 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelAllModifys(List paramList)
/*      */   {
/*  355 */     if (paramList == null)
/*      */       return;
/*      */     Object localObject1;
/*      */     Object localObject2;
/*  358 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  359 */       localObject1 = getModifiedPojoList(paramList);
/*      */       Object localObject3;
/*  360 */       if (((List)localObject1).size() > 0) {
/*  361 */         for (localObject3 = ((List)localObject1).iterator(); ((Iterator)localObject3).hasNext(); ) { localObject2 = ((Iterator)localObject3).next();
/*  362 */           cancelModify(localObject2);
/*      */         }
/*      */       }
/*  365 */       localObject2 = getDeletedPojoList(paramList);
/*  366 */       if (((List)localObject2).size() > 0)
/*  367 */         for (Iterator localIterator = ((List)localObject2).iterator(); localIterator.hasNext(); ) { localObject3 = localIterator.next();
/*  368 */           cancelModify(localObject3); }
/*      */     }
/*      */     else
/*      */     {
/*  372 */       for (localObject2 = paramList.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject1 = ((Iterator)localObject2).next();
/*  373 */         cancelModify(localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void cancelModify(Object paramObject)
/*      */   {
/*  385 */     Map localMap1 = ContextUtil.getPojoContext();
/*  386 */     if (localMap1.containsKey(paramObject)) {
/*  387 */       Map localMap2 = (Map)localMap1.get(paramObject);
/*  388 */       Object localObject = localMap2.get("origin_data_info");
/*  389 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/*  390 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/*  390 */         .get("origin_data_context");
/*  391 */       if ((localArrayList != null) && 
/*  392 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject)))
/*      */       {
/*  394 */         if ((localObject instanceof EntityEntry)) {
/*  395 */           SessionImpl localSessionImpl = 
/*  396 */             (SessionImpl)localMap2
/*  396 */             .get("origin_data_session");
/*  397 */           cancelModifyWithEntityEntry(localSessionImpl, localMap1, 
/*  398 */             (EntityEntry)localObject, paramObject, new HashMap());
/*      */         }
/*      */         else {
/*      */           try {
/*  402 */             PojoUtil.cancelModidiedProperties(localObject, paramObject);
/*      */           } catch (Exception localException) {
/*  404 */             localException.printStackTrace();
/*  405 */             Throwable localThrowable = localException.getCause();
/*  406 */             throw new UniEAPSystemException("", localThrowable, null);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void cancelModifyWithEntityEntry(SessionImpl paramSessionImpl, Map paramMap, Object paramObject1, Object paramObject2, Map<Object, Object> paramMap1)
/*      */   {
/*  426 */     if ((paramObject1 != null) && ((paramObject1 instanceof EntityEntry))) {
/*  427 */       EntityEntry localEntityEntry = (EntityEntry)paramObject1;
/*  428 */       EntityPersister localEntityPersister = localEntityEntry.getPersister();
/*      */ 
/*  431 */       paramMap1.put(paramObject2, paramObject2);
/*  432 */       EntityMode localEntityMode = paramSessionImpl.getEntityMode();
/*  433 */       EntityMetamodel localEntityMetamodel = localEntityPersister.getEntityMetamodel();
/*  434 */       cancelModify(localEntityEntry.getLoadedState(), localEntityPersister.getPropertyValues(
/*  435 */         paramObject2, localEntityMode), localEntityMetamodel.getProperties(), 
/*  436 */         paramSessionImpl, paramMap, paramMap1, localEntityMetamodel, 
/*  437 */         localEntityMode, paramObject2);
/*      */ 
/*  439 */       paramMap1.remove(paramObject2);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void cancelModify(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, StandardProperty[] paramArrayOfStandardProperty, SessionImpl paramSessionImpl, Map paramMap, Map<Object, Object> paramMap1, EntityMetamodel paramEntityMetamodel, EntityMode paramEntityMode, Object paramObject)
/*      */   {
/*  449 */     int i = 1;
/*  450 */     int j = paramArrayOfStandardProperty.length;
/*  451 */     for (int k = 0; k < j; k++) {
/*  452 */       StandardProperty localStandardProperty = paramArrayOfStandardProperty[k];
/*  453 */       Type localType = localStandardProperty.getType();
/*  454 */       Object localObject1 = paramArrayOfObject1[k];
/*  455 */       Object localObject2 = paramArrayOfObject2[k];
/*  456 */       i = (localObject2 != LazyPropertyInitializer.UNFETCHED_PROPERTY) && 
/*  457 */         (localStandardProperty.isDirtyCheckable(false)) && (
/*  457 */         localType
/*  458 */         .isDirty(localObject1, localObject2, paramSessionImpl)) ? 0 : 1;
/*      */       Object localObject3;
/*  459 */       if ((localType.isCollectionType()) && (i != 0) && (!isInstrumented(localObject2)))
/*      */       {
/*  461 */         localObject3 = ((CollectionType)localType)
/*  462 */           .getElementsIterator(localObject2, paramSessionImpl);
/*      */ 
/*  464 */         int m = 1;
/*      */         Object localObject4;
/*  465 */         while (((Iterator)localObject3).hasNext()) {
/*  466 */           localObject4 = ((Iterator)localObject3).next();
/*      */ 
/*  468 */           if (paramMap1.containsKey(localObject4)) {
/*  469 */             m = 0;
/*  470 */             break;
/*      */           }
/*      */         }
/*      */ 
/*  474 */         if (m != 0) {
/*  475 */           localObject3 = ((CollectionType)localType)
/*  476 */             .getElementsIterator(localObject2, paramSessionImpl);
/*  477 */           while (((Iterator)localObject3).hasNext()) {
/*  478 */             localObject4 = ((Iterator)localObject3).next();
/*      */ 
/*  480 */             Map localMap = (Map)paramMap.get(localObject4);
/*  481 */             if (!compareObjWithEntityEntry(
/*  483 */               (SessionImpl)localMap
/*  483 */               .get("origin_data_session"), 
/*  484 */               paramMap, localMap
/*  485 */               .get("origin_data_info"), localObject4, 
/*  486 */               paramMap1)) {
/*  487 */               cancelModifyWithEntityEntry(
/*  489 */                 (SessionImpl)localMap
/*  489 */                 .get("origin_data_session"), 
/*  490 */                 paramMap, localMap
/*  491 */                 .get("origin_data_info"), 
/*  492 */                 localObject4, paramMap1);
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*  498 */       else if ((localType.isAssociationType()) && (i != 0) && (!isInstrumented(localObject1))) {
/*  499 */         if (!paramMap1.containsKey(localObject1))
/*      */         {
/*  503 */           localObject3 = (Map)paramMap.get(localObject1);
/*  504 */           if (!compareObjWithEntityEntry(
/*  505 */             (SessionImpl)((Map)localObject3)
/*  505 */             .get("origin_data_session"), paramMap, 
/*  506 */             ((Map)localObject3).get("origin_data_info"), localObject1, 
/*  507 */             paramMap1))
/*  508 */             cancelModifyWithEntityEntry(
/*  509 */               (SessionImpl)((Map)localObject3)
/*  509 */               .get("origin_data_session"), paramMap, 
/*  510 */               ((Map)localObject3).get("origin_data_info"), 
/*  511 */               localObject1, paramMap1);
/*      */         }
/*      */       }
/*  514 */       else if (i == 0)
/*      */       {
/*  517 */         paramEntityMetamodel.getTuplizer(paramEntityMode).setPropertyValue(
/*  518 */           paramObject, k, localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public static boolean hasDeletePojos(List paramList)
/*      */   {
/*  530 */     List localList = getDeletedPojoList(paramList);
/*  531 */     boolean bool = false;
/*  532 */     if (localList.size() > 0) {
/*  533 */       bool = true;
/*      */     }
/*  535 */     return bool;
/*      */   }
/*      */ 
/*      */   public static List getNewPOJOList(List paramList)
/*      */   {
/*  545 */     java.util.ArrayList localArrayList = new java.util.ArrayList();
/*  546 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  547 */       localArrayList
/*  548 */         .addAll(((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList)
/*  549 */         .getNewObjects());
/*      */     }
/*  551 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   public static List getModifiedPojoList(List paramList)
/*      */   {
/*  563 */     Map localMap = ContextUtil.getPojoContext();
/*  564 */     java.util.ArrayList localArrayList = new java.util.ArrayList();
/*  565 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  566 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList1 = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList;
/*  567 */       if ((localMap != null) && (localMap.size() > 0)) {
/*  568 */         HashMap localHashMap = new HashMap();
/*  569 */         for (int i = 0; i < localArrayList1.size(); i++) {
/*  570 */           Object localObject1 = localArrayList1.get(i);
/*      */ 
/*  572 */           if (!localArrayList1.contains(localArrayList1.getNewObjects(), localObject1)) {
/*  573 */             Object localObject2 = localMap.get(localObject1);
/*  574 */             if ((localObject2 instanceof Map)) {
/*  575 */               Object localObject3 = ((Map)localObject2)
/*  576 */                 .get("origin_data_info");
/*  577 */               if ((localObject3 != null) && (localObject1 != null)) {
/*      */                 try
/*      */                 {
/*  580 */                   if ((localObject3 instanceof EntityEntry)) {
/*  581 */                     SessionImpl localSessionImpl = 
/*  582 */                       (SessionImpl)((Map)localObject2)
/*  582 */                       .get("origin_data_session");
/*  583 */                     if (!compareObjWithEntityEntry(localSessionImpl, 
/*  584 */                       localMap, localObject3, localObject1, 
/*  585 */                       localHashMap)) {
/*  586 */                       localArrayList.add(localObject1);
/*      */                     }
/*      */ 
/*      */                   }
/*  591 */                   else if (!PojoUtil.compareObj(localObject3, localObject1)) {
/*  592 */                     localArrayList.add(localObject1);
/*      */                   }
/*      */                 }
/*      */                 catch (Exception localException) {
/*  596 */                   localException.printStackTrace();
/*  597 */                   Throwable localThrowable = localException.getCause();
/*  598 */                   throw new UniEAPSystemException("", localThrowable, 
/*  599 */                     null);
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  607 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   private static boolean compareObj(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, StandardProperty[] paramArrayOfStandardProperty, SessionImpl paramSessionImpl, Map paramMap, Map<Object, Object> paramMap1)
/*      */   {
/*  626 */     boolean bool = true;
/*  627 */     int i = paramArrayOfStandardProperty.length;
/*  628 */     for (int j = 0; j < i; j++) {
/*  629 */       StandardProperty localStandardProperty = paramArrayOfStandardProperty[j];
/*  630 */       Type localType = localStandardProperty.getType();
/*  631 */       Object localObject1 = paramArrayOfObject1[j];
/*  632 */       Object localObject2 = paramArrayOfObject2[j];
/*  633 */       bool = (localObject2 == LazyPropertyInitializer.UNFETCHED_PROPERTY) || 
/*  634 */         (!localStandardProperty.isDirtyCheckable(false)) || (!
/*  634 */         localType
/*  635 */         .isDirty(localObject1, localObject2, paramSessionImpl));
/*      */       Object localObject3;
/*  636 */       if ((localType.isCollectionType()) && (bool) && (!isInstrumented(localObject2)))
/*      */       {
/*  638 */         localObject3 = ((CollectionType)localType)
/*  639 */           .getElementsIterator(localObject2, paramSessionImpl);
/*      */ 
/*  641 */         int k = 1;
/*      */         Object localObject4;
/*  642 */         while (((Iterator)localObject3).hasNext()) {
/*  643 */           localObject4 = ((Iterator)localObject3).next();
/*      */ 
/*  645 */           if (paramMap1.containsKey(localObject4)) {
/*  646 */             k = 0;
/*  647 */             break;
/*      */           }
/*      */         }
/*      */ 
/*  651 */         if (k != 0) {
/*  652 */           localObject3 = ((CollectionType)localType)
/*  653 */             .getElementsIterator(localObject2, paramSessionImpl);
/*  654 */           while (((Iterator)localObject3).hasNext()) {
/*  655 */             localObject4 = ((Iterator)localObject3).next();
/*      */ 
/*  657 */             Map localMap = (Map)paramMap.get(localObject4);
/*  658 */             if (!compareObjWithEntityEntry(
/*  660 */               (SessionImpl)localMap
/*  660 */               .get("origin_data_session"), 
/*  661 */               paramMap, localMap
/*  662 */               .get("origin_data_info"), localObject4, 
/*  663 */               paramMap1)) {
/*  664 */               bool = false;
/*  665 */               break;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*  671 */       else if ((localType.isAssociationType()) && (bool) && (!isInstrumented(localObject1))) {
/*  672 */         if ((paramMap1.containsKey(localObject1)) || (localObject1 == null))
/*      */         {
/*      */           continue;
/*      */         }
/*  676 */         localObject3 = (Map)paramMap.get(localObject1);
/*  677 */         bool = compareObjWithEntityEntry(
/*  678 */           (SessionImpl)((Map)localObject3)
/*  678 */           .get("origin_data_session"), paramMap, 
/*  679 */           ((Map)localObject3).get("origin_data_info"), localObject1, 
/*  680 */           paramMap1);
/*      */       }
/*  682 */       if (!bool)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  689 */     return bool;
/*      */   }
/*      */ 
/*      */   public static boolean isCollectionInstrumented(Object paramObject)
/*      */   {
/*  699 */     if (((paramObject instanceof AbstractPersistentCollection)) && 
/*  700 */       (!((AbstractPersistentCollection)paramObject).wasInitialized())) {
/*  701 */       return true;
/*      */     }
/*  703 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isInstrumented(Object paramObject)
/*      */   {
/*  713 */     return (paramObject != null) && (isInstrumented(paramObject.getClass()));
/*      */   }
/*      */ 
/*      */   public static boolean isInstrumented(Class paramClass)
/*      */   {
/*  723 */     Class[] arrayOfClass = paramClass.getInterfaces();
/*  724 */     for (int i = 0; i < arrayOfClass.length; i++)
/*      */     {
/*  726 */       if ("org.hibernate.proxy.HibernateProxy"
/*  726 */         .equals(arrayOfClass[i].getName())) {
/*  727 */         return true;
/*      */       }
/*      */     }
/*  730 */     return false;
/*      */   }
/*      */ 
/*      */   private static boolean compareObjWithEntityEntry(SessionImpl paramSessionImpl, Map paramMap, Object paramObject1, Object paramObject2, Map<Object, Object> paramMap1)
/*      */   {
/*  746 */     boolean bool = false;
/*  747 */     if ((paramObject1 != null) && ((paramObject1 instanceof EntityEntry))) {
/*  748 */       EntityEntry localEntityEntry = (EntityEntry)paramObject1;
/*  749 */       EntityPersister localEntityPersister = localEntityEntry.getPersister();
/*      */ 
/*  752 */       paramMap1.put(paramObject2, paramObject2);
/*  753 */       bool = compareObj(localEntityEntry.getLoadedState(), localEntityPersister
/*  754 */         .getPropertyValues(paramObject2, paramSessionImpl.getEntityMode()), 
/*  755 */         localEntityPersister.getEntityMetamodel().getProperties(), paramSessionImpl, 
/*  756 */         paramMap, paramMap1);
/*      */ 
/*  758 */       paramMap1.remove(paramObject2);
/*      */     }
/*  760 */     return bool;
/*      */   }
/*      */ 
/*      */   public static List getDeletedPojoList(List paramList)
/*      */   {
/*  771 */     java.util.ArrayList localArrayList = new java.util.ArrayList();
/*  772 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/*  773 */       localArrayList
/*  774 */         .addAll(((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList)
/*  775 */         .getDeletedObjects());
/*      */     }
/*  777 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   public static List getConditionValues(Object paramObject)
/*      */   {
/*  787 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  788 */     if (localDataStore == null)
/*  789 */       return null;
/*  790 */     return localDataStore.getConditionValues();
/*      */   }
/*      */ 
/*      */   public static String getCondition(Object paramObject)
/*      */   {
/*  800 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  801 */     if (localDataStore == null)
/*  802 */       return null;
/*  803 */     return localDataStore.getCondition();
/*      */   }
/*      */ 
/*      */   public static String getOrder(Object paramObject)
/*      */   {
/*  813 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  814 */     if (localDataStore == null)
/*  815 */       return null;
/*  816 */     return localDataStore.getOrder();
/*      */   }
/*      */ 
/*      */   public static int getPageNumber(Object paramObject)
/*      */   {
/*  826 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  827 */     if (localDataStore == null)
/*  828 */       return 1;
/*  829 */     return localDataStore.getPageNumber();
/*      */   }
/*      */ 
/*      */   public static int getPageSize(Object paramObject)
/*      */   {
/*  839 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  840 */     if (localDataStore == null)
/*  841 */       return 2147483647;
/*  842 */     return localDataStore.getPageSize();
/*      */   }
/*      */ 
/*      */   public static MetaData getMetaData(Object paramObject)
/*      */   {
/*  852 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  853 */     if (localDataStore == null)
/*  854 */       return null;
/*  855 */     return localDataStore.getMetaData();
/*      */   }
/*      */ 
/*      */   public static Object getOriginPojo(Object paramObject)
/*      */   {
/*  866 */     Map localMap1 = ContextUtil.getPojoContext();
/*  867 */     if (localMap1.containsKey(paramObject)) {
/*  868 */       Map localMap2 = (Map)localMap1.get(paramObject);
/*  869 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/*  870 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/*  870 */         .get("origin_data_context");
/*  871 */       if ((localArrayList != null) && 
/*  872 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject))) {
/*  873 */         Object localObject1 = localMap2
/*  874 */           .get("origin_data_info");
/*  875 */         if ((localObject1 instanceof EntityEntry)) {
/*  876 */           Object localObject2 = localMap2
/*  877 */             .get("origin_hibernate_data_info");
/*      */ 
/*  879 */           if (localObject2 == null) {
/*  880 */             SessionImpl localSessionImpl = 
/*  881 */               (SessionImpl)localMap2
/*  881 */               .get("origin_data_session");
/*  882 */             EntityEntry localEntityEntry = (EntityEntry)localObject1;
/*      */ 
/*  884 */             localObject2 = localEntityEntry.getPersister().instantiate(
/*  885 */               localEntityEntry.getPersister().getIdentifier(paramObject, 
/*  886 */               localSessionImpl.getEntityMode()), 
/*  887 */               localSessionImpl.getEntityMode());
/*  888 */             localEntityEntry.getPersister()
/*  889 */               .setPropertyValues(localObject2, localEntityEntry.getLoadedState(), 
/*  890 */               localSessionImpl.getEntityMode());
/*  891 */             localMap2.put(
/*  892 */               "origin_hibernate_data_info", localObject2);
/*      */           }
/*  894 */           return localObject2;
/*      */         }
/*  896 */         return localObject1;
/*      */       }
/*      */     }
/*      */ 
/*  900 */     return null;
/*      */   }
/*      */ 
/*      */   public static void setOriginPojo(Object paramObject1, Object paramObject2)
/*      */   {
/*  910 */     Map localMap1 = ContextUtil.getPojoContext();
/*  911 */     if (localMap1.containsKey(paramObject1)) {
/*  912 */       Map localMap2 = (Map)localMap1.get(paramObject1);
/*  913 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/*  914 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/*  914 */         .get("origin_data_context");
/*  915 */       if ((localArrayList != null) && 
/*  916 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject1)))
/*  917 */         localMap2.put("origin_data_info", 
/*  918 */           paramObject2);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static Map getParameters(Object paramObject)
/*      */   {
/*  930 */     if (paramObject == null)
/*  931 */       return null;
/*  932 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  933 */     Map localMap = localDataStore.getParameters();
/*  934 */     if (localMap == null) {
/*  935 */       return null;
/*      */     }
/*  937 */     Iterator localIterator1 = localMap.entrySet().iterator();
/*  938 */     HashMap localHashMap1 = new HashMap();
/*  939 */     while (localIterator1.hasNext()) {
/*  940 */       Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
/*  941 */       Object localObject = localEntry1.getValue();
/*  942 */       if ((localObject instanceof JSONArray)) {
/*  943 */         localHashMap1.put(localEntry1.getKey().toString(), ((JSONArray)localObject)
/*  944 */           .toArray());
/*      */       }
/*  947 */       else if ((localObject instanceof JSONObject)) {
/*  948 */         Set localSet = ((JSONObject)localObject).entrySet();
/*  949 */         Iterator localIterator2 = localSet.iterator();
/*  950 */         HashMap localHashMap2 = new HashMap();
/*  951 */         while (localIterator2.hasNext()) {
/*  952 */           Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
/*  953 */           localHashMap2.put(localEntry2.getKey().toString(), localEntry2.getValue());
/*      */         }
/*  955 */         localHashMap1.put(localEntry1.getKey().toString(), localHashMap2);
/*      */       }
/*      */       else {
/*  958 */         localHashMap1.put(localEntry1.getKey().toString(), localObject);
/*      */       }
/*      */     }
/*  960 */     return localMap;
/*      */   }
/*      */ 
/*      */   public static Object getParameter(Object paramObject, String paramString)
/*      */   {
/*  971 */     if (paramObject == null)
/*  972 */       return null;
/*  973 */     DataStore localDataStore = getPojoDataStore(paramObject);
/*  974 */     if (localDataStore == null) {
/*  975 */       return null;
/*      */     }
/*  977 */     Map localMap = localDataStore.getParameters();
/*  978 */     if (localMap != null) {
/*  979 */       return localMap.get(paramString);
/*      */     }
/*  981 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isNotModified(Object paramObject)
/*      */   {
/* 1001 */     int i = 0;
/* 1002 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1003 */     if (localMap1.containsKey(paramObject)) {
/* 1004 */       Map localMap2 = (Map)localMap1.get(paramObject);
/* 1005 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1006 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1006 */         .get("origin_data_context");
/* 1007 */       if ((localArrayList != null) && 
/* 1008 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject))) {
/* 1009 */         Object localObject = localMap2
/* 1010 */           .get("origin_data_info");
/* 1011 */         if ((localObject != null) && (paramObject != null)) {
/*      */           try {
/* 1013 */             if ((localObject instanceof EntityEntry)) {
/* 1014 */               SessionImpl localSessionImpl = 
/* 1015 */                 (SessionImpl)localMap2
/* 1015 */                 .get("origin_data_session");
/* 1016 */               i = compareObjWithEntityEntry(localSessionImpl, 
/* 1017 */                 localMap1, localObject, paramObject, new HashMap()) ? 0 : 1;
/*      */             }
/*      */             else {
/* 1019 */               i = PojoUtil.compareObj(localObject, paramObject) ? 0 : 1;
/*      */             }
/*      */           } catch (Exception localException) {
/* 1022 */             localException.printStackTrace();
/* 1023 */             Throwable localThrowable = localException.getCause();
/* 1024 */             throw new UniEAPSystemException("", localThrowable, null);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1029 */     return i == 0;
/*      */   }
/*      */ 
/*      */   private static Row getRowByPojoContext(Object paramObject, DataStore paramDataStore) {
/* 1033 */     Row localRow = null;
/* 1034 */     Object localObject = getPojoDataStoreIndex(paramObject);
/* 1035 */     if (localObject != null) {
/* 1036 */       int i = Integer.parseInt(localObject.toString());
/* 1037 */       if (i < 0) {
/* 1038 */         i = -1 - i;
/* 1039 */         localRow = (Row)paramDataStore.getRowSet().getDeleteRows().get(i);
/*      */       }
/* 1041 */       localRow = paramDataStore.getRowSet().getRow(i);
/*      */     }
/* 1043 */     return localRow;
/*      */   }
/*      */ 
/*      */   public static boolean isDeleted(Object paramObject)
/*      */   {
/* 1062 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1063 */     if (localMap1.containsKey(paramObject)) {
/* 1064 */       Map localMap2 = (Map)localMap1.get(paramObject);
/* 1065 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1066 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1066 */         .get("origin_data_context");
/* 1067 */       boolean bool = false;
/* 1068 */       if ((localArrayList != null) && 
/* 1069 */         (localArrayList.contains(localArrayList.getDeletedObjects(), paramObject))) {
/* 1070 */         bool = true;
/*      */       }
/* 1072 */       return bool;
/*      */     }
/*      */ 
/* 1075 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isNewModified(Object paramObject)
/*      */   {
/* 1095 */     boolean bool = false;
/* 1096 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1097 */     if (localMap1.containsKey(paramObject)) {
/* 1098 */       Map localMap2 = (Map)localMap1.get(paramObject);
/* 1099 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1100 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1100 */         .get("origin_data_context");
/* 1101 */       if ((localArrayList != null) && 
/* 1102 */         (localArrayList.contains(localArrayList.getNewObjects(), paramObject))) {
/* 1103 */         bool = true;
/*      */       }
/*      */     }
/* 1106 */     return bool;
/*      */   }
/*      */ 
/*      */   public static boolean isSelected(Object paramObject)
/*      */   {
/* 1117 */     DataStore localDataStore = getPojoDataStore(paramObject);
/* 1118 */     Object localObject = getPojoDataStoreIndex(paramObject);
/* 1119 */     if ((localDataStore != null) && (localObject != null)) {
/* 1120 */       int i = Integer.parseInt(localObject.toString());
/* 1121 */       if (localDataStore.getRowSet().getRows().size() > i) {
/* 1122 */         Row localRow = localDataStore.getRowSet().getRow(i);
/* 1123 */         return localRow.isSeleted();
/*      */       }
/*      */     }
/* 1126 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isDataModified(Object paramObject)
/*      */   {
/* 1146 */     boolean bool = false;
/* 1147 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1148 */     if (localMap1.containsKey(paramObject)) {
/* 1149 */       Map localMap2 = (Map)localMap1.get(paramObject);
/* 1150 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1151 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1151 */         .get("origin_data_context");
/* 1152 */       if ((localArrayList != null) && 
/* 1153 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject))) {
/* 1154 */         Object localObject = localMap2
/* 1155 */           .get("origin_data_info");
/* 1156 */         if ((localObject != null) && (paramObject != null)) {
/*      */           try
/*      */           {
/* 1159 */             if ((localObject instanceof EntityEntry)) {
/* 1160 */               SessionImpl localSessionImpl = 
/* 1161 */                 (SessionImpl)localMap2
/* 1161 */                 .get("origin_data_session");
/* 1162 */               bool = !compareObjWithEntityEntry(
/* 1163 */                 localSessionImpl, localMap1, localObject, paramObject, 
/* 1164 */                 new HashMap());
/*      */             }
/*      */             else {
/* 1167 */               bool = !PojoUtil.compareObj(localObject, paramObject);
/*      */             }
/*      */           } catch (Exception localException) {
/* 1170 */             localException.printStackTrace();
/* 1171 */             Throwable localThrowable = localException.getCause();
/* 1172 */             throw new UniEAPSystemException("", localThrowable, null);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1177 */     return bool;
/*      */   }
/*      */ 
/*      */   public static boolean isDirty(Object paramObject, String paramString)
/*      */   {
/* 1198 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1199 */     boolean bool = false;
/* 1200 */     if (localMap1.containsKey(paramObject)) {
/* 1201 */       Map localMap2 = (Map)localMap1.get(paramObject);
/* 1202 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1203 */         (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1203 */         .get("origin_data_context");
/* 1204 */       if ((localArrayList != null) && 
/* 1205 */         (!localArrayList.contains(localArrayList.getNewObjects(), paramObject))) {
/* 1206 */         Object localObject = localMap2
/* 1207 */           .get("origin_data_info");
/* 1208 */         if ((localObject != null) && (paramObject != null))
/*      */         {
/* 1210 */           if ((localObject instanceof EntityEntry))
/* 1211 */             bool = isDirty(localMap1, 
/* 1213 */               (SessionImpl)localMap2
/* 1213 */               .get("origin_data_session"), 
/* 1214 */               paramObject, 
/* 1215 */               (EntityEntry)localMap2
/* 1215 */               .get("origin_data_info"), 
/* 1216 */               paramString);
/*      */           else {
/*      */             try {
/* 1219 */               bool = !PojoUtil.compareObj(localObject, paramObject, 
/* 1220 */                 paramString);
/*      */             } catch (Exception localException) {
/* 1222 */               localException.printStackTrace();
/* 1223 */               Throwable localThrowable = localException.getCause();
/* 1224 */               throw new UniEAPSystemException("", localThrowable, null);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1231 */     return bool;
/*      */   }
/*      */ 
/*      */   public static List getModifiedProperties(Object paramObject)
/*      */   {
/* 1242 */     Object localObject1 = new java.util.ArrayList();
/* 1243 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1244 */     if ((localMap1 != null) && (localMap1.size() > 0)) {
/* 1245 */       Object localObject2 = localMap1.get(paramObject);
/* 1246 */       if ((localObject2 != null) && ((localObject2 instanceof Map))) {
/* 1247 */         Map localMap2 = (Map)localObject2;
/* 1248 */         Object localObject3 = localMap2.get("origin_data_info");
/* 1249 */         com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = 
/* 1250 */           (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localMap2
/* 1250 */           .get("origin_data_context");
/* 1251 */         if ((localArrayList != null) && 
/* 1252 */           (!localArrayList.contains(localArrayList.getNewObjects(), paramObject)) && 
/* 1253 */           (localObject3 != null) && (paramObject != null))
/*      */         {
/*      */           Object localObject4;
/* 1255 */           if ((localObject3 instanceof EntityEntry)) {
/* 1256 */             HashMap localHashMap = new HashMap();
/* 1257 */             generatePropertiesStatesWithEntityEntry(
/* 1258 */               (EntityEntry)localObject3, 
/* 1259 */               paramObject, 
/* 1261 */               (SessionImpl)localMap2
/* 1261 */               .get("origin_data_session"), 
/* 1262 */               localMap1, localHashMap, new HashMap(), 
/* 1263 */               "");
/* 1264 */             if (localHashMap.size() > 0) {
/* 1265 */               localObject4 = localHashMap
/* 1266 */                 .entrySet().iterator();
/* 1267 */               while (((Iterator)localObject4).hasNext()) {
/* 1268 */                 Map.Entry localEntry = (Map.Entry)((Iterator)localObject4).next();
/* 1269 */                 if (((Boolean)localEntry.getValue()).booleanValue())
/* 1270 */                   ((List)localObject1).add(localEntry.getKey());
/*      */               }
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*      */             try {
/* 1277 */               localObject1 = PojoUtil.getModidiedProperties(
/* 1278 */                 localObject3, paramObject, localMap2);
/*      */             } catch (Exception localException) {
/* 1280 */               localException.printStackTrace();
/* 1281 */               localObject4 = localException.getCause();
/* 1282 */               throw new UniEAPSystemException("", (Throwable)localObject4, null);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1289 */     return localObject1;
/*      */   }
/*      */ 
/*      */   public static String getPojoClassName(Object paramObject)
/*      */   {
/* 1322 */     if (paramObject == null)
/* 1323 */       return "";
/* 1324 */     DataStore localDataStore = getPojoDataStore(paramObject);
/* 1325 */     if (localDataStore != null) {
/* 1326 */       return localDataStore.getRowSetName();
/*      */     }
/* 1328 */     if (((paramObject instanceof List)) && (((List)paramObject).size() > 0)) {
/* 1329 */       return ((List)paramObject).get(0).getClass().getName();
/*      */     }
/* 1331 */     return paramObject.getClass().getName();
/*      */   }
/*      */ 
/*      */   public static void resetUpdate(List paramList, SessionImpl paramSessionImpl)
/*      */   {
/* 1342 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/* 1343 */       com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList;
/* 1344 */       localArrayList.resetUpdate();
/* 1345 */       setPojoContext(localArrayList, paramSessionImpl);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static List setPojoContext(List paramList, SessionImpl paramSessionImpl)
/*      */   {
/* 1356 */     com.neusoft.unieap.techcomp.ria.context.util.ArrayList localArrayList = null;
/* 1357 */     if ((paramList instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/* 1358 */       localArrayList = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramList;
/*      */     } else {
/* 1360 */       localArrayList = new com.neusoft.unieap.techcomp.ria.context.util.ArrayList();
/* 1361 */       localArrayList._addAll(paramList);
/*      */     }
/* 1363 */     Map localMap = ContextUtil.getPojoContext();
/* 1364 */     Object localObject1 = null;
/* 1365 */     if ((localArrayList != null) && (localArrayList.size() > 0)) {
/* 1366 */       localObject1 = localArrayList.get(0);
/*      */     }
/* 1368 */     if ((paramSessionImpl != null) && (localObject1 != null) && (!(localObject1 instanceof Map))) {
/* 1369 */       Set localSet = null;
/* 1370 */       IdentityMap localIdentityMap = (IdentityMap)paramSessionImpl
/* 1371 */         .getPersistenceContext().getEntityEntries();
/*      */       try
/*      */       {
/* 1374 */         localSet = getEntityProperties(localObject1.getClass());
/*      */       } catch (Exception localException) {
/* 1376 */         localException.printStackTrace();
/*      */       }
/* 1378 */       if (localSet != null)
/*      */       {
/*      */         Iterator localIterator2;
/* 1379 */         for (Iterator localIterator1 = localArrayList.iterator(); localIterator1.hasNext(); 
/* 1387 */           localIterator2
/* 1388 */           .hasNext())
/*      */         {
/* 1379 */           Object localObject2 = localIterator1.next();
/*      */ 
/* 1381 */           setPojoContext(paramSessionImpl, localArrayList, localMap, localIdentityMap, 
/* 1382 */             localObject2);
/*      */ 
/* 1387 */           localIterator2 = localSet.iterator(); continue;
/*      */           String str1;
/* 1389 */           String str2 = str1 = (String)localIterator2.next();
/* 1390 */           Object localObject3 = localObject2;
/* 1391 */           if (str1.indexOf(".") > 0) {
/* 1392 */             String[] arrayOfString = str1.split("\\.");
/* 1393 */             for (int i = 0; i < arrayOfString.length - 1; i++) {
/*      */               try {
/* 1395 */                 localObject3 = PropertyUtils.getProperty(
/* 1396 */                   localObject3, arrayOfString[i]);
/*      */               } catch (IllegalAccessException localIllegalAccessException2) {
/* 1398 */                 localIllegalAccessException2.printStackTrace();
/*      */               } catch (InvocationTargetException localInvocationTargetException2) {
/* 1400 */                 localInvocationTargetException2.printStackTrace();
/*      */               } catch (NoSuchMethodException localNoSuchMethodException2) {
/* 1402 */                 localNoSuchMethodException2.printStackTrace();
/*      */               }
/* 1404 */               if ((localObject3 == null) || (isInstrumented(localObject3))) {
/*      */                 break;
/*      */               }
/* 1407 */               setPojoContext(paramSessionImpl, localArrayList, 
/* 1408 */                 localMap, localIdentityMap, localObject3);
/* 1409 */               if (((localObject3 instanceof Collection)) && 
/* 1410 */                 (!isCollectionInstrumented(localObject3))) {
/* 1411 */                 setCollectionContext(paramSessionImpl, localArrayList, 
/* 1412 */                   localMap, localIdentityMap, localObject3);
/*      */               }
/*      */             }
/*      */ 
/* 1416 */             str2 = arrayOfString[(arrayOfString.length - 1)];
/*      */           }
/* 1418 */           if ((localObject3 != null) && (!isInstrumented(localObject3))) {
/*      */             try {
/* 1420 */               Object localObject4 = PropertyUtils.getProperty(
/* 1421 */                 localObject3, str2);
/* 1422 */               if (localObject4 != null) {
/* 1423 */                 setPojoContext(paramSessionImpl, localArrayList, 
/* 1424 */                   localMap, localIdentityMap, localObject4);
/* 1425 */                 if (((localObject4 instanceof Collection)) && 
/* 1426 */                   (!isCollectionInstrumented(localObject4)))
/* 1427 */                   setCollectionContext(paramSessionImpl, localArrayList, 
/* 1428 */                     localMap, localIdentityMap, localObject4);
/*      */               }
/*      */             }
/*      */             catch (IllegalAccessException localIllegalAccessException1) {
/* 1432 */               localIllegalAccessException1.printStackTrace();
/*      */             } catch (InvocationTargetException localInvocationTargetException1) {
/* 1434 */               localInvocationTargetException1.printStackTrace();
/*      */             } catch (NoSuchMethodException localNoSuchMethodException1) {
/* 1436 */               localNoSuchMethodException1.printStackTrace();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1443 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   private static Object getPropertyValue(Map paramMap, SessionImpl paramSessionImpl, Object paramObject, EntityEntry paramEntityEntry, String paramString)
/*      */   {
/* 1449 */     EntityPersister localEntityPersister = paramEntityEntry.getPersister();
/* 1450 */     Object[] arrayOfObject = localEntityPersister.getPropertyValues(paramObject, paramSessionImpl
/* 1451 */       .getEntityMode());
/* 1452 */     StandardProperty[] arrayOfStandardProperty = localEntityPersister.getEntityMetamodel()
/* 1453 */       .getProperties();
/* 1454 */     int i = arrayOfStandardProperty.length;
/* 1455 */     for (int j = 0; j < i; j++) {
/* 1456 */       StandardProperty localStandardProperty = arrayOfStandardProperty[j];
/* 1457 */       String str = localStandardProperty.getName();
/* 1458 */       if (str.equals(paramString)) {
/* 1459 */         return arrayOfObject[j];
/*      */       }
/*      */     }
/* 1462 */     return null;
/*      */   }
/*      */ 
/*      */   private static boolean isDirty(Map paramMap, SessionImpl paramSessionImpl, Object paramObject, EntityEntry paramEntityEntry, String paramString)
/*      */   {
/* 1467 */     HashMap localHashMap1 = new HashMap();
/* 1468 */     HashMap localHashMap2 = new HashMap();
/* 1469 */     generatePropertiesStatesWithEntityEntry(paramEntityEntry, paramObject, paramSessionImpl, 
/* 1470 */       paramMap, localHashMap2, localHashMap1, "");
/* 1471 */     if (localHashMap2.containsKey(paramString))
/* 1472 */       return ((Boolean)localHashMap2.get(paramString)).booleanValue();
/* 1473 */     if (paramString.indexOf(".") > 0) {
/* 1474 */       String[] arrayOfString = paramString.split("\\.");
/* 1475 */       String str = "";
/* 1476 */       for (int i = 0; i < arrayOfString.length - 1; i++) {
/* 1477 */         if (str.length() > 0) {
/* 1478 */           str = str + ".";
/*      */         }
/* 1480 */         str = str + arrayOfString[i];
/* 1481 */         if (localHashMap2.containsKey(str)) {
/* 1482 */           Boolean localBoolean = (Boolean)localHashMap2.get(str);
/* 1483 */           if (!localBoolean.booleanValue()) {
/* 1484 */             return localBoolean.booleanValue();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1489 */     return false;
/*      */   }
/*      */ 
/*      */   private static void generatePropertiesStatesWithEntityEntry(EntityEntry paramEntityEntry, Object paramObject, SessionImpl paramSessionImpl, Map paramMap1, Map<String, Boolean> paramMap, Map paramMap2, String paramString)
/*      */   {
/* 1509 */     EntityPersister localEntityPersister = paramEntityEntry.getPersister();
/*      */ 
/* 1512 */     paramMap2.put(paramObject, paramObject);
/* 1513 */     Serializable localSerializable1 = paramEntityEntry.getId();
/* 1514 */     String str = localEntityPersister.getIdentifierPropertyName();
/* 1515 */     if (paramString.length() > 0) {
/* 1516 */       str = paramString + "." + str;
/*      */     }
/* 1518 */     EntityMode localEntityMode = paramSessionImpl.getEntityMode();
/* 1519 */     Serializable localSerializable2 = localEntityPersister.getIdentifier(paramObject, localEntityMode);
/* 1520 */     paramMap.put(str, Boolean.valueOf(!localEntityPersister.getIdentifierType().isEqual(localSerializable1, 
/* 1521 */       localSerializable2, localEntityMode)));
/* 1522 */     generatePropertiesStates(paramEntityEntry.getLoadedState(), localEntityPersister
/* 1523 */       .getPropertyValues(paramObject, localEntityMode), localEntityPersister
/* 1524 */       .getEntityMetamodel().getProperties(), paramSessionImpl, paramMap, 
/* 1525 */       paramMap1, paramMap2, paramString);
/*      */ 
/* 1527 */     paramMap2.remove(paramObject);
/*      */   }
/*      */ 
/*      */   private static void generatePropertiesStates(Object[] paramArrayOfObject1, Object[] paramArrayOfObject2, StandardProperty[] paramArrayOfStandardProperty, SessionImpl paramSessionImpl, Map<String, Boolean> paramMap, Map paramMap1, Map paramMap2, String paramString)
/*      */   {
/* 1546 */     int i = 1;
/* 1547 */     int j = paramArrayOfStandardProperty.length;
/* 1548 */     for (int k = 0; k < j; k++) {
/* 1549 */       StandardProperty localStandardProperty = paramArrayOfStandardProperty[k];
/* 1550 */       String str1 = localStandardProperty.getName();
/* 1551 */       if (paramString.length() > 0) {
/* 1552 */         str1 = paramString + "." + str1;
/*      */       }
/* 1554 */       Type localType = localStandardProperty.getType();
/* 1555 */       Object localObject1 = paramArrayOfObject1[k];
/* 1556 */       Object localObject2 = paramArrayOfObject2[k];
/*      */       Object localObject3;
/*      */       Object localObject4;
/*      */       Object localObject5;
/* 1557 */       if (localType.isComponentType())
/*      */       {
/* 1559 */         localObject3 = paramSessionImpl.getEntityMode();
/* 1560 */         String[] arrayOfString = ((ComponentType)localType)
/* 1561 */           .getPropertyNames();
/* 1562 */         localObject4 = (Object[])null;
/* 1563 */         localObject5 = (Object[])null;
/* 1564 */         if (localObject1 != null)
/* 1565 */           localObject4 = ((ComponentType)localType).getPropertyValues(localObject1, 
/* 1566 */             (EntityMode)localObject3);
/*      */         else {
/* 1568 */           localObject4 = new String[arrayOfString.length];
/*      */         }
/* 1570 */         if (localObject2 != null)
/* 1571 */           localObject5 = ((ComponentType)localType).getPropertyValues(localObject2, 
/* 1572 */             (EntityMode)localObject3);
/*      */         else {
/* 1574 */           localObject5 = new String[arrayOfString.length];
/*      */         }
/* 1576 */         Type[] arrayOfType = ((ComponentType)localType).getSubtypes();
/* 1577 */         for (int n = 0; n < localObject4.length; n++) {
/* 1578 */           String str2 = arrayOfString[n];
/* 1579 */           if (str1.length() > 0) {
/* 1580 */             str2 = str1 + "." + str2;
/*      */           }
/* 1582 */           paramMap.put(str2, Boolean.valueOf(arrayOfType[n].isDirty(
/* 1583 */             localObject4[n], localObject5[n], paramSessionImpl)));
/*      */         }
/*      */       } else {
/* 1586 */         i = (localObject2 != LazyPropertyInitializer.UNFETCHED_PROPERTY) && 
/* 1587 */           (localStandardProperty.isDirtyCheckable(false)) && (
/* 1587 */           localType
/* 1588 */           .isDirty(localObject1, localObject2, paramSessionImpl)) ? 0 : 1;
/*      */ 
/* 1590 */         if ((localType.isCollectionType()) && (!isInstrumented(localObject2)) && (i != 0))
/*      */         {
/* 1592 */           localObject3 = ((CollectionType)localType)
/* 1593 */             .getElementsIterator(localObject2, paramSessionImpl);
/*      */ 
/* 1595 */           int m = 1;
/* 1596 */           while (((Iterator)localObject3).hasNext()) {
/* 1597 */             localObject4 = ((Iterator)localObject3).next();
/*      */ 
/* 1599 */             if (paramMap2.containsKey(localObject4)) {
/* 1600 */               m = 0;
/* 1601 */               break;
/*      */             }
/*      */           }
/*      */ 
/* 1605 */           if (m != 0) {
/* 1606 */             localObject3 = ((CollectionType)localType)
/* 1607 */               .getElementsIterator(localObject2, paramSessionImpl);
/* 1608 */             while (((Iterator)localObject3).hasNext()) {
/* 1609 */               localObject4 = ((Iterator)localObject3).next();
/*      */ 
/* 1611 */               localObject5 = (Map)paramMap1.get(localObject4);
/* 1612 */               if (!compareObjWithEntityEntry(
/* 1614 */                 (SessionImpl)((Map)localObject5)
/* 1614 */                 .get("origin_data_session"), 
/* 1615 */                 paramMap1, ((Map)localObject5)
/* 1616 */                 .get("origin_data_info"), 
/* 1617 */                 localObject4, paramMap2))
/*      */               {
/*      */                 break;
/*      */               }
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/* 1626 */         else if ((localType.isAssociationType()) && (!isInstrumented(localObject1)) && 
/* 1627 */           (i != 0)) {
/* 1628 */           if ((paramMap2.containsKey(localObject1)) || (localObject1 == null))
/*      */           {
/*      */             continue;
/*      */           }
/* 1632 */           localObject3 = (Map)paramMap1.get(localObject1);
/* 1633 */           compareObjWithEntityEntry(
/* 1634 */             (SessionImpl)((Map)localObject3)
/* 1634 */             .get("origin_data_session"), paramMap1, 
/* 1635 */             ((Map)localObject3).get("origin_data_info"), 
/* 1636 */             localObject1, paramMap2);
/* 1637 */           generatePropertiesStatesWithEntityEntry(
/* 1639 */             (EntityEntry)((Map)localObject3)
/* 1639 */             .get("origin_data_info"), localObject1, 
/* 1641 */             (SessionImpl)((Map)localObject3)
/* 1641 */             .get("origin_data_session"), 
/* 1642 */             paramMap1, paramMap, paramMap2, str1);
/*      */         }
/* 1644 */         paramMap.put(str1, Boolean.valueOf(i == 0));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void setCollectionContext(SessionImpl paramSessionImpl, com.neusoft.unieap.techcomp.ria.context.util.ArrayList paramArrayList, Map paramMap, IdentityMap paramIdentityMap, Object paramObject)
/*      */   {
/* 1652 */     Iterator localIterator = ((Collection)paramObject).iterator();
/* 1653 */     while (localIterator.hasNext()) {
/* 1654 */       Object localObject = localIterator.next();
/* 1655 */       setPojoContext(paramSessionImpl, paramArrayList, paramMap, paramIdentityMap, localObject);
/* 1656 */       if (((localObject instanceof Collection)) && (!isCollectionInstrumented(localObject)))
/* 1657 */         setCollectionContext(paramSessionImpl, paramArrayList, paramMap, paramIdentityMap, 
/* 1658 */           localObject);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void setPojoContext(SessionImpl paramSessionImpl, com.neusoft.unieap.techcomp.ria.context.util.ArrayList paramArrayList, Map paramMap1, Map paramMap2, Object paramObject)
/*      */   {
/* 1676 */     if (paramMap2.containsKey(paramObject)) {
/* 1677 */       EntityEntry localEntityEntry = (EntityEntry)paramMap2.get(paramObject);
/* 1678 */       Status localStatus = localEntityEntry.getStatus();
/* 1679 */       if ((localStatus != Status.LOADING) && (localStatus != Status.GONE)) {
/* 1680 */         Object localObject1 = null;
/* 1681 */         if (!paramMap1.containsKey(paramObject)) {
/* 1682 */           localObject1 = new HashMap();
/* 1683 */           ((Map)localObject1)
/* 1684 */             .put("origin_data_session", paramSessionImpl);
/* 1685 */           ((Map)localObject1).put("origin_data_info", localEntityEntry);
/* 1686 */           ((Map)localObject1).put("origin_data_context", 
/* 1687 */             paramArrayList);
/* 1688 */           paramMap1.put(paramObject, localObject1);
/*      */         }
/*      */         else {
/* 1691 */           localObject1 = (Map)paramMap1.get(paramObject);
/* 1692 */           Object localObject2 = ((Map)localObject1)
/* 1693 */             .get("origin_data_info");
/* 1694 */           if (localObject2 != null) {
/* 1695 */             if (!(localObject2 instanceof EntityEntry))
/* 1696 */               BeanUtils.copyProperties(paramObject, localObject2);
/*      */           }
/*      */           else {
/* 1699 */             ((Map)localObject1).put("origin_data_info", localEntityEntry);
/* 1700 */             ((Map)localObject1).put("origin_data_context", 
/* 1701 */               paramArrayList);
/* 1702 */             ((Map)localObject1).put("origin_data_session", 
/* 1703 */               paramSessionImpl);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Set getEntityProperties(Class paramClass)
/*      */     throws Exception
/*      */   {
/* 1718 */     if (pojoEntiyProperty.containsKey(paramClass)) {
/* 1719 */       return (Set)pojoEntiyProperty.get(paramClass);
/*      */     }
/* 1721 */     Set localSet1 = Collections.synchronizedSet(new HashSet());
/* 1722 */     pojoEntiyProperty.put(paramClass, localSet1);
/* 1723 */     HashSet localHashSet1 = new HashSet();
/* 1724 */     Method[] arrayOfMethod = paramClass.getMethods();
/* 1725 */     int i = 0; for (int j = arrayOfMethod.length; i < j; i++) {
/* 1726 */       String str1 = arrayOfMethod[i].getName();
/* 1727 */       localHashSet1.add(str1);
/*      */     }
/* 1729 */     java.util.ArrayList localArrayList = new java.util.ArrayList();
/* 1730 */     Class localClass1 = paramClass;
/*      */ 
/* 1732 */     while ((localClass1 != null) && (localClass1 != Object.class)) {
/* 1733 */       localArrayList.add(localClass1.getDeclaredFields());
/* 1734 */       localClass1 = localClass1.getSuperclass();
/*      */     }
/* 1736 */     for (int k = 0; k < localArrayList.size(); k++) {
/* 1737 */       Field[] arrayOfField = (Field[])localArrayList.get(k);
/* 1738 */       int m = 0; for (int n = arrayOfField.length; m < n; m++) {
/* 1739 */         String str2 = arrayOfField[m].getName();
/* 1740 */         String str3 = 
/* 1741 */           PojoUtil.getStandardBeanName(str2);
/*      */ 
/* 1743 */         if ((localHashSet1.contains("get".concat(str3))) || 
/* 1744 */           (localHashSet1
/* 1744 */           .contains("is".concat(str3)))) {
/* 1745 */           Class localClass2 = arrayOfField[m].getType();
/* 1746 */           String str4 = localClass2.getName();
/*      */ 
/* 1748 */           if ((!str4.startsWith("java.")) && 
/* 1749 */             (!localClass2.isPrimitive()) && 
/* 1750 */             (!PojoUtil.isCodeType(localClass2))) {
/* 1751 */             Set localSet2 = getEntityProperties(localClass2);
/* 1752 */             HashSet localHashSet2 = new HashSet();
/* 1753 */             for (Iterator localIterator = localSet2.iterator(); localIterator
/* 1754 */               .hasNext(); )
/*      */             {
/* 1755 */               String str5 = (String)localIterator.next();
/* 1756 */               localHashSet2.add(str2.concat(".").concat(str5));
/*      */             }
/* 1758 */             localSet1.addAll(localHashSet2);
/*      */           }
/*      */           else {
/* 1761 */             localSet1.add(str2);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1766 */     return localSet1;
/*      */   }
/*      */ 
/*      */   private static DataStore getPojoDataStore(Object paramObject) {
/* 1770 */     if (paramObject == null)
/* 1771 */       return null;
/* 1772 */     if ((paramObject instanceof com.neusoft.unieap.techcomp.ria.context.util.ArrayList)) {
/* 1773 */       localObject1 = (com.neusoft.unieap.techcomp.ria.context.util.ArrayList)paramObject;
/* 1774 */       return ((com.neusoft.unieap.techcomp.ria.context.util.ArrayList)localObject1).getDataStore();
/*      */     }
/* 1776 */     if (((paramObject instanceof Map)) || 
/* 1777 */       ((paramObject instanceof java.util.ArrayList))) {
/* 1778 */       return getMapPojoDataStore(paramObject);
/*      */     }
/* 1780 */     Object localObject1 = ContextUtil.getPojoContext();
/* 1781 */     Object localObject2 = ((Map)localObject1).get(paramObject);
/* 1782 */     if ((localObject2 instanceof Map)) {
/* 1783 */       Object localObject3 = ((Map)localObject2)
/* 1784 */         .get("origin_data_dataStore");
/* 1785 */       if ((localObject3 != null) && ((localObject3 instanceof DataStore))) {
/* 1786 */         return (DataStore)localObject3;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1791 */     return null;
/*      */   }
/*      */ 
/*      */   private static DataStore getMapPojoDataStore(Object paramObject) {
/* 1795 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1796 */     Object localObject1 = localMap1.get("map_data_context");
/* 1797 */     Object localObject2 = null;
/* 1798 */     if ((localObject1 instanceof Map)) {
/* 1799 */       Map localMap2 = (Map)localObject1;
/* 1800 */       Object localObject3 = null;
/* 1801 */       Iterator localIterator = localMap2.entrySet().iterator();
/*      */       Object localObject4;
/* 1802 */       while (localIterator.hasNext()) {
/* 1803 */         localObject4 = (Map.Entry)localIterator.next();
/* 1804 */         Object localObject5 = ((Map.Entry)localObject4).getKey();
/* 1805 */         if (localObject5 == paramObject) {
/* 1806 */           localObject3 = ((Map.Entry)localObject4).getValue();
/* 1807 */           break;
/*      */         }
/*      */       }
/* 1810 */       if ((localObject3 instanceof Map)) {
/* 1811 */         localObject4 = (Map)localObject3;
/* 1812 */         localObject2 = ((Map)localObject4).get("origin_data_dataStore");
/* 1813 */         if ((localObject2 instanceof DataStore)) {
/* 1814 */           return (DataStore)localObject2;
/*      */         }
/*      */       }
/*      */     }
/* 1818 */     return null;
/*      */   }
/*      */ 
/*      */   private static Object getPojoDataStoreIndex(Object paramObject) {
/* 1822 */     if (paramObject == null)
/* 1823 */       return null;
/*      */     Object localObject2;
/* 1824 */     if ((paramObject instanceof Map)) {
/* 1825 */       localMap1 = ContextUtil.getPojoContext();
/* 1826 */       localObject1 = localMap1.get("map_data_context");
/* 1827 */       localObject2 = null;
/* 1828 */       if ((localObject1 instanceof Map)) {
/* 1829 */         Map localMap2 = (Map)localObject1;
/* 1830 */         Object localObject3 = null;
/* 1831 */         Iterator localIterator = localMap2.entrySet().iterator();
/*      */         Object localObject4;
/* 1832 */         while (localIterator.hasNext()) {
/* 1833 */           localObject4 = (Map.Entry)localIterator.next();
/* 1834 */           Object localObject5 = ((Map.Entry)localObject4).getKey();
/* 1835 */           if (localObject5 == paramObject) {
/* 1836 */             localObject3 = ((Map.Entry)localObject4).getValue();
/* 1837 */             break;
/*      */           }
/*      */         }
/* 1840 */         if ((localObject3 instanceof Map)) {
/* 1841 */           localObject4 = (Map)localObject3;
/* 1842 */           localObject2 = ((Map)localObject4)
/* 1843 */             .get("origin_data_dataStore_index");
/* 1844 */           return localObject2;
/*      */         }
/*      */       }
/* 1847 */       return null;
/*      */     }
/* 1849 */     Map localMap1 = ContextUtil.getPojoContext();
/* 1850 */     Object localObject1 = localMap1.get(paramObject);
/* 1851 */     if ((localObject1 != null) && ((localObject1 instanceof Map))) {
/* 1852 */       localObject2 = ((Map)localObject1)
/* 1853 */         .get("origin_data_dataStore_index");
/* 1854 */       if (localObject2 != null) {
/* 1855 */         int i = Integer.parseInt(localObject2.toString());
/* 1856 */         return Integer.valueOf(i);
/*      */       }
/*      */     }
/*      */ 
/* 1860 */     return null;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.PojoContextUtil
 * JD-Core Version:    0.6.2
 */