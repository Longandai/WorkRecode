/*    */ package com.neusoft.unieap.techcomp.ria.util.proxy;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class ProxyObjHandlerFactory
/*    */ {
/* 12 */   private static ProxyObjHandler proxyPojoHandler = null;
/*    */ 
/*    */   public static ProxyObjHandler getHandler()
/*    */   {
/* 20 */     if (proxyPojoHandler == null) {
/* 21 */       InputStream localInputStream = null;
/* 22 */       String str = null;
/*    */       try {
/* 24 */         Properties localProperties = new Properties();
/* 25 */         localInputStream = ProxyObjHandler.class
/* 26 */           .getResourceAsStream("proxyObjHandlerConfig.properties");
/* 27 */         localProperties.load(localInputStream);
/* 28 */         str = localProperties.getProperty("proxyPojoHandler");
/* 29 */         if ((str != null) && (str.length() > 0))
/* 30 */           proxyPojoHandler = 
/* 31 */             (ProxyObjHandler)Class.forName(str)
/* 31 */             .newInstance();
/*    */       }
/*    */       catch (Exception localException) {
/* 34 */         throw new RIAException(
/* 35 */           "EAPTECH008006", localException, 
/* 36 */           new String[] { str });
/*    */       } finally {
/* 38 */         if (localInputStream != null) {
/*    */           try {
/* 40 */             localInputStream.close();
/*    */           } catch (IOException localIOException1) {
/* 42 */             localIOException1.printStackTrace();
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 48 */     return proxyPojoHandler;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.proxy.ProxyObjHandlerFactory
 * JD-Core Version:    0.6.2
 */