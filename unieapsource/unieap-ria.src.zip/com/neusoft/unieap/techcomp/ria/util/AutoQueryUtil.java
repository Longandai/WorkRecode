/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class AutoQueryUtil
/*     */ {
/*     */   public static final String QUERY_OPERATORS = "_queryOperators";
/*     */   public static final String QUERY_ORDERS = "_queryOrders";
/*     */   public static final String QUERY_FAKE_INFO = "_queryFakeInfo";
/*     */   public static final String QUERY_JOIN_FETCH = "_queryJoinFetch";
/*     */   public static final String QUERY_DS_ROWSETNAME = "_queryDSRowSetName";
/*  17 */   public static final String[] OPERATORS = { ">", "<", "like", "=", ">=", "<=", "llike", "rlike", "<>" };
/*     */ 
/*     */   public static Map getOperators(Object paramObject)
/*     */   {
/*  26 */     return getAutoQueryMapPar(paramObject, "_queryOperators");
/*     */   }
/*     */ 
/*     */   private static Map getAutoQueryMapPar(Object paramObject, String paramString) {
/*  30 */     Object localObject1 = PojoContextUtil.getParameter(paramObject, paramString);
/*  31 */     HashMap localHashMap = new HashMap();
/*  32 */     if ((localObject1 != null) && ((localObject1 instanceof JSONObject))) {
/*  33 */       JSONObject localJSONObject = (JSONObject)localObject1;
/*  34 */       Set localSet = localJSONObject.entrySet();
/*  35 */       Iterator localIterator = localSet.iterator();
/*     */ 
/*  39 */       while (localIterator.hasNext()) {
/*  40 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  41 */         String str = (String)localEntry.getKey();
/*  42 */         Object localObject2 = localEntry.getValue();
/*     */ 
/*  44 */         if (((localObject2 instanceof JSONObject)) && 
/*  45 */           (((JSONObject)localObject2).isNullObject())) {
/*  46 */           localObject2 = null;
/*     */         }
/*     */ 
/*  49 */         localHashMap.put(str, localObject2);
/*     */       }
/*     */     }
/*  52 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public static String getOrders(Object paramObject)
/*     */   {
/*  61 */     return getAutoQueryStringPar(paramObject, "_queryOrders");
/*     */   }
/*     */ 
/*     */   private static String getAutoQueryStringPar(Object paramObject, String paramString) {
/*  65 */     Object localObject = PojoContextUtil.getParameter(paramObject, paramString);
/*  66 */     if (localObject == null) {
/*  67 */       return "";
/*     */     }
/*  69 */     if ((localObject instanceof JSONObject)) {
/*  70 */       JSONObject localJSONObject = (JSONObject)localObject;
/*  71 */       if (localJSONObject.isNullObject()) {
/*  72 */         return "";
/*     */       }
/*     */     }
/*  75 */     return localObject.toString();
/*     */   }
/*     */ 
/*     */   public static Map getFakeInfo(Object paramObject)
/*     */   {
/*  84 */     return getAutoQueryMapPar(paramObject, "_queryFakeInfo");
/*     */   }
/*     */ 
/*     */   public static String getJoinFetchInfo(Object paramObject)
/*     */   {
/*  93 */     return getAutoQueryStringPar(paramObject, "_queryJoinFetch");
/*     */   }
/*     */ 
/*     */   public static String getQueryClassName(Object paramObject)
/*     */   {
/* 102 */     Object localObject = PojoContextUtil.getParameter(paramObject, "_queryDSRowSetName");
/* 103 */     if ((localObject == null) || (localObject.equals(""))) {
/* 104 */       return PojoContextUtil.getPojoClassName(paramObject);
/*     */     }
/* 106 */     if ((localObject instanceof JSONObject)) {
/* 107 */       JSONObject localJSONObject = (JSONObject)localObject;
/* 108 */       if (localJSONObject.isNullObject()) {
/* 109 */         return PojoContextUtil.getPojoClassName(paramObject);
/*     */       }
/*     */     }
/* 112 */     return localObject.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.AutoQueryUtil
 * JD-Core Version:    0.6.2
 */