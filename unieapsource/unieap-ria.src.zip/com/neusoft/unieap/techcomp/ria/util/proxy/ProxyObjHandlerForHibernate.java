/*     */ package com.neusoft.unieap.techcomp.ria.util.proxy;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.hibernate.engine.SessionFactoryImplementor;
/*     */ import org.hibernate.engine.SessionImplementor;
/*     */ import org.hibernate.persister.entity.EntityPersister;
/*     */ import org.hibernate.proxy.HibernateProxy;
/*     */ import org.hibernate.proxy.LazyInitializer;
/*     */ 
/*     */ public class ProxyObjHandlerForHibernate
/*     */   implements ProxyObjHandler
/*     */ {
/*  27 */   private static final Set simplePojo = new HashSet();
/*     */ 
/*  29 */   private static final Map pojoSimpleProperty = new ConcurrentHashMap();
/*     */ 
/*     */   public String getIdentifierName(Object paramObject) {
/*  32 */     HibernateProxy localHibernateProxy = (HibernateProxy)paramObject;
/*  33 */     LazyInitializer localLazyInitializer = localHibernateProxy
/*  34 */       .getHibernateLazyInitializer();
/*  35 */     EntityPersister localEntityPersister = 
/*  37 */       (EntityPersister)localLazyInitializer
/*  36 */       .getSession().getFactory().getAllClassMetadata()
/*  37 */       .get(localLazyInitializer.getPersistentClass().getName());
/*  38 */     return localEntityPersister.getIdentifierPropertyName();
/*     */   }
/*     */ 
/*     */   public boolean isProxy(Object paramObject)
/*     */   {
/* 108 */     if (paramObject == null) {
/* 109 */       return false;
/*     */     }
/* 111 */     Class localClass = paramObject.getClass();
/*     */ 
/* 113 */     if ((paramObject == null) || (simplePojo.contains(localClass))) {
/* 114 */       return false;
/*     */     }
/* 116 */     if ((paramObject instanceof HibernateProxy)) {
/* 117 */       return true;
/*     */     }
/* 119 */     HashSet localHashSet = new HashSet();
/* 120 */     return isProxyField(paramObject, localHashSet);
/*     */   }
/*     */ 
/*     */   public Set getEntityProperties(Object paramObject)
/*     */   {
/* 132 */     HashMap localHashMap = new HashMap();
/* 133 */     return getEntityProperties(paramObject, localHashMap);
/*     */   }
/*     */ 
/*     */   private Set getEntityProperties(Object paramObject, Map paramMap)
/*     */   {
/* 138 */     if (paramMap.containsKey(paramObject)) {
/* 139 */       localObject1 = (Set)paramMap.get(paramObject);
/* 140 */       if (localObject1 != null) {
/* 141 */         return localObject1;
/*     */       }
/*     */ 
/* 144 */       return getSimpleProperty(paramObject.getClass());
/*     */     }
/*     */ 
/* 148 */     paramMap.put(paramObject, null);
/* 149 */     Object localObject1 = paramObject.getClass();
/* 150 */     HashSet localHashSet = new HashSet();
/*     */     Object localObject2;
/* 151 */     if ((paramObject instanceof HibernateProxy)) {
/* 152 */       localObject2 = getIdentifierName(paramObject);
/* 153 */       localHashSet.add(localObject2);
/*     */     }
/*     */     else {
/* 156 */       localObject2 = new HashSet();
/* 157 */       Method[] arrayOfMethod = ((Class)localObject1).getMethods();
/* 158 */       int i = 0; for (int j = arrayOfMethod.length; i < j; i++) {
/* 159 */         String str1 = arrayOfMethod[i].getName();
/* 160 */         ((Set)localObject2).add(str1);
/*     */       }
/* 162 */       ArrayList localArrayList = new ArrayList();
/* 163 */       Object localObject3 = localObject1;
/* 164 */       while (localObject3 != Object.class) {
/* 165 */         localArrayList.add(((Class)localObject3).getDeclaredFields());
/* 166 */         localObject3 = ((Class)localObject3).getSuperclass();
/*     */       }
/* 168 */       for (int k = 0; k < localArrayList.size(); k++) {
/* 169 */         Field[] arrayOfField = (Field[])localArrayList.get(k);
/* 170 */         int m = 0; for (int n = arrayOfField.length; m < n; m++) {
/* 171 */           String str2 = arrayOfField[m].getName();
/* 172 */           String str3 = 
/* 173 */             PojoUtil.getStandardBeanName(str2);
/* 174 */           if ((((Set)localObject2).contains("set".concat(str3))) && (
/* 175 */             (((Set)localObject2).contains("get".concat(str3))) || 
/* 176 */             (((Set)localObject2)
/* 176 */             .contains("is".concat(str3))))) {
/* 177 */             Class localClass = arrayOfField[m].getType();
/* 178 */             String str4 = localClass.getName();
/*     */ 
/* 180 */             if ((!str4.startsWith("java.")) && 
/* 181 */               (!localClass.isPrimitive()) && 
/* 182 */               (!PojoUtil.isCodeType(localClass))) {
/*     */               try
/*     */               {
/* 185 */                 Object localObject4 = PropertyUtils.getProperty(paramObject, 
/* 186 */                   str2);
/*     */                 Object localObject5;
/* 187 */                 if ((localObject4 instanceof HibernateProxy))
/*     */                 {
/* 189 */                   localObject5 = getIdentifierName(localObject4);
/* 190 */                   localHashSet.add(str2.concat(".")
/* 191 */                     .concat((String)localObject5));
/*     */                 } else {
/* 193 */                   localObject5 = new HashSet();
/*     */                   Set localSet;
/*     */                   Object localObject6;
/*     */                   Object localObject7;
/* 194 */                   if (isProxyField(localObject4, (Set)localObject5))
/*     */                   {
/* 196 */                     localSet = getEntityProperties(
/* 197 */                       localObject4, paramMap);
/* 198 */                     if (!localSet.isEmpty()) {
/* 199 */                       localObject6 = localSet
/* 200 */                         .iterator();
/* 201 */                       while (((Iterator)localObject6).hasNext()) {
/* 202 */                         localObject7 = 
/* 203 */                           (String)((Iterator)localObject6)
/* 203 */                           .next();
/* 204 */                         localObject7 = str2
/* 205 */                           .concat(".").concat(
/* 206 */                           (String)localObject7);
/* 207 */                         localHashSet.add(localObject7);
/*     */                       }
/*     */                     }
/*     */                   }
/*     */                   else {
/* 212 */                     localSet = 
/* 213 */                       PojoUtil.getEntityProperties(localClass);
/* 214 */                     localObject6 = new HashSet();
/* 215 */                     for (localObject7 = localSet
/* 216 */                       .iterator(); 
/* 216 */                       ((Iterator)localObject7).hasNext(); )
/*     */                     {
/* 217 */                       String str5 = 
/* 218 */                         (String)((Iterator)localObject7)
/* 218 */                         .next();
/* 219 */                       ((Set)localObject6).add(str2.concat(".")
/* 220 */                         .concat(str5));
/*     */                     }
/* 222 */                     localHashSet.addAll((Collection)localObject6);
/*     */                   }
/*     */                 }
/*     */               } catch (Exception localException) {
/* 226 */                 throw new RIAException(
/* 227 */                   "EAPTECH008005", 
/* 228 */                   localException, new String[] { ((Class)localObject1).getName(), 
/* 229 */                   str2 });
/*     */               }
/*     */             }
/* 232 */             else if (!PojoUtil.isCollectionOrMap(localClass)) {
/* 233 */               localHashSet.add(str2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 240 */     paramMap.put(paramObject, localHashSet);
/* 241 */     return localHashSet;
/*     */   }
/*     */ 
/*     */   private boolean isProxyField(Object paramObject, Set paramSet)
/*     */   {
/* 251 */     if ((paramObject == null) || (paramSet.contains(paramObject)))
/* 252 */       return false;
/* 253 */     int i = 1;
/* 254 */     paramSet.add(paramObject);
/* 255 */     HashSet localHashSet = new HashSet();
/* 256 */     Class localClass1 = paramObject.getClass();
/* 257 */     Method[] arrayOfMethod = localClass1.getMethods();
/* 258 */     int j = 0; for (int k = arrayOfMethod.length; j < k; j++) {
/* 259 */       String str1 = arrayOfMethod[j].getName();
/* 260 */       localHashSet.add(str1);
/*     */     }
/* 262 */     ArrayList localArrayList = new ArrayList();
/* 263 */     Class localClass2 = localClass1;
/* 264 */     while (localClass2 != Object.class) {
/* 265 */       localArrayList.add(localClass2.getDeclaredFields());
/* 266 */       localClass2 = localClass2.getSuperclass();
/*     */     }
/* 268 */     for (int m = 0; m < localArrayList.size(); m++) {
/* 269 */       Field[] arrayOfField = (Field[])localArrayList.get(m);
/* 270 */       int n = 0; for (int i1 = arrayOfField.length; n < i1; n++) {
/* 271 */         String str2 = arrayOfField[n].getName();
/* 272 */         String str3 = 
/* 273 */           PojoUtil.getStandardBeanName(str2);
/* 274 */         if ((localHashSet.contains("set".concat(str3))) && (
/* 275 */           (localHashSet.contains("get".concat(str3))) || 
/* 276 */           (localHashSet
/* 276 */           .contains("is".concat(str3))))) {
/* 277 */           Class localClass3 = arrayOfField[n].getType();
/* 278 */           String str4 = localClass3.getName();
/*     */ 
/* 280 */           if ((!str4.startsWith("java.")) && 
/* 281 */             (!localClass3.isPrimitive()) && 
/* 282 */             (!PojoUtil.isCodeType(localClass3)))
/*     */           {
/* 284 */             if (i != 0)
/* 285 */               i = 0;
/*     */             try
/*     */             {
/* 288 */               Object localObject = PropertyUtils.getProperty(paramObject, 
/* 289 */                 str2);
/* 290 */               if (((localObject instanceof HibernateProxy)) || 
/* 291 */                 (isProxyField(localObject, paramSet)))
/* 292 */                 return true;
/*     */             }
/*     */             catch (IllegalAccessException localIllegalAccessException) {
/* 295 */               throw new RIAException(
/* 296 */                 "EAPTECH008005", localIllegalAccessException, 
/* 297 */                 new String[] { localClass1.getName(), str2 });
/*     */             } catch (InvocationTargetException localInvocationTargetException) {
/* 299 */               throw new RIAException(
/* 300 */                 "EAPTECH008005", localInvocationTargetException, 
/* 301 */                 new String[] { localClass1.getName(), str2 });
/*     */             } catch (NoSuchMethodException localNoSuchMethodException) {
/* 303 */               throw new RIAException(
/* 304 */                 "EAPTECH008005", localNoSuchMethodException, 
/* 305 */                 new String[] { localClass1.getName(), str2 });
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 311 */     if (i != 0) {
/* 312 */       simplePojo.add(localClass1);
/*     */     }
/* 314 */     return false;
/*     */   }
/*     */ 
/*     */   private Set getSimpleProperty(Class paramClass)
/*     */   {
/* 325 */     if (pojoSimpleProperty.containsKey(paramClass)) {
/* 326 */       return (Set)pojoSimpleProperty.get(paramClass);
/*     */     }
/* 328 */     Set localSet = Collections.synchronizedSet(new HashSet());
/* 329 */     pojoSimpleProperty.put(paramClass, localSet);
/* 330 */     HashSet localHashSet = new HashSet();
/* 331 */     Method[] arrayOfMethod = paramClass.getMethods();
/* 332 */     int i = 0; for (int j = arrayOfMethod.length; i < j; i++) {
/* 333 */       String str1 = arrayOfMethod[i].getName();
/* 334 */       localHashSet.add(str1);
/*     */     }
/* 336 */     ArrayList localArrayList = new ArrayList();
/* 337 */     Class localClass1 = paramClass;
/* 338 */     while (localClass1 != Object.class) {
/* 339 */       localArrayList.add(localClass1.getDeclaredFields());
/* 340 */       localClass1 = localClass1.getSuperclass();
/*     */     }
/* 342 */     for (int k = 0; k < localArrayList.size(); k++) {
/* 343 */       Field[] arrayOfField = (Field[])localArrayList.get(k);
/* 344 */       int m = 0; for (int n = arrayOfField.length; m < n; m++) {
/* 345 */         String str2 = arrayOfField[m].getName();
/* 346 */         String str3 = 
/* 347 */           PojoUtil.getStandardBeanName(str2);
/* 348 */         if ((localHashSet.contains("set".concat(str3))) && (
/* 349 */           (localHashSet.contains("get".concat(str3))) || 
/* 350 */           (localHashSet
/* 350 */           .contains("is".concat(str3))))) {
/* 351 */           Class localClass2 = arrayOfField[m].getType();
/* 352 */           String str4 = localClass2.getName();
/*     */ 
/* 354 */           if ((str4.startsWith("java.")) || 
/* 355 */             (localClass2.isPrimitive()) || 
/* 356 */             (PojoUtil.isCodeType(localClass2)))
/*     */           {
/* 360 */             if (!PojoUtil.isCollectionOrMap(localClass2)) {
/* 361 */               localSet.add(str2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 367 */     return localSet;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.proxy.ProxyObjHandlerForHibernate
 * JD-Core Version:    0.6.2
 */