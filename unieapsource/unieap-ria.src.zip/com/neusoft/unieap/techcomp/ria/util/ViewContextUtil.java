/*    */ package com.neusoft.unieap.techcomp.ria.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*    */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ViewContextUtil
/*    */ {
/*    */   public static ViewContext getViewContext()
/*    */   {
/*  9 */     ViewContext localViewContext = 
/* 10 */       (ViewContext)UnieapRequestContextHolder.getRequestContext().get("viewContext");
/* 11 */     return localViewContext;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.ViewContextUtil
 * JD-Core Version:    0.6.2
 */