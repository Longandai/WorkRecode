/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ import java.util.zip.ZipInputStream;
/*     */ 
/*     */ public class ZipUtil
/*     */ {
/*     */   public static String compress(String paramString)
/*     */     throws IOException
/*     */   {
/*  15 */     if ((paramString == null) || (paramString.length() == 0)) {
/*  16 */       return paramString;
/*     */     }
/*  18 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  19 */     GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
/*  20 */     localGZIPOutputStream.write(paramString.getBytes());
/*  21 */     localGZIPOutputStream.close();
/*  22 */     byte[] arrayOfByte = localByteArrayOutputStream.toByteArray();
/*  23 */     return Base64.encodeBase64String(arrayOfByte);
/*     */   }
/*     */ 
/*     */   public static String uncompress(String paramString) throws IOException
/*     */   {
/*  28 */     if ((paramString == null) || (paramString.length() == 0)) {
/*  29 */       return paramString;
/*     */     }
/*  31 */     byte[] arrayOfByte1 = Base64.decodeBase64(paramString);
/*  32 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  33 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(arrayOfByte1);
/*  34 */     GZIPInputStream localGZIPInputStream = new GZIPInputStream(localByteArrayInputStream);
/*  35 */     byte[] arrayOfByte2 = new byte[256];
/*     */     int i;
/*  37 */     while ((i = localGZIPInputStream.read(arrayOfByte2)) >= 0) {
/*  38 */       localByteArrayOutputStream.write(arrayOfByte2, 0, i);
/*     */     }
/*  40 */     return localByteArrayOutputStream.toString();
/*     */   }
/*     */ 
/*     */   public static String uncompress(String paramString1, String paramString2)
/*     */     throws IOException
/*     */   {
/*  52 */     if ((paramString1 == null) || (paramString1.length() == 0)) {
/*  53 */       return paramString1;
/*     */     }
/*  55 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*  56 */     ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramString1
/*  57 */       .getBytes("ISO-8859-1"));
/*  58 */     GZIPInputStream localGZIPInputStream = new GZIPInputStream(localByteArrayInputStream);
/*  59 */     byte[] arrayOfByte = new byte[256];
/*     */     int i;
/*  61 */     while ((i = localGZIPInputStream.read(arrayOfByte)) >= 0) {
/*  62 */       localByteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */     }
/*     */ 
/*  65 */     return localByteArrayOutputStream.toString(paramString2);
/*     */   }
/*     */ 
/*     */   public static final String decompress(byte[] paramArrayOfByte) {
/*  69 */     if (paramArrayOfByte == null) {
/*  70 */       return null; } ByteArrayOutputStream localByteArrayOutputStream = null;
/*  73 */     ByteArrayInputStream localByteArrayInputStream = null;
/*  74 */     ZipInputStream localZipInputStream = null;
/*     */     String str;
/*     */     try { localByteArrayOutputStream = new ByteArrayOutputStream();
/*  78 */       localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte);
/*  79 */       localZipInputStream = new ZipInputStream(localByteArrayInputStream);
/*  80 */       byte[] arrayOfByte = new byte[1024];
/*  81 */       int i = -1;
/*  82 */       while ((i = localZipInputStream.read(arrayOfByte)) != -1) {
/*  83 */         localByteArrayOutputStream.write(arrayOfByte, 0, i);
/*     */       }
/*  85 */       str = localByteArrayOutputStream.toString();
/*     */     } catch (IOException localIOException1) {
/*  87 */       str = null;
/*     */ 
/*  89 */       if (localZipInputStream != null)
/*     */         try {
/*  91 */           localZipInputStream.close();
/*     */         }
/*     */         catch (IOException localIOException2) {
/*     */         }
/*  95 */       if (localByteArrayInputStream != null)
/*     */         try {
/*  97 */           localByteArrayInputStream.close();
/*     */         }
/*     */         catch (IOException localIOException3) {
/*     */         }
/* 101 */       if (localByteArrayOutputStream != null)
/*     */         try {
/* 103 */           localByteArrayOutputStream.close();
/*     */         }
/*     */         catch (IOException localIOException4)
/*     */         {
/*     */         }
/*     */     }
/*     */     finally
/*     */     {
/*  89 */       if (localZipInputStream != null)
/*     */         try {
/*  91 */           localZipInputStream.close();
/*     */         }
/*     */         catch (IOException localIOException5) {
/*     */         }
/*  95 */       if (localByteArrayInputStream != null)
/*     */         try {
/*  97 */           localByteArrayInputStream.close();
/*     */         }
/*     */         catch (IOException localIOException6) {
/*     */         }
/* 101 */       if (localByteArrayOutputStream != null)
/*     */         try {
/* 103 */           localByteArrayOutputStream.close();
/*     */         }
/*     */         catch (IOException localIOException7) {
/*     */         }
/*     */     }
/* 108 */     return str;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.ZipUtil
 * JD-Core Version:    0.6.2
 */