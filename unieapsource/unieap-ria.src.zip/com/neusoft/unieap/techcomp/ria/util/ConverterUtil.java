/*     */ package com.neusoft.unieap.techcomp.ria.util;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class ConverterUtil
/*     */ {
/*     */   private static final int VARCHAR = 12;
/*     */ 
/*     */   public static Object constructObject(Object paramObject, int paramInt)
/*     */   {
/*  32 */     if (((paramObject instanceof JSONObject)) && 
/*  33 */       (((JSONObject)paramObject).isNullObject()))
/*  34 */       return null;
/*  35 */     Object localObject = null;
/*  36 */     String str = paramObject.toString();
/*  37 */     if ((str == null) || ("".equals(str))) {
/*  38 */       return str;
/*     */     }
/*  40 */     if (paramInt == 91)
/*  41 */       localObject = GMT.fromGMTToCST(Long.valueOf(str).longValue());
/*  42 */     else if (paramInt == 93)
/*  43 */       localObject = new Timestamp(GMT.fromGMTToCST(Long.valueOf(str).longValue()).getTime());
/*     */     else {
/*     */       try
/*     */       {
/*  47 */         Class localClass = Class.forName(sqlTypeToJavaType(paramInt));
/*  48 */         localObject = localClass.getConstructor(new Class[] { String.class })
/*  49 */           .newInstance(new Object[] { str });
/*     */       } catch (Exception localException) {
/*  51 */         localException.printStackTrace();
/*     */       }
/*     */     }
/*  54 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static String sqlTypeToJavaType(int paramInt)
/*     */   {
/*  67 */     switch (paramInt)
/*     */     {
/*     */     case 4:
/*  71 */       return "java.lang.Integer";
/*     */     case 8:
/*  73 */       return "java.lang.Double";
/*     */     case 6:
/*  75 */       return "java.lang.Float";
/*     */     case 3:
/*  77 */       return "java.lang.Long";
/*     */     case 5:
/*     */     case 7:
/*  80 */     }return "java.lang.String";
/*     */   }
/*     */ 
/*     */   public static int javaTypeToSqlType(String paramString)
/*     */   {
/*  93 */     int i = 12;
/*  94 */     if (paramString.equals("java.lang.Integer"))
/*  95 */       i = 4;
/*  96 */     else if (paramString.equals("java.lang.Long"))
/*  97 */       i = 4;
/*  98 */     else if (paramString.equals("java.lang.Double"))
/*  99 */       i = 8;
/* 100 */     else if (paramString.equals("java.sql.Date"))
/* 101 */       i = 91;
/* 102 */     else if (paramString.equals("java.sql.Timestamp"))
/* 103 */       i = 93;
/* 104 */     else if (paramString.equals("java.lang.Float"))
/* 105 */       i = 6;
/* 106 */     else if (paramString.equals("java.math.BigDecimal"))
/* 107 */       i = 3;
/* 108 */     else if (paramString.equals("java.math.BigInteger")) {
/* 109 */       i = -5;
/*     */     }
/*     */ 
/* 112 */     return i;
/*     */   }
/*     */ 
/*     */   public static String toValidJson(String paramString)
/*     */   {
/* 126 */     if (paramString != null) {
/* 127 */       return paramString.replaceAll("([\"\\\\])", "\\\\$1").replaceAll("[\f]", 
/* 128 */         "\\\\f").replaceAll("[\b]", "\\\\b").replaceAll("[\n]", 
/* 129 */         "\\\\n").replaceAll("[\t]", "\\\\t").replaceAll("[\r]", 
/* 130 */         "\\\\r");
/*     */     }
/* 132 */     return paramString;
/*     */   }
/*     */ 
/*     */   public static String toJson(Object paramObject)
/*     */   {
/* 150 */     if (paramObject == null) {
/* 151 */       return "null";
/*     */     }
/* 153 */     if (((paramObject instanceof Number)) || ((paramObject instanceof Boolean))) {
/* 154 */       return paramObject.toString();
/*     */     }
/* 156 */     if ((paramObject instanceof Date)) {
/* 157 */       return GMT.fromCSTToGMT((Date)paramObject);
/*     */     }
/* 159 */     return "\"" + toValidJson(paramObject.toString()) + "\"";
/*     */   }
/*     */ 
/*     */   public static Object toBaseType(Object paramObject) {
/* 163 */     if ((paramObject instanceof Date)) {
/* 164 */       return Long.valueOf(GMT.fromCSTToGMT((Date)paramObject));
/*     */     }
/* 166 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public static Object strToObj(String paramString, int paramInt)
/*     */   {
/* 181 */     if (paramString == null)
/* 182 */       return null;
/* 183 */     if ("".equals(paramString)) {
/* 184 */       return null;
/*     */     }
/* 186 */     switch (paramInt) {
/*     */     case 12:
/* 188 */       return paramString;
/*     */     case 16:
/* 190 */       return Boolean.valueOf(paramString);
/*     */     case 4:
/* 192 */       return Integer.valueOf(paramString);
/*     */     case -5:
/* 194 */       return Long.valueOf(paramString);
/*     */     case 6:
/* 196 */       return Float.valueOf(paramString);
/*     */     case 8:
/* 198 */       return Double.valueOf(paramString);
/*     */     case 3:
/* 200 */       return new BigDecimal(paramString);
/*     */     case 93:
/* 202 */       return new Timestamp(GMT.fromGMTToCST(Long.valueOf(paramString).longValue()).getTime());
/*     */     case 91:
/* 204 */       return GMT.fromGMTToCST(Long.valueOf(paramString).longValue());
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.util.ConverterUtil
 * JD-Core Version:    0.6.2
 */