/*     */ package com.neusoft.unieap.techcomp.ria.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.base.bo.BaseBO;
/*     */ import com.neusoft.unieap.core.base.model.DCRepository;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.page.Page;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.context.impl.ViewContextImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.OrderImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.PageImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.entity.Custom;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.bo.GridIndividualBO;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.struts2.interceptor.ServletRequestAware;
/*     */ import org.apache.struts2.interceptor.ServletResponseAware;
/*     */ import org.apache.struts2.interceptor.SessionAware;
/*     */ 
/*     */ public class BaseEntry extends ActionSupport
/*     */   implements ServletRequestAware, ServletResponseAware, SessionAware
/*     */ {
/*     */   private static final long serialVersionUID = -6878193283750803946L;
/*     */   public static final String DCTAG = "request-dc";
/*     */   public static final String CONTENT_TYPE = "text/html;charset=UTF-8";
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */   private Map session;
/*     */   private BaseBO baseBO;
/*     */   private GridIndividualBO gridIndividualBO;
/*     */   private EAPCacheManager eapCacheManager;
/*     */   public static final String CACHE_NAME = "gridIndividual";
/*     */ 
/*     */   public EAPCacheManager getEapCacheManager()
/*     */   {
/*  85 */     return this.eapCacheManager;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/*  89 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public GridIndividualBO getGridIndividualBO() {
/*  93 */     return this.gridIndividualBO;
/*     */   }
/*     */ 
/*     */   public void setGridIndividualBO(GridIndividualBO paramGridIndividualBO) {
/*  97 */     this.gridIndividualBO = paramGridIndividualBO;
/*     */   }
/*     */ 
/*     */   public final void setServletRequest(HttpServletRequest paramHttpServletRequest)
/*     */   {
/* 107 */     this.request = paramHttpServletRequest;
/*     */   }
/*     */ 
/*     */   public final void setServletResponse(HttpServletResponse paramHttpServletResponse)
/*     */   {
/* 117 */     this.response = paramHttpServletResponse;
/* 118 */     paramHttpServletResponse.setContentType("text/html;charset=UTF-8");
/*     */   }
/*     */ 
/*     */   public final void setSession(Map paramMap)
/*     */   {
/* 128 */     this.session = paramMap;
/*     */   }
/*     */ 
/*     */   public final HttpServletRequest getRequest()
/*     */   {
/* 135 */     return this.request;
/*     */   }
/*     */ 
/*     */   public final HttpServletResponse getResponse()
/*     */   {
/* 142 */     return this.response;
/*     */   }
/*     */ 
/*     */   public final Map getSession()
/*     */   {
/* 149 */     return this.session;
/*     */   }
/*     */ 
/*     */   private boolean isExistParameter(ViewContext paramViewContext, Object paramObject)
/*     */   {
/* 162 */     return paramViewContext.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   protected final ViewContext generateContext()
/*     */     throws Exception
/*     */   {
/* 172 */     ViewContextImpl localViewContextImpl = new ViewContextImpl();
/*     */ 
/* 174 */     DataCenter localDataCenter = DataCenterIOManager.createReader(
/* 175 */       this.request.getInputStream()).parse();
/*     */ 
/* 178 */     if (this.request.getParameter("data") != null) {
/* 179 */       localDataCenter = DataCenterIOManager.createReader(
/* 180 */         this.request.getParameter("data")).parse();
/*     */     }
/*     */ 
/* 183 */     if (this.request.getParameter("dc") != null) {
/* 184 */       localDataCenter = DataCenterIOManager.createReader(
/* 185 */         this.request.getParameter("dc")).parse();
/*     */     }
/*     */ 
/* 188 */     if (this.request.getParameter("_forwardDataCenter") != null) {
/* 189 */       localDataCenter = DataCenterIOManager.createReader(
/* 190 */         this.request.getParameter("_forwardDataCenter")).parse();
/*     */     }
/*     */ 
/* 193 */     Map localMap1 = localDataCenter.getParameters();
/* 194 */     ((ViewContextImpl)localViewContextImpl).setDc(localDataCenter);
/* 195 */     localViewContextImpl.putAll(localMap1);
/* 196 */     Map localMap2 = this.request.getParameterMap();
/* 197 */     Iterator localIterator = localMap2.entrySet().iterator();
/* 198 */     while (localIterator.hasNext()) {
/* 199 */       localObject1 = (Map.Entry)localIterator.next();
/* 200 */       localObject2 = ((Map.Entry)localObject1).getKey().toString();
/* 201 */       Object localObject3 = ((Map.Entry)localObject1).getValue();
/* 202 */       if (!"_forwardDataCenter".equals(localObject2))
/*     */       {
/* 205 */         if (localObject3.getClass().isArray()) {
/* 206 */           if (Array.getLength(localObject3) == 1)
/* 207 */             localViewContextImpl.put(localObject2, this.request.getParameter((String)localObject2));
/*     */           else
/* 209 */             localViewContextImpl.put(localObject2, localObject3);
/*     */         }
/*     */       }
/*     */     }
/* 213 */     Object localObject1 = localDataCenter.getDataStores();
/* 214 */     Object localObject2 = null;
/* 215 */     int i = 0;
/* 216 */     for (int j = 0; j < ((List)localObject1).size(); j++) {
/* 217 */       DataStore localDataStore = (DataStore)((List)localObject1).get(j);
/* 218 */       String str = localDataStore.getStoreName();
/*     */ 
/* 223 */       JSONObject localJSONObject = ((DataStoreImpl)localDataStore).getJSONObject();
/*     */ 
/* 225 */       if (localJSONObject.isNullObject()) {
/* 226 */         localViewContextImpl.put(str, null);
/*     */       } else {
/* 228 */         localViewContextImpl.put(str, localDataStore);
/* 229 */         if ((i == 0) && 
/* 230 */           (localDataStore.getPageSize() > 0) && 
/* 231 */           (localDataStore.getPageNumber() > 0)) {
/* 232 */           localObject2 = localDataStore;
/* 233 */           if (localDataStore.getPageSize() == 2147483647)
/*     */           {
/* 235 */             DCRepository.getDevelopmentComponent(Page.class);
/* 236 */             int k = CoreVariability.getGridPageSize();
/* 237 */             ((DataStore)localObject2).setPageSize(k);
/*     */           }
/* 239 */           Page localPage = createPage((DataStore)localObject2);
/* 240 */           UniEAPContextHolder.getContext().addCustomProperty(
/* 241 */             "UNIEAP_PAGE", localPage);
/* 242 */           i = 1;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 249 */     List localList = (List)this.request
/* 250 */       .getAttribute("UNIEAP_FILEATTACHMENT");
/*     */ 
/* 254 */     ((ViewContextImpl)localViewContextImpl).setFileAttachmens(localList);
/* 255 */     return localViewContextImpl;
/*     */   }
/*     */ 
/*     */   protected final void attach2Request(DataCenter paramDataCenter)
/*     */   {
/* 265 */     this.request.setAttribute("request-dc", paramDataCenter);
/*     */   }
/*     */ 
/*     */   public final BaseBO getBaseBO()
/*     */   {
/* 272 */     return this.baseBO;
/*     */   }
/*     */ 
/*     */   public final void setBaseBO(BaseBO paramBaseBO)
/*     */   {
/* 282 */     this.baseBO = paramBaseBO;
/*     */   }
/*     */ 
/*     */   protected final DataStore queryDS(DataStore paramDataStore)
/*     */   {
/* 293 */     String str1 = paramDataStore.getRowSetName();
/* 294 */     int i = paramDataStore.getPageNumber();
/* 295 */     int j = paramDataStore.getPageSize();
/* 296 */     String str2 = paramDataStore.getCondition();
/* 297 */     Object[] arrayOfObject = paramDataStore.getConditionValues().toArray();
/* 298 */     String str3 = paramDataStore.getOrder();
/* 299 */     List localList = this.baseBO.queryPOJOList(str1, str2, 
/* 300 */       arrayOfObject, str3, i, j);
/* 301 */     return PojoUtil.toDataStore(localList, paramDataStore);
/*     */   }
/*     */ 
/*     */   protected final DataCenter queryDC(DataCenter paramDataCenter)
/*     */   {
/* 312 */     DataCenterImpl localDataCenterImpl = new DataCenterImpl();
/* 313 */     List localList = paramDataCenter.getDataStores();
/* 314 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/* 315 */       DataStore localDataStore = (DataStore)localList.get(i);
/* 316 */       localDataCenterImpl.addDataStore(queryDS(localDataStore));
/*     */     }
/* 318 */     return localDataCenterImpl;
/*     */   }
/*     */ 
/*     */   protected final void countDS(DataStore paramDataStore)
/*     */   {
/* 328 */     String str1 = paramDataStore.getRowSetName();
/* 329 */     String str2 = paramDataStore.getCondition();
/* 330 */     Object[] arrayOfObject1 = paramDataStore.getConditionValues().toArray();
/* 331 */     Map localMap = paramDataStore.getStatisticsPatterns();
/* 332 */     Object[] arrayOfObject2 = this.baseBO.queryPOJOListCount(str1, str2, 
/* 333 */       arrayOfObject1, localMap);
/* 334 */     PojoUtil.assembleStatistics(paramDataStore, arrayOfObject2);
/*     */   }
/*     */ 
/*     */   protected final void countDC(DataCenter paramDataCenter)
/*     */   {
/* 344 */     List localList = paramDataCenter.getDataStores();
/* 345 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/* 346 */       DataStore localDataStore = (DataStore)localList.get(i);
/* 347 */       countDS(localDataStore);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Page createPage(DataStore paramDataStore)
/*     */   {
/* 359 */     PageImpl localPageImpl = new PageImpl();
/* 360 */     localPageImpl.setCondition(paramDataStore.getCondition());
/* 361 */     localPageImpl.setConditionValues(paramDataStore.getConditionValues());
/* 362 */     localPageImpl.setPageNumber(paramDataStore.getPageNumber());
/* 363 */     localPageImpl.setSize(paramDataStore.getPageSize());
/* 364 */     localPageImpl.setRowSetName(paramDataStore.getRowSetName());
/* 365 */     String str1 = paramDataStore.getOrder();
/* 366 */     ArrayList localArrayList = new ArrayList();
/* 367 */     if ((str1 != null) && (!"".equals(str1.trim())))
/*     */     {
/* 369 */       String[] arrayOfString1 = str1.split(",");
/* 370 */       for (int i = 0; i < arrayOfString1.length; i++) {
/* 371 */         String str2 = arrayOfString1[i].trim();
/* 372 */         String[] arrayOfString2 = str2.split(" ");
/* 373 */         OrderImpl localOrderImpl = new OrderImpl();
/* 374 */         localOrderImpl.setOrderStyle(arrayOfString2[(arrayOfString2.length - 1)]);
/* 375 */         localOrderImpl.setPropertyName(arrayOfString2[0]);
/* 376 */         localArrayList.add(localOrderImpl);
/*     */       }
/*     */     }
/* 379 */     localPageImpl.setOrders(localArrayList);
/* 380 */     return localPageImpl;
/*     */   }
/*     */ 
/*     */   protected final void getIndividual(DataCenter paramDataCenter)
/*     */   {
/* 385 */     String str1 = (String)paramDataCenter.getParameter("path");
/* 386 */     String str2 = (String)paramDataCenter.getParameter("userId");
/* 387 */     Object localObject1 = (Map)this.eapCacheManager.get("gridIndividual");
/* 388 */     if (localObject1 == null) {
/* 389 */       localObject1 = new HashMap();
/* 390 */       this.eapCacheManager.put("gridIndividual", localObject1, false);
/*     */     }
/* 392 */     List localList = (List)((Map)localObject1).get(str2);
/* 393 */     if (localList == null) {
/* 394 */       localList = this.gridIndividualBO.getIndividualByUser(str2);
/* 395 */       ((Map)localObject1).put(str2, localList);
/*     */     }
/* 397 */     ArrayList localArrayList = new ArrayList();
/* 398 */     if (str1 == null) {
/* 399 */       str1 = "";
/*     */     }
/* 401 */     for (int i = 0; i < localList.size(); i++) {
/* 402 */       localObject2 = (Custom)localList.get(i);
/* 403 */       if (str1.equals(((Custom)localObject2).getPath())) {
/* 404 */         localArrayList.add(localObject2);
/*     */       }
/*     */     }
/* 407 */     String str3 = "";
/* 408 */     Object localObject2 = new JSONObject();
/* 409 */     if ((localArrayList != null) && (localArrayList.size() > 0)) {
/* 410 */       int j = localArrayList.size();
/* 411 */       for (int k = 0; k < j; k++) {
/* 412 */         ((JSONObject)localObject2).put(((Custom)localArrayList.get(k)).getCmpId(), 
/* 413 */           ((Custom)localArrayList.get(k)).getContent());
/*     */       }
/* 415 */       str3 = ((JSONObject)localObject2).toString();
/*     */     }
/* 417 */     paramDataCenter.addParameter("individual", str3);
/*     */   }
/*     */ 
/*     */   protected final void setIndividual(DataCenter paramDataCenter) {
/* 421 */     String str1 = (String)paramDataCenter.getParameter("path");
/* 422 */     String str2 = (String)paramDataCenter.getParameter("userId");
/* 423 */     String str3 = paramDataCenter.getParameter("content").toString();
/* 424 */     String str4 = (String)paramDataCenter.getParameter("cmpId");
/* 425 */     if ("[]".equals(str3)) {
/* 426 */       this.gridIndividualBO.delIndividual(str2, str1, str4);
/*     */     } else {
/* 428 */       localObject1 = this.gridIndividualBO.getIndividual(str2, str1, str4);
/* 429 */       if ((localObject1 == null) || (((List)localObject1).size() == 0)) {
/* 430 */         localObject2 = new Custom();
/* 431 */         ((Custom)localObject2).setCmpId(str4);
/* 432 */         ((Custom)localObject2).setContent(str3);
/* 433 */         ((Custom)localObject2).setPath(str1);
/* 434 */         ((Custom)localObject2).setUserId(str2);
/* 435 */         this.gridIndividualBO.saveIndividual(localObject2);
/*     */       } else {
/* 437 */         this.gridIndividualBO.updateIndividual(str2, str1, str4, str3);
/*     */       }
/*     */     }
/*     */ 
/* 441 */     Object localObject1 = (Map)this.eapCacheManager.get("gridIndividual");
/* 442 */     if (localObject1 == null) {
/* 443 */       localObject1 = new HashMap();
/* 444 */       this.eapCacheManager.put("gridIndividual", localObject1, false);
/*     */     }
/* 446 */     Object localObject2 = this.gridIndividualBO.getIndividualByUser(str2);
/* 447 */     ((Map)localObject1).put(str2, localObject2);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.action.BaseEntry
 * JD-Core Version:    0.6.2
 */