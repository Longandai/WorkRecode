/*     */ package com.neusoft.unieap.techcomp.ria.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.bo.BaseBO;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class BaseProcessor extends BaseEntry
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   protected void write(DataCenter paramDataCenter)
/*     */     throws Exception
/*     */   {
/*  34 */     DataCenterWriter localDataCenterWriter = 
/*  35 */       DataCenterIOManager.createWriter(getResponse().getOutputStream());
/*  36 */     localDataCenterWriter.write(paramDataCenter);
/*  37 */     localDataCenterWriter.close();
/*     */   }
/*     */ 
/*     */   public void query()
/*     */     throws Exception
/*     */   {
/*  46 */     ViewContext localViewContext = generateContext();
/*  47 */     DataCenter localDataCenter = queryDC(localViewContext.getDataCenter());
/*     */ 
/*  49 */     if ("true".equals(localViewContext.getString("synCount"))) {
/*  50 */       countDC(localDataCenter);
/*     */     }
/*  52 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void count()
/*     */     throws Exception
/*     */   {
/*  62 */     ViewContext localViewContext = generateContext();
/*  63 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/*  64 */     countDC(localDataCenter);
/*  65 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void update()
/*     */     throws Exception
/*     */   {
/*  74 */     ViewContext localViewContext = generateContext();
/*  75 */     List localList = localViewContext.getDataStores();
/*  76 */     DataCenterImpl localDataCenterImpl = new DataCenterImpl();
/*     */ 
/*  78 */     List[] arrayOfList1 = new List[localList.size()];
/*  79 */     List[] arrayOfList2 = new List[localList.size()];
/*  80 */     List[] arrayOfList3 = new List[localList.size()];
/*     */ 
/*  82 */     int i = 0;
/*     */     Object localObject;
/*  82 */     for (int j = localList.size(); i < j; i++) {
/*  83 */       DataStore localDataStore1 = (DataStore)localList.get(i);
/*  84 */       localObject = localDataStore1.getStoreName();
/*  85 */       arrayOfList1[i] = localViewContext.getNewPOJOList((String)localObject);
/*  86 */       arrayOfList2[i] = localViewContext.getUpdatePOJOList((String)localObject);
/*  87 */       arrayOfList3[i] = localViewContext.getDeletePOJOList((String)localObject);
/*     */     }
/*  89 */     List[] arrayOfList4 = getBaseBO().save(arrayOfList1, 
/*  90 */       arrayOfList2, arrayOfList3);
/*     */ 
/*  92 */     j = 0; for (int k = arrayOfList4.length; j < k; j++) {
/*  93 */       localObject = (DataStore)localList.get(j);
/*  94 */       MetaData localMetaData = ((DataStore)localObject).getMetaData();
/*  95 */       if ((localMetaData != null) && (localMetaData.containsPrimaryKey())) {
/*  96 */         String str = localMetaData.getPrimaryKey();
/*  97 */         DataStore localDataStore2 = PojoUtil.getQueryDataStore((DataStore)localObject);
/*  98 */         for (int m = 0; m < arrayOfList4[j].size(); m++) {
/*  99 */           HashMap localHashMap = new HashMap();
/* 100 */           localHashMap.put(str, arrayOfList4[j].get(m));
/* 101 */           localDataStore2.getRowSet().addRowData(localHashMap);
/*     */         }
/* 103 */         localDataCenterImpl.addDataStore(localDataStore2);
/*     */       }
/*     */     }
/* 106 */     write(localDataCenterImpl);
/*     */   }
/*     */ 
/*     */   public void getIndividual()
/*     */     throws Exception
/*     */   {
/* 115 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 116 */     String str1 = localUser.getAccount();
/* 117 */     ViewContext localViewContext = generateContext();
/* 118 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/* 119 */     String str2 = localViewContext.getString("path");
/* 120 */     localDataCenter.addParameter("path", str2);
/* 121 */     localDataCenter.addParameter("userId", str1);
/* 122 */     getIndividual(localDataCenter);
/* 123 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void setIndividual()
/*     */     throws Exception
/*     */   {
/* 132 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 133 */     String str1 = localUser.getAccount();
/* 134 */     ViewContext localViewContext = generateContext();
/* 135 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/*     */ 
/* 137 */     String str2 = localViewContext.getString("id");
/*     */ 
/* 139 */     String str3 = localViewContext.getString("path");
/* 140 */     String str4 = localViewContext.get("individual").toString();
/* 141 */     localDataCenter.addParameter("path", str3);
/* 142 */     localDataCenter.addParameter("userId", str1);
/* 143 */     localDataCenter.addParameter("content", str4);
/* 144 */     localDataCenter.addParameter("cmpId", str2);
/* 145 */     setIndividual(localDataCenter);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.action.BaseProcessor
 * JD-Core Version:    0.6.2
 */