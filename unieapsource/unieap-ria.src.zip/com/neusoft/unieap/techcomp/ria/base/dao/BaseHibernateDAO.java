/*     */ package com.neusoft.unieap.techcomp.ria.base.dao;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.page.PageUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.util.AutoQueryUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.hibernate.metadata.ClassMetadata;
/*     */ import org.hibernate.type.BigDecimalType;
/*     */ import org.hibernate.type.DateType;
/*     */ import org.hibernate.type.IntegerType;
/*     */ import org.hibernate.type.LongType;
/*     */ import org.hibernate.type.ManyToOneType;
/*     */ import org.hibernate.type.OneToOneType;
/*     */ import org.hibernate.type.StringType;
/*     */ import org.hibernate.type.TimestampType;
/*     */ import org.hibernate.type.TrueFalseType;
/*     */ import org.hibernate.type.Type;
/*     */ 
/*     */ public class BaseHibernateDAO extends com.neusoft.unieap.core.base.dao.BaseHibernateDAO
/*     */ {
/*     */   public QueryResult autoQueryByPage(Map<String, String> paramMap, Integer paramInteger1, Integer paramInteger2)
/*     */   {
/*  44 */     ArrayList localArrayList = new ArrayList();
/*  45 */     String str = getAutoQueryHQL(paramMap, localArrayList, "");
/*  46 */     if (paramInteger1 != null)
/*  47 */       PageUtil.setPageNumber(paramInteger1.intValue());
/*  48 */     if (paramInteger2 != null)
/*  49 */       PageUtil.setPageSize(paramInteger2.intValue());
/*  50 */     return queryObjectsByPage(str, localArrayList.toArray());
/*     */   }
/*     */ 
/*     */   public QueryResult autoQueryByPage(Map<String, String> paramMap)
/*     */   {
/*  59 */     ArrayList localArrayList = new ArrayList();
/*  60 */     String str = getAutoQueryHQL(paramMap, localArrayList, "");
/*  61 */     return queryObjectsByPage(str, localArrayList.toArray());
/*     */   }
/*     */ 
/*     */   public List autoQuery(Map<String, String> paramMap)
/*     */   {
/*  70 */     ArrayList localArrayList = new ArrayList();
/*  71 */     String str = getAutoQueryHQL(paramMap, localArrayList, "");
/*  72 */     return queryObjects(str, localArrayList.toArray());
/*     */   }
/*     */ 
/*     */   private String getAutoQueryHQL(Map<String, String> paramMap, List<Object> paramList, String paramString)
/*     */   {
/* 126 */     if ((paramString == null) || ("".equals(paramString.trim()))) {
/* 127 */       paramString = "t";
/*     */     }
/* 129 */     String str1 = AutoQueryUtil.getQueryClassName(paramMap);
/* 130 */     if ((str1 == null) || ("".equals(str1)) || (str1.equals(HashMap.class.getName()))) {
/* 131 */       throw new RIAException(
/* 132 */         "EAPTECH008015", new Object[0]);
/*     */     }
/* 134 */     String str2 = AutoQueryUtil.getJoinFetchInfo(paramMap);
/* 135 */     String str3 = "select " + paramString + " from " + str1 + " " + paramString + " ";
/* 136 */     ClassMetadata localClassMetadata = getSessionFactory().getClassMetadata(str1);
/* 137 */     if (StringUtils.isNotBlank(str2)) {
/* 138 */       String[] arrayOfString1 = str2.split(",");
/* 139 */       for (String str4 : arrayOfString1) {
/* 140 */         Boolean localBoolean = isFetchProperty(localClassMetadata, str4);
/* 141 */         if (!localBoolean.booleanValue()) {
/* 142 */           throw new RIAException(
/* 143 */             "EAPTECH008014", new Object[0]);
/*     */         }
/* 145 */         str3 = str3 + "left outer join fetch " + paramString + "." + str4 + " ";
/*     */       }
/*     */     }
/* 148 */     str3 = str3 + "where " + getAutoConditionWhere(paramMap, paramList, paramString, localClassMetadata);
/* 149 */     str3 = getAutoQueryOrderHQL(paramMap, paramString, str3, localClassMetadata);
/* 150 */     return str3;
/*     */   }
/*     */ 
/*     */   private String getAutoQueryOrderHQL(Map<String, String> paramMap, String paramString1, String paramString2, ClassMetadata paramClassMetadata)
/*     */   {
/* 155 */     String str1 = AutoQueryUtil.getOrders(paramMap);
/* 156 */     Set localSet = paramMap.keySet();
/* 157 */     if (StringUtils.isNotBlank(str1)) {
/* 158 */       String[] arrayOfString = str1.split(",");
/* 159 */       paramString2 = paramString2 + "order by ";
/* 160 */       for (int i = 0; i < arrayOfString.length; i++) {
/* 161 */         String str2 = arrayOfString[i].trim();
/* 162 */         String str3 = "";
/* 163 */         if (str2.endsWith("asc"))
/* 164 */           str3 = str2.substring(0, str2.length() - 3).trim();
/* 165 */         else if (str2.endsWith("desc"))
/* 166 */           str3 = str2.substring(0, str2.length() - 4).trim();
/*     */         else {
/* 168 */           throw new RIAException(
/* 169 */             "EAPTECH008014", new Object[0]);
/*     */         }
/* 171 */         if ((localSet == null) || (!localSet.contains(str3))) {
/* 172 */           getPropertyType(paramClassMetadata, str3);
/*     */         }
/* 174 */         if (i != arrayOfString.length - 1)
/* 175 */           paramString2 = paramString2 + paramString1 + "." + str2 + ",";
/*     */         else {
/* 177 */           paramString2 = paramString2 + paramString1 + "." + str2;
/*     */         }
/*     */       }
/*     */     }
/* 181 */     return paramString2;
/*     */   }
/*     */ 
/*     */   private String getAutoConditionWhere(Map<String, String> paramMap, List<Object> paramList, String paramString, ClassMetadata paramClassMetadata)
/*     */   {
/* 186 */     Map localMap1 = AutoQueryUtil.getFakeInfo(paramMap);
/* 187 */     Map localMap2 = AutoQueryUtil.getOperators(paramMap);
/* 188 */     List localList = Arrays.asList(AutoQueryUtil.OPERATORS);
/* 189 */     String str1 = "1=1";
/* 190 */     Set localSet = paramMap.keySet();
/* 191 */     if (paramMap != null) {
/* 192 */       localSet = paramMap.keySet();
/* 193 */       for (String str2 : localSet)
/* 194 */         if (!"pojoContext".equals(str2))
/*     */         {
/* 196 */           String str3 = (String)paramMap.get(str2);
/* 197 */           String str4 = (String)localMap2.get(str2);
/* 198 */           if (localMap1.containsKey(str2))
/* 199 */             str2 = (String)localMap1.get(str2);
/* 200 */           if (StringUtils.isNotBlank(str3)) {
/* 201 */             Type localType = getPropertyType(paramClassMetadata, str2);
/* 202 */             if (str4 == null)
/* 203 */               str4 = "=";
/* 204 */             if ("llike".equals(str4)) {
/* 205 */               str1 = str1 + "and " + paramString + "." + str2 + " like ? ";
/* 206 */               str3 = "%" + str3;
/* 207 */             } else if ("rlike".equals(str4)) {
/* 208 */               str1 = str1 + "and " + paramString + "." + str2 + " like ? ";
/* 209 */               str3 = str3 + "%";
/* 210 */             } else if ("like".equals(str4)) {
/* 211 */               str1 = str1 + "and " + paramString + "." + str2 + " like ? ";
/* 212 */               str3 = "%" + str3 + "%";
/*     */             }
/* 214 */             else if (localList.contains(str4)) {
/* 215 */               str1 = str1 + "and " + paramString + "." + str2 + " " + str4 + " ? ";
/*     */             } else {
/* 217 */               throw new RIAException(
/* 218 */                 "EAPTECH008014", new Object[0]);
/*     */             }
/*     */ 
/* 221 */             if ((localType instanceof StringType)) {
/* 222 */               paramList.add(str3);
/* 223 */             } else if ((localType instanceof LongType)) {
/* 224 */               paramList.add(Long.valueOf(Long.parseLong(str3)));
/* 225 */             } else if ((localType instanceof IntegerType)) {
/* 226 */               paramList.add(Integer.valueOf(Integer.parseInt(str3)));
/* 227 */             } else if ((localType instanceof BigDecimalType)) {
/* 228 */               paramList.add(new BigDecimal(str3));
/* 229 */             } else if ((localType instanceof DateType)) {
/* 230 */               paramList.add(new Date(Long.parseLong(str3)));
/* 231 */             } else if ((localType instanceof TimestampType)) {
/* 232 */               paramList.add(new Timestamp(Long.parseLong(str3)));
/* 233 */             } else if ((localType instanceof TrueFalseType)) {
/* 234 */               TrueFalseType localTrueFalseType = new TrueFalseType();
/* 235 */               paramList.add(localTrueFalseType.fromStringValue(str3));
/*     */             }
/*     */           }
/*     */         }
/*     */     }
/* 240 */     return str1;
/*     */   }
/*     */ 
/*     */   private Type getPropertyType(ClassMetadata paramClassMetadata, String paramString) {
/* 244 */     if (paramString.indexOf(".") != -1) {
/* 245 */       String str1 = paramString.substring(0, paramString.indexOf("."));
/* 246 */       String str2 = paramString.substring(paramString.indexOf(".") + 1);
/* 247 */       ManyToOneType localManyToOneType = (ManyToOneType)paramClassMetadata.getPropertyType(str1);
/* 248 */       ClassMetadata localClassMetadata = getSessionFactory().getClassMetadata(localManyToOneType.getAssociatedEntityName());
/* 249 */       return getPropertyType(localClassMetadata, str2);
/*     */     }
/*     */     try {
/* 252 */       return paramClassMetadata.getPropertyType(paramString); } catch (HibernateException localHibernateException) {
/*     */     }
/* 254 */     throw new RIAException(
/* 255 */       "EAPTECH008014", new Object[0]);
/*     */   }
/*     */ 
/*     */   private Boolean isFetchProperty(ClassMetadata paramClassMetadata, String paramString)
/*     */   {
/*     */     Object localObject;
/* 261 */     if (paramString.indexOf(".") != -1) {
/* 262 */       localObject = paramString.substring(0, paramString.indexOf("."));
/* 263 */       String str = paramString.substring(paramString.indexOf(".") + 1);
/* 264 */       ManyToOneType localManyToOneType = (ManyToOneType)paramClassMetadata.getPropertyType((String)localObject);
/* 265 */       ClassMetadata localClassMetadata = getSessionFactory().getClassMetadata(localManyToOneType.getAssociatedEntityName());
/* 266 */       return isFetchProperty(localClassMetadata, str);
/*     */     }
/*     */     try {
/* 269 */       localObject = paramClassMetadata.getPropertyType(paramString);
/* 270 */       if (((localObject instanceof ManyToOneType)) || ((localObject instanceof OneToOneType))) {
/* 271 */         return Boolean.valueOf(true);
/*     */       }
/* 273 */       return Boolean.valueOf(false);
/*     */     } catch (HibernateException localHibernateException) {
/*     */     }
/* 276 */     throw new RIAException(
/* 277 */       "EAPTECH008014", new Object[0]);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.base.dao.BaseHibernateDAO
 * JD-Core Version:    0.6.2
 */