/*    */ package com.neusoft.unieap.techcomp.ria.richeditor.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("upInfotipAttachment.entity")
/*    */ public class UpInfotipAttachment
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String infotipId;
/*    */   private String fileName;
/*    */   private byte[] content;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 31 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 35 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setInfotipId(String paramString) {
/* 39 */     this.infotipId = paramString;
/*    */   }
/*    */ 
/*    */   public String getInfotipId() {
/* 43 */     return this.infotipId;
/*    */   }
/*    */ 
/*    */   public void setFileName(String paramString) {
/* 47 */     this.fileName = paramString;
/*    */   }
/*    */ 
/*    */   public String getFileName() {
/* 51 */     return this.fileName;
/*    */   }
/*    */ 
/*    */   public void setContent(byte[] paramArrayOfByte) {
/* 55 */     this.content = paramArrayOfByte;
/*    */   }
/*    */ 
/*    */   public byte[] getContent() {
/* 59 */     return this.content;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment
 * JD-Core Version:    0.6.2
 */