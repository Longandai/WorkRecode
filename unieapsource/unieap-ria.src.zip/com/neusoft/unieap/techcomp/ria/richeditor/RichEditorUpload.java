package com.neusoft.unieap.techcomp.ria.richeditor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public abstract interface RichEditorUpload
{
  public abstract void upload(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.RichEditorUpload
 * JD-Core Version:    0.6.2
 */