package com.neusoft.unieap.techcomp.ria.richeditor;

import java.util.HashMap;

public abstract interface RichEditorConfig
{
  public abstract String getBaseDir();

  public abstract void setBaseDir(String paramString);

  public abstract String getAllowedExtensionsFile();

  public abstract String getDeniedExtensionsFile();

  public abstract String getAllowedExtensionsImage();

  public abstract String getDeniedExtensionsImage();

  public abstract String getAllowedExtensionsFlash();

  public abstract String getDeniedExtensionsFlash();

  public abstract HashMap getOtherProp();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.RichEditorConfig
 * JD-Core Version:    0.6.2
 */