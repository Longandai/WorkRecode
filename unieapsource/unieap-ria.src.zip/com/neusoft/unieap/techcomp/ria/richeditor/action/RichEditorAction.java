/*    */ package com.neusoft.unieap.techcomp.ria.richeditor.action;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.InfotipConfig;
/*    */ import com.neusoft.unieap.techcomp.ria.help.helpUtil.HelpConfig;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorUpload;
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import com.opensymphony.xwork2.inject.Inject;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.interceptor.ServletRequestAware;
/*    */ import org.apache.struts2.interceptor.ServletResponseAware;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class RichEditorAction extends ActionSupport
/*    */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*    */ {
/*    */   private static final long serialVersionUID = -5560721990786836931L;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private ApplicationContext applicationContext;
/* 38 */   private String maxFileSize = null;
/*    */   RichEditorUpload richEditorUpload;
/*    */ 
/*    */   @Inject("struts.multipart.maxSize")
/*    */   public void setMaxFileSize(String paramString)
/*    */   {
/* 43 */     this.maxFileSize = paramString;
/*    */   }
/*    */ 
/*    */   public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
/* 47 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 51 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 56 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   public String richEditorUpload()
/*    */     throws Exception
/*    */   {
/* 62 */     if (this.richEditorUpload == null) {
/* 63 */       String str1 = InfotipConfig.getValue("附件上传方式");
/* 64 */       String str2 = "richEditorUploadToServer";
/* 65 */       if (this.request.getParameter("uploadParameter") != null)
/*    */       {
/* 67 */         if (str1 != null)
/*    */         {
/* 69 */           if (("infotip"
/* 69 */             .equals(this.request.getParameter("uploadParameter"))) && 
/* 70 */             ("数据库".equals(str1))) {
/* 71 */             str2 = "richEditorUploadToDB";
/*    */           }
/*    */         }
/*    */ 
/* 75 */         String str3 = HelpConfig.getValue("uploadType");
/*    */ 
/* 77 */         if ((str3 != null) && 
/* 78 */           (this.request.getParameter("uploadParameter").contains("helpId")) && 
/* 79 */           ("DBUpload".equals(str3))) {
/* 80 */           str2 = "helpAttachmentUpload";
/*    */         }
/*    */       }
/*    */ 
/* 84 */       this.richEditorUpload = 
/* 85 */         ((RichEditorUpload)this.applicationContext
/* 85 */         .getBean(str2));
/*    */     }
/* 87 */     if (this.richEditorUpload != null) {
/* 88 */       this.richEditorUpload.upload(this.request, this.response, this.maxFileSize);
/*    */     }
/* 90 */     return "none";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.action.RichEditorAction
 * JD-Core Version:    0.6.2
 */