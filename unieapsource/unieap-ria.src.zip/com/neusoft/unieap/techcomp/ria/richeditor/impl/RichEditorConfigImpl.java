/*     */ package com.neusoft.unieap.techcomp.ria.richeditor.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorConfig;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class RichEditorConfigImpl
/*     */   implements RichEditorConfig
/*     */ {
/*     */   public String baseDir;
/*     */   public String allowedExtensionsFile;
/*     */   public String deniedExtensionsFile;
/*     */   public String allowedExtensionsImage;
/*     */   public String deniedExtensionsImage;
/*     */   public String allowedExtensionsFlash;
/*     */   public String deniedExtensionsFlash;
/*  15 */   public HashMap otherProp = null;
/*     */ 
/*     */   public String getBaseDir()
/*     */   {
/*  22 */     return this.baseDir;
/*     */   }
/*     */ 
/*     */   public void setBaseDir(String paramString)
/*     */   {
/*  30 */     this.baseDir = paramString;
/*     */   }
/*     */ 
/*     */   public String getAllowedExtensionsFile()
/*     */   {
/*  38 */     return this.allowedExtensionsFile;
/*     */   }
/*     */ 
/*     */   public void setAllowedExtensionsFile(String paramString)
/*     */   {
/*  46 */     this.allowedExtensionsFile = paramString;
/*     */   }
/*     */ 
/*     */   public String getDeniedExtensionsFile()
/*     */   {
/*  54 */     return this.deniedExtensionsFile;
/*     */   }
/*     */ 
/*     */   public void setDeniedExtensionsFile(String paramString)
/*     */   {
/*  62 */     this.deniedExtensionsFile = paramString;
/*     */   }
/*     */ 
/*     */   public String getAllowedExtensionsImage()
/*     */   {
/*  70 */     return this.allowedExtensionsImage;
/*     */   }
/*     */ 
/*     */   public void setAllowedExtensionsImage(String paramString)
/*     */   {
/*  78 */     this.allowedExtensionsImage = paramString;
/*     */   }
/*     */ 
/*     */   public String getDeniedExtensionsImage()
/*     */   {
/*  86 */     return this.deniedExtensionsImage;
/*     */   }
/*     */ 
/*     */   public void setDeniedExtensionsImage(String paramString)
/*     */   {
/*  94 */     this.deniedExtensionsImage = paramString;
/*     */   }
/*     */ 
/*     */   public String getAllowedExtensionsFlash()
/*     */   {
/* 102 */     return this.allowedExtensionsFlash;
/*     */   }
/*     */ 
/*     */   public void setAllowedExtensionsFlash(String paramString)
/*     */   {
/* 110 */     this.allowedExtensionsFlash = paramString;
/*     */   }
/*     */ 
/*     */   public String getDeniedExtensionsFlash()
/*     */   {
/* 118 */     return this.deniedExtensionsFlash;
/*     */   }
/*     */ 
/*     */   public void setDeniedExtensionsFlash(String paramString)
/*     */   {
/* 126 */     this.deniedExtensionsFlash = paramString;
/*     */   }
/*     */ 
/*     */   public HashMap getOtherProp()
/*     */   {
/* 134 */     return this.otherProp;
/*     */   }
/*     */ 
/*     */   public void setOtherProp(HashMap paramHashMap)
/*     */   {
/* 142 */     this.otherProp = paramHashMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.impl.RichEditorConfigImpl
 * JD-Core Version:    0.6.2
 */