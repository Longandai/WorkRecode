/*    */ package com.neusoft.unieap.techcomp.ria.richeditor.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.dao.RicheditorDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("RicheditorDAO.dao")
/*    */ public class RicheditorDAOImpl extends BaseHibernateDAO
/*    */   implements RicheditorDAO
/*    */ {
/*    */   public void saveOrUpdate(UpInfotipAttachment paramUpInfotipAttachment)
/*    */   {
/* 22 */     getHibernateTemplate().saveOrUpdate(paramUpInfotipAttachment);
/*    */   }
/*    */ 
/*    */   public UpInfotipAttachment getAttachment(String paramString) {
/* 26 */     String str = "from UpInfotipAttachment upInfotipAttachment where upInfotipAttachment.id = ?";
/* 27 */     List localList = queryObjects(str, paramString);
/* 28 */     if (localList.size() > 0)
/* 29 */       return (UpInfotipAttachment)localList.get(0);
/* 30 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.dao.impl.RicheditorDAOImpl
 * JD-Core Version:    0.6.2
 */