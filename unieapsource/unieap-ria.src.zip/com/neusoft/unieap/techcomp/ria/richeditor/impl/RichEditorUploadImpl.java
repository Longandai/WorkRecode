/*     */ package com.neusoft.unieap.techcomp.ria.richeditor.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.core.fileupload.impl.FileAttachmentImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorConfig;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorUpload;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class RichEditorUploadImpl
/*     */   implements RichEditorUpload
/*     */ {
/*     */   public RichEditorConfig config;
/*     */   public Hashtable allowedExtensions;
/*     */   public Hashtable deniedExtensions;
/*  39 */   String retVal = "0";
/*  40 */   String errorMessage = "";
/*     */ 
/*     */   public void upload(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */   {
/*  50 */     if (!(paramHttpServletRequest instanceof MultiPartRequestWrapper))
/*     */     {
/*  52 */       return;
/*     */     }
/*  54 */     paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/*  55 */     String str1 = "";
/*  56 */     String str2 = "";
/*  57 */     InputStream localInputStream = null;
/*  58 */     FileOutputStream localFileOutputStream = null;
/*  59 */     PrintWriter localPrintWriter = null;
/*  60 */     MultiPartRequestWrapper localMultiPartRequestWrapper = (MultiPartRequestWrapper)paramHttpServletRequest;
/*     */     try {
/*  62 */       localPrintWriter = paramHttpServletResponse.getWriter();
/*     */     } catch (IOException localIOException1) {
/*  64 */       localIOException1.printStackTrace();
/*     */     }
/*     */     Object localObject1;
/*  66 */     if (localMultiPartRequestWrapper.hasErrors()) {
/*  67 */       handleError(localMultiPartRequestWrapper, paramString);
/*     */     }
/*     */     else {
/*  70 */       localObject1 = localMultiPartRequestWrapper
/*  71 */         .getFileParameterNames();
/*  72 */       ArrayList localArrayList = new ArrayList();
/*  73 */       if ((localObject1 != null) && 
/*  74 */         (((Enumeration)localObject1).hasMoreElements()))
/*     */       {
/*     */         int i;
/*  75 */         for (; ((Enumeration)localObject1).hasMoreElements(); 
/*  80 */           i < localObject3.length)
/*     */         {
/*  76 */           str3 = 
/*  77 */             (String)((Enumeration)localObject1)
/*  77 */             .nextElement();
/*  78 */           localObject2 = localMultiPartRequestWrapper.getFileNames(str3);
/*  79 */           localObject3 = localMultiPartRequestWrapper.getFiles(str3);
/*  80 */           i = 0; continue;
/*  81 */           if (localObject3[i].exists())
/*     */           {
/*     */             try {
/*  84 */               localObject4 = new FileAttachmentImpl(
/*  85 */                 str3, 
/*  86 */                 FileUtils.openInputStream(localObject3[i]), 
/*  87 */                 localObject3[i].length(), localObject2[i]);
/*  88 */               localArrayList.add(localObject4);
/*     */             } catch (IOException localIOException2) {
/*  90 */               localIOException2.printStackTrace();
/*     */             }
/*  92 */             localObject3[i].delete();
/*     */           }
/*  80 */           i++;
/*     */         }
/*     */ 
/*  96 */         paramHttpServletRequest.setAttribute("UNIEAP_FILEATTACHMENT", 
/*  97 */           localArrayList);
/*     */       }
/*     */ 
/* 100 */       String str3 = paramHttpServletRequest.getParameter("Type");
/* 101 */       Object localObject2 = paramHttpServletRequest.getParameter("number");
/* 102 */       Object localObject3 = this.config.getBaseDir() + str3;
/* 103 */       String str4 = paramHttpServletRequest.getSession().getServletContext()
/* 104 */         .getRealPath((String)localObject3);
/* 105 */       localObject3 = paramHttpServletRequest.getContextPath() + (String)localObject3;
/* 106 */       if (localObject2 != null) {
/* 107 */         str4 = str4 + "\\" + (String)localObject2;
/* 108 */         localObject3 = localObject3 + "/" + (String)localObject2;
/*     */       }
/*     */ 
/* 111 */       Object localObject4 = System.getProperties().getProperty("os.name");
/* 112 */       if (!((String)localObject4).contains("Windows"))
/*     */       {
/* 114 */         str4 = str4.replace("/", File.separator);
/* 115 */         localObject3 = ((String)localObject3).replace("/", File.separator);
/*     */       }
/*     */       try {
/* 118 */         if ((localArrayList != null) && (localArrayList.size() > 0)) {
/* 119 */           FileAttachment localFileAttachment = 
/* 120 */             (FileAttachment)localArrayList
/* 120 */             .get(0);
/* 121 */           if (localFileAttachment != null) {
/* 122 */             String str5 = localFileAttachment.getFileName();
/* 123 */             String str6 = getExtension(str5);
/* 124 */             File localFile1 = new File(str4);
/* 125 */             if (!localFile1.exists()) {
/* 126 */               localFile1.mkdirs();
/*     */             }
/* 128 */             Date localDate = new Date();
/* 129 */             long l = localDate.getTime();
/* 130 */             str1 = l + "." + str6;
/* 131 */             File localFile2 = new File(str4, str1);
/* 132 */             if (!localFile2.exists()) {
/* 133 */               localFile2.createNewFile();
/*     */             }
/* 135 */             str2 = localObject3 + "/" + str1;
/* 136 */             if (!((String)localObject4).contains("Windows")) {
/* 137 */               str2 = str2.replace("/", File.separator);
/*     */             }
/* 139 */             if (extIsAllowed(str3, str6)) {
/* 140 */               localInputStream = localFileAttachment.getInputStream();
/* 141 */               localFileOutputStream = new FileOutputStream(localFile2);
/* 142 */               int j = 0;
/* 143 */               while ((j = localInputStream.read()) != -1)
/* 144 */                 localFileOutputStream.write(j);
/*     */             }
/*     */             else {
/* 147 */               this.retVal = "202";
/* 148 */               this.errorMessage = "";
/*     */             }
/*     */           }
/*     */         }
/*     */       } catch (Exception localException) {
/* 153 */         localException.printStackTrace();
/* 154 */         this.retVal = "203";
/*     */         try
/*     */         {
/* 157 */           if (localInputStream != null) {
/* 158 */             localInputStream.close();
/*     */           }
/* 160 */           if (localFileOutputStream != null)
/* 161 */             localFileOutputStream.close();
/*     */         }
/*     */         catch (IOException localIOException3) {
/* 164 */           localIOException3.printStackTrace();
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 157 */           if (localInputStream != null) {
/* 158 */             localInputStream.close();
/*     */           }
/* 160 */           if (localFileOutputStream != null)
/* 161 */             localFileOutputStream.close();
/*     */         }
/*     */         catch (IOException localIOException4) {
/* 164 */           localIOException4.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 168 */     if (localPrintWriter != null)
/*     */     {
/* 175 */       localObject1 = ServletActionContext.getRequest().getParameter("CKEditorFuncNum");
/* 176 */       localPrintWriter.println("<script type=\"text/javascript\">");
/* 177 */       localPrintWriter.println("window.parent.CKEDITOR.tools.callFunction(" + (String)localObject1 + ",'" + str2 + "','')");
/* 178 */       localPrintWriter.println("</script>");
/* 179 */       localPrintWriter.flush();
/* 180 */       localPrintWriter.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void handleError(MultiPartRequestWrapper paramMultiPartRequestWrapper, String paramString)
/*     */   {
/* 195 */     StringBuffer localStringBuffer = new StringBuffer();
/* 196 */     Iterator localIterator = paramMultiPartRequestWrapper.getErrors().iterator();
/* 197 */     while (localIterator.hasNext()) {
/* 198 */       localStringBuffer.append((String)localIterator.next());
/* 199 */       localStringBuffer.append("\n");
/*     */     }
/*     */ 
/* 202 */     if (localStringBuffer.toString().contains("exceeds the configured maximum")) {
/* 203 */       this.retVal = "204";
/* 204 */       if ((paramString != null) && (paramString.length() > 0) && 
/* 205 */         (Long.parseLong(paramString) > 0L)) {
/* 206 */         Long localLong = Long.valueOf(Long.parseLong(paramString) / 1024L / 1024L);
/* 207 */         this.errorMessage = String.valueOf(localLong.intValue());
/*     */       }
/*     */     } else {
/* 210 */       this.retVal = "203";
/*     */     }
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/* 216 */     if (this.config.getBaseDir() == null)
/* 217 */       this.config.setBaseDir("/UserFiles/");
/* 218 */     this.allowedExtensions = new Hashtable(3);
/* 219 */     this.deniedExtensions = new Hashtable(3);
/*     */ 
/* 221 */     this.allowedExtensions.put("File", stringToArrayList(this.config
/* 222 */       .getAllowedExtensionsFile()));
/* 223 */     this.deniedExtensions.put("File", stringToArrayList(this.config
/* 224 */       .getDeniedExtensionsFile()));
/*     */ 
/* 226 */     this.allowedExtensions.put("Image", stringToArrayList(this.config
/* 227 */       .getAllowedExtensionsImage()));
/* 228 */     this.deniedExtensions.put("Image", stringToArrayList(this.config
/* 229 */       .getDeniedExtensionsImage()));
/*     */ 
/* 231 */     this.allowedExtensions.put("Flash", stringToArrayList(this.config
/* 232 */       .getAllowedExtensionsFlash()));
/* 233 */     this.deniedExtensions.put("Flash", stringToArrayList(this.config
/* 234 */       .getDeniedExtensionsFlash()));
/*     */   }
/*     */ 
/*     */   private String getExtension(String paramString)
/*     */   {
/* 240 */     return paramString.substring(paramString.lastIndexOf(".") + 1);
/*     */   }
/*     */ 
/*     */   private ArrayList stringToArrayList(String paramString)
/*     */   {
/* 245 */     String[] arrayOfString = paramString.split("\\|");
/*     */ 
/* 247 */     ArrayList localArrayList = new ArrayList();
/* 248 */     if (paramString.length() > 0) {
/* 249 */       for (int i = 0; i < arrayOfString.length; i++) {
/* 250 */         localArrayList.add(arrayOfString[i].toLowerCase());
/*     */       }
/*     */     }
/* 253 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private boolean extIsAllowed(String paramString1, String paramString2)
/*     */   {
/* 258 */     paramString2 = paramString2.toLowerCase();
/* 259 */     ArrayList localArrayList1 = (ArrayList)this.allowedExtensions.get(paramString1);
/* 260 */     ArrayList localArrayList2 = (ArrayList)this.deniedExtensions.get(paramString1);
/* 261 */     if (localArrayList1.size() == 0) {
/* 262 */       if (localArrayList2.contains(paramString2)) {
/* 263 */         return false;
/*     */       }
/* 265 */       return true;
/* 266 */     }if (localArrayList2.size() == 0) {
/* 267 */       if (localArrayList1.contains(paramString2)) {
/* 268 */         return true;
/*     */       }
/* 270 */       return false;
/* 271 */     }return false;
/*     */   }
/*     */ 
/*     */   public RichEditorConfig getConfig()
/*     */   {
/* 276 */     return this.config;
/*     */   }
/*     */ 
/*     */   public void setConfig(RichEditorConfig paramRichEditorConfig)
/*     */   {
/* 285 */     this.config = paramRichEditorConfig;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.impl.RichEditorUploadImpl
 * JD-Core Version:    0.6.2
 */