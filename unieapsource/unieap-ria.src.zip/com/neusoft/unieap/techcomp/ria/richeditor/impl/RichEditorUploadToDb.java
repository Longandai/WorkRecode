/*     */ package com.neusoft.unieap.techcomp.ria.richeditor.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.core.fileupload.impl.FileAttachmentImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorConfig;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.bo.RicheditorBO;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class RichEditorUploadToDb extends RichEditorUploadImpl
/*     */ {
/*     */   RicheditorBO richeditorBo;
/*     */ 
/*     */   public RicheditorBO getRicheditorBo()
/*     */   {
/*  30 */     return this.richeditorBo;
/*     */   }
/*     */ 
/*     */   public void setRicheditorBo(RicheditorBO paramRicheditorBO) {
/*  34 */     this.richeditorBo = paramRicheditorBO;
/*     */   }
/*     */ 
/*     */   public void upload(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */   {
/*  45 */     if (!(paramHttpServletRequest instanceof MultiPartRequestWrapper))
/*     */     {
/*  47 */       return;
/*     */     }
/*  49 */     paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/*     */ 
/*  51 */     String str1 = "";
/*  52 */     String str2 = "";
/*     */ 
/*  54 */     InputStream localInputStream = null;
/*  55 */     ByteArrayOutputStream localByteArrayOutputStream = null;
/*  56 */     PrintWriter localPrintWriter = null;
/*  57 */     MultiPartRequestWrapper localMultiPartRequestWrapper = (MultiPartRequestWrapper)paramHttpServletRequest;
/*     */     try {
/*  59 */       localPrintWriter = paramHttpServletResponse.getWriter();
/*     */     } catch (IOException localIOException1) {
/*  61 */       localIOException1.printStackTrace();
/*     */     }
/*     */     Object localObject1;
/*  63 */     if (localMultiPartRequestWrapper.hasErrors()) {
/*  64 */       handleError(localMultiPartRequestWrapper, paramString);
/*     */     } else {
/*  66 */       localObject1 = localMultiPartRequestWrapper
/*  67 */         .getFileParameterNames();
/*  68 */       ArrayList localArrayList = new ArrayList();
/*  69 */       if ((localObject1 != null) && 
/*  70 */         (((Enumeration)localObject1).hasMoreElements()))
/*     */       {
/*     */         int i;
/*  71 */         for (; ((Enumeration)localObject1).hasMoreElements(); 
/*  76 */           i < localObject3.length)
/*     */         {
/*  72 */           str3 = 
/*  73 */             (String)((Enumeration)localObject1)
/*  73 */             .nextElement();
/*  74 */           localObject2 = localMultiPartRequestWrapper.getFileNames(str3);
/*  75 */           localObject3 = localMultiPartRequestWrapper.getFiles(str3);
/*  76 */           i = 0; continue;
/*  77 */           if (localObject3[i].exists())
/*     */           {
/*     */             try {
/*  80 */               localObject4 = new FileAttachmentImpl(
/*  81 */                 str3, 
/*  82 */                 FileUtils.openInputStream(localObject3[i]), 
/*  83 */                 localObject3[i].length(), localObject2[i]);
/*  84 */               localArrayList.add(localObject4);
/*     */             } catch (IOException localIOException2) {
/*  86 */               localIOException2.printStackTrace();
/*     */             }
/*  88 */             localObject3[i].delete();
/*     */           }
/*  76 */           i++;
/*     */         }
/*     */ 
/*  92 */         paramHttpServletRequest.setAttribute("UNIEAP_FILEATTACHMENT", 
/*  93 */           localArrayList);
/*     */       }
/*     */ 
/*  96 */       String str3 = paramHttpServletRequest.getParameter("Type");
/*  97 */       Object localObject2 = paramHttpServletRequest.getParameter("number");
/*  98 */       Object localObject3 = this.config.getBaseDir() + str3;
/*  99 */       String str4 = paramHttpServletRequest.getSession().getServletContext()
/* 100 */         .getRealPath((String)localObject3);
/* 101 */       localObject3 = paramHttpServletRequest.getContextPath() + (String)localObject3;
/* 102 */       if (localObject2 != null) {
/* 103 */         str4 = str4 + "\\" + (String)localObject2;
/* 104 */         localObject3 = localObject3 + "/" + (String)localObject2;
/*     */       }
/* 106 */       Object localObject4 = System.getProperties().getProperty("os.name");
/* 107 */       if (!((String)localObject4).contains("Windows"))
/*     */       {
/* 109 */         str4 = str4.replace("/", File.separator);
/* 110 */         localObject3 = ((String)localObject3).replace("/", File.separator);
/*     */       }
/*     */       try {
/* 113 */         if ((localArrayList != null) && (localArrayList.size() > 0)) {
/* 114 */           FileAttachment localFileAttachment = 
/* 115 */             (FileAttachment)localArrayList
/* 115 */             .get(0);
/*     */           try {
/* 117 */             localInputStream = localFileAttachment.getInputStream();
/* 118 */             localByteArrayOutputStream = new ByteArrayOutputStream();
/*     */ 
/* 120 */             byte[] arrayOfByte1 = new byte[localInputStream.available()];
/*     */ 
/* 122 */             while (-1 != localInputStream.read(arrayOfByte1)) {
/* 123 */               localByteArrayOutputStream.write(arrayOfByte1);
/*     */             }
/*     */ 
/* 126 */             byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
/*     */ 
/* 128 */             UpInfotipAttachment localUpInfotipAttachment = new UpInfotipAttachment();
/* 129 */             localUpInfotipAttachment.setContent(arrayOfByte2);
/* 130 */             localUpInfotipAttachment.setFileName(localFileAttachment.getFileName());
/* 131 */             this.richeditorBo.saveOrUpdate(localUpInfotipAttachment);
/* 132 */             if (str3.equals("Image")) {
/* 133 */               str2 = "../../techcomp/ria/fileDownloadAction.action?id=" + 
/* 134 */                 localUpInfotipAttachment.getId();
/*     */             }
/*     */             else
/*     */             {
/* 141 */               str2 = "/fileDownloadAction.action?id=" + 
/* 142 */                 localUpInfotipAttachment.getId();
/*     */             }
/*     */ 
/* 145 */             localInputStream.close();
/* 146 */             localByteArrayOutputStream.close();
/*     */           } catch (Exception localException2) {
/* 148 */             localException2.printStackTrace();
/*     */           }
/*     */         }
/*     */       } catch (Exception localException1) {
/* 152 */         localException1.printStackTrace();
/*     */         try
/*     */         {
/* 156 */           if ((localInputStream != null) && (localByteArrayOutputStream != null)) {
/* 157 */             localInputStream.close();
/* 158 */             localByteArrayOutputStream.close();
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException3) {
/* 162 */           localIOException3.printStackTrace();
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 156 */           if ((localInputStream != null) && (localByteArrayOutputStream != null)) {
/* 157 */             localInputStream.close();
/* 158 */             localByteArrayOutputStream.close();
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException4) {
/* 162 */           localIOException4.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 166 */     if (localPrintWriter != null)
/*     */     {
/* 169 */       localObject1 = ServletActionContext.getRequest().getParameter("CKEditorFuncNum");
/* 170 */       localPrintWriter.println("<script type=\"text/javascript\">");
/* 171 */       localPrintWriter.println("window.parent.CKEDITOR.tools.callFunction(" + (String)localObject1 + ",'" + str2 + str1 + "','')");
/*     */ 
/* 180 */       localPrintWriter.println("</script>");
/* 181 */       localPrintWriter.flush();
/* 182 */       localPrintWriter.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.impl.RichEditorUploadToDb
 * JD-Core Version:    0.6.2
 */