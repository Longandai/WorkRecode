/*    */ package com.neusoft.unieap.techcomp.ria.richeditor.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.bo.RicheditorBO;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.dao.RicheditorDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment;
/*    */ 
/*    */ @ModelFile("richeditorBO.bo")
/*    */ public class RicheditorBOImpl
/*    */   implements RicheditorBO
/*    */ {
/*    */   RicheditorDAO richeditorDao;
/*    */ 
/*    */   public RicheditorDAO getRicheditorDao()
/*    */   {
/* 24 */     return this.richeditorDao;
/*    */   }
/*    */ 
/*    */   public void setRicheditorDao(RicheditorDAO paramRicheditorDAO) {
/* 28 */     this.richeditorDao = paramRicheditorDAO;
/*    */   }
/*    */ 
/*    */   public void saveOrUpdate(UpInfotipAttachment paramUpInfotipAttachment)
/*    */   {
/* 36 */     this.richeditorDao.saveOrUpdate(paramUpInfotipAttachment);
/*    */   }
/*    */ 
/*    */   public UpInfotipAttachment getAttachment(String paramString) {
/* 40 */     return this.richeditorDao.getAttachment(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.bo.impl.RicheditorBOImpl
 * JD-Core Version:    0.6.2
 */