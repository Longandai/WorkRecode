package com.neusoft.unieap.techcomp.ria.richeditor.dao;

import com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment;

public abstract interface RicheditorDAO
{
  public abstract void saveOrUpdate(UpInfotipAttachment paramUpInfotipAttachment);

  public abstract UpInfotipAttachment getAttachment(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.richeditor.dao.RicheditorDAO
 * JD-Core Version:    0.6.2
 */