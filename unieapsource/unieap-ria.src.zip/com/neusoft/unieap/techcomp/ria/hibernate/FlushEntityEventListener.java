/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import com.neusoft.unieap.core.transaction.TransactionDateUtil;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.util.List;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.def.DefaultFlushEntityEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.tuple.StandardProperty;
/*    */ import org.hibernate.tuple.entity.EntityMetamodel;
/*    */ 
/*    */ public class FlushEntityEventListener extends DefaultFlushEntityEventListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   protected boolean invokeInterceptor(SessionImplementor paramSessionImplementor, Object paramObject, EntityEntry paramEntityEntry, Object[] paramArrayOfObject, EntityPersister paramEntityPersister)
/*    */   {
/* 41 */     boolean bool = super.invokeInterceptor(paramSessionImplementor, paramObject, 
/* 42 */       paramEntityEntry, paramArrayOfObject, paramEntityPersister);
/*    */ 
/* 44 */     List localList = 
/* 45 */       TransactionDateUtil.getTransactionDateProperties(paramObject, 
/* 46 */       "update");
/* 47 */     if ((localList != null) && 
/* 48 */       (localList.size() > 0)) {
/* 49 */       localObject = paramEntityPersister.getEntityMetamodel()
/* 50 */         .getProperties();
/* 51 */       for (PropertyDescriptor localPropertyDescriptor : localList)
/*    */       {
/* 53 */         TransactionDateUtil.setTransactionDate(paramObject, localPropertyDescriptor);
/*    */ 
/* 55 */         String str = localPropertyDescriptor.getName();
/* 56 */         if ((localObject != null) && (localObject.length > 0)) {
/* 57 */           int i = 0; for (int j = localObject.length; i < j; i++) {
/* 58 */             if (localObject[i].getName().equals(str))
/*    */             {
/* 60 */               paramArrayOfObject[i] = paramEntityPersister.getPropertyValue(paramObject, i, 
/* 61 */                 paramSessionImplementor.getEntityMode());
/* 62 */               break;
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/* 67 */       bool = true;
/*    */     }
/* 69 */     Object localObject = HistoryUtil.getHistoryClass(paramObject.getClass());
/* 70 */     if ((localObject != null) && (((String)localObject).length() > 0)) {
/* 71 */       HistoryUtil.saveHistory((Session)paramSessionImplementor, paramObject, (String)localObject, 
/* 72 */         "update");
/*    */     }
/* 74 */     return bool;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.FlushEntityEventListener
 * JD-Core Version:    0.6.2
 */