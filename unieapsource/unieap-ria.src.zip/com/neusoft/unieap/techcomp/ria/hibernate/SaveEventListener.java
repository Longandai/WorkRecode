/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import com.neusoft.unieap.core.transaction.TransactionDateUtil;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.def.DefaultSaveEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.tuple.StandardProperty;
/*    */ import org.hibernate.tuple.entity.EntityMetamodel;
/*    */ 
/*    */ public class SaveEventListener extends DefaultSaveEventListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   protected boolean substituteValuesIfNecessary(Object paramObject, Serializable paramSerializable, Object[] paramArrayOfObject, EntityPersister paramEntityPersister, SessionImplementor paramSessionImplementor)
/*    */   {
/* 39 */     boolean bool = super
/* 40 */       .substituteValuesIfNecessary(paramObject, paramSerializable, paramArrayOfObject, paramEntityPersister, 
/* 41 */       paramSessionImplementor);
/* 42 */     String str1 = HistoryUtil.getHistoryClass(paramObject.getClass());
/*    */ 
/* 44 */     List localList = 
/* 45 */       TransactionDateUtil.getTransactionDateProperties(paramObject, 
/* 46 */       "insert");
/* 47 */     if ((localList != null) && 
/* 48 */       (localList.size() > 0)) {
/* 49 */       StandardProperty[] arrayOfStandardProperty = paramEntityPersister.getEntityMetamodel()
/* 50 */         .getProperties();
/* 51 */       for (PropertyDescriptor localPropertyDescriptor : localList)
/*    */       {
/* 53 */         TransactionDateUtil.setTransactionDate(paramObject, localPropertyDescriptor);
/*    */ 
/* 55 */         String str2 = localPropertyDescriptor.getName();
/* 56 */         if ((arrayOfStandardProperty != null) && (arrayOfStandardProperty.length > 0)) {
/* 57 */           int i = 0; for (int j = arrayOfStandardProperty.length; i < j; i++) {
/* 58 */             if (arrayOfStandardProperty[i].getName().equals(str2))
/*    */             {
/* 60 */               paramArrayOfObject[i] = paramEntityPersister.getPropertyValue(paramObject, i, 
/* 61 */                 paramSessionImplementor.getEntityMode());
/* 62 */               break;
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/* 67 */       bool = true;
/*    */     }
/*    */ 
/* 70 */     if ((str1 != null) && (str1.length() > 0)) {
/* 71 */       HistoryUtil.saveHistory((Session)paramSessionImplementor, paramObject, str1, 
/* 72 */         "insert");
/*    */     }
/* 74 */     return bool;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.SaveEventListener
 * JD-Core Version:    0.6.2
 */