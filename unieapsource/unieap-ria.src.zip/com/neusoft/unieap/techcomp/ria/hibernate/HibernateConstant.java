package com.neusoft.unieap.techcomp.ria.hibernate;

public abstract interface HibernateConstant
{
  public static final int PERSISTENT = 0;
  public static final int TRANSIENT = 1;
  public static final int DETACHED = 2;
  public static final int DELETED = 3;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.HibernateConstant
 * JD-Core Version:    0.6.2
 */