/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.History;
/*    */ import com.neusoft.unieap.core.annotation.TransactionDate;
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.sql.Time;
/*    */ import java.sql.Timestamp;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.beans.BeanUtils;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ 
/*    */ public class HistoryUtil
/*    */   implements HibernateConstant
/*    */ {
/*    */   public static final String HISTORY_UPDATE = "update";
/*    */   public static final String HISTORY_INSERT = "insert";
/*    */   public static final String HISTORY_DELETE = "delete";
/*    */   public static final String HISTORY_PROPERTY_OPERATION = "hOperation";
/*    */   public static final String HISTORY_PROPERTY_LAST_UPDATE_BY = "hLastUpdatedBy";
/*    */   public static final String HISTORY_PROPERTY_LAST_UPDATE_DATE = "hLastUpdatedDate";
/* 29 */   static final Log logger = LogFactory.getLog(HistoryUtil.class);
/*    */ 
/*    */   public static void saveHistory(Session paramSession, Object paramObject, String paramString1, String paramString2)
/*    */   {
/*    */     try {
/*    */       try {
/* 35 */         if ((paramString2 != null) && (paramString2.length() > 0)) {
/* 36 */           Object localObject1 = Class.forName(paramString1)
/* 37 */             .newInstance();
/*    */ 
/* 39 */           BeanUtils.copyProperties(paramObject, localObject1);
/* 40 */           User localUser = 
/* 41 */             UniEAPContextHolder.getContext().getCurrentUser();
/*    */ 
/* 43 */           if (AnnotationUtils.findAnnotation(
/* 44 */             PropertyUtils.getPropertyDescriptor(localObject1, 
/* 45 */             "hLastUpdatedDate")
/* 46 */             .getWriteMethod(), TransactionDate.class) == null) {
/* 47 */             long l = new java.util.Date().getTime();
/* 48 */             Object localObject2 = null;
/* 49 */             Class localClass = PropertyUtils.getPropertyType(
/* 50 */               localObject1, 
/* 51 */               "hLastUpdatedDate");
/* 52 */             if (localClass == java.util.Date.class)
/* 53 */               localObject2 = new java.util.Date(l);
/* 54 */             else if (localClass == java.sql.Date.class)
/* 55 */               localObject2 = new java.sql.Date(l);
/* 56 */             else if (localClass == Timestamp.class)
/* 57 */               localObject2 = new Timestamp(l);
/* 58 */             else if (localClass == Time.class) {
/* 59 */               localObject2 = new Time(l);
/*    */             }
/* 61 */             PropertyUtils.setProperty(localObject1, 
/* 62 */               "hLastUpdatedDate", localObject2);
/*    */           }
/* 64 */           PropertyUtils.setProperty(localObject1, 
/* 65 */             "hLastUpdatedBy", localUser
/* 66 */             .getAccount());
/* 67 */           PropertyUtils.setProperty(localObject1, 
/* 68 */             "hOperation", paramString2);
/*    */ 
/* 70 */           paramSession.save(localObject1);
/* 71 */           logger.info("保存" + paramObject.getClass().getCanonicalName() + 
/* 72 */             "的历史数据，操作为：" + paramString2 + "!");
/*    */         }
/*    */       } catch (InstantiationException localInstantiationException) {
/* 75 */         localInstantiationException.printStackTrace();
/*    */       } catch (IllegalAccessException localIllegalAccessException) {
/* 77 */         localIllegalAccessException.printStackTrace();
/*    */       } catch (InvocationTargetException localInvocationTargetException) {
/* 79 */         localInvocationTargetException.printStackTrace();
/*    */       } catch (NoSuchMethodException localNoSuchMethodException) {
/* 81 */         localNoSuchMethodException.printStackTrace();
/*    */       }
/*    */     } catch (ClassNotFoundException localClassNotFoundException) {
/* 84 */       localClassNotFoundException.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static String getHistoryClass(Class paramClass) {
/* 89 */     History localHistory = (History)AnnotationUtils.findAnnotation(paramClass, 
/* 90 */       History.class);
/* 91 */     if (localHistory != null) {
/* 92 */       return localHistory.entity();
/*    */     }
/* 94 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.HistoryUtil
 * JD-Core Version:    0.6.2
 */