/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import com.neusoft.unieap.core.transaction.TransactionDateUtil;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.event.def.DefaultSaveOrUpdateEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ import org.hibernate.tuple.StandardProperty;
/*    */ import org.hibernate.tuple.entity.EntityMetamodel;
/*    */ 
/*    */ public class SaveOrUpdateEventListener extends DefaultSaveOrUpdateEventListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   protected boolean substituteValuesIfNecessary(Object paramObject, Serializable paramSerializable, Object[] paramArrayOfObject, EntityPersister paramEntityPersister, SessionImplementor paramSessionImplementor)
/*    */   {
/* 38 */     boolean bool = super
/* 39 */       .substituteValuesIfNecessary(paramObject, paramSerializable, paramArrayOfObject, paramEntityPersister, 
/* 40 */       paramSessionImplementor);
/* 41 */     String str1 = HistoryUtil.getHistoryClass(paramObject.getClass());
/*    */ 
/* 43 */     List localList = 
/* 44 */       TransactionDateUtil.getTransactionDateProperties(paramObject, 
/* 45 */       "insert");
/* 46 */     if ((localList != null) && 
/* 47 */       (localList.size() > 0)) {
/* 48 */       StandardProperty[] arrayOfStandardProperty = paramEntityPersister.getEntityMetamodel()
/* 49 */         .getProperties();
/* 50 */       for (PropertyDescriptor localPropertyDescriptor : localList)
/*    */       {
/* 52 */         TransactionDateUtil.setTransactionDate(paramObject, localPropertyDescriptor);
/*    */ 
/* 54 */         String str2 = localPropertyDescriptor.getName();
/* 55 */         if ((arrayOfStandardProperty != null) && (arrayOfStandardProperty.length > 0)) {
/* 56 */           int i = 0; for (int j = arrayOfStandardProperty.length; i < j; i++) {
/* 57 */             if (arrayOfStandardProperty[i].getName().equals(str2))
/*    */             {
/* 59 */               paramArrayOfObject[i] = paramEntityPersister.getPropertyValue(paramObject, i, 
/* 60 */                 paramSessionImplementor.getEntityMode());
/* 61 */               break;
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/* 66 */       bool = true;
/*    */     }
/*    */ 
/* 69 */     if ((str1 != null) && (str1.length() > 0)) {
/* 70 */       HistoryUtil.saveHistory((Session)paramSessionImplementor, paramObject, str1, 
/* 71 */         "insert");
/*    */     }
/* 73 */     return bool;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.SaveOrUpdateEventListener
 * JD-Core Version:    0.6.2
 */