/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import org.hibernate.event.EventSource;
/*    */ import org.hibernate.event.def.DefaultDeleteEventListener;
/*    */ import org.hibernate.persister.entity.EntityPersister;
/*    */ 
/*    */ public class DeleteEventListener extends DefaultDeleteEventListener
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   protected boolean invokeDeleteLifecycle(EventSource paramEventSource, Object paramObject, EntityPersister paramEntityPersister)
/*    */   {
/* 26 */     boolean bool = super.invokeDeleteLifecycle(paramEventSource, 
/* 27 */       paramObject, paramEntityPersister);
/* 28 */     if (!bool) {
/* 29 */       String str = 
/* 30 */         HistoryUtil.getHistoryClass(paramObject.getClass());
/* 31 */       if ((str != null) && (str.length() > 0)) {
/* 32 */         HistoryUtil.saveHistory(paramEventSource, paramObject, str, 
/* 33 */           "delete");
/*    */       }
/*    */     }
/* 36 */     return bool;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.DeleteEventListener
 * JD-Core Version:    0.6.2
 */