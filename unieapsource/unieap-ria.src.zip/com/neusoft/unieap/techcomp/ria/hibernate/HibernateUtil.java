/*    */ package com.neusoft.unieap.techcomp.ria.hibernate;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.util.PojoContextUtil;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.engine.EntityEntry;
/*    */ import org.hibernate.engine.ForeignKeys;
/*    */ import org.hibernate.engine.PersistenceContext;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.engine.Status;
/*    */ 
/*    */ public class HibernateUtil
/*    */   implements HibernateConstant
/*    */ {
/*    */   public static int getEntityState(Session paramSession, Object paramObject, String paramString)
/*    */   {
/* 24 */     SessionImplementor localSessionImplementor = (SessionImplementor)paramSession;
/* 25 */     EntityEntry localEntityEntry = localSessionImplementor
/* 26 */       .getPersistenceContext().getEntry(paramObject);
/* 27 */     if (localEntityEntry != null)
/*    */     {
/* 29 */       if (localEntityEntry.getStatus() != Status.DELETED)
/*    */       {
/* 31 */         return 0;
/*    */       }
/*    */ 
/* 34 */       return 3;
/*    */     }
/*    */ 
/* 41 */     if (PojoContextUtil.getOriginPojo(paramObject) != null) {
/* 42 */       return 2;
/*    */     }
/*    */ 
/* 45 */     if (PojoContextUtil.isNewModified(paramObject)) {
/* 46 */       return 1;
/*    */     }
/*    */ 
/* 49 */     if (ForeignKeys.isTransient(paramString, paramObject, null, localSessionImplementor)) {
/* 50 */       return 1;
/*    */     }
/* 52 */     return 2;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.hibernate.HibernateUtil
 * JD-Core Version:    0.6.2
 */