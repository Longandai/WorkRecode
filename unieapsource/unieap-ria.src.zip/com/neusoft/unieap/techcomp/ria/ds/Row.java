package com.neusoft.unieap.techcomp.ria.ds;

import java.util.Date;

public abstract interface Row
{
  public static final String ORIGIN = "_o";
  public static final String STATUS = "_t";
  public static final String SELECTED = "_s";
  public static final int NEWMODIFIED = 1;
  public static final int NOTMODIFIED = 2;
  public static final int DATAMODIFIED = 3;

  public abstract boolean isNewModify();

  public abstract boolean isDataModify();

  public abstract boolean isNotModify();

  public abstract int getRowStatus();

  public abstract boolean isSeleted();

  public abstract boolean isPropertyModify(String paramString);

  public abstract Object getItemValue(String paramString);

  public abstract void setItemValue(String paramString, Object paramObject);

  public abstract Object getOrigValue(String paramString);

  public abstract void setSelected(boolean paramBoolean);

  public abstract int getRowIndex();

  public abstract void setRowStatus(int paramInt);

  public abstract void resetUpdate();

  public abstract int getInt(String paramString);

  public abstract float getFloat(String paramString);

  public abstract double getDouble(String paramString);

  public abstract Date getDate(String paramString);

  public abstract String getString(String paramString);

  public abstract boolean getBoolean(String paramString);

  public abstract long getLong(String paramString);

  public abstract void setInt(String paramString, Integer paramInteger);

  public abstract void setFloat(String paramString, Float paramFloat);

  public abstract void setDouble(String paramString, Double paramDouble);

  public abstract void setDate(String paramString, Date paramDate);

  public abstract void setString(String paramString1, String paramString2);

  public abstract void setBoolean(String paramString, Boolean paramBoolean);

  public abstract void setLong(String paramString, Long paramLong);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.Row
 * JD-Core Version:    0.6.2
 */