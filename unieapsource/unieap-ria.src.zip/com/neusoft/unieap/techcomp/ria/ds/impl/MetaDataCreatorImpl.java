/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.validation.BeanValidator;
/*     */ import com.neusoft.unieap.core.validation.BeanValidatorFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaDataCreator;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MetaDataCreatorImpl
/*     */   implements MetaDataCreator
/*     */ {
/*  22 */   private static Map<String, MetaData> metaDataCache = new HashMap();
/*     */ 
/*     */   public MetaData afterRowSetNameSetted(String paramString) {
/*  25 */     BeanValidator localBeanValidator = BeanValidatorFactory.getBeanValidator();
/*  26 */     if ((paramString == null) || ("".equals(paramString.trim())) || 
/*  27 */       (localBeanValidator.getConstraints(paramString) == null)) {
/*  28 */       return null;
/*     */     }
/*  30 */     if (metaDataCache.containsKey(paramString)) {
/*  31 */       return (MetaData)metaDataCache.get(paramString);
/*     */     }
/*  33 */     Set localSet = null;
/*  34 */     Class localClass1 = null;
/*     */     try {
/*  36 */       localSet = PojoUtil.getEntityProperties(localClass1 = 
/*  37 */         Class.forName(paramString));
/*  38 */       MetaDataImpl localMetaDataImpl = new MetaDataImpl();
/*  39 */       for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/*  40 */         String str1 = (String)localIterator.next();
/*  41 */         Class localClass2 = localClass1;
/*  42 */         String str2 = str1;
/*     */         Object localObject2;
/*  43 */         if (str1.indexOf(".") > 0) {
/*  44 */           localObject1 = str1.split("\\.");
/*  45 */           for (int i = 0; i < localObject1.length - 1; i++) {
/*  46 */             localObject2 = getFieldFromClass(localClass2, localObject1[i].trim());
/*  47 */             localClass2 = ((Field)localObject2).getType();
/*     */           }
/*  49 */           str2 = localObject1[(localObject1.length - 1)];
/*     */         }
/*  51 */         Object localObject1 = localBeanValidator.getConstraints(localClass2.getName());
/*     */ 
/*  53 */         str2 = PojoUtil.getStandardBeanName(str2);
/*     */         Map localMap;
/*  55 */         if (((localMap = (Map)((Map)localObject1).get("get".concat(str2))) != null) || 
/*  56 */           ((localMap = (Map)((Map)localObject1).get("is"
/*  57 */           .concat(str2))) != null))
/*     */         {
/*  59 */           localObject2 = createColumn(str1, localMap);
/*  60 */           localMetaDataImpl.addColumn((Column)localObject2);
/*     */         }
/*     */       }
/*  62 */       metaDataCache.put(paramString, localMetaDataImpl);
/*  63 */       return localMetaDataImpl;
/*     */     } catch (Exception localException) {
/*  65 */       localException.printStackTrace();
/*     */     }
/*     */ 
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   private Field getFieldFromClass(Class paramClass, String paramString) {
/*  72 */     Field localField = null;
/*     */     try
/*     */     {
/*  75 */       localField = paramClass.getDeclaredField(paramString);
/*     */     } catch (SecurityException localSecurityException) {
/*  77 */       localSecurityException.printStackTrace();
/*     */     } catch (NoSuchFieldException localNoSuchFieldException) {
/*  79 */       if (paramClass == Object.class)
/*  80 */         localNoSuchFieldException.printStackTrace();
/*     */       else {
/*  82 */         return getFieldFromClass(paramClass.getSuperclass(), paramString);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  87 */     return localField;
/*     */   }
/*     */ 
/*     */   private Column createColumn(String paramString, Map paramMap) {
/*  91 */     ColumnImpl localColumnImpl = new ColumnImpl();
/*  92 */     localColumnImpl.setName(paramString);
/*     */     Map localMap;
/*     */     Object localObject1;
/*     */     Object localObject2;
/*  94 */     if (paramMap.containsKey("max")) {
/*  95 */       localMap = (Map)paramMap.get("max");
/*  96 */       localObject1 = (Number)localMap.get("value");
/*  97 */       localColumnImpl.setMax((Number)localObject1);
/*  98 */       localObject2 = 
/*  99 */         (String)localMap
/*  99 */         .get("prompts");
/* 100 */       localColumnImpl.setPrompt("max", (String)localObject2);
/*     */     }
/*     */ 
/* 103 */     if (paramMap.containsKey("min")) {
/* 104 */       localMap = (Map)paramMap.get("min");
/* 105 */       localObject1 = (Number)localMap.get("value");
/* 106 */       localColumnImpl.setMin((Number)localObject1);
/* 107 */       localObject2 = 
/* 108 */         (String)localMap
/* 108 */         .get("prompts");
/* 109 */       localColumnImpl.setPrompt("min", (String)localObject2);
/*     */     }
/*     */ 
/* 112 */     if (paramMap.containsKey("decimalMax")) {
/* 113 */       localMap = 
/* 114 */         (Map)paramMap
/* 114 */         .get("decimalMax");
/* 115 */       localObject1 = new Float(localMap.get("value"));
/*     */ 
/* 117 */       localColumnImpl.setMax((Number)localObject1);
/* 118 */       localObject2 = 
/* 119 */         (String)localMap
/* 119 */         .get("prompts");
/* 120 */       localColumnImpl.setPrompt("max", (String)localObject2);
/*     */     }
/*     */ 
/* 123 */     if (paramMap.containsKey("decimalMin")) {
/* 124 */       localMap = 
/* 125 */         (Map)paramMap
/* 125 */         .get("decimalMin");
/* 126 */       localObject1 = new Float(localMap.get("value"));
/*     */ 
/* 128 */       localColumnImpl.setMin((Number)localObject1);
/* 129 */       localObject2 = 
/* 130 */         (String)localMap
/* 130 */         .get("prompts");
/* 131 */       localColumnImpl.setPrompt("min", (String)localObject2);
/*     */     }
/*     */ 
/* 134 */     if (paramMap.containsKey("range")) {
/* 135 */       localMap = (Map)paramMap.get("range");
/* 136 */       if (localMap.containsKey("max")) {
/* 137 */         localObject1 = (Number)localMap.get("max");
/* 138 */         localColumnImpl.setRangeMax((Number)localObject1);
/*     */       }
/* 140 */       if (localMap.containsKey("min")) {
/* 141 */         localObject1 = (Number)localMap.get("min");
/* 142 */         localColumnImpl.setRangeMin((Number)localObject1);
/*     */       }
/* 144 */       localObject1 = 
/* 145 */         (String)localMap
/* 145 */         .get("prompts");
/* 146 */       localColumnImpl.setPrompt("range", (String)localObject1);
/*     */     }
/*     */ 
/* 149 */     if (paramMap.containsKey("past")) {
/* 150 */       localMap = (Map)paramMap.get("past");
/* 151 */       localColumnImpl.setPast(new Date());
/* 152 */       localObject1 = 
/* 153 */         (String)localMap
/* 153 */         .get("prompts");
/* 154 */       localColumnImpl.setPrompt("past", (String)localObject1);
/*     */     }
/*     */ 
/* 157 */     if (paramMap.containsKey("future")) {
/* 158 */       localMap = (Map)paramMap.get("future");
/* 159 */       localColumnImpl.setFuture(new Date());
/* 160 */       localObject1 = 
/* 161 */         (String)localMap
/* 161 */         .get("prompts");
/* 162 */       localColumnImpl.setPrompt("future", (String)localObject1);
/*     */     }
/*     */ 
/* 165 */     if (paramMap.containsKey("notNull")) {
/* 166 */       localMap = (Map)paramMap.get("notNull");
/* 167 */       localColumnImpl.setNullable(false);
/* 168 */       localObject1 = 
/* 169 */         (String)localMap
/* 169 */         .get("prompts");
/* 170 */       localColumnImpl.setPrompt("nullable", (String)localObject1);
/*     */     }
/*     */ 
/* 173 */     if (paramMap.containsKey("pattern")) {
/* 174 */       localMap = (Map)paramMap.get("pattern");
/* 175 */       localObject1 = (String)localMap.get("regesp");
/* 176 */       localColumnImpl.setPattern((String)localObject1);
/* 177 */       localObject2 = 
/* 178 */         (String)localMap
/* 178 */         .get("prompts");
/* 179 */       localColumnImpl.setPrompt("pattern", (String)localObject2);
/*     */     }
/*     */ 
/* 182 */     if (paramMap.containsKey("length")) {
/* 183 */       localMap = (Map)paramMap.get("length");
/* 184 */       localObject1 = 
/* 185 */         (String)localMap
/* 185 */         .get("prompts");
/* 186 */       if (localMap.containsKey("max")) {
/* 187 */         localObject2 = 
/* 188 */           (Integer)localMap
/* 188 */           .get("max");
/* 189 */         localColumnImpl.setMaxLength(((Integer)localObject2).intValue());
/* 190 */         localColumnImpl.setPrompt("maxLength", (String)localObject1);
/*     */       }
/* 192 */       if (localMap.containsKey("min")) {
/* 193 */         localObject2 = 
/* 194 */           (Integer)localMap
/* 194 */           .get("min");
/* 195 */         localColumnImpl.setMinLength(((Integer)localObject2).intValue());
/* 196 */         localColumnImpl.setPrompt("minLength", (String)localObject1);
/*     */       }
/*     */     }
/*     */ 
/* 200 */     if (paramMap.containsKey("digits")) {
/* 201 */       localMap = (Map)paramMap.get("digits");
/* 202 */       localObject1 = 
/* 203 */         (String)localMap
/* 203 */         .get("prompts");
/* 204 */       int i = 0;
/*     */       Integer localInteger;
/* 205 */       if (localMap.containsKey("fraction")) {
/* 206 */         localInteger = 
/* 207 */           (Integer)localMap
/* 207 */           .get("fraction");
/* 208 */         i += localInteger.intValue();
/* 209 */         localColumnImpl.setScale(localInteger.intValue());
/* 210 */         localColumnImpl.setPrompt("scale", (String)localObject1);
/*     */       }
/* 212 */       if (localMap.containsKey("integer")) {
/* 213 */         localInteger = 
/* 214 */           (Integer)localMap
/* 214 */           .get("integer");
/* 215 */         localColumnImpl.setPrecision(i + localInteger.intValue());
/* 216 */         localColumnImpl.setPrompt("precision", (String)localObject1);
/*     */       }
/*     */     }
/*     */ 
/* 220 */     return localColumnImpl;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataCreatorImpl
 * JD-Core Version:    0.6.2
 */