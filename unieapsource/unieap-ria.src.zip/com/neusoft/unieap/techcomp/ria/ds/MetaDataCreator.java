package com.neusoft.unieap.techcomp.ria.ds;

public abstract interface MetaDataCreator
{
  public abstract MetaData afterRowSetNameSetted(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.MetaDataCreator
 * JD-Core Version:    0.6.2
 */