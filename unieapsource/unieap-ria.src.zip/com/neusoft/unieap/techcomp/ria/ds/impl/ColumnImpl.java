/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*     */ import com.neusoft.unieap.techcomp.ria.util.GMT;
/*     */ import java.util.Date;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class ColumnImpl
/*     */   implements Column
/*     */ {
/*     */   private JSONObject columnObj;
/*     */ 
/*     */   public ColumnImpl(JSONObject paramJSONObject)
/*     */   {
/*  15 */     this.columnObj = paramJSONObject;
/*     */   }
/*     */ 
/*     */   public ColumnImpl() {
/*  19 */     this.columnObj = JSONObject.fromObject("{}");
/*     */   }
/*     */ 
/*     */   public final JSONObject getJSONObject() {
/*  23 */     return this.columnObj;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  32 */     return this.columnObj.getString("name");
/*     */   }
/*     */ 
/*     */   public void setName(String paramString)
/*     */   {
/*  42 */     this.columnObj.put("name", paramString);
/*     */   }
/*     */ 
/*     */   public int getDataType()
/*     */   {
/*  51 */     if (this.columnObj.containsKey("dataType")) {
/*  52 */       return this.columnObj.getInt("dataType");
/*     */     }
/*  54 */     return 12;
/*     */   }
/*     */ 
/*     */   public void setDataType(int paramInt)
/*     */   {
/*  64 */     this.columnObj.put("dataType", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public boolean isNullable()
/*     */   {
/*  73 */     if (this.columnObj.containsKey("nullable")) {
/*  74 */       return this.columnObj.getBoolean("nullable");
/*     */     }
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public void setNullable(boolean paramBoolean)
/*     */   {
/*  85 */     this.columnObj.put("nullable", Boolean.valueOf(paramBoolean));
/*     */   }
/*     */ 
/*     */   public int getPrecision()
/*     */   {
/*  94 */     if (this.columnObj.containsKey("precision")) {
/*  95 */       return this.columnObj.getInt("precision");
/*     */     }
/*  97 */     return -1;
/*     */   }
/*     */ 
/*     */   public void setPrecision(int paramInt)
/*     */   {
/* 106 */     this.columnObj.put("precision", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public int getScale()
/*     */   {
/* 115 */     if (this.columnObj.containsKey("scale")) {
/* 116 */       return this.columnObj.getInt("scale");
/*     */     }
/* 118 */     return 0;
/*     */   }
/*     */ 
/*     */   public void setScale(int paramInt)
/*     */   {
/* 127 */     this.columnObj.put("scale", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public boolean isPrimaryKey()
/*     */   {
/* 136 */     if (this.columnObj.containsKey("primaryKey")) {
/* 137 */       return this.columnObj.getBoolean("primaryKey");
/*     */     }
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */   public void setPrimaryKey(boolean paramBoolean)
/*     */   {
/* 148 */     this.columnObj.put("primaryKey", Boolean.valueOf(paramBoolean));
/*     */   }
/*     */ 
/*     */   public String getLabel()
/*     */   {
/* 157 */     if (this.columnObj.containsKey("label")) {
/* 158 */       return this.columnObj.getString("label");
/*     */     }
/* 160 */     return "";
/*     */   }
/*     */ 
/*     */   public void setLabel(String paramString)
/*     */   {
/* 169 */     this.columnObj.put("label", paramString);
/*     */   }
/*     */ 
/*     */   public Object getDefaultValue()
/*     */   {
/* 178 */     return this.columnObj.get("defaultValue");
/*     */   }
/*     */ 
/*     */   public void setDefaultValue(Object paramObject)
/*     */   {
/* 187 */     this.columnObj.put("defaultValue", paramObject);
/*     */   }
/*     */ 
/*     */   public String getFormat()
/*     */   {
/* 196 */     return this.columnObj.getString("format");
/*     */   }
/*     */ 
/*     */   public void setFormat(String paramString)
/*     */   {
/* 205 */     this.columnObj.put("format", paramString);
/*     */   }
/*     */ 
/*     */   public Number getMax()
/*     */   {
/* 214 */     return (Number)this.columnObj.get("max");
/*     */   }
/*     */ 
/*     */   public void setMax(Number paramNumber)
/*     */   {
/* 223 */     this.columnObj.put("max", paramNumber);
/*     */   }
/*     */ 
/*     */   public Number getMin()
/*     */   {
/* 232 */     return (Number)this.columnObj.get("min");
/*     */   }
/*     */ 
/*     */   public void setMin(Number paramNumber)
/*     */   {
/* 241 */     this.columnObj.put("min", paramNumber);
/*     */   }
/*     */ 
/*     */   public Number getRangeMin()
/*     */   {
/* 250 */     if (this.columnObj.containsKey("range")) {
/* 251 */       JSONObject localJSONObject = this.columnObj.getJSONObject("range");
/* 252 */       return (Number)localJSONObject.get("min");
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */ 
/*     */   public Number getRangeMax()
/*     */   {
/* 263 */     if (this.columnObj.containsKey("range")) {
/* 264 */       JSONObject localJSONObject = this.columnObj.getJSONObject("range");
/* 265 */       return (Number)localJSONObject.get("max");
/*     */     }
/* 267 */     return null;
/*     */   }
/*     */ 
/*     */   public void setRangeMin(Number paramNumber)
/*     */   {
/* 276 */     if (!this.columnObj.containsKey("range")) {
/* 277 */       this.columnObj.put("range", new JSONObject());
/*     */     }
/* 279 */     this.columnObj.getJSONObject("range").put("min", paramNumber);
/*     */   }
/*     */ 
/*     */   public void setRangeMax(Number paramNumber)
/*     */   {
/* 288 */     if (!this.columnObj.containsKey("range")) {
/* 289 */       this.columnObj.put("range", new JSONObject());
/*     */     }
/* 291 */     this.columnObj.getJSONObject("range").put("max", paramNumber);
/*     */   }
/*     */ 
/*     */   public void setRange(Number paramNumber1, Number paramNumber2)
/*     */   {
/* 300 */     setRangeMin(paramNumber1);
/* 301 */     setRangeMax(paramNumber2);
/*     */   }
/*     */ 
/*     */   public Date getPast()
/*     */   {
/* 310 */     if (this.columnObj.containsKey("past")) {
/* 311 */       long l = this.columnObj.getLong("past");
/* 312 */       return GMT.fromGMTToCST(l);
/*     */     }
/* 314 */     return null;
/*     */   }
/*     */ 
/*     */   public void setPast(Date paramDate)
/*     */   {
/* 323 */     this.columnObj.put("past", Long.valueOf(GMT.fromCSTToGMT(paramDate)));
/*     */   }
/*     */ 
/*     */   public Date getFuture()
/*     */   {
/* 332 */     if (this.columnObj.containsKey("future")) {
/* 333 */       long l = this.columnObj.getLong("future");
/* 334 */       return GMT.fromGMTToCST(l);
/*     */     }
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */   public void setFuture(Date paramDate)
/*     */   {
/* 345 */     this.columnObj.put("future", Long.valueOf(GMT.fromCSTToGMT(paramDate)));
/*     */   }
/*     */ 
/*     */   public String getPattern()
/*     */   {
/* 354 */     return this.columnObj.getString("pattern");
/*     */   }
/*     */ 
/*     */   public void setPattern(String paramString)
/*     */   {
/* 363 */     this.columnObj.put("pattern", paramString);
/*     */   }
/*     */ 
/*     */   public String getPrompt(String paramString)
/*     */   {
/* 372 */     if (this.columnObj.containsKey("prompts")) {
/* 373 */       return this.columnObj.getJSONObject("prompts").getString(paramString);
/*     */     }
/* 375 */     return null;
/*     */   }
/*     */ 
/*     */   public void setPrompt(String paramString1, String paramString2)
/*     */   {
/* 384 */     if (!this.columnObj.containsKey("prompts")) {
/* 385 */       this.columnObj.put("prompts", new JSONObject());
/*     */     }
/* 387 */     this.columnObj.getJSONObject("prompts").put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(String paramString)
/*     */   {
/* 396 */     return this.columnObj.get(paramString);
/*     */   }
/*     */ 
/*     */   public void setAttribute(String paramString, Object paramObject)
/*     */   {
/* 405 */     this.columnObj.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   public int getMaxLength() {
/* 409 */     if (this.columnObj.containsKey("maxLength")) {
/* 410 */       int i = this.columnObj.getInt("maxLength");
/* 411 */       return i;
/*     */     }
/* 413 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getMinLength() {
/* 417 */     if (this.columnObj.containsKey("minLength")) {
/* 418 */       int i = this.columnObj.getInt("minLength");
/* 419 */       return i;
/*     */     }
/* 421 */     return 0;
/*     */   }
/*     */ 
/*     */   public void setMaxLength(int paramInt) {
/* 425 */     this.columnObj.put("maxLength", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public void setMinLength(int paramInt) {
/* 429 */     this.columnObj.put("minLength", Integer.valueOf(paramInt));
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.ColumnImpl
 * JD-Core Version:    0.6.2
 */