/*     */ package com.neusoft.unieap.techcomp.ria.ds;
/*     */ 
/*     */ import com.neusoft.unieap.core.page.Page;
/*     */ import java.util.List;
/*     */ 
/*     */ public class PageImpl
/*     */   implements Page
/*     */ {
/*     */   private static final long serialVersionUID = -4871873647394553671L;
/*  17 */   private String codition = null;
/*     */ 
/*  21 */   private int size = 10;
/*     */ 
/*  25 */   private int pageNumber = 1;
/*     */ 
/*  29 */   private List conditionValues = null;
/*     */ 
/*  33 */   private List orders = null;
/*     */ 
/*  37 */   private String rowSetName = null;
/*     */ 
/*     */   public String getCondition()
/*     */   {
/*  42 */     return this.codition;
/*     */   }
/*     */ 
/*     */   public List getConditionValues()
/*     */   {
/*  48 */     return this.conditionValues;
/*     */   }
/*     */ 
/*     */   public List getOrders()
/*     */   {
/*  54 */     return this.orders;
/*     */   }
/*     */ 
/*     */   public int getPageNumber()
/*     */   {
/*  60 */     return this.pageNumber;
/*     */   }
/*     */ 
/*     */   public String getRowSetName()
/*     */   {
/*  66 */     return this.rowSetName;
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */   {
/*  72 */     return this.size;
/*     */   }
/*     */ 
/*     */   public void setCondition(String paramString)
/*     */   {
/*  79 */     this.codition = paramString;
/*     */   }
/*     */ 
/*     */   public void setConditionValues(List paramList)
/*     */   {
/*  87 */     this.conditionValues = paramList;
/*     */   }
/*     */ 
/*     */   public void setOrders(List paramList)
/*     */   {
/*  94 */     this.orders = paramList;
/*     */   }
/*     */ 
/*     */   public void setPageNumber(int paramInt)
/*     */   {
/* 101 */     this.pageNumber = paramInt;
/*     */   }
/*     */ 
/*     */   public void setRowSetName(String paramString)
/*     */   {
/* 109 */     this.rowSetName = paramString;
/*     */   }
/*     */ 
/*     */   public void setSize(int paramInt)
/*     */   {
/* 117 */     this.size = paramInt;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.PageImpl
 * JD-Core Version:    0.6.2
 */