package com.neusoft.unieap.techcomp.ria.ds;

public abstract interface RowHandler
{
  public abstract boolean handle(Row paramRow);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.RowHandler
 * JD-Core Version:    0.6.2
 */