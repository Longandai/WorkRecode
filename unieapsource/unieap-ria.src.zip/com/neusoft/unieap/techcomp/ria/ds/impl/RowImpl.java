/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.util.GMT;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.JsonConfig;
/*     */ 
/*     */ public class RowImpl
/*     */   implements Row
/*     */ {
/*  14 */   private int index = -1;
/*  15 */   private JSONObject rowObj = new JSONObject();
/*     */ 
/*     */   public RowImpl() {
/*     */   }
/*  19 */   public RowImpl(Map paramMap) { if (paramMap == null) {
/*  20 */       paramMap = new HashMap();
/*     */     }
/*  22 */     this.rowObj.putAll(paramMap); }
/*     */ 
/*     */   public RowImpl(JSONObject paramJSONObject, int paramInt) {
/*  25 */     this.rowObj = paramJSONObject;
/*  26 */     this.index = paramInt;
/*     */   }
/*     */   public JSONObject getJSONObject() {
/*  29 */     return this.rowObj;
/*     */   }
/*     */ 
/*     */   public boolean isNewModify()
/*     */   {
/*  37 */     if (this.rowObj.containsKey("_t")) {
/*  38 */       return this.rowObj.getInt("_t") == 1;
/*     */     }
/*  40 */     return false;
/*     */   }
/*     */   public boolean isDataModify() {
/*  43 */     if (this.rowObj.containsKey("_t")) {
/*  44 */       return this.rowObj.getInt("_t") == 3;
/*     */     }
/*  46 */     return false;
/*     */   }
/*     */   public boolean isNotModify() {
/*  49 */     if (this.rowObj.containsKey("_t")) {
/*  50 */       return this.rowObj.getInt("_t") == 2;
/*     */     }
/*  52 */     return true;
/*     */   }
/*     */   public int getRowStatus() {
/*  55 */     if (!this.rowObj.containsKey("_t")) {
/*  56 */       return 2;
/*     */     }
/*  58 */     int i = Integer.parseInt(this.rowObj.get("_t").toString());
/*  59 */     return i;
/*     */   }
/*     */ 
/*     */   public boolean isSeleted() {
/*  63 */     if (!this.rowObj.containsKey("_s")) {
/*  64 */       return false;
/*     */     }
/*  66 */     boolean bool = this.rowObj.getBoolean("_s");
/*  67 */     return bool;
/*     */   }
/*     */   public boolean isPropertyModify(String paramString) {
/*  70 */     if (this.rowObj.containsKey("_o")) {
/*  71 */       JSONObject localJSONObject = this.rowObj.getJSONObject("_o");
/*  72 */       return localJSONObject.containsKey(paramString);
/*     */     }
/*  74 */     return false;
/*     */   }
/*     */   public Object getItemValue(String paramString) {
/*  77 */     if (!this.rowObj.containsKey(paramString)) {
/*  78 */       return null;
/*     */     }
/*  80 */     return this.rowObj.get(paramString);
/*     */   }
/*     */   public void setItemValue(String paramString, Object paramObject) {
/*  83 */     if ((paramObject instanceof Date)) {
/*  84 */       paramObject = Long.valueOf(GMT.fromCSTToGMT((Date)paramObject));
/*     */     }
/*     */ 
/*  87 */     if ((paramObject instanceof Float)) {
/*  88 */       paramObject = Double.valueOf(paramObject);
/*     */     }
/*     */ 
/*  91 */     if ((paramObject instanceof String)) {
/*  92 */       JsonConfig localJsonConfig = new JsonConfig();
/*  93 */       localJsonConfig.registerJsonValueProcessor(paramString, new StrJsonValueProcessor());
/*  94 */       this.rowObj.accumulate(paramString, paramObject, localJsonConfig);
/*     */     } else {
/*  96 */       this.rowObj.accumulate(paramString, paramObject);
/*     */     }
/*     */   }
/*     */ 
/* 100 */   public Object getOrigValue(String paramString) { if (!isPropertyModify(paramString)) {
/* 101 */       return null;
/*     */     }
/* 103 */     JSONObject localJSONObject = this.rowObj.getJSONObject("_o");
/* 104 */     return localJSONObject.get(paramString); }
/*     */ 
/*     */   public void setSelected(boolean paramBoolean)
/*     */   {
/* 108 */     this.rowObj.put("_s", Boolean.valueOf(paramBoolean));
/*     */   }
/*     */   public int getRowIndex() {
/* 111 */     return this.index;
/*     */   }
/*     */   public void setRowStatus(int paramInt) {
/* 114 */     this.rowObj.put("_t", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public void resetUpdate()
/*     */   {
/*     */     String str;
/* 119 */     if (this.rowObj.containsKey("_t")) {
/* 120 */       str = "_t";
/* 121 */       this.rowObj.remove(str);
/*     */     }
/* 123 */     if (this.rowObj.containsKey("_s")) {
/* 124 */       str = "_s";
/* 125 */       this.rowObj.remove(str);
/*     */     }
/* 127 */     if (this.rowObj.containsKey("_o")) {
/* 128 */       str = "_o";
/* 129 */       this.rowObj.remove(str);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String paramString)
/*     */   {
/* 135 */     return this.rowObj.getBoolean(paramString);
/*     */   }
/*     */ 
/*     */   public Date getDate(String paramString)
/*     */   {
/* 142 */     return new Date(getLong(paramString));
/*     */   }
/*     */   public double getDouble(String paramString) {
/* 145 */     return this.rowObj.getDouble(paramString);
/*     */   }
/*     */   public float getFloat(String paramString) {
/* 148 */     return Float.parseFloat(getDouble(paramString));
/*     */   }
/*     */   public int getInt(String paramString) {
/* 151 */     return this.rowObj.getInt(paramString);
/*     */   }
/*     */   public String getString(String paramString) {
/* 154 */     return this.rowObj.getString(paramString);
/*     */   }
/*     */   public long getLong(String paramString) {
/* 157 */     return this.rowObj.getLong(paramString);
/*     */   }
/*     */   public void setBoolean(String paramString, Boolean paramBoolean) {
/* 160 */     setItemValue(paramString, paramBoolean);
/*     */   }
/*     */   public void setDate(String paramString, Date paramDate) {
/* 163 */     setItemValue(paramString, Long.valueOf(paramDate.getTime()));
/*     */   }
/*     */   public void setDouble(String paramString, Double paramDouble) {
/* 166 */     setItemValue(paramString, paramDouble);
/*     */   }
/*     */   public void setFloat(String paramString, Float paramFloat) {
/* 169 */     setItemValue(paramString, paramFloat);
/*     */   }
/*     */   public void setInt(String paramString, Integer paramInteger) {
/* 172 */     setItemValue(paramString, paramInteger);
/*     */   }
/*     */   public void setString(String paramString1, String paramString2) {
/* 175 */     setItemValue(paramString1, paramString2);
/*     */   }
/*     */   public void setLong(String paramString, Long paramLong) {
/* 178 */     setItemValue(paramString, paramLong);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.RowImpl
 * JD-Core Version:    0.6.2
 */