package com.neusoft.unieap.techcomp.ria.ds;

import java.util.Date;

public abstract interface Column
{
  public static final String NAME = "name";
  public static final String DATATYPE = "dataType";
  public static final String NULLABLE = "nullable";
  public static final String PRECISION = "precision";
  public static final String SCALE = "scale";
  public static final String MAXLENGTH = "maxLength";
  public static final String MINLENGTH = "minLength";
  public static final String PRIMARYKEY = "primaryKey";
  public static final String LABEL = "label";
  public static final String DEFAULTVALUE = "defaultValue";
  public static final String FORMAT = "format";
  public static final String MIN = "min";
  public static final String MAX = "max";
  public static final String RANGE = "range";
  public static final String PAST = "past";
  public static final String FUTURE = "future";
  public static final String PATTERN = "pattern";
  public static final String PROMPTS = "prompts";

  public abstract String getName();

  public abstract void setName(String paramString);

  public abstract int getDataType();

  public abstract void setDataType(int paramInt);

  public abstract boolean isNullable();

  public abstract void setNullable(boolean paramBoolean);

  public abstract int getPrecision();

  public abstract void setPrecision(int paramInt);

  public abstract int getScale();

  public abstract void setScale(int paramInt);

  public abstract int getMaxLength();

  public abstract void setMaxLength(int paramInt);

  public abstract int getMinLength();

  public abstract void setMinLength(int paramInt);

  public abstract boolean isPrimaryKey();

  public abstract void setPrimaryKey(boolean paramBoolean);

  public abstract String getLabel();

  public abstract void setLabel(String paramString);

  public abstract Object getDefaultValue();

  public abstract void setDefaultValue(Object paramObject);

  public abstract String getFormat();

  public abstract void setFormat(String paramString);

  public abstract Number getMax();

  public abstract void setMax(Number paramNumber);

  public abstract Number getMin();

  public abstract void setMin(Number paramNumber);

  public abstract Number getRangeMin();

  public abstract Number getRangeMax();

  public abstract void setRangeMin(Number paramNumber);

  public abstract void setRangeMax(Number paramNumber);

  public abstract void setRange(Number paramNumber1, Number paramNumber2);

  public abstract Date getPast();

  public abstract void setPast(Date paramDate);

  public abstract Date getFuture();

  public abstract void setFuture(Date paramDate);

  public abstract String getPattern();

  public abstract void setPattern(String paramString);

  public abstract String getPrompt(String paramString);

  public abstract void setPrompt(String paramString1, String paramString2);

  public abstract Object getAttribute(String paramString);

  public abstract void setAttribute(String paramString, Object paramObject);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.Column
 * JD-Core Version:    0.6.2
 */