package com.neusoft.unieap.techcomp.ria.ds;

import java.util.List;
import java.util.Map;

public abstract interface DataCenter
{
  public static final String HEADER = "header";
  public static final String CODE = "code";
  public static final String MESSAGE = "message";
  public static final String TITLE = "title";
  public static final String DETAIL = "detail";
  public static final String BODY = "body";
  public static final String PARAMETERS = "parameters";
  public static final String DATASTORES = "dataStores";

  public abstract void setCode(long paramLong);

  public abstract long getCode();

  public abstract void setTitle(String paramString);

  public abstract String getTitle();

  public abstract void setDetail(String paramString);

  public abstract String getDetail();

  public abstract void addParameter(String paramString, Object paramObject);

  public abstract void setParameter(String paramString, Object paramObject);

  public abstract Map getParameters();

  public abstract Object getParameter(String paramString);

  public abstract void addHeaderAttribute(String paramString1, String paramString2);

  public abstract Map getHeaderAttributes();

  public abstract void addDataStore(DataStore paramDataStore);

  public abstract List getDataStores();

  public abstract DataStore getDataStore(String paramString);

  public abstract String toString();

  public abstract Object clone();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.DataCenter
 * JD-Core Version:    0.6.2
 */