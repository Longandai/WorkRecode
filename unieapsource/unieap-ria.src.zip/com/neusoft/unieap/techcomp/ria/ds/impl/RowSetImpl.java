/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowEachHandler;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowHandler;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class RowSetImpl
/*     */   implements RowSet
/*     */ {
/*     */   JSONObject rowsetObj;
/*     */ 
/*     */   public RowSetImpl(JSONObject paramJSONObject)
/*     */   {
/*  20 */     this.rowsetObj = paramJSONObject;
/*     */   }
/*     */ 
/*     */   public List getDeleteRows() {
/*  24 */     return getRowsFromArray("delete");
/*     */   }
/*     */ 
/*     */   public List getFilterRows() {
/*  28 */     return getRowsFromArray("filter");
/*     */   }
/*     */   public List getRows() {
/*  31 */     return getRowsFromArray("primary");
/*     */   }
/*     */   private List getRowsFromArray(String paramString) {
/*  34 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray(paramString);
/*  35 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  37 */     for (int i = 0; i < localJSONArray.size(); i++) {
/*  38 */       JSONObject localJSONObject = localJSONArray.getJSONObject(i);
/*  39 */       RowImpl localRowImpl = new RowImpl(localJSONObject, i);
/*  40 */       localArrayList.add(localRowImpl);
/*     */     }
/*  42 */     return localArrayList;
/*     */   }
/*     */   public List getNewModifyRows() {
/*  45 */     List localList1 = getRows();
/*  46 */     List localList2 = getFilterRows();
/*  47 */     if (localList2.size() > 0) {
/*  48 */       localList1.add(getFilterRows());
/*     */     }
/*  50 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  52 */     for (int i = 0; i < localList1.size(); i++) {
/*  53 */       Row localRow = (Row)localList1.get(i);
/*  54 */       if (localRow.isNewModify()) {
/*  55 */         localArrayList.add(localRow);
/*     */       }
/*     */     }
/*  58 */     return localArrayList;
/*     */   }
/*     */   public List getSelectedRows() {
/*  61 */     List localList1 = getRows();
/*  62 */     List localList2 = getFilterRows();
/*  63 */     if (localList2.size() > 0) {
/*  64 */       localList1.add(getFilterRows());
/*     */     }
/*  66 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  68 */     for (int i = 0; i < localList1.size(); i++) {
/*  69 */       Row localRow = (Row)localList1.get(i);
/*  70 */       if (localRow.isSeleted()) {
/*  71 */         localArrayList.add(localRow);
/*     */       }
/*     */     }
/*  74 */     return localArrayList;
/*     */   }
/*     */   public List getModifyRows() {
/*  77 */     List localList1 = getRows();
/*  78 */     List localList2 = getFilterRows();
/*  79 */     if (localList2.size() > 0) {
/*  80 */       localList1.add(localList2);
/*     */     }
/*  82 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  84 */     for (int i = 0; i < localList1.size(); i++) {
/*  85 */       Row localRow = (Row)localList1.get(i);
/*  86 */       if (localRow.isDataModify()) {
/*  87 */         localArrayList.add(localRow);
/*     */       }
/*     */     }
/*  90 */     return localArrayList;
/*     */   }
/*     */   public Row getRow(int paramInt) {
/*  93 */     return getRow(paramInt, "primary");
/*     */   }
/*     */   public Row getRow(int paramInt, String paramString) {
/*  96 */     List localList = null;
/*  97 */     if (paramString.equalsIgnoreCase("filter"))
/*  98 */       localList = getFilterRows();
/*  99 */     else if (paramString.equalsIgnoreCase("delete"))
/* 100 */       localList = getDeleteRows();
/*     */     else {
/* 102 */       localList = getRows();
/*     */     }
/* 104 */     if (localList == null) {
/* 105 */       return null;
/*     */     }
/* 107 */     Row localRow = (Row)localList.get(paramInt);
/* 108 */     return localRow;
/*     */   }
/*     */   public void forEach(RowEachHandler paramRowEachHandler, String paramString) {
/* 111 */     List localList = getRowsFromArray(paramString);
/*     */ 
/* 113 */     for (int i = 0; i < localList.size(); i++) {
/* 114 */       Row localRow = (Row)localList.get(i);
/* 115 */       paramRowEachHandler.handle(localRow);
/*     */     }
/*     */   }
/*     */ 
/* 119 */   public boolean every(RowHandler paramRowHandler, String paramString) { List localList = getRowsFromArray(paramString);
/*     */ 
/* 121 */     boolean bool = false;
/* 122 */     for (int i = 0; i < localList.size(); i++) {
/* 123 */       Row localRow = (Row)localList.get(i);
/* 124 */       bool = paramRowHandler.handle(localRow);
/* 125 */       if (!bool) return false;
/*     */     }
/* 127 */     return true; }
/*     */ 
/*     */   public boolean some(RowHandler paramRowHandler, String paramString) {
/* 130 */     List localList = getRowsFromArray(paramString);
/*     */ 
/* 132 */     boolean bool = false;
/* 133 */     for (int i = 0; i < localList.size(); i++) {
/* 134 */       Row localRow = (Row)localList.get(i);
/* 135 */       bool = paramRowHandler.handle(localRow);
/* 136 */       if (bool) return true;
/*     */     }
/* 138 */     return false;
/*     */   }
/*     */   public int getRowCount(String paramString) {
/* 141 */     List localList = getRowsFromArray(paramString);
/*     */ 
/* 143 */     return localList.size();
/*     */   }
/*     */   public int getTotalCount() {
/* 146 */     int i = getFilterRows().size();
/* 147 */     i += getDeleteRows().size();
/* 148 */     i += getRows().size();
/* 149 */     return i;
/*     */   }
/*     */   public boolean isEmpty() {
/* 152 */     if (getTotalCount() == 0) {
/* 153 */       return true;
/*     */     }
/* 155 */     return false;
/*     */   }
/*     */ 
/*     */   public void deleteRow(int paramInt, String paramString) {
/* 159 */     JSONObject localJSONObject = this.rowsetObj;
/*     */     JSONArray localJSONArray;
/* 160 */     if (paramString.equalsIgnoreCase("primary")) {
/* 161 */       localJSONArray = localJSONObject.getJSONArray("primary");
/* 162 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 163 */         return;
/*     */       }
/* 165 */       localJSONArray.remove(paramInt);
/* 166 */     } else if (paramString.equalsIgnoreCase("delete")) {
/* 167 */       localJSONArray = localJSONObject.getJSONArray("delete");
/* 168 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 169 */         return;
/*     */       }
/* 171 */       localJSONArray.remove(paramInt);
/* 172 */     } else if (paramString.equalsIgnoreCase("filter")) {
/* 173 */       localJSONArray = localJSONObject.getJSONArray("filter");
/* 174 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 175 */         return;
/*     */       }
/* 177 */       localJSONArray.remove(paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int addDeleteData(Map paramMap) {
/* 182 */     if (paramMap == null) {
/* 183 */       paramMap = new HashMap();
/*     */     }
/* 185 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray("delete");
/* 186 */     localJSONArray.add(paramMap);
/* 187 */     return localJSONArray.size() - 1;
/*     */   }
/*     */ 
/*     */   public int addFilterData(Map paramMap) {
/* 191 */     if (paramMap == null) {
/* 192 */       paramMap = new HashMap();
/*     */     }
/* 194 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray("filter");
/* 195 */     localJSONArray.add(paramMap);
/* 196 */     return localJSONArray.size() - 1;
/*     */   }
/*     */   public void clear() {
/* 199 */     this.rowsetObj.put("primary", new JSONArray());
/* 200 */     this.rowsetObj.put("delete", new JSONArray());
/* 201 */     this.rowsetObj.put("filter", new JSONArray());
/*     */   }
/*     */   public void addBatchRowData(List paramList) {
/* 204 */     int i = 0; for (int j = paramList.size(); i < j; i++)
/* 205 */       addRowData((Map)paramList.get(i));
/*     */   }
/*     */ 
/*     */   public int addRow(Row paramRow) {
/* 209 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray("primary");
/* 210 */     localJSONArray.add(((RowImpl)paramRow).getJSONObject());
/* 211 */     return localJSONArray.size() - 1;
/*     */   }
/*     */   public int addRowData(Map paramMap) {
/* 214 */     if (paramMap == null) {
/* 215 */       paramMap = new HashMap();
/*     */     }
/* 217 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray("primary");
/* 218 */     localJSONArray.add(paramMap);
/* 219 */     return localJSONArray.size() - 1;
/*     */   }
/*     */   public void delBatchRow(int[] paramArrayOfInt) {
/* 222 */     int i = -1; int j = 0;
/* 223 */     for (int k = 0; k < paramArrayOfInt.length; k++) {
/* 224 */       j = k;
/* 225 */       i = paramArrayOfInt[k];
/* 226 */       for (int m = k + 1; m < paramArrayOfInt.length; m++) {
/* 227 */         if (paramArrayOfInt[m] > i) {
/* 228 */           i = paramArrayOfInt[m];
/* 229 */           j = m;
/*     */         }
/*     */       }
/* 232 */       paramArrayOfInt[j] = paramArrayOfInt[k];
/* 233 */       JSONArray localJSONArray = this.rowsetObj.getJSONArray("primary");
/* 234 */       localJSONArray.remove(i);
/*     */     }
/*     */   }
/*     */ 
/* 238 */   public void insertRow(int paramInt, Row paramRow) { JSONArray localJSONArray = this.rowsetObj.getJSONArray("primary");
/* 239 */     localJSONArray.add(paramInt, ((RowImpl)paramRow).getJSONObject()); }
/*     */ 
/*     */   public void insertRowData(int paramInt, Map paramMap) {
/* 242 */     if (paramMap == null) {
/* 243 */       paramMap = new HashMap();
/*     */     }
/* 245 */     JSONArray localJSONArray = this.rowsetObj.getJSONArray("primary");
/* 246 */     localJSONArray.add(paramInt, paramMap);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.RowSetImpl
 * JD-Core Version:    0.6.2
 */