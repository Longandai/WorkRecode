/*    */ package com.neusoft.unieap.techcomp.ria.ds;
/*    */ 
/*    */ import com.neusoft.unieap.core.page.Order;
/*    */ 
/*    */ public class OrderImpl
/*    */   implements Order
/*    */ {
/*    */   private static final long serialVersionUID = -1937484566840397460L;
/* 17 */   private String orderStyle = null;
/*    */ 
/* 21 */   private String propertyName = null;
/*    */ 
/*    */   public String getOrderStyle()
/*    */   {
/* 27 */     return this.orderStyle;
/*    */   }
/*    */ 
/*    */   public String getPropertyName()
/*    */   {
/* 33 */     return this.propertyName;
/*    */   }
/*    */ 
/*    */   public void setOrderStyle(String paramString)
/*    */   {
/* 40 */     this.orderStyle = paramString;
/*    */   }
/*    */ 
/*    */   public void setPropertyName(String paramString)
/*    */   {
/* 47 */     this.propertyName = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.OrderImpl
 * JD-Core Version:    0.6.2
 */