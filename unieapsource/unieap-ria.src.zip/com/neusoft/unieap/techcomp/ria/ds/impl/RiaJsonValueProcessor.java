/*    */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*    */ 
/*    */ import net.sf.json.JsonConfig;
/*    */ import net.sf.json.processors.JsonValueProcessor;
/*    */ 
/*    */ public class RiaJsonValueProcessor
/*    */   implements JsonValueProcessor
/*    */ {
/*    */   public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig)
/*    */   {
/* 10 */     return null;
/*    */   }
/*    */ 
/*    */   public Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig)
/*    */   {
/* 15 */     if (paramObject.equals("null"))
/* 16 */       paramObject = "'" + paramObject + "'";
/* 17 */     else if (((paramObject instanceof String)) && (((((String)paramObject).startsWith("{")) && 
/* 18 */       (((String)paramObject).endsWith("}"))) || (
/* 18 */       (((String)paramObject).startsWith("[")) && 
/* 19 */       (((String)paramObject).endsWith("]"))))) {
/* 20 */       paramObject = "'" + paramObject + "'";
/*    */     }
/* 22 */     return paramObject;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.RiaJsonValueProcessor
 * JD-Core Version:    0.6.2
 */