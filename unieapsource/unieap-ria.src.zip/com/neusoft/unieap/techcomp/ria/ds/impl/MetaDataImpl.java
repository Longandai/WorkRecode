/*    */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ public class MetaDataImpl
/*    */   implements MetaData
/*    */ {
/*    */   private JSONObject metaObj;
/*    */ 
/*    */   public MetaDataImpl(JSONObject paramJSONObject)
/*    */   {
/* 22 */     this.metaObj = paramJSONObject;
/*    */   }
/*    */ 
/*    */   public MetaDataImpl() {
/* 26 */     String str = "{columns:{},order:\"\",condition:\"\"}";
/* 27 */     this.metaObj = JSONObject.fromObject(str);
/*    */   }
/*    */ 
/*    */   public final JSONObject getJSONObject() {
/* 31 */     return this.metaObj;
/*    */   }
/*    */ 
/*    */   private JSONObject getColumnObj() {
/* 35 */     return this.metaObj.getJSONObject("columns");
/*    */   }
/*    */ 
/*    */   public void addColumn(Column paramColumn)
/*    */   {
/* 43 */     getColumnObj().accumulate(paramColumn.getName(), ((ColumnImpl)paramColumn).getJSONObject());
/*    */   }
/*    */ 
/*    */   public List getColumns() {
/* 47 */     ArrayList localArrayList = new ArrayList();
/* 48 */     for (Iterator localIterator = getColumnObj().entrySet().iterator(); 
/* 49 */       localIterator.hasNext(); )
/*    */     {
/* 50 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 51 */       ColumnImpl localColumnImpl = new ColumnImpl((JSONObject)localEntry.getValue());
/* 52 */       localColumnImpl.setName((String)localEntry.getKey());
/* 53 */       localArrayList.add(localColumnImpl);
/*    */     }
/* 55 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public Column getColumn(String paramString)
/*    */   {
/* 62 */     JSONObject localJSONObject = getColumnObj().getJSONObject(paramString);
/* 63 */     return localJSONObject != null ? new ColumnImpl(localJSONObject) : null;
/*    */   }
/*    */ 
/*    */   public Object getPropertyValue(String paramString)
/*    */   {
/* 73 */     return this.metaObj.get(paramString);
/*    */   }
/*    */ 
/*    */   public void addProperty(String paramString, Object paramObject)
/*    */   {
/* 83 */     this.metaObj.accumulate(paramString, paramObject);
/*    */   }
/*    */ 
/*    */   public void setPrimaryKey(String paramString) {
/* 87 */     addProperty("PRIMARYKEY", paramString);
/*    */   }
/*    */   public String getPrimaryKey() {
/* 90 */     return (String)getPropertyValue("PRIMARYKEY");
/*    */   }
/*    */   public boolean containsKey(String paramString) {
/* 93 */     return this.metaObj.containsKey(paramString);
/*    */   }
/*    */   public boolean containsPrimaryKey() {
/* 96 */     return containsKey("PRIMARYKEY");
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataImpl
 * JD-Core Version:    0.6.2
 */