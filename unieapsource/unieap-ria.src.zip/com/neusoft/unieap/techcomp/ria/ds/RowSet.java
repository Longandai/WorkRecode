package com.neusoft.unieap.techcomp.ria.ds;

import java.util.List;
import java.util.Map;

public abstract interface RowSet
{
  public static final String PRIMARY = "primary";
  public static final String DELETE = "delete";
  public static final String FILTER = "filter";

  public abstract List getDeleteRows();

  public abstract List getFilterRows();

  public abstract List getRows();

  public abstract List getNewModifyRows();

  public abstract List getSelectedRows();

  public abstract List getModifyRows();

  public abstract Row getRow(int paramInt);

  public abstract Row getRow(int paramInt, String paramString);

  public abstract int getRowCount(String paramString);

  public abstract int getTotalCount();

  public abstract boolean isEmpty();

  public abstract void forEach(RowEachHandler paramRowEachHandler, String paramString);

  public abstract boolean every(RowHandler paramRowHandler, String paramString);

  public abstract boolean some(RowHandler paramRowHandler, String paramString);

  public abstract void deleteRow(int paramInt, String paramString);

  public abstract int addDeleteData(Map paramMap);

  public abstract int addFilterData(Map paramMap);

  public abstract void clear();

  public abstract int addRowData(Map paramMap);

  public abstract int addRow(Row paramRow);

  public abstract void insertRow(int paramInt, Row paramRow);

  public abstract void insertRowData(int paramInt, Map paramMap);

  public abstract void addBatchRowData(List paramList);

  public abstract void delBatchRow(int[] paramArrayOfInt);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.RowSet
 * JD-Core Version:    0.6.2
 */