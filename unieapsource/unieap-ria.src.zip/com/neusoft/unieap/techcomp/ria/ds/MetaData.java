package com.neusoft.unieap.techcomp.ria.ds;

import java.util.List;

public abstract interface MetaData
{
  public static final String COLUMNS = "columns";
  public static final String PRIMARYKEY = "PRIMARYKEY";

  public abstract void addColumn(Column paramColumn);

  public abstract List getColumns();

  public abstract Column getColumn(String paramString);

  public abstract Object getPropertyValue(String paramString);

  public abstract void addProperty(String paramString, Object paramObject);

  public abstract void setPrimaryKey(String paramString);

  public abstract String getPrimaryKey();

  public abstract boolean containsKey(String paramString);

  public abstract boolean containsPrimaryKey();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.MetaData
 * JD-Core Version:    0.6.2
 */