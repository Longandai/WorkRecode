/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.util.GMT;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class DataCenterImpl
/*     */   implements DataCenter, Cloneable
/*     */ {
/*     */   private JSONObject jsonObj;
/*  19 */   private Map paramMap = new HashMap();
/*  20 */   private Map dataStoreMap = new HashMap();
/*     */ 
/*     */   public DataCenterImpl()
/*     */   {
/*  26 */     String str = "{header:{\"code\": 0,\"message\":{\"title\": \"\",\"detail\": \"\"}},body: {parameters:{},dataStores:{}}}";
/*     */ 
/*  28 */     this.jsonObj = JSONObject.fromObject(str);
/*     */   }
/*     */ 
/*     */   public final JSONObject getJSONObject() {
/*  32 */     return this.jsonObj;
/*     */   }
/*     */ 
/*     */   public DataCenterImpl(JSONObject paramJSONObject)
/*     */   {
/*  41 */     this.jsonObj = paramJSONObject;
/*  42 */     initDataStores();
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  46 */     return getJSONObject().toString();
/*     */   }
/*     */ 
/*     */   private void initDataStores()
/*     */   {
/*  51 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/*  52 */       "dataStores");
/*  53 */     Iterator localIterator = localJSONObject.entrySet().iterator();
/*     */ 
/*  57 */     while (localIterator.hasNext()) {
/*  58 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  59 */       String str = localEntry.getKey().toString();
/*  60 */       if (!localJSONObject.getJSONObject(str).isNullObject()) {
/*  61 */         DataStoreImpl localDataStoreImpl = new DataStoreImpl(str, localJSONObject
/*  62 */           .getJSONObject(str));
/*  63 */         this.dataStoreMap.put(str, localDataStoreImpl);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private JSONObject getHeaderObj() {
/*  69 */     return this.jsonObj.getJSONObject("header");
/*     */   }
/*     */ 
/*     */   private JSONObject getBodyObj() {
/*  73 */     return this.jsonObj.getJSONObject("body");
/*     */   }
/*     */ 
/*     */   public long getCode()
/*     */   {
/*  82 */     String str = getHeaderObj().get("code").toString();
/*     */ 
/*  84 */     return Long.parseLong(str);
/*     */   }
/*     */ 
/*     */   public void setCode(long paramLong) {
/*  88 */     getHeaderObj().put("code", String.valueOf(paramLong));
/*     */   }
/*     */ 
/*     */   public DataStore getDataStore(String paramString)
/*     */   {
/*  98 */     return (DataStore)this.dataStoreMap.get(paramString);
/*     */   }
/*     */ 
/*     */   public List getDataStores()
/*     */   {
/* 105 */     Iterator localIterator = this.dataStoreMap.entrySet().iterator();
/*     */ 
/* 107 */     ArrayList localArrayList = new ArrayList();
/* 108 */     while (localIterator.hasNext()) {
/* 109 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 110 */       localArrayList.add(localEntry.getValue());
/*     */     }
/* 112 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void addDataStore(DataStore paramDataStore) {
/* 116 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/* 117 */       "dataStores");
/* 118 */     DataStoreImpl localDataStoreImpl = (DataStoreImpl)paramDataStore;
/* 119 */     localJSONObject.put(paramDataStore.getStoreName(), localDataStoreImpl.getJSONObject());
/* 120 */     this.dataStoreMap.put(paramDataStore.getStoreName(), localDataStoreImpl);
/*     */   }
/*     */ 
/*     */   public String getDetail()
/*     */   {
/* 129 */     JSONObject localJSONObject = getHeaderObj().getJSONObject(
/* 130 */       "message");
/* 131 */     String str = localJSONObject.get("detail").toString();
/* 132 */     return str;
/*     */   }
/*     */ 
/*     */   public void setDetail(String paramString) {
/* 136 */     JSONObject localJSONObject = getHeaderObj().getJSONObject(
/* 137 */       "message");
/* 138 */     localJSONObject.put("detail", paramString);
/*     */   }
/*     */ 
/*     */   public Map getParameters()
/*     */   {
/* 148 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/* 149 */       "parameters");
/*     */ 
/* 152 */     Iterator localIterator = localJSONObject.entrySet().iterator();
/* 153 */     while (localIterator.hasNext()) {
/* 154 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 155 */       Object localObject = localEntry.getValue();
/* 156 */       if (((localObject instanceof JSONObject)) && 
/* 157 */         (((JSONObject)localObject).isNullObject())) {
/* 158 */         localObject = null;
/*     */       }
/* 160 */       this.paramMap.put(localEntry.getKey().toString(), localObject);
/*     */     }
/* 162 */     return this.paramMap;
/*     */   }
/*     */ 
/*     */   public Object getParameter(String paramString)
/*     */   {
/* 172 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/* 173 */       "parameters");
/* 174 */     Object localObject = localJSONObject.get(paramString);
/* 175 */     if (((localObject instanceof JSONObject)) && (((JSONObject)localObject).isNullObject())) {
/* 176 */       localObject = null;
/*     */     }
/* 178 */     return localObject;
/*     */   }
/*     */ 
/*     */   public void addParameter(String paramString, Object paramObject) {
/* 182 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/* 183 */       "parameters");
/* 184 */     if ((paramObject instanceof Date)) {
/* 185 */       paramObject = Long.valueOf(GMT.fromCSTToGMT((Date)paramObject));
/*     */     }
/*     */ 
/* 188 */     if ((paramObject instanceof Float)) {
/* 189 */       paramObject = Double.valueOf(paramObject);
/*     */     }
/* 191 */     localJSONObject.accumulate(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   public void setParameter(String paramString, Object paramObject) {
/* 195 */     JSONObject localJSONObject = getBodyObj().getJSONObject(
/* 196 */       "parameters");
/* 197 */     if ((paramObject instanceof Date)) {
/* 198 */       paramObject = Long.valueOf(GMT.fromCSTToGMT((Date)paramObject));
/*     */     }
/*     */ 
/* 201 */     if ((paramObject instanceof Float)) {
/* 202 */       paramObject = Double.valueOf(paramObject);
/*     */     }
/* 204 */     localJSONObject.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/* 213 */     JSONObject localJSONObject = getHeaderObj().getJSONObject(
/* 214 */       "message");
/* 215 */     String str = localJSONObject.get("title").toString();
/* 216 */     return str;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/* 220 */     JSONObject localJSONObject = getHeaderObj().getJSONObject(
/* 221 */       "message");
/* 222 */     localJSONObject.put("title", paramString);
/*     */   }
/*     */ 
/*     */   public Map getHeaderAttributes()
/*     */   {
/* 229 */     Iterator localIterator = getHeaderObj().entrySet().iterator();
/* 230 */     HashMap localHashMap = new HashMap();
/* 231 */     while (localIterator.hasNext()) {
/* 232 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 233 */       if ((!localEntry.getKey().toString().equals("code")) && 
/* 234 */         (!localEntry.getKey().toString().equals("message"))) {
/* 235 */         localHashMap.put(localEntry.getKey().toString(), localEntry.getValue()
/* 236 */           .toString());
/*     */       }
/*     */     }
/* 239 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public void addHeaderAttribute(String paramString1, String paramString2) {
/* 243 */     getHeaderObj().put(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   public Object clone() {
/* 247 */     return new DataCenterImpl(JSONObject.fromObject(this.jsonObj));
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl
 * JD-Core Version:    0.6.2
 */