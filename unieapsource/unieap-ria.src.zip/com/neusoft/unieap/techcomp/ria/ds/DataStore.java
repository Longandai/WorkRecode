package com.neusoft.unieap.techcomp.ria.ds;

import com.neusoft.unieap.techcomp.ria.io.RowSetWriter;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface DataStore
{
  public static final String NAME = "name";
  public static final String PAGESIZE = "pageSize";
  public static final String PAGENUMBER = "pageNumber";
  public static final String RECODECOUNT = "recordCount";
  public static final String ROWSETNAME = "rowSetName";
  public static final String METADATA = "metaData";
  public static final String ROWSET = "rowSet";
  public static final String CONDITION = "condition";
  public static final String CONDITIONVALUES = "conditionValues";
  public static final String ORDER = "order";
  public static final String STATEMENTNAME = "statementName";
  public static final String ATTRIBUTES = "attributes";
  public static final String STATISTICS = "statistics";
  public static final String PARAMETERS = "parameters";
  public static final String POOL = "pool";
  public static final String DISTINCT = "distinct";
  public static final String PRINT_LAYOUT = "printLayout";
  public static final String JSON_DATASTORE_ISCOUNTFIRST = "isCountFirst";
  public static final int VALUE_INDEX = 0;
  public static final int TYPE_INDEX = 1;
  public static final String SYNCCOUNT = "synCount";

  public abstract String getStoreName();

  public abstract void setStoreName(String paramString);

  public abstract Map getAttributes();

  public abstract void addAttribute(String paramString1, String paramString2, String paramString3);

  public abstract void setAttributes(Map paramMap);

  public abstract String getCondition();

  public abstract void setCondition(String paramString);

  public abstract Object getPropertyValue(String paramString);

  public abstract void addProperty(String paramString, Object paramObject);

  public abstract Map getParameters();

  public abstract void addParameter(String paramString, Object paramObject);

  public abstract void setParameters(Map paramMap);

  public abstract MetaData getMetaData();

  public abstract void setMetaData(MetaData paramMetaData);

  public abstract String getOrder();

  public abstract void setOrder(String paramString);

  public abstract int getPageNumber();

  public abstract void setPageNumber(int paramInt);

  public abstract int getPageSize();

  public abstract void setPageSize(int paramInt);

  public abstract List getConditionValues();

  public abstract void setConditionValues(List paramList);

  public abstract void insertConditionObj(int paramInt, Object paramObject);

  public abstract void insertConditionValue(int paramInt, String paramString1, String paramString2);

  public abstract String getPool();

  public abstract void setPool(String paramString);

  public abstract int getRecordCount();

  public abstract void setRecordCount(int paramInt);

  public abstract List getRowDatasWithStatus();

  public abstract List getRowDatas();

  /** @deprecated */
  public abstract void addRowData(Map paramMap);

  /** @deprecated */
  public abstract List getDeleteDatas();

  /** @deprecated */
  public abstract void addDeleteData(Map paramMap);

  public abstract List getFilterDatasWithStatus();

  /** @deprecated */
  public abstract void addFilterData(Map paramMap);

  public abstract String getRowSetName();

  public abstract void setRowSetName(String paramString);

  public abstract String getStatementName();

  public abstract void setStatementName(String paramString);

  public abstract Map getStatistics();

  public abstract Map getStatisticsPatterns();

  public abstract Set getStatisticsPattern(String paramString);

  public abstract Number getStatisticsValue(String paramString1, String paramString2);

  public abstract void addStatistics(String paramString1, String paramString2);

  public abstract void addStatistics(String paramString1, String paramString2, Number paramNumber);

  public abstract void addStatistics(String paramString, Map paramMap);

  public abstract boolean isDistinct();

  public abstract void setDistinct(boolean paramBoolean);

  public abstract void setRowSetWriter(RowSetWriter paramRowSetWriter);

  public abstract Object clone();

  /** @deprecated */
  public abstract void clearRowSet();

  /** @deprecated */
  public abstract void deleteRow(int paramInt, String paramString);

  public abstract RowSet getRowSet();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.DataStore
 * JD-Core Version:    0.6.2
 */