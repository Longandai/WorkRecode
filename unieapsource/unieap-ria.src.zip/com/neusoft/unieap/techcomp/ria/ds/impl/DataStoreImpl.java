/*     */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaDataCreator;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.io.RowSetWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.util.ConverterUtil;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class DataStoreImpl
/*     */   implements DataStore, Serializable, Cloneable
/*     */ {
/*     */   private String storeName;
/*     */   private transient JSONObject storeObj;
/*  36 */   private RowSetWriter rowSetWriter = null;
/*     */ 
/*     */   public DataStoreImpl(String paramString) {
/*  39 */     this.storeName = paramString;
/*  40 */     String str = "{rowSet: {\"primary\": [],\"filter\": [],\"delete\": []},parameters:{},name: \"" + 
/*  42 */       paramString + 
/*  43 */       "\",pageNumber: 1,pageSize: 2147483647,recordCount: 0}";
/*  44 */     this.storeObj = JSONObject.fromObject(str);
/*     */   }
/*     */ 
/*     */   public DataStoreImpl(String paramString, JSONObject paramJSONObject) {
/*  48 */     this.storeName = paramString;
/*  49 */     this.storeObj = (paramJSONObject == null ? JSONObject.fromObject(null) : 
/*  50 */       paramJSONObject);
/*  51 */     onRowSetNameSetted(getRowSetName());
/*     */   }
/*     */ 
/*     */   public String getStoreName()
/*     */   {
/*  60 */     return this.storeName;
/*     */   }
/*     */ 
/*     */   public void setStoreName(String paramString) {
/*  64 */     this.storeName = paramString;
/*     */   }
/*     */ 
/*     */   public final JSONObject getJSONObject() {
/*  68 */     return this.storeObj;
/*     */   }
/*     */ 
/*     */   public final JSONArray getPrimaryArray() {
/*  72 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/*  73 */     return localJSONObject.getJSONArray("primary");
/*     */   }
/*     */ 
/*     */   public final JSONArray getFilterArray() {
/*  77 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/*  78 */     return localJSONObject.getJSONArray("filter");
/*     */   }
/*     */ 
/*     */   public final JSONArray getDeleteArray() {
/*  82 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/*  83 */     return localJSONObject.getJSONArray("delete");
/*     */   }
/*     */ 
/*     */   public Map getAttributes()
/*     */   {
/*  93 */     HashMap localHashMap = null;
/*  94 */     if (this.storeObj.containsKey("attributes")) {
/*  95 */       localHashMap = new HashMap();
/*  96 */       JSONObject localJSONObject = this.storeObj.getJSONObject("attributes");
/*  97 */       Iterator localIterator = localJSONObject.entrySet().iterator();
/*     */ 
/* 100 */       while (localIterator.hasNext()) {
/* 101 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 102 */         ArrayList localArrayList = new ArrayList();
/*     */         try {
/* 104 */           Object[] arrayOfObject = ((JSONArray)localEntry.getValue()).toArray();
/* 105 */           if ((arrayOfObject != null) && (arrayOfObject.length == 2))
/*     */           {
/* 108 */             localArrayList.add(arrayOfObject[0]);
/* 109 */             localArrayList.add(arrayOfObject[1]);
/* 110 */             localHashMap.put(localEntry.getKey().toString(), localArrayList);
/*     */           }
/*     */         }
/*     */         catch (Exception localException) {
/* 114 */           localException.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 119 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public void addAttribute(String paramString1, String paramString2, String paramString3) {
/* 123 */     if (!this.storeObj.containsKey("attributes")) {
/* 124 */       this.storeObj.accumulate("attributes", "{}");
/*     */     }
/* 126 */     String str = "[\"" + paramString2 + "\",\"" + paramString3 + "\"]";
/* 127 */     this.storeObj.getJSONObject("attributes").accumulate(paramString1, str);
/*     */   }
/*     */ 
/*     */   public void setAttributes(Map paramMap) {
/* 131 */     if (paramMap != null) {
/* 132 */       Iterator localIterator = paramMap.entrySet().iterator();
/*     */ 
/* 134 */       while (localIterator.hasNext()) {
/* 135 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 136 */         if (!this.storeObj.containsKey("attributes")) {
/* 137 */           this.storeObj.accumulate("attributes", "{}");
/*     */         }
/* 139 */         Object localObject = localEntry.getValue();
/*     */ 
/* 141 */         if ((localObject instanceof Float)) {
/* 142 */           localObject = Double.valueOf(localObject);
/*     */         }
/* 144 */         this.storeObj.getJSONObject("attributes").accumulate(
/* 145 */           localEntry.getKey().toString(), localObject);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getCondition()
/*     */   {
/*     */     String str;
/* 158 */     if (this.storeObj.containsKey("condition"))
/* 159 */       str = this.storeObj.get("condition").toString();
/*     */     else {
/* 161 */       str = null;
/*     */     }
/* 163 */     return str;
/*     */   }
/*     */ 
/*     */   public void setCondition(String paramString) {
/* 167 */     this.storeObj.put("condition", paramString);
/*     */   }
/*     */ 
/*     */   public Object getPropertyValue(String paramString)
/*     */   {
/* 177 */     Object localObject = null;
/* 178 */     if (this.storeObj.containsKey(paramString)) {
/* 179 */       localObject = this.storeObj.get(paramString);
/*     */     }
/* 181 */     return localObject;
/*     */   }
/*     */ 
/*     */   public void addProperty(String paramString, Object paramObject) {
/* 185 */     this.storeObj.put(paramString, paramObject.toString());
/*     */   }
/*     */ 
/*     */   public Map getParameters()
/*     */   {
/* 194 */     return getMapUtil("parameters");
/*     */   }
/*     */ 
/*     */   public void addParameter(String paramString, Object paramObject) {
/* 198 */     if (!this.storeObj.containsKey("parameters")) {
/* 199 */       this.storeObj.accumulate("parameters", "{}");
/*     */     }
/*     */ 
/* 202 */     if ((paramObject instanceof Float)) {
/* 203 */       paramObject = Double.valueOf(paramObject);
/*     */     }
/* 205 */     this.storeObj.getJSONObject("parameters").accumulate(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   public void setParameters(Map paramMap) {
/* 209 */     if (paramMap != null) {
/* 210 */       if (!this.storeObj.containsKey("parameters")) {
/* 211 */         this.storeObj.accumulate("parameters", "{}");
/*     */       }
/* 213 */       Iterator localIterator = paramMap.entrySet().iterator();
/*     */ 
/* 215 */       while (localIterator.hasNext()) {
/* 216 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 217 */         Object localObject = localEntry.getValue();
/*     */ 
/* 219 */         if ((localObject instanceof Float)) {
/* 220 */           localObject = Double.valueOf(localObject);
/*     */         }
/* 222 */         this.storeObj.getJSONObject("parameters").accumulate(
/* 223 */           localEntry.getKey().toString(), localObject);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public MetaData getMetaData()
/*     */   {
/* 234 */     MetaDataImpl localMetaDataImpl = null;
/* 235 */     if (this.storeObj.containsKey("metaData")) {
/* 236 */       localMetaDataImpl = new MetaDataImpl(this.storeObj.getJSONObject("metaData"));
/*     */     }
/* 238 */     return localMetaDataImpl;
/*     */   }
/*     */ 
/*     */   public void setMetaData(MetaData paramMetaData) {
/* 242 */     if (!this.storeObj.containsKey("metaData")) {
/* 243 */       this.storeObj.accumulate("metaData", "{}");
/*     */     }
/* 245 */     MetaDataImpl localMetaDataImpl = (MetaDataImpl)paramMetaData;
/* 246 */     this.storeObj.put("metaData", localMetaDataImpl.getJSONObject());
/*     */   }
/*     */ 
/*     */   public String getOrder()
/*     */   {
/* 257 */     String str = null;
/* 258 */     if (this.storeObj.containsKey("order")) {
/* 259 */       str = this.storeObj.get("order").toString();
/*     */     }
/* 261 */     return str;
/*     */   }
/*     */ 
/*     */   public void setOrder(String paramString) {
/* 265 */     this.storeObj.put("order", paramString);
/*     */   }
/*     */ 
/*     */   public int getPageNumber()
/*     */   {
/* 274 */     String str = this.storeObj.get("pageNumber").toString();
/* 275 */     return Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public void setPageNumber(int paramInt) {
/* 279 */     this.storeObj.put("pageNumber", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public int getPageSize()
/*     */   {
/* 288 */     String str = this.storeObj.get("pageSize").toString();
/* 289 */     return Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public void setPageSize(int paramInt) {
/* 293 */     this.storeObj.put("pageSize", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public List getConditionValues()
/*     */   {
/* 302 */     ArrayList localArrayList = new ArrayList();
/* 303 */     if (this.storeObj.containsKey("conditionValues")) {
/* 304 */       JSONArray localJSONArray = this.storeObj
/* 305 */         .getJSONArray("conditionValues");
/* 306 */       Object[] arrayOfObject1 = localJSONArray.toArray();
/* 307 */       for (int i = 0; i < arrayOfObject1.length; i++) {
/* 308 */         Object[] arrayOfObject2 = ((JSONArray)arrayOfObject1[i]).toArray();
/* 309 */         int j = Integer.parseInt(arrayOfObject2[1].toString());
/* 310 */         localArrayList.add(ConverterUtil.constructObject(arrayOfObject2[0], j));
/*     */       }
/*     */     }
/* 313 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void setConditionValues(List paramList) {
/* 317 */     this.storeObj.put("conditionValues", "[]");
/* 318 */     if (paramList != null)
/*     */     {
/* 321 */       for (int j = 0; j < paramList.size(); j++) {
/* 322 */         Object localObject = paramList.get(j);
/* 323 */         int i = ConverterUtil.javaTypeToSqlType(localObject.getClass()
/* 324 */           .toString());
/* 325 */         insertConditionValue(j, ConverterUtil.toJson(localObject), 
/* 326 */           String.valueOf(i));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void insertConditionValue(int paramInt, String paramString1, String paramString2) {
/* 332 */     if (!this.storeObj.containsKey("conditionValues")) {
/* 333 */       this.storeObj.accumulate("conditionValues", "[]");
/*     */     }
/* 335 */     JSONArray localJSONArray1 = this.storeObj.getJSONArray("conditionValues");
/* 336 */     JSONArray localJSONArray2 = new JSONArray();
/* 337 */     localJSONArray2.add(0, paramString1);
/* 338 */     localJSONArray2.add(1, paramString2);
/* 339 */     localJSONArray1.add(paramInt, localJSONArray2);
/*     */   }
/*     */ 
/*     */   public void insertConditionObj(int paramInt, Object paramObject) {
/* 343 */     int i = ConverterUtil.javaTypeToSqlType(paramObject.getClass()
/* 344 */       .toString());
/* 345 */     insertConditionValue(paramInt, ConverterUtil.toJson(paramObject), 
/* 346 */       String.valueOf(i));
/*     */   }
/*     */ 
/*     */   public String getPool()
/*     */   {
/* 355 */     String str = null;
/* 356 */     if (this.storeObj.containsKey("pool")) {
/* 357 */       str = this.storeObj.get("pool").toString();
/*     */     }
/* 359 */     return str;
/*     */   }
/*     */ 
/*     */   public void setPool(String paramString) {
/* 363 */     this.storeObj.put("pool", paramString);
/*     */   }
/*     */ 
/*     */   public int getRecordCount()
/*     */   {
/* 372 */     String str = this.storeObj.get("recordCount").toString();
/* 373 */     return Integer.parseInt(str);
/*     */   }
/*     */ 
/*     */   public void setRecordCount(int paramInt) {
/* 377 */     this.storeObj.put("recordCount", Integer.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public List getRowDatasWithStatus()
/*     */   {
/* 386 */     JSONArray localJSONArray = getPrimaryArray();
/* 387 */     return getListUtil(localJSONArray);
/*     */   }
/*     */ 
/*     */   public List getRowDatas() {
/* 391 */     JSONArray localJSONArray = getPrimaryArray();
/*     */ 
/* 396 */     ArrayList localArrayList = new ArrayList();
/* 397 */     for (int i = 0; i < localJSONArray.size(); i++) {
/* 398 */       JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
/* 399 */       Iterator localIterator = localJSONObject.entrySet().iterator();
/* 400 */       HashMap localHashMap = new HashMap();
/* 401 */       while (localIterator.hasNext()) {
/* 402 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 403 */         String str = localEntry.getKey().toString();
/* 404 */         Object localObject = localEntry.getValue();
/* 405 */         if ((!str.equals("_o")) && (!str.equals("_s")) && 
/* 406 */           (!str.equals("_t")))
/*     */         {
/* 409 */           if (isNull(localObject)) {
/* 410 */             localObject = null;
/*     */           }
/* 412 */           localHashMap.put(str, localObject);
/*     */         }
/*     */       }
/* 414 */       localArrayList.add(localHashMap);
/*     */     }
/* 416 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRowDataObjs() {
/* 420 */     JSONArray localJSONArray = getPrimaryArray();
/* 421 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 423 */     for (int i = 0; i < localJSONArray.size(); i++) {
/* 424 */       JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
/* 425 */       localArrayList.add(localJSONObject);
/*     */     }
/* 427 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void addRowData(Map paramMap)
/*     */   {
/* 432 */     if (paramMap != null) {
/* 433 */       JSONArray localJSONArray = getPrimaryArray();
/* 434 */       localJSONArray.add(paramMap);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getDeleteDatas()
/*     */   {
/* 444 */     JSONArray localJSONArray = getDeleteArray();
/* 445 */     return getListUtil(localJSONArray);
/*     */   }
/*     */ 
/*     */   public List getDeleteRowObjs() {
/* 449 */     JSONArray localJSONArray = getDeleteArray();
/* 450 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 452 */     for (int i = 0; i < localJSONArray.size(); i++) {
/* 453 */       JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
/* 454 */       localArrayList.add(localJSONObject);
/*     */     }
/* 456 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void addDeleteData(Map paramMap) {
/* 460 */     if (paramMap != null)
/* 461 */       getDeleteArray().add(paramMap);
/*     */   }
/*     */ 
/*     */   public List getFilterDatasWithStatus()
/*     */   {
/* 472 */     JSONArray localJSONArray = getFilterArray();
/* 473 */     return getListUtil(localJSONArray);
/*     */   }
/*     */ 
/*     */   public List getFilterRowDataObjs() {
/* 477 */     JSONArray localJSONArray = getFilterArray();
/* 478 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 480 */     for (int i = 0; i < localJSONArray.size(); i++) {
/* 481 */       JSONObject localJSONObject = (JSONObject)localJSONArray.get(i);
/* 482 */       localArrayList.add(localJSONObject);
/*     */     }
/* 484 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void addFilterData(Map paramMap)
/*     */   {
/* 489 */     if (paramMap != null)
/* 490 */       getFilterArray().add(paramMap);
/*     */   }
/*     */ 
/*     */   public String getRowSetName()
/*     */   {
/* 500 */     String str = null;
/* 501 */     if (this.storeObj.containsKey("rowSetName")) {
/* 502 */       str = this.storeObj.get("rowSetName").toString();
/*     */     }
/* 504 */     return str;
/*     */   }
/*     */ 
/*     */   public void setRowSetName(String paramString) {
/* 508 */     String str = getRowSetName();
/* 509 */     this.storeObj.put("rowSetName", paramString);
/* 510 */     if ((paramString == null) || ("".equals(paramString.trim())))
/* 511 */       return;
/* 512 */     if ((getMetaData() == null) || (!paramString.equals(str)))
/* 513 */       onRowSetNameSetted(paramString);
/*     */   }
/*     */ 
/*     */   public String getStatementName()
/*     */   {
/* 523 */     String str = null;
/* 524 */     if (this.storeObj.containsKey("statementName")) {
/* 525 */       str = this.storeObj.get("statementName").toString();
/*     */     }
/* 527 */     return str;
/*     */   }
/*     */ 
/*     */   public void setStatementName(String paramString) {
/* 531 */     this.storeObj.put("statementName", paramString);
/*     */   }
/*     */ 
/*     */   public Map getStatistics()
/*     */   {
/* 540 */     HashMap localHashMap1 = null;
/* 541 */     if (this.storeObj.containsKey("statistics")) {
/* 542 */       localHashMap1 = new HashMap();
/* 543 */       JSONObject localJSONObject1 = this.storeObj.getJSONObject("statistics");
/* 544 */       Iterator localIterator1 = localJSONObject1.entrySet().iterator();
/*     */ 
/* 550 */       while (localIterator1.hasNext()) {
/* 551 */         Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
/* 552 */         JSONObject localJSONObject2 = (JSONObject)localEntry1.getValue();
/* 553 */         Iterator localIterator2 = localJSONObject2.entrySet().iterator();
/* 554 */         HashMap localHashMap2 = new HashMap();
/* 555 */         while (localIterator2.hasNext()) {
/* 556 */           Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
/* 557 */           localHashMap2.put(localEntry2.getKey().toString(), localEntry2
/* 558 */             .getValue().toString());
/*     */         }
/* 560 */         localHashMap1.put(localEntry1.getKey().toString(), localHashMap2);
/*     */       }
/*     */     }
/* 563 */     return localHashMap1;
/*     */   }
/*     */ 
/*     */   public void addStatistics(String paramString, Map paramMap) {
/* 567 */     if (!this.storeObj.containsKey("statistics")) {
/* 568 */       this.storeObj.accumulate("statistics", "{}");
/*     */     }
/* 570 */     JSONObject localJSONObject = this.storeObj.getJSONObject("statistics");
/* 571 */     if (!localJSONObject.containsKey(paramString)) {
/* 572 */       localJSONObject.accumulate(paramString, "{}");
/*     */     }
/* 574 */     Iterator localIterator = paramMap.entrySet().iterator();
/*     */ 
/* 577 */     while (localIterator.hasNext()) {
/* 578 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 579 */       String str = localEntry.getValue().toString();
/* 580 */       localJSONObject.getJSONObject(paramString).put(localEntry.getKey().toString(), 
/* 581 */         str);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addStatistics(String paramString1, String paramString2)
/*     */   {
/* 587 */     if (!this.storeObj.containsKey("statistics")) {
/* 588 */       this.storeObj.accumulate("statistics", "{}");
/*     */     }
/* 590 */     JSONObject localJSONObject = this.storeObj.getJSONObject("statistics");
/* 591 */     if (!localJSONObject.containsKey(paramString1)) {
/* 592 */       localJSONObject.accumulate(paramString1, "{}");
/*     */     }
/* 594 */     localJSONObject.getJSONObject(paramString1).put(paramString2, "");
/*     */   }
/*     */ 
/*     */   public boolean isDistinct()
/*     */   {
/* 603 */     boolean bool = false;
/* 604 */     if (this.storeObj.containsKey("distinct")) {
/* 605 */       String str = this.storeObj.get("distinct").toString();
/* 606 */       if (str.equals("true")) {
/* 607 */         bool = true;
/*     */       }
/*     */     }
/* 610 */     return bool;
/*     */   }
/*     */ 
/*     */   public void setDistinct(boolean paramBoolean) {
/* 614 */     if (paramBoolean)
/* 615 */       this.storeObj.put("distinct", "true");
/*     */     else
/* 617 */       this.storeObj.put("distinct", "false");
/*     */   }
/*     */ 
/*     */   private Map getMapUtil(String paramString)
/*     */   {
/* 622 */     HashMap localHashMap = null;
/* 623 */     if (this.storeObj.containsKey(paramString)) {
/* 624 */       localHashMap = new HashMap();
/* 625 */       JSONObject localJSONObject = this.storeObj.getJSONObject(paramString);
/* 626 */       Iterator localIterator = localJSONObject.entrySet().iterator();
/*     */ 
/* 628 */       while (localIterator.hasNext()) {
/* 629 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 630 */         localHashMap.put(localEntry.getKey().toString(), localEntry.getValue());
/*     */       }
/*     */     }
/* 633 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private List getListUtil(JSONArray paramJSONArray) {
/* 637 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 642 */     for (int i = 0; i < paramJSONArray.size(); i++) {
/* 643 */       JSONObject localJSONObject1 = (JSONObject)paramJSONArray.get(i);
/* 644 */       Iterator localIterator1 = localJSONObject1.entrySet().iterator();
/* 645 */       HashMap localHashMap1 = new HashMap();
/* 646 */       while (localIterator1.hasNext())
/*     */       {
/* 648 */         Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
/* 649 */         String str = localEntry1.getKey().toString();
/* 650 */         Object localObject1 = localEntry1.getValue();
/* 651 */         if (str.equals("_o")) {
/* 652 */           JSONObject localJSONObject2 = (JSONObject)localObject1;
/* 653 */           Iterator localIterator2 = localJSONObject2.entrySet().iterator();
/* 654 */           HashMap localHashMap2 = new HashMap();
/* 655 */           while (localIterator2.hasNext()) {
/* 656 */             Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
/* 657 */             Object localObject2 = localEntry2.getValue();
/* 658 */             localHashMap2.put(localEntry2.getKey(), isNull(localObject2) ? null : localObject2);
/*     */           }
/* 660 */           localObject1 = localHashMap2;
/* 661 */         } else if (isNull(localObject1)) {
/* 662 */           localObject1 = null;
/*     */         }
/* 664 */         localHashMap1.put(str, localObject1);
/*     */       }
/* 666 */       localArrayList.add(localHashMap1);
/*     */     }
/* 668 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private boolean isNull(Object paramObject) {
/* 672 */     if ((paramObject instanceof JSONObject)) {
/* 673 */       JSONObject localJSONObject = (JSONObject)paramObject;
/* 674 */       if (localJSONObject.isNullObject()) {
/* 675 */         return true;
/*     */       }
/*     */     }
/* 678 */     return false;
/*     */   }
/*     */ 
/*     */   public void setRowSetWriter(RowSetWriter paramRowSetWriter) {
/* 682 */     this.rowSetWriter = paramRowSetWriter;
/*     */   }
/*     */ 
/*     */   public RowSetWriter getRowSetWriter() {
/* 686 */     return this.rowSetWriter;
/*     */   }
/*     */ 
/*     */   public Object clone() {
/* 690 */     DataStoreImpl localDataStoreImpl = new DataStoreImpl(this.storeName, 
/* 691 */       JSONObject.fromObject(this.storeObj));
/* 692 */     localDataStoreImpl.setRowSetWriter(this.rowSetWriter);
/* 693 */     return localDataStoreImpl;
/*     */   }
/*     */ 
/*     */   public void clearRowSet() {
/* 697 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/* 698 */     localJSONObject.put("primary", new JSONArray());
/* 699 */     localJSONObject.put("delete", new JSONArray());
/* 700 */     localJSONObject.put("filter", new JSONArray());
/*     */   }
/*     */ 
/*     */   public void deleteRow(int paramInt, String paramString) {
/* 704 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/*     */     JSONArray localJSONArray;
/* 705 */     if (paramString.equalsIgnoreCase("primary")) {
/* 706 */       localJSONArray = localJSONObject.getJSONArray("primary");
/* 707 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 708 */         return;
/*     */       }
/* 710 */       localJSONArray.remove(paramInt);
/* 711 */     } else if (paramString.equalsIgnoreCase("delete")) {
/* 712 */       localJSONArray = localJSONObject.getJSONArray("delete");
/* 713 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 714 */         return;
/*     */       }
/* 716 */       localJSONArray.remove(paramInt);
/* 717 */     } else if (paramString.equalsIgnoreCase("filter")) {
/* 718 */       localJSONArray = localJSONObject.getJSONArray("filter");
/* 719 */       if ((localJSONArray.size() == 0) || (paramInt > localJSONArray.size() - 1)) {
/* 720 */         return;
/*     */       }
/* 722 */       localJSONArray.remove(paramInt);
/*     */     }
/*     */   }
/*     */ 
/*     */   public RowSet getRowSet() {
/* 727 */     JSONObject localJSONObject = this.storeObj.getJSONObject("rowSet");
/* 728 */     return new RowSetImpl(localJSONObject);
/*     */   }
/*     */ 
/*     */   public void addStatistics(String paramString1, String paramString2, Number paramNumber) {
/* 732 */     if (!this.storeObj.containsKey("statistics")) {
/* 733 */       this.storeObj.accumulate("statistics", new JSONObject());
/*     */     }
/* 735 */     JSONObject localJSONObject = this.storeObj.getJSONObject("statistics");
/* 736 */     if (!localJSONObject.containsKey(paramString1)) {
/* 737 */       localJSONObject.accumulate(paramString1, new JSONObject());
/*     */     }
/*     */ 
/* 740 */     if ((paramNumber instanceof Float)) {
/* 741 */       paramNumber = Double.valueOf(paramNumber);
/*     */     }
/* 743 */     localJSONObject.getJSONObject(paramString1).put(paramString2, paramNumber);
/*     */   }
/*     */ 
/*     */   public Set getStatisticsPattern(String paramString) {
/* 747 */     HashSet localHashSet = new HashSet();
/* 748 */     if (this.storeObj.containsKey("statistics")) {
/* 749 */       JSONObject localJSONObject1 = this.storeObj.getJSONObject("statistics");
/* 750 */       if (localJSONObject1.containsKey(paramString)) {
/* 751 */         JSONObject localJSONObject2 = localJSONObject1.getJSONObject(paramString);
/* 752 */         for (Iterator localIterator = localJSONObject2.keys(); localIterator.hasNext(); ) {
/* 753 */           String str = (String)localIterator.next();
/* 754 */           localHashSet.add(str);
/*     */         }
/*     */       }
/*     */     }
/* 758 */     return localHashSet;
/*     */   }
/*     */ 
/*     */   public Map getStatisticsPatterns() {
/* 762 */     HashMap localHashMap = new HashMap();
/* 763 */     if (this.storeObj.containsKey("statistics")) {
/* 764 */       JSONObject localJSONObject1 = this.storeObj.getJSONObject("statistics");
/* 765 */       for (Iterator localIterator1 = localJSONObject1.entrySet().iterator(); localIterator1
/* 766 */         .hasNext(); )
/*     */       {
/* 767 */         Map.Entry localEntry = (Map.Entry)localIterator1.next();
/* 768 */         String str1 = (String)localEntry.getKey();
/* 769 */         JSONObject localJSONObject2 = (JSONObject)localEntry.getValue();
/* 770 */         HashSet localHashSet = new HashSet();
/* 771 */         for (Iterator localIterator2 = localJSONObject2.keys(); localIterator2.hasNext(); ) {
/* 772 */           String str2 = (String)localIterator2.next();
/* 773 */           localHashSet.add(str2);
/*     */         }
/* 775 */         localHashMap.put(str1, localHashSet);
/*     */       }
/*     */     }
/* 778 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   public Number getStatisticsValue(String paramString1, String paramString2) {
/* 782 */     if (this.storeObj.containsKey("statistics")) {
/* 783 */       JSONObject localJSONObject1 = this.storeObj.getJSONObject("statistics");
/* 784 */       if (localJSONObject1.containsKey(paramString1)) {
/* 785 */         JSONObject localJSONObject2 = localJSONObject1.getJSONObject(paramString1);
/* 786 */         if (localJSONObject2.containsKey(paramString2)) {
/* 787 */           return (Number)localJSONObject2.get(paramString2);
/*     */         }
/*     */       }
/*     */     }
/* 791 */     return null;
/*     */   }
/*     */ 
/*     */   public void onRowSetNameSetted(String paramString) {
/* 795 */     MetaDataCreatorImpl localMetaDataCreatorImpl = new MetaDataCreatorImpl();
/* 796 */     MetaData localMetaData = localMetaDataCreatorImpl.afterRowSetNameSetted(paramString);
/* 797 */     if (localMetaData != null)
/* 798 */       setMetaData(localMetaData);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl
 * JD-Core Version:    0.6.2
 */