/*     */ package com.neusoft.unieap.techcomp.ria.ds;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.ColumnImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.RowImpl;
/*     */ import java.util.Map;
/*     */ 
/*     */ public final class DataCenterFactory
/*     */ {
/*     */   private static DataCenterFactory factory;
/*     */ 
/*     */   public static final DataCenterFactory getInstance()
/*     */   {
/*  30 */     if (factory == null) {
/*  31 */       factory = new DataCenterFactory();
/*     */     }
/*  33 */     return factory;
/*     */   }
/*     */ 
/*     */   public DataCenter createDataCenter()
/*     */   {
/*  44 */     return new DataCenterImpl();
/*     */   }
/*     */ 
/*     */   public DataStore createDataStore(String paramString)
/*     */   {
/*  57 */     return new DataStoreImpl(paramString);
/*     */   }
/*     */ 
/*     */   public DataStore createNullDataStore(String paramString)
/*     */   {
/*  70 */     return new DataStoreImpl(paramString, null);
/*     */   }
/*     */ 
/*     */   public Row createRow()
/*     */   {
/*  83 */     return new RowImpl();
/*     */   }
/*     */ 
/*     */   public Row createRow(Map paramMap)
/*     */   {
/*  99 */     return new RowImpl(paramMap);
/*     */   }
/*     */ 
/*     */   public MetaData createMetaData()
/*     */   {
/* 116 */     return new MetaDataImpl();
/*     */   }
/*     */ 
/*     */   public Column createColumn()
/*     */   {
/* 131 */     return new ColumnImpl();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory
 * JD-Core Version:    0.6.2
 */