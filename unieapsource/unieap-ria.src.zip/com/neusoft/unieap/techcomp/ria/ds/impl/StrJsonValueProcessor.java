/*    */ package com.neusoft.unieap.techcomp.ria.ds.impl;
/*    */ 
/*    */ import net.sf.json.JsonConfig;
/*    */ import net.sf.json.processors.JsonValueProcessor;
/*    */ 
/*    */ public class StrJsonValueProcessor
/*    */   implements JsonValueProcessor
/*    */ {
/*    */   public Object processArrayValue(Object paramObject, JsonConfig paramJsonConfig)
/*    */   {
/*  9 */     return paramObject;
/*    */   }
/*    */ 
/*    */   public Object processObjectValue(String paramString, Object paramObject, JsonConfig paramJsonConfig)
/*    */   {
/* 14 */     if (paramObject.equals("null"))
/* 15 */       paramObject = "'" + paramObject + "'";
/* 16 */     else if (((paramObject instanceof String)) && (((((String)paramObject).startsWith("{")) && 
/* 17 */       (((String)paramObject).endsWith("}"))) || (
/* 17 */       (((String)paramObject).startsWith("[")) && 
/* 18 */       (((String)paramObject).endsWith("]"))))) {
/* 19 */       paramObject = "'" + paramObject + "'";
/*    */     }
/* 21 */     return paramObject;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.ds.impl.StrJsonValueProcessor
 * JD-Core Version:    0.6.2
 */