package com.neusoft.unieap.techcomp.ria.codelist.bo;

import java.util.List;

public abstract interface ZoneCodeListBO
{
  public abstract List getZoneCodeList(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.bo.ZoneCodeListBO
 * JD-Core Version:    0.6.2
 */