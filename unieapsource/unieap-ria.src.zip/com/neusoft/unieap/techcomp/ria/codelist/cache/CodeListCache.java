package com.neusoft.unieap.techcomp.ria.codelist.cache;

import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
import java.io.Serializable;
import java.util.List;

public abstract interface CodeListCache extends Serializable
{
  public static final String REGION_NAME = "codelist";

  public abstract CodeList getCodeList(String paramString);

  public abstract List getAllCodeList();

  public abstract void putCodeList(String paramString, CodeList paramCodeList);

  public abstract void putCodeList(String paramString, CodeList paramCodeList, boolean paramBoolean);

  public abstract void removeCodeList(String paramString);

  public abstract void clearCodeList(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCache
 * JD-Core Version:    0.6.2
 */