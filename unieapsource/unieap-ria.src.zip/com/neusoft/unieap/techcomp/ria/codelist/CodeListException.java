/*    */ package com.neusoft.unieap.techcomp.ria.codelist;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class CodeListException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 3574721974874292526L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */ 
/*    */   public CodeListException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 19 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public CodeListException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 29 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.CodeListException
 * JD-Core Version:    0.6.2
 */