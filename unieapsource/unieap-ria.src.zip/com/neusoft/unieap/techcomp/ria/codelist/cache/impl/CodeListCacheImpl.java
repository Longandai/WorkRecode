/*     */ package com.neusoft.unieap.techcomp.ria.codelist.cache.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.exception.UniEAPException;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListException;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCache;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CodeListCacheImpl
/*     */   implements CodeListCache
/*     */ {
/*     */   private static final long serialVersionUID = 6817278485997300938L;
/*     */   private static final String REGION_NAME = "codelist";
/*     */   private EAPCacheManager eapCacheManager;
/*     */ 
/*     */   public EAPCacheManager getEapCacheManager()
/*     */   {
/*  24 */     return this.eapCacheManager;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/*  28 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public CodeList getCodeList(String paramString) {
/*  32 */     CodeList localCodeList = null;
/*     */     try {
/*  34 */       localCodeList = (CodeList)getEapCacheManager().get(paramString, 
/*  35 */         "codelist");
/*     */     } catch (UniEAPException localUniEAPException) {
/*  37 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/*  38 */         null);
/*     */     }
/*  40 */     return localCodeList;
/*     */   }
/*     */ 
/*     */   public void putCodeList(String paramString, CodeList paramCodeList) {
/*  44 */     putCodeList(paramString, paramCodeList, false);
/*     */   }
/*     */ 
/*     */   public void putCodeList(String paramString, CodeList paramCodeList, boolean paramBoolean)
/*     */   {
/*     */     try
/*     */     {
/*  51 */       getEapCacheManager().put(paramString, paramCodeList, "codelist", 
/*  52 */         paramBoolean);
/*     */     } catch (UniEAPException localUniEAPException) {
/*  54 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/*  55 */         null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Set listCacheKeys() {
/*  60 */     Set localSet = null;
/*     */     try {
/*  62 */       localSet = getEapCacheManager().getKeys("codelist");
/*     */     } catch (UniEAPException localUniEAPException) {
/*  64 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/*  65 */         null);
/*     */     }
/*  67 */     return localSet;
/*     */   }
/*     */ 
/*     */   public void clearCodeList(String paramString) {
/*     */     try {
/*  72 */       Iterator localIterator = listCacheKeys().iterator();
/*  73 */       while (localIterator.hasNext()) {
/*  74 */         String str = (String)localIterator.next();
/*  75 */         if (paramString.equals(str))
/*  76 */           getEapCacheManager().remove(paramString, "codelist");
/*     */       }
/*     */     }
/*     */     catch (UniEAPException localUniEAPException) {
/*  80 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/*  81 */         null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeCodeList(String paramString)
/*     */   {
/*     */     try {
/*  88 */       Iterator localIterator = listCacheKeys().iterator();
/*  89 */       while (localIterator.hasNext()) {
/*  90 */         String str = (String)localIterator.next();
/*  91 */         if (paramString.equals(str))
/*  92 */           getEapCacheManager().remove(paramString, "codelist");
/*     */       }
/*     */     }
/*     */     catch (UniEAPException localUniEAPException) {
/*  96 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/*  97 */         null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getAllCodeList()
/*     */   {
/* 103 */     ArrayList localArrayList = new ArrayList();
/*     */     try {
/* 105 */       Iterator localIterator = listCacheKeys().iterator();
/* 106 */       CodeList localCodeList = null;
/* 107 */       while (localIterator.hasNext()) {
/* 108 */         String str = (String)localIterator.next();
/* 109 */         localCodeList = (CodeList)getEapCacheManager().get(str, 
/* 110 */           "codelist");
/* 111 */         if (localCodeList != null)
/* 112 */           localArrayList.add(localCodeList);
/*     */       }
/*     */     }
/*     */     catch (UniEAPException localUniEAPException) {
/* 116 */       throw new CodeListException("EAPTECH009011", localUniEAPException, 
/* 117 */         null);
/*     */     }
/* 119 */     return localArrayList;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.cache.impl.CodeListCacheImpl
 * JD-Core Version:    0.6.2
 */