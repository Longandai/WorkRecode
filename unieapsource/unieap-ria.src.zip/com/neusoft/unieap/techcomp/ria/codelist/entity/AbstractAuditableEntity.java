/*    */ package com.neusoft.unieap.techcomp.ria.codelist.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.audit.Auditable;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class AbstractAuditableEntity
/*    */   implements Auditable
/*    */ {
/*    */   private String creator;
/*    */   private Timestamp creationTime;
/*    */   private Timestamp modificationTime;
/*    */   private String modifier;
/*    */ 
/*    */   public String getCreatedBy()
/*    */   {
/* 11 */     return this.creator;
/*    */   }
/*    */ 
/*    */   public void setCreatedBy(String paramString) {
/* 15 */     this.creator = paramString;
/*    */   }
/*    */ 
/*    */   public Timestamp getCreationTime()
/*    */   {
/* 21 */     return this.creationTime;
/*    */   }
/*    */ 
/*    */   public void setCreationTime(Timestamp paramTimestamp) {
/* 25 */     this.creationTime = paramTimestamp;
/*    */   }
/*    */ 
/*    */   public Timestamp getModificationTime()
/*    */   {
/* 31 */     return this.modificationTime;
/*    */   }
/*    */ 
/*    */   public void setModificationTime(Timestamp paramTimestamp) {
/* 35 */     this.modificationTime = paramTimestamp;
/*    */   }
/*    */ 
/*    */   public String getModifiedBy()
/*    */   {
/* 41 */     return this.modifier;
/*    */   }
/*    */ 
/*    */   public void setModifiedBy(String paramString) {
/* 45 */     this.modifier = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.entity.AbstractAuditableEntity
 * JD-Core Version:    0.6.2
 */