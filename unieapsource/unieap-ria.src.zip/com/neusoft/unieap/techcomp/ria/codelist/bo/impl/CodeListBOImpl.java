/*     */ package com.neusoft.unieap.techcomp.ria.codelist.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.dao.CacheObjectTimestampDAO;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.DateUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.bo.CodeListBO;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCache;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.dao.CodeListDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.util.Util;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class CodeListBOImpl
/*     */   implements CodeListBO
/*     */ {
/*     */   private static final long serialVersionUID = 2023892076596186119L;
/*  29 */   private static final LocalizedTextUtil util = LocalizedTextUtil.getLocalizedTextUtil(CodeListBOImpl.class);
/*     */ 
/*  32 */   private static final Logger logger = LoggerFactory.getLogger(CodeListBOImpl.class);
/*     */   private CodeListCache codeListCache;
/*  37 */   private boolean updateTimeStamp = false;
/*     */   private CodeListDAO codeListDAO;
/*     */   private static CacheObjectTimestampDAO cacheObjectTimestampDAO;
/*     */ 
/*     */   public void setCodeListCache(CodeListCache paramCodeListCache)
/*     */   {
/*  40 */     this.codeListCache = paramCodeListCache;
/*     */   }
/*     */ 
/*     */   public void setCodeListDAO(CodeListDAO paramCodeListDAO) {
/*  44 */     this.codeListDAO = paramCodeListDAO;
/*     */   }
/*     */ 
/*     */   public void setCacheObjectTimestampDAO(CacheObjectTimestampDAO paramCacheObjectTimestampDAO)
/*     */   {
/*  53 */     cacheObjectTimestampDAO = paramCacheObjectTimestampDAO;
/*     */   }
/*     */ 
/*     */   public void initCache() {
/*     */     try {
/*  58 */       List localList = this.codeListDAO.getAllCodeList();
/*  59 */       if (localList != null)
/*  60 */         for (int i = 0; i < localList.size(); i++) {
/*  61 */           CodeList localCodeList = (CodeList)localList.get(i);
/*  62 */           this.codeListCache.putCodeList(localCodeList.getName(), localCodeList, true);
/*     */         }
/*     */     }
/*     */     catch (Exception localException) {
/*  66 */       String str = util
/*  67 */         .findText("codelist.CodeListCacheLoader.bootstrapLoadFailure.error");
/*  68 */       logger.error(str, localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Code getCode(String paramString1, String paramString2) {
/*  73 */     CodeList localCodeList = getCodeList(paramString1);
/*  74 */     if (localCodeList != null) {
/*  75 */       List localList = localCodeList.getCode(paramString2);
/*  76 */       if (localList.size() > 0) {
/*  77 */         return (Code)localList.get(0);
/*     */       }
/*     */     }
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */   public CodeList getCodeList(String paramString) {
/*  84 */     if (Util.isNullOrEmpty(paramString))
/*  85 */       throw new IllegalArgumentException(
/*  86 */         "Invalid codeListCoding, codeListCoding is null or empty");
/*  87 */     CodeList localCodeList1 = null;
/*  88 */     CodeList localCodeList2 = this.codeListCache.getCodeList(paramString);
/*     */ 
/*  90 */     if (localCodeList2 != null) {
/*  91 */       localCodeList1 = new CodeList();
/*  92 */       localCodeList1.setName(paramString);
/*  93 */       Locale localLocale = getLocale();
/*  94 */       String str1 = localLocale.toString();
/*  95 */       if (localCodeList2 != null) {
/*  96 */         if (localCodeList2.getCodeListMap().get(str1) == null)
/*     */         {
/*  98 */           String str2 = getSysDefaultLoacle().toString();
/*  99 */           if (localCodeList2.getCodeListMap().get(str2) != null)
/* 100 */             localCodeList1.getCodeListMap().put(str2, 
/* 101 */               (List)localCodeList2.getCodeListMap().get(str2));
/*     */         }
/*     */         else {
/* 104 */           localCodeList1.getCodeListMap().put(str1, 
/* 105 */             (List)localCodeList2.getCodeListMap().get(str1));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 110 */     return localCodeList1;
/*     */   }
/*     */ 
/*     */   private Locale getLocale() {
/* 114 */     return GlobalService.getUserI18nContext().getLocale();
/*     */   }
/*     */ 
/*     */   private Locale getSysDefaultLoacle() {
/* 118 */     return GlobalService.getDefaultI18nContext().getLocale();
/*     */   }
/*     */ 
/*     */   public void putCode(String paramString, Code paramCode)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void putCodeList(CodeList paramCodeList)
/*     */   {
/* 127 */     if ((paramCodeList != null) && (paramCodeList.getName() != null) && 
/* 128 */       (!paramCodeList.getName().equals("")))
/* 129 */       this.codeListCache.putCodeList(paramCodeList.getName(), paramCodeList);
/*     */   }
/*     */ 
/*     */   public void removeCode(String paramString1, String paramString2)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void removeCodeList(String paramString)
/*     */   {
/* 140 */     this.codeListCache.removeCodeList(paramString);
/*     */   }
/*     */ 
/*     */   public List getAllCodeList()
/*     */   {
/* 145 */     return this.codeListCache.getAllCodeList();
/*     */   }
/*     */ 
/*     */   public boolean isUpdateTimeStamp() {
/* 149 */     return this.updateTimeStamp;
/*     */   }
/*     */ 
/*     */   public void setUpdateTimeStamp(boolean paramBoolean) {
/* 153 */     this.updateTimeStamp = paramBoolean;
/*     */   }
/*     */ 
/*     */   public QueryResult getAllCodelist() {
/* 157 */     return this.codeListDAO.getAllCodelist();
/*     */   }
/*     */ 
/*     */   public QueryResult getCodelistByCode(Code paramCode) {
/* 161 */     return this.codeListDAO.getCodelistByCode(paramCode);
/*     */   }
/*     */ 
/*     */   public void deleteCodelist(String paramString) {
/* 165 */     String str = "codelist_" + paramString;
/* 166 */     this.codeListDAO.deleteCodelist(paramString);
/* 167 */     cacheObjectTimestampDAO.deleteCacheTimestampByType(str);
/*     */   }
/*     */ 
/*     */   public boolean queryCodelist(String paramString) {
/* 171 */     return this.codeListDAO.queryCodelist(paramString);
/*     */   }
/*     */ 
/*     */   public String queryCode(List<Code> paramList) {
/* 175 */     return this.codeListDAO.queryCode(paramList);
/*     */   }
/*     */ 
/*     */   public BOContext saveCodeList(Code paramCode, List<Code> paramList)
/*     */   {
/* 180 */     String str1 = "codelist_" + paramCode.getCodetype();
/* 181 */     String str2 = getDBServerTime();
/* 182 */     Object localObject = new ArrayList();
/* 183 */     String str3 = paramCode.getCodetype();
/* 184 */     if ((paramList != null) && (paramList.size() > 0)) {
/* 185 */       str3 = ((Code)paramList.get(0)).getCodetype();
/*     */     }
/* 187 */     this.codeListDAO.deleteCodelist(str3);
/*     */ 
/* 189 */     if (paramList.size() == 0) {
/* 190 */       cacheObjectTimestampDAO.deleteCacheTimestampByType(str1);
/*     */     } else {
/* 192 */       for (int i = 0; i < paramList.size(); i++) {
/* 193 */         ((Code)paramList.get(i)).setId(null);
/* 194 */         ((Code)paramList.get(i)).setCodetype(paramCode.getCodetype());
/* 195 */         ((Code)paramList.get(i)).setCodetypeName(paramCode.getCodetypeName());
/*     */       }
/* 197 */       localObject = this.codeListDAO.saveCodeList(paramList);
/*     */ 
/* 199 */       if (!this.codeListDAO.queryCacheTimestamp(str1))
/* 200 */         cacheObjectTimestampDAO.addCacheTimestampByType(str1);
/*     */       else {
/* 202 */         cacheObjectTimestampDAO.updateCacheTimestampByType(str1, str2);
/*     */       }
/*     */     }
/*     */ 
/* 206 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 207 */     localBOContextImpl.put("code", localObject);
/* 208 */     return localBOContextImpl;
/*     */   }
/*     */ 
/*     */   public static String getDBServerTime() {
/* 212 */     String str = DateUtil.getDate(cacheObjectTimestampDAO
/* 213 */       .getDBServerTime(), "YYYY-MM-DD HH24:MI:SS");
/* 214 */     return str;
/*     */   }
/*     */ 
/*     */   public QueryResult getCodeByCodeType(String paramString) {
/* 218 */     return this.codeListDAO.getCodeByCodeType(paramString);
/*     */   }
/*     */ 
/*     */   public QueryResult getCodelistByCode(String paramString1, String paramString2) {
/* 222 */     Code localCode = new Code();
/* 223 */     localCode.setCodetype(paramString1);
/* 224 */     localCode.setCodetypeName(paramString2);
/* 225 */     return getCodelistByCode(localCode);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.bo.impl.CodeListBOImpl
 * JD-Core Version:    0.6.2
 */