/*    */ package com.neusoft.unieap.techcomp.ria.codelist.activator;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.cache.CacheLoader;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.ICacheUpdater;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.bo.CodeListBO;
/*    */ import java.util.List;
/*    */ 
/*    */ public class CodelistActivator
/*    */ {
/* 16 */   private boolean cacheAllOnStartUp = false;
/*    */ 
/* 18 */   private boolean isLoaded = false;
/*    */ 
/* 20 */   private boolean updateTimeStampOnStartUp = false;
/*    */ 
/* 50 */   private CodeListBO codeListBO = null;
/*    */   private EAPCacheManager manager;
/*    */   private CacheSynchronizeManager cacheSynchronizeManager;
/*    */   private ICacheUpdater codeListCacheUpdater;
/*    */ 
/*    */   public void startup()
/*    */     throws Exception
/*    */   {
/* 23 */     if ((isCacheAllOnStartUp()) && (!this.isLoaded)) {
/* 24 */       if (this.cacheSynchronizeManager != null)
/*    */       {
/* 26 */         this.cacheSynchronizeManager.registerCacheUpdater("codelist", this.codeListCacheUpdater);
/*    */       }
/* 28 */       this.codeListBO.initCache();
/*    */ 
/* 30 */       if (isUpdateTimeStampOnStartUp()) {
/* 31 */         this.codeListBO.setUpdateTimeStamp(isUpdateTimeStampOnStartUp());
/* 32 */         List localList = this.codeListBO.getAllCodeList();
/* 33 */         for (int i = 0; i < localList.size(); i++) {
/* 34 */           CodeList localCodeList = (CodeList)localList.get(i);
/* 35 */           this.cacheSynchronizeManager.updateCacheStatusBySysTime("codelist_" + localCodeList.getName());
/*    */         }
/*    */       }
/* 38 */       this.isLoaded = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isCacheAllOnStartUp() {
/* 43 */     return this.cacheAllOnStartUp;
/*    */   }
/*    */ 
/*    */   public void setCacheAllOnStartUp(boolean paramBoolean) {
/* 47 */     this.cacheAllOnStartUp = paramBoolean;
/*    */   }
/*    */ 
/*    */   public void setCodeListBO(CodeListBO paramCodeListBO)
/*    */   {
/* 53 */     this.codeListBO = paramCodeListBO;
/*    */   }
/*    */ 
/*    */   public void setCacheLoader(CacheLoader paramCacheLoader) {
/* 57 */     if ((this.manager != null) && (paramCacheLoader != null))
/* 58 */       this.manager.registerCacheLoader("codelist", paramCacheLoader);
/*    */   }
/*    */ 
/*    */   public void setCacheManager(EAPCacheManager paramEAPCacheManager)
/*    */   {
/* 65 */     this.manager = paramEAPCacheManager;
/*    */   }
/*    */ 
/*    */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*    */   {
/* 72 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*    */   }
/*    */ 
/*    */   public void setCodeListCacheUpdater(ICacheUpdater paramICacheUpdater)
/*    */   {
/* 78 */     this.codeListCacheUpdater = paramICacheUpdater;
/*    */   }
/*    */ 
/*    */   public void setUpdateTimeStampOnStartUp(boolean paramBoolean) {
/* 82 */     this.updateTimeStampOnStartUp = paramBoolean;
/*    */   }
/*    */ 
/*    */   public boolean isUpdateTimeStampOnStartUp() {
/* 86 */     return this.updateTimeStampOnStartUp;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.activator.CodelistActivator
 * JD-Core Version:    0.6.2
 */