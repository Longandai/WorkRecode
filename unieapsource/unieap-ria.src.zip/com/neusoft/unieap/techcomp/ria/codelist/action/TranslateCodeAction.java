/*     */ package com.neusoft.unieap.techcomp.ria.codelist.action;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheStatus;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.DateUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.util.Util;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONArray;
/*     */ 
/*     */ public class TranslateCodeAction extends BaseProcessor
/*     */ {
/*     */   private static final long serialVersionUID = -6305728536322552835L;
/*  29 */   private String STORE = "store";
/*     */   private static final String CODENAME = "CODENAME";
/*     */   private static final String CODEVALUE = "CODEVALUE";
/*     */   private static final String ID = "ID";
/*     */   private static final String PARENTID = "PARENTID";
/*     */   private static final String FILTER = "FILTER";
/*  36 */   private CodeListManager codeListManager = null;
/*     */ 
/*  38 */   private CacheSynchronizeManager cacheSynchronizeManager = null;
/*     */ 
/*     */   public void setCodeListManager(CodeListManager paramCodeListManager)
/*     */   {
/*  46 */     this.codeListManager = paramCodeListManager;
/*     */   }
/*     */ 
/*     */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*     */   {
/*  55 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*     */   }
/*     */ 
/*     */   public void getSingleCodeListByStore()
/*     */     throws Exception
/*     */   {
/*  64 */     ViewContext localViewContext = generateContext();
/*  65 */     String str = localViewContext.getString(this.STORE);
/*  66 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  67 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/*  68 */     if (Util.isNullOrEmpty(str)) {
/*  69 */       write(localDataCenter);
/*  70 */       return;
/*     */     }
/*     */ 
/*  73 */     CodeList localCodeList = this.codeListManager.getCodeList(str);
/*  74 */     if (localCodeList != null) {
/*  75 */       DataStore localDataStore = localDataCenterFactory.createDataStore(str.trim());
/*  76 */       RowSet localRowSet = localDataStore.getRowSet();
/*  77 */       Code localCode = null;
/*  78 */       ArrayList localArrayList = new ArrayList();
/*  79 */       List localList = localCodeList.getSoleCodeList();
/*  80 */       if (localList != null) {
/*  81 */         localArrayList.addAll(localList);
/*     */       }
/*  83 */       for (int i = 0; i < localArrayList.size(); i++) {
/*  84 */         localCode = (Code)localArrayList.get(i);
/*  85 */         HashMap localHashMap = new HashMap();
/*  86 */         localHashMap.put("ID", localCode.getCodeValue());
/*  87 */         localHashMap.put("CODENAME", localCode.getCodeName());
/*  88 */         localHashMap.put("CODEVALUE", localCode.getCodeValue());
/*  89 */         localHashMap.put("PARENTID", localCode.getParent());
/*  90 */         localHashMap.put("FILTER", localCode.getFilter());
/*  91 */         localRowSet.addRowData(localHashMap);
/*     */       }
/*  93 */       localDataCenter.addDataStore(localDataStore);
/*  94 */       Long localLong = getCodeTimeStamp(str);
/*  95 */       if (localLong != null) {
/*  96 */         localDataCenter.addParameter(str, localLong);
/*     */       }
/*     */     }
/*  99 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getAllCodesByCodelistKey()
/*     */     throws Exception
/*     */   {
/* 107 */     ViewContext localViewContext = generateContext();
/* 108 */     String str = localViewContext.getString(this.STORE);
/* 109 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 110 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 111 */     if (Util.isNullOrEmpty(str)) {
/* 112 */       write(localDataCenter);
/* 113 */       return;
/*     */     }
/*     */ 
/* 134 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getSingleCodesListByParam()
/*     */     throws Exception
/*     */   {
/* 143 */     String str = super.generateContext().getString("codeListCoding");
/* 144 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 145 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 146 */     if (Util.isNullOrEmpty(str)) {
/* 147 */       write(localDataCenter);
/* 148 */       return;
/*     */     }
/* 150 */     str = str.trim();
/* 151 */     CodeList localCodeList = this.codeListManager.getCodeList(str);
/* 152 */     if (localCodeList != null) {
/* 153 */       DataStore localDataStore = localDataCenterFactory.createDataStore(str);
/* 154 */       RowSet localRowSet = localDataStore.getRowSet();
/* 155 */       Code localCode = null;
/* 156 */       ArrayList localArrayList = new ArrayList();
/* 157 */       List localList = localCodeList.getSoleCodeList();
/* 158 */       if (localList != null) {
/* 159 */         localArrayList.addAll(localList);
/*     */       }
/* 161 */       for (int i = 0; i < localArrayList.size(); i++) {
/* 162 */         localCode = (Code)localArrayList.get(i);
/* 163 */         HashMap localHashMap = new HashMap();
/* 164 */         localHashMap.put("ID", localCode.getCodeValue());
/* 165 */         localHashMap.put("CODENAME", localCode.getCodeName());
/* 166 */         localHashMap.put("CODEVALUE", localCode.getCodeValue());
/* 167 */         localHashMap.put("PARENTID", localCode.getParent());
/* 168 */         localHashMap.put("FILTER", localCode.getFilter());
/* 169 */         localRowSet.addRowData(localHashMap);
/*     */       }
/* 171 */       localDataCenter.addDataStore(localDataStore);
/* 172 */       Long localLong = getCodeTimeStamp(str);
/* 173 */       if (localLong != null) {
/* 174 */         localDataCenter.addParameter(str, localLong);
/*     */       }
/*     */     }
/* 177 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getMultiCodeList()
/*     */     throws Exception
/*     */   {
/* 185 */     getResponse().reset();
/* 186 */     ViewContext localViewContext = generateContext();
/* 187 */     JSONArray localJSONArray = (JSONArray)localViewContext.get("stores");
/* 188 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 189 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 190 */     if (localJSONArray == null) {
/* 191 */       write(localDataCenter);
/* 192 */       return;
/*     */     }
/* 194 */     for (int i = 0; i < localJSONArray.size(); i++) {
/* 195 */       String str = localJSONArray.getString(i);
/* 196 */       if (!str.trim().equals("")) {
/* 197 */         CodeList localCodeList = this.codeListManager.getCodeList(str);
/* 198 */         if (localCodeList != null) {
/* 199 */           DataStore localDataStore = localDataCenterFactory.createDataStore(str);
/* 200 */           RowSet localRowSet = localDataStore.getRowSet();
/* 201 */           Code localCode = null;
/* 202 */           ArrayList localArrayList = new ArrayList();
/* 203 */           List localList = localCodeList.getSoleCodeList();
/* 204 */           if (localList != null) {
/* 205 */             localArrayList.addAll(localList);
/*     */           }
/* 207 */           for (int j = 0; j < localArrayList.size(); j++) {
/* 208 */             localCode = (Code)localArrayList.get(j);
/* 209 */             HashMap localHashMap = new HashMap();
/* 210 */             localHashMap.put("ID", localCode.getCodeValue());
/* 211 */             localHashMap.put("CODENAME", localCode.getCodeName());
/* 212 */             localHashMap.put("CODEVALUE", localCode.getCodeValue());
/* 213 */             localHashMap.put("PARENTID", localCode.getParent());
/* 214 */             localHashMap.put("FILTER", localCode.getFilter());
/* 215 */             localRowSet.addRowData(localHashMap);
/*     */           }
/* 217 */           localDataCenter.addDataStore(localDataStore);
/* 218 */           Long localLong = getCodeTimeStamp(str);
/* 219 */           if (localLong != null) {
/* 220 */             localDataCenter.addParameter(str, localLong);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 225 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private Long getCodeTimeStamp(String paramString) {
/* 229 */     Map localMap = this.cacheSynchronizeManager.getAllCacheStatus();
/* 230 */     if ((paramString != null) && (!paramString.equals(""))) {
/* 231 */       String str = "codelist_" + paramString;
/* 232 */       if (localMap != null) {
/* 233 */         CacheStatus localCacheStatus = (CacheStatus)localMap.get(str);
/* 234 */         if (localCacheStatus != null) {
/* 235 */           Date localDate = DateUtil.stringToDate(localCacheStatus.getUpdateTime(), "YYYY-MM-DD HH24:MI:SS");
/* 236 */           if (localDate != null) {
/* 237 */             return Long.valueOf(localDate.getTime());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 242 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.action.TranslateCodeAction
 * JD-Core Version:    0.6.2
 */