package com.neusoft.unieap.techcomp.ria.codelist.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
import java.util.List;

public abstract interface CodeListDAO
{
  public abstract List getAllCodeList();

  public abstract CodeList getCodeListByName(String paramString);

  public abstract QueryResult getAllCodelist();

  public abstract QueryResult getCodelistByCode(Code paramCode);

  public abstract void deleteCodelist(String paramString);

  public abstract boolean queryCodelist(String paramString);

  public abstract List<Code> saveCodeList(List<Code> paramList);

  public abstract boolean queryCacheTimestamp(String paramString);

  public abstract String queryCode(List<Code> paramList);

  public abstract QueryResult getCodeByCodeType(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.dao.CodeListDAO
 * JD-Core Version:    0.6.2
 */