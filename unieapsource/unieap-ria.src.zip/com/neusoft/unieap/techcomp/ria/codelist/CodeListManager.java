package com.neusoft.unieap.techcomp.ria.codelist;

import java.io.Serializable;
import java.util.List;

public abstract interface CodeListManager extends Serializable
{
  public static final String ROOT = "-1";

  public abstract CodeList getCodeList(String paramString);

  public abstract List getAllCodeList();

  public abstract void putCodeList(CodeList paramCodeList);

  public abstract void removeCodeList(String paramString);

  public abstract boolean validCodeRangeValue(String paramString1, String paramString2);

  public abstract boolean validCodeRangeName(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.CodeListManager
 * JD-Core Version:    0.6.2
 */