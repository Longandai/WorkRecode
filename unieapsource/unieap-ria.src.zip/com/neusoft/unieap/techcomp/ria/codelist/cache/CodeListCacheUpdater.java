/*    */ package com.neusoft.unieap.techcomp.ria.codelist.cache;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.ICacheUpdater;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.CacheTaskUtil;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.dao.CodeListDAO;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class CodeListCacheUpdater
/*    */   implements ICacheUpdater
/*    */ {
/*    */   public static final String CODELIST_PREFIX = "codelist_";
/*    */   private CacheTaskUtil cacheTaskUtil;
/*    */   private CodeListCache codeListCache;
/*    */   private CodeListDAO codeListDAO;
/* 34 */   private static final Logger logger = LoggerFactory.getLogger(CodeListCacheUpdater.class);
/*    */ 
/*    */   public void setCodeListCache(CodeListCache paramCodeListCache)
/*    */   {
/* 23 */     this.codeListCache = paramCodeListCache;
/*    */   }
/*    */ 
/*    */   public void setCacheTaskUtil(CacheTaskUtil paramCacheTaskUtil) {
/* 27 */     this.cacheTaskUtil = paramCacheTaskUtil;
/*    */   }
/*    */ 
/*    */   public void setCodeListDAO(CodeListDAO paramCodeListDAO) {
/* 31 */     this.codeListDAO = paramCodeListDAO;
/*    */   }
/*    */ 
/*    */   public void update(String paramString)
/*    */     throws Exception
/*    */   {
/* 39 */     String str = paramString.substring("codelist_".length());
/* 40 */     if ((str != null) && (!str.equals(""))) {
/* 41 */       CodeList localCodeList = this.codeListDAO.getCodeListByName(str);
/* 42 */       this.codeListCache.putCodeList(str, localCodeList, true);
/* 43 */       CacheTaskUtil.updateCache(paramString);
/* 44 */       logger.info(paramString + " has updated...");
/*    */     } else {
/* 46 */       logger.info(paramString + " is unKnowned...");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCacheUpdater
 * JD-Core Version:    0.6.2
 */