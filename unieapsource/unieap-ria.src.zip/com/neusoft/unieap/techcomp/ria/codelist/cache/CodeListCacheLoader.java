/*    */ package com.neusoft.unieap.techcomp.ria.codelist.cache;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.cache.CacheLoader;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.dao.CodeListDAO;
/*    */ 
/*    */ public class CodeListCacheLoader
/*    */   implements CacheLoader
/*    */ {
/*    */   private CodeListDAO codeListDAO;
/*    */ 
/*    */   public Object load(Object paramObject)
/*    */   {
/* 15 */     String str = (String)paramObject;
/* 16 */     CodeList localCodeList = getCodeListDAO().getCodeListByName(str);
/* 17 */     if (localCodeList == null)
/* 18 */       return null;
/* 19 */     return localCodeList;
/*    */   }
/*    */ 
/*    */   public CodeListDAO getCodeListDAO() {
/* 23 */     return this.codeListDAO;
/*    */   }
/*    */ 
/*    */   public void setCodeListDAO(CodeListDAO paramCodeListDAO) {
/* 27 */     this.codeListDAO = paramCodeListDAO;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void init()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCacheLoader
 * JD-Core Version:    0.6.2
 */