package com.neusoft.unieap.techcomp.ria.codelist;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class CodeListExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "009";
  private static final String _P = "EAPTECH009";
  public static final String SYS_CODEGROUP_SAVED_OBJ_CAN_NOT_SAVE = "EAPTECH009001";
  public static final String SYS_CODEGROUP_UNSAVED_OBJ_CAN_NOT_UPDATE = "EAPTECH009002";
  public static final String SYS_CODEGROUP_INVALID_PARENTID = "EAPTECH009003";
  public static final String SYS_CODECATEGORY_SAVED_OBJ_CAN_NOT_SAVE = "EAPTECH009004";
  public static final String SYS_CODECATEGORY_UNSAVED_OBJ_CAN_NOT_UPDATE = "EAPTECH009005";
  public static final String SYS_CODECATEGORY_INVALID_GROUPID = "EAPTECH009006";
  public static final String SYS_INVALID_GROUPCODING = "EAPTECH009007";
  public static final String SYS_CODEITEM_SAVED_OBJ_CAN_NOT_SAVE = "EAPTECH009008";
  public static final String SYS_CODEITEM_UNSAVED_OBJ_CAN_NOT_UPDATE = "EAPTECH009009";
  public static final String SYS_CODEITEM_INVALID_PARENTID = "EAPTECH009010";
  public static final String SYS_CACHE_EXP = "EAPTECH009011";
  public static final String TARGET_GROUP_NOEXIT = "EAPTECH009012";
  public static final String PARENT_GROUP_NOEXIT = "EAPTECH009013";
  public static final String PARENT_CODE_NOEXIT = "EAPTECH009014";
  public static final String SYS_DAO_EXP = "EAPTECH009031";
  public static final String SERV_NOTEMPTY_GROUP_CANNOT_DELETE = "EAPTECH009022";
  public static final String CODEGROUP_NAME_IS_NULL = "EAPTECH009030";
  public static final String CODELIST_NAME_IS_NULL = "EAPTECH009040";
  public static final String CODELIST_IS_NULL = "EAPTECH009041";
  public static final String CODE_NAME_IS_NULL = "EAPTECH009050";
  public static final String CODE_VALUE_IS_NULL = "EAPTECH009051";
  public static final String CODELISTGROUP_CODE_HAS_EXIST = "EAPTECH009052";
  public static final String CODELIST_CODE_HAS_EXIST = "EAPTECH009053";
  public static final String CODELISTGROUP_CODE_HAS_CODELIST = "EAPTECH009054";
  public static final String CODELISTGROUP_CODELIST_HAS_CODELISTITEM = "EAPTECH009055";
  public static final String CODELISTGROUP_CODEITEM_HAS_SUBCODEITEM = "EAPTECH009056";
  public static final String CODELISTITEM_CODE_HAS_EXIST = "EAPTECH009057";
  public static final String CODELISTITEM_CODELIST_IS_NULL = "EAPTECH009058";
  public static final String CODELISTITEM_CODELIST_HAS_SUBCODEITEM = "EAPTECH009059";
  public static final String CODELIST_DEFAULT_NOT_FOUND = "EAPTECH009060";
  public static final String CODE_DEFAULT_NOT_FOUND = "EAPTECH009061";
  public static final String UPDATE_IS_UNVALID = "EAPTECH009062";
  public static final String CODELIST_HAS_DELETED = "EAPTECH009063";
  public static final String CODEITEM_IS_NULL = "EAPTECH009064";
  public static final String CONSTANTCODETYPE_CONSTRUCTOR_INVOKE_FAIL = "EAPTECH009065";
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.CodeListExceptionCode
 * JD-Core Version:    0.6.2
 */