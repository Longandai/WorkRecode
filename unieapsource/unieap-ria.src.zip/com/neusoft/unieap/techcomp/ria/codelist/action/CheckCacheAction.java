/*     */ package com.neusoft.unieap.techcomp.ria.codelist.action;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheStatus;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.DateUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class CheckCacheAction extends BaseProcessor
/*     */ {
/*     */   private static final String CODENAME = "CODENAME";
/*     */   private static final String CODEVALUE = "CODEVALUE";
/*     */   private static final String ID = "ID";
/*     */   private static final String PARENTID = "PARENTID";
/*     */   private static final String FILTER = "FILTER";
/*  34 */   private CodeListManager codeListManager = null;
/*     */ 
/*  36 */   private CacheSynchronizeManager cacheSynchronizeManager = null;
/*     */   private static final long serialVersionUID = -1223163629283832802L;
/*     */ 
/*     */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*     */   {
/*  45 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*     */   }
/*     */ 
/*     */   private Long getCodeTimeStamp(String paramString)
/*     */   {
/*  54 */     Map localMap = this.cacheSynchronizeManager.getAllCacheStatus();
/*  55 */     if ((paramString != null) && (!paramString.equals(""))) {
/*  56 */       String str = "codelist_" + paramString;
/*  57 */       if (localMap != null) {
/*  58 */         CacheStatus localCacheStatus = (CacheStatus)localMap.get(str);
/*  59 */         if (localCacheStatus != null) {
/*  60 */           Date localDate = DateUtil.stringToDate(localCacheStatus.getUpdateTime(), 
/*  61 */             "YYYY-MM-DD HH24:MI:SS");
/*  62 */           if (localDate != null) {
/*  63 */             return Long.valueOf(localDate.getTime());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   public void checkCacheData() throws Exception {
/*  72 */     ViewContext localViewContext = generateContext();
/*     */ 
/*  74 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  75 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/*  76 */     String str1 = (String)localViewContext.get("mode");
/*     */     Object localObject1;
/*     */     JSONObject localJSONObject1;
/*     */     Iterator localIterator;
/*     */     JSONObject localJSONObject2;
/*     */     Object localObject2;
/*     */     Object localObject3;
/*     */     Object localObject4;
/*     */     long l;
/*     */     Long localLong2;
/*  77 */     if (str1.equals("check"))
/*     */     {
/*  80 */       localObject1 = localViewContext.get("timeStamps");
/*  81 */       if ((localObject1 instanceof String))
/*  82 */         localJSONObject1 = JSONObject.fromObject(localObject1);
/*     */       else {
/*  84 */         localJSONObject1 = (JSONObject)localObject1;
/*     */       }
/*  86 */       if (localJSONObject1 != null) {
/*  87 */         localIterator = localJSONObject1.entrySet().iterator();
/*  88 */         localJSONObject2 = new JSONObject();
/*  89 */         while (localIterator.hasNext()) {
/*  90 */           localObject2 = (Map.Entry)localIterator.next();
/*  91 */           localObject3 = (String)((Map.Entry)localObject2).getKey();
/*  92 */           localObject4 = (Long)((Map.Entry)localObject2).getValue();
/*  93 */           l = ((Long)localObject4).longValue();
/*     */ 
/*  95 */           localLong2 = getCodeTimeStamp((String)localObject3);
/*     */ 
/*  97 */           if (localLong2 == null)
/*  98 */             localJSONObject2.put(localObject3, Long.valueOf(0L));
/*  99 */           else if (l != localLong2.longValue()) {
/* 100 */             localJSONObject2
/* 101 */               .put(localObject3, Long.valueOf(localLong2.longValue()));
/*     */           }
/*     */         }
/* 104 */         localDataCenter.addParameter("timeStamps", localJSONObject2);
/*     */       }
/* 106 */     } else if (str1.equals("update"))
/*     */     {
/* 109 */       localObject1 = localViewContext.get("timeStamps");
/* 110 */       if ((localObject1 instanceof String))
/* 111 */         localJSONObject1 = JSONObject.fromObject(localObject1);
/*     */       else {
/* 113 */         localJSONObject1 = (JSONObject)localObject1;
/*     */       }
/* 115 */       if (localJSONObject1 != null) {
/* 116 */         localIterator = localJSONObject1.entrySet().iterator();
/* 117 */         localJSONObject2 = new JSONObject();
/* 118 */         if (localJSONObject1.size() > 0) {
/* 119 */           while (localIterator.hasNext()) {
/* 120 */             localObject2 = (Map.Entry)localIterator.next();
/* 121 */             localObject3 = (String)((Map.Entry)localObject2).getKey();
/* 122 */             localObject4 = (Long)((Map.Entry)localObject2).getValue();
/* 123 */             l = ((Long)localObject4).longValue();
/*     */ 
/* 125 */             localLong2 = getCodeTimeStamp((String)localObject3);
/*     */             DataStore localDataStore;
/* 127 */             if (localLong2 == null) {
/* 128 */               localDataStore = getCodeListDSByKey((String)localObject3);
/* 129 */               if (localDataStore != null) {
/* 130 */                 localJSONObject2.put(localObject3, Long.valueOf(0L));
/* 131 */                 localDataCenter.addDataStore(localDataStore);
/*     */               }
/* 133 */             } else if (l != localLong2
/* 134 */               .longValue()) {
/* 135 */               localDataStore = getCodeListDSByKey((String)localObject3);
/* 136 */               if (localDataStore != null) {
/* 137 */                 localJSONObject2.put(localObject3, 
/* 138 */                   Long.valueOf(localLong2.longValue()));
/* 139 */                 localDataCenter.addDataStore(localDataStore);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 145 */           localObject2 = getAllCodeListDS();
/* 146 */           for (localObject4 = ((List)localObject2).iterator(); ((Iterator)localObject4).hasNext(); ) { localObject3 = (DataStore)((Iterator)localObject4).next();
/* 147 */             String str2 = ((DataStore)localObject3).getStoreName();
/* 148 */             Long localLong1 = getCodeTimeStamp(str2);
/* 149 */             localDataCenter.addDataStore((DataStore)localObject3);
/* 150 */             localJSONObject2.put(str2, 
/* 151 */               Long.valueOf(localLong1.longValue()));
/*     */           }
/*     */         }
/* 154 */         localDataCenter.addParameter("timeStamps", localJSONObject2);
/*     */       }
/*     */     }
/*     */ 
/* 158 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private List<DataStore> getAllCodeListDS() {
/* 162 */     ArrayList localArrayList = new ArrayList();
/* 163 */     List localList = getCodeListManager().getAllCodeList();
/* 164 */     if ((localList != null) && (localList.size() > 0)) {
/* 165 */       for (CodeList localCodeList : localList) {
/* 166 */         localArrayList.add(generateCodeListStore(localCodeList));
/*     */       }
/*     */     }
/* 169 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private DataStore getCodeListDSByKey(String paramString) {
/* 173 */     CodeList localCodeList = getCodeListManager().getCodeList(paramString);
/* 174 */     if (localCodeList != null) {
/* 175 */       return generateCodeListStore(localCodeList);
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   private DataStore generateCodeListStore(CodeList paramCodeList) {
/* 181 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore(
/* 182 */       paramCodeList.getName());
/* 183 */     RowSet localRowSet = localDataStore.getRowSet();
/* 184 */     Code localCode = null;
/* 185 */     ArrayList localArrayList = new ArrayList();
/* 186 */     List localList = paramCodeList.getSoleCodeList();
/* 187 */     if (localList != null) {
/* 188 */       localArrayList.addAll(localList);
/*     */     }
/* 190 */     for (int i = 0; i < localArrayList.size(); i++) {
/* 191 */       localCode = (Code)localArrayList.get(i);
/* 192 */       HashMap localHashMap = new HashMap();
/* 193 */       localHashMap.put("ID", localCode.getCodeValue());
/* 194 */       localHashMap.put("CODENAME", localCode.getCodeName());
/* 195 */       localHashMap.put("CODEVALUE", localCode.getCodeValue());
/* 196 */       localHashMap.put("PARENTID", localCode.getParent());
/* 197 */       localHashMap.put("FILTER", localCode.getFilter());
/* 198 */       localRowSet.addRowData(localHashMap);
/*     */     }
/* 200 */     return localDataStore;
/*     */   }
/*     */ 
/*     */   public void setCodeListManager(CodeListManager paramCodeListManager) {
/* 204 */     this.codeListManager = paramCodeListManager;
/*     */   }
/*     */ 
/*     */   public CodeListManager getCodeListManager() {
/* 208 */     return this.codeListManager;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.action.CheckCacheAction
 * JD-Core Version:    0.6.2
 */