package com.neusoft.unieap.techcomp.ria.codelist.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.core.common.bo.context.BOContext;
import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
import java.io.Serializable;
import java.util.List;

public abstract interface CodeListBO extends Serializable
{
  public static final String ROOT = "-1";

  public abstract void initCache();

  public abstract CodeList getCodeList(String paramString);

  public abstract List getAllCodeList();

  public abstract Code getCode(String paramString1, String paramString2);

  public abstract void putCodeList(CodeList paramCodeList);

  public abstract void putCode(String paramString, Code paramCode);

  public abstract void removeCodeList(String paramString);

  public abstract void removeCode(String paramString1, String paramString2);

  public abstract boolean isUpdateTimeStamp();

  public abstract void setUpdateTimeStamp(boolean paramBoolean);

  public abstract QueryResult getAllCodelist();

  public abstract QueryResult getCodelistByCode(Code paramCode);

  public abstract void deleteCodelist(String paramString);

  public abstract boolean queryCodelist(String paramString);

  public abstract String queryCode(List<Code> paramList);

  public abstract BOContext saveCodeList(Code paramCode, List<Code> paramList);

  public abstract QueryResult getCodeByCodeType(String paramString);

  public abstract QueryResult getCodelistByCode(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.bo.CodeListBO
 * JD-Core Version:    0.6.2
 */