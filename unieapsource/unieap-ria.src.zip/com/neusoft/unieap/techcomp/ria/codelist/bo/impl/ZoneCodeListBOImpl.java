/*    */ package com.neusoft.unieap.techcomp.ria.codelist.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.bo.ZoneCodeListBO;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*    */ import com.neusoft.unieap.techcomp.ria.context.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ZoneCodeListBOImpl
/*    */   implements ZoneCodeListBO
/*    */ {
/*    */   private String aab301;
/*    */   private CodeListManager codeListManager;
/*    */ 
/*    */   public String getAab301()
/*    */   {
/* 20 */     return this.aab301;
/*    */   }
/*    */ 
/*    */   public void setAab301(String paramString) {
/* 24 */     this.aab301 = paramString;
/*    */   }
/*    */ 
/*    */   public CodeListManager getCodeListManager()
/*    */   {
/* 30 */     return this.codeListManager;
/*    */   }
/*    */ 
/*    */   public void setCodeListManager(CodeListManager paramCodeListManager) {
/* 34 */     this.codeListManager = paramCodeListManager;
/*    */   }
/*    */ 
/*    */   public List getZoneCodeList(String paramString) {
/* 38 */     if ((paramString == null) || (paramString.length() == 0)) {
/* 39 */       paramString = "-1";
/*    */     }
/* 41 */     CodeList localCodeList = this.codeListManager.getCodeList(this.aab301);
/* 42 */     ArrayList localArrayList = new ArrayList();
/* 43 */     if (localCodeList != null) {
/* 44 */       List localList = localCodeList.getCodeListByDefaultLocale();
/* 45 */       if ((localList != null) && (localList.size() > 0)) {
/* 46 */         for (Code localCode : localList) {
/* 47 */           if (localCode.getParent().equals(paramString)) {
/* 48 */             localArrayList.add(localCode);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 53 */     return localArrayList;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.bo.impl.ZoneCodeListBOImpl
 * JD-Core Version:    0.6.2
 */