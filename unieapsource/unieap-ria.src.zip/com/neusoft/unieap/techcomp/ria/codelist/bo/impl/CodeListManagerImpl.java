/*    */ package com.neusoft.unieap.techcomp.ria.codelist.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.bo.CodeListBO;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("CodeListManager.bo")
/*    */ public class CodeListManagerImpl
/*    */   implements CodeListManager
/*    */ {
/*    */   private CodeListBO codeListBO;
/*    */   private CacheSynchronizeManager cacheSynchronizeManager;
/*    */ 
/*    */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*    */   {
/* 30 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*    */   }
/*    */ 
/*    */   public void setCodeListBO(CodeListBO paramCodeListBO) {
/* 34 */     this.codeListBO = paramCodeListBO;
/*    */   }
/*    */ 
/*    */   public CodeList getCodeList(String paramString) {
/* 38 */     return this.codeListBO.getCodeList(paramString);
/*    */   }
/*    */ 
/*    */   public void putCodeList(CodeList paramCodeList) {
/*    */     try {
/* 43 */       this.codeListBO.putCodeList(paramCodeList);
/* 44 */       if (this.codeListBO.isUpdateTimeStamp()) {
/* 45 */         String str = "codelist_" + 
/* 46 */           paramCodeList.getName();
/* 47 */         this.cacheSynchronizeManager.updateCacheStatusBySysTime(str);
/*    */       }
/*    */     } catch (Exception localException) {
/* 50 */       localException.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public void removeCodeList(String paramString)
/*    */   {
/* 56 */     this.codeListBO.removeCodeList(paramString);
/*    */   }
/*    */ 
/*    */   public List getAllCodeList()
/*    */   {
/* 61 */     return this.codeListBO.getAllCodeList();
/*    */   }
/*    */ 
/*    */   public boolean validCodeRangeValue(String paramString1, String paramString2) {
/* 65 */     if (this.codeListBO.getCode(paramString1, paramString2) != null) {
/* 66 */       return true;
/*    */     }
/* 68 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean validCodeRangeName(String paramString1, String paramString2)
/*    */   {
/* 73 */     CodeList localCodeList = getCodeList(paramString1);
/* 74 */     if (localCodeList != null) {
/* 75 */       List localList = localCodeList.getCodeListByDefaultLocale();
/* 76 */       if (localList.size() > 0) {
/* 77 */         for (int i = 0; i < localList.size(); i++) {
/* 78 */           Code localCode = (Code)localList.get(i);
/* 79 */           if (localCode.getCodeName().equals(paramString2)) {
/* 80 */             return true;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 85 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.bo.impl.CodeListManagerImpl
 * JD-Core Version:    0.6.2
 */