/*     */ package com.neusoft.unieap.techcomp.ria.codelist.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import javax.validation.constraints.NotNull;
/*     */ 
/*     */ @ModelFile("code.entity")
/*     */ public class Code
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String codeValue;
/*     */   private String codeName;
/*  36 */   private String parent = "-1";
/*     */   private BigDecimal codeOrder;
/*  46 */   private String enabled = "0";
/*     */   private String remark;
/*  56 */   private String language = "zh_CN";
/*     */   private String createdBy;
/*     */   private Timestamp creationTime;
/*     */   private String modifiedBy;
/*     */   private Timestamp modificationTime;
/*     */   private String codetype;
/*     */   private String codetypeName;
/*     */   private String filter;
/*     */   private Map pojoContext;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  95 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  99 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setCodeValue(String paramString) {
/* 103 */     this.codeValue = paramString;
/*     */   }
/*     */ 
/*     */   @NotNull(message="代码值不能为空！")
/*     */   public String getCodeValue() {
/* 108 */     return this.codeValue;
/*     */   }
/*     */ 
/*     */   public void setCodeName(String paramString) {
/* 112 */     this.codeName = paramString;
/*     */   }
/*     */ 
/*     */   @NotNull(message="代码名不能为空！")
/*     */   public String getCodeName() {
/* 117 */     return this.codeName;
/*     */   }
/*     */ 
/*     */   public void setParent(String paramString) {
/* 121 */     this.parent = paramString;
/*     */   }
/*     */ 
/*     */   public String getParent() {
/* 125 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public void setCodeOrder(BigDecimal paramBigDecimal) {
/* 129 */     this.codeOrder = paramBigDecimal;
/*     */   }
/*     */ 
/*     */   public BigDecimal getCodeOrder() {
/* 133 */     return this.codeOrder;
/*     */   }
/*     */ 
/*     */   public void setEnabled(String paramString) {
/* 137 */     this.enabled = paramString;
/*     */   }
/*     */ 
/*     */   public String getEnabled() {
/* 141 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public void setRemark(String paramString) {
/* 145 */     this.remark = paramString;
/*     */   }
/*     */ 
/*     */   public String getRemark() {
/* 149 */     return this.remark;
/*     */   }
/*     */ 
/*     */   public void setLanguage(String paramString) {
/* 153 */     this.language = paramString;
/*     */   }
/*     */ 
/*     */   public String getLanguage() {
/* 157 */     return this.language;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 161 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/* 165 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationTime(Timestamp paramTimestamp) {
/* 169 */     this.creationTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationTime() {
/* 173 */     return this.creationTime;
/*     */   }
/*     */ 
/*     */   public void setModifiedBy(String paramString) {
/* 177 */     this.modifiedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getModifiedBy() {
/* 181 */     return this.modifiedBy;
/*     */   }
/*     */ 
/*     */   public void setModificationTime(Timestamp paramTimestamp) {
/* 185 */     this.modificationTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getModificationTime() {
/* 189 */     return this.modificationTime;
/*     */   }
/*     */ 
/*     */   public void setCodetype(String paramString) {
/* 193 */     this.codetype = paramString;
/*     */   }
/*     */ 
/*     */   @NotNull(message="代码表名称不能为空！")
/*     */   public String getCodetype() {
/* 198 */     return this.codetype;
/*     */   }
/*     */ 
/*     */   public void setCodetypeName(String paramString) {
/* 202 */     this.codetypeName = paramString;
/*     */   }
/*     */ 
/*     */   public String getCodetypeName() {
/* 206 */     return this.codetypeName;
/*     */   }
/*     */ 
/*     */   public void setFilter(String paramString) {
/* 210 */     this.filter = paramString;
/*     */   }
/*     */ 
/*     */   public String getFilter() {
/* 214 */     return this.filter;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.entity.Code
 * JD-Core Version:    0.6.2
 */