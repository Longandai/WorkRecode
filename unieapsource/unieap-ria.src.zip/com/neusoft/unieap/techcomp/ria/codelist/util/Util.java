/*     */ package com.neusoft.unieap.techcomp.ria.codelist.util;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.io.StringReader;
/*     */ import java.rmi.server.UID;
/*     */ import java.security.MessageDigest;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public final class Util
/*     */ {
/*  24 */   public static String simpleDateFormat = "yyyy-MM-dd HH:mm:ss";
/*     */ 
/*  26 */   public static String complexDateFormat = "yyyy-MM-dd HH:mm:ss.SSS";
/*     */ 
/*     */   public static boolean isNullOrEmpty(Map paramMap)
/*     */   {
/*  41 */     return (paramMap == null) || (paramMap.isEmpty());
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmpty(Object[] paramArrayOfObject)
/*     */   {
/*  51 */     return (paramArrayOfObject == null) || (paramArrayOfObject.length == 0);
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmpty(String paramString)
/*     */   {
/*  61 */     boolean bool = true;
/*  62 */     if ((paramString != null) && 
/*  63 */       (paramString.trim().length() > 0)) {
/*  64 */       bool = false;
/*     */     }
/*  66 */     return bool;
/*     */   }
/*     */ 
/*     */   public static boolean isNullOrEmpty(Collection paramCollection)
/*     */   {
/*  76 */     return (paramCollection == null) || (paramCollection.isEmpty());
/*     */   }
/*     */ 
/*     */   public static boolean compareObjects(Object paramObject1, Object paramObject2)
/*     */   {
/*  89 */     boolean bool = false;
/*  90 */     if (paramObject1 != null) {
/*  91 */       if (paramObject1.equals(paramObject2))
/*  92 */         bool = true;
/*  93 */     } else if (paramObject2 == null) {
/*  94 */       bool = true;
/*     */     }
/*  96 */     return bool;
/*     */   }
/*     */ 
/*     */   public static Iterator join(Iterator paramIterator, Object paramObject)
/*     */   {
/* 107 */     if (paramObject == null) {
/* 108 */       return paramIterator;
/*     */     }
/* 110 */     return join(paramIterator, Collections.singleton(paramObject).iterator());
/*     */   }
/*     */ 
/*     */   public static String trimText(String paramString)
/*     */   {
/* 123 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 124 */     if (!isNullOrEmpty(paramString))
/*     */     {
/* 126 */       BufferedReader localBufferedReader = new BufferedReader(new StringReader(
/* 127 */         paramString));
/*     */       try {
/* 129 */         String str2 = "";
/*     */         String str1;
/* 130 */         while ((str1 = localBufferedReader.readLine()) != null) {
/* 131 */           localStringBuffer.append(str2);
/* 132 */           localStringBuffer.append(str1.trim());
/* 133 */           str2 = "\n";
/*     */         }
/*     */       }
/*     */       catch (IOException localIOException) {
/*     */       }
/*     */     }
/* 139 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static int getNumeric(String paramString)
/*     */     throws Exception
/*     */   {
/* 152 */     int i = Integer.parseInt(paramString);
/*     */ 
/* 154 */     return i;
/*     */   }
/*     */ 
/*     */   public static boolean fileExists(String paramString)
/*     */   {
/* 164 */     boolean bool = false;
/*     */     try
/*     */     {
/* 167 */       bool = new File(paramString).exists();
/*     */     }
/*     */     catch (Throwable localThrowable)
/*     */     {
/*     */     }
/* 172 */     return bool;
/*     */   }
/*     */ 
/*     */   public static byte[] getMessageDigest(InputStream paramInputStream)
/*     */   {
/*     */     try
/*     */     {
/* 186 */       MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
/*     */ 
/* 188 */       byte[] arrayOfByte = new byte[512];
/*     */       int i;
/* 189 */       for (int j = 0; (i = paramInputStream.read(arrayOfByte)) > 0; j += i) {
/* 190 */         localMessageDigest.update(arrayOfByte, 0, i);
/*     */       }
/* 192 */       return localMessageDigest.digest();
/*     */     }
/*     */     catch (Exception localException) {
/* 195 */       throw new RuntimeException(localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getSafeString(String paramString)
/*     */   {
/* 207 */     if (isNullOrEmpty(paramString)) {
/* 208 */       return "";
/*     */     }
/* 210 */     return paramString;
/*     */   }
/*     */ 
/*     */   public static SimpleDateFormat getDateFormat()
/*     */   {
/* 218 */     return new SimpleDateFormat(simpleDateFormat);
/*     */   }
/*     */ 
/*     */   public static String format(Date paramDate) {
/* 222 */     return getDateFormat().format(paramDate);
/*     */   }
/*     */ 
/*     */   public static String formatAccurater(Date paramDate) {
/* 226 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(complexDateFormat);
/* 227 */     return localSimpleDateFormat.format(paramDate);
/*     */   }
/*     */ 
/*     */   public static Date parseAccurater(String paramString) throws ParseException {
/* 231 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(complexDateFormat);
/* 232 */     return localSimpleDateFormat.parse(paramString);
/*     */   }
/*     */ 
/*     */   public static String generateGUID() {
/* 236 */     return new UID().toString();
/*     */   }
/*     */ 
/*     */   public static Date parse(String paramString) throws ParseException {
/* 240 */     if (!isNullOrEmpty(paramString)) {
/* 241 */       return getDateFormat().parse(paramString);
/*     */     }
/* 243 */     return null;
/*     */   }
/*     */ 
/*     */   public static Vector reverseOrder(Vector paramVector)
/*     */   {
/* 248 */     int i = paramVector.size();
/* 249 */     int j = i / 2;
/* 250 */     i--;
/* 251 */     Object localObject = null;
/* 252 */     for (int k = 0; k < j; k++) {
/* 253 */       localObject = paramVector.get(k);
/* 254 */       paramVector.set(k, paramVector.get(i - k));
/* 255 */       paramVector.set(i - k, localObject);
/*     */     }
/* 257 */     return paramVector;
/*     */   }
/*     */ 
/*     */   public static Object getObjectFromByteBuffer(byte[] paramArrayOfByte) throws Exception
/*     */   {
/* 262 */     if (paramArrayOfByte == null)
/* 263 */       return null;
/* 264 */     Object localObject = null;
/*     */     try {
/* 266 */       ByteArrayInputStream localByteArrayInputStream = new ByteArrayInputStream(paramArrayOfByte, 
/* 267 */         0, paramArrayOfByte.length);
/* 268 */       ObjectInputStream localObjectInputStream = new ObjectInputStream(localByteArrayInputStream);
/* 269 */       localObject = localObjectInputStream.readObject();
/* 270 */       localObjectInputStream.close();
/*     */     } catch (StreamCorruptedException localStreamCorruptedException) {
/* 272 */       throw localStreamCorruptedException;
/*     */     }
/* 274 */     if (localObject == null)
/* 275 */       return null;
/* 276 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static String parseExceptionCause(Exception paramException) {
/* 280 */     StackTraceElement[] arrayOfStackTraceElement = paramException.getStackTrace();
/* 281 */     int i = Math.min(arrayOfStackTraceElement.length, 6);
/* 282 */     StringBuffer localStringBuffer = new StringBuffer();
/* 283 */     localStringBuffer.append(paramException.toString());
/* 284 */     localStringBuffer.append("\n");
/* 285 */     for (int j = 0; j < i; j++) {
/* 286 */       localStringBuffer.append("\tat ");
/* 287 */       localStringBuffer.append(arrayOfStackTraceElement[j]);
/* 288 */       localStringBuffer.append("\n");
/*     */     }
/* 290 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static Vector filter(Collection paramCollection) {
/* 294 */     Vector localVector = new Vector();
/* 295 */     Iterator localIterator = paramCollection.iterator();
/* 296 */     while (localIterator.hasNext()) {
/* 297 */       String str = (String)localIterator.next();
/* 298 */       if (!exist(localVector, str))
/*     */       {
/* 301 */         localVector.add(str);
/*     */       }
/*     */     }
/* 304 */     return localVector;
/*     */   }
/*     */ 
/*     */   private static boolean exist(Vector paramVector, String paramString) {
/* 308 */     for (int i = 0; i < paramVector.size(); i++) {
/* 309 */       String str = (String)paramVector.get(i);
/* 310 */       if (str.equals(paramString)) {
/* 311 */         return true;
/*     */       }
/*     */     }
/* 314 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.util.Util
 * JD-Core Version:    0.6.2
 */