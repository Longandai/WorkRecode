/*     */ package com.neusoft.unieap.techcomp.ria.codelist.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.dao.CodeListDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("codeListDAO.dao")
/*     */ public class CodeListDAOImpl extends BaseHibernateDAO
/*     */   implements CodeListDAO
/*     */ {
/*     */   public List getAllCodeList()
/*     */   {
/*  26 */     String str1 = "0";
/*     */ 
/*  28 */     String str2 = "from Code code where code.enabled = ? order by code.codetype,code.codeOrder,code.codeValue";
/*     */ 
/*  30 */     List localList = getHibernateTemplate().find(str2, str1);
/*  31 */     if ((localList != null) && (localList.size() > 0))
/*     */     {
/*  33 */       return convertCodeTypeList(localList);
/*     */     }
/*  35 */     return null;
/*     */   }
/*     */ 
/*     */   private List convertCodeTypeList(List paramList)
/*     */   {
/*  40 */     ArrayList localArrayList = new ArrayList();
/*  41 */     if (paramList != null) {
/*  42 */       HashMap localHashMap = new HashMap();
/*     */ 
/*  44 */       for (int i = 0; i < paramList.size(); i++) {
/*  45 */         Code localCode = (Code)paramList.get(i);
/*  46 */         String str1 = localCode.getCodetype();
/*  47 */         if (str1 != null) {
/*  48 */           CodeList localCodeList = (CodeList)localHashMap.get(localCode.getCodetype());
/*  49 */           if (localCodeList == null)
/*     */           {
/*  51 */             localCodeList = new CodeList();
/*  52 */             localCodeList.setName(str1);
/*     */ 
/*  54 */             if (localCode.getCodetypeName() != null) {
/*  55 */               localCodeList.setCodeTypeName(localCode.getCodetypeName());
/*     */             }
/*     */ 
/*  58 */             localHashMap.put(str1, localCodeList);
/*     */           }
/*     */ 
/*  61 */           String str2 = localCode.getLanguage();
/*  62 */           if (str2 != null) {
/*  63 */             Object localObject = 
/*  64 */               (List)localCodeList.getCodeListMap()
/*  64 */               .get(str2);
/*  65 */             if (localObject == null) {
/*  66 */               localObject = new ArrayList();
/*  67 */               ((List)localObject).add(localCode);
/*  68 */               localCodeList.getCodeListMap().put(str2, 
/*  69 */                 localObject);
/*     */             }
/*     */             else {
/*  72 */               ((List)localObject).add(localCode);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*  77 */       localArrayList.addAll(localHashMap.values());
/*     */     }
/*  79 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private CodeList convertCodeType(String paramString, List paramList) {
/*  83 */     if ((paramString != null) && (paramList != null)) {
/*  84 */       CodeList localCodeList = new CodeList();
/*  85 */       localCodeList.setName(paramString);
/*  86 */       for (int i = 0; i < paramList.size(); i++)
/*     */       {
/*  88 */         Code localCode = (Code)paramList.get(i);
/*  89 */         String str = localCode.getLanguage();
/*     */ 
/*  91 */         if ((localCode.getCodetypeName() != null) && 
/*  92 */           (!localCode.getCodetypeName().equals("")) && 
/*  93 */           (localCodeList.getCodeTypeName() != null) && 
/*  94 */           (!localCodeList.getCodeTypeName().equals(""))) {
/*  95 */           localCodeList.setCodeTypeName(localCode.getCodetypeName());
/*     */         }
/*     */ 
/*  98 */         if (str != null) {
/*  99 */           Object localObject = (List)localCodeList.getCodeListMap().get(
/* 100 */             str);
/* 101 */           if (localObject == null) {
/* 102 */             localObject = new ArrayList();
/* 103 */             ((List)localObject).add(localCode);
/* 104 */             localCodeList.getCodeListMap().put(str, localObject);
/*     */           }
/*     */           else {
/* 107 */             ((List)localObject).add(localCode);
/*     */           }
/*     */         }
/*     */       }
/* 111 */       return localCodeList;
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   public CodeList getCodeListByName(String paramString) {
/* 117 */     String str1 = "0";
/*     */ 
/* 119 */     String str2 = "from Code code where code.enabled = ? and code.codetype = ? order by code.codeOrder,code.codeValue";
/*     */ 
/* 121 */     List localList = getHibernateTemplate().find(str2, 
/* 122 */       new Object[] { str1, paramString });
/* 123 */     if ((localList != null) && (localList.size() > 0))
/*     */     {
/* 125 */       return convertCodeType(paramString, localList);
/*     */     }
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   public QueryResult getAllCodelist()
/*     */   {
/* 134 */     String str = "select distinct(code.codetype), code.codetype_name from up_codelist code order by code.codetype";
/* 135 */     QueryResult localQueryResult = query(str, null);
/* 136 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public QueryResult getCodelistByCode(Code paramCode) {
/* 140 */     String str1 = "select distinct(code.codetype), code.codetype_name from up_codelist code ";
/* 141 */     String str2 = "";
/* 142 */     int i = 0;
/*     */ 
/* 145 */     if (paramCode == null) {
/* 146 */       str1 = str1 + "order by code.codetype ";
/*     */     } else {
/* 148 */       str1 = str1 + "where 1=1 ";
/* 149 */       if (paramCode.getCodetype() != null) {
/* 150 */         str2 = str2 + "and code.codetype like ? ";
/* 151 */         i++;
/*     */       }
/* 153 */       if ((paramCode.getCodetypeName() != null) && (!paramCode.getCodetypeName().equals(""))) {
/* 154 */         str2 = str2 + "and code.codetype_name like ? ";
/* 155 */         i++;
/*     */       }
/*     */     }
/*     */ 
/* 159 */     Object[] arrayOfObject = new Object[i];
/* 160 */     i = 0;
/* 161 */     if (paramCode.getCodetype() != null) {
/* 162 */       arrayOfObject[i] = ("%" + paramCode.getCodetype() + "%");
/* 163 */       i++;
/*     */     }
/* 165 */     if ((paramCode.getCodetypeName() != null) && (!paramCode.getCodetypeName().equals(""))) {
/* 166 */       arrayOfObject[i] = ("%" + paramCode.getCodetypeName() + "%");
/* 167 */       i++;
/*     */     }
/* 169 */     String str3 = "order by code.codetype ";
/* 170 */     str1 = str1 + str2 + str3;
/*     */ 
/* 172 */     return query(str1, arrayOfObject);
/*     */   }
/*     */ 
/*     */   public void deleteCodelist(String paramString) {
/* 176 */     String str = "delete Code code where code.codetype = ? ";
/* 177 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public boolean queryCodelist(String paramString) {
/* 181 */     String str = "from Code code where code.codetype = ? ";
/*     */ 
/* 183 */     Object[] arrayOfObject = new Object[1];
/* 184 */     arrayOfObject[0] = paramString;
/* 185 */     if (queryObject(str, arrayOfObject) != null) {
/* 186 */       return true;
/*     */     }
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   public String queryCode(List<Code> paramList)
/*     */   {
/* 193 */     String[] arrayOfString1 = new String[paramList.size()];
/* 194 */     String[] arrayOfString2 = new String[paramList.size()];
/* 195 */     for (int i = 0; i < paramList.size(); i++) {
/* 196 */       arrayOfString1[i] = ((Code)paramList.get(i)).getCodeValue();
/* 197 */       if (arrayOfString1[i] == null) {
/* 198 */         return null;
/*     */       }
/*     */     }
/* 201 */     for (i = 0; i < paramList.size(); i++) {
/* 202 */       arrayOfString2[i] = ((Code)paramList.get(i)).getCodeName();
/* 203 */       if (arrayOfString2[i] == null) {
/* 204 */         return null;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 209 */     for (i = 0; i < paramList.size(); i++) {
/* 210 */       for (int j = i + 1; j < paramList.size(); j++) {
/* 211 */         if (arrayOfString1[i].equals(arrayOfString1[j])) {
/* 212 */           return "codeValueEqual";
/*     */         }
/*     */ 
/* 215 */         for (int k = 0; k < paramList.size(); k++) {
/* 216 */           for (int m = k + 1; m < paramList.size(); m++) {
/* 217 */             if (arrayOfString2[i].equals(arrayOfString2[j])) {
/* 218 */               return "codeNameEqual";
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 226 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Code> saveCodeList(List<Code> paramList) {
/* 230 */     addOrUpdateObjects(paramList);
/* 231 */     return paramList;
/*     */   }
/*     */ 
/*     */   public boolean queryCacheTimestamp(String paramString) {
/* 235 */     String str = "from CacheObjectTimestamp cacheObjectTimestamp where cacheObjectTimestamp.type = ? ";
/*     */ 
/* 237 */     Object[] arrayOfObject = new Object[1];
/* 238 */     arrayOfObject[0] = paramString;
/* 239 */     Object localObject = queryObject(
/* 240 */       str, arrayOfObject);
/* 241 */     if (localObject != null) {
/* 242 */       return true;
/*     */     }
/* 244 */     return false;
/*     */   }
/*     */ 
/*     */   public QueryResult getCodeByCodeType(String paramString)
/*     */   {
/* 249 */     String str = "from Code code where code.codetype = ? order by code.codeOrder ";
/*     */ 
/* 252 */     Object[] arrayOfObject = new Object[1];
/* 253 */     arrayOfObject[0] = paramString;
/*     */ 
/* 255 */     return queryObjectsByPage(str, arrayOfObject);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.dao.impl.CodeListDAOImpl
 * JD-Core Version:    0.6.2
 */