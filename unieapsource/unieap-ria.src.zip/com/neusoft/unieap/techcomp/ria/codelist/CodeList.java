/*     */ package com.neusoft.unieap.techcomp.ria.codelist;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class CodeList
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String name;
/*     */   private String codeTypeName;
/*  42 */   private Map<String, List<Code>> codeListMap = new HashMap();
/*     */ 
/*     */   public String getName()
/*     */   {
/*  46 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString) {
/*  50 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public Map<String, List<Code>> getCodeListMap() {
/*  54 */     return this.codeListMap;
/*     */   }
/*     */ 
/*     */   public void setCodeListMap(Map<String, List<Code>> paramMap) {
/*  58 */     this.codeListMap = paramMap;
/*     */   }
/*     */ 
/*     */   private Locale getSysDefaultLoacle()
/*     */   {
/*  63 */     return GlobalService.getDefaultI18nContext().getLocale();
/*     */   }
/*     */ 
/*     */   public List<Code> getSoleCodeList()
/*     */   {
/*  72 */     ArrayList localArrayList = new ArrayList();
/*  73 */     localArrayList.addAll(this.codeListMap.keySet());
/*  74 */     if (localArrayList.size() == 1) {
/*  75 */       return (List)this.codeListMap.get(localArrayList.get(0));
/*     */     }
/*  77 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Code> getCodeListByDefaultLocale()
/*     */   {
/*  85 */     return getCodeListByLocale(getSysDefaultLoacle().toString());
/*     */   }
/*     */ 
/*     */   public List<Code> getCodeListByLocale(String paramString)
/*     */   {
/*  93 */     if ((paramString != null) && (!paramString.equals(""))) {
/*  94 */       List localList = (List)this.codeListMap.get(paramString);
/*  95 */       if (localList != null) {
/*  96 */         return localList;
/*     */       }
/*     */     }
/*  99 */     return null;
/*     */   }
/*     */ 
/*     */   public void setCodeListByDefaultLocale(List<Code> paramList)
/*     */   {
/* 107 */     setCodeListByLocale(getSysDefaultLoacle().toString(), paramList);
/*     */   }
/*     */ 
/*     */   public void setCodeListByLocale(String paramString, List<Code> paramList)
/*     */   {
/* 116 */     if ((paramString != null) && (!paramString.equals("")) && (paramList != null))
/* 117 */       this.codeListMap.put(paramString, paramList);
/*     */   }
/*     */ 
/*     */   public List<Code> getCode(String paramString)
/*     */   {
/* 128 */     ArrayList localArrayList1 = new ArrayList();
/* 129 */     ArrayList localArrayList2 = new ArrayList();
/* 130 */     localArrayList2.addAll(this.codeListMap.keySet());
/* 131 */     for (int i = 0; i < localArrayList2.size(); i++) {
/* 132 */       List localList = (List)this.codeListMap.get(localArrayList2.get(i));
/* 133 */       for (Code localCode : localList) {
/* 134 */         if (localCode.getCodeValue().equals(paramString)) {
/* 135 */           localArrayList1.add(localCode);
/*     */         }
/*     */       }
/*     */     }
/* 139 */     return localArrayList1;
/*     */   }
/*     */ 
/*     */   public void setCodeTypeName(String paramString) {
/* 143 */     this.codeTypeName = paramString;
/*     */   }
/*     */ 
/*     */   public String getCodeTypeName() {
/* 147 */     return this.codeTypeName;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.codelist.CodeList
 * JD-Core Version:    0.6.2
 */