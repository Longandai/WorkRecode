/*     */ package com.neusoft.unieap.techcomp.ria.context.util;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ArrayList extends java.util.ArrayList
/*     */   implements List
/*     */ {
/*  10 */   private java.util.List deletedObjects = new java.util.ArrayList();
/*  11 */   private java.util.List newObjects = new java.util.ArrayList();
/*  12 */   private DataStore dataStore = null;
/*     */ 
/*     */   public Object remove(int paramInt)
/*     */   {
/*  16 */     Object localObject = super.remove(paramInt);
/*  17 */     if (contains(this.newObjects, localObject)) {
/*  18 */       this.newObjects.remove(localObject);
/*  19 */       ContextUtil.setPojoContext(localObject, null);
/*     */     } else {
/*  21 */       this.deletedObjects.add(localObject);
/*     */     }
/*  23 */     return localObject;
/*     */   }
/*     */ 
/*     */   public void add(int paramInt, Object paramObject)
/*     */   {
/*  28 */     super.add(paramInt, paramObject);
/*  29 */     this.newObjects.add(paramObject);
/*  30 */     ContextUtil.setPojoContext(paramObject, this);
/*  31 */     if (contains(this.deletedObjects, paramObject))
/*  32 */       this.deletedObjects.remove(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean add(Object paramObject)
/*     */   {
/*  38 */     boolean bool = super.add(paramObject);
/*  39 */     if (bool) {
/*  40 */       this.newObjects.add(paramObject);
/*  41 */       if (contains(this.deletedObjects, paramObject)) {
/*  42 */         this.deletedObjects.remove(paramObject);
/*     */       }
/*  44 */       ContextUtil.setPojoContext(paramObject, this);
/*     */     }
/*  46 */     return bool;
/*     */   }
/*     */ 
/*     */   public boolean _add(Object paramObject) {
/*  50 */     return super.add(paramObject);
/*     */   }
/*     */ 
/*     */   public boolean _addAll(Collection paramCollection) {
/*  54 */     return super.addAll(paramCollection);
/*     */   }
/*     */ 
/*     */   public boolean addAll(Collection paramCollection)
/*     */   {
/*  59 */     boolean bool = super.addAll(paramCollection);
/*  60 */     if (bool) {
/*  61 */       this.newObjects.addAll(paramCollection);
/*  62 */       for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/*  63 */         ContextUtil.setPojoContext(localObject, this);
/*     */       }
/*  65 */       if (containsAll(this.deletedObjects, paramCollection)) {
/*  66 */         removeAll(this.deletedObjects, paramCollection);
/*     */       }
/*     */     }
/*  69 */     return bool;
/*     */   }
/*     */ 
/*     */   public boolean addAll(int paramInt, Collection paramCollection)
/*     */   {
/*  74 */     boolean bool = super.addAll(paramInt, paramCollection);
/*  75 */     if (bool) {
/*  76 */       this.newObjects.addAll(paramCollection);
/*  77 */       for (Iterator localIterator = paramCollection.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/*  78 */         ContextUtil.setPojoContext(localObject, this);
/*     */       }
/*  80 */       if (containsAll(this.deletedObjects, paramCollection)) {
/*  81 */         removeAll(this.deletedObjects, paramCollection);
/*     */       }
/*     */     }
/*  84 */     return bool;
/*     */   }
/*     */ 
/*     */   public java.util.List getDeletedObjects() {
/*  88 */     return this.deletedObjects;
/*     */   }
/*     */ 
/*     */   public java.util.List getNewObjects() {
/*  92 */     return this.newObjects;
/*     */   }
/*     */ 
/*     */   public boolean removeAll(Collection paramCollection, Collection<?> paramCollection1) {
/*  96 */     boolean bool = false;
/*  97 */     Iterator localIterator = paramCollection.iterator();
/*  98 */     while (localIterator.hasNext()) {
/*  99 */       if (contains(paramCollection1, localIterator.next())) {
/* 100 */         localIterator.remove();
/* 101 */         bool = true;
/*     */       }
/*     */     }
/* 104 */     return bool;
/*     */   }
/*     */ 
/*     */   public boolean containsAll(Collection paramCollection, Collection<?> paramCollection1) {
/* 108 */     Iterator localIterator = paramCollection1.iterator();
/* 109 */     while (localIterator.hasNext())
/* 110 */       if (!contains(paramCollection, localIterator.next()))
/* 111 */         return false;
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean contains(Collection paramCollection, Object paramObject) {
/* 116 */     return indexOf(paramCollection, paramObject) >= 0;
/*     */   }
/*     */ 
/*     */   public int indexOf(Collection paramCollection, Object paramObject) {
/* 120 */     Iterator localIterator = paramCollection.iterator();
/* 121 */     int i = 0;
/* 122 */     if (paramObject == null)
/* 123 */       while (localIterator.hasNext()) {
/* 124 */         if (localIterator.next() == null) {
/* 125 */           return i;
/*     */         }
/* 127 */         i++;
/*     */       }
/*     */     else {
/* 130 */       while (localIterator.hasNext()) {
/* 131 */         Object localObject = localIterator.next();
/* 132 */         if ((paramObject.equals(localObject)) || (paramObject == localObject)) {
/* 133 */           return i;
/*     */         }
/* 135 */         i++;
/*     */       }
/*     */     }
/* 138 */     return -1;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 143 */     super.clear();
/*     */   }
/*     */ 
/*     */   public void resetUpdate()
/*     */   {
/* 167 */     this.deletedObjects.clear();
/* 168 */     this.newObjects.clear();
/*     */   }
/*     */ 
/*     */   public void setDataStore(DataStore paramDataStore) {
/* 172 */     this.dataStore = paramDataStore;
/*     */   }
/*     */ 
/*     */   public DataStore getDataStore() {
/* 176 */     return this.dataStore;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.context.util.ArrayList
 * JD-Core Version:    0.6.2
 */