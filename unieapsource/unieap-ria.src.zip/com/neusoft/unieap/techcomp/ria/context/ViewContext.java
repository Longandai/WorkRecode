package com.neusoft.unieap.techcomp.ria.context;

import com.neusoft.unieap.techcomp.ria.RIAException;
import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
import com.neusoft.unieap.techcomp.ria.ds.DataStore;
import java.util.List;
import java.util.Map;

public abstract interface ViewContext extends Map
{
  public static final String DEFAULT_RESPONSE_RESULT = "_default_response_result";

  public abstract String getString(String paramString)
    throws RIAException;

  public abstract String[] getStrings(String paramString)
    throws RIAException;

  public abstract int getInt(String paramString)
    throws RIAException;

  public abstract boolean getBoolean(String paramString)
    throws RIAException;

  public abstract long getLong(String paramString)
    throws RIAException;

  public abstract float getFloat(String paramString)
    throws RIAException;

  public abstract double getDouble(String paramString)
    throws RIAException;

  public abstract List getPOJOList(String paramString)
    throws Exception;

  public abstract Object getPOJO(String paramString)
    throws Exception;

  public abstract List getNewPOJOList(String paramString)
    throws Exception;

  public abstract List getDeletePOJOList(String paramString)
    throws Exception;

  public abstract List getUpdatePOJOList(String paramString)
    throws Exception;

  public abstract DataStore getDataStore(String paramString)
    throws Exception;

  public abstract DataStore getSingleDataStore()
    throws Exception;

  public abstract List getDataStores()
    throws Exception;

  public abstract String[] getDataStoreNames()
    throws Exception;

  public abstract DataCenter getDataCenter()
    throws Exception;

  public abstract List getFileAttachments();

  public abstract DataStore getQueryConditionStore()
    throws Exception;

  public abstract List getQueryConditions()
    throws Exception;

  public abstract List getPojoListWithContext(String paramString)
    throws Exception;

  public abstract Object getPojoWithContext(String paramString)
    throws Exception;

  public abstract Map getPojoMap(String paramString)
    throws Exception;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.context.ViewContext
 * JD-Core Version:    0.6.2
 */