/*     */ package com.neusoft.unieap.techcomp.ria.context.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.exception.UniEAPSystemException;
/*     */ import com.neusoft.unieap.core.validation.BeanValidator;
/*     */ import com.neusoft.unieap.core.validation.BeanValidatorFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.pojo.PojoEntity;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ public class ContextUtil
/*     */ {
/*     */   public static final String ORIGIN_DATA_SESSION = "origin_data_session";
/*     */   public static final String ORIGIN_DATA_CONTEXT = "origin_data_context";
/*     */   public static final String ORIGIN_DATA_INFO = "origin_data_info";
/*     */   public static final String ORIGIN_HIBERNATE_DATA_INFO = "origin_hibernate_data_info";
/*     */   public static final String ORIGIN_DATA_INFO_CASCADE_REFERENCE = "origin_data_info_cascade_reference";
/*     */   public static final String ORIGIN_DATA_DATASTORE = "origin_data_dataStore";
/*     */   public static final String ORIGIN_DATA_DATASTORE_INDEX = "origin_data_dataStore_index";
/*     */   public static final String ORIGIN_DATA_DATASTORE_DELETE_INDEX = "origin_data_dataStore_delete_index";
/*     */   public static final String MAP_DATA_CONTEXT = "map_data_context";
/*     */   public static final String POJO_CONTEXT = "pojoContext";
/*     */ 
/*     */   public static void setPojoContext(Object paramObject, List paramList)
/*     */   {
/*  52 */     Map localMap = getPojoContext();
/*  53 */     Object localObject = null;
/*  54 */     if (!localMap.containsKey(paramObject)) {
/*  55 */       localObject = new HashMap();
/*  56 */       localMap.put(paramObject, localObject);
/*     */     } else {
/*  58 */       localObject = (Map)localMap.get(paramObject);
/*     */     }
/*  60 */     ((Map)localObject).put("origin_data_context", paramList);
/*     */   }
/*     */ 
/*     */   public static Map getPojoContext() {
/*  64 */     Object localObject1 = UnieapRequestContextHolder.getRequestContext().get(
/*  65 */       "pojoContext");
/*  66 */     Object localObject2 = null;
/*  67 */     if (localObject1 == null) {
/*  68 */       localObject2 = new HashMap();
/*  69 */       UnieapRequestContextHolder.getRequestContext().put("pojoContext", 
/*  70 */         localObject2);
/*  71 */     } else if ((localObject1 instanceof Map)) {
/*  72 */       localObject2 = (Map)localObject1;
/*     */     }
/*  74 */     return localObject2;
/*     */   }
/*     */ 
/*     */   public static Object getOriginPojoByRow(Row paramRow, String paramString)
/*     */     throws Exception
/*     */   {
/*  80 */     Object localObject = null;
/*  81 */     PojoEntity localPojoEntity = PojoUtil.createPojoEntity(paramString, paramRow);
/*  82 */     if (paramRow.isDataModify())
/*  83 */       localObject = localPojoEntity.getOrignPojoObj();
/*     */     else {
/*  85 */       localObject = localPojoEntity.getPojoObj();
/*     */     }
/*  87 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static List getPojoListWithContext(DataStore paramDataStore) throws Exception {
/*  91 */     if (paramDataStore == null)
/*  92 */       return null;
/*  93 */     List localList1 = paramDataStore.getRowSet().getRows();
/*  94 */     String str = paramDataStore.getRowSetName();
/*  95 */     Map localMap1 = getPojoContext();
/*     */     int j;
/*     */     Object localObject2;
/*  97 */     if ((str == null) || (str.trim().equals(""))) {
/*  98 */       localObject1 = new java.util.ArrayList();
/*  99 */       i = 0; for (j = localList1.size(); i < j; i++) {
/* 100 */         localObject2 = (Row)localList1.get(i);
/* 101 */         Map localMap2 = PojoUtil.createMap((Row)localObject2);
/* 102 */         setMapPojoContext(paramDataStore, localMap1, i, localMap2);
/* 103 */         ((List)localObject1).add(localMap2);
/*     */       }
/* 105 */       setMapPojoContext(paramDataStore, localMap1, -1, localObject1);
/* 106 */       return localObject1;
/*     */     }
/*     */ 
/* 109 */     Object localObject1 = new ArrayList();
/* 110 */     ((ArrayList)localObject1).setDataStore(paramDataStore);
/* 111 */     int i = localList1.size();
/*     */     try
/*     */     {
/* 114 */       for (j = 0; j < i; j++) {
/* 115 */         localObject2 = (Row)localList1.get(j);
/* 116 */         initPojoContextMap(j, (Row)localObject2, paramDataStore, (ArrayList)localObject1, localMap1, 
/* 117 */           str);
/*     */       }
/*     */ 
/* 120 */       List localList2 = paramDataStore.getRowSet().getDeleteRows();
/* 121 */       localObject2 = new java.util.ArrayList();
/* 122 */       for (int k = 0; k < localList2.size(); k++) {
/* 123 */         Row localRow = (Row)localList2.get(k);
/* 124 */         if (!localRow.isNewModify())
/*     */         {
/* 128 */           HashMap localHashMap = new HashMap();
/* 129 */           localHashMap.put("origin_data_dataStore", paramDataStore);
/* 130 */           localHashMap.put(
/* 131 */             "origin_data_dataStore_delete_index", 
/* 132 */             Integer.valueOf(k));
/* 133 */           localHashMap.put("origin_data_context", 
/* 134 */             localObject1);
/*     */ 
/* 136 */           PojoEntity localPojoEntity = PojoUtil.createPojoEntity(
/* 137 */             str, localRow);
/* 138 */           Object localObject3 = localPojoEntity.getPojoObj();
/* 139 */           localMap1.put(localObject3, localHashMap);
/*     */ 
/* 141 */           Object localObject4 = getOriginPojoByRow(localRow, 
/* 142 */             str);
/* 143 */           localHashMap.put("origin_data_info", 
/* 144 */             localObject4);
/* 145 */           ((ArrayList)localObject1)._add(localObject3);
/* 146 */           ((List)localObject2).add(localObject3);
/*     */ 
/* 148 */           initPojoCascadeContext(k, paramDataStore, (ArrayList)localObject1, localMap1, 
/* 149 */             str, localHashMap, localObject3, localObject4, 
/* 150 */             true);
/*     */         }
/*     */       }
/* 152 */       ((ArrayList)localObject1).removeAll((Collection)localObject2);
/*     */     } catch (Exception localException) {
/* 154 */       localException.printStackTrace();
/* 155 */       localObject2 = localException.getCause();
/* 156 */       throw new UniEAPSystemException("", (Throwable)localObject2, null);
/*     */     }
/* 158 */     return localObject1;
/*     */   }
/*     */ 
/*     */   public static void setMapPojoContext(DataStore paramDataStore, Map paramMap, int paramInt, Object paramObject)
/*     */   {
/* 164 */     HashMap localHashMap1 = new HashMap();
/* 165 */     HashMap localHashMap2 = new HashMap();
/* 166 */     localHashMap2.put("origin_data_dataStore", paramDataStore);
/* 167 */     if (paramInt != -1) {
/* 168 */       localHashMap2.put("origin_data_dataStore_index", Integer.valueOf(paramInt));
/*     */     }
/* 170 */     localHashMap1.put(paramObject, localHashMap2);
/* 171 */     paramMap.put("map_data_context", localHashMap1);
/*     */   }
/*     */ 
/*     */   private static void initPojoContextMap(int paramInt, Row paramRow, DataStore paramDataStore, ArrayList paramArrayList, Map paramMap, String paramString)
/*     */     throws Exception
/*     */   {
/* 178 */     HashMap localHashMap = new HashMap();
/* 179 */     localHashMap.put("origin_data_dataStore", paramDataStore);
/* 180 */     localHashMap.put("origin_data_dataStore_index", Integer.valueOf(paramInt));
/* 181 */     localHashMap.put("origin_data_context", paramArrayList);
/*     */ 
/* 183 */     PojoEntity localPojoEntity = PojoUtil.createPojoEntity(paramString, paramRow);
/* 184 */     Object localObject1 = localPojoEntity.getPojoObj();
/* 185 */     paramMap.put(localObject1, localHashMap);
/*     */ 
/* 187 */     BeanValidatorFactory.getBeanValidator().validate(localObject1);
/*     */ 
/* 189 */     Object localObject2 = null;
/* 190 */     if (paramRow.isNewModify()) {
/* 191 */       paramArrayList.add(localObject1);
/*     */     } else {
/* 193 */       paramArrayList._add(localObject1);
/* 194 */       localObject2 = getOriginPojoByRow(paramRow, paramString);
/* 195 */       localHashMap.put("origin_data_info", localObject2);
/*     */     }
/*     */ 
/* 198 */     initPojoCascadeContext(paramInt, paramDataStore, paramArrayList, paramMap, paramString, 
/* 199 */       localHashMap, localObject1, localObject2, false);
/*     */   }
/*     */ 
/*     */   private static void initPojoCascadeContext(int paramInt, DataStore paramDataStore, ArrayList paramArrayList, Map paramMap1, String paramString, Map paramMap2, Object paramObject1, Object paramObject2, boolean paramBoolean)
/*     */     throws ClassNotFoundException, Exception, IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 208 */     HashMap localHashMap1 = new HashMap();
/* 209 */     paramMap2.put("origin_data_info_cascade_reference", localHashMap1);
/* 210 */     Class localClass = Class.forName(paramString);
/* 211 */     Set localSet = PojoUtil.getEntityProperties(localClass);
/*     */ 
/* 214 */     for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/* 215 */       String str = (String)localIterator.next();
/* 216 */       if (str.indexOf(".") > 0) {
/* 217 */         String[] arrayOfString = str.split("\\.");
/* 218 */         Object localObject1 = paramObject1; Object localObject2 = paramObject2;
/* 219 */         for (int i = 0; i < arrayOfString.length - 1; i++) {
/* 220 */           localObject1 = 
/* 221 */             PropertyUtils.getProperty(localObject1, arrayOfString[i]);
/* 222 */           if (localObject1 == null) {
/*     */             break;
/*     */           }
/* 225 */           if (localObject2 != null) {
/* 226 */             localObject2 = PropertyUtils.getProperty(localObject2, 
/* 227 */               arrayOfString[i]);
/*     */           }
/*     */ 
/* 230 */           if (!paramMap1.containsKey(localObject1)) {
/* 231 */             HashMap localHashMap2 = new HashMap();
/* 232 */             localHashMap2.put("origin_data_dataStore", 
/* 233 */               paramDataStore);
/* 234 */             if (paramBoolean)
/* 235 */               localHashMap2
/* 236 */                 .put(
/* 237 */                 "origin_data_dataStore_delete_index", 
/* 238 */                 Integer.valueOf(paramInt));
/*     */             else {
/* 240 */               localHashMap2
/* 241 */                 .put(
/* 242 */                 "origin_data_dataStore_index", 
/* 243 */                 Integer.valueOf(paramInt));
/*     */             }
/* 245 */             localHashMap2.put("origin_data_context", 
/* 246 */               paramArrayList);
/* 247 */             localHashMap2.put("origin_data_info", 
/* 248 */               localObject2);
/* 249 */             localHashMap1.put(arrayOfString[i], localObject1);
/* 250 */             paramMap1.put(localObject1, localHashMap2);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object getPojoWithContext(DataStore paramDataStore) throws Exception
/*     */   {
/* 259 */     if (paramDataStore == null) {
/* 260 */       return null;
/*     */     }
/* 262 */     String str = paramDataStore.getRowSetName();
/* 263 */     List localList = paramDataStore.getRowSet().getRows();
/* 264 */     if (localList.size() == 0) {
/* 265 */       return null;
/*     */     }
/* 267 */     Row localRow = (Row)localList.get(0);
/* 268 */     if ((str == null) || (str.trim().equals(""))) {
/* 269 */       localObject1 = PojoUtil.createMap(localRow);
/* 270 */       localObject2 = new HashMap();
/* 271 */       ((Map)localObject2).put("_pojoIndexInContext", Integer.valueOf(0));
/* 272 */       ((Map)localObject2).put("dataStore", paramDataStore);
/* 273 */       ((Map)localObject1).put("pojoContext", localObject2);
/* 274 */       return localObject1;
/*     */     }
/*     */ 
/* 277 */     Object localObject1 = new ArrayList();
/* 278 */     Object localObject2 = getPojoContext();
/* 279 */     initPojoContextMap(0, localRow, paramDataStore, (ArrayList)localObject1, (Map)localObject2, str);
/* 280 */     return ((ArrayList)localObject1).get(0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.context.util.ContextUtil
 * JD-Core Version:    0.6.2
 */