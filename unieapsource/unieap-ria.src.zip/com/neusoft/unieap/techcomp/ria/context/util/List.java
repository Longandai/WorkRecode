package com.neusoft.unieap.techcomp.ria.context.util;

public abstract interface List extends java.util.List
{
  public abstract java.util.List getDeletedObjects();

  public abstract java.util.List getNewObjects();

  public abstract void resetUpdate();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.context.util.List
 * JD-Core Version:    0.6.2
 */