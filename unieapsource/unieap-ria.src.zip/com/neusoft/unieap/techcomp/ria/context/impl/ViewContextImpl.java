/*     */ package com.neusoft.unieap.techcomp.ria.context.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.context.util.ContextUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.pojo.PojoEntity;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ViewContextImpl extends HashMap
/*     */   implements ViewContext
/*     */ {
/*     */   private static final String CONDITIONDATASTORE = "_queryConditionStore";
/*     */   private static final String DEFAULTCONDITIONDATASTORENAME = "_queryStore";
/*     */   private static final String DATASTORE = "dataStore";
/*     */   private DataCenter dc;
/*     */   private List fileAttachments;
/*     */   private static final long serialVersionUID = -890752706307844077L;
/*     */ 
/*     */   public void setDc(DataCenter paramDataCenter)
/*     */   {
/*  29 */     this.dc = paramDataCenter;
/*     */   }
/*     */ 
/*     */   public String getString(String paramString)
/*     */     throws RIAException
/*     */   {
/*  35 */     Object localObject = get(paramString);
/*  36 */     if (localObject == null) {
/*  37 */       return null;
/*     */     }
/*  39 */     if ((localObject instanceof String[])) {
/*  40 */       return ((String[])localObject)[0];
/*     */     }
/*  42 */     return String.valueOf(localObject);
/*     */   }
/*     */   public String[] getStrings(String paramString) throws RIAException {
/*  45 */     Object localObject = get(paramString);
/*  46 */     if (localObject == null) {
/*  47 */       return null;
/*     */     }
/*  49 */     if ((localObject instanceof String[])) {
/*  50 */       return (String[])localObject;
/*     */     }
/*  52 */     return new String[] { String.valueOf(localObject) };
/*     */   }
/*     */ 
/*     */   public int getInt(String paramString) throws RIAException {
/*  56 */     if (get(paramString) == null) {
/*  57 */       throw new RIAException("EAPTECH008001", new String[] { paramString });
/*     */     }
/*  59 */     return Integer.parseInt(getString(paramString));
/*     */   }
/*     */   public boolean getBoolean(String paramString) throws RIAException {
/*  62 */     if (get(paramString) == null) {
/*  63 */       throw new RIAException("EAPTECH008001", new String[] { paramString });
/*     */     }
/*  65 */     return Boolean.getBoolean(getString(paramString));
/*     */   }
/*     */ 
/*     */   public double getDouble(String paramString) throws RIAException {
/*  69 */     if (get(paramString) == null) {
/*  70 */       throw new RIAException("EAPTECH008001", new String[] { paramString });
/*     */     }
/*  72 */     return Double.parseDouble(getString(paramString));
/*     */   }
/*     */ 
/*     */   public float getFloat(String paramString) throws RIAException {
/*  76 */     if (get(paramString) == null) {
/*  77 */       throw new RIAException("EAPTECH008001", new String[] { paramString });
/*     */     }
/*  79 */     return Float.parseFloat(getString(paramString));
/*     */   }
/*     */ 
/*     */   public long getLong(String paramString) throws RIAException {
/*  83 */     if (get(paramString) == null) {
/*  84 */       throw new RIAException("EAPTECH008001", new String[] { paramString });
/*     */     }
/*  86 */     return Long.parseLong(getString(paramString));
/*     */   }
/*     */ 
/*     */   public List getPOJOList(String paramString) throws Exception {
/*  90 */     DataStore localDataStore = (DataStore)get(paramString);
/*  91 */     if (localDataStore == null) return null;
/*  92 */     ArrayList localArrayList = new ArrayList();
/*  93 */     List localList = localDataStore.getRowSet().getRows();
/*  94 */     String str = localDataStore.getRowSetName();
/*  95 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/*  96 */       Row localRow = (Row)localList.get(i);
/*  97 */       PojoEntity localPojoEntity = PojoUtil.createPojoEntity(str, localRow);
/*  98 */       localArrayList.add(localPojoEntity.getPojoObj());
/*     */     }
/* 100 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public Map getPojoMap(String paramString) throws Exception {
/* 104 */     DataStore localDataStore = (DataStore)get(paramString);
/* 105 */     if (localDataStore == null) return null;
/* 106 */     List localList = localDataStore.getRowSet().getRows();
/* 107 */     Map localMap1 = ContextUtil.getPojoContext();
/* 108 */     if (localList.size() > 0) {
/* 109 */       Row localRow = (Row)localList.get(0);
/* 110 */       Map localMap2 = PojoUtil.createMap(localRow);
/* 111 */       ContextUtil.setMapPojoContext(localDataStore, localMap1, 0, localMap2);
/* 112 */       return localMap2;
/*     */     }
/* 114 */     return null;
/*     */   }
/*     */ 
/*     */   public List getPojoListWithContext(String paramString) throws Exception {
/* 118 */     DataStore localDataStore = (DataStore)get(paramString);
/* 119 */     return ContextUtil.getPojoListWithContext(localDataStore);
/*     */   }
/*     */ 
/*     */   public Object getPOJO(String paramString)
/*     */     throws Exception
/*     */   {
/* 125 */     List localList = getPOJOList(paramString);
/* 126 */     return (localList == null) || (localList.isEmpty()) ? null : localList.get(0);
/*     */   }
/*     */ 
/*     */   public Object getPojoWithContext(String paramString) throws Exception {
/* 130 */     DataStore localDataStore = getDataStore(paramString);
/* 131 */     return ContextUtil.getPojoWithContext(localDataStore);
/*     */   }
/*     */ 
/*     */   public List getDeletePOJOList(String paramString) throws Exception
/*     */   {
/* 136 */     DataStore localDataStore = (DataStore)get(paramString);
/* 137 */     if (localDataStore == null) return null;
/* 138 */     ArrayList localArrayList = new ArrayList();
/* 139 */     List localList = localDataStore.getRowSet().getDeleteRows();
/* 140 */     String str = localDataStore.getRowSetName();
/* 141 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/* 142 */       Row localRow = (Row)localList.get(i);
/* 143 */       if (!localRow.isNewModify()) {
/* 144 */         PojoEntity localPojoEntity = PojoUtil.createPojoEntity(str, localRow);
/* 145 */         localArrayList.add(localPojoEntity.isDataModified() ? localPojoEntity.getOrignPojoObj() : localPojoEntity.getPojoObj());
/*     */       }
/*     */     }
/* 147 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getNewPOJOList(String paramString) throws Exception {
/* 151 */     DataStore localDataStore = (DataStore)get(paramString);
/* 152 */     if (localDataStore == null) return null;
/* 153 */     ArrayList localArrayList = new ArrayList();
/* 154 */     List localList = localDataStore.getRowSet().getRows();
/* 155 */     String str = localDataStore.getRowSetName();
/* 156 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/* 157 */       Row localRow = (Row)localList.get(i);
/* 158 */       if (localRow.isNewModify()) {
/* 159 */         PojoEntity localPojoEntity = PojoUtil.createPojoEntity(str, localRow);
/* 160 */         localArrayList.add(localPojoEntity.getPojoObj());
/*     */       }
/*     */     }
/* 162 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getUpdatePOJOList(String paramString) throws Exception {
/* 166 */     DataStore localDataStore = (DataStore)get(paramString);
/* 167 */     if (localDataStore == null) return null;
/* 168 */     ArrayList localArrayList = new ArrayList();
/* 169 */     List localList = localDataStore.getRowSet().getRows();
/* 170 */     String str = localDataStore.getRowSetName();
/* 171 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/* 172 */       Row localRow = (Row)localList.get(i);
/* 173 */       if (localRow.isDataModify()) {
/* 174 */         PojoEntity localPojoEntity = PojoUtil.createPojoEntity(str, localRow);
/* 175 */         localArrayList.add(localPojoEntity.getPojoObj());
/*     */       }
/*     */     }
/* 177 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public DataStore getDataStore(String paramString) throws Exception {
/* 181 */     return this.dc.getDataStore(paramString);
/*     */   }
/*     */ 
/*     */   public List getDataStores() throws Exception {
/* 185 */     return this.dc.getDataStores();
/*     */   }
/*     */ 
/*     */   public DataStore getSingleDataStore() throws Exception {
/* 189 */     List localList = getDataStores();
/* 190 */     return localList.isEmpty() ? null : (DataStore)localList.get(0);
/*     */   }
/*     */ 
/*     */   public String[] getDataStoreNames() throws Exception {
/* 194 */     List localList = getDataStores();
/* 195 */     String[] arrayOfString = new String[localList.size()];
/* 196 */     for (int i = 0; i < localList.size(); i++) {
/* 197 */       arrayOfString[i] = ((DataStore)localList.get(i)).getStoreName();
/*     */     }
/* 199 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */   public DataCenter getDataCenter() {
/* 203 */     return this.dc;
/*     */   }
/*     */ 
/*     */   public void setFileAttachmens(List paramList) {
/* 207 */     this.fileAttachments = paramList;
/*     */   }
/*     */ 
/*     */   public List getFileAttachments() {
/* 211 */     return this.fileAttachments;
/*     */   }
/*     */ 
/*     */   public DataStore getQueryConditionStore() throws Exception {
/* 215 */     String str = getString("_queryConditionStore");
/* 216 */     if ((str == null) || (str.equals("")))
/* 217 */       str = "_queryStore";
/* 218 */     return getDataStore(str);
/*     */   }
/*     */ 
/*     */   public List getQueryConditions() throws Exception {
/* 222 */     String str = getString("_queryConditionStore");
/* 223 */     if ((str == null) || (str.equals("")))
/* 224 */       str = "_queryStore";
/* 225 */     return getPOJOList(str);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.context.impl.ViewContextImpl
 * JD-Core Version:    0.6.2
 */