/*    */ package com.neusoft.unieap.techcomp.ria.export.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.techcomp.ria.export.bo.GridExportBO;
/*    */ import com.neusoft.unieap.techcomp.ria.export.dao.GridExportDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.export.entity.GridExportConfig;
/*    */ 
/*    */ @ModelFile("gridExportBO.bo")
/*    */ public class GridExportBOImpl
/*    */   implements GridExportBO
/*    */ {
/*    */   private GridExportDAO gridExportDAO;
/*    */ 
/*    */   public void setGridExportDAO(GridExportDAO paramGridExportDAO)
/*    */   {
/* 21 */     this.gridExportDAO = paramGridExportDAO;
/*    */   }
/*    */ 
/*    */   public String getExportConfig(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 26 */     return this.gridExportDAO.getExportConfig(paramString1, paramString2, paramString3);
/*    */   }
/*    */ 
/*    */   public void saveExportConfig(String paramString1, String paramString2, String paramString3, String paramString4)
/*    */   {
/* 31 */     GridExportConfig localGridExportConfig = new GridExportConfig();
/* 32 */     localGridExportConfig.setCmpId(paramString4);
/* 33 */     localGridExportConfig.setContent(paramString1);
/* 34 */     localGridExportConfig.setPath(paramString2);
/* 35 */     localGridExportConfig.setUserId(paramString3);
/* 36 */     this.gridExportDAO.saveExportConfig(localGridExportConfig);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.bo.impl.GridExportBOImpl
 * JD-Core Version:    0.6.2
 */