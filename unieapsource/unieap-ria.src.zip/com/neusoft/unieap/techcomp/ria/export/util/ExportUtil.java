/*     */ package com.neusoft.unieap.techcomp.ria.export.util;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.export.Column;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONException;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.poi.hssf.usermodel.HSSFWorkbook;
/*     */ import org.apache.poi.ss.usermodel.Cell;
/*     */ import org.apache.poi.ss.usermodel.CellStyle;
/*     */ import org.apache.poi.ss.usermodel.DataFormat;
/*     */ import org.apache.poi.ss.usermodel.IndexedColors;
/*     */ import org.apache.poi.ss.usermodel.Row;
/*     */ import org.apache.poi.ss.usermodel.Sheet;
/*     */ import org.apache.poi.ss.usermodel.Workbook;
/*     */ import org.apache.poi.xssf.streaming.SXSSFWorkbook;
/*     */ 
/*     */ public final class ExportUtil
/*     */ {
/*     */   private static final String EXPORT_EXCEL = "excel";
/*     */   private static final String EXPORT_EXCEL07 = "excel07";
/*     */   private static final String EXPORT_WPS = "wps";
/*     */   private static final String EXPORT_WPS07 = "wps07";
/*     */ 
/*     */   public static void exportExcel(List paramList, DataStore paramDataStore1, DataStore paramDataStore2, String paramString1, OutputStream paramOutputStream, String paramString2)
/*     */     throws Exception
/*     */   {
/*  53 */     Object localObject = null;
/*     */ 
/*  55 */     if (("excel".equals(paramString2)) || ("wps".equals(paramString2)))
/*  56 */       localObject = new HSSFWorkbook();
/*  57 */     else if (("excel07".equals(paramString2)) || ("wps07".equals(paramString2))) {
/*  58 */       localObject = new SXSSFWorkbook();
/*     */     }
/*     */ 
/*  62 */     Sheet localSheet = ((Workbook)localObject).createSheet("sheet1");
/*     */ 
/*  64 */     localSheet.setDefaultColumnWidth(15);
/*     */ 
/*  67 */     outputHeaders(paramList, localSheet);
/*     */ 
/*  69 */     int i = 1;
/*     */ 
/*  72 */     if (paramDataStore1 != null) {
/*  73 */       i = outputColumns(paramList, paramDataStore1
/*  74 */         .getRowDatas(), localSheet, i);
/*     */     }
/*     */ 
/*  78 */     if (paramDataStore2 != null) {
/*  79 */       i = outputColumns(paramList, paramDataStore2
/*  80 */         .getRowDatas(), localSheet, i);
/*     */     }
/*     */ 
/*  84 */     outputFooter(paramString1, localSheet, i);
/*     */ 
/*  86 */     autoSizeWorkbook((Workbook)localObject, paramList.size());
/*  87 */     ((Workbook)localObject).write(paramOutputStream);
/*  88 */     if ((localObject instanceof SXSSFWorkbook))
/*  89 */       ((SXSSFWorkbook)localObject).dispose();
/*     */   }
/*     */ 
/*     */   public static void autoSizeWorkbook(Workbook paramWorkbook, int paramInt)
/*     */   {
/*  95 */     Sheet localSheet = paramWorkbook.getSheetAt(0);
/*  96 */     for (int i = 0; i < paramInt; i++) {
/*  97 */       localSheet.autoSizeColumn(i);
/*  98 */       if (localSheet.getColumnWidth(i) + 1000 <= 65280)
/*  99 */         localSheet.setColumnWidth(i, localSheet.getColumnWidth(i) + 1000);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void outputHeaders(List paramList, Sheet paramSheet)
/*     */   {
/* 106 */     Row localRow = paramSheet.createRow(0);
/* 107 */     int i = paramList.size();
/* 108 */     Column localColumn = null;
/*     */ 
/* 110 */     CellStyle localCellStyle = paramSheet.getWorkbook().createCellStyle();
/* 111 */     localCellStyle.setFillForegroundColor(IndexedColors.AQUA.getIndex());
/* 112 */     localCellStyle.setFillPattern((short)1);
/*     */ 
/* 114 */     for (int j = 0; j < i; j++) {
/* 115 */       localColumn = (Column)paramList.get(j);
/* 116 */       Cell localCell = localRow.createCell(j);
/* 117 */       localCell.setCellValue(localColumn.getTitle());
/* 118 */       localCell.setCellStyle(localCellStyle);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static int outputColumns(List paramList1, List paramList2, Sheet paramSheet, int paramInt)
/*     */     throws JSONException
/*     */   {
/* 127 */     String str1 = "";
/*     */ 
/* 129 */     Workbook localWorkbook = paramSheet.getWorkbook();
/* 130 */     CellStyle localCellStyle1 = localWorkbook.createCellStyle();
/* 131 */     CellStyle localCellStyle2 = localWorkbook.createCellStyle();
/*     */ 
/* 133 */     DataFormat localDataFormat = localWorkbook.createDataFormat();
/* 134 */     localCellStyle1.setDataFormat(localDataFormat.getFormat("@"));
/* 135 */     Object localObject1 = null;
/* 136 */     String str2 = "";
/* 137 */     Object localObject2 = new Date();
/* 138 */     int i = paramList1.size();
/* 139 */     int j = paramList2.size();
/* 140 */     for (int k = 0; k < j; k++) {
/* 141 */       Row localRow = paramSheet.createRow(paramInt + k);
/* 142 */       Map localMap = (Map)paramList2.get(k);
/* 143 */       for (int m = 0; m < i; m++) {
/* 144 */         Column localColumn = (Column)paramList1.get(m);
/* 145 */         if (localMap.get(localColumn.getName()) == null)
/* 146 */           str1 = null;
/*     */         else {
/* 148 */           str1 = formatCellValue(localColumn, localMap.get(localColumn
/* 149 */             .getName()), "excel");
/*     */         }
/* 151 */         Cell localCell = localRow.createCell(m);
/* 152 */         if (str1 == null) {
/* 153 */           localCell.setCellValue("");
/* 154 */           localCell.setCellStyle(localCellStyle1);
/*     */         }
/*     */         else {
/* 157 */           localObject1 = localMap.get(localColumn.getName());
/* 158 */           str2 = localColumn.getFormat();
/* 159 */           if (((localObject1 instanceof Date)) || ((localObject1 instanceof Timestamp)) || ((str2 != null) && (str2.indexOf("yyyy") > -1))) {
/* 160 */             localCellStyle2.setDataFormat(localDataFormat.getFormat(str2));
/* 161 */             if ((localObject1 instanceof Timestamp)) {
/* 162 */               localObject2 = new Date();
/* 163 */               localObject2 = (Timestamp)localObject1;
/* 164 */               localCell.setCellValue((Date)localObject2);
/* 165 */             } else if ((localObject1 instanceof Date)) {
/* 166 */               localCell.setCellValue((Date)localObject1);
/*     */             } else {
/* 168 */               localObject2 = new Date(Long.parseLong(localObject1.toString()));
/* 169 */               localCell.setCellValue((Date)localObject2);
/*     */             }
/* 171 */             localCell.setCellStyle(localCellStyle2);
/*     */           } else {
/* 173 */             localCell.setCellValue(str1);
/* 174 */             localCell.setCellStyle(localCellStyle1);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 179 */     return paramInt + j;
/*     */   }
/*     */ 
/*     */   public static void outputFooter(String paramString, Sheet paramSheet, int paramInt) {
/* 183 */     if ((paramString != null) && (!paramString.equals("")))
/* 184 */       paramSheet.createRow(paramInt).createCell(0).setCellValue(paramString);
/*     */   }
/*     */ 
/*     */   public static List getHeadersInfo(ViewContext paramViewContext)
/*     */     throws JSONException
/*     */   {
/* 190 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 192 */     JSONArray localJSONArray1 = (JSONArray)paramViewContext.get("layout");
/* 193 */     JSONArray localJSONArray2 = null;
/*     */     try {
/* 195 */       if (!"{}".equals(String.valueOf(paramViewContext.getDataCenter().getParameter("exportLabels"))))
/* 196 */         localJSONArray2 = (JSONArray)paramViewContext.getDataCenter().getParameter("exportLabels");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 200 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 203 */     Column localColumn = null;
/* 204 */     int i = 0; for (int j = localJSONArray1.size(); i < j; i++) {
/* 205 */       JSONArray localJSONArray3 = localJSONArray1.getJSONArray(i);
/* 206 */       int k = 0; for (int m = localJSONArray3.size(); k < m; k++) {
/* 207 */         JSONArray localJSONArray4 = localJSONArray3.getJSONArray(k);
/* 208 */         int n = 0; for (int i1 = localJSONArray4.size(); n < i1; n++) {
/* 209 */           JSONObject localJSONObject = (JSONObject)localJSONArray4.get(n);
/* 210 */           if (!localJSONObject.containsKey("isMulTitle"))
/*     */           {
/* 212 */             if ((localJSONObject.containsKey("name")) && (advanceConfigContains(localJSONArray2, localJSONObject.getString("name")))) {
/* 213 */               localColumn = new Column(localJSONObject.getString("name"), localJSONObject
/* 214 */                 .getString("label"));
/* 215 */               if (localJSONObject.containsKey("dataFormat")) {
/* 216 */                 localColumn.setFormat(localJSONObject.getString("dataFormat"));
/*     */               }
/* 218 */               if (localJSONObject.containsKey("decoder")) {
/* 219 */                 localColumn.setCodelist((Map)localJSONObject.get("decoder"));
/*     */               }
/* 221 */               localArrayList.add(localColumn);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 226 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static boolean advanceConfigContains(JSONArray paramJSONArray, String paramString)
/*     */   {
/* 231 */     if (paramJSONArray == null) {
/* 232 */       return true;
/*     */     }
/* 234 */     int i = paramJSONArray.size();
/* 235 */     for (int j = 0; j < i; j++) {
/* 236 */       JSONObject localJSONObject = paramJSONArray.getJSONObject(j);
/* 237 */       if (localJSONObject.get("name").toString().equals(paramString)) {
/* 238 */         return true;
/*     */       }
/*     */     }
/* 241 */     return false;
/*     */   }
/*     */ 
/*     */   public static void outputHeaders(List paramList, OutputStreamWriter paramOutputStreamWriter) throws IOException
/*     */   {
/* 246 */     int i = paramList.size();
/* 247 */     Column localColumn = null;
/* 248 */     for (int j = 0; j < i; j++) {
/* 249 */       localColumn = (Column)paramList.get(j);
/* 250 */       paramOutputStreamWriter.write(localColumn.getTitle());
/* 251 */       if (j != i - 1) {
/* 252 */         paramOutputStreamWriter.write(",");
/*     */       }
/*     */     }
/*     */ 
/* 256 */     paramOutputStreamWriter.write("\r\n");
/*     */   }
/*     */ 
/*     */   public static void outputColumns(List paramList1, List paramList2, OutputStreamWriter paramOutputStreamWriter)
/*     */     throws IOException
/*     */   {
/* 264 */     String str = "";
/* 265 */     int i = paramList1.size();
/* 266 */     int j = paramList2.size();
/* 267 */     for (int k = 0; k < j; k++) {
/* 268 */       Map localMap = (Map)paramList2.get(k);
/* 269 */       for (int m = 0; m < i; m++) {
/* 270 */         Column localColumn = (Column)paramList1.get(m);
/* 271 */         if (localMap.get(localColumn.getName()) == null)
/* 272 */           str = null;
/*     */         else {
/* 274 */           str = formatCellValue(localColumn, localMap.get(localColumn
/* 275 */             .getName()), "csv");
/*     */         }
/* 277 */         if (str == null)
/* 278 */           paramOutputStreamWriter.write("\"\"");
/*     */         else {
/* 280 */           paramOutputStreamWriter.write(str);
/*     */         }
/* 282 */         if (m != i - 1) {
/* 283 */           paramOutputStreamWriter.write(",");
/*     */         }
/*     */       }
/* 286 */       paramOutputStreamWriter.write("\r\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void outputFooter(String paramString, OutputStreamWriter paramOutputStreamWriter)
/*     */     throws IOException
/*     */   {
/* 293 */     if ((paramString != null) && (!paramString.equals("")))
/*     */     {
/* 295 */       if ((paramString.indexOf(",") > -1) || (paramString.indexOf("\n") > -1)) {
/* 296 */         paramString = "\"" + paramString + "\"";
/*     */       }
/*     */       else {
/* 299 */         String str = "^(-)?\\d+(.)?\\d*$";
/* 300 */         paramString = paramString.trim();
/* 301 */         if (((paramString.matches(str)) && (paramString.length() >= 9)) || 
/* 302 */           (paramString.startsWith("0"))) {
/* 303 */           paramString = "=\"" + paramString + "\"";
/*     */         }
/*     */       }
/* 306 */       paramOutputStreamWriter.write(paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String formatCellValue(Column paramColumn, Object paramObject, String paramString)
/*     */   {
/* 313 */     String str1 = "";
/* 314 */     String str2 = paramColumn.getFormat();
/*     */     Object localObject1;
/*     */     Object localObject3;
/*     */     Object localObject4;
/* 316 */     if (paramColumn.ifCodeList()) {
/* 317 */       localObject1 = paramColumn.getCodelist();
/*     */ 
/* 320 */       localObject2 = paramObject.toString();
/* 321 */       localObject3 = ((String)localObject2).split(",");
/* 322 */       if (localObject3.length > 1) {
/* 323 */         localObject4 = new StringBuilder();
/* 324 */         for (Object localObject5 : localObject3) {
/* 325 */           ((StringBuilder)localObject4).append((String)((Map)localObject1).get(localObject5))
/* 326 */             .append(",");
/*     */         }
/* 328 */         str1 = ((StringBuilder)localObject4).substring(0, ((StringBuilder)localObject4).length() - 1);
/*     */       } else {
/* 330 */         str1 = (String)((Map)localObject1).get(paramObject.toString());
/*     */       }
/*     */     }
/* 333 */     else if ((str2 != null) && (!str2.equals(""))) {
/* 334 */       if (((paramObject instanceof Date)) || 
/* 335 */         ((paramObject instanceof Timestamp)) || 
/* 336 */         (str2.indexOf("yyyy") > -1)) {
/* 337 */         localObject1 = new SimpleDateFormat(str2);
/*     */         try {
/* 339 */           paramObject = Long.valueOf(paramObject.toString());
/* 340 */           str1 = ((SimpleDateFormat)localObject1).format(paramObject);
/*     */         } catch (NumberFormatException localNumberFormatException1) {
/* 342 */           str1 = ((SimpleDateFormat)localObject1).format(paramObject);
/*     */         }
/* 344 */       } else if (((paramObject instanceof Number)) || 
/* 345 */         (str2.startsWith("#"))) {
/* 346 */         localObject1 = new DecimalFormat();
/*     */ 
/* 348 */         ((DecimalFormat)localObject1).applyPattern(str2);
/*     */         try {
/* 350 */           localObject2 = new BigDecimal(paramObject.toString());
/* 351 */           str1 = ((DecimalFormat)localObject1).format(localObject2);
/*     */         }
/*     */         catch (NumberFormatException localNumberFormatException2)
/*     */         {
/* 355 */           str1 = paramObject.toString();
/*     */         }
/*     */       }
/*     */     } else {
/* 359 */       str1 = paramObject.toString();
/*     */     }
/* 361 */     if ((str1 != null) && (
/* 362 */       (str1.contains("\n")) || (str1.contains("\r")))) {
/* 363 */       str1 = str1.replace("\n", " ");
/* 364 */       str1 = str1.replace("\r", " ");
/*     */     }
/*     */ 
/* 367 */     Object localObject2 = new StringBuilder();
/* 368 */     if (str1 != null) {
/* 369 */       if (paramString.equals("csv")) {
/* 370 */         localObject3 = Pattern.compile("\\d{1}[\\d-/.]*");
/* 371 */         localObject4 = ((Pattern)localObject3).matcher(str1);
/* 372 */         if (((Matcher)localObject4).matches()) {
/* 373 */           ((StringBuilder)localObject2).append("=");
/*     */         }
/* 375 */         ((StringBuilder)localObject2).append("\"").append(str1).append("\"");
/*     */       } else {
/* 377 */         ((StringBuilder)localObject2).append(str1);
/*     */       }
/*     */     }
/* 380 */     return ((StringBuilder)localObject2).toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.util.ExportUtil
 * JD-Core Version:    0.6.2
 */