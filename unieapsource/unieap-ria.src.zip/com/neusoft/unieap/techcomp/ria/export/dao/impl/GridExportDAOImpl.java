/*    */ package com.neusoft.unieap.techcomp.ria.export.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.export.dao.GridExportDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.export.entity.GridExportConfig;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("gridExportDAO.dao")
/*    */ public class GridExportDAOImpl extends BaseHibernateDAO
/*    */   implements GridExportDAO
/*    */ {
/*    */   public String getExportConfig(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 22 */     String str = "select exportConfig.content from GridExportConfig exportConfig where exportConfig.userId = ? and exportConfig.cmpId = ? and exportConfig.path = ?";
/* 23 */     List localList = getHibernateTemplate().find(str, new Object[] { paramString2, paramString3, paramString1 });
/* 24 */     if (localList.size() == 0) {
/* 25 */       return "";
/*    */     }
/* 27 */     return String.valueOf(localList.get(0));
/*    */   }
/*    */ 
/*    */   public void saveExportConfig(GridExportConfig paramGridExportConfig) {
/* 31 */     String str = "select exportConfig.id from GridExportConfig exportConfig where exportConfig.userId = ? and exportConfig.cmpId = ? and exportConfig.path = ?";
/* 32 */     List localList = getHibernateTemplate().find(str, new Object[] { paramGridExportConfig.getUserId(), paramGridExportConfig.getCmpId(), paramGridExportConfig.getPath() });
/* 33 */     if (localList.size() > 0) {
/* 34 */       paramGridExportConfig.setId(String.valueOf(localList.get(0)));
/* 35 */       getHibernateTemplate().update(paramGridExportConfig);
/*    */     } else {
/* 37 */       getHibernateTemplate().save(paramGridExportConfig);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.dao.impl.GridExportDAOImpl
 * JD-Core Version:    0.6.2
 */