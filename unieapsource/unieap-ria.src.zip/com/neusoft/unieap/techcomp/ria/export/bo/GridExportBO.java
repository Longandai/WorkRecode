package com.neusoft.unieap.techcomp.ria.export.bo;

public abstract interface GridExportBO
{
  public abstract void saveExportConfig(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract String getExportConfig(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.bo.GridExportBO
 * JD-Core Version:    0.6.2
 */