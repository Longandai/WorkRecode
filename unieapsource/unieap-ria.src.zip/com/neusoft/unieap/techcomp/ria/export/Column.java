/*    */ package com.neusoft.unieap.techcomp.ria.export;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class Column
/*    */ {
/*    */   private String name;
/*    */   private String title;
/*    */   private int width;
/*  9 */   private int colSpan = 1;
/* 10 */   private int rowSpan = 1;
/*    */   private boolean isMulTitle;
/*    */   private String format;
/* 13 */   private Map codelist = null;
/*    */ 
/*    */   public Column() {
/*    */   }
/*    */ 
/*    */   public Column(String paramString) {
/* 19 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public Column(String paramString1, String paramString2) {
/* 23 */     this.name = paramString1;
/* 24 */     this.title = paramString2;
/*    */   }
/*    */ 
/*    */   public Column(String paramString1, String paramString2, int paramInt) {
/* 28 */     this.name = paramString1;
/* 29 */     this.title = paramString2;
/* 30 */     this.width = paramInt;
/*    */   }
/*    */ 
/*    */   public boolean ifCodeList() {
/* 34 */     return this.codelist != null;
/*    */   }
/*    */ 
/*    */   public Map getCodelist() {
/* 38 */     return this.codelist;
/*    */   }
/*    */ 
/*    */   public void setCodelist(Map paramMap) {
/* 42 */     this.codelist = paramMap;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 46 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString) {
/* 50 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public String getTitle() {
/* 54 */     return this.title;
/*    */   }
/*    */ 
/*    */   public void setTitle(String paramString) {
/* 58 */     this.title = paramString;
/*    */   }
/*    */ 
/*    */   public int getWidth() {
/* 62 */     return this.width;
/*    */   }
/*    */ 
/*    */   public void setWidth(int paramInt) {
/* 66 */     this.width = paramInt;
/*    */   }
/*    */ 
/*    */   public String getFormat() {
/* 70 */     return this.format;
/*    */   }
/*    */ 
/*    */   public void setFormat(String paramString) {
/* 74 */     this.format = paramString;
/*    */   }
/*    */ 
/*    */   public int getColSpan() {
/* 78 */     return this.colSpan;
/*    */   }
/*    */ 
/*    */   public void setColSpan(int paramInt) {
/* 82 */     this.colSpan = paramInt;
/*    */   }
/*    */ 
/*    */   public int getRowSpan() {
/* 86 */     return this.rowSpan;
/*    */   }
/*    */ 
/*    */   public void setRowSpan(int paramInt) {
/* 90 */     this.rowSpan = paramInt;
/*    */   }
/*    */ 
/*    */   public boolean isMulTitle() {
/* 94 */     return this.isMulTitle;
/*    */   }
/*    */ 
/*    */   public void setMulTitle(boolean paramBoolean) {
/* 98 */     this.isMulTitle = paramBoolean;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.Column
 * JD-Core Version:    0.6.2
 */