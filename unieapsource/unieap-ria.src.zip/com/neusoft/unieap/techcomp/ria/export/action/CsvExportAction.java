/*     */ package com.neusoft.unieap.techcomp.ria.export.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.page.PageUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.context.impl.ViewContextImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.export.GridExport;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*     */ import com.neusoft.unieap.techcomp.ria.util.Base64;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletOutputStream;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import net.sf.json.JSONObject;
/*     */ import net.sf.json.util.JSONUtils;
/*     */ import org.apache.struts2.interceptor.ServletRequestAware;
/*     */ import org.apache.struts2.interceptor.ServletResponseAware;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class CsvExportAction extends ActionSupport
/*     */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = -5190096257036218733L;
/*     */   private static final String EXPORT_CSV = "csv";
/*     */   private static final String EXPORT_EXCEL = "excel";
/*     */   private static final String EXPORT_EXCEL07 = "excel07";
/*     */   private static final String EXPORT_WPS = "wps";
/*     */   private static final String EXPORT_WPS07 = "wps07";
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */   private ApplicationContext applicationContext;
/*  66 */   private int serverExportMaxCount = -1;
/*     */ 
/*     */   public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
/*  69 */     this.request = paramHttpServletRequest;
/*     */   }
/*     */ 
/*     */   public void setServletResponse(HttpServletResponse paramHttpServletResponse)
/*     */   {
/*  74 */     this.response = paramHttpServletResponse;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getRequest() {
/*  78 */     return this.request;
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getResponse() {
/*  82 */     return this.response;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*     */   {
/*  87 */     this.applicationContext = paramApplicationContext;
/*     */   }
/*     */ 
/*     */   public void setServerExportMaxCount(int paramInt) {
/*  91 */     this.serverExportMaxCount = paramInt;
/*     */   }
/*     */ 
/*     */   protected final ViewContext generateContext(String paramString)
/*     */     throws Exception
/*     */   {
/* 101 */     ViewContextImpl localViewContextImpl = new ViewContextImpl();
/* 102 */     DataCenter localDataCenter = DataCenterIOManager.createReader(
/* 103 */       this.request.getParameter(paramString)).parse();
/*     */ 
/* 105 */     Map localMap1 = localDataCenter.getParameters();
/* 106 */     ((ViewContextImpl)localViewContextImpl).setDc(localDataCenter);
/* 107 */     localViewContextImpl.putAll(localMap1);
/*     */ 
/* 109 */     Map localMap2 = this.request.getParameterMap();
/* 110 */     Iterator localIterator = localMap2.entrySet().iterator();
/*     */     Object localObject2;
/* 111 */     while (localIterator.hasNext()) {
/* 112 */       localObject1 = (Map.Entry)localIterator.next();
/* 113 */       String str1 = ((Map.Entry)localObject1).getKey().toString();
/* 114 */       localObject2 = ((Map.Entry)localObject1).getValue();
/* 115 */       if (localObject2.getClass().isArray()) {
/* 116 */         if (Array.getLength(localObject2) == 1)
/* 117 */           localViewContextImpl.put(str1, this.request.getParameter(str1));
/*     */         else {
/* 119 */           localViewContextImpl.put(str1, localObject2);
/*     */         }
/*     */       }
/*     */     }
/* 123 */     Object localObject1 = localDataCenter.getDataStores();
/*     */     Object localObject3;
/* 124 */     for (int i = 0; i < ((List)localObject1).size(); i++) {
/* 125 */       localObject2 = (DataStore)((List)localObject1).get(i);
/* 126 */       localObject3 = ((DataStore)localObject2).getStoreName();
/* 127 */       localViewContextImpl.put(localObject3, localObject2);
/*     */     }
/*     */ 
/* 130 */     String str2 = localViewContextImpl.getString("type");
/*     */     Object localObject4;
/*     */     Object localObject5;
/*     */     Object localObject6;
/*     */     Object localObject7;
/*     */     Object localObject8;
/*     */     Object localObject10;
/*     */     Object localObject9;
/* 131 */     if (str2.equals("server")) {
/* 132 */       int j = -1;
/*     */ 
/* 134 */       localObject3 = localViewContextImpl.getString("count");
/* 135 */       if (localObject3 != null) {
/* 136 */         j = Integer.valueOf((String)localObject3).intValue();
/*     */       }
/*     */       else {
/* 139 */         j = this.serverExportMaxCount;
/*     */       }
/*     */ 
/* 142 */       if (j != -1) {
/* 143 */         PageUtil.setPageNumber(1);
/* 144 */         PageUtil.setPageSize(j);
/* 145 */         PageUtil.setAutoCalcCount(true);
/*     */       } else {
/* 147 */         PageUtil.setPageNumber(1);
/* 148 */         PageUtil.setPageSize(this.serverExportMaxCount);
/* 149 */         PageUtil.setAutoCalcCount(true);
/*     */       }
/*     */ 
/* 152 */       localObject4 = localViewContextImpl.getString("dsName");
/* 153 */       localObject5 = localViewContextImpl.getDataStore((String)localObject4);
/*     */ 
/* 156 */       if (localObject5 != null) {
/* 157 */         localObject6 = ((DataStore)localObject5).getParameters();
/* 158 */         if ((localObject6 != null) && (!((Map)localObject6).isEmpty())) {
/* 159 */           localViewContextImpl.putAll((Map)localObject6);
/* 160 */           localObject7 = null;
/* 161 */           localObject8 = ((Map)localObject6).keySet();
/* 162 */           for (localObject10 = ((Set)localObject8).iterator(); ((Iterator)localObject10).hasNext(); ) { localObject9 = ((Iterator)localObject10).next();
/* 163 */             if (!localObject9.toString().equalsIgnoreCase("_exportDS"))
/*     */             {
/* 166 */               String str4 = ((Map)localObject6).get(localObject9).toString();
/* 167 */               if (str4.equals("null")) {
/* 168 */                 localViewContextImpl.put(localObject9.toString(), null);
/*     */               }
/* 171 */               else if (str4.trim().equals("")) {
/* 172 */                 localViewContextImpl.put(localObject9.toString(), "");
/*     */               }
/*     */               else {
/* 175 */                 if ((JSONUtils.mayBeJSON(str4)) && 
/* 176 */                   (str4.contains("rowSet"))) {
/* 177 */                   JSONObject localJSONObject = 
/* 178 */                     JSONObject.fromObject(str4);
/* 179 */                   localObject7 = new DataStoreImpl(localObject9.toString(), 
/* 180 */                     localJSONObject);
/* 181 */                   localViewContextImpl.put(localObject9.toString(), localObject7);
/* 182 */                   localViewContextImpl.getDataCenter().addDataStore((DataStore)localObject7);
/*     */                 }
/*     */ 
/* 185 */                 if (localObject9.toString().equals("pageSize")) {
/* 186 */                   int k = Integer.valueOf(((Map)localObject6).get(
/* 187 */                     "pageSize").toString()).intValue();
/*     */ 
/* 188 */                   k = ((DataStore)localObject5).getRecordCount();
/* 189 */                   if (j != -1)
/* 190 */                     localViewContextImpl.put("pageSize", Integer.valueOf(j));
/*     */                   else
/* 192 */                     localViewContextImpl.put("pageSize", Integer.valueOf(k));
/*     */                 }
/*     */               }
/*     */             } }
/*     */         }
/*     */       }
/* 198 */     } else if (str2.equals("client"))
/*     */     {
/* 200 */       String str3 = localViewContextImpl.getString("dsName");
/* 201 */       localObject3 = localViewContextImpl.getDataStore(str3);
/* 202 */       if (localObject3 != null) {
/* 203 */         localObject4 = ((DataStore)localObject3).getParameters();
/* 204 */         if ((localObject4 != null) && (!((Map)localObject4).isEmpty())) {
/* 205 */           localObject5 = null;
/* 206 */           localObject6 = ((Map)localObject4).keySet();
/* 207 */           for (localObject8 = ((Set)localObject6).iterator(); ((Iterator)localObject8).hasNext(); ) { localObject7 = ((Iterator)localObject8).next();
/* 208 */             if (localObject7.toString().equals("_exportDS")) {
/* 209 */               localObject9 = ((Map)localObject4).get(localObject7).toString();
/* 210 */               if ((((String)localObject9).equals("null")) || 
/* 211 */                 (((String)localObject9).trim().equals(""))) {
/*     */                 break;
/*     */               }
/* 214 */               if (JSONUtils.mayBeJSON((String)localObject9)) {
/* 215 */                 if (((String)localObject9).contains("rowSet")) {
/* 216 */                   localObject10 = 
/* 217 */                     JSONObject.fromObject(localObject9);
/* 218 */                   localObject5 = new DataStoreImpl("_exportDS", 
/* 219 */                     (JSONObject)localObject10);
/* 220 */                   localViewContextImpl.getDataCenter().addDataStore(
/* 221 */                     (DataStore)localObject5);
/* 222 */                   break;
/*     */                 }
/* 224 */                 throw new RIAException("EAPTECH008013", 
/* 225 */                   null);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 233 */     return localViewContextImpl;
/*     */   }
/*     */ 
/*     */   public String export()
/*     */   {
/* 243 */     UniEAPContextHolder.getContext().addCustomProperty("exportDone", "false");
/*     */     try {
/* 245 */       ViewContext localViewContext = generateContext("data");
/* 246 */       String str = (String)localViewContext.getDataCenter().getParameter(
/* 247 */         "exportType");
/* 248 */       if ("excel".equals(str))
/* 249 */         return exportGrid(localViewContext, "excel");
/* 250 */       if ("excel07".equals(str))
/* 251 */         return exportGrid(localViewContext, "excel07");
/* 252 */       if ("wps".equals(str))
/* 253 */         return exportGrid(localViewContext, "wps");
/* 254 */       if ("wps07".equals(str)) {
/* 255 */         return exportGrid(localViewContext, "wps07");
/*     */       }
/* 257 */       return exportGrid(localViewContext, "csv");
/*     */     } catch (Exception localException) {
/* 259 */       UniEAPContextHolder.getContext().addCustomProperty("exportDone", "error");
/*     */     }
/* 261 */     return null;
/*     */   }
/*     */ 
/*     */   public String exportExcel()
/*     */   {
/* 271 */     UniEAPContextHolder.getContext().addCustomProperty("exportDone", "false");
/*     */     try {
/* 273 */       ViewContext localViewContext = generateContext("data");
/* 274 */       String str = (String)localViewContext.getDataCenter().getParameter(
/* 275 */         "exportType");
/* 276 */       if ("excel".equals(str))
/* 277 */         return exportGrid(localViewContext, "excel");
/* 278 */       if ("excel07".equals(str))
/* 279 */         return exportGrid(localViewContext, "excel07");
/* 280 */       if ("wps".equals(str))
/* 281 */         return exportGrid(localViewContext, "wps");
/* 282 */       if ("wps07".equals(str)) {
/* 283 */         return exportGrid(localViewContext, "wps07");
/*     */       }
/* 285 */       return exportGrid(localViewContext, "excel");
/*     */     } catch (Exception localException) {
/* 287 */       UniEAPContextHolder.getContext().addCustomProperty("exportDone", "error");
/*     */     }
/* 289 */     return null;
/*     */   }
/*     */ 
/*     */   private String exportGrid(ViewContext paramViewContext, String paramString)
/*     */     throws Exception
/*     */   {
/* 301 */     String str1 = (String)paramViewContext.getDataCenter().getParameter(
/* 302 */       "name");
/* 303 */     if ((str1 == null) || (str1.trim().length() == 0)) {
/* 304 */       str1 = "export";
/*     */     } else {
/* 306 */       localObject1 = this.request.getHeader("USER-AGENT");
/* 307 */       if (localObject1 != null) {
/* 308 */         if (((String)localObject1).indexOf("Firefox") > 0)
/*     */         {
/* 310 */           str1 = "=?UTF-8?B?" + 
/* 311 */             new String(Base64.encodeBase64(str1
/* 312 */             .getBytes("UTF-8"))) + "?=";
/*     */         }
/*     */         else {
/* 315 */           str1 = new String(str1.getBytes("GBK"), "ISO-8859-1");
/*     */         }
/*     */       }
/*     */     }
/* 319 */     Object localObject1 = null;
/*     */     try {
/* 321 */       this.response.setContentType("application/octet-stream");
/* 322 */       if ("excel".equals(paramString))
/* 323 */         this.response.setHeader("Content-Disposition", 
/* 324 */           "attachment;filename=" + str1 + ".xls");
/* 325 */       else if ("excel07".equals(paramString))
/* 326 */         this.response.setHeader("Content-Disposition", 
/* 327 */           "attachment;filename=" + str1 + ".xlsx");
/* 328 */       else if ("wps".equals(paramString))
/* 329 */         this.response.setHeader("Content-Disposition", 
/* 330 */           "attachment;filename=" + str1 + ".et");
/* 331 */       else if ("wps07".equals(paramString))
/* 332 */         this.response.setHeader("Content-Disposition", 
/* 333 */           "attachment;filename=" + str1 + ".et");
/*     */       else {
/* 335 */         this.response.setHeader("Content-Disposition", 
/* 336 */           "attachment;filename=" + str1 + ".csv");
/*     */       }
/* 338 */       localObject1 = this.response.getOutputStream();
/* 339 */       doExport(paramViewContext, (OutputStream)localObject1, paramString);
/* 340 */       UniEAPContextHolder.getContext().addCustomProperty("exportDone", "true");
/* 341 */       ((ServletOutputStream)localObject1).flush();
/*     */     }
/*     */     catch (Exception localException) {
/* 344 */       UniEAPContextHolder.getContext().addCustomProperty("exportDone", "error");
/*     */ 
/* 346 */       String str2 = localException.getClass().getCanonicalName();
/*     */ 
/* 348 */       if (str2
/* 348 */         .endsWith("org.apache.catalina.connector.ClientAbortException")) {
/* 349 */         return "none";
/*     */       }
/* 351 */       localException.printStackTrace();
/*     */     }
/*     */     finally {
/* 354 */       if (localObject1 != null) {
/* 355 */         ((ServletOutputStream)localObject1).close();
/*     */       }
/*     */     }
/*     */ 
/* 359 */     return "none";
/*     */   }
/*     */ 
/*     */   private void doExport(ViewContext paramViewContext, OutputStream paramOutputStream, String paramString)
/*     */     throws Exception
/*     */   {
/* 371 */     String str = paramViewContext.getString("type");
/* 372 */     if ((str == null) || (str.equals("")))
/* 373 */       return;
/* 374 */     if (str.equals("client")) {
/* 375 */       doClientExport(paramViewContext, paramOutputStream, paramString);
/*     */     }
/* 377 */     if (str.equals("server"))
/* 378 */       doServerExport(paramViewContext, paramOutputStream, paramString);
/*     */   }
/*     */ 
/*     */   private void doServerExport(ViewContext paramViewContext, OutputStream paramOutputStream, String paramString)
/*     */     throws Exception
/*     */   {
/* 400 */     Object localObject = null;
/*     */ 
/* 402 */     String str1 = (String)paramViewContext.get("_pageKey");
/* 403 */     if (str1 != null) {
/* 404 */       localObject = this.applicationContext.getBean("ria_pageQueryBO_bo");
/* 405 */       if (localObject == null)
/* 406 */         throw new RIAException("EAPTECH008012", 
/* 407 */           new Object[] { "ria_pageQueryBO_bo" });
/*     */     }
/*     */     else {
/* 410 */       String str2 = paramViewContext.getString("_boId");
/* 411 */       if (str2 == null) {
/* 412 */         throw new RIAException("EAPTECH008011", null);
/*     */       }
/*     */ 
/* 416 */       localObject = this.applicationContext.getBean(str2);
/* 417 */       if (localObject == null) {
/* 418 */         throw new RIAException("EAPTECH008012", new Object[] { str2 });
/*     */       }
/*     */     }
/* 421 */     GridExport.doServerExport(paramViewContext, paramOutputStream, localObject, paramString);
/*     */   }
/*     */ 
/*     */   private void doClientExport(ViewContext paramViewContext, OutputStream paramOutputStream, String paramString)
/*     */     throws Exception
/*     */   {
/* 434 */     GridExport.doClientExport(paramViewContext, paramOutputStream, paramString);
/*     */   }
/*     */ 
/*     */   public void getExportFinishedFlag()
/*     */   {
/* 445 */     String str = (String)UniEAPContextHolder.getContext().getCustomProperty("exportDone");
/* 446 */     if ((str != null) && (!"false".equals(str)))
/* 447 */       UniEAPContextHolder.getContext().removeCustomProperty("exportDone");
/*     */     try
/*     */     {
/* 450 */       PrintWriter localPrintWriter = this.response.getWriter();
/* 451 */       if (str == null)
/* 452 */         localPrintWriter.write("");
/*     */       else
/* 454 */         localPrintWriter.write(str);
/*     */     }
/*     */     catch (IOException localIOException) {
/* 457 */       localIOException.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.action.CsvExportAction
 * JD-Core Version:    0.6.2
 */