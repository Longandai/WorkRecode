/*     */ package com.neusoft.unieap.techcomp.ria.export;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.core.page.PageContext;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCache;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.export.util.ExportUtil;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ 
/*     */ public class GridExport
/*     */ {
/*     */   public static void doServerExport(ViewContext paramViewContext, OutputStream paramOutputStream, Object paramObject, String paramString)
/*     */     throws Exception
/*     */   {
/*  38 */     List localList = ExportUtil.getHeadersInfo(paramViewContext);
/*     */ 
/*  41 */     DataCenter localDataCenter = DataCenterFactory.getInstance()
/*  42 */       .createDataCenter();
/*     */ 
/*  44 */     String str1 = (String)paramViewContext.get("_pageKey");
/*     */     Object localObject5;
/*  45 */     if (str1 != null) {
/*  46 */       localObject1 = UniEAPContextHolder.getContext()
/*  47 */         .getCurrentUser().getAccount();
/*  48 */       localObject2 = (Map)((EAPCacheManager)
/*  49 */         BeanUtil.getBean("eapCacheManager")).getCache("pageContext")
/*  50 */         .getObject(localObject1);
/*  51 */       if ((localObject2 != null) && (((Map)localObject2).size() > 0)) {
/*  52 */         localObject3 = (PageContext)((Map)localObject2).get(str1);
/*  53 */         localObject4 = null;
/*  54 */         if (localObject3 != null) {
/*  55 */           localObject5 = ((PageContext)localObject3).getDataSourceID();
/*  56 */           if ((localObject5 != null) && (!"".equals(localObject5))) {
/*  57 */             DataSourceContextHolder.setDataSourceType((String)localObject5);
/*     */           }
/*  59 */           String str2 = ((PageContext)localObject3).getSessionFactoryId();
/*  60 */           if ((str2 != null) && 
/*  61 */             (str2.length() > 0)) {
/*  62 */             PropertyUtils.setProperty(PropertyUtils.getProperty(
/*  63 */               BeanUtil.getBean("ria_pageQueryBO_bo"), 
/*  64 */               "pageQueryDAO"), "sessionFactory", 
/*  65 */               BeanUtil.getBean(str2));
/*     */           }
/*  67 */           Method[] arrayOfMethod = paramObject.getClass().getMethods();
/*  68 */           for (int i = 0; i < arrayOfMethod.length; i++)
/*  69 */             if (arrayOfMethod[i].getName().equals("query")) {
/*  70 */               localObject4 = arrayOfMethod[i].invoke(paramObject, new Object[] { localObject3 });
/*  71 */               Class localClass = arrayOfMethod[i].getReturnType();
/*  72 */               CommonUtil.handleBoMethodReturn(localDataCenter, localObject4, 
/*  73 */                 localClass);
/*  74 */               break;
/*     */             }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  81 */       CommonUtil.invokeBoMethod(paramViewContext, localDataCenter, paramObject);
/*     */     }
/*     */ 
/*  84 */     Object localObject1 = null;
/*  85 */     Object localObject2 = localDataCenter.getDataStores();
/*  86 */     if (((List)localObject2).size() == 1) {
/*  87 */       localObject1 = (DataStore)((List)localObject2).get(0);
/*     */     } else {
/*  89 */       localObject3 = 
/*  90 */         (DataStore)paramViewContext.getDataCenter()
/*  90 */         .getDataStores().get(0);
/*  91 */       for (localObject5 = ((List)localObject2).iterator(); ((Iterator)localObject5).hasNext(); ) { localObject4 = (DataStore)((Iterator)localObject5).next();
/*  92 */         if (((DataStore)localObject4).getRowSetName().equals(((DataStore)localObject3).getRowSetName())) {
/*  93 */           localObject1 = localObject4;
/*  94 */           break;
/*  95 */         }if ((((DataStore)localObject3).getParameters().get("_pageKey") != null) && 
/*  96 */           (((DataStore)localObject3).getParameters().get("_pageKey").equals(
/*  97 */           ((DataStore)localObject4).getParameters().get("_pageKey")))) {
/*  98 */           localObject1 = localObject4;
/*  99 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 103 */     Object localObject3 = paramViewContext.getDataStore("lockedStore");
/* 104 */     Object localObject4 = paramViewContext.getString("footer");
/*     */ 
/* 106 */     if (paramString.equalsIgnoreCase("csv")) {
/* 107 */       localObject5 = new OutputStreamWriter(paramOutputStream, "GBK");
/*     */ 
/* 109 */       ExportUtil.outputHeaders(localList, (OutputStreamWriter)localObject5);
/*     */ 
/* 112 */       if (localObject1 != null) {
/* 113 */         ExportUtil.outputColumns(localList, ((DataStore)localObject1).getRowDatas(), 
/* 114 */           (OutputStreamWriter)localObject5);
/*     */       }
/*     */ 
/* 118 */       if (localObject3 != null) {
/* 119 */         ExportUtil.outputColumns(localList, 
/* 120 */           ((DataStore)localObject3).getRowDatas(), (OutputStreamWriter)localObject5);
/*     */       }
/*     */ 
/* 124 */       ExportUtil.outputFooter((String)localObject4, (OutputStreamWriter)localObject5);
/*     */ 
/* 126 */       ((OutputStreamWriter)localObject5).close();
/*     */     } else {
/* 128 */       ExportUtil.exportExcel(localList, (DataStore)localObject1, (DataStore)localObject3, (String)localObject4, 
/* 129 */         paramOutputStream, paramString);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void doClientExport(ViewContext paramViewContext, OutputStream paramOutputStream, String paramString)
/*     */     throws Exception
/*     */   {
/* 144 */     List localList = ExportUtil.getHeadersInfo(paramViewContext);
/* 145 */     String str1 = paramViewContext.getString("dsName");
/* 146 */     Object localObject = paramViewContext.getDataStore(str1);
/* 147 */     DataStore localDataStore1 = paramViewContext.getDataStore("lockedStore");
/* 148 */     String str2 = paramViewContext.getString("footer");
/*     */ 
/* 151 */     DataStore localDataStore2 = paramViewContext.getDataStore("_exportDS");
/* 152 */     if (localDataStore2 != null) {
/* 153 */       localObject = localDataStore2;
/* 154 */       localDataStore1 = null;
/*     */     }
/* 156 */     if (paramString.equalsIgnoreCase("csv")) {
/* 157 */       OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(paramOutputStream, "GBK");
/*     */ 
/* 160 */       ExportUtil.outputHeaders(localList, localOutputStreamWriter);
/*     */ 
/* 163 */       if (localObject != null) {
/* 164 */         ExportUtil.outputColumns(localList, ((DataStore)localObject).getRowDatas(), 
/* 165 */           localOutputStreamWriter);
/*     */       }
/*     */ 
/* 169 */       if (localDataStore1 != null) {
/* 170 */         ExportUtil.outputColumns(localList, 
/* 171 */           localDataStore1.getRowDatas(), localOutputStreamWriter);
/*     */       }
/*     */ 
/* 175 */       ExportUtil.outputFooter(str2, localOutputStreamWriter);
/*     */ 
/* 177 */       localOutputStreamWriter.close();
/*     */     } else {
/* 179 */       ExportUtil.exportExcel(localList, (DataStore)localObject, localDataStore1, str2, 
/* 180 */         paramOutputStream, paramString);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.GridExport
 * JD-Core Version:    0.6.2
 */