package com.neusoft.unieap.techcomp.ria.export.dao;

import com.neusoft.unieap.techcomp.ria.export.entity.GridExportConfig;

public abstract interface GridExportDAO
{
  public abstract String getExportConfig(String paramString1, String paramString2, String paramString3);

  public abstract void saveExportConfig(GridExportConfig paramGridExportConfig);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.export.dao.GridExportDAO
 * JD-Core Version:    0.6.2
 */