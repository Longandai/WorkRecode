package com.neusoft.unieap.techcomp.ria.help.bo;

import com.neusoft.unieap.techcomp.ria.help.entity.HelptipCase;
import java.util.List;

public abstract interface HelptipCaseBO
{
  public abstract HelptipCase queryHelptipCase(String paramString);

  public abstract List<HelptipCase> queryMenuAllHelptipCase(String paramString);

  public abstract HelptipCase saveHelptipCase(HelptipCase paramHelptipCase);

  public abstract void deleteHelptipCase(String paramString);

  public abstract void updateHelptipCase(HelptipCase paramHelptipCase);

  public abstract void swapHelptipCaseIndex(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2);

  public abstract List<HelptipCase> updateHelptipCaseIndex(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2, String paramString, boolean paramBoolean);

  public abstract HelptipCase updateCopyHelptipCase(HelptipCase paramHelptipCase, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.HelptipCaseBO
 * JD-Core Version:    0.6.2
 */