/*     */ package com.neusoft.unieap.techcomp.ria.help.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.form.Form;
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.techcomp.ria.help.bo.HelptipBO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.Helptip;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("helptipBO.bo")
/*     */ public class HelptipBOImpl
/*     */   implements HelptipBO
/*     */ {
/*     */   private HelptipDAO helptipDAO;
/*     */ 
/*     */   public void setHelptipDAO(HelptipDAO paramHelptipDAO)
/*     */   {
/*  27 */     this.helptipDAO = paramHelptipDAO;
/*     */   }
/*     */ 
/*     */   public List<Helptip> getAllTipsByCaseId(String paramString) {
/*  31 */     List localList = this.helptipDAO.getAllTipsByCaseId(paramString);
/*  32 */     return localList;
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateTipsByCaseId(String paramString, List<Helptip> paramList) {
/*  36 */     this.helptipDAO.deleteAllTipsByCaseId(paramString);
/*  37 */     this.helptipDAO.saveOrUpdateTipsByCaseId(paramList);
/*     */   }
/*     */ 
/*     */   public Helptip saveOrUpdateHelptip(Helptip paramHelptip) {
/*  41 */     return this.helptipDAO.saveOrUpdateHelptip(paramHelptip);
/*     */   }
/*     */ 
/*     */   public void deleteHelptip(Helptip paramHelptip) {
/*  45 */     this.helptipDAO.deleteHelptip(paramHelptip);
/*     */   }
/*     */ 
/*     */   public void updateHelptipIndex(Helptip paramHelptip1, Helptip paramHelptip2) {
/*  49 */     BigDecimal localBigDecimal = paramHelptip2.getTipIndex();
/*  50 */     paramHelptip2.setTipIndex(paramHelptip1.getTipIndex());
/*  51 */     paramHelptip1.setTipIndex(localBigDecimal);
/*  52 */     this.helptipDAO.updateHelptipIndex(paramHelptip1);
/*  53 */     this.helptipDAO.updateHelptipIndex(paramHelptip2);
/*     */   }
/*     */ 
/*     */   public List<Helptip> updateHelptipIndex(Helptip paramHelptip1, Helptip paramHelptip2, String paramString, boolean paramBoolean) {
/*  57 */     ArrayList localArrayList = new ArrayList();
/*  58 */     localArrayList.add(paramHelptip2);
/*  59 */     localArrayList.add(paramHelptip1);
/*     */     BigDecimal localBigDecimal;
/*  60 */     if ("T".equals(paramHelptip1.getIsStart())) {
/*  61 */       localBigDecimal = this.helptipDAO.getMinTipIndexByCaseId(paramHelptip2.getCaseid());
/*  62 */       if (localBigDecimal != null)
/*  63 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(localBigDecimal.intValue() - 1));
/*     */       else
/*  65 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(1L));
/*     */     }
/*  67 */     else if ("T".equals(paramHelptip1.getIsEnd())) {
/*  68 */       localBigDecimal = this.helptipDAO.getMaxTipIndexByCaseId(paramHelptip2.getCaseid());
/*  69 */       if (localBigDecimal != null)
/*  70 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(localBigDecimal.intValue() + 1));
/*     */       else
/*  72 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(1L));
/*     */     }
/*     */     else {
/*  75 */       int i = paramHelptip1.getTipIndex().intValue();
/*     */       List localList;
/*     */       Iterator localIterator;
/*     */       Helptip localHelptip;
/*  76 */       if ("After".equalsIgnoreCase(paramString)) {
/*  77 */         localList = this.helptipDAO.getHelptips4AfterIndex(paramHelptip1);
/*  78 */         for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptip = (Helptip)localIterator.next();
/*  79 */           if ((!"T".equals(localHelptip.getIsStart())) && (!"T".equals(localHelptip.getIsEnd())) && (!localHelptip.getId().equals(paramHelptip2.getId()))) {
/*  80 */             localHelptip.setTipIndex(BigDecimal.valueOf(localHelptip.getTipIndex().intValue() + 1));
/*  81 */             this.helptipDAO.updateHelptipIndex(localHelptip);
/*  82 */             localArrayList.add(localHelptip);
/*     */           }
/*     */         }
/*  85 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(i + 1));
/*     */       } else {
/*  87 */         localList = this.helptipDAO.getHelptips4BeforeIndex(paramHelptip1);
/*  88 */         for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptip = (Helptip)localIterator.next();
/*  89 */           if ((!"T".equals(localHelptip.getIsStart())) && (!"T".equals(localHelptip.getIsEnd())) && (!localHelptip.getId().equals(paramHelptip2.getId()))) {
/*  90 */             localHelptip.setTipIndex(BigDecimal.valueOf(localHelptip.getTipIndex().intValue() - 1));
/*  91 */             this.helptipDAO.updateHelptipIndex(localHelptip);
/*  92 */             localArrayList.add(localHelptip);
/*     */           }
/*     */         }
/*  95 */         paramHelptip2.setTipIndex(BigDecimal.valueOf(i - 1));
/*     */       }
/*     */     }
/*  98 */     if (paramBoolean)
/*     */     {
/* 111 */       this.helptipDAO.saveHelptip(paramHelptip2);
/* 112 */       return localArrayList;
/*     */     }
/* 114 */     this.helptipDAO.updateHelptipIndex(paramHelptip2);
/* 115 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public Helptip updateHelptip(Helptip paramHelptip)
/*     */   {
/* 120 */     return this.helptipDAO.updateHelptip(paramHelptip);
/*     */   }
/*     */ 
/*     */   public void saveImageData(String paramString, Form paramForm) {
/* 124 */     byte[] arrayOfByte = (paramForm.getFiles() != null) && (paramForm.getFiles().size() == 1) ? ((FileAttachment)paramForm.getFiles().get(0)).getBytes() : null;
/* 125 */     this.helptipDAO.saveImageData(paramString, arrayOfByte);
/*     */   }
/*     */ 
/*     */   public void updateCopyCaseTips(String paramString1, String paramString2) {
/* 129 */     this.helptipDAO.updateCopyCaseTips(paramString1, paramString2);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.impl.HelptipBOImpl
 * JD-Core Version:    0.6.2
 */