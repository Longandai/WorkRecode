package com.neusoft.unieap.techcomp.ria.help.bo;

import java.util.List;

public abstract interface HelpImgPickerBO
{
  public abstract String getProjPath();

  public abstract List<?> getChildFilesByFolder(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.HelpImgPickerBO
 * JD-Core Version:    0.6.2
 */