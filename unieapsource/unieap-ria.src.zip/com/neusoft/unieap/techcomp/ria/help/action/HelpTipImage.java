/*    */ package com.neusoft.unieap.techcomp.ria.help.action;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipDAO;
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.interceptor.ServletRequestAware;
/*    */ import org.apache.struts2.interceptor.ServletResponseAware;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class HelpTipImage extends ActionSupport
/*    */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*    */ {
/*    */   private static final long serialVersionUID = -2567572777614918328L;
/*    */   private String id;
/*    */   private HelptipDAO dao;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 38 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 42 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setDao(HelptipDAO paramHelptipDAO) {
/* 46 */     this.dao = paramHelptipDAO;
/*    */   }
/*    */ 
/*    */   public HelptipDAO getDao() {
/* 50 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
/* 54 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 58 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 63 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   public String getHelpTipImageById() {
/*    */     try {
/* 68 */       ServletOutputStream localServletOutputStream = this.response.getOutputStream();
/* 69 */       byte[] arrayOfByte = this.dao.getImageData(getId());
/* 70 */       if (arrayOfByte != null)
/* 71 */         localServletOutputStream.write(arrayOfByte);
/*    */     }
/*    */     catch (Exception localException) {
/* 74 */       localException.printStackTrace();
/*    */     }
/* 76 */     return "none";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.action.HelpTipImage
 * JD-Core Version:    0.6.2
 */