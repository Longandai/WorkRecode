package com.neusoft.unieap.techcomp.ria.help.dao;

import com.neusoft.unieap.techcomp.ria.help.entity.Helptip;
import java.math.BigDecimal;
import java.util.List;

public abstract interface HelptipDAO
{
  public abstract List<Helptip> getAllTipsByCaseId(String paramString);

  public abstract void saveOrUpdateTipsByCaseId(List<Helptip> paramList);

  public abstract void deleteAllTipsByCaseId(String paramString);

  public abstract Helptip saveOrUpdateHelptip(Helptip paramHelptip);

  public abstract void deleteHelptip(Helptip paramHelptip);

  public abstract Helptip updateHelptip(Helptip paramHelptip);

  public abstract void updateHelptipIndex(Helptip paramHelptip);

  public abstract List<Helptip> getHelptips4AfterIndex(Helptip paramHelptip);

  public abstract List<Helptip> getHelptips4BeforeIndex(Helptip paramHelptip);

  public abstract BigDecimal getMaxTipIndexByCaseId(String paramString);

  public abstract BigDecimal getMinTipIndexByCaseId(String paramString);

  public abstract Helptip saveHelptip(Helptip paramHelptip);

  public abstract byte[] getImageData(String paramString);

  public abstract void saveImageData(String paramString, byte[] paramArrayOfByte);

  public abstract void updateCopyCaseTips(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.HelptipDAO
 * JD-Core Version:    0.6.2
 */