/*     */ package com.neusoft.unieap.techcomp.ria.help.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.Helptip;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.HelptipImage;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.List;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("helptipDAO.dao")
/*     */ public class HelptipDAOImpl extends BaseHibernateDAO
/*     */   implements HelptipDAO
/*     */ {
/*     */   public List<Helptip> getAllTipsByCaseId(String paramString)
/*     */   {
/*  24 */     String str = "from Helptip helpTip  where helpTip.caseid = ?";
/*  25 */     List localList = getHibernateTemplate().find(str, paramString);
/*  26 */     return localList;
/*     */   }
/*     */ 
/*     */   public BigDecimal getMaxTipIndexByCaseId(String paramString)
/*     */   {
/*  31 */     String str = "select Max(helpTip.tipIndex) from Helptip helpTip  where helpTip.caseid = ? and (helpTip.isEnd ='F' or helpTip.isEnd is null) and (helpTip.isStart ='F' or helpTip.isStart is null)";
/*  32 */     List localList = getHibernateTemplate().find(str, paramString);
/*  33 */     return (BigDecimal)localList.get(0);
/*     */   }
/*     */ 
/*     */   public BigDecimal getMinTipIndexByCaseId(String paramString) {
/*  37 */     String str = "select Min(helpTip.tipIndex) from Helptip helpTip  where helpTip.caseid = ? and (helpTip.isEnd ='F' or helpTip.isEnd is null) and (helpTip.isStart ='F' or helpTip.isStart is null)";
/*  38 */     List localList = getHibernateTemplate().find(str, paramString);
/*  39 */     return (BigDecimal)localList.get(0);
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateTipsByCaseId(List<Helptip> paramList) {
/*  43 */     for (Helptip localHelptip : paramList)
/*  44 */       getHibernateTemplate().save(localHelptip);
/*     */   }
/*     */ 
/*     */   public Helptip saveHelptip(Helptip paramHelptip)
/*     */   {
/*  49 */     getHibernateTemplate().save(paramHelptip);
/*  50 */     return paramHelptip;
/*     */   }
/*     */ 
/*     */   public void deleteAllTipsByCaseId(String paramString) {
/*  54 */     String str = "delete from Helptip helpTip  where helpTip.caseid = ?";
/*  55 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public Helptip saveOrUpdateHelptip(Helptip paramHelptip) {
/*  59 */     if ((!"T".equals(paramHelptip.getIsStart())) && (!"T".equals(paramHelptip.getIsEnd()))) {
/*  60 */       BigDecimal localBigDecimal = getMaxTipIndexByCaseId(paramHelptip.getCaseid());
/*  61 */       if (localBigDecimal == null)
/*  62 */         paramHelptip.setTipIndex(BigDecimal.valueOf(0L));
/*     */       else
/*  64 */         paramHelptip.setTipIndex(BigDecimal.valueOf(localBigDecimal.floatValue() + 1.0F));
/*     */     }
/*     */     else {
/*  67 */       paramHelptip.setTipIndex(BigDecimal.valueOf(0L));
/*     */     }
/*  69 */     getHibernateTemplate().save(paramHelptip);
/*  70 */     return paramHelptip;
/*     */   }
/*     */ 
/*     */   public void deleteHelptip(Helptip paramHelptip) {
/*  74 */     getHibernateTemplate().delete(paramHelptip);
/*     */   }
/*     */ 
/*     */   public Helptip updateHelptip(Helptip paramHelptip)
/*     */   {
/*  79 */     getHibernateTemplate().update(paramHelptip);
/*  80 */     return paramHelptip;
/*     */   }
/*     */ 
/*     */   public void updateHelptipIndex(Helptip paramHelptip) {
/*  84 */     String str = "update Helptip helpTip set helpTip.tipIndex =? where helpTip.id = ?";
/*  85 */     getHibernateTemplate().bulkUpdate(str, new Object[] { paramHelptip.getTipIndex(), paramHelptip.getId() });
/*     */   }
/*     */ 
/*     */   public List<Helptip> getHelptips4AfterIndex(Helptip paramHelptip) {
/*  89 */     String str = "from Helptip helpTip where helpTip.caseid = ? and helpTip.tipIndex > ?  and (helpTip.isEnd ='F' or helpTip.isEnd is null) and (helpTip.isStart ='F' or helpTip.isStart is null)";
/*  90 */     List localList = getHibernateTemplate().find(str, new Object[] { paramHelptip.getCaseid(), paramHelptip.getTipIndex() });
/*  91 */     return localList;
/*     */   }
/*     */ 
/*     */   public List<Helptip> getHelptips4BeforeIndex(Helptip paramHelptip) {
/*  95 */     String str = "from Helptip helpTip where helpTip.caseid = ? and helpTip.tipIndex < ?  and (helpTip.isEnd ='F' or helpTip.isEnd is null) and (helpTip.isStart ='F' or helpTip.isStart is null)";
/*  96 */     List localList = getHibernateTemplate().find(str, new Object[] { paramHelptip.getCaseid(), paramHelptip.getTipIndex() });
/*  97 */     return localList;
/*     */   }
/*     */ 
/*     */   public byte[] getImageData(String paramString) {
/* 101 */     byte[] arrayOfByte = (byte[])null;
/*     */ 
/* 103 */     String str = "from HelptipImage image where image.helptip.id = ?";
/* 104 */     List localList = getHibernateTemplate().find(str, paramString);
/*     */ 
/* 106 */     if (localList.size() == 1) {
/* 107 */       HelptipImage localHelptipImage = (HelptipImage)localList.get(0);
/* 108 */       arrayOfByte = localHelptipImage.getImageData();
/*     */     }
/*     */ 
/* 111 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   public void saveImageData(String paramString, byte[] paramArrayOfByte) {
/* 115 */     String str = "from HelptipImage image where image.helptip.id = ?";
/* 116 */     List localList = getHibernateTemplate().find(str, paramString);
/*     */     HelptipImage localHelptipImage;
/* 118 */     if (localList.size() == 0) {
/* 119 */       localHelptipImage = new HelptipImage();
/*     */ 
/* 121 */       Helptip localHelptip = new Helptip();
/* 122 */       localHelptip.setId(paramString);
/* 123 */       localHelptipImage.setHelptip(localHelptip);
/*     */ 
/* 125 */       localHelptipImage.setImageData(paramArrayOfByte);
/*     */ 
/* 127 */       getHibernateTemplate().save(localHelptipImage);
/*     */ 
/* 129 */       updateHasImage(paramString, paramArrayOfByte != null);
/* 130 */     } else if (localList.size() == 1) {
/* 131 */       localHelptipImage = (HelptipImage)localList.get(0);
/*     */ 
/* 133 */       localHelptipImage.setImageData(paramArrayOfByte);
/*     */ 
/* 135 */       getHibernateTemplate().save(localHelptipImage);
/*     */ 
/* 137 */       updateHasImage(paramString, paramArrayOfByte != null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateHasImage(String paramString, boolean paramBoolean) {
/* 142 */     String str = "from Helptip helptip where helptip.id = ?";
/* 143 */     List localList = getHibernateTemplate().find(str, paramString);
/*     */ 
/* 145 */     if (localList.size() == 1) {
/* 146 */       Helptip localHelptip = (Helptip)localList.get(0);
/*     */ 
/* 148 */       if (paramBoolean)
/* 149 */         localHelptip.setHasImage("T");
/*     */       else {
/* 151 */         localHelptip.setHasImage("F");
/*     */       }
/*     */ 
/* 154 */       getHibernateTemplate().save(localHelptip);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateCopyCaseTips(String paramString1, String paramString2) {
/* 159 */     List localList = getAllTipsByCaseId(paramString1);
/*     */ 
/* 161 */     for (Helptip localHelptip : localList) {
/* 162 */       getHibernateTemplate().evict(localHelptip);
/* 163 */       String str1 = localHelptip.getId();
/* 164 */       localHelptip.setId(null);
/* 165 */       localHelptip.setCaseid(paramString2);
/* 166 */       getHibernateTemplate().save(localHelptip);
/* 167 */       String str2 = localHelptip.getId();
/* 168 */       updateCopyCaseImage(str1, str2);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void updateCopyCaseImage(String paramString1, String paramString2) {
/* 173 */     String str = "from HelptipImage image where image.helptip.id = ?";
/* 174 */     List localList = getHibernateTemplate().find(str, paramString1);
/* 175 */     if (localList.size() == 1) {
/* 176 */       HelptipImage localHelptipImage = (HelptipImage)localList.get(0);
/* 177 */       saveImageData(paramString2, localHelptipImage.getImageData());
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.impl.HelptipDAOImpl
 * JD-Core Version:    0.6.2
 */