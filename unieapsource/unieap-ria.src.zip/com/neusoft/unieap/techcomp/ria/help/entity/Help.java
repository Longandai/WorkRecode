/*    */ package com.neusoft.unieap.techcomp.ria.help.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("help.entity")
/*    */ public class Help
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String helpContent;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 21 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 25 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setHelpContent(String paramString) {
/* 29 */     this.helpContent = paramString;
/*    */   }
/*    */ 
/*    */   public String getHelpContent() {
/* 33 */     return this.helpContent;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.entity.Help
 * JD-Core Version:    0.6.2
 */