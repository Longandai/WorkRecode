/*    */ package com.neusoft.unieap.techcomp.ria.help.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipCaseDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.entity.HelptipCase;
/*    */ import java.math.BigDecimal;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("helptipCaseDAO.dao")
/*    */ public class HelptipCaseDAOImpl extends BaseHibernateDAO
/*    */   implements HelptipCaseDAO
/*    */ {
/*    */   public HelptipCase queryHelptipCase(String paramString)
/*    */   {
/* 23 */     String str = "from HelptipCase helptipCase  where helptipCase.id = ?";
/* 24 */     List localList = getHibernateTemplate().find(str, paramString);
/* 25 */     if ((localList != null) && (localList.size() > 1)) {
/* 26 */       return (HelptipCase)localList.get(0);
/*    */     }
/* 28 */     return null;
/*    */   }
/*    */ 
/*    */   public List<HelptipCase> queryMenuAllHelptipCase(String paramString) {
/* 32 */     String str = "from HelptipCase helptipCase where helptipCase.menuid = ? order by helptipCase.caseIndex";
/* 33 */     List localList = getHibernateTemplate().find(str, paramString);
/* 34 */     return localList;
/*    */   }
/*    */ 
/*    */   public HelptipCase saveHelptipCase(HelptipCase paramHelptipCase) {
/* 38 */     String str = "select c from HelptipCase c where c.caseIndex = (select max(cc.caseIndex) from HelptipCase cc where cc.menuid = ?)";
/* 39 */     List localList = getHibernateTemplate().find(str, paramHelptipCase.getMenuid());
/*    */ 
/* 41 */     if (localList.size() == 1)
/* 42 */       paramHelptipCase.setCaseIndex(((HelptipCase)localList.get(0)).getCaseIndex().add(BigDecimal.ONE));
/*    */     else {
/* 44 */       paramHelptipCase.setCaseIndex(BigDecimal.ONE);
/*    */     }
/*    */ 
/* 47 */     getHibernateTemplate().save(paramHelptipCase);
/* 48 */     return paramHelptipCase;
/*    */   }
/*    */ 
/*    */   public void deleteHelptipCase(String paramString) {
/* 52 */     String str = "delete from HelptipCase helptipCase where helptipCase.id = ?";
/* 53 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*    */   }
/*    */ 
/*    */   public void deleteHelptipByCaseId(String paramString) {
/* 57 */     String str = "delete from Helptip helptip where helptip.caseid = ?";
/* 58 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*    */   }
/*    */ 
/*    */   public void updateHelptipCase(HelptipCase paramHelptipCase) {
/* 62 */     getHibernateTemplate().update(paramHelptipCase);
/*    */   }
/*    */ 
/*    */   public List<HelptipCase> getAllHelpTipCaseAfter(HelptipCase paramHelptipCase) {
/* 66 */     String str = "from HelptipCase helptipCase where helptipCase.menuid = ? and helptipCase.caseIndex > ?";
/* 67 */     return getHibernateTemplate().find(str, new Object[] { paramHelptipCase.getMenuid(), paramHelptipCase.getCaseIndex() });
/*    */   }
/*    */ 
/*    */   public List<HelptipCase> getAllHelpTipCaseBefore(HelptipCase paramHelptipCase) {
/* 71 */     String str = "from HelptipCase helptipCase where helptipCase.menuid = ? and helptipCase.caseIndex < ?";
/* 72 */     return getHibernateTemplate().find(str, new Object[] { paramHelptipCase.getMenuid(), paramHelptipCase.getCaseIndex() });
/*    */   }
/*    */ 
/*    */   public List<HelptipCase> getAllHelpTipCaseBetween(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2)
/*    */   {
/* 77 */     int i = paramHelptipCase1.getCaseIndex().intValue();
/* 78 */     int j = paramHelptipCase2.getCaseIndex().intValue();
/*    */ 
/* 80 */     if (i > j) {
/* 81 */       int k = i;
/* 82 */       i = j;
/* 83 */       j = k;
/*    */     }
/*    */ 
/* 86 */     String str = "from HelptipCase helptipCase where helptipCase.menuid = ? and helptipCase.caseIndex > ? and helptipCase.caseIndex < ?";
/* 87 */     return getHibernateTemplate().find(str, new Object[] { paramHelptipCase1.getMenuid(), BigDecimal.valueOf(i), BigDecimal.valueOf(j) });
/*    */   }
/*    */ 
/*    */   public void mergeHelptipCase(HelptipCase paramHelptipCase) {
/* 91 */     getHibernateTemplate().merge(paramHelptipCase);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.impl.HelptipCaseDAOImpl
 * JD-Core Version:    0.6.2
 */