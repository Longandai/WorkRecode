/*     */ package com.neusoft.unieap.techcomp.ria.help.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ 
/*     */ @ModelFile("helptip.entity")
/*     */ public class Helptip
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String noderefid;
/*     */   private String title;
/*     */   private String content;
/*     */   private String imgWidth;
/*     */   private String isBind;
/*     */   private String isSkip;
/*     */   private String isDialog;
/*     */   private String isTab;
/*     */   private String createdBy;
/*     */   private Date creationDate;
/*     */   private String isData;
/*     */   private String hasImage;
/*     */   private String lastUpdatedBy;
/*     */   private Date lastUpdateDate;
/*     */   private String isCloseDialog;
/*     */   private String caseid;
/*     */   private String helpData;
/*     */   private String imgHeight;
/*     */   private String position;
/*     */   private String isStart;
/*     */   private String isEnd;
/*     */   private String isAuto;
/*     */   private String isNoderef;
/*     */   private String controlType;
/*     */   private BigDecimal tipIndex;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/* 145 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 149 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setNoderefid(String paramString) {
/* 153 */     this.noderefid = paramString;
/*     */   }
/*     */ 
/*     */   public String getNoderefid() {
/* 157 */     return this.noderefid;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/* 161 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/* 165 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setContent(String paramString) {
/* 169 */     this.content = paramString;
/*     */   }
/*     */ 
/*     */   public String getContent() {
/* 173 */     return this.content;
/*     */   }
/*     */ 
/*     */   public void setImgWidth(String paramString) {
/* 177 */     this.imgWidth = paramString;
/*     */   }
/*     */ 
/*     */   public String getImgWidth() {
/* 181 */     return this.imgWidth;
/*     */   }
/*     */ 
/*     */   public void setIsBind(String paramString) {
/* 185 */     this.isBind = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsBind() {
/* 189 */     return this.isBind;
/*     */   }
/*     */ 
/*     */   public void setIsSkip(String paramString) {
/* 193 */     this.isSkip = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsSkip() {
/* 197 */     return this.isSkip;
/*     */   }
/*     */ 
/*     */   public void setIsDialog(String paramString) {
/* 201 */     this.isDialog = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsDialog() {
/* 205 */     return this.isDialog;
/*     */   }
/*     */ 
/*     */   public void setIsTab(String paramString) {
/* 209 */     this.isTab = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsTab() {
/* 213 */     return this.isTab;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 217 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/* 221 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date paramDate) {
/* 225 */     this.creationDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/* 229 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setIsData(String paramString) {
/* 233 */     this.isData = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsData() {
/* 237 */     return this.isData;
/*     */   }
/*     */ 
/*     */   public void setHasImage(String paramString) {
/* 241 */     this.hasImage = paramString;
/*     */   }
/*     */ 
/*     */   public String getHasImage() {
/* 245 */     return this.hasImage;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 249 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/* 253 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Date paramDate) {
/* 257 */     this.lastUpdateDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getLastUpdateDate() {
/* 261 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setIsCloseDialog(String paramString) {
/* 265 */     this.isCloseDialog = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsCloseDialog() {
/* 269 */     return this.isCloseDialog;
/*     */   }
/*     */ 
/*     */   public void setCaseid(String paramString) {
/* 273 */     this.caseid = paramString;
/*     */   }
/*     */ 
/*     */   public String getCaseid() {
/* 277 */     return this.caseid;
/*     */   }
/*     */ 
/*     */   public void setHelpData(String paramString) {
/* 281 */     this.helpData = paramString;
/*     */   }
/*     */ 
/*     */   public String getHelpData() {
/* 285 */     return this.helpData;
/*     */   }
/*     */ 
/*     */   public void setImgHeight(String paramString) {
/* 289 */     this.imgHeight = paramString;
/*     */   }
/*     */ 
/*     */   public String getImgHeight() {
/* 293 */     return this.imgHeight;
/*     */   }
/*     */ 
/*     */   public void setPosition(String paramString) {
/* 297 */     this.position = paramString;
/*     */   }
/*     */ 
/*     */   public String getPosition() {
/* 301 */     return this.position;
/*     */   }
/*     */ 
/*     */   public void setIsStart(String paramString) {
/* 305 */     this.isStart = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsStart() {
/* 309 */     return this.isStart;
/*     */   }
/*     */ 
/*     */   public void setIsEnd(String paramString) {
/* 313 */     this.isEnd = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsEnd() {
/* 317 */     return this.isEnd;
/*     */   }
/*     */ 
/*     */   public void setIsAuto(String paramString) {
/* 321 */     this.isAuto = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsAuto() {
/* 325 */     return this.isAuto;
/*     */   }
/*     */ 
/*     */   public void setIsNoderef(String paramString) {
/* 329 */     this.isNoderef = paramString;
/*     */   }
/*     */ 
/*     */   public String getIsNoderef() {
/* 333 */     return this.isNoderef;
/*     */   }
/*     */ 
/*     */   public void setControlType(String paramString) {
/* 337 */     this.controlType = paramString;
/*     */   }
/*     */ 
/*     */   public String getControlType() {
/* 341 */     return this.controlType;
/*     */   }
/*     */ 
/*     */   public void setTipIndex(BigDecimal paramBigDecimal) {
/* 345 */     this.tipIndex = paramBigDecimal;
/*     */   }
/*     */ 
/*     */   public BigDecimal getTipIndex() {
/* 349 */     return this.tipIndex;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.entity.Helptip
 * JD-Core Version:    0.6.2
 */