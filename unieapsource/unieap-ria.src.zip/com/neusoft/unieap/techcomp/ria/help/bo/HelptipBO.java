package com.neusoft.unieap.techcomp.ria.help.bo;

import com.neusoft.unieap.core.common.form.Form;
import com.neusoft.unieap.techcomp.ria.help.entity.Helptip;
import java.util.List;

public abstract interface HelptipBO
{
  public abstract List<Helptip> getAllTipsByCaseId(String paramString);

  public abstract void saveOrUpdateTipsByCaseId(String paramString, List<Helptip> paramList);

  public abstract Helptip saveOrUpdateHelptip(Helptip paramHelptip);

  public abstract void deleteHelptip(Helptip paramHelptip);

  public abstract void updateHelptipIndex(Helptip paramHelptip1, Helptip paramHelptip2);

  public abstract Helptip updateHelptip(Helptip paramHelptip);

  public abstract void saveImageData(String paramString, Form paramForm);

  public abstract List<Helptip> updateHelptipIndex(Helptip paramHelptip1, Helptip paramHelptip2, String paramString, boolean paramBoolean);

  public abstract void updateCopyCaseTips(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.HelptipBO
 * JD-Core Version:    0.6.2
 */