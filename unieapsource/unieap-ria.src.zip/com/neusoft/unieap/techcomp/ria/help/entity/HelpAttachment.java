/*    */ package com.neusoft.unieap.techcomp.ria.help.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("helpAttachment.entity")
/*    */ public class HelpAttachment
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String helpId;
/*    */   private byte[] content;
/*    */   private String fileName;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 31 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 35 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setHelpId(String paramString) {
/* 39 */     this.helpId = paramString;
/*    */   }
/*    */ 
/*    */   public String getHelpId() {
/* 43 */     return this.helpId;
/*    */   }
/*    */ 
/*    */   public void setContent(byte[] paramArrayOfByte) {
/* 47 */     this.content = paramArrayOfByte;
/*    */   }
/*    */ 
/*    */   public byte[] getContent() {
/* 51 */     return this.content;
/*    */   }
/*    */ 
/*    */   public void setFileName(String paramString) {
/* 55 */     this.fileName = paramString;
/*    */   }
/*    */ 
/*    */   public String getFileName() {
/* 59 */     return this.fileName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment
 * JD-Core Version:    0.6.2
 */