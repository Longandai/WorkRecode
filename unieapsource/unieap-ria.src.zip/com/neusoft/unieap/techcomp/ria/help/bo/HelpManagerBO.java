package com.neusoft.unieap.techcomp.ria.help.bo;

import com.neusoft.unieap.techcomp.ria.help.entity.Help;
import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
import java.util.List;

public abstract interface HelpManagerBO
{
  public abstract void saveOrUpdateHelpInfoByMenuId(String paramString1, String paramString2);

  public abstract Help getHelpInfoByMenuId(String paramString);

  public abstract List getAvailableMenusByAppId(String paramString);

  public abstract void saveOrUpdateAttachment(HelpAttachment paramHelpAttachment);

  public abstract HelpAttachment getAttachment(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.HelpManagerBO
 * JD-Core Version:    0.6.2
 */