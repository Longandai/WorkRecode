/*    */ package com.neusoft.unieap.techcomp.ria.help.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ import java.sql.Date;
/*    */ 
/*    */ @ModelFile("helptipImage.entity")
/*    */ public class HelptipImage
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String createdBy;
/*    */   private Date creationDate;
/*    */   private String lastUpdatedBy;
/*    */   private Date lastUpdateDate;
/*    */   private byte[] imageData;
/*    */   private Helptip helptip;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 45 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 49 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setCreatedBy(String paramString) {
/* 53 */     this.createdBy = paramString;
/*    */   }
/*    */ 
/*    */   public String getCreatedBy() {
/* 57 */     return this.createdBy;
/*    */   }
/*    */ 
/*    */   public void setCreationDate(Date paramDate) {
/* 61 */     this.creationDate = paramDate;
/*    */   }
/*    */ 
/*    */   public Date getCreationDate() {
/* 65 */     return this.creationDate;
/*    */   }
/*    */ 
/*    */   public void setLastUpdatedBy(String paramString) {
/* 69 */     this.lastUpdatedBy = paramString;
/*    */   }
/*    */ 
/*    */   public String getLastUpdatedBy() {
/* 73 */     return this.lastUpdatedBy;
/*    */   }
/*    */ 
/*    */   public void setLastUpdateDate(Date paramDate) {
/* 77 */     this.lastUpdateDate = paramDate;
/*    */   }
/*    */ 
/*    */   public Date getLastUpdateDate() {
/* 81 */     return this.lastUpdateDate;
/*    */   }
/*    */ 
/*    */   public void setImageData(byte[] paramArrayOfByte) {
/* 85 */     this.imageData = paramArrayOfByte;
/*    */   }
/*    */ 
/*    */   public byte[] getImageData() {
/* 89 */     return this.imageData;
/*    */   }
/*    */ 
/*    */   public void setHelptip(Helptip paramHelptip) {
/* 93 */     this.helptip = paramHelptip;
/*    */   }
/*    */ 
/*    */   public Helptip getHelptip() {
/* 97 */     return this.helptip;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.entity.HelptipImage
 * JD-Core Version:    0.6.2
 */