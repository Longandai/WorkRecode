package com.neusoft.unieap.techcomp.ria.help.dao;

import com.neusoft.unieap.techcomp.ria.help.entity.HelptipCase;
import java.util.List;

public abstract interface HelptipCaseDAO
{
  public abstract HelptipCase queryHelptipCase(String paramString);

  public abstract List<HelptipCase> queryMenuAllHelptipCase(String paramString);

  public abstract HelptipCase saveHelptipCase(HelptipCase paramHelptipCase);

  public abstract void deleteHelptipCase(String paramString);

  public abstract void deleteHelptipByCaseId(String paramString);

  public abstract void updateHelptipCase(HelptipCase paramHelptipCase);

  public abstract List<HelptipCase> getAllHelpTipCaseAfter(HelptipCase paramHelptipCase);

  public abstract List<HelptipCase> getAllHelpTipCaseBefore(HelptipCase paramHelptipCase);

  public abstract List<HelptipCase> getAllHelpTipCaseBetween(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2);

  public abstract void mergeHelptipCase(HelptipCase paramHelptipCase);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.HelptipCaseDAO
 * JD-Core Version:    0.6.2
 */