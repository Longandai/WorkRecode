package com.neusoft.unieap.techcomp.ria.help.dao;

import com.neusoft.unieap.techcomp.ria.help.entity.Help;
import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
import java.util.List;

public abstract interface HelpManagerDAO
{
  public abstract void saveOrUpdateHelpInfo(Help paramHelp);

  public abstract Help getHelpInfoByMenuId(String paramString);

  public abstract void saveOrUpdateAttachment(HelpAttachment paramHelpAttachment);

  public abstract HelpAttachment getAttachment(String paramString);

  public abstract void deleteHelpAttachmentsByIds(List<String> paramList, String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.HelpManagerDAO
 * JD-Core Version:    0.6.2
 */