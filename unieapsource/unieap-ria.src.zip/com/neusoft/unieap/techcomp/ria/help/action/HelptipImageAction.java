/*    */ package com.neusoft.unieap.techcomp.ria.help.action;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipDAO;
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.servlet.ServletContext;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.io.IOUtils;
/*    */ import org.apache.struts2.interceptor.ServletRequestAware;
/*    */ import org.apache.struts2.interceptor.ServletResponseAware;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class HelptipImageAction extends ActionSupport
/*    */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*    */ {
/*    */   private static final long serialVersionUID = -2567572777614918328L;
/*    */   private String id;
/*    */   private HelptipDAO dao;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 42 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 46 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setDao(HelptipDAO paramHelptipDAO) {
/* 50 */     this.dao = paramHelptipDAO;
/*    */   }
/*    */ 
/*    */   public HelptipDAO getDao() {
/* 54 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setServletRequest(HttpServletRequest paramHttpServletRequest) {
/* 58 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 62 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 67 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   public String getHelpTipImageById() {
/*    */     try {
/* 72 */       ServletOutputStream localServletOutputStream = this.response.getOutputStream();
/* 73 */       byte[] arrayOfByte = this.dao.getImageData(getId());
/* 74 */       if (arrayOfByte == null) {
/* 75 */         ServletContext localServletContext = this.request.getSession().getServletContext();
/* 76 */         String str1 = File.separator;
/* 77 */         String str2 = localServletContext.getRealPath(str1 + "techcomp" + str1 + "ria" + str1 + "unieap" + str1 + "themes" + str1 + "gainsboro" + str1 + "images" + str1 + "helpTip" + str1 + "holder.png");
/* 78 */         File localFile = new File(str2);
/* 79 */         if (localFile.exists()) localServletOutputStream.write(IOUtils.toByteArray(new FileInputStream(localFile))); 
/*    */       } else { localServletOutputStream.write(arrayOfByte); }
/*    */ 
/* 82 */       localServletOutputStream.close();
/*    */     } catch (Exception localException) {
/* 84 */       localException.printStackTrace();
/*    */     }
/* 86 */     return "none";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.action.HelptipImageAction
 * JD-Core Version:    0.6.2
 */