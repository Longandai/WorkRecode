/*     */ package com.neusoft.unieap.techcomp.ria.help.richEditorAction;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import com.neusoft.unieap.core.fileupload.impl.FileAttachmentImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.help.bo.HelpManagerBO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.RichEditorConfig;
/*     */ import com.neusoft.unieap.techcomp.ria.richeditor.impl.RichEditorUploadImpl;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class HelpAttachmentUpload extends RichEditorUploadImpl
/*     */ {
/*     */   HelpManagerBO helpManagerBO;
/*     */ 
/*     */   public void setHelpManagerBO(HelpManagerBO paramHelpManagerBO)
/*     */   {
/*  29 */     this.helpManagerBO = paramHelpManagerBO;
/*     */   }
/*     */ 
/*     */   public void upload(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */   {
/*  40 */     if (!(paramHttpServletRequest instanceof MultiPartRequestWrapper))
/*     */     {
/*  42 */       return;
/*     */     }
/*  44 */     paramHttpServletResponse.setHeader("Cache-Control", "no-cache");
/*     */ 
/*  46 */     String str1 = "";
/*  47 */     String str2 = "";
/*     */ 
/*  49 */     InputStream localInputStream = null;
/*  50 */     ByteArrayOutputStream localByteArrayOutputStream = null;
/*  51 */     PrintWriter localPrintWriter = null;
/*  52 */     MultiPartRequestWrapper localMultiPartRequestWrapper = (MultiPartRequestWrapper)paramHttpServletRequest;
/*     */     try {
/*  54 */       localPrintWriter = paramHttpServletResponse.getWriter();
/*     */     } catch (IOException localIOException1) {
/*  56 */       localIOException1.printStackTrace();
/*     */     }
/*     */     Object localObject1;
/*  58 */     if (localMultiPartRequestWrapper.hasErrors()) {
/*  59 */       handleError(localMultiPartRequestWrapper, paramString);
/*     */     } else {
/*  61 */       localObject1 = localMultiPartRequestWrapper
/*  62 */         .getFileParameterNames();
/*  63 */       ArrayList localArrayList = new ArrayList();
/*  64 */       if ((localObject1 != null) && 
/*  65 */         (((Enumeration)localObject1).hasMoreElements()))
/*     */       {
/*     */         int i;
/*  66 */         for (; ((Enumeration)localObject1).hasMoreElements(); 
/*  71 */           i < localObject3.length)
/*     */         {
/*  67 */           str3 = 
/*  68 */             (String)((Enumeration)localObject1)
/*  68 */             .nextElement();
/*  69 */           localObject2 = localMultiPartRequestWrapper.getFileNames(str3);
/*  70 */           localObject3 = localMultiPartRequestWrapper.getFiles(str3);
/*  71 */           i = 0; continue;
/*  72 */           if (localObject3[i].exists())
/*     */           {
/*     */             try {
/*  75 */               localObject4 = new FileAttachmentImpl(
/*  76 */                 str3, 
/*  77 */                 FileUtils.openInputStream(localObject3[i]), 
/*  78 */                 localObject3[i].length(), localObject2[i]);
/*  79 */               localArrayList.add(localObject4);
/*     */             } catch (IOException localIOException2) {
/*  81 */               localIOException2.printStackTrace();
/*     */             }
/*  83 */             localObject3[i].delete();
/*     */           }
/*  71 */           i++;
/*     */         }
/*     */ 
/*  87 */         paramHttpServletRequest.setAttribute("UNIEAP_FILEATTACHMENT", 
/*  88 */           localArrayList);
/*     */       }
/*     */ 
/*  91 */       String str3 = paramHttpServletRequest.getParameter("Type");
/*  92 */       Object localObject2 = paramHttpServletRequest.getParameter("number");
/*  93 */       Object localObject3 = this.config.getBaseDir() + str3;
/*  94 */       String str4 = paramHttpServletRequest.getSession().getServletContext()
/*  95 */         .getRealPath((String)localObject3);
/*  96 */       localObject3 = paramHttpServletRequest.getContextPath() + (String)localObject3;
/*  97 */       if (localObject2 != null) {
/*  98 */         str4 = str4 + "\\" + (String)localObject2;
/*  99 */         localObject3 = localObject3 + "/" + (String)localObject2;
/*     */       }
/* 101 */       Object localObject4 = System.getProperties().getProperty("os.name");
/* 102 */       if (!((String)localObject4).contains("Windows"))
/*     */       {
/* 104 */         str4 = str4.replace("/", File.separator);
/* 105 */         localObject3 = ((String)localObject3).replace("/", File.separator);
/*     */       }
/*     */       try {
/* 108 */         if ((localArrayList != null) && (localArrayList.size() > 0)) {
/* 109 */           FileAttachment localFileAttachment = 
/* 110 */             (FileAttachment)localArrayList
/* 110 */             .get(0);
/*     */           try {
/* 112 */             localInputStream = localFileAttachment.getInputStream();
/* 113 */             localByteArrayOutputStream = new ByteArrayOutputStream();
/*     */ 
/* 115 */             byte[] arrayOfByte1 = new byte[localInputStream.available()];
/*     */ 
/* 117 */             while (-1 != localInputStream.read(arrayOfByte1)) {
/* 118 */               localByteArrayOutputStream.write(arrayOfByte1);
/*     */             }
/*     */ 
/* 121 */             byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
/*     */ 
/* 123 */             HelpAttachment localHelpAttachment = new HelpAttachment();
/* 124 */             localHelpAttachment.setContent(arrayOfByte2);
/* 125 */             String str5 = paramHttpServletRequest.getParameter("uploadParameter").split(":")[1];
/* 126 */             localHelpAttachment.setHelpId(str5);
/* 127 */             localHelpAttachment.setFileName(localFileAttachment.getFileName());
/* 128 */             this.helpManagerBO.saveOrUpdateAttachment(localHelpAttachment);
/* 129 */             if (str3.equals("Image")) {
/* 130 */               str2 = "../../techcomp/ria/helpAttachmentDownload.action?id=" + 
/* 131 */                 localHelpAttachment.getId();
/*     */             }
/*     */             else
/*     */             {
/* 138 */               str2 = "/techcomp/ria/helpAttachmentDownload.action?id=" + 
/* 139 */                 localHelpAttachment.getId();
/*     */             }
/*     */ 
/* 142 */             localInputStream.close();
/* 143 */             localByteArrayOutputStream.close();
/*     */           } catch (Exception localException2) {
/* 145 */             localException2.printStackTrace();
/*     */           }
/*     */         }
/*     */       } catch (Exception localException1) {
/* 149 */         localException1.printStackTrace();
/*     */         try
/*     */         {
/* 153 */           if ((localInputStream != null) && (localByteArrayOutputStream != null)) {
/* 154 */             localInputStream.close();
/* 155 */             localByteArrayOutputStream.close();
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException3) {
/* 159 */           localIOException3.printStackTrace();
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 153 */           if ((localInputStream != null) && (localByteArrayOutputStream != null)) {
/* 154 */             localInputStream.close();
/* 155 */             localByteArrayOutputStream.close();
/*     */           }
/*     */         }
/*     */         catch (IOException localIOException4) {
/* 159 */           localIOException4.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 163 */     if (localPrintWriter != null)
/*     */     {
/* 165 */       localObject1 = ServletActionContext.getRequest().getParameter("CKEditorFuncNum");
/* 166 */       localPrintWriter.println("<script type=\"text/javascript\">");
/* 167 */       localPrintWriter.println("window.parent.CKEDITOR.tools.callFunction(" + (String)localObject1 + ",'" + str2 + str1 + "','')");
/* 168 */       localPrintWriter.println("</script>");
/* 169 */       localPrintWriter.flush();
/* 170 */       localPrintWriter.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.richEditorAction.HelpAttachmentUpload
 * JD-Core Version:    0.6.2
 */