/*     */ package com.neusoft.unieap.techcomp.ria.help.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.techcomp.ria.help.bo.HelpManagerBO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.dao.HelpManagerDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.Help;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import java.net.URLDecoder;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ 
/*     */ @ModelFile("helpManagerBO.bo")
/*     */ public class HelpManagerBOImpl
/*     */   implements HelpManagerBO
/*     */ {
/*     */   private HelpManagerDAO helpManagerDAO;
/*     */   private MenuBO menuBO;
/*     */   private MenuAuthBO menuAuthBO;
/*     */ 
/*     */   public void setHelpManagerDAO(HelpManagerDAO paramHelpManagerDAO)
/*     */   {
/*  35 */     this.helpManagerDAO = paramHelpManagerDAO;
/*     */   }
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO)
/*     */   {
/*  41 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public void setMenuAuthBO(MenuAuthBO paramMenuAuthBO)
/*     */   {
/*  47 */     this.menuAuthBO = paramMenuAuthBO;
/*     */   }
/*     */ 
/*     */   public Help getHelpInfoByMenuId(String paramString)
/*     */   {
/*  61 */     if (paramString == null) {
/*  62 */       throw new UniEAPBusinessException("EAPTECHHELP0001");
/*     */     }
/*  64 */     Help localHelp = this.helpManagerDAO.getHelpInfoByMenuId(paramString);
/*  65 */     if (localHelp != null) {
/*  66 */       String str1 = localHelp.getHelpContent();
/*  67 */       String str2 = ServletActionContext.getRequest()
/*  68 */         .getContextPath();
/*  69 */       String str3 = "$webAppPath$/UserFiles";
/*  70 */       String str4 = str2 + "/UserFiles";
/*  71 */       str1 = replace(str1, str3, str4);
/*  72 */       str3 = "$webAppPath$/unieap";
/*  73 */       str4 = str2 + "/unieap";
/*  74 */       str1 = replace(str1, str3, str4);
/*  75 */       localHelp.setHelpContent(str1);
/*     */     }
/*  77 */     return localHelp;
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateHelpInfoByMenuId(String paramString1, String paramString2)
/*     */   {
/*  84 */     if (paramString2 == null) {
/*  85 */       throw new UniEAPBusinessException("EAPTECHHELP0001");
/*     */     }
/*     */ 
/*  88 */     Help localHelp = new Help();
/*  89 */     localHelp.setId(paramString2);
/*  90 */     localHelp.setHelpContent(getChangedHelpInfo(paramString1));
/*  91 */     this.helpManagerDAO.saveOrUpdateHelpInfo(localHelp);
/*  92 */     List localList = getAttachmentIdsFromHelpContent(localHelp);
/*     */ 
/*  94 */     this.helpManagerDAO.deleteHelpAttachmentsByIds(localList, localHelp.getId());
/*     */   }
/*     */ 
/*     */   private String getChangedHelpInfo(String paramString) {
/*  98 */     HttpServletRequest localHttpServletRequest = ServletActionContext.getRequest();
/*  99 */     String str1 = localHttpServletRequest.getContextPath();
/* 100 */     String str2 = localHttpServletRequest.getScheme() + "://" + 
/* 101 */       localHttpServletRequest.getServerName() + ":" + 
/* 102 */       String.valueOf(localHttpServletRequest.getServerPort());
/*     */     try {
/* 104 */       paramString = URLDecoder.decode(paramString, "UTF-8");
/*     */     } catch (Exception localException) {
/* 106 */       throw new UniEAPBusinessException("EAPTECHHELP0002");
/*     */     }
/* 108 */     if (!paramString.equals("")) {
/* 109 */       String str3 = str1 + "/UserFiles";
/* 110 */       String str4 = "$webAppPath$/UserFiles";
/* 111 */       paramString = replace(paramString, str3, str4);
/* 112 */       str3 = str1 + "/unieap";
/* 113 */       str4 = "$webAppPath$/unieap";
/* 114 */       paramString = replace(paramString, str3, str4);
/* 115 */       str3 = str2;
/* 116 */       str4 = "";
/* 117 */       paramString = replace(paramString, str3, str4);
/*     */     }
/* 119 */     if (!paramString.equals("")) {
/* 120 */       int i = paramString.getBytes().length;
/* 121 */       if ((i >= 1000) && (i <= 2000))
/* 122 */         paramString = StringUtils.rightPad(paramString, 2002);
/*     */     }
/* 124 */     return paramString;
/*     */   }
/*     */ 
/*     */   private String replace(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 129 */     if (paramString1 == null) {
/* 130 */       return null;
/*     */     }
/* 132 */     if ((paramString2 == null) || (paramString2.equals(""))) {
/* 133 */       return paramString1;
/*     */     }
/* 135 */     if (paramString3 == null) {
/* 136 */       return paramString1;
/*     */     }
/* 138 */     String str = "";
/* 139 */     int i = paramString2.length();
/*     */     while (true) {
/* 141 */       int j = paramString1.indexOf(paramString2);
/* 142 */       if (j == -1) break;
/* 143 */       str = str + paramString1.substring(0, j) + paramString3;
/* 144 */       paramString1 = paramString1.substring(j + i);
/*     */     }
/*     */ 
/* 147 */     str = str + paramString1;
/*     */ 
/* 150 */     return str;
/*     */   }
/*     */ 
/*     */   public List getAvailableMenusByAppId(String paramString)
/*     */   {
/* 158 */     ArrayList localArrayList = new ArrayList();
/* 159 */     localArrayList.clear();
/* 160 */     List localList1 = this.menuBO.getRootMenusByAppId(paramString);
/* 161 */     List localList2 = this.menuAuthBO.getAllowedMenus(localList1);
/* 162 */     for (int i = 0; i < localList2.size(); i++) {
/* 163 */       Menu localMenu = (Menu)localList2.get(i);
/* 164 */       localArrayList.add(localMenu);
/* 165 */       List localList3 = this.menuBO.getAllDescendantMenusById(paramString, localMenu
/* 166 */         .getId());
/* 167 */       List localList4 = this.menuAuthBO.getAllowedMenus(localList3);
/* 168 */       localArrayList.addAll(localList4);
/*     */     }
/*     */ 
/* 171 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public HelpAttachment getAttachment(String paramString)
/*     */   {
/* 178 */     return this.helpManagerDAO.getAttachment(paramString);
/*     */   }
/*     */ 
/*     */   public void saveOrUpdateAttachment(HelpAttachment paramHelpAttachment)
/*     */   {
/* 185 */     this.helpManagerDAO.saveOrUpdateAttachment(paramHelpAttachment);
/*     */   }
/*     */ 
/*     */   private List<String> getAttachmentIdsFromHelpContent(Help paramHelp)
/*     */   {
/* 190 */     ArrayList localArrayList = new ArrayList();
/* 191 */     String str1 = "?id=";
/* 192 */     int i = 32;
/* 193 */     int j = str1.length();
/* 194 */     String str2 = paramHelp.getHelpContent();
/* 195 */     int k = str2.indexOf(str1);
/* 196 */     while (k != -1) {
/* 197 */       localArrayList.add(str2.substring(k + j, k + 
/* 198 */         j + i));
/* 199 */       str2 = str2.substring(k + j + i);
/* 200 */       k = str2.indexOf(str1);
/*     */     }
/* 202 */     return localArrayList;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.impl.HelpManagerBOImpl
 * JD-Core Version:    0.6.2
 */