/*     */ package com.neusoft.unieap.techcomp.ria.help.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.techcomp.ria.help.bo.HelptipBO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.bo.HelptipCaseBO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.dao.HelptipCaseDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.help.entity.HelptipCase;
/*     */ import java.math.BigDecimal;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("helptipCaseBO.bo")
/*     */ public class HelptipCaseBOImpl
/*     */   implements HelptipCaseBO
/*     */ {
/*     */   private HelptipCaseDAO helptipCaseDAO;
/*     */   private HelptipBO helptipBO;
/*     */ 
/*     */   public void setHelptipCaseDAO(HelptipCaseDAO paramHelptipCaseDAO)
/*     */   {
/*  28 */     this.helptipCaseDAO = paramHelptipCaseDAO;
/*     */   }
/*     */ 
/*     */   public void setHelptipBO(HelptipBO paramHelptipBO) {
/*  32 */     this.helptipBO = paramHelptipBO;
/*     */   }
/*     */ 
/*     */   public HelptipCase queryHelptipCase(String paramString) {
/*  36 */     return this.helptipCaseDAO.queryHelptipCase(paramString);
/*     */   }
/*     */ 
/*     */   public List<HelptipCase> queryMenuAllHelptipCase(String paramString) {
/*  40 */     return this.helptipCaseDAO.queryMenuAllHelptipCase(paramString);
/*     */   }
/*     */ 
/*     */   public HelptipCase saveHelptipCase(HelptipCase paramHelptipCase) {
/*  44 */     return this.helptipCaseDAO.saveHelptipCase(paramHelptipCase);
/*     */   }
/*     */ 
/*     */   public void deleteHelptipCase(String paramString) {
/*  48 */     this.helptipCaseDAO.deleteHelptipCase(paramString);
/*  49 */     this.helptipCaseDAO.deleteHelptipByCaseId(paramString);
/*     */   }
/*     */ 
/*     */   public void updateHelptipCase(HelptipCase paramHelptipCase) {
/*  53 */     this.helptipCaseDAO.updateHelptipCase(paramHelptipCase);
/*     */   }
/*     */ 
/*     */   public void swapHelptipCaseIndex(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2)
/*     */   {
/*  58 */     BigDecimal localBigDecimal = paramHelptipCase1.getCaseIndex();
/*  59 */     paramHelptipCase1.setCaseIndex(paramHelptipCase2.getCaseIndex());
/*  60 */     paramHelptipCase2.setCaseIndex(localBigDecimal);
/*     */ 
/*  62 */     this.helptipCaseDAO.updateHelptipCase(paramHelptipCase1);
/*  63 */     this.helptipCaseDAO.updateHelptipCase(paramHelptipCase2);
/*     */   }
/*     */ 
/*     */   public List<HelptipCase> updateHelptipCaseIndex(HelptipCase paramHelptipCase1, HelptipCase paramHelptipCase2, String paramString, boolean paramBoolean)
/*     */   {
/*  68 */     ArrayList localArrayList = new ArrayList();
/*     */     List localList;
/*     */     Iterator localIterator;
/*     */     HelptipCase localHelptipCase;
/*  70 */     if ("After".equalsIgnoreCase(paramString))
/*     */     {
/*  72 */       if (paramHelptipCase2.getCaseIndex().intValue() > paramHelptipCase1.getCaseIndex().intValue())
/*     */       {
/*  76 */         localList = this.helptipCaseDAO.getAllHelpTipCaseBetween(paramHelptipCase2, paramHelptipCase1);
/*  77 */         for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptipCase = (HelptipCase)localIterator.next();
/*  78 */           localHelptipCase.setCaseIndex(localHelptipCase.getCaseIndex().add(BigDecimal.ONE));
/*  79 */           this.helptipCaseDAO.updateHelptipCase(localHelptipCase);
/*     */ 
/*  81 */           localArrayList.add(localHelptipCase);
/*     */         }
/*     */ 
/*  85 */         paramHelptipCase2.setCaseIndex(paramHelptipCase1.getCaseIndex().add(BigDecimal.ONE));
/*     */       }
/*     */       else
/*     */       {
/*  90 */         localList = this.helptipCaseDAO.getAllHelpTipCaseBetween(paramHelptipCase2, paramHelptipCase1);
/*  91 */         for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptipCase = (HelptipCase)localIterator.next();
/*  92 */           localHelptipCase.setCaseIndex(localHelptipCase.getCaseIndex().subtract(BigDecimal.ONE));
/*  93 */           this.helptipCaseDAO.updateHelptipCase(localHelptipCase);
/*     */ 
/*  95 */           localArrayList.add(localHelptipCase);
/*     */         }
/*     */ 
/*  99 */         paramHelptipCase2.setCaseIndex(paramHelptipCase1.getCaseIndex());
/* 100 */         paramHelptipCase1.setCaseIndex(paramHelptipCase1.getCaseIndex().subtract(BigDecimal.ONE));
/*     */       }
/*     */ 
/*     */     }
/* 104 */     else if (paramHelptipCase2.getCaseIndex().intValue() > paramHelptipCase1.getCaseIndex().intValue())
/*     */     {
/* 108 */       localList = this.helptipCaseDAO.getAllHelpTipCaseBetween(paramHelptipCase2, paramHelptipCase1);
/* 109 */       for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptipCase = (HelptipCase)localIterator.next();
/* 110 */         localHelptipCase.setCaseIndex(localHelptipCase.getCaseIndex().add(BigDecimal.ONE));
/* 111 */         this.helptipCaseDAO.updateHelptipCase(localHelptipCase);
/*     */ 
/* 113 */         localArrayList.add(localHelptipCase);
/*     */       }
/*     */ 
/* 117 */       paramHelptipCase2.setCaseIndex(paramHelptipCase1.getCaseIndex());
/* 118 */       paramHelptipCase1.setCaseIndex(paramHelptipCase2.getCaseIndex().add(BigDecimal.ONE));
/*     */     }
/*     */     else
/*     */     {
/* 123 */       localList = this.helptipCaseDAO.getAllHelpTipCaseBetween(paramHelptipCase2, paramHelptipCase1);
/* 124 */       for (localIterator = localList.iterator(); localIterator.hasNext(); ) { localHelptipCase = (HelptipCase)localIterator.next();
/* 125 */         localHelptipCase.setCaseIndex(localHelptipCase.getCaseIndex().subtract(BigDecimal.ONE));
/* 126 */         this.helptipCaseDAO.updateHelptipCase(localHelptipCase);
/*     */ 
/* 128 */         localArrayList.add(localHelptipCase);
/*     */       }
/*     */ 
/* 132 */       paramHelptipCase2.setCaseIndex(paramHelptipCase1.getCaseIndex().subtract(BigDecimal.ONE));
/*     */     }
/*     */ 
/* 136 */     this.helptipCaseDAO.mergeHelptipCase(paramHelptipCase1);
/* 137 */     this.helptipCaseDAO.mergeHelptipCase(paramHelptipCase2);
/*     */ 
/* 139 */     localArrayList.add(paramHelptipCase1);
/* 140 */     localArrayList.add(paramHelptipCase2);
/*     */ 
/* 142 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public HelptipCase updateCopyHelptipCase(HelptipCase paramHelptipCase, String paramString) {
/* 146 */     HelptipCase localHelptipCase = null;
/*     */ 
/* 148 */     if (paramString != null) {
/* 149 */       String str = paramHelptipCase.getId();
/*     */ 
/* 152 */       paramHelptipCase.setId(null);
/* 153 */       paramHelptipCase.setMenuid(paramString);
/* 154 */       localHelptipCase = this.helptipCaseDAO.saveHelptipCase(paramHelptipCase);
/*     */ 
/* 157 */       this.helptipBO.updateCopyCaseTips(str, localHelptipCase.getId());
/*     */     }
/*     */ 
/* 160 */     return localHelptipCase;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.impl.HelptipCaseBOImpl
 * JD-Core Version:    0.6.2
 */