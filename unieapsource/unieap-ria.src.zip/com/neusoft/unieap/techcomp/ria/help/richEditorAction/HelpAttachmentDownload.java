/*    */ package com.neusoft.unieap.techcomp.ria.help.richEditorAction;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.help.bo.HelpManagerBO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.interceptor.ServletRequestAware;
/*    */ import org.apache.struts2.interceptor.ServletResponseAware;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class HelpAttachmentDownload extends ActionSupport
/*    */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*    */ {
/*    */   HelpManagerBO helpManagerBO;
/*    */   private static final long serialVersionUID = -5560721990786836931L;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public void setHelpManagerBO(HelpManagerBO paramHelpManagerBO)
/*    */   {
/* 27 */     this.helpManagerBO = paramHelpManagerBO;
/*    */   }
/*    */ 
/*    */   public void setServletRequest(HttpServletRequest paramHttpServletRequest)
/*    */   {
/* 47 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 51 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 56 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   public String download() {
/* 60 */     HelpAttachment localHelpAttachment = this.helpManagerBO.getAttachment(this.request
/* 61 */       .getParameter("id"));
/* 62 */     if (localHelpAttachment != null) {
/* 63 */       String str = localHelpAttachment.getFileName();
/* 64 */       if ((str == null) || (str.length() == 0)) {
/* 65 */         str = "downloadFile.tmp";
/*    */       }
/* 67 */       byte[] arrayOfByte = localHelpAttachment.getContent();
/* 68 */       this.response.setCharacterEncoding("UTF-8");
/* 69 */       this.response.setContentType("application/x-shockwave-flash; charset=UTF-8");
/*    */       try {
/* 71 */         str = URLEncoder.encode(str, "UTF-8");
/* 72 */         this.response.addHeader("Content-Disposition", 
/* 73 */           "attachment; filename=" + str);
/*    */       } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 75 */         localUnsupportedEncodingException.printStackTrace();
/*    */       }
/* 77 */       ServletOutputStream localServletOutputStream = null;
/*    */       try {
/* 79 */         localServletOutputStream = this.response.getOutputStream();
/* 80 */         localServletOutputStream.write(arrayOfByte);
/* 81 */         localServletOutputStream.close();
/*    */       } catch (IOException localIOException1) {
/* 83 */         if (localServletOutputStream != null) {
/*    */           try {
/* 85 */             localServletOutputStream.close();
/*    */           }
/*    */           catch (IOException localIOException2) {
/* 88 */             localIOException2.printStackTrace();
/*    */           }
/*    */         }
/* 91 */         localIOException1.printStackTrace();
/*    */       }
/*    */     }
/*    */ 
/* 95 */     return "none";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.richEditorAction.HelpAttachmentDownload
 * JD-Core Version:    0.6.2
 */