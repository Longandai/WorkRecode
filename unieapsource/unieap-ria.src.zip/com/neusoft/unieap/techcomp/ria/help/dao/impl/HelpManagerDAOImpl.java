/*    */ package com.neusoft.unieap.techcomp.ria.help.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.dao.HelpManagerDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.entity.Help;
/*    */ import com.neusoft.unieap.techcomp.ria.help.entity.HelpAttachment;
/*    */ import java.util.List;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("helpManagerDAO.dao")
/*    */ public class HelpManagerDAOImpl extends BaseHibernateDAO
/*    */   implements HelpManagerDAO
/*    */ {
/*    */   public Help getHelpInfoByMenuId(String paramString)
/*    */   {
/* 41 */     String str = "from Help help where help.id = ?";
/* 42 */     List localList = getHibernateTemplate().find(str, paramString);
/* 43 */     if ((localList != null) && (localList.size() > 0)) {
/* 44 */       return (Help)localList.get(0);
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public void saveOrUpdateHelpInfo(Help paramHelp)
/*    */   {
/* 53 */     getHibernateTemplate().saveOrUpdate(paramHelp);
/*    */   }
/*    */ 
/*    */   public void saveOrUpdateAttachment(HelpAttachment paramHelpAttachment)
/*    */   {
/* 60 */     getHibernateTemplate().saveOrUpdate(paramHelpAttachment);
/*    */   }
/*    */ 
/*    */   public void deleteHelpAttachmentsByIds(List<String> paramList, String paramString)
/*    */   {
/* 68 */     StringBuffer localStringBuffer = new StringBuffer();
/* 69 */     if ((paramList == null) || (paramList.size() == 0))
/* 70 */       localStringBuffer.append("delete from HelpAttachment h where h.helpId = ? ");
/*    */     else {
/* 72 */       localStringBuffer.append("delete from HelpAttachment h where h.helpId = ? and h.id not in (:ids) ");
/*    */     }
/* 74 */     Query localQuery = super.getSession().createQuery(localStringBuffer.toString());
/* 75 */     localQuery.setParameter(0, paramString);
/* 76 */     if ((paramList != null) && (paramList.size() > 0)) {
/* 77 */       localQuery.setParameterList("ids", paramList);
/*    */     }
/* 79 */     localQuery.executeUpdate();
/*    */   }
/*    */ 
/*    */   public HelpAttachment getAttachment(String paramString)
/*    */   {
/* 86 */     String str = "from HelpAttachment t where t.id = ?";
/* 87 */     List localList = queryObjects(str, paramString);
/* 88 */     if (localList.size() > 0)
/* 89 */       return (HelpAttachment)localList.get(0);
/* 90 */     return null;
/*    */   }
/*    */ 
/*    */   public void saveOrUpdateHelpAttachment(HelpAttachment paramHelpAttachment)
/*    */   {
/* 97 */     getHibernateTemplate().saveOrUpdate(paramHelpAttachment);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dao.impl.HelpManagerDAOImpl
 * JD-Core Version:    0.6.2
 */