/*    */ package com.neusoft.unieap.techcomp.ria.help.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*    */ import com.neusoft.unieap.techcomp.ria.help.bo.HelpImgPickerBO;
/*    */ import com.neusoft.unieap.techcomp.ria.help.dto.HelpImageDTO;
/*    */ import java.io.File;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ @ModelFile("helpImgPickerBO.bo")
/*    */ public class HelpImgPickerBOImpl
/*    */   implements HelpImgPickerBO
/*    */ {
/*    */   public String getProjPath()
/*    */   {
/* 23 */     String str = I18nGlobalContext.getInstance().getServletContext()
/* 24 */       .getRealPath(File.separator);
/* 25 */     return str;
/*    */   }
/*    */ 
/*    */   public List<?> getChildFilesByFolder(String paramString1, String paramString2)
/*    */   {
/* 32 */     String str1 = I18nGlobalContext.getInstance()
/* 33 */       .getServletContext().getRealPath(File.separator);
/* 34 */     String str2 = str1 + paramString1 + File.separator;
/* 35 */     File localFile1 = new File(str2);
/* 36 */     ArrayList localArrayList = new ArrayList();
/* 37 */     if (localFile1.isDirectory()) {
/* 38 */       File[] arrayOfFile1 = localFile1.listFiles();
/* 39 */       for (File localFile2 : arrayOfFile1)
/*    */       {
/*    */         HelpImageDTO localHelpImageDTO;
/* 40 */         if (localFile2.isDirectory())
/*    */         {
/* 42 */           if (!localFile2.getName().equals("WEB-INF"))
/*    */           {
/* 45 */             localHelpImageDTO = new HelpImageDTO();
/* 46 */             localHelpImageDTO.setTreeId(paramString2 + "_" + localFile2.getName());
/* 47 */             localHelpImageDTO.setIsLeaf(false);
/* 48 */             localHelpImageDTO.setTitle(localFile2.getName());
/* 49 */             localHelpImageDTO.setParentID(paramString2);
/* 50 */             localHelpImageDTO
/* 51 */               .setUrl(localFile2.getPath().replace(File.separator, "/"));
/* 52 */             localArrayList.add(localHelpImageDTO);
/*    */           } } else if (isFormatImage(localFile2.getName())) {
/* 54 */           localHelpImageDTO = new HelpImageDTO();
/* 55 */           localHelpImageDTO.setTreeId(paramString2 + "_" + localFile2.getName());
/* 56 */           localHelpImageDTO.setIsLeaf(true);
/* 57 */           localHelpImageDTO.setTitle(localFile2.getName());
/* 58 */           localHelpImageDTO.setParentID(paramString2);
/* 59 */           localHelpImageDTO
/* 60 */             .setUrl(localFile2.getPath().replace(File.separator, "/"));
/* 61 */           localArrayList.add(localHelpImageDTO);
/*    */         }
/*    */       }
/*    */     }
/* 65 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   private boolean isFormatImage(String paramString) {
/* 69 */     String str = paramString.toLowerCase();
/* 70 */     if ((str.endsWith(".jpg")) || (str.endsWith(".png")) || 
/* 71 */       (str.endsWith(".gif")) || (str.endsWith(".bmp")) || 
/* 72 */       (str.endsWith(".jpeg")) || (str.endsWith(".swf")) || 
/* 73 */       (str.endsWith(".svg")) || (str.endsWith(".tiff")) || 
/* 74 */       (str.endsWith(".psd"))) {
/* 75 */       return true;
/*    */     }
/* 77 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.bo.impl.HelpImgPickerBOImpl
 * JD-Core Version:    0.6.2
 */