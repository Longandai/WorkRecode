/*    */ package com.neusoft.unieap.techcomp.ria.help.dto;
/*    */ 
/*    */ public class HelpImageDTO
/*    */ {
/*    */   private String treeId;
/*    */   private String title;
/*    */   private String parentID;
/*    */   private boolean isLeaf;
/*    */   private String url;
/*    */ 
/*    */   public String getUrl()
/*    */   {
/* 18 */     return this.url;
/*    */   }
/*    */   public void setUrl(String paramString) {
/* 21 */     this.url = paramString;
/*    */   }
/*    */   public String getTreeId() {
/* 24 */     return this.treeId;
/*    */   }
/*    */   public void setTreeId(String paramString) {
/* 27 */     this.treeId = paramString;
/*    */   }
/*    */   public String getTitle() {
/* 30 */     return this.title;
/*    */   }
/*    */   public void setTitle(String paramString) {
/* 33 */     this.title = paramString;
/*    */   }
/*    */   public String getParentID() {
/* 36 */     return this.parentID;
/*    */   }
/*    */   public void setParentID(String paramString) {
/* 39 */     this.parentID = paramString;
/*    */   }
/*    */   public boolean getIsLeaf() {
/* 42 */     return this.isLeaf;
/*    */   }
/*    */   public void setIsLeaf(boolean paramBoolean) {
/* 45 */     this.isLeaf = paramBoolean;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.dto.HelpImageDTO
 * JD-Core Version:    0.6.2
 */