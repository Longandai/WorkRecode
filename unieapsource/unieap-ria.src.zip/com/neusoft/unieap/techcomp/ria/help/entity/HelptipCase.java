/*     */ package com.neusoft.unieap.techcomp.ria.help.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ 
/*     */ @ModelFile("helptipCase.entity")
/*     */ public class HelptipCase
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String createdBy;
/*     */   private Date creationDate;
/*     */   private BigDecimal caseIndex;
/*     */   private String lastUpdatedBy;
/*     */   private Date lastUpdateDate;
/*     */   private String menuid;
/*     */   private String title;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  55 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  59 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/*  63 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/*  67 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date paramDate) {
/*  71 */     this.creationDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/*  75 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setCaseIndex(BigDecimal paramBigDecimal) {
/*  79 */     this.caseIndex = paramBigDecimal;
/*     */   }
/*     */ 
/*     */   public BigDecimal getCaseIndex() {
/*  83 */     return this.caseIndex;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/*  87 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/*  91 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Date paramDate) {
/*  95 */     this.lastUpdateDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getLastUpdateDate() {
/*  99 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setMenuid(String paramString) {
/* 103 */     this.menuid = paramString;
/*     */   }
/*     */ 
/*     */   public String getMenuid() {
/* 107 */     return this.menuid;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/* 111 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/* 115 */     return this.title;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.help.entity.HelptipCase
 * JD-Core Version:    0.6.2
 */