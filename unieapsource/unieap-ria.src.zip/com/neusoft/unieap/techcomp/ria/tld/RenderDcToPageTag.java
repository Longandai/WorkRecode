/*     */ package com.neusoft.unieap.techcomp.ria.tld;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.page.Page;
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.MetaDataCreator;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.OrderImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.PageImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.ColumnImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataCreatorImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.TagSupport;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class RenderDcToPageTag extends TagSupport
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  48 */   String scope = "request";
/*     */ 
/*  57 */   String validateStore = "";
/*     */ 
/*  59 */   String i18nName = "";
/*     */ 
/*  61 */   String i18nKeys = "";
/*     */ 
/*     */   public void setScope(String paramString)
/*     */   {
/*  51 */     this.scope = paramString;
/*     */   }
/*     */ 
/*     */   public void setValidateStore(String paramString)
/*     */   {
/*  64 */     this.validateStore = paramString;
/*     */   }
/*     */ 
/*     */   public void setI18nName(String paramString) {
/*  68 */     this.i18nName = paramString;
/*     */   }
/*     */ 
/*     */   public void setI18nKeys(String paramString) {
/*  72 */     this.i18nKeys = paramString;
/*     */   }
/*     */ 
/*     */   private int transformScope(String paramString)
/*     */   {
/*  77 */     if (paramString.equals("page"))
/*  78 */       return 1;
/*  79 */     if (paramString.equals("session"))
/*  80 */       return 3;
/*  81 */     if (paramString.equals("application")) {
/*  82 */       return 4;
/*     */     }
/*  84 */     return 2;
/*     */   }
/*     */ 
/*     */   private Map getValidateStores(String paramString)
/*     */   {
/*  90 */     HashMap localHashMap = new HashMap();
/*  91 */     if ((paramString == null) || (paramString.equals(""))) {
/*  92 */       return localHashMap;
/*     */     }
/*  94 */     String[] arrayOfString1 = paramString.split(",");
/*  95 */     for (int i = 0; i < arrayOfString1.length; i++) {
/*  96 */       String[] arrayOfString2 = arrayOfString1[i].split(":");
/*  97 */       if (arrayOfString2.length > 1) {
/*  98 */         localHashMap.put(arrayOfString2[0], arrayOfString2[1]);
/*     */       }
/*     */     }
/* 101 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Object collectStoreMetaData(Object paramObject, Map paramMap) {
/* 105 */     if ((paramObject instanceof DataCenter)) {
/* 106 */       DataCenter localDataCenter = (DataCenter)paramObject;
/* 107 */       Object[] arrayOfObject = paramMap.keySet().toArray();
/* 108 */       if (arrayOfObject != null) {
/* 109 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 110 */           Object localObject = arrayOfObject[i];
/* 111 */           String str1 = (String)localObject;
/* 112 */           String str2 = (String)paramMap.get(localObject);
/* 113 */           DataStore localDataStore = DataCenterFactory.getInstance()
/* 114 */             .createDataStore(str1);
/* 115 */           localDataStore.setRowSetName(str2);
/* 116 */           localDataCenter.addDataStore(localDataStore);
/*     */         }
/*     */       }
/*     */ 
/* 120 */       return localDataCenter;
/*     */     }
/* 122 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public int doStartTag() throws JspException
/*     */   {
/* 127 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)this.pageContext
/* 128 */       .getRequest();
/* 129 */     ServletContext localServletContext = this.pageContext.getServletContext();
/* 130 */     if (localServletContext != null) {
/* 131 */       I18nGlobalContext.getInstance().setServletContext(
/* 132 */         this.pageContext.getServletContext());
/* 133 */       I18nGlobalContext.getInstance().clearI18nMap();
/*     */     }
/* 135 */     String str = "";
/* 136 */     if ((localHttpServletRequest.getAttribute("request-dc") != null) && 
/* 137 */       ((localHttpServletRequest.getAttribute("request-dc") instanceof DataCenter))) {
/* 138 */       str = localHttpServletRequest.getAttribute("request-dc").toString();
/*     */     }
/* 140 */     DataCenter localDataCenter = null;
/*     */     try {
/* 142 */       if ((str != null) && (!str.equals("")))
/* 143 */         localDataCenter = DataCenterIOManager.createReader(str)
/* 144 */           .parse();
/*     */       else {
/* 146 */         localDataCenter = DataCenterIOManager.createReader(
/* 147 */           localHttpServletRequest.getInputStream()).parse();
/*     */       }
/*     */ 
/* 157 */       Map localMap = localHttpServletRequest.getParameterMap();
/*     */       Object localObject2;
/*     */       Object localObject3;
/*     */       Object localObject4;
/* 158 */       for (Object localObject1 = localMap.entrySet().iterator(); ((Iterator)localObject1).hasNext(); ) {
/* 159 */         localObject2 = (Map.Entry)((Iterator)localObject1).next();
/* 160 */         localObject3 = (String)((Map.Entry)localObject2).getKey();
/* 161 */         localObject4 = ((Map.Entry)localObject2).getValue();
/* 162 */         if (!((String)localObject3).equals("_forwardDataCenter"))
/*     */         {
/* 165 */           if (!localDataCenter.getParameters().containsKey(localObject3))
/*     */           {
/* 168 */             if (localObject4.getClass().isArray()) {
/* 169 */               if (Array.getLength(localObject4) == 1)
/* 170 */                 localDataCenter.addParameter((String)localObject3, localHttpServletRequest.getParameter((String)localObject3));
/*     */               else {
/* 172 */                 localDataCenter.addParameter((String)localObject3, localObject4);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 178 */       localObject1 = localHttpServletRequest.getAttributeNames();
/* 179 */       while (((Enumeration)localObject1).hasMoreElements()) {
/* 180 */         localObject2 = ((Enumeration)localObject1).nextElement();
/* 181 */         localObject3 = localHttpServletRequest.getAttribute(localObject2.toString());
/*     */ 
/* 183 */         if (!localObject2.toString().equals("request-dc"))
/*     */         {
/* 185 */           if (!localObject2.toString().startsWith("struts."))
/*     */           {
/* 187 */             if (!localObject2.toString().startsWith("javax.servlet."))
/*     */             {
/* 189 */               if (!localObject2.toString().equals(
/* 190 */                 "_unieap_session_integration_filter_applied"))
/*     */               {
/* 192 */                 if (CommonUtil.isCommonType(localObject3)) {
/* 193 */                   localDataCenter.addParameter(localObject2.toString(), localObject3);
/* 194 */                 } else if ((localObject3 instanceof List)) {
/* 195 */                   localObject4 = DataCenterFactory.getInstance()
/* 196 */                     .createDataStore(localObject2.toString());
/* 197 */                   localObject4 = PojoUtil.toDataStore((List)localObject3, (DataStore)localObject4);
/* 198 */                   localDataCenter.addDataStore((DataStore)localObject4);
/*     */                 } else {
/* 200 */                   localObject4 = DataCenterFactory.getInstance()
/* 201 */                     .createDataStore(localObject2.toString());
/* 202 */                   ArrayList localArrayList = new ArrayList();
/* 203 */                   localArrayList.add(localObject3);
/* 204 */                   localObject4 = PojoUtil.toDataStore(localArrayList, (DataStore)localObject4);
/* 205 */                   localDataCenter.addDataStore((DataStore)localObject4);
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       } } catch (IOException localIOException) { 
/*     */     } catch (Exception localException) { localException.printStackTrace(); }
/*     */ 
/* 213 */     if (localDataCenter != null) {
/* 214 */       i18n4Js(localDataCenter);
/* 215 */       localHttpServletRequest.setAttribute("request-dc", localDataCenter);
/*     */     }
/* 217 */     return super.doStartTag();
/*     */   }
/*     */ 
/*     */   public int doEndTag() throws JspException
/*     */   {
/* 222 */     int i = transformScope(this.scope);
/* 223 */     Object localObject = this.pageContext.getAttribute("request-dc", i);
/* 224 */     ServletContext localServletContext = this.pageContext.getServletContext();
/* 225 */     if (localServletContext != null) {
/* 226 */       I18nGlobalContext.getInstance().setServletContext(localServletContext);
/* 227 */       I18nGlobalContext.getInstance().clearI18nMap();
/*     */     }
/* 229 */     DataCenter localDataCenter = null;
/* 230 */     if (localObject != null) {
/*     */       try {
/* 232 */         localDataCenter = (DataCenter)localObject;
/*     */       } catch (ClassCastException localClassCastException) {
/* 234 */         localDataCenter = null;
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 240 */       JspWriter localJspWriter = this.pageContext.getOut();
/* 241 */       if (localDataCenter != null) {
/* 242 */         localJspWriter.write("<script type='text/javascript'>\n");
/* 243 */         localJspWriter.write("var value=");
/* 244 */         DataCenterIOManager.createWriter(localJspWriter).write(localDataCenter);
/* 245 */         localJspWriter.write(";");
/* 246 */         localJspWriter.write("if(value){");
/* 247 */         localJspWriter
/* 248 */           .write("\tdataCenter.append(new unieap.ds.DataCenter(value),\"replace\");");
/* 249 */         localJspWriter.write("}\n");
/* 250 */         localJspWriter.write("</script>\n");
/*     */       }
/*     */ 
/* 253 */       if (!"".equals(this.validateStore.trim())) {
/* 254 */         localJspWriter.write("<script type='text/javascript'>\n");
/* 255 */         localJspWriter.write(addDataStoreMetaData());
/* 256 */         localJspWriter.write("</script>\n");
/*     */       }
/*     */     } catch (IOException localIOException) {
/* 259 */       localIOException.printStackTrace();
/*     */     }
/* 261 */     return 6;
/*     */   }
/*     */ 
/*     */   private String addDataStoreMetaData() {
/* 265 */     StringBuffer localStringBuffer1 = new StringBuffer("");
/* 266 */     Map localMap = getValidateStores(this.validateStore);
/* 267 */     long l = new Date().getTime();
/* 268 */     for (Iterator localIterator1 = localMap.keySet().iterator(); localIterator1.hasNext(); ) { Object localObject1 = localIterator1.next();
/* 269 */       String str1 = (String)localObject1;
/* 270 */       String str2 = (String)localMap.get(localObject1);
/* 271 */       MetaDataCreatorImpl localMetaDataCreatorImpl = new MetaDataCreatorImpl();
/* 272 */       MetaData localMetaData = localMetaDataCreatorImpl.afterRowSetNameSetted(str2);
/* 273 */       StringBuffer localStringBuffer2 = new StringBuffer(256);
/* 274 */       localStringBuffer2.append("{\"columns\":{");
/*     */ 
/* 276 */       List localList = localMetaData.getColumns();
/* 277 */       for (Iterator localIterator2 = localList.iterator(); localIterator2.hasNext(); ) { localObject2 = (Column)localIterator2.next();
/* 278 */         localStringBuffer2.append('"').append(((Column)localObject2).getName()).append("\":");
/* 279 */         String str3 = ((ColumnImpl)localObject2).getJSONObject()
/* 280 */           .toString();
/* 281 */         if (((Column)localObject2).getFuture() != null) {
/* 282 */           str3 = str3.replaceAll("\"future\":\\d+", 
/* 283 */             "\"future\":" + l);
/*     */         }
/* 285 */         if (((Column)localObject2).getPast() != null) {
/* 286 */           str3 = str3.replaceAll("\"future\":\\d+", 
/* 287 */             "\"future\":" + l);
/*     */         }
/* 289 */         localStringBuffer2.append(str3);
/* 290 */         localStringBuffer2.append(',');
/*     */       }
/*     */ 
/* 293 */       Object localObject2 = localStringBuffer2.substring(0, localStringBuffer2.length() - 1);
/* 294 */       localStringBuffer1.append("dataCenter.getDataStore(\"");
/* 295 */       localStringBuffer1.append(str1).append("\").metaData=").append((String)localObject2)
/* 296 */         .append("},\"order\":\"\",\"condition\":\"\"};");
/*     */     }
/* 298 */     return localStringBuffer1.toString();
/*     */   }
/*     */ 
/*     */   private boolean isExistParameter(ViewContext paramViewContext, Object paramObject) {
/* 302 */     return paramViewContext.containsKey(paramObject);
/*     */   }
/*     */ 
/*     */   private Page createPage(DataStore paramDataStore) {
/* 306 */     PageImpl localPageImpl = new PageImpl();
/* 307 */     localPageImpl.setCondition(paramDataStore.getCondition());
/* 308 */     localPageImpl.setConditionValues(paramDataStore.getConditionValues());
/* 309 */     localPageImpl.setPageNumber(paramDataStore.getPageNumber());
/* 310 */     localPageImpl.setSize(paramDataStore.getPageSize());
/* 311 */     localPageImpl.setRowSetName(paramDataStore.getRowSetName());
/* 312 */     String str1 = paramDataStore.getOrder();
/* 313 */     ArrayList localArrayList = new ArrayList();
/* 314 */     if ((str1 != null) && (!"".equals(str1.trim()))) {
/* 315 */       String[] arrayOfString1 = str1.split(",");
/* 316 */       for (int i = 0; i < arrayOfString1.length; i++) {
/* 317 */         String str2 = arrayOfString1[i].trim();
/* 318 */         String[] arrayOfString2 = str2.split(" ");
/* 319 */         OrderImpl localOrderImpl = new OrderImpl();
/* 320 */         localOrderImpl.setOrderStyle(arrayOfString2[(arrayOfString2.length - 1)]);
/* 321 */         localOrderImpl.setPropertyName(arrayOfString2[0]);
/* 322 */         localArrayList.add(localOrderImpl);
/*     */       }
/*     */     }
/* 325 */     localPageImpl.setOrders(localArrayList);
/* 326 */     return localPageImpl;
/*     */   }
/*     */ 
/*     */   private void i18n4Js(DataCenter paramDataCenter)
/*     */   {
/* 337 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/* 338 */     String[] arrayOfString1 = this.i18nName.split(",");
/* 339 */     HashMap localHashMap = new HashMap();
/* 340 */     for (localObject : arrayOfString1) {
/* 341 */       ResourceBundle localResourceBundle = 
/* 342 */         LocalizedTextUtil.findResourceBundle((String)localObject, localLocale);
/* 343 */       if ((this.i18nKeys.length() > 0) && (localResourceBundle != null)) {
/* 344 */         String[] arrayOfString3 = this.i18nKeys.split(",");
/* 345 */         if (arrayOfString3 != null) {
/* 346 */           int k = arrayOfString3.length;
/* 347 */           String str2 = "";
/* 348 */           for (int m = 0; m < k; m++) {
/* 349 */             str2 = LocalizedTextUtil.findText(localResourceBundle, 
/* 350 */               arrayOfString3[m], localLocale);
/* 351 */             if ((!localHashMap.containsKey(arrayOfString3[m])) || 
/* 352 */               (!arrayOfString3[m].equals(str2))) {
/* 353 */               localHashMap.put(arrayOfString3[m], str2);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 359 */     Object localObject = new StringBuffer();
/* 360 */     Iterator localIterator = localHashMap.keySet().iterator();
/* 361 */     while (localIterator.hasNext()) {
/* 362 */       String str1 = (String)localIterator.next();
/* 363 */       ((StringBuffer)localObject).append(str1).append(":\"").append((String)localHashMap.get(str1)).append("\"");
/* 364 */       if (localIterator.hasNext()) {
/* 365 */         ((StringBuffer)localObject).append(",");
/*     */       }
/*     */     }
/* 368 */     paramDataCenter.addParameter("i18n", "{" + ((StringBuffer)localObject).toString() + "}");
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.tld.RenderDcToPageTag
 * JD-Core Version:    0.6.2
 */