package com.neusoft.unieap.techcomp.ria.io;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;

public abstract interface CommonWriter
{
  public abstract void parseStream(PrintWriter paramPrintWriter, HttpServletRequest paramHttpServletRequest, String paramString)
    throws IOException;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.CommonWriter
 * JD-Core Version:    0.6.2
 */