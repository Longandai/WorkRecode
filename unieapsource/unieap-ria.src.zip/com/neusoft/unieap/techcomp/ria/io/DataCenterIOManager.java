/*    */ package com.neusoft.unieap.techcomp.ria.io;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.io.impl.DataCenterReaderImpl;
/*    */ import com.neusoft.unieap.techcomp.ria.io.impl.DataCenterWriterImpl;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ 
/*    */ public class DataCenterIOManager
/*    */ {
/*    */   public static DataCenterReader createReader(String paramString)
/*    */   {
/* 24 */     return new DataCenterReaderImpl(paramString);
/*    */   }
/*    */ 
/*    */   public static DataCenterReader createReader(InputStream paramInputStream)
/*    */   {
/* 32 */     return new DataCenterReaderImpl(paramInputStream);
/*    */   }
/*    */ 
/*    */   public static DataCenterWriter createWriter(OutputStream paramOutputStream)
/*    */   {
/*    */     try
/*    */     {
/* 42 */       BufferedWriter localBufferedWriter = new BufferedWriter(new OutputStreamWriter(paramOutputStream, "UTF-8"));
/* 43 */       return createWriter(localBufferedWriter);
/*    */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 45 */       localUnsupportedEncodingException.printStackTrace();
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   public static DataCenterWriter createWriter(Writer paramWriter)
/*    */   {
/* 55 */     return new DataCenterWriterImpl(paramWriter);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager
 * JD-Core Version:    0.6.2
 */