/*    */ package com.neusoft.unieap.techcomp.ria.io.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl;
/*    */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.InputStreamReader;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ public class DataCenterReaderImpl
/*    */   implements DataCenterReader
/*    */ {
/* 20 */   InputStream is = null;
/*    */ 
/* 22 */   String json = null;
/*    */ 
/*    */   public DataCenterReaderImpl(String paramString) {
/* 25 */     this.json = paramString;
/*    */   }
/*    */   public DataCenterReaderImpl(InputStream paramInputStream) {
/* 28 */     this.is = paramInputStream;
/*    */   }
/*    */   public DataCenter parse() throws Exception {
/* 31 */     if (this.is == null) {
/* 32 */       return parse(this.json);
/*    */     }
/*    */ 
/* 35 */     BufferedReader localBufferedReader = null;
/* 36 */     StringBuffer localStringBuffer = new StringBuffer("");
/*    */     try {
/* 38 */       String str = null;
/* 39 */       localBufferedReader = new BufferedReader(new InputStreamReader(this.is, "UTF-8"));
/* 40 */       while ((str = localBufferedReader.readLine()) != null)
/* 41 */         localStringBuffer.append(str);
/*    */     }
/*    */     catch (IOException localIOException) {
/* 44 */       throw localIOException;
/*    */     }
/*    */     finally {
/* 47 */       if (localBufferedReader != null) {
/*    */         try {
/* 49 */           localBufferedReader.close();
/*    */         } catch (Exception localException1) {
/* 51 */           localException1.printStackTrace();
/*    */         }
/*    */       }
/* 54 */       if (this.is != null) {
/*    */         try {
/* 56 */           this.is.close();
/*    */         } catch (Exception localException2) {
/* 58 */           localException2.printStackTrace();
/*    */         }
/*    */       }
/*    */     }
/* 62 */     return parse(localStringBuffer.toString());
/*    */   }
/*    */ 
/*    */   private DataCenter parse(String paramString) {
/* 66 */     DataCenterImpl localDataCenterImpl = new DataCenterImpl();
/* 67 */     if ((paramString != null) && (!"".equals(paramString.trim()))) {
/* 68 */       localDataCenterImpl = new DataCenterImpl(JSONObject.fromObject(paramString));
/*    */     }
/* 70 */     return localDataCenterImpl;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.impl.DataCenterReaderImpl
 * JD-Core Version:    0.6.2
 */