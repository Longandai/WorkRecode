/*     */ package com.neusoft.unieap.techcomp.ria.io.impl;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataCenterImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.io.RowSetWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.io.RowWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.util.ConverterUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ 
/*     */ public class DataCenterWriterImpl
/*     */   implements DataCenterWriter, RowWriter
/*     */ {
/*     */   Writer writer;
/*  26 */   private boolean writerClose = false;
/*  27 */   private boolean rsBool = false;
/*  28 */   private boolean dsBool = false;
/*     */ 
/*     */   public DataCenterWriterImpl(Writer paramWriter) {
/*  31 */     this.writer = paramWriter;
/*     */   }
/*     */ 
/*     */   public void write(DataCenter paramDataCenter)
/*     */     throws IOException
/*     */   {
/*  37 */     if (paramDataCenter == null) {
/*  38 */       return;
/*     */     }
/*  40 */     writeDC(paramDataCenter);
/*     */   }
/*     */   public void close() throws IOException {
/*  43 */     this.writer.close();
/*     */   }
/*     */   private void writeDC(DataCenter paramDataCenter) throws IOException {
/*  46 */     if (this.writerClose) return;
/*  47 */     this.dsBool = false;
/*  48 */     append("{");
/*  49 */     writeHeader(paramDataCenter);
/*  50 */     append(",");
/*  51 */     writeBody(paramDataCenter);
/*  52 */     append("}");
/*  53 */     this.writerClose = true;
/*     */   }
/*     */   private void writeHeader(DataCenter paramDataCenter) throws IOException {
/*  56 */     append("header:");
/*  57 */     append(((DataCenterImpl)paramDataCenter).getJSONObject().getJSONObject("header").toString());
/*     */   }
/*     */   private void writeBody(DataCenter paramDataCenter) throws IOException {
/*  60 */     append("body :{");
/*  61 */     writeParameters(paramDataCenter);
/*  62 */     append(",");
/*  63 */     writeStores(paramDataCenter);
/*  64 */     append("}");
/*     */   }
/*     */   private void writeParameters(DataCenter paramDataCenter) throws IOException {
/*  67 */     append("parameters :");
/*  68 */     append(((DataCenterImpl)paramDataCenter).getJSONObject().getJSONObject("body")
/*  69 */       .getJSONObject("parameters").toString());
/*     */   }
/*     */   private void writeStores(DataCenter paramDataCenter) throws IOException {
/*  72 */     append("dataStores :{");
/*  73 */     List localList = paramDataCenter.getDataStores();
/*  74 */     int i = 0; for (int j = localList.size(); i < j; i++) {
/*  75 */       writeDS((DataStoreImpl)localList.get(i));
/*     */     }
/*  77 */     append("}");
/*     */   }
/*     */   private void writeDS(DataStoreImpl paramDataStoreImpl) throws IOException {
/*  80 */     if ((this.dsBool) || ((this.dsBool = 1) == 0)) {
/*  81 */       append(",");
/*     */     }
/*  83 */     append("\"" + paramDataStoreImpl.getStoreName() + "\":");
/*  84 */     JSONObject localJSONObject = paramDataStoreImpl.getJSONObject();
/*  85 */     if ((localJSONObject == null) || (localJSONObject.isNullObject())) {
/*  86 */       append("null");
/*     */     } else {
/*  88 */       append("{");
/*  89 */       writeDSProperties(paramDataStoreImpl);
/*  90 */       writeRS(paramDataStoreImpl);
/*  91 */       append("}");
/*     */     }
/*     */   }
/*     */ 
/*  95 */   private void writeDSProperties(DataStoreImpl paramDataStoreImpl) throws IOException { append("name:\"" + paramDataStoreImpl.getStoreName() + "\",");
/*  96 */     append("pageNumber:" + paramDataStoreImpl.getPageNumber() + ",");
/*  97 */     append("pageSize:" + paramDataStoreImpl.getPageSize() + ",");
/*  98 */     append("recordCount:" + paramDataStoreImpl.getRecordCount() + ",");
/*  99 */     if (paramDataStoreImpl.getMetaData() != null) {
/* 100 */       append("\"metaData\"");
/* 101 */       append(":");
/* 102 */       append(((MetaDataImpl)paramDataStoreImpl.getMetaData()).getJSONObject().toString());
/* 103 */       append(",");
/*     */     }
/* 105 */     if (paramDataStoreImpl.getAttributes() != null) {
/* 106 */       append("\"attributes\":{");
/* 107 */       append(getAttrStr(paramDataStoreImpl.getAttributes()));
/* 108 */       append("},");
/*     */     }
/* 110 */     if (paramDataStoreImpl.getCondition() != null) {
/* 111 */       append("\"condition\":");
/* 112 */       append("\"");
/* 113 */       append(ConverterUtil.toValidJson(paramDataStoreImpl.getCondition()));
/* 114 */       append("\"");
/* 115 */       append(",");
/*     */     }
/* 117 */     if (paramDataStoreImpl.getJSONObject().containsKey("conditionValues")) {
/* 118 */       append("\"conditionValues\":");
/* 119 */       append(paramDataStoreImpl.getJSONObject().getJSONArray("conditionValues").toString());
/* 120 */       append(",");
/*     */     }
/* 122 */     if (paramDataStoreImpl.getRowSetName() != null) {
/* 123 */       append("\"rowSetName\":");
/* 124 */       append("\"");
/* 125 */       append(ConverterUtil.toValidJson(paramDataStoreImpl.getRowSetName()));
/* 126 */       append("\"");
/* 127 */       append(",");
/*     */     }
/* 129 */     if (paramDataStoreImpl.getStatementName() != null) {
/* 130 */       append("\"statementName\":");
/* 131 */       append("\"");
/* 132 */       append(ConverterUtil.toValidJson(paramDataStoreImpl.getStatementName()));
/* 133 */       append("\"");
/* 134 */       append(",");
/*     */     }
/* 136 */     if (paramDataStoreImpl.getParameters() != null) {
/* 137 */       append("\"parameters\":");
/* 138 */       append(paramDataStoreImpl.getJSONObject().getJSONObject("parameters").toString());
/* 139 */       append(",");
/*     */     }
/*     */ 
/* 142 */     if (paramDataStoreImpl.getOrder() != null) {
/* 143 */       append("\"order\":");
/* 144 */       append("\"");
/* 145 */       append(ConverterUtil.toValidJson(paramDataStoreImpl.getOrder()));
/* 146 */       append("\"");
/* 147 */       append(",");
/*     */     }
/* 149 */     if (paramDataStoreImpl.getStatistics() != null) {
/* 150 */       append("\"statistics\": ");
/* 151 */       append(paramDataStoreImpl.getJSONObject().getJSONObject("statistics").toString());
/* 152 */       append(",");
/*     */     }
/* 154 */     if (paramDataStoreImpl.getPool() != null) {
/* 155 */       append("pool:\"");
/* 156 */       append(ConverterUtil.toValidJson(paramDataStoreImpl.getPool()));
/* 157 */       append("\",");
/*     */     }
/* 159 */     if (paramDataStoreImpl.getJSONObject().containsKey("distinct")) {
/* 160 */       append("distinct:");
/* 161 */       if (paramDataStoreImpl.isDistinct())
/* 162 */         append("\"true\"");
/*     */       else {
/* 164 */         append("\"false\"");
/*     */       }
/* 166 */       append(",");
/*     */     } }
/*     */ 
/*     */   private String getAttrStr(Map paramMap) {
/* 170 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 171 */     Iterator localIterator = paramMap.entrySet().iterator();
/*     */ 
/* 173 */     int i = 0;
/*     */ 
/* 175 */     while (localIterator.hasNext()) {
/* 176 */       if (i != 0) {
/* 177 */         localStringBuffer.append(",");
/*     */       }
/* 179 */       i++;
/* 180 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 181 */       localStringBuffer.append("\"");
/* 182 */       localStringBuffer.append(ConverterUtil.toValidJson(localEntry.getKey().toString()) + "\":[");
/* 183 */       List localList = (List)paramMap.get(localEntry.getKey());
/* 184 */       localStringBuffer.append(ConverterUtil.toJson(localList.get(0)) + 
/* 185 */         "," + ConverterUtil.toJson(localList.get(1)) + "]");
/*     */     }
/* 187 */     return localStringBuffer.toString();
/*     */   }
/*     */   private void writeRS(DataStoreImpl paramDataStoreImpl) throws IOException {
/* 190 */     append("rowSet:{");
/* 191 */     writePrimaryBuffer(paramDataStoreImpl);
/* 192 */     writeFilterBuffer(paramDataStoreImpl);
/* 193 */     writeDeleteBuffer(paramDataStoreImpl);
/* 194 */     append("}");
/*     */   }
/*     */   private void writePrimaryBuffer(DataStoreImpl paramDataStoreImpl) throws IOException {
/* 197 */     append("\"primary\": [");
/* 198 */     RowSetWriter localRowSetWriter = paramDataStoreImpl.getRowSetWriter();
/* 199 */     if (localRowSetWriter != null) {
/* 200 */       this.rsBool = false;
/* 201 */       localRowSetWriter.writeRowSet(this);
/*     */     }
/*     */     else {
/* 204 */       writeBuffer(paramDataStoreImpl.getPrimaryArray());
/*     */     }
/* 206 */     append("]");
/* 207 */     append(",");
/*     */   }
/*     */   private void writeFilterBuffer(DataStoreImpl paramDataStoreImpl) throws IOException {
/* 210 */     append("\"filter\": [");
/* 211 */     writeBuffer(paramDataStoreImpl.getFilterArray());
/* 212 */     append("]");
/* 213 */     append(",");
/*     */   }
/*     */   private void writeDeleteBuffer(DataStoreImpl paramDataStoreImpl) throws IOException {
/* 216 */     append("\"delete\": [");
/* 217 */     writeBuffer(paramDataStoreImpl.getDeleteArray());
/* 218 */     append("]");
/*     */   }
/*     */   private void writeBuffer(JSONArray paramJSONArray) throws IOException {
/* 221 */     this.rsBool = false;
/* 222 */     for (int i = 0; i < paramJSONArray.size(); i++)
/* 223 */       writeRow((Map)paramJSONArray.get(i));
/*     */   }
/*     */ 
/*     */   public void writeRow(Map paramMap)
/*     */     throws IOException
/*     */   {
/* 231 */     if ((this.rsBool) || ((this.rsBool = 1) == 0)) {
/* 232 */       append(",");
/*     */     }
/* 234 */     if ((paramMap instanceof JSONObject)) {
/* 235 */       append(paramMap.toString());
/*     */     }
/*     */     else {
/* 238 */       Iterator localIterator = paramMap.entrySet().iterator();
/*     */ 
/* 240 */       int i = 0;
/* 241 */       StringBuffer localStringBuffer = new StringBuffer("");
/* 242 */       localStringBuffer.append("{");
/* 243 */       while (localIterator.hasNext()) {
/* 244 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 245 */         if (i != 0) {
/* 246 */           localStringBuffer.append(",");
/*     */         }
/* 248 */         i = 1;
/* 249 */         localStringBuffer.append("\"" + ConverterUtil.toValidJson(localEntry.getKey().toString()) + "\":");
/* 250 */         localStringBuffer.append(ConverterUtil.toJson(localEntry.getValue()));
/*     */       }
/* 252 */       localStringBuffer.append("}");
/* 253 */       append(localStringBuffer.toString());
/*     */     }
/*     */   }
/*     */ 
/* 257 */   private void append(String paramString) throws IOException { this.writer.write(paramString); }
/*     */ 
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.impl.DataCenterWriterImpl
 * JD-Core Version:    0.6.2
 */