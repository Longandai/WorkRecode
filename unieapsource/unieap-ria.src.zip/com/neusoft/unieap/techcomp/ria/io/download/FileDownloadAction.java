/*    */ package com.neusoft.unieap.techcomp.ria.io.download;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.bo.RicheditorBO;
/*    */ import com.neusoft.unieap.techcomp.ria.richeditor.entity.UpInfotipAttachment;
/*    */ import com.opensymphony.xwork2.ActionSupport;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URLEncoder;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import org.apache.struts2.interceptor.ServletRequestAware;
/*    */ import org.apache.struts2.interceptor.ServletResponseAware;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class FileDownloadAction extends ActionSupport
/*    */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*    */ {
/*    */   RicheditorBO richeditorBo;
/*    */   private static final long serialVersionUID = -5560721990786836931L;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public RicheditorBO getRicheditorBo()
/*    */   {
/* 25 */     return this.richeditorBo;
/*    */   }
/*    */ 
/*    */   public void setRicheditorBo(RicheditorBO paramRicheditorBO) {
/* 29 */     this.richeditorBo = paramRicheditorBO;
/*    */   }
/*    */ 
/*    */   public void setServletRequest(HttpServletRequest paramHttpServletRequest)
/*    */   {
/* 49 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public void setServletResponse(HttpServletResponse paramHttpServletResponse) {
/* 53 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 58 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   public String download() {
/* 62 */     UpInfotipAttachment localUpInfotipAttachment = this.richeditorBo.getAttachment(this.request
/* 63 */       .getParameter("id"));
/* 64 */     if (localUpInfotipAttachment != null) {
/* 65 */       String str = localUpInfotipAttachment.getFileName();
/* 66 */       if ((str == null) || (str.length() == 0)) {
/* 67 */         str = "downloadFile.tmp";
/*    */       }
/* 69 */       byte[] arrayOfByte = localUpInfotipAttachment.getContent();
/* 70 */       this.response.setCharacterEncoding("UTF-8");
/* 71 */       this.response.setContentType("application/octet-stream; charset=UTF-8");
/*    */       try {
/* 73 */         str = URLEncoder.encode(str, "UTF-8");
/* 74 */         this.response.addHeader("Content-Disposition", 
/* 75 */           "attachment; filename=" + str);
/*    */       } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 77 */         localUnsupportedEncodingException.printStackTrace();
/*    */       }
/* 79 */       ServletOutputStream localServletOutputStream = null;
/*    */       try {
/* 81 */         localServletOutputStream = this.response.getOutputStream();
/* 82 */         localServletOutputStream.write(arrayOfByte);
/* 83 */         localServletOutputStream.close();
/*    */       } catch (IOException localIOException1) {
/* 85 */         if (localServletOutputStream != null) {
/*    */           try {
/* 87 */             localServletOutputStream.close();
/*    */           }
/*    */           catch (IOException localIOException2) {
/* 90 */             localIOException2.printStackTrace();
/*    */           }
/*    */         }
/* 93 */         localIOException1.printStackTrace();
/*    */       }
/*    */     }
/*    */ 
/* 97 */     return "none";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.download.FileDownloadAction
 * JD-Core Version:    0.6.2
 */