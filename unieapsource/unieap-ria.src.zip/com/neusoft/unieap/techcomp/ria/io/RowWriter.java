package com.neusoft.unieap.techcomp.ria.io;

import java.io.IOException;
import java.util.Map;

public abstract interface RowWriter
{
  public abstract void writeRow(Map paramMap)
    throws IOException;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.RowWriter
 * JD-Core Version:    0.6.2
 */