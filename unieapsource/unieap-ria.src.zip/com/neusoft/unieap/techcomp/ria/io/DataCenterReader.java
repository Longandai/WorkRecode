package com.neusoft.unieap.techcomp.ria.io;

import com.neusoft.unieap.techcomp.ria.ds.DataCenter;

public abstract interface DataCenterReader
{
  public abstract DataCenter parse()
    throws Exception;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.DataCenterReader
 * JD-Core Version:    0.6.2
 */