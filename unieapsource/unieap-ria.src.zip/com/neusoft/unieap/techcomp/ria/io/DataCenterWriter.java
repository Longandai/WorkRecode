package com.neusoft.unieap.techcomp.ria.io;

import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
import java.io.IOException;

public abstract interface DataCenterWriter
{
  public abstract void write(DataCenter paramDataCenter)
    throws IOException;

  public abstract void close()
    throws IOException;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.io.DataCenterWriter
 * JD-Core Version:    0.6.2
 */