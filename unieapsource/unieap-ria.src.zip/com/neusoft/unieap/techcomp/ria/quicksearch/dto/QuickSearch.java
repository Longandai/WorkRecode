/*     */ package com.neusoft.unieap.techcomp.ria.quicksearch.dto;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class QuickSearch
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String sql;
/*     */   private String hql;
/*  23 */   private int max = 10;
/*     */   private String structure;
/*     */   private String prompt;
/*     */   private String width;
/*     */   private String popupWidth;
/*     */   private String codeAttr;
/*     */   private String valueAttr;
/*     */   private String codeAttrConfig;
/*     */   private String valueAttrConfig;
/*     */   private String dataSource;
/*     */   private String queryMode;
/*     */   private String queryMatch;
/*     */   private String dialogType;
/*  50 */   private int dialogMax = 10;
/*     */   private String queryConfig;
/*     */   private String queryAliasName;
/*     */   private String queryHql;
/*     */   private String querySql;
/*     */ 
/*     */   public String getSql()
/*     */   {
/*  60 */     return this.sql;
/*     */   }
/*     */   public void setSql(String paramString) {
/*  63 */     this.sql = paramString;
/*     */   }
/*     */   public String getHql() {
/*  66 */     return this.hql;
/*     */   }
/*     */   public void setHql(String paramString) {
/*  69 */     this.hql = paramString;
/*     */   }
/*     */   public int getMax() {
/*  72 */     return this.max;
/*     */   }
/*     */   public void setMax(int paramInt) {
/*  75 */     this.max = paramInt;
/*     */   }
/*     */   public String getStructure() {
/*  78 */     return this.structure;
/*     */   }
/*     */   public void setStructure(String paramString) {
/*  81 */     this.structure = paramString;
/*     */   }
/*     */   public String getPrompt() {
/*  84 */     return this.prompt;
/*     */   }
/*     */   public void setPrompt(String paramString) {
/*  87 */     this.prompt = paramString;
/*     */   }
/*     */   public String getWidth() {
/*  90 */     return this.width;
/*     */   }
/*     */   public void setWidth(String paramString) {
/*  93 */     this.width = paramString;
/*     */   }
/*     */   public String getCodeAttr() {
/*  96 */     return this.codeAttr;
/*     */   }
/*     */   public void setCodeAttr(String paramString) {
/*  99 */     this.codeAttr = paramString;
/*     */   }
/*     */   public String getValueAttr() {
/* 102 */     return this.valueAttr;
/*     */   }
/*     */   public void setValueAttr(String paramString) {
/* 105 */     this.valueAttr = paramString;
/*     */   }
/*     */   public String getDataSource() {
/* 108 */     return this.dataSource;
/*     */   }
/*     */   public void setDataSource(String paramString) {
/* 111 */     this.dataSource = paramString;
/*     */   }
/*     */   public String getQueryMode() {
/* 114 */     return this.queryMode;
/*     */   }
/*     */   public void setQueryMode(String paramString) {
/* 117 */     this.queryMode = paramString;
/*     */   }
/*     */   public String getQueryMatch() {
/* 120 */     return this.queryMatch;
/*     */   }
/*     */   public void setQueryMatch(String paramString) {
/* 123 */     this.queryMatch = paramString;
/*     */   }
/*     */   public String getDialogType() {
/* 126 */     return this.dialogType;
/*     */   }
/*     */   public void setDialogType(String paramString) {
/* 129 */     this.dialogType = paramString;
/*     */   }
/*     */   public int getDialogMax() {
/* 132 */     return this.dialogMax;
/*     */   }
/*     */   public void setDialogMax(int paramInt) {
/* 135 */     this.dialogMax = paramInt;
/*     */   }
/*     */   public String getQueryConfig() {
/* 138 */     return this.queryConfig;
/*     */   }
/*     */   public void setQueryConfig(String paramString) {
/* 141 */     this.queryConfig = paramString;
/*     */   }
/*     */   public String getQueryAliasName() {
/* 144 */     return this.queryAliasName;
/*     */   }
/*     */   public void setQueryAliasName(String paramString) {
/* 147 */     this.queryAliasName = paramString;
/*     */   }
/*     */   public String getQueryHql() {
/* 150 */     return this.queryHql;
/*     */   }
/*     */   public void setQueryHql(String paramString) {
/* 153 */     this.queryHql = paramString;
/*     */   }
/*     */   public String getQuerySql() {
/* 156 */     return this.querySql;
/*     */   }
/*     */   public void setQuerySql(String paramString) {
/* 159 */     this.querySql = paramString;
/*     */   }
/*     */   public void setPopupWidth(String paramString) {
/* 162 */     this.popupWidth = paramString;
/*     */   }
/*     */   public String getPopupWidth() {
/* 165 */     return this.popupWidth;
/*     */   }
/*     */   public void setCodeAttrConfig(String paramString) {
/* 168 */     this.codeAttrConfig = paramString;
/*     */   }
/*     */   public String getCodeAttrConfig() {
/* 171 */     return this.codeAttrConfig;
/*     */   }
/*     */   public void setValueAttrConfig(String paramString) {
/* 174 */     this.valueAttrConfig = paramString;
/*     */   }
/*     */   public String getValueAttrConfig() {
/* 177 */     return this.valueAttrConfig;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.dto.QuickSearch
 * JD-Core Version:    0.6.2
 */