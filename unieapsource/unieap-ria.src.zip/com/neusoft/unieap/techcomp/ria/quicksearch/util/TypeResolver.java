/*    */ package com.neusoft.unieap.techcomp.ria.quicksearch.util;
/*    */ 
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class TypeResolver
/*    */ {
/*  6 */   private static final Properties typeMap = new Properties();
/*    */ 
/*    */   static {
/*  9 */     typeMap.setProperty("float", "2");
/* 10 */     typeMap.setProperty("real", "2");
/* 11 */     typeMap.setProperty("float unsigned zerofill", "2");
/* 12 */     typeMap.setProperty("double", "2");
/* 13 */     typeMap.setProperty("binary_float", "2");
/* 14 */     typeMap.setProperty("binary_double", "2");
/* 15 */     typeMap.setProperty("decimal", "2");
/* 16 */     typeMap.setProperty("money", "2");
/* 17 */     typeMap.setProperty("currency", "2");
/* 18 */     typeMap.setProperty("int", "2");
/* 19 */     typeMap.setProperty("long", "2");
/* 20 */     typeMap.setProperty("uniqueidentifier", "2");
/* 21 */     typeMap.setProperty("nvarchar", "12");
/* 22 */     typeMap.setProperty("tinyint", "12");
/* 23 */     typeMap.setProperty("smallint", "2");
/* 24 */     typeMap.setProperty("mediumint", "2");
/* 25 */     typeMap.setProperty("int2", "2");
/* 26 */     typeMap.setProperty("int4", "2");
/* 27 */     typeMap.setProperty("int8", "2");
/* 28 */     typeMap.setProperty("integer", "2");
/* 29 */     typeMap.setProperty("int identity", "2");
/* 30 */     typeMap.setProperty("bigint", "2");
/* 31 */     typeMap.setProperty("numeric", "2");
/* 32 */     typeMap.setProperty("number", "2");
/* 33 */     typeMap.setProperty("serial", "2");
/* 34 */     typeMap.setProperty("int unsigned", "2");
/* 35 */     typeMap.setProperty("smallint", "2");
/* 36 */     typeMap.setProperty("mediumint", "2");
/* 37 */     typeMap.setProperty("datetime", "91");
/* 38 */     typeMap.setProperty("timestamp", "91");
/* 39 */     typeMap.setProperty("timestamptz", "91");
/* 40 */     typeMap.setProperty("typesystimestamp", "91");
/* 41 */     typeMap.setProperty("smalldatetime", "91");
/* 42 */     typeMap.setProperty("interval", "91");
/* 43 */     typeMap.setProperty("time", "91");
/* 44 */     typeMap.setProperty("date", "91");
/* 45 */     typeMap.setProperty("smalldate", "91");
/* 46 */     typeMap.setProperty("ntext", "12");
/* 47 */     typeMap.setProperty("text", "12");
/* 48 */     typeMap.setProperty("mediumtext", "12");
/* 49 */     typeMap.setProperty("mediumblob", "12");
/* 50 */     typeMap.setProperty("longtext", "12");
/* 51 */     typeMap.setProperty("varchar", "12");
/* 52 */     typeMap.setProperty("varchar2", "12");
/* 53 */     typeMap.setProperty("char", "16");
/* 54 */     typeMap.setProperty("nchar", "12");
/* 55 */     typeMap.setProperty("bpchar", "12");
/* 56 */     typeMap.setProperty("clob", "12");
/* 57 */     typeMap.setProperty("blob", "12");
/* 58 */     typeMap.setProperty("bit", "16");
/* 59 */     typeMap.setProperty("bool", "16");
/* 60 */     typeMap.setProperty("varbinary", "12");
/* 61 */     typeMap.setProperty("image", "12");
/* 62 */     typeMap.setProperty("byte", "12");
/* 63 */     typeMap.setProperty("binary", "12");
/* 64 */     typeMap.setProperty("nvarchar2", "12");
/*    */   }
/*    */ 
/*    */   public static String resolveType(String paramString) {
/* 68 */     if (paramString == null)
/* 69 */       return null;
/* 70 */     String str = typeMap.getProperty(paramString.toLowerCase());
/* 71 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.util.TypeResolver
 * JD-Core Version:    0.6.2
 */