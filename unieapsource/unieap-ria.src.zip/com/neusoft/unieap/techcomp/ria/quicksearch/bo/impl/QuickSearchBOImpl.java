/*     */ package com.neusoft.unieap.techcomp.ria.quicksearch.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.CodeListManager;
/*     */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*     */ import com.neusoft.unieap.techcomp.ria.quicksearch.bo.QuickSearchBO;
/*     */ import com.neusoft.unieap.techcomp.ria.quicksearch.dao.QuickSearchDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.quicksearch.dto.QuickSearch;
/*     */ import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchAttrConfig;
/*     */ import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchConfig;
/*     */ import com.neusoft.unieap.techcomp.ria.util.HSUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.orm.hibernate3.LocalSessionFactoryBean;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ @ModelFile("quickSearchBO.bo")
/*     */ public class QuickSearchBOImpl
/*     */   implements QuickSearchBO
/*     */ {
/*     */   private QuickSearchDAO quickSearchDAO;
/*     */   private CodeListManager codeListManager;
/*     */ 
/*     */   public void setQuickSearchDAO(QuickSearchDAO paramQuickSearchDAO)
/*     */   {
/*  49 */     this.quickSearchDAO = paramQuickSearchDAO;
/*     */   }
/*     */ 
/*     */   public void setCodeListManager(CodeListManager paramCodeListManager) {
/*  53 */     this.codeListManager = paramCodeListManager;
/*     */   }
/*     */ 
/*     */   public List query(String paramString1, String paramString2, QuickSearch paramQuickSearch, boolean paramBoolean, Map<String, Object> paramMap)
/*     */   {
/*  61 */     return this.quickSearchDAO.query(paramString1, paramString2, paramMap, paramQuickSearch, paramBoolean);
/*     */   }
/*     */ 
/*     */   public QueryResult queryByAdvanceCondition(QuickSearch paramQuickSearch, int paramInt1, int paramInt2, Map paramMap)
/*     */   {
/*  68 */     return this.quickSearchDAO.queryByAdvanceCondition(paramQuickSearch, paramMap, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public QueryResult queryByFormCondition(QuickSearch paramQuickSearch, Map paramMap1, int paramInt1, int paramInt2, Map paramMap2)
/*     */   {
/*  75 */     return this.quickSearchDAO.queryByFormCondition(paramQuickSearch, paramMap1, paramMap2, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public QuickSearch getQuickSearch(String paramString)
/*     */   {
/*  82 */     QuickSearch localQuickSearch = null;
/*     */     try {
/*  84 */       localQuickSearch = (QuickSearch)BeanUtil.getBean(paramString);
/*  85 */       if (localQuickSearch != null) {
/*  86 */         return localQuickSearch;
/*     */       }
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  91 */       QuickSearchConfig localQuickSearchConfig = this.quickSearchDAO.getQuickSearchConfigById(paramString);
/*  92 */       if (localQuickSearchConfig != null) {
/*  93 */         localQuickSearch = new QuickSearch();
/*  94 */         String str1 = localQuickSearchConfig.getQueryLanguageType();
/*  95 */         String str2 = localQuickSearchConfig.getQueryLanguage();
/*  96 */         if ("hql".equals(str1))
/*  97 */           localQuickSearch.setHql(str2);
/*     */         else {
/*  99 */           localQuickSearch.setSql(str2);
/*     */         }
/* 101 */         List localList = getDataSourceNames();
/* 102 */         if ((localList != null) && (localList.size() > 1)) {
/* 103 */           localQuickSearch.setDataSource(localQuickSearchConfig.getQueryDatasource());
/*     */         }
/* 105 */         localQuickSearch.setQueryMode(localQuickSearchConfig.getQueryMode());
/* 106 */         localQuickSearch.setQueryMatch(localQuickSearchConfig.getQueryMatchOperator());
/* 107 */         localQuickSearch.setMax(localQuickSearchConfig.getQueryMaxSize().intValue());
/* 108 */         if ("sql".equals(str1)) {
/* 109 */           localQuickSearch.setCodeAttr(HSUtil.getJavaName(localQuickSearchConfig.getCodeAttr().replace(".", "_")));
/* 110 */           localQuickSearch.setValueAttr(HSUtil.getJavaName(localQuickSearchConfig.getValueAttr().replace(".", "_")));
/*     */         } else {
/* 112 */           localQuickSearch.setCodeAttr(localQuickSearchConfig.getCodeAttr());
/* 113 */           localQuickSearch.setValueAttr(localQuickSearchConfig.getValueAttr());
/*     */         }
/* 115 */         initStructure(localQuickSearch, localQuickSearchConfig);
/* 116 */         if (localQuickSearchConfig.getDialogEnabled().booleanValue()) {
/* 117 */           localQuickSearch.setDialogType(localQuickSearchConfig.getDialogQueryType());
/* 118 */           localQuickSearch.setDialogMax(localQuickSearchConfig.getDialogQueryMaxSize().intValue());
/* 119 */           String str3 = localQuickSearchConfig.getDialogQueryLanguage();
/* 120 */           if ("hql".equals(str1))
/* 121 */             localQuickSearch.setQueryHql(str3);
/*     */           else {
/* 123 */             localQuickSearch.setQuerySql(str3);
/*     */           }
/* 125 */           initDialogStructure(localQuickSearch, localQuickSearchConfig);
/*     */         }
/* 127 */         return localQuickSearch;
/*     */       }
/*     */     }
/* 129 */     return null;
/*     */   }
/*     */ 
/*     */   private void initCodeAttrConfig(QuickSearch paramQuickSearch, String paramString, QuickSearchAttrConfig paramQuickSearchAttrConfig)
/*     */   {
/* 138 */     JSONObject localJSONObject = new JSONObject();
/* 139 */     localJSONObject.put("attr", paramString);
/* 140 */     localJSONObject.put("alias", paramQuickSearchAttrConfig.getAlias());
/* 141 */     localJSONObject.put("dataType", paramQuickSearchAttrConfig.getDataType());
/* 142 */     paramQuickSearch.setCodeAttrConfig(localJSONObject.toString());
/*     */   }
/*     */ 
/*     */   private void initValueAttrConfig(QuickSearch paramQuickSearch, String paramString, QuickSearchAttrConfig paramQuickSearchAttrConfig)
/*     */   {
/* 152 */     JSONObject localJSONObject = new JSONObject();
/* 153 */     localJSONObject.put("attr", paramString);
/* 154 */     localJSONObject.put("alias", paramQuickSearchAttrConfig.getAlias());
/* 155 */     localJSONObject.put("dataType", paramQuickSearchAttrConfig.getDataType());
/* 156 */     paramQuickSearch.setValueAttrConfig(localJSONObject.toString());
/*     */   }
/*     */ 
/*     */   private void initStructure(QuickSearch paramQuickSearch, QuickSearchConfig paramQuickSearchConfig)
/*     */   {
/* 166 */     int i = 0;
/* 167 */     int j = 0;
/* 168 */     if ("sql".equals(paramQuickSearchConfig.getQueryLanguageType())) {
/* 169 */       j = 1;
/* 170 */       if (paramQuickSearchConfig.getQueryTable().split(",").length > 1) {
/* 171 */         i = 1;
/*     */       }
/*     */     }
/* 174 */     String str1 = paramQuickSearchConfig.getCodeAttr();
/* 175 */     if (str1.contains(".")) {
/* 176 */       str1 = str1.split("\\.")[1];
/*     */     }
/* 178 */     String str2 = paramQuickSearchConfig.getValueAttr();
/* 179 */     if (str2.contains(".")) {
/* 180 */       str2 = str2.split("\\.")[1];
/*     */     }
/* 182 */     List localList = this.quickSearchDAO.getDisplayItemsByQuickSearchId(paramQuickSearchConfig.getId(), false, str1, str2);
/* 183 */     if (localList != null) {
/* 184 */       JSONArray localJSONArray = new JSONArray();
/* 185 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { localObject = (QuickSearchAttrConfig)localIterator.next();
/*     */ 
/* 187 */         if (((QuickSearchAttrConfig)localObject).getAttr().equals(str1)) {
/* 188 */           initCodeAttrConfig(paramQuickSearch, str1, (QuickSearchAttrConfig)localObject);
/*     */         }
/*     */ 
/* 191 */         if (((QuickSearchAttrConfig)localObject).getAttr().equals(str2)) {
/* 192 */           initValueAttrConfig(paramQuickSearch, str2, (QuickSearchAttrConfig)localObject);
/*     */         }
/* 194 */         if (((QuickSearchAttrConfig)localObject).getDisplayItemEnabled().booleanValue()) {
/* 195 */           JSONObject localJSONObject = new JSONObject();
/* 196 */           localJSONObject.put("title", ((QuickSearchAttrConfig)localObject).getTitle());
/* 197 */           if (j != 0) {
/* 198 */             if (i != 0)
/* 199 */               localJSONObject.put("field", HSUtil.getJavaName(((QuickSearchAttrConfig)localObject).getAlias() + "_" + ((QuickSearchAttrConfig)localObject).getAttr()));
/*     */             else
/* 201 */               localJSONObject.put("field", HSUtil.getJavaName(((QuickSearchAttrConfig)localObject).getAttr()));
/*     */           }
/*     */           else {
/* 204 */             localJSONObject.put("field", ((QuickSearchAttrConfig)localObject).getAttr());
/*     */           }
/* 206 */           localJSONObject.put("alias", ((QuickSearchAttrConfig)localObject).getAlias());
/* 207 */           localJSONObject.put("attr", ((QuickSearchAttrConfig)localObject).getAttr());
/* 208 */           localJSONObject.put("dataType", Integer.valueOf(((QuickSearchAttrConfig)localObject).getDataType()));
/* 209 */           localJSONObject.put("width", ((QuickSearchAttrConfig)localObject).getColumnWidth() + "%");
/* 210 */           localJSONArray.add(localJSONObject);
/*     */         }
/*     */       }
/* 213 */       Object localObject = new JSONObject();
/* 214 */       ((JSONObject)localObject).put("rows", localJSONArray);
/* 215 */       paramQuickSearch.setStructure(((JSONObject)localObject).toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initDialogStructure(QuickSearch paramQuickSearch, QuickSearchConfig paramQuickSearchConfig)
/*     */   {
/* 227 */     int i = 0;
/* 228 */     int j = 0;
/* 229 */     if ("sql".equals(paramQuickSearchConfig.getQueryLanguageType())) {
/* 230 */       j = 1;
/* 231 */       if (paramQuickSearchConfig.getQueryTable().trim().split(",").length > 1) {
/* 232 */         i = 1;
/*     */       }
/*     */     }
/* 235 */     List localList = this.quickSearchDAO.getQueryDisplayItemsByQuickSearchId(paramQuickSearchConfig.getId());
/* 236 */     if (localList != null) {
/* 237 */       JSONObject localJSONObject1 = new JSONObject();
/* 238 */       String str1 = null;
/* 239 */       String str2 = null;
/* 240 */       for (QuickSearchAttrConfig localQuickSearchAttrConfig : localList) {
/* 241 */         JSONObject localJSONObject2 = new JSONObject();
/* 242 */         str1 = localQuickSearchAttrConfig.getAlias();
/* 243 */         str2 = localQuickSearchAttrConfig.getAttr();
/* 244 */         localJSONObject2.put("alias", localQuickSearchAttrConfig.getAlias());
/* 245 */         localJSONObject2.put("label", localQuickSearchAttrConfig.getTitle());
/* 246 */         localJSONObject2.put("store", localQuickSearchAttrConfig.getCodeList());
/* 247 */         if (j != 0) {
/* 248 */           if (i != 0)
/* 249 */             localJSONObject2.put("sqlAttr", HSUtil.getJavaName(str1 + "_" + str2));
/*     */           else {
/* 251 */             localJSONObject2.put("sqlAttr", HSUtil.getJavaName(str2));
/*     */           }
/*     */         }
/* 254 */         String str3 = localQuickSearchAttrConfig.getColumnWidth();
/* 255 */         if (str3 != null) {
/* 256 */           if (str3.trim().endsWith("%"))
/* 257 */             localJSONObject2.put("width", str3);
/*     */           else {
/* 259 */             localJSONObject2.put("width", str3 + "px");
/*     */           }
/*     */         }
/* 262 */         localJSONObject2.put("dataType", Integer.valueOf(localQuickSearchAttrConfig.getDataType()));
/* 263 */         if (localQuickSearchAttrConfig.getQueryItemEnabled().booleanValue()) {
/* 264 */           localJSONObject2.put("queryItem", Boolean.valueOf(true));
/*     */         }
/* 266 */         if (localQuickSearchAttrConfig.getDisplayItemEnabled().booleanValue()) {
/* 267 */           localJSONObject2.put("displayItem", Boolean.valueOf(true));
/*     */         }
/* 269 */         if (localQuickSearchAttrConfig.getCodeList() != null) {
/* 270 */           localJSONObject2.put("displayAttr", "CODENAME");
/* 271 */           localJSONObject2.put("valueAttr", "CODEVALUE");
/*     */         }
/* 273 */         localJSONObject1.put(localQuickSearchAttrConfig.getAttr(), localJSONObject2);
/*     */       }
/* 275 */       paramQuickSearch.setQueryConfig(localJSONObject1.toString());
/* 276 */       paramQuickSearch.setQueryAliasName(str1);
/*     */     }
/*     */   }
/*     */ 
/*     */   public QueryResult getAllQuickSearchConfig()
/*     */   {
/* 284 */     return this.quickSearchDAO.getAllQuickSearchConfig();
/*     */   }
/*     */ 
/*     */   public QueryResult getQuickSearchConfigByName(String paramString)
/*     */   {
/* 291 */     return this.quickSearchDAO.getQuickSearchConfigByName(paramString);
/*     */   }
/*     */ 
/*     */   public void deleteQuickSearchConfigList(List<QuickSearchConfig> paramList)
/*     */   {
/* 299 */     this.quickSearchDAO.deleteQuickSearchConfigList(paramList);
/*     */   }
/*     */ 
/*     */   public List<String> getDataSourceNames()
/*     */   {
/* 307 */     Map localMap = DataSourceContextHolder.getDataSources();
/*     */     Object localObject2;
/* 308 */     if ((localMap == null) || (localMap.isEmpty()))
/*     */     {
/* 310 */       localObject1 = 
/* 311 */         WebApplicationContextUtils.getRequiredWebApplicationContext(
/* 312 */         I18nGlobalContext.getInstance().getServletContext());
/* 313 */       localObject2 = (DefaultListableBeanFactory)((WebApplicationContext)localObject1)
/* 314 */         .getAutowireCapableBeanFactory();
/* 315 */       String[] arrayOfString1 = ((DefaultListableBeanFactory)localObject2)
/* 316 */         .getBeanNamesForType(LocalSessionFactoryBean.class);
/* 317 */       if ((arrayOfString1 != null) && (arrayOfString1.length > 0)) {
/* 318 */         ArrayList localArrayList = new ArrayList(arrayOfString1.length);
/* 319 */         for (String str1 : arrayOfString1) {
/* 320 */           if (str1.startsWith("&")) {
/* 321 */             str1 = str1.replace("&", "");
/*     */           }
/* 323 */           String str2 = ((RuntimeBeanReference)((DefaultListableBeanFactory)localObject2)
/* 324 */             .getBeanDefinition(str1).getPropertyValues()
/* 325 */             .getPropertyValue("dataSource").getValue())
/* 326 */             .getBeanName();
/* 327 */           if (!localArrayList.contains(str2)) {
/* 328 */             localArrayList.add(str2);
/*     */           }
/*     */         }
/* 331 */         if (!localArrayList.isEmpty()) {
/* 332 */           return localArrayList;
/*     */         }
/* 334 */         localArrayList.add(
/* 337 */           ((RuntimeBeanReference)((DefaultListableBeanFactory)localObject2)
/* 335 */           .getBeanDefinition("sessionFactory")
/* 336 */           .getPropertyValues().getPropertyValue("dataSource")
/* 337 */           .getValue()).getBeanName());
/* 338 */         return localArrayList;
/*     */       }
/*     */     }
/*     */     else {
/* 342 */       localObject1 = localMap.values();
/* 343 */       localObject2 = new ArrayList(((Collection)localObject1).size());
/* 344 */       ((List)localObject2).addAll((Collection)localObject1);
/* 345 */       return localObject2;
/*     */     }
/* 347 */     Object localObject1 = new ArrayList(1);
/* 348 */     ((List)localObject1).add("dataSource");
/* 349 */     return localObject1;
/*     */   }
/*     */ 
/*     */   public void updateDataSourceNames()
/*     */   {
/* 356 */     List localList = getDataSourceNames();
/* 357 */     CodeList localCodeList = new CodeList();
/* 358 */     localCodeList.setName("quicksearch_datasource");
/* 359 */     ArrayList localArrayList = new ArrayList();
/* 360 */     for (int i = 0; i < localList.size(); i++) {
/* 361 */       Code localCode = new Code();
/* 362 */       localCode.setCodeValue((String)localList.get(i));
/* 363 */       localCode.setCodeName((String)localList.get(i));
/* 364 */       localArrayList.add(localCode);
/*     */     }
/*     */ 
/* 367 */     localCodeList.setCodeListByDefaultLocale(localArrayList);
/*     */ 
/* 369 */     this.codeListManager.putCodeList(localCodeList);
/*     */   }
/*     */ 
/*     */   public CodeList getTableNames(String paramString)
/*     */   {
/* 376 */     return this.quickSearchDAO.getTableNames(paramString);
/*     */   }
/*     */ 
/*     */   public BOContext getTableColumnInfos(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2)
/*     */   {
/* 385 */     if ((paramString3 == null) || (!paramBoolean2)) {
/* 386 */       return this.quickSearchDAO.getTableColumnInfos(paramString1, paramString2, 
/* 387 */         paramBoolean1, paramString4);
/*     */     }
/* 389 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 390 */     List localList = this.quickSearchDAO.getQuickSearchAttrConfigByQuickSearchId(
/* 391 */       paramString3, paramBoolean1);
/* 392 */     if (localList.isEmpty()) {
/* 393 */       return this.quickSearchDAO.getTableColumnInfos(paramString1, paramString2, 
/* 394 */         paramBoolean1, paramString4);
/*     */     }
/* 396 */     if ("hql".equals(paramString4)) {
/* 397 */       localBOContextImpl.put("className", this.quickSearchDAO
/* 398 */         .getEntityNameByTableName(paramString2));
/*     */     }
/* 400 */     localBOContextImpl.put("isDialogAttr", Boolean.valueOf(paramBoolean1));
/* 401 */     localBOContextImpl.put("attrConfig", localList);
/* 402 */     return localBOContextImpl;
/*     */   }
/*     */ 
/*     */   public BOContext saveQuickSearchConfig(QuickSearchConfig paramQuickSearchConfig, List paramList1, List paramList2)
/*     */   {
/* 410 */     if ((paramQuickSearchConfig.getId() == null) && 
/* 411 */       (isQuickSearchNameExisted(paramQuickSearchConfig.getName()))) {
/* 412 */       throw new UniEAPBusinessException("EAPTECHRIA1005", 
/* 413 */         new Object[] { paramQuickSearchConfig.getName() });
/*     */     }
/* 415 */     return this.quickSearchDAO.saveQuickSearchConfig(paramQuickSearchConfig, paramList1, paramList2);
/*     */   }
/*     */ 
/*     */   public List getAllCodeList()
/*     */   {
/* 422 */     return this.codeListManager.getAllCodeList();
/*     */   }
/*     */ 
/*     */   public boolean isQuickSearchNameExisted(String paramString)
/*     */   {
/* 429 */     return this.quickSearchDAO.isQuickSearchNameExisted(paramString);
/*     */   }
/*     */ 
/*     */   public BOContext getQuickSearchConfig(String paramString)
/*     */   {
/* 436 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 437 */     QuickSearchConfig localQuickSearchConfig = this.quickSearchDAO.getQuickSearchConfigById(paramString);
/* 438 */     if (localQuickSearchConfig == null) {
/* 439 */       return localBOContextImpl;
/*     */     }
/* 441 */     localBOContextImpl.put("codeAttr", localQuickSearchConfig.getCodeAttr());
/* 442 */     localBOContextImpl.put("valueAttr", localQuickSearchConfig.getValueAttr());
/* 443 */     return localBOContextImpl;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.bo.impl.QuickSearchBOImpl
 * JD-Core Version:    0.6.2
 */