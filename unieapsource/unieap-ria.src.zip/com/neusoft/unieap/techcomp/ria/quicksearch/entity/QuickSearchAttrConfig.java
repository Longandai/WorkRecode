/*     */ package com.neusoft.unieap.techcomp.ria.quicksearch.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Date;
/*     */ import javax.validation.constraints.NotNull;
/*     */ import org.hibernate.validator.constraints.Length;
/*     */ 
/*     */ @ModelFile("quickSearchAttrConfig.entity")
/*     */ public class QuickSearchAttrConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String quicksearchId;
/*     */   private String alias;
/*     */   private String attr;
/*     */   private String title;
/*     */   private String dataType;
/*     */   private String codeList;
/*     */   private Integer attrOrder;
/*     */   private Boolean isDialogAttr;
/*     */   private Boolean queryItemEnabled;
/*     */   private Boolean displayItemEnabled;
/*     */   private String columnWidth;
/*     */   private String createdBy;
/*     */   private Date creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Date lastUpdateDate;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  97 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 101 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setQuicksearchId(String paramString) {
/* 105 */     this.quicksearchId = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.quicksearchId.length.message}")
/*     */   public String getQuicksearchId() {
/* 110 */     return this.quicksearchId;
/*     */   }
/*     */ 
/*     */   public void setAlias(String paramString) {
/* 114 */     this.alias = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.alias.notNull.message}")
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.alias.length.message}")
/*     */   public String getAlias() {
/* 120 */     return this.alias;
/*     */   }
/*     */ 
/*     */   public void setAttr(String paramString) {
/* 124 */     this.attr = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.attr.notNull.message}")
/*     */   @Length(max=128, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.attr.length.message}")
/*     */   public String getAttr() {
/* 130 */     return this.attr;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/* 134 */     this.title = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.title.notNull.message}")
/*     */   @Length(max=64, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.title.length.message}")
/*     */   public String getTitle() {
/* 140 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setDataType(String paramString) {
/* 144 */     this.dataType = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=64, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.dataType.length.message}")
/*     */   public String getDataType() {
/* 149 */     return this.dataType;
/*     */   }
/*     */ 
/*     */   public void setCodeList(String paramString) {
/* 153 */     this.codeList = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=64, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.codeList.length.message}")
/*     */   public String getCodeList() {
/* 158 */     return this.codeList;
/*     */   }
/*     */ 
/*     */   public void setAttrOrder(Integer paramInteger) {
/* 162 */     this.attrOrder = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getAttrOrder() {
/* 166 */     return this.attrOrder;
/*     */   }
/*     */ 
/*     */   public void setIsDialogAttr(Boolean paramBoolean) {
/* 170 */     this.isDialogAttr = paramBoolean;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.isDialogAttr.notNull.message}")
/*     */   public Boolean getIsDialogAttr() {
/* 175 */     return this.isDialogAttr;
/*     */   }
/*     */ 
/*     */   public void setQueryItemEnabled(Boolean paramBoolean) {
/* 179 */     this.queryItemEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.queryItemEnabled.notNull.message}")
/*     */   public Boolean getQueryItemEnabled() {
/* 184 */     return this.queryItemEnabled;
/*     */   }
/*     */ 
/*     */   public void setDisplayItemEnabled(Boolean paramBoolean) {
/* 188 */     this.displayItemEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.displayItemEnabled.notNull.message}")
/*     */   public Boolean getDisplayItemEnabled() {
/* 193 */     return this.displayItemEnabled;
/*     */   }
/*     */ 
/*     */   public void setColumnWidth(String paramString) {
/* 197 */     this.columnWidth = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=5, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.columnWidth.length.message}")
/*     */   public String getColumnWidth() {
/* 202 */     return this.columnWidth;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 206 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.createdBy.length.message}")
/*     */   public String getCreatedBy() {
/* 211 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date paramDate) {
/* 215 */     this.creationDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/* 219 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 223 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchAttrConfig.lastUpdatedBy.length.message}")
/*     */   public String getLastUpdatedBy() {
/* 228 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Date paramDate) {
/* 232 */     this.lastUpdateDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getLastUpdateDate() {
/* 236 */     return this.lastUpdateDate;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchAttrConfig
 * JD-Core Version:    0.6.2
 */