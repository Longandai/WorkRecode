package com.neusoft.unieap.techcomp.ria.quicksearch.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.core.common.bo.context.BOContext;
import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
import com.neusoft.unieap.techcomp.ria.quicksearch.dto.QuickSearch;
import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchConfig;
import java.util.List;
import java.util.Map;

public abstract interface QuickSearchDAO
{
  public abstract List query(String paramString1, String paramString2, Map<String, Object> paramMap, QuickSearch paramQuickSearch, boolean paramBoolean);

  public abstract QueryResult queryByAdvanceCondition(QuickSearch paramQuickSearch, Map paramMap, int paramInt1, int paramInt2);

  public abstract QueryResult queryByFormCondition(QuickSearch paramQuickSearch, Map paramMap1, Map paramMap2, int paramInt1, int paramInt2);

  public abstract QuickSearchConfig getQuickSearchConfigById(String paramString);

  public abstract QueryResult getAllQuickSearchConfig();

  public abstract QueryResult getQuickSearchConfigByName(String paramString);

  public abstract List getQuickSearchAttrConfigByQuickSearchId(String paramString, boolean paramBoolean);

  public abstract void deleteQuickSearchConfigList(List<QuickSearchConfig> paramList);

  public abstract CodeList getTableNames(String paramString);

  public abstract BOContext getTableColumnInfos(String paramString1, String paramString2, boolean paramBoolean, String paramString3);

  public abstract String getEntityNameByTableName(String paramString);

  public abstract BOContext saveQuickSearchConfig(QuickSearchConfig paramQuickSearchConfig, List paramList1, List paramList2);

  public abstract void deleteQuickSearchAttrConfigByQuickSearchId(String paramString);

  public abstract boolean isQuickSearchNameExisted(String paramString);

  public abstract List getDisplayItemsByQuickSearchId(String paramString1, boolean paramBoolean, String paramString2, String paramString3);

  public abstract List getQueryDisplayItemsByQuickSearchId(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.dao.QuickSearchDAO
 * JD-Core Version:    0.6.2
 */