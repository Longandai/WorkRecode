package com.neusoft.unieap.techcomp.ria.quicksearch.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.core.common.bo.context.BOContext;
import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
import com.neusoft.unieap.techcomp.ria.quicksearch.dto.QuickSearch;
import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchConfig;
import java.util.List;
import java.util.Map;

public abstract interface QuickSearchBO
{
  public abstract List query(String paramString1, String paramString2, QuickSearch paramQuickSearch, boolean paramBoolean, Map<String, Object> paramMap);

  public abstract QueryResult queryByAdvanceCondition(QuickSearch paramQuickSearch, int paramInt1, int paramInt2, Map paramMap);

  public abstract QueryResult queryByFormCondition(QuickSearch paramQuickSearch, Map paramMap1, int paramInt1, int paramInt2, Map paramMap2);

  public abstract QuickSearch getQuickSearch(String paramString);

  public abstract BOContext getQuickSearchConfig(String paramString);

  public abstract QueryResult getAllQuickSearchConfig();

  public abstract QueryResult getQuickSearchConfigByName(String paramString);

  public abstract void deleteQuickSearchConfigList(List<QuickSearchConfig> paramList);

  public abstract List<String> getDataSourceNames();

  public abstract void updateDataSourceNames();

  public abstract CodeList getTableNames(String paramString);

  public abstract BOContext getTableColumnInfos(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, String paramString4, boolean paramBoolean2);

  public abstract BOContext saveQuickSearchConfig(QuickSearchConfig paramQuickSearchConfig, List paramList1, List paramList2);

  public abstract List getAllCodeList();

  public abstract boolean isQuickSearchNameExisted(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.bo.QuickSearchBO
 * JD-Core Version:    0.6.2
 */