/*      */ package com.neusoft.unieap.techcomp.ria.quicksearch.dao.impl;
/*      */ 
/*      */ import com.neusoft.unieap.core.annotation.ModelFile;
/*      */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*      */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*      */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*      */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*      */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*      */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*      */ import com.neusoft.unieap.core.page.PageUtil;
/*      */ import com.neusoft.unieap.core.util.BeanUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*      */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.quicksearch.dao.QuickSearchDAO;
/*      */ import com.neusoft.unieap.techcomp.ria.quicksearch.dto.QuickSearch;
/*      */ import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchAttrConfig;
/*      */ import com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchConfig;
/*      */ import com.neusoft.unieap.techcomp.ria.quicksearch.util.TypeResolver;
/*      */ import com.neusoft.unieap.techcomp.ria.util.HSUtil;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.sql.DataSource;
/*      */ import net.sf.json.JSONObject;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.Query;
/*      */ import org.hibernate.SQLQuery;
/*      */ import org.hibernate.Session;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.dialect.SQLServerDialect;
/*      */ import org.hibernate.impl.SessionFactoryImpl;
/*      */ import org.hibernate.persister.entity.AbstractEntityPersister;
/*      */ import org.hibernate.transform.Transformers;
/*      */ import org.hibernate.type.ManyToOneType;
/*      */ import org.hibernate.type.OneToOneType;
/*      */ import org.hibernate.type.Type;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*      */ import org.springframework.orm.hibernate3.HibernateCallback;
/*      */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*      */ 
/*      */ @ModelFile("quickSearchDAO.dao")
/*      */ public class QuickSearchDAOImpl extends BaseHibernateDAO
/*      */   implements QuickSearchDAO
/*      */ {
/*      */   public List query(String id, final String keyword, final Map<String, Object> params, final QuickSearch config, final boolean isSetValue)
/*      */   {
/*   72 */     if ((params != null) && (params.size() == 1) && 
/*   73 */       (((String)params.keySet().iterator().next()).equals("")))
/*   74 */       params.clear();
/*      */     try
/*      */     {
/*   77 */       final QuickSearch quickSearch = (QuickSearch)BeanUtil.getBean(id);
/*   78 */       return getHibernateTemplate().executeFind(
/*   79 */         new HibernateCallback()
/*      */       {
/*      */         public Object doInHibernate(Session session) throws HibernateException, SQLException {
/*   82 */           String hql = quickSearch.getHql();
/*   83 */           if ((hql != null) && (hql.trim().length() > 0)) {
/*   84 */             Query query = session.createQuery(hql);
/*   85 */             if (quickSearch.getMax() > 0) {
/*   86 */               query.setMaxResults(quickSearch.getMax());
/*      */             }
/*   88 */             query.setParameter("query", keyword + "%");
/*   89 */             for (Iterator localIterator1 = params.keySet().iterator(); localIterator1.hasNext(); ) { Object key = localIterator1.next();
/*   90 */               query.setParameter((String)key, params
/*   91 */                 .get(key));
/*      */             }
/*   93 */             return query.list();
/*      */           }
/*   95 */           String sql = quickSearch.getSql();
/*   96 */           if ((sql != null) && (sql.trim().length() > 0)) {
/*   97 */             SQLQuery query = session.createSQLQuery(sql);
/*   98 */             if (quickSearch.getMax() > 0) {
/*   99 */               query.setMaxResults(quickSearch.getMax());
/*      */             }
/*  101 */             query.setParameter("query", keyword + "%");
/*  102 */             for (Iterator localIterator2 = params.keySet().iterator(); localIterator2.hasNext(); ) { Object key = localIterator2.next();
/*  103 */               query.setParameter((String)key, params
/*  104 */                 .get(key));
/*      */             }
/*  106 */             query
/*  107 */               .setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
/*  108 */             return query.list();
/*      */           }
/*  110 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */     catch (Exception localException) {
/*      */     }
/*  116 */     return getHibernateTemplate().executeFind(new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session session) throws HibernateException, SQLException {
/*  119 */         String match = config.getQueryMatch();
/*  120 */         String hql = config.getHql();
/*  121 */         String sql = config.getSql();
/*  122 */         int maxSize = config.getMax();
/*      */ 
/*  124 */         boolean isNumberType = false;
/*  125 */         boolean typeMisMatch = false;
/*  126 */         if ((hql != null) && (hql.trim().length() > 0))
/*      */         {
/*      */           JSONObject codeAttrConfig;
/*  127 */           if (isSetValue) {
/*  128 */             JSONObject valueAttrConfig = JSONObject.fromObject(config.getValueAttrConfig());
/*  129 */             if (valueAttrConfig != null) {
/*  130 */               String condition = valueAttrConfig.get("alias") + "." + valueAttrConfig.get("attr");
/*  131 */               if ("2".equals(valueAttrConfig.get("dataType"))) {
/*  132 */                 isNumberType = true;
/*      */                 try {
/*  134 */                   Long.parseLong(keyword);
/*      */                 } catch (NumberFormatException e) {
/*  136 */                   typeMisMatch = true;
/*      */                 }
/*      */               }
/*      */ 
/*  140 */               if (!typeMisMatch) {
/*  141 */                 if (hql.contains("where"))
/*  142 */                   hql = hql.substring(0, hql.indexOf("where")) + " where " + condition + " = :queryKeyWord";
/*      */                 else
/*  144 */                   hql = hql + " where " + condition + " = :queryKeyWord";
/*      */               }
/*      */               else
/*      */               {
/*  148 */                 codeAttrConfig = JSONObject.fromObject(config.getCodeAttrConfig());
/*  149 */                 if (codeAttrConfig != null) {
/*  150 */                   condition = codeAttrConfig.get("alias") + "." + codeAttrConfig.get("attr");
/*  151 */                   if (hql.contains("where"))
/*  152 */                     hql = hql.substring(0, hql.indexOf("where")) + " where " + condition + " = :queryKeyWord";
/*      */                   else {
/*  154 */                     hql = hql + " where " + condition + " = :queryKeyWord";
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  160 */           Query query = session.createQuery(hql);
/*  161 */           if (maxSize > 0) {
/*  162 */             query.setMaxResults(maxSize);
/*      */           }
/*  164 */           if (!isSetValue) {
/*  165 */             if ("allMatch".equals(match))
/*  166 */               query.setParameter("query", "%" + keyword + "%");
/*  167 */             else if ("leftMatch".equals(match))
/*  168 */               query.setParameter("query", "%" + keyword);
/*      */             else {
/*  170 */               query.setParameter("query", keyword + "%");
/*      */             }
/*  172 */             for (codeAttrConfig = params.keySet().iterator(); codeAttrConfig.hasNext(); ) { Object key = codeAttrConfig.next();
/*  173 */               query.setParameter((String)key, params.get(key));
/*      */             }
/*      */           }
/*      */ 
/*  177 */           if (isSetValue) {
/*  178 */             if ((isNumberType) && (!typeMisMatch))
/*      */             {
/*  180 */               query.setParameter("queryKeyWord", Long.valueOf(keyword));
/*      */             }
/*  182 */             else query.setParameter("queryKeyWord", keyword);
/*      */ 
/*      */           }
/*      */ 
/*  186 */           List resultList = query.list();
/*  187 */           if ((resultList != null) && (resultList.size() > 0) && 
/*  188 */             (isSetValue)) {
/*  189 */             List newList = new ArrayList();
/*  190 */             newList.add(resultList.get(0));
/*  191 */             return newList;
/*      */           }
/*      */ 
/*  194 */           return resultList;
/*  195 */         }if ((sql != null) && (sql.trim().length() > 0))
/*      */         {
/*      */           JSONObject codeAttrConfig;
/*  196 */           if (isSetValue) {
/*  197 */             JSONObject valueAttrConfig = JSONObject.fromObject(config.getValueAttrConfig());
/*  198 */             if (valueAttrConfig != null) {
/*  199 */               String condition = valueAttrConfig.get("alias") + "." + valueAttrConfig.get("attr");
/*  200 */               if ("2".equals(valueAttrConfig.get("dataType"))) {
/*  201 */                 isNumberType = true;
/*      */                 try {
/*  203 */                   Long.parseLong(keyword);
/*      */                 } catch (NumberFormatException e) {
/*  205 */                   typeMisMatch = true;
/*      */                 }
/*      */               }
/*      */ 
/*  209 */               if (!typeMisMatch) {
/*  210 */                 if (sql.contains("where"))
/*  211 */                   sql = sql.substring(0, sql.indexOf("where")) + " where " + condition + " = :queryKeyWord";
/*      */                 else
/*  213 */                   sql = sql + " where " + condition + " = :queryKeyWord";
/*      */               }
/*      */               else
/*      */               {
/*  217 */                 codeAttrConfig = JSONObject.fromObject(config.getCodeAttrConfig());
/*  218 */                 if (codeAttrConfig != null) {
/*  219 */                   condition = codeAttrConfig.get("alias") + "." + codeAttrConfig.get("attr");
/*  220 */                   if (sql.contains("where"))
/*  221 */                     sql = sql.substring(0, sql.indexOf("where")) + " where " + condition + " = :queryKeyWord";
/*      */                   else {
/*  223 */                     sql = sql + " where " + condition + " = :queryKeyWord";
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*      */           }
/*  229 */           SQLQuery query = session.createSQLQuery(sql);
/*  230 */           if (maxSize > 0) {
/*  231 */             query.setMaxResults(maxSize);
/*      */           }
/*  233 */           if (!isSetValue) {
/*  234 */             if ("allMatch".equals(match))
/*  235 */               query.setParameter("query", "%" + keyword + "%");
/*  236 */             else if ("leftMatch".equals(match))
/*  237 */               query.setParameter("query", "%" + keyword);
/*      */             else {
/*  239 */               query.setParameter("query", keyword + "%");
/*      */             }
/*  241 */             for (codeAttrConfig = params.keySet().iterator(); codeAttrConfig.hasNext(); ) { Object key = codeAttrConfig.next();
/*  242 */               query.setParameter((String)key, params.get(key));
/*      */             }
/*      */           }
/*  245 */           if (isSetValue) {
/*  246 */             if ((isNumberType) && (!typeMisMatch))
/*      */             {
/*  248 */               query.setParameter("queryKeyWord", Long.valueOf(keyword));
/*      */             }
/*  250 */             else query.setParameter("queryKeyWord", keyword);
/*      */           }
/*      */ 
/*  253 */           query
/*  254 */             .setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
/*  255 */           List list = query.list();
/*  256 */           if (list != null) {
/*  257 */             int size = list.size();
/*  258 */             List newList = new ArrayList(size);
/*  259 */             for (int i = 0; i < size; i++) {
/*  260 */               Map map = (Map)list.get(i);
/*  261 */               Map newMap = new HashMap(map.size());
/*  262 */               Iterator it = map.entrySet().iterator();
/*  263 */               while (it.hasNext()) {
/*  264 */                 Map.Entry entry = (Map.Entry)it.next();
/*  265 */                 String key = String.valueOf(entry.getKey());
/*  266 */                 Object value = entry.getValue();
/*  267 */                 newMap.put(HSUtil.getJavaName(key), value);
/*      */               }
/*  269 */               newList.add(newMap);
/*      */             }
/*  271 */             if ((isSetValue) && (size > 0)) {
/*  272 */               List resultList = new ArrayList();
/*  273 */               resultList.add(newList.get(0));
/*  274 */               return resultList;
/*      */             }
/*  276 */             return newList;
/*      */           }
/*  278 */           return null;
/*      */         }
/*      */ 
/*  281 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public QueryResult queryByAdvanceCondition(QuickSearch config, Map params, int pageNumber, int pageSize)
/*      */   {
/*  291 */     String hql = config.getQueryHql();
/*  292 */     if ((hql != null) && (hql.trim().length() > 0)) {
/*  293 */       List paramList = new ArrayList();
/*      */ 
/*  295 */       if ((params != null) && (params.size() > 0)) {
/*  296 */         for (Iterator localIterator = params.keySet().iterator(); localIterator.hasNext(); ) { Object key = localIterator.next();
/*  297 */           if (!"".equals(key)) {
/*  298 */             String paramValue = (String)params.get(key);
/*  299 */             hql = hql.replace(":" + key, "?");
/*  300 */             paramList.add(paramValue);
/*      */           }
/*      */         }
/*      */       }
/*  304 */       String condition = AdvanceQueryUtil.getHQLCondition(config
/*  305 */         .getQueryAliasName());
/*  306 */       if ((condition == null) || (condition.trim().length() == 0)) {
/*  307 */         return queryObjectsByPage(hql, paramList.toArray());
/*      */       }
/*  309 */       paramList.addAll(Arrays.asList(
/*  310 */         AdvanceQueryUtil.getHQLConditionValues()));
/*      */ 
/*  312 */       if (hql.contains("where"))
/*  313 */         hql = hql + " and " + condition;
/*      */       else {
/*  315 */         hql = hql + " where " + condition;
/*      */       }
/*      */ 
/*  318 */       PageUtil.setPageNumber(pageNumber);
/*  319 */       if (pageSize > 0)
/*  320 */         PageUtil.setPageSize(pageSize);
/*      */       else {
/*  322 */         PageUtil.setPageSize(-1);
/*      */       }
/*  324 */       PageUtil.setAutoCalcCount(true);
/*  325 */       return queryObjectsByPage(hql, paramList.toArray());
/*      */     }
/*  327 */     return null;
/*      */   }
/*      */ 
/*      */   public QueryResult queryByFormCondition(QuickSearch config, Map map, Map params, int pageNumber, int pageSize)
/*      */   {
/*  336 */     String type = "hql";
/*  337 */     String match = config.getQueryMatch();
/*  338 */     String language = config.getQueryHql();
/*  339 */     if ((language == null) || (language.trim().length() == 0)) {
/*  340 */       language = config.getQuerySql();
/*  341 */       if ((language != null) && (language.trim().length() > 0)) {
/*  342 */         type = "sql";
/*      */       }
/*      */     }
/*  345 */     PageUtil.setPageNumber(pageNumber);
/*  346 */     if (pageSize > 0)
/*  347 */       PageUtil.setPageSize(pageSize);
/*      */     else {
/*  349 */       PageUtil.setPageSize(-1);
/*      */     }
/*  351 */     PageUtil.setAutoCalcCount(true);
/*      */ 
/*  353 */     List paramList = new ArrayList();
/*      */ 
/*  355 */     String[] tempStrs = language.split(":");
/*  356 */     int tempLength = tempStrs.length;
/*  357 */     if (tempLength > 0) {
/*  358 */       for (int x = 1; x < tempLength; x++) {
/*  359 */         for (Iterator localIterator1 = params.keySet().iterator(); localIterator1.hasNext(); ) { Object key = localIterator1.next();
/*  360 */           if (tempStrs[x].startsWith(key.toString())) {
/*  361 */             String paramValue = (String)params.get(key);
/*  362 */             language = language.replace(":" + key, "?");
/*  363 */             paramList.add(paramValue);
/*  364 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  370 */     if (map != null) {
/*  371 */       if (language.contains("where"))
/*  372 */         language = language + " and";
/*      */       else {
/*  374 */         language = language + " where";
/*      */       }
/*      */ 
/*  377 */       String queryConfig = config.getQueryConfig();
/*  378 */       JSONObject configJson = JSONObject.fromObject(queryConfig);
/*  379 */       Iterator configIter = configJson.entrySet().iterator();
/*  380 */       List dateList = new ArrayList();
/*  381 */       List numberList = new ArrayList();
/*  382 */       while (configIter.hasNext()) {
/*  383 */         Map.Entry entry = (Map.Entry)configIter.next();
/*  384 */         Object obj = entry.getKey();
/*  385 */         JSONObject jsonObj = configJson.getJSONObject(String.valueOf(obj));
/*  386 */         if (jsonObj != null) {
/*  387 */           if ("91".equals(jsonObj.getString("dataType")))
/*  388 */             dateList.add(jsonObj.getString("alias") + "." + String.valueOf(obj));
/*  389 */           else if ("2".equals(jsonObj.getString("dataType"))) {
/*  390 */             numberList.add(jsonObj.getString("alias") + "." + String.valueOf(obj));
/*      */           }
/*      */         }
/*      */       }
/*  394 */       int size = map.size();
/*  395 */       Iterator iter = map.entrySet().iterator();
/*  396 */       while (iter.hasNext()) {
/*  397 */         Map.Entry entry = (Map.Entry)iter.next();
/*  398 */         Object obj = entry.getValue();
/*  399 */         if ((obj != null) && (obj.toString().trim().length() != 0))
/*      */         {
/*  402 */           language = language + " " + entry.getKey();
/*  403 */           if (dateList.contains(String.valueOf(entry.getKey())))
/*      */           {
/*  405 */             language = language + " = ? ";
/*  406 */             language = language + " and";
/*  407 */             paramList.add(new Date(Long.valueOf(String.valueOf(obj)).longValue()));
/*  408 */           } else if (numberList.contains(String.valueOf(entry.getKey())))
/*      */           {
/*  410 */             language = language + " = ? ";
/*  411 */             language = language + " and";
/*  412 */             paramList.add(obj);
/*      */           } else {
/*  414 */             language = language + " like ? ";
/*  415 */             language = language + " and";
/*  416 */             if ("allMatch".equals(match))
/*  417 */               paramList.add("%" + obj + "%");
/*  418 */             else if ("leftMatch".equals(match))
/*  419 */               paramList.add("%" + obj);
/*      */             else {
/*  421 */               paramList.add(obj + "%");
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  426 */       if (language.endsWith("and"))
/*  427 */         language = language.substring(0, language.length() - 3);
/*  428 */       else if (language.endsWith("where")) {
/*  429 */         language = language.substring(0, language.length() - 5);
/*      */       }
/*      */     }
/*  432 */     Object[] arg1 = (Object[])null;
/*  433 */     if (language.indexOf("?") > 0) {
/*  434 */       arg1 = paramList.toArray();
/*      */     }
/*      */ 
/*  437 */     if ("hql".equals(type)) {
/*  438 */       return queryObjectsByPage(language, arg1);
/*      */     }
/*  440 */     return query(language, arg1);
/*      */   }
/*      */ 
/*      */   public QueryResult getAllQuickSearchConfig()
/*      */   {
/*  448 */     String hql = "from QuickSearchConfig quickSearchConfig order by quickSearchConfig.name ";
/*  449 */     QueryResult result = queryObjectsByPage(hql, null);
/*  450 */     return result;
/*      */   }
/*      */ 
/*      */   public QueryResult getQuickSearchConfigByName(String name)
/*      */   {
/*  457 */     String hql = "from QuickSearchConfig quickSearchConfig where quickSearchConfig.name like ? order by quickSearchConfig.name ";
/*      */ 
/*  459 */     QueryResult result = queryObjectsByPage(hql, 
/*  460 */       new Object[] { '%' + name + '%' });
/*  461 */     return result;
/*      */   }
/*      */ 
/*      */   public void deleteQuickSearchConfigList(List<QuickSearchConfig> quicksearchList)
/*      */   {
/*  469 */     getHibernateTemplate().deleteAll(quicksearchList);
/*  470 */     if ((quicksearchList != null) && (quicksearchList.size() > 0))
/*  471 */       for (QuickSearchConfig config : quicksearchList)
/*  472 */         deleteQuickSearchAttrConfigByQuickSearchId(config.getId());
/*      */   }
/*      */ 
/*      */   public List getQuickSearchAttrConfigByQuickSearchId(String id, boolean isDialogAttr)
/*      */   {
/*  482 */     String hql = "from QuickSearchAttrConfig quickSearchAttrConfig where quickSearchAttrConfig.quicksearchId = ? and quickSearchAttrConfig.isDialogAttr = ? order by quickSearchAttrConfig.attrOrder";
/*      */ 
/*  484 */     return getHibernateTemplate().find(hql, 
/*  485 */       new Object[] { id, Boolean.valueOf(isDialogAttr) });
/*      */   }
/*      */ 
/*      */   public CodeList getTableNames(String dataSourceId)
/*      */   {
/*  492 */     Map dataSourceMap = DataSourceContextHolder.getDataSources();
/*  493 */     if ((dataSourceMap != null) && (dataSourceMap.size() > 0)) {
/*  494 */       Set keySet = dataSourceMap.keySet();
/*  495 */       for (String key : keySet) {
/*  496 */         if (dataSourceId.equals(dataSourceMap.get(key))) {
/*  497 */           dataSourceId = key;
/*  498 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  502 */     DataSource ds = null;
/*      */     try {
/*  504 */       ds = (DataSource)BeanUtil.getBean(dataSourceId);
/*      */     } catch (NoSuchBeanDefinitionException e) {
/*  506 */       throw new UniEAPBusinessException("EAPTECHRIA1006", new Object[] { dataSourceId });
/*      */     }
/*  508 */     Connection con = DataSourceUtils.getConnection(ds);
/*  509 */     DatabaseMetaData metadata = null;
/*      */     try {
/*  511 */       metadata = con.getMetaData();
/*      */     } catch (SQLException e) {
/*  513 */       e.printStackTrace();
/*      */     }
/*  515 */     Dialect dialect = ((SessionFactoryImpl)getSessionFactory())
/*  516 */       .getDialect();
/*      */ 
/*  518 */     CodeList codelist = new CodeList();
/*  519 */     codelist.setName("quicksearch_table");
/*      */ 
/*  521 */     List codes = new ArrayList();
/*  522 */     ResultSet rs = null;
/*      */     try {
/*  524 */       String schemaPattern = metadata.getUserName();
/*  525 */       if (schemaPattern != null) {
/*  526 */         schemaPattern = schemaPattern.toUpperCase();
/*      */       }
/*      */ 
/*  529 */       if ((dialect instanceof SQLServerDialect)) {
/*  530 */         schemaPattern = null;
/*      */       }
/*  532 */       rs = metadata.getTables(null, schemaPattern, "%", new String[] { "TABLE", "VIEW" });
/*  533 */       String TABLE_NAME = "TABLE_NAME";
/*  534 */       String TABLE_TYPE = "TABLE_TYPE";
/*  535 */       String SYSTEM = "SYSTEM";
/*  536 */       List sysList = null;
/*  537 */       if ((dialect instanceof SQLServerDialect)) {
/*  538 */         String[] sys = { "sys", "INFORMATION_SCHEMA" };
/*  539 */         sysList = Arrays.asList(sys);
/*      */       }
/*  541 */       while (rs.next()) {
/*  542 */         String tableName = rs.getString(TABLE_NAME);
/*  543 */         String tableType = rs.getString(TABLE_TYPE);
/*  544 */         if ((dialect instanceof SQLServerDialect))
/*      */         {
/*  545 */           String tableNamePre = rs.getString(2);
/*  546 */           if ((sysList != null) && (sysList.contains(tableNamePre)));
/*      */         }
/*  550 */         else if (((tableType == null) || 
/*  551 */           (tableType.toUpperCase().indexOf(SYSTEM) < 0)) && 
/*  552 */           (tableName.indexOf("$") == -1))
/*      */         {
/*  554 */           Code code = new Code();
/*  555 */           code.setCodeValue(tableName);
/*  556 */           code.setCodeName(tableName);
/*  557 */           codes.add(code);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  562 */       codelist.setCodeListByDefaultLocale(codes);
/*      */ 
/*  564 */       codelist.setCodeListByLocale("ja_JP", codes);
/*      */ 
/*  566 */       codelist.setCodeListByLocale("en_US", codes);
/*      */     } catch (SQLException e) {
/*  568 */       e.printStackTrace();
/*      */       try
/*      */       {
/*  571 */         con.close();
/*      */       } catch (SQLException e1) {
/*  573 */         e1.printStackTrace();
/*      */       }
/*  575 */       if (rs != null)
/*      */         try {
/*  577 */           rs.close();
/*      */         } catch (SQLException e) {
/*  579 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*      */       try
/*      */       {
/*  571 */         con.close();
/*      */       } catch (SQLException e1) {
/*  573 */         e1.printStackTrace();
/*      */       }
/*  575 */       if (rs != null) {
/*      */         try {
/*  577 */           rs.close();
/*      */         } catch (SQLException e) {
/*  579 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  584 */     return codelist;
/*      */   }
/*      */ 
/*      */   public BOContext getTableColumnInfos(String dataSourceId, String tableName, boolean isDialogAttr, String queryType)
/*      */   {
/*  592 */     if ("hql".equals(queryType)) {
/*  593 */       return getHQLAttrConfig(dataSourceId, tableName, isDialogAttr);
/*      */     }
/*  595 */     return getSQLAttrConfig(dataSourceId, tableName, isDialogAttr);
/*      */   }
/*      */ 
/*      */   private BOContext getHQLAttrConfig(String dataSourceId, String tableName, boolean isDialogAttr)
/*      */   {
/*  609 */     BOContext bc = new BOContextImpl();
/*  610 */     AbstractEntityPersister classMetadata = null;
/*  611 */     Map map = getSessionFactory().getAllClassMetadata();
/*  612 */     Collection values = map.values();
/*  613 */     Iterator iter = values.iterator();
/*  614 */     while (iter.hasNext()) {
/*  615 */       classMetadata = (AbstractEntityPersister)iter.next();
/*  616 */       if (tableName.equals(classMetadata.getTableName())) {
/*  617 */         bc.put("className", classMetadata.getEntityName());
/*  618 */         break;
/*      */       }
/*      */     }
/*  621 */     Map dataSourceMap = DataSourceContextHolder.getDataSources();
/*  622 */     if ((dataSourceMap != null) && (dataSourceMap.size() > 0)) {
/*  623 */       Set keySet = dataSourceMap.keySet();
/*  624 */       for (String key : keySet) {
/*  625 */         if (dataSourceId.equals(dataSourceMap.get(key))) {
/*  626 */           dataSourceId = key;
/*  627 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  631 */     DataSource ds = (DataSource)BeanUtil.getBean(dataSourceId);
/*  632 */     Connection con = DataSourceUtils.getConnection(ds);
/*  633 */     DatabaseMetaData metadata = null;
/*      */     try {
/*  635 */       metadata = con.getMetaData();
/*      */     } catch (SQLException e) {
/*  637 */       e.printStackTrace();
/*      */     }
/*  639 */     List orderList = new ArrayList();
/*  640 */     orderList.add(Integer.valueOf(0));
/*  641 */     List attrList = handleHQLAttrConfig(tableName, 
/*  642 */       isDialogAttr, classMetadata, metadata, "", orderList, con);
/*  643 */     if (con != null) {
/*      */       try {
/*  645 */         con.close();
/*      */       } catch (SQLException e) {
/*  647 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  650 */     bc.put("attrConfig", attrList);
/*  651 */     bc.put("isDialogAttr", Boolean.valueOf(isDialogAttr));
/*  652 */     return bc;
/*      */   }
/*      */ 
/*      */   private List<QuickSearchAttrConfig> handleHQLAttrConfig(String tableName, boolean isDialogAttr, AbstractEntityPersister classMetadata, DatabaseMetaData metadata, String attrPrefix, List<Integer> orderList, Connection con)
/*      */   {
/*  670 */     int order = ((Integer)orderList.get(0)).intValue();
/*  671 */     List attrList = new ArrayList();
/*  672 */     Map manyToOneMap = new HashMap();
/*      */ 
/*  675 */     String schemaPattern = null;
/*  676 */     Dialect dialect = ((SessionFactoryImpl)getSessionFactory()).getDialect();
/*      */ 
/*  678 */     Map columnMap = null;
/*  679 */     if ((dialect instanceof SQLServerDialect)) {
/*  680 */       schemaPattern = null;
/*  681 */       columnMap = new HashMap();
/*      */     } else {
/*      */       try {
/*  684 */         schemaPattern = metadata.getUserName();
/*      */       } catch (SQLException e) {
/*  686 */         schemaPattern = null;
/*      */       }
/*      */     }
/*      */ 
/*  690 */     ResultSet column = null;
/*      */     try {
/*  692 */       column = metadata.getColumns(null, schemaPattern, 
/*  693 */         tableName, null);
/*  694 */       while (column.next()) {
/*  695 */         String columnName = column.getString("COLUMN_NAME");
/*  696 */         String originalColumnName = columnName;
/*  697 */         if (classMetadata != null) {
/*  698 */           String[] identifierColumnNames = classMetadata
/*  699 */             .getIdentifierColumnNames();
/*  700 */           if ((identifierColumnNames != null) && 
/*  701 */             (columnName.equals(identifierColumnNames[0]))) {
/*  702 */             columnName = classMetadata.getIdentifierPropertyName();
/*      */           } else {
/*  704 */             String[] propertyNames = classMetadata
/*  705 */               .getPropertyNames();
/*  706 */             boolean isProperty = false;
/*  707 */             for (String propertyName : propertyNames)
/*      */             {
/*  709 */               boolean isCollection = classMetadata
/*  710 */                 .getPropertyType(propertyName)
/*  711 */                 .isCollectionType();
/*  712 */               if (!isCollection) {
/*  713 */                 String[] propertyColumnNames = classMetadata
/*  714 */                   .getPropertyColumnNames(propertyName);
/*  715 */                 for (String tempColumnName : propertyColumnNames) {
/*  716 */                   if (columnName.equals(tempColumnName)) {
/*  717 */                     columnName = propertyName;
/*  718 */                     isProperty = true;
/*  719 */                     break;
/*      */                   }
/*      */                 }
/*      */               }
/*      */             }
/*  724 */             if (isProperty) {
/*  725 */               Type type = classMetadata
/*  726 */                 .getPropertyType(columnName);
/*  727 */               if (((type instanceof ManyToOneType)) || 
/*  728 */                 ((type instanceof OneToOneType))) {
/*  729 */                 manyToOneMap.put(columnName, type);
/*  730 */                 continue;
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  737 */         String label = column.getString("REMARKS");
/*  738 */         if ((label == null) || (label.equals("")))
/*  739 */           label = columnName;
/*      */         else {
/*  741 */           label = label.replaceAll("\"", "'");
/*      */         }
/*  743 */         String datatype = column.getString("TYPE_NAME");
/*  744 */         QuickSearchAttrConfig config = new QuickSearchAttrConfig();
/*  745 */         config.setAlias("t");
/*  746 */         config.setAttr(attrPrefix + columnName);
/*  747 */         config.setTitle(label);
/*  748 */         config.setAttrOrder(Integer.valueOf(order++));
/*  749 */         orderList.set(0, Integer.valueOf(order));
/*  750 */         config.setDataType(TypeResolver.resolveType(datatype));
/*  751 */         config.setQueryItemEnabled(Boolean.valueOf(false));
/*  752 */         config.setDisplayItemEnabled(Boolean.valueOf(false));
/*  753 */         config.setIsDialogAttr(Boolean.valueOf(isDialogAttr));
/*  754 */         attrList.add(config);
/*  755 */         if (columnMap != null)
/*  756 */           columnMap.put(config.getAttr(), originalColumnName);
/*      */       }
/*      */     }
/*      */     catch (SQLException e) {
/*  760 */       e.printStackTrace();
/*      */ 
/*  762 */       if (column != null)
/*      */         try {
/*  764 */           column.close();
/*      */         } catch (SQLException e) {
/*  766 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*  762 */       if (column != null) {
/*      */         try {
/*  764 */           column.close();
/*      */         } catch (SQLException e) {
/*  766 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  771 */     handleSQLServerAttrConfig(tableName, con, attrList, columnMap);
/*      */ 
/*  773 */     if (!manyToOneMap.isEmpty()) {
/*  774 */       Iterator iter = manyToOneMap.entrySet().iterator();
/*  775 */       while (iter.hasNext()) {
/*  776 */         Map.Entry entry = (Map.Entry)iter.next();
/*  777 */         String columnName = (String)entry.getKey();
/*  778 */         ManyToOneType type = (ManyToOneType)entry.getValue();
/*  779 */         String entityName = type.getAssociatedEntityName();
/*  780 */         AbstractEntityPersister manyToOneMetaData = 
/*  781 */           (AbstractEntityPersister)getSessionFactory().getAllClassMetadata().get(
/*  782 */           entityName);
/*  783 */         String relationTableName = manyToOneMetaData.getTableName();
/*      */ 
/*  785 */         if (!relationTableName.equals(tableName))
/*      */         {
/*  788 */           attrList.addAll(handleHQLAttrConfig(relationTableName, 
/*  789 */             isDialogAttr, manyToOneMetaData, metadata, attrPrefix + 
/*  790 */             columnName + ".", orderList, con));
/*      */         }
/*      */       }
/*      */     }
/*  793 */     return attrList;
/*      */   }
/*      */ 
/*      */   private BOContext getSQLAttrConfig(String dataSourceId, String tableName, boolean isDialogAttr)
/*      */   {
/*  806 */     BOContext bc = new BOContextImpl();
/*      */ 
/*  808 */     Map dataSourceMap = DataSourceContextHolder.getDataSources();
/*  809 */     if ((dataSourceMap != null) && (dataSourceMap.size() > 0)) {
/*  810 */       Set keySet = dataSourceMap.keySet();
/*  811 */       for (String key : keySet) {
/*  812 */         if (dataSourceId.equals(dataSourceMap.get(key))) {
/*  813 */           dataSourceId = key;
/*  814 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  818 */     DataSource ds = (DataSource)BeanUtil.getBean(dataSourceId);
/*  819 */     Connection con = DataSourceUtils.getConnection(ds);
/*  820 */     DatabaseMetaData metadata = null;
/*      */     try {
/*  822 */       metadata = con.getMetaData();
/*      */     } catch (SQLException e) {
/*  824 */       e.printStackTrace();
/*      */     }
/*  826 */     if (tableName != null) {
/*  827 */       String[] tableNames = tableName.trim().split(",");
/*  828 */       List attrList = null;
/*  829 */       List allAttrList = new ArrayList();
/*  830 */       int len = tableNames.length;
/*  831 */       if (len == 1) {
/*  832 */         attrList = handleSQLAttrConfig(tableNames[0], isDialogAttr, 
/*  833 */           metadata, "t", 0);
/*  834 */         handleSQLServerAttrConfig(tableNames[0], con, attrList, null);
/*  835 */         if (attrList != null)
/*  836 */           allAttrList.addAll(attrList);
/*      */       }
/*      */       else {
/*  839 */         for (int i = 0; i < len; i++) {
/*  840 */           attrList = handleSQLAttrConfig(tableNames[i], isDialogAttr, 
/*  841 */             metadata, "t" + i, 0);
/*  842 */           handleSQLServerAttrConfig(tableNames[i], con, attrList, null);
/*  843 */           if (attrList != null) {
/*  844 */             allAttrList.addAll(attrList);
/*      */           }
/*      */         }
/*      */       }
/*  848 */       bc.put("attrConfig", allAttrList);
/*      */     }
/*      */ 
/*  851 */     if (con != null) {
/*      */       try {
/*  853 */         con.close();
/*      */       } catch (SQLException e) {
/*  855 */         e.printStackTrace();
/*      */       }
/*      */     }
/*  858 */     bc.put("isDialogAttr", Boolean.valueOf(isDialogAttr));
/*  859 */     return bc;
/*      */   }
/*      */ 
/*      */   private List<QuickSearchAttrConfig> handleSQLAttrConfig(String tableName, boolean isDialogAttr, DatabaseMetaData metadata, String alias, int order)
/*      */   {
/*  874 */     List attrList = new ArrayList();
/*      */ 
/*  877 */     String schemaPattern = null;
/*  878 */     Dialect dialect = ((SessionFactoryImpl)getSessionFactory()).getDialect();
/*      */ 
/*  880 */     if ((dialect instanceof SQLServerDialect))
/*  881 */       schemaPattern = null;
/*      */     else {
/*      */       try {
/*  884 */         schemaPattern = metadata.getUserName();
/*      */       } catch (SQLException e) {
/*  886 */         schemaPattern = null;
/*      */       }
/*      */     }
/*      */ 
/*  890 */     ResultSet column = null;
/*      */     try {
/*  892 */       column = metadata.getColumns(null, schemaPattern, 
/*  893 */         tableName, null);
/*  894 */       while (column.next()) {
/*  895 */         String columnName = column.getString("COLUMN_NAME");
/*      */ 
/*  898 */         String label = column.getString("REMARKS");
/*  899 */         if ((label == null) || (label.equals("")))
/*  900 */           label = columnName;
/*      */         else {
/*  902 */           label = label.replaceAll("\"", "'");
/*      */         }
/*  904 */         String datatype = column.getString("TYPE_NAME");
/*  905 */         QuickSearchAttrConfig config = new QuickSearchAttrConfig();
/*  906 */         config.setAlias(alias);
/*  907 */         config.setAttr(columnName);
/*  908 */         config.setTitle(label);
/*  909 */         config.setAttrOrder(Integer.valueOf(order++));
/*  910 */         config.setDataType(TypeResolver.resolveType(datatype));
/*  911 */         config.setQueryItemEnabled(Boolean.valueOf(false));
/*  912 */         config.setDisplayItemEnabled(Boolean.valueOf(false));
/*  913 */         config.setIsDialogAttr(Boolean.valueOf(isDialogAttr));
/*  914 */         attrList.add(config);
/*      */       }
/*      */     } catch (SQLException e) {
/*  917 */       e.printStackTrace();
/*      */ 
/*  919 */       if (column != null)
/*      */         try {
/*  921 */           column.close();
/*      */         } catch (SQLException e) {
/*  923 */           e.printStackTrace();
/*      */         }
/*      */     }
/*      */     finally
/*      */     {
/*  919 */       if (column != null) {
/*      */         try {
/*  921 */           column.close();
/*      */         } catch (SQLException e) {
/*  923 */           e.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*  927 */     return attrList;
/*      */   }
/*      */ 
/*      */   private void handleSQLServerAttrConfig(String tableName, Connection con, List<QuickSearchAttrConfig> attrList, Map<String, String> columnMap)
/*      */   {
/*  939 */     Dialect dialect = ((SessionFactoryImpl)getSessionFactory())
/*  940 */       .getDialect();
/*  941 */     if ((dialect instanceof SQLServerDialect)) {
/*  942 */       PreparedStatement pstmt = null;
/*  943 */       ResultSet rs = null;
/*      */       try {
/*  945 */         String SQL = "SELECT row_number() over (order BY t1.字段代码)序号, cast(t1.[字段代码] as varchar(100)) as COLUMN_NAME,cast(t1.[字段名称] as varchar(100)),t1.类型 as TYPE_NAME,isnull(t2.主键,''), t1.可空,cast(t1.[备注] as varchar(200)) as REMARKS FROM (SELECT c.name 字段代码,value 字段名称, systypes.name 类型,case c.isnullable when 0 then '否' else '是' end  可空, c.length 长度,value 备注 FROM systypes,sys.sysobjects o,syscolumns c LEFT JOIN ::fn_listextendedproperty(N'MS_Description', N'user', N'dbo', N'table','" + 
/*  952 */           tableName + 
/*  953 */           "', N'column', default) d ON objname = c.name COLLATE Chinese_PRC_CI_AS WHERE  c.xusertype = systypes.xusertype  AND c.id = o.id AND o.name ='" + 
/*  954 */           tableName + 
/*  955 */           "') t1 " + 
/*  956 */           "LEFT JOIN (SELECT i.name 主键名称,c.name 主键 FROM sys.indexes i,sys.sysindexkeys sd, sys.all_columns c, sys.sysobjects o " + 
/*  957 */           "WHERE i.index_id = sd.indid AND i.object_id = o.id AND i.is_primary_key = 1 AND sd.id = o.id AND c.object_id = o.id AND c.column_id = sd.colid AND o.xtype='u' AND o.name ='" + 
/*  958 */           tableName + 
/*  959 */           "') t2 ON t1.字段代码 = t2.主键 ORDER BY t1.字段代码";
/*      */ 
/*  961 */         pstmt = con.prepareStatement(SQL);
/*  962 */         rs = pstmt.executeQuery();
/*  963 */         while (rs.next()) {
/*  964 */           String columnName = rs.getString("COLUMN_NAME");
/*  965 */           String label = rs.getString("remarks");
/*  966 */           if (label != null) {
/*  967 */             for (QuickSearchAttrConfig config : attrList)
/*  968 */               if (columnMap == null) {
/*  969 */                 if (config.getAttr().equals(columnName)) {
/*  970 */                   config.setTitle(label);
/*  971 */                   break;
/*      */                 }
/*      */               }
/*  974 */               else if (((String)columnMap.get(config.getAttr())).equals(columnName)) {
/*  975 */                 config.setTitle(label);
/*  976 */                 break;
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*  983 */         e.printStackTrace();
/*      */ 
/*  985 */         if (rs != null) {
/*      */           try {
/*  987 */             rs.close();
/*      */           } catch (SQLException e) {
/*  989 */             e.printStackTrace();
/*      */           }
/*      */         }
/*  992 */         if (pstmt != null)
/*      */           try {
/*  994 */             pstmt.close();
/*      */           } catch (SQLException e) {
/*  996 */             e.printStackTrace();
/*      */           }
/*      */       }
/*      */       finally
/*      */       {
/*  985 */         if (rs != null) {
/*      */           try {
/*  987 */             rs.close();
/*      */           } catch (SQLException e) {
/*  989 */             e.printStackTrace();
/*      */           }
/*      */         }
/*  992 */         if (pstmt != null)
/*      */           try {
/*  994 */             pstmt.close();
/*      */           } catch (SQLException e) {
/*  996 */             e.printStackTrace();
/*      */           }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getEntityNameByTableName(String tableName)
/*      */   {
/* 1007 */     Map map = getSessionFactory().getAllClassMetadata();
/* 1008 */     Collection values = map.values();
/* 1009 */     Iterator iter = values.iterator();
/* 1010 */     while (iter.hasNext()) {
/* 1011 */       AbstractEntityPersister classMetadata = 
/* 1012 */         (AbstractEntityPersister)iter
/* 1012 */         .next();
/* 1013 */       if (tableName.equals(classMetadata.getTableName())) {
/* 1014 */         return classMetadata.getEntityName();
/*      */       }
/*      */     }
/* 1017 */     return null;
/*      */   }
/*      */ 
/*      */   public BOContext saveQuickSearchConfig(QuickSearchConfig quickSearchConfig, List baseAttrConfigList, List dialogAttrConfigList)
/*      */   {
/* 1027 */     if (quickSearchConfig.getId() != null) {
/* 1028 */       deleteQuickSearchAttrConfigByQuickSearchId(quickSearchConfig
/* 1029 */         .getId());
/*      */     }
/*      */ 
/* 1032 */     getHibernateTemplate().saveOrUpdate(quickSearchConfig);
/*      */ 
/* 1035 */     if ((baseAttrConfigList != null) && (baseAttrConfigList.size() > 0)) {
/* 1036 */       int size = baseAttrConfigList.size();
/* 1037 */       QuickSearchAttrConfig attrConfig = null;
/* 1038 */       for (int i = 0; i < size; i++) {
/* 1039 */         attrConfig = (QuickSearchAttrConfig)baseAttrConfigList.get(i);
/* 1040 */         attrConfig.setId(null);
/* 1041 */         attrConfig.setQuicksearchId(quickSearchConfig.getId());
/* 1042 */         getHibernateTemplate().save(attrConfig);
/*      */       }
/*      */     }
/*      */ 
/* 1046 */     if ((quickSearchConfig.getDialogEnabled().booleanValue()) && 
/* 1047 */       (dialogAttrConfigList != null) && (dialogAttrConfigList.size() > 0)) {
/* 1048 */       int size = dialogAttrConfigList.size();
/* 1049 */       QuickSearchAttrConfig attrConfig = null;
/* 1050 */       for (int i = 0; i < size; i++) {
/* 1051 */         attrConfig = 
/* 1052 */           (QuickSearchAttrConfig)dialogAttrConfigList
/* 1052 */           .get(i);
/* 1053 */         attrConfig.setId(null);
/* 1054 */         attrConfig.setQuicksearchId(quickSearchConfig.getId());
/* 1055 */         getHibernateTemplate().save(attrConfig);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1060 */     BOContext bc = new BOContextImpl();
/* 1061 */     bc.put("configForm", quickSearchConfig);
/* 1062 */     bc.put("baseAttrGrid", baseAttrConfigList);
/* 1063 */     bc.put("dialogAttrGrid", dialogAttrConfigList);
/* 1064 */     return bc;
/*      */   }
/*      */ 
/*      */   public void deleteQuickSearchAttrConfigByQuickSearchId(String querySearchId)
/*      */   {
/* 1071 */     String hql = "delete from QuickSearchAttrConfig quickSearchAttrConfig where quickSearchAttrConfig.quicksearchId = ? ";
/* 1072 */     getHibernateTemplate().bulkUpdate(hql, querySearchId);
/*      */   }
/*      */ 
/*      */   public boolean isQuickSearchNameExisted(String name)
/*      */   {
/* 1079 */     String hql = "from QuickSearchConfig quickSearchConfig where quickSearchConfig.name = ? ";
/* 1080 */     List list = getHibernateTemplate().find(hql, name);
/* 1081 */     if ((list != null) && (list.size() > 0)) {
/* 1082 */       return true;
/*      */     }
/* 1084 */     return false;
/*      */   }
/*      */ 
/*      */   public QuickSearchConfig getQuickSearchConfigById(String name)
/*      */   {
/* 1091 */     String hql = "from QuickSearchConfig quickSearchConfig where quickSearchConfig.name = ? ";
/* 1092 */     List list = getHibernateTemplate().find(hql, name);
/* 1093 */     if ((list != null) && (list.size() > 0)) {
/* 1094 */       return (QuickSearchConfig)list.get(0);
/*      */     }
/* 1096 */     return null;
/*      */   }
/*      */ 
/*      */   public List getDisplayItemsByQuickSearchId(String id, boolean isDialogAttr, String codeAttr, String valueAttr)
/*      */   {
/* 1103 */     String hql = "from QuickSearchAttrConfig quickSearchAttrConfig where quickSearchAttrConfig.quicksearchId = ? and quickSearchAttrConfig.isDialogAttr = ? and (quickSearchAttrConfig.displayItemEnabled = ? or quickSearchAttrConfig.attr = ? or  quickSearchAttrConfig.attr = ? ) order by quickSearchAttrConfig.attrOrder";
/*      */ 
/* 1106 */     return getHibernateTemplate().find(hql, 
/* 1107 */       new Object[] { id, Boolean.valueOf(isDialogAttr), Boolean.valueOf(true), codeAttr, valueAttr });
/*      */   }
/*      */ 
/*      */   public List getQueryDisplayItemsByQuickSearchId(String id)
/*      */   {
/* 1114 */     String hql = "from QuickSearchAttrConfig quickSearchAttrConfig where quickSearchAttrConfig.quicksearchId = ? and quickSearchAttrConfig.isDialogAttr = ? and ( quickSearchAttrConfig.queryItemEnabled = ? or quickSearchAttrConfig.displayItemEnabled = ?) order by quickSearchAttrConfig.attrOrder";
/*      */ 
/* 1116 */     return getHibernateTemplate().find(hql, 
/* 1117 */       new Object[] { id, Boolean.valueOf(true), Boolean.valueOf(true), Boolean.valueOf(true) });
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.dao.impl.QuickSearchDAOImpl
 * JD-Core Version:    0.6.2
 */