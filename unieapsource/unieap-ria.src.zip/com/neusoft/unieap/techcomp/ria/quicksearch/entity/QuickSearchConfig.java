/*     */ package com.neusoft.unieap.techcomp.ria.quicksearch.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Date;
/*     */ import javax.validation.constraints.NotNull;
/*     */ import org.hibernate.validator.constraints.Length;
/*     */ 
/*     */ @ModelFile("quickSearchConfig.entity")
/*     */ public class QuickSearchConfig
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String name;
/*     */   private String queryDatasource;
/*     */   private String queryLanguageType;
/*     */   private String queryMatchOperator;
/*     */   private String queryTable;
/*     */   private Integer queryMaxSize;
/*     */   private String codeAttr;
/*     */   private String valueAttr;
/*     */   private String queryLanguage;
/*     */   private Boolean queryLanguageCustom;
/*     */   private Boolean dialogQueryLanguageCustom;
/*     */   private String queryMode;
/*     */   private Boolean dialogEnabled;
/*     */   private String dialogQueryType;
/*     */   private String dialogQueryTable;
/*     */   private Integer dialogQueryMaxSize;
/*     */   private String dialogQueryLanguage;
/*     */   private String description;
/*     */   private String createdBy;
/*     */   private Date creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Date lastUpdateDate;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/* 132 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/* 136 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString) {
/* 140 */     this.name = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.name.notNull.message}")
/*     */   @Length(max=64, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.name.length.message}")
/*     */   public String getName() {
/* 146 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setQueryDatasource(String paramString) {
/* 150 */     this.queryDatasource = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryDatasource.notNull.message}")
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryDatasource.length.message}")
/*     */   public String getQueryDatasource() {
/* 156 */     return this.queryDatasource;
/*     */   }
/*     */ 
/*     */   public void setQueryLanguageType(String paramString) {
/* 160 */     this.queryLanguageType = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryLanguageType.notNull.message}")
/*     */   @Length(max=3, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryLanguageType.length.message}")
/*     */   public String getQueryLanguageType() {
/* 166 */     return this.queryLanguageType;
/*     */   }
/*     */ 
/*     */   public void setQueryMatchOperator(String paramString) {
/* 170 */     this.queryMatchOperator = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryMatchOperator.notNull.message}")
/*     */   @Length(max=16, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryMatchOperator.length.message}")
/*     */   public String getQueryMatchOperator() {
/* 176 */     return this.queryMatchOperator;
/*     */   }
/*     */ 
/*     */   public void setQueryTable(String paramString) {
/* 180 */     this.queryTable = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryTable.notNull.message}")
/*     */   @Length(max=128, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryTable.length.message}")
/*     */   public String getQueryTable() {
/* 186 */     return this.queryTable;
/*     */   }
/*     */ 
/*     */   public void setQueryMaxSize(Integer paramInteger) {
/* 190 */     this.queryMaxSize = paramInteger;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryMaxSize.notNull.message}")
/*     */   public Integer getQueryMaxSize() {
/* 195 */     return this.queryMaxSize;
/*     */   }
/*     */ 
/*     */   public void setCodeAttr(String paramString) {
/* 199 */     this.codeAttr = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.codeAttr.notNull.message}")
/*     */   @Length(max=128, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.codeAttr.length.message}")
/*     */   public String getCodeAttr() {
/* 205 */     return this.codeAttr;
/*     */   }
/*     */ 
/*     */   public void setValueAttr(String paramString) {
/* 209 */     this.valueAttr = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.valueAttr.notNull.message}")
/*     */   @Length(max=128, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.valueAttr.length.message}")
/*     */   public String getValueAttr() {
/* 215 */     return this.valueAttr;
/*     */   }
/*     */ 
/*     */   public void setQueryLanguage(String paramString) {
/* 219 */     this.queryLanguage = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryLanguage.notNull.message}")
/*     */   @Length(max=4000, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryLanguage.length.message}")
/*     */   public String getQueryLanguage() {
/* 225 */     return this.queryLanguage;
/*     */   }
/*     */ 
/*     */   public void setQueryLanguageCustom(Boolean paramBoolean) {
/* 229 */     this.queryLanguageCustom = paramBoolean;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryLanguageCustom.notNull.message}")
/*     */   public Boolean getQueryLanguageCustom() {
/* 234 */     return this.queryLanguageCustom;
/*     */   }
/*     */ 
/*     */   public void setDialogQueryLanguageCustom(Boolean paramBoolean) {
/* 238 */     this.dialogQueryLanguageCustom = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getDialogQueryLanguageCustom() {
/* 242 */     return this.dialogQueryLanguageCustom;
/*     */   }
/*     */ 
/*     */   public void setQueryMode(String paramString) {
/* 246 */     this.queryMode = paramString;
/*     */   }
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryMode.notNull.message}")
/*     */   @Length(max=16, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.queryMode.length.message}")
/*     */   public String getQueryMode() {
/* 252 */     return this.queryMode;
/*     */   }
/*     */ 
/*     */   public void setDialogEnabled(Boolean paramBoolean) {
/* 256 */     this.dialogEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   @NotNull(message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.dialogEnabled.notNull.message}")
/*     */   public Boolean getDialogEnabled() {
/* 261 */     return this.dialogEnabled;
/*     */   }
/*     */ 
/*     */   public void setDialogQueryType(String paramString) {
/* 265 */     this.dialogQueryType = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=16, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.dialogQueryType.length.message}")
/*     */   public String getDialogQueryType() {
/* 270 */     return this.dialogQueryType;
/*     */   }
/*     */ 
/*     */   public void setDialogQueryTable(String paramString) {
/* 274 */     this.dialogQueryTable = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=128, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.dialogQueryTable.length.message}")
/*     */   public String getDialogQueryTable() {
/* 279 */     return this.dialogQueryTable;
/*     */   }
/*     */ 
/*     */   public void setDialogQueryMaxSize(Integer paramInteger) {
/* 283 */     this.dialogQueryMaxSize = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getDialogQueryMaxSize() {
/* 287 */     return this.dialogQueryMaxSize;
/*     */   }
/*     */ 
/*     */   public void setDialogQueryLanguage(String paramString) {
/* 291 */     this.dialogQueryLanguage = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=4000, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.dialogQueryLanguage.length.message}")
/*     */   public String getDialogQueryLanguage() {
/* 296 */     return this.dialogQueryLanguage;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString) {
/* 300 */     this.description = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=255, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.description.length.message}")
/*     */   public String getDescription() {
/* 305 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 309 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.createdBy.length.message}")
/*     */   public String getCreatedBy() {
/* 314 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Date paramDate) {
/* 318 */     this.creationDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getCreationDate() {
/* 322 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 326 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.quickSearchConfig.lastUpdatedBy.length.message}")
/*     */   public String getLastUpdatedBy() {
/* 331 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Date paramDate) {
/* 335 */     this.lastUpdateDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getLastUpdateDate() {
/* 339 */     return this.lastUpdateDate;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.quicksearch.entity.QuickSearchConfig
 * JD-Core Version:    0.6.2
 */