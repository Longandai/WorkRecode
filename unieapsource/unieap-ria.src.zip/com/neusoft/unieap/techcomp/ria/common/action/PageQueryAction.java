/*     */ package com.neusoft.unieap.techcomp.ria.common.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.page.PageContext;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCache;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition;
/*     */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.context.impl.ViewContextImpl;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import com.opensymphony.xwork2.ActionSupport;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.struts2.interceptor.ServletRequestAware;
/*     */ import org.apache.struts2.interceptor.ServletResponseAware;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class PageQueryAction extends ActionSupport
/*     */   implements ServletRequestAware, ServletResponseAware, ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = 7841434863232711024L;
/*     */   private HttpServletRequest request;
/*     */   private HttpServletResponse response;
/*     */   private ApplicationContext applicationContext;
/*     */ 
/*     */   public void setServletRequest(HttpServletRequest paramHttpServletRequest)
/*     */   {
/*  54 */     this.request = paramHttpServletRequest;
/*     */   }
/*     */ 
/*     */   public void setServletResponse(HttpServletResponse paramHttpServletResponse)
/*     */   {
/*  59 */     this.response = paramHttpServletResponse;
/*     */   }
/*     */ 
/*     */   public HttpServletRequest getRequest() {
/*  63 */     return this.request;
/*     */   }
/*     */ 
/*     */   public HttpServletResponse getResponse() {
/*  67 */     return this.response;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*     */   {
/*  72 */     this.applicationContext = paramApplicationContext;
/*     */   }
/*     */ 
/*     */   protected final ViewContext generateContext() throws Exception {
/*  76 */     ViewContextImpl localViewContextImpl = new ViewContextImpl();
/*  77 */     DataCenter localDataCenter = DataCenterIOManager.createReader(
/*  78 */       this.request.getInputStream()).parse();
/*     */ 
/*  80 */     Map localMap = localDataCenter.getParameters();
/*  81 */     ((ViewContextImpl)localViewContextImpl).setDc(localDataCenter);
/*  82 */     localViewContextImpl.putAll(localMap);
/*     */ 
/*  84 */     List localList = localDataCenter.getDataStores();
/*  85 */     for (int i = 0; i < localList.size(); i++) {
/*  86 */       DataStore localDataStore = (DataStore)localList.get(i);
/*  87 */       String str = localDataStore.getStoreName();
/*  88 */       localViewContextImpl.put(str, localDataStore);
/*     */     }
/*  90 */     return localViewContextImpl;
/*     */   }
/*     */ 
/*     */   public void commonMethod() throws Exception {
/*  94 */     ViewContext localViewContext = generateContext();
/*  95 */     DataCenter localDataCenter = DataCenterFactory.getInstance()
/*  96 */       .createDataCenter();
/*  97 */     UnieapRequestContextHolder.getRequestContext().put("viewContext", 
/*  98 */       localViewContext);
/*     */ 
/* 100 */     if ((localViewContext.getString("_pageNumber") != null) && 
/* 101 */       (localViewContext.getString("_pageSize") != null)) {
/* 102 */       localObject1 = new QueryResult();
/* 103 */       ((QueryResult)localObject1).setPageNumber(Integer.valueOf(localViewContext
/* 104 */         .getString("_pageNumber")).intValue());
/*     */ 
/* 105 */       ((QueryResult)localObject1).setPageSize(Integer.valueOf(localViewContext
/* 106 */         .getString("_pageSize")).intValue());
/*     */ 
/* 108 */       ((QueryResult)localObject1).setAutoCalcCount(true);
/*     */ 
/* 113 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/* 114 */         localObject1);
/*     */     }
/*     */ 
/* 117 */     Object localObject1 = localViewContext.getPOJOList("_advancedQueryConditionStore");
/* 118 */     if (localObject1 != null) {
/* 119 */       localObject2 = new QueryCondition();
/* 120 */       ((QueryCondition)localObject2).setConditions((List)localObject1);
/* 121 */       UnieapRequestContextHolder.getRequestContext().put(
/* 122 */         "advanceQueryCondition", localObject2);
/*     */     }
/*     */ 
/* 125 */     Object localObject2 = (String)localViewContext.get("_pageKey");
/*     */ 
/* 127 */     if (localObject2 != null) {
/* 128 */       localObject3 = UniEAPContextHolder.getContext()
/* 129 */         .getCurrentUser().getAccount();
/* 130 */       Map localMap = (Map)((EAPCacheManager)
/* 131 */         BeanUtil.getBean("eapCacheManager")).getCache("pageContext")
/* 132 */         .getObject(localObject3);
/* 133 */       if ((localMap != null) && (localMap.size() > 0)) {
/* 134 */         PageContext localPageContext = (PageContext)localMap.get(localObject2);
/* 135 */         Object localObject4 = null;
/* 136 */         if (localPageContext != null) {
/* 137 */           String str1 = localPageContext.getDataSourceID();
/* 138 */           if ((str1 != null) && (!"".equals(str1))) {
/* 139 */             DataSourceContextHolder.setDataSourceType(str1);
/*     */           }
/* 141 */           Object localObject5 = this.applicationContext
/* 142 */             .getBean("ria_pageQueryBO_bo");
/* 143 */           String str2 = localPageContext.getSessionFactoryId();
/* 144 */           if ((str2 != null) && 
/* 145 */             (str2.length() > 0)) {
/* 146 */             PropertyUtils.setProperty(PropertyUtils.getProperty(localObject5, 
/* 147 */               "pageQueryDAO"), "sessionFactory", 
/* 148 */               this.applicationContext.getBean(str2));
/*     */           }
/* 150 */           Method[] arrayOfMethod = localObject5.getClass().getMethods();
/* 151 */           for (int i = 0; i < arrayOfMethod.length; i++)
/* 152 */             if (arrayOfMethod[i].getName().equals("query")) {
/* 153 */               localObject4 = arrayOfMethod[i].invoke(localObject5, new Object[] { localPageContext });
/* 154 */               Class localClass = arrayOfMethod[i].getReturnType();
/* 155 */               CommonUtil.handleBoMethodReturn(localDataCenter, localObject4, 
/* 156 */                 localClass);
/* 157 */               break;
/*     */             }
/*     */         }
/*     */         else {
/* 161 */           throw new UniEAPBusinessException("EAPTECHRIA1004");
/*     */         }
/*     */       } else {
/* 164 */         throw new UniEAPBusinessException("EAPTECHRIA1004");
/*     */       }
/*     */     }
/* 167 */     Object localObject3 = 
/* 168 */       DataCenterIOManager.createWriter(getResponse().getOutputStream());
/* 169 */     ((DataCenterWriter)localObject3).write(localDataCenter);
/* 170 */     ((DataCenterWriter)localObject3).close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.action.PageQueryAction
 * JD-Core Version:    0.6.2
 */