package com.neusoft.unieap.techcomp.ria.common.rest;

public class CommonRestCompatible extends CommonRest
{
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.rest.CommonRestCompatible
 * JD-Core Version:    0.6.2
 */