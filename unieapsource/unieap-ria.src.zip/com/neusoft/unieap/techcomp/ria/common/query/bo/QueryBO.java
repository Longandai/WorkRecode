package com.neusoft.unieap.techcomp.ria.common.query.bo;

import com.neusoft.unieap.techcomp.ria.common.query.entity.QueryCondition;
import java.io.Serializable;
import java.util.List;

public abstract interface QueryBO extends Serializable
{
  public abstract List getQueryData(List paramList, String paramString, int paramInt1, int paramInt2);

  public abstract int getRecordCount(List paramList, String paramString);

  public abstract QueryCondition saveQueryCondition(List paramList, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List queryHistoryConditions(String paramString1, String paramString2, String paramString3);

  public abstract void deleteHistoryCondition(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.QueryBO
 * JD-Core Version:    0.6.2
 */