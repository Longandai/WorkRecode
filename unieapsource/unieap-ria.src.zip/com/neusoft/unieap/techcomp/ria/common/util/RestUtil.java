/*      */ package com.neusoft.unieap.techcomp.ria.common.util;
/*      */ 
/*      */ import com.neusoft.unieap.core.CoreVariability;
/*      */ import com.neusoft.unieap.core.annotation.RestService;
/*      */ import com.neusoft.unieap.core.base.model.DCRepository;
/*      */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*      */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*      */ import com.neusoft.unieap.core.common.bo.CommonBO;
/*      */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*      */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*      */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*      */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*      */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*      */ import com.neusoft.unieap.core.statement.Statement;
/*      */ import com.neusoft.unieap.core.statement.impl.StatementImpl;
/*      */ import com.neusoft.unieap.core.util.BeanUtil;
/*      */ import com.neusoft.unieap.core.util.InteractionUtil;
/*      */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.CacheTaskUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*      */ import com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition;
/*      */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.impl.RowImpl;
/*      */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*      */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*      */ import com.neusoft.unieap.techcomp.ria.pojo.PojoEntity;
/*      */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.util.ViewContextUtil;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONObject;
/*      */ import net.sf.json.util.JSONUtils;
/*      */ import org.apache.poi.ss.usermodel.Workbook;
/*      */ import org.springframework.aop.TargetSource;
/*      */ import org.springframework.aop.framework.AdvisedSupport;
/*      */ import org.springframework.aop.framework.AopProxy;
/*      */ import org.springframework.aop.support.AopUtils;
/*      */ 
/*      */ public class RestUtil
/*      */ {
/*      */   public static final String POJO_INDEX_IN_CONTEXT = "_pojoIndexInContext";
/*      */   public static final String DATASTORE = "dataStore";
/*      */   public static final String MAP = "map";
/*      */   public static final String BOID = "boId";
/*      */   public static final String METHODNAME = "methodName";
/*      */   public static final String PARAMETERS = "parameters";
/*      */   public static final String PARAMETERTYPES = "_parameterTypes";
/*      */   public static final String DATASOURCEID = "_dataSourceID";
/*      */   public static final String METHODPARAMETERTYPES = "methodParameterTypes";
/*      */   public static final String RESULT = "result";
/*      */   public static final String DATASTORE_PRIMARY = "primary";
/*      */   public static final String FORM_PARAMETER_TYPE = "com.neusoft.unieap.core.common.form.Form";
/*      */   public static final String DATACENTER_PARAMETER_TYPE = "com.neusoft.unieap.techcomp.ria.ds.DataCenter";
/*      */   public static final String UPLOAD_FORM_STORE = "_uploadFormStore";
/*      */   public static final String PAGENUMBER = "_pageNumber";
/*      */   public static final String PAGESIZE = "_pageSize";
/*      */   public static final String CALCCOUNT = "_calcRecordCount";
/*      */   public static final String NAMED_QUERY = "_namedQuery";
/*      */   public static final String QUERYPARAMETERTYPES = "_queryParameterTypes";
/*      */   public static final String STATEMENT = "_statement";
/*      */   public static final String STATEMENT_REF = "_statementRef";
/*      */   public static final String DCID = "_dcId";
/*      */   public static final String POJO_CONTEXT = "pojoContext";
/*  115 */   public static final String[] PrimitiveTypes = { "int", "float", "double", "boolean", "short", "byte", "char", "long" };
/*      */ 
/*  117 */   public static final Map<String, Class> TYPEMAP = new HashMap();
/*      */ 
/*  119 */   static { TYPEMAP.put("Integer", Integer.class);
/*  120 */     TYPEMAP.put("Float", Float.class);
/*  121 */     TYPEMAP.put("Double", Double.class);
/*  122 */     TYPEMAP.put("Boolean", Boolean.class);
/*  123 */     TYPEMAP.put("Byte", Byte.class);
/*  124 */     TYPEMAP.put("Character", Character.class);
/*  125 */     TYPEMAP.put("Long", Long.class);
/*  126 */     TYPEMAP.put("Short", Short.class);
/*  127 */     TYPEMAP.put("String", String.class);
/*  128 */     TYPEMAP.put("Object", Object.class);
/*      */   }
/*      */ 
/*      */   public static boolean isBaseDataType(String paramString)
/*      */   {
/*  133 */     for (int i = 0; i < PrimitiveTypes.length; i++)
/*      */     {
/*  135 */       if (PrimitiveTypes[i].equals(paramString))
/*      */       {
/*  137 */         return true;
/*      */       }
/*      */     }
/*  140 */     return false;
/*      */   }
/*      */ 
/*      */   public static Class[] convertToClassTypes(String[] paramArrayOfString)
/*      */   {
/*  145 */     ArrayList localArrayList = new ArrayList();
/*  146 */     if (paramArrayOfString != null)
/*      */     {
/*  148 */       for (int i = 0; i < paramArrayOfString.length; i++)
/*      */       {
/*  150 */         if (paramArrayOfString[i].equals("string"))
/*      */         {
/*  152 */           localArrayList.add(String.class);
/*      */         }
/*  154 */         if (paramArrayOfString[i].equals("int"))
/*      */         {
/*  156 */           localArrayList.add(Integer.class);
/*      */         }
/*  158 */         if (paramArrayOfString[i].equals("long"))
/*      */         {
/*  160 */           localArrayList.add(Long.class);
/*      */         }
/*  162 */         if (paramArrayOfString[i].equals("float"))
/*      */         {
/*  164 */           localArrayList.add(Float.class);
/*      */         }
/*  166 */         if (paramArrayOfString[i].equals("long"))
/*      */         {
/*  168 */           localArrayList.add(Long.class);
/*      */         }
/*      */       }
/*      */     }
/*  172 */     return (Class[])localArrayList.toArray(new Class[localArrayList.size()]);
/*      */   }
/*      */ 
/*      */   public static boolean hasRestAnnotation(Object paramObject, Method paramMethod) throws Exception
/*      */   {
/*  177 */     Object localObject = getTarget(paramObject);
/*  178 */     if (localObject != null)
/*      */     {
/*  180 */       Class localClass = localObject.getClass();
/*  181 */       Method localMethod = localClass.getMethod(paramMethod.getName(), paramMethod.getParameterTypes());
/*  182 */       boolean bool = localMethod.isAnnotationPresent(RestService.class);
/*  183 */       return bool;
/*      */     }
/*  185 */     return false;
/*      */   }
/*      */ 
/*      */   private static Object getTarget(Object paramObject)
/*      */     throws Exception
/*      */   {
/*  198 */     if (!AopUtils.isAopProxy(paramObject))
/*      */     {
/*  200 */       return paramObject;
/*  201 */     }if (AopUtils.isJdkDynamicProxy(paramObject))
/*      */     {
/*  203 */       localObject = getJdkDynamicProxyTargetObject(paramObject);
/*  204 */       return getTarget(localObject);
/*      */     }
/*      */ 
/*  208 */     Object localObject = getCglibProxyTargetObject(paramObject);
/*  209 */     return getTarget(localObject);
/*      */   }
/*      */ 
/*      */   private static Object getCglibProxyTargetObject(Object paramObject)
/*      */     throws Exception
/*      */   {
/*  215 */     Field localField1 = paramObject.getClass().getDeclaredField("CGLIB$CALLBACK_0");
/*  216 */     localField1.setAccessible(true);
/*  217 */     Object localObject1 = localField1.get(paramObject);
/*  218 */     Field localField2 = localObject1.getClass().getDeclaredField("advised");
/*  219 */     localField2.setAccessible(true);
/*  220 */     Object localObject2 = ((AdvisedSupport)localField2.get(localObject1)).getTargetSource().getTarget();
/*  221 */     return localObject2;
/*      */   }
/*      */ 
/*      */   private static Object getJdkDynamicProxyTargetObject(Object paramObject) throws Exception
/*      */   {
/*  226 */     Field localField1 = paramObject.getClass().getSuperclass().getDeclaredField("h");
/*  227 */     localField1.setAccessible(true);
/*  228 */     AopProxy localAopProxy = (AopProxy)localField1.get(paramObject);
/*  229 */     Field localField2 = localAopProxy.getClass().getDeclaredField("advised");
/*  230 */     localField2.setAccessible(true);
/*  231 */     Object localObject = ((AdvisedSupport)localField2.get(localAopProxy)).getTargetSource().getTarget();
/*  232 */     return localObject;
/*      */   }
/*      */ 
/*      */   private static List<RestParameter> getParameterList(String paramString) throws Exception
/*      */   {
/*  237 */     ArrayList localArrayList = new ArrayList();
/*  238 */     if ((paramString != null) && (!paramString.equals("")) && (JSONUtils.mayBeJSON(paramString)))
/*      */     {
/*  240 */       JSONArray localJSONArray = JSONArray.fromObject(paramString);
/*  241 */       for (int i = 0; i < localJSONArray.size(); i++)
/*      */       {
/*  243 */         JSONObject localJSONObject1 = localJSONArray.getJSONObject(i);
/*  244 */         if (localJSONObject1.size() == 0)
/*  245 */           throw new RIAException("EAPTECH008001", new Object[] { localJSONObject1 });
/*  246 */         Iterator localIterator1 = localJSONObject1.entrySet().iterator();
/*  247 */         while (localIterator1.hasNext())
/*      */         {
/*  249 */           Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
/*  250 */           String str1 = (String)localEntry1.getKey();
/*  251 */           String str2 = localEntry1.getValue().toString();
/*  252 */           RestParameter localRestParameter = new RestParameter();
/*  253 */           localRestParameter.setType(str1);
/*  254 */           if ((str1.trim().equalsIgnoreCase("pojo")) || (str1.trim().equalsIgnoreCase("pojoList")))
/*      */           {
/*  256 */             if (JSONUtils.mayBeJSON(str2))
/*      */             {
/*  258 */               JSONObject localJSONObject2 = JSONObject.fromObject(str2);
/*  259 */               Iterator localIterator2 = localJSONObject2.entrySet().iterator();
/*  260 */               while (localIterator2.hasNext())
/*      */               {
/*  262 */                 Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
/*  263 */                 String str3 = (String)localEntry2.getKey();
/*  264 */                 localRestParameter.setClazz(str3);
/*  265 */                 String str4 = (str1.trim().equalsIgnoreCase("pojo") ? localJSONObject2.getJSONObject(str3) : localJSONObject2.getJSONArray(str3)).toString();
/*  266 */                 localRestParameter.setValue(str4);
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/*  271 */             localRestParameter.setValue(str2);
/*      */           }
/*  273 */           localArrayList.add(localRestParameter);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  278 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   public static Object invokeBoMethod(ViewContext paramViewContext, Object paramObject)
/*      */     throws Exception
/*      */   {
/*  293 */     String str1 = paramViewContext.getString("boId");
/*  294 */     String str2 = paramViewContext.getString("methodName");
/*      */ 
/*  296 */     String str3 = paramViewContext.getString("parameters");
/*  297 */     List localList = getParameterList(str3);
/*      */ 
/*  301 */     if (str2 == null)
/*      */     {
/*  303 */       throw new RIAException("EAPTECH008010", null);
/*      */     }
/*      */ 
/*  306 */     String[] arrayOfString = (String[])null;
/*  307 */     String str4 = paramViewContext.getString("paraTable");
/*  308 */     if ((str4 != null) && (!str4.trim().equals("")))
/*      */     {
/*  310 */       arrayOfString = str4.split(",");
/*      */     }
/*  313 */     else if (localList.size() > 0)
/*      */     {
/*  315 */       arrayOfString = new String[localList.size()];
/*  316 */       for (int i = 0; i < localList.size(); i++)
/*      */       {
/*  318 */         localObject1 = (RestParameter)localList.get(i);
/*  319 */         localObject2 = ((RestParameter)localObject1).getType();
/*  320 */         if (((String)localObject2).trim().equalsIgnoreCase("pojo"))
/*      */         {
/*  322 */           arrayOfString[i] = ((RestParameter)localObject1).getClazz();
/*      */         }
/*  325 */         else if (((String)localObject2).trim().equalsIgnoreCase("pojoList"))
/*      */         {
/*  327 */           arrayOfString[i] = List.class.getName();
/*      */         }
/*  330 */         else if (((String)localObject2).trim().equalsIgnoreCase("map"))
/*      */         {
/*  332 */           arrayOfString[i] = Map.class.getName();
/*      */         }
/*      */         else {
/*  335 */           arrayOfString[i] = localObject2;
/*      */         }
/*      */       }
/*      */     }
/*  339 */     Method localMethod = getBOMethod(paramObject, str2, arrayOfString);
/*      */ 
/*  342 */     if (localMethod == null)
/*      */     {
/*  344 */       localObject1 = new Object[] { str1, str2, Arrays.toString(arrayOfString) };
/*  345 */       throw new RIAException("EAPTECH008008", (Object[])localObject1);
/*      */     }
/*      */ 
/*  348 */     if (!hasRestAnnotation(paramObject, localMethod))
/*      */     {
/*  350 */       throw new UniEAPBusinessException("EAPTECHRIA1002");
/*      */     }
/*      */ 
/*  354 */     Object localObject1 = InteractionUtil.getInteractionValue(paramObject, localMethod);
/*  355 */     if (localObject1 == null)
/*      */     {
/*  357 */       if (CoreVariability.isPrecheckForInteraction())
/*      */       {
/*  360 */         throw new UniEAPBusinessException("EAPTECHRIA1001");
/*      */       }
/*      */ 
/*      */     }
/*  365 */     else if (ViewContextUtil.getViewContext() != null)
/*      */     {
/*  367 */       ViewContextUtil.getViewContext().put("BUSINESS_REQUEST_ID", localObject1);
/*      */     }
/*      */ 
/*  372 */     if (ViewContextUtil.getViewContext() != null)
/*      */     {
/*  374 */       localObject2 = ViewContextUtil.getViewContext().getString("dcID");
/*  375 */       if ((localObject2 != null) && (DCRepository.getDevelopmentComponent((String)localObject2) != null))
/*      */       {
/*  377 */         localObject3 = DCRepository.getDevelopmentComponent((String)localObject2).getSoftwareComponent().getId();
/*  378 */         if (localObject3 != null)
/*      */         {
/*  380 */           ViewContextUtil.getViewContext().put("scID", localObject3);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  386 */     Object localObject2 = localMethod.getParameterTypes();
/*  387 */     Object localObject3 = new ArrayList();
/*  388 */     if ((str3 != null) && (!str3.equals("")))
/*      */     {
/*  390 */       localObject3 = initParameters(paramViewContext, localList, (Class[])localObject2);
/*      */     }
/*      */ 
/*  394 */     paramViewContext.put("boMethodType", localMethod.getReturnType());
/*      */ 
/*  397 */     Object localObject4 = null;
/*      */     try
/*      */     {
/*  400 */       localObject4 = localMethod.invoke(paramObject, ((List)localObject3).toArray());
/*      */     }
/*      */     catch (InvocationTargetException localInvocationTargetException)
/*      */     {
/*  404 */       Throwable localThrowable = localInvocationTargetException.getCause();
/*  405 */       throw new Exception(localThrowable.getLocalizedMessage(), localThrowable);
/*      */     }
/*      */     catch (Exception localException) {
/*  408 */       throw localException;
/*      */     }
/*  410 */     return localObject4;
/*      */   }
/*      */ 
/*      */   private static Object initDataCenterParameters(String paramString)
/*      */     throws Exception
/*      */   {
/*  423 */     if (JSONUtils.mayBeJSON(paramString))
/*      */     {
/*  425 */       DataCenter localDataCenter = DataCenterIOManager.createReader(paramString).parse();
/*  426 */       return localDataCenter;
/*      */     }
/*  428 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveType(Object paramObject)
/*      */   {
/*  440 */     if ((paramObject instanceof String))
/*      */     {
/*  442 */       return true;
/*      */     }
/*  444 */     if ((paramObject instanceof Number))
/*      */     {
/*  446 */       return true;
/*      */     }
/*  448 */     if ((paramObject instanceof Character))
/*      */     {
/*  450 */       return true;
/*      */     }
/*  452 */     if ((paramObject instanceof Boolean))
/*      */     {
/*  454 */       return true;
/*      */     }
/*  456 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isCommonType(Object paramObject)
/*      */   {
/*  467 */     if (isPrimitiveType(paramObject))
/*      */     {
/*  469 */       return true;
/*      */     }
/*  471 */     if ((paramObject instanceof BigDecimal))
/*      */     {
/*  473 */       return true;
/*      */     }
/*  475 */     if ((paramObject instanceof Date))
/*      */     {
/*  477 */       return true;
/*      */     }
/*  479 */     return false;
/*      */   }
/*      */ 
/*      */   public static Object getParam(String paramString, RestParameter paramRestParameter)
/*      */   {
/*  493 */     String str1 = paramRestParameter.getValue();
/*  494 */     String str2 = paramRestParameter.getType();
/*  495 */     if (TYPEMAP.keySet().contains(str2))
/*  496 */       str2 = ((Class)TYPEMAP.get(str2)).getName();
/*      */     try
/*      */     {
/*  499 */       if (str2.equals(String.class.getName()))
/*      */       {
/*  501 */         return String.valueOf(str1);
/*      */       }
/*  503 */       if ((str2.equals(Integer.class.getName())) || (str2.equals("int")))
/*      */       {
/*  505 */         return Integer.valueOf(str1.toString());
/*      */       }
/*  507 */       if ((str2.equals(Float.class.getName())) || (str2.equals("float")))
/*      */       {
/*  509 */         return Float.valueOf(str1.toString());
/*      */       }
/*  511 */       if ((str2.equals(Double.class.getName())) || (str2.equals("double")))
/*      */       {
/*  513 */         return Double.valueOf(str1.toString());
/*      */       }
/*  515 */       if ((str2.equals(Boolean.class.getName())) || (str2.equals("boolean")))
/*      */       {
/*  517 */         return Boolean.valueOf(str1.toString());
/*      */       }
/*  519 */       if ((str2.equals(Short.class.getName())) || (str2.equals("short")))
/*      */       {
/*  521 */         return Short.valueOf(str1.toString());
/*      */       }
/*  523 */       if ((str2.equals(Long.class.getName())) || (str2.equals("long")))
/*      */       {
/*  525 */         return Long.valueOf(str1.toString());
/*      */       }
/*  527 */       if ((str2.equals(Character.class.getName())) || (str2.equals("char")))
/*      */       {
/*  529 */         return new Character(str1.toString().charAt(0));
/*      */       }
/*  531 */       if (str2.equals(BigDecimal.class.getName()))
/*      */       {
/*  533 */         return new BigDecimal(str1.toString());
/*      */       }
/*      */       Object localObject1;
/*  535 */       if ((str2.equals(Map.class.getName())) || (str2.trim().equalsIgnoreCase("map")))
/*      */       {
/*  537 */         localObject1 = new RowImpl(JSONObject.fromObject(str1), 0);
/*  538 */         return PojoUtil.createMap((Row)localObject1);
/*      */       }
/*      */       Object localObject2;
/*      */       Object localObject3;
/*  540 */       if (str2.trim().equalsIgnoreCase("pojo"))
/*      */       {
/*  542 */         if (JSONUtils.mayBeJSON(str1.toString()))
/*      */         {
/*  544 */           localObject1 = null;
/*  545 */           if (JSONUtils.isArray(str1.toString()))
/*      */           {
/*  547 */             localObject2 = JSONArray.fromObject(str1);
/*  548 */             if (!((JSONArray)localObject2).isEmpty())
/*      */             {
/*  550 */               localObject1 = ((JSONArray)localObject2).getJSONObject(0);
/*      */             }
/*      */           }
/*      */           else {
/*  554 */             localObject1 = JSONObject.fromObject(str1);
/*      */           }
/*  556 */           localObject2 = null;
/*  557 */           localObject3 = new RowImpl((JSONObject)localObject1, 0);
/*      */           try
/*      */           {
/*  560 */             localObject2 = PojoUtil.createPojoEntity(paramRestParameter.getClazz(), (Row)localObject3);
/*  561 */             return ((PojoEntity)localObject2).getPojoObj();
/*      */           }
/*      */           catch (Exception localException1) {
/*  564 */             localException1.printStackTrace();
/*      */           }
/*      */         }
/*      */       }
/*  568 */       else if (str2.trim().equalsIgnoreCase("pojoList"))
/*      */       {
/*  570 */         localObject1 = new ArrayList();
/*  571 */         if (JSONUtils.mayBeJSON(str1.toString()))
/*      */         {
/*  573 */           localObject2 = null;
/*  574 */           localObject3 = JSONArray.fromObject(str1);
/*  575 */           for (int i = 0; i < ((JSONArray)localObject3).size(); i++)
/*      */           {
/*  577 */             JSONObject localJSONObject = ((JSONArray)localObject3).getJSONObject(i);
/*  578 */             RowImpl localRowImpl = new RowImpl(localJSONObject, i);
/*      */             try
/*      */             {
/*  581 */               localObject2 = PojoUtil.createPojoEntity(paramRestParameter.getClazz(), localRowImpl);
/*  582 */               ((List)localObject1).add(((PojoEntity)localObject2).getPojoObj());
/*      */             }
/*      */             catch (Exception localException2) {
/*  585 */               localException2.printStackTrace();
/*      */             }
/*      */           }
/*      */         }
/*  589 */         return localObject1;
/*      */       }
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {
/*  593 */       throw new RIAException("EAPTECH008001", new String[] { str1.toString() });
/*      */     }
/*  595 */     return null;
/*      */   }
/*      */ 
/*      */   public static void handleBoMethodReturn(DataCenter paramDataCenter, Object paramObject, Class paramClass, HttpServletResponse paramHttpServletResponse)
/*      */     throws Exception
/*      */   {
/*  610 */     if (Void.TYPE.equals(paramClass))
/*      */       return;
/*      */     Object localObject1;
/*  614 */     if (paramObject == null)
/*      */     {
/*  616 */       paramDataCenter.addParameter("result", null);
/*  617 */       localObject1 = DataCenterFactory.getInstance().createDataStore("result");
/*  618 */       paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       return;
/*      */     }
/*      */     Object localObject2;
/*      */     Object localObject4;
/*  622 */     if ((paramObject instanceof Workbook))
/*      */     {
/*  624 */       localObject1 = (Workbook)paramObject;
/*  625 */       localObject2 = null;
/*      */       try
/*      */       {
/*  628 */         paramHttpServletResponse.setContentType("application/msexcel;charset=UTF-8");
/*  629 */         paramHttpServletResponse.setHeader("Content-Disposition", "attachment;filename=export.xls");
/*  630 */         localObject2 = paramHttpServletResponse.getOutputStream();
/*  631 */         ((Workbook)localObject1).write((OutputStream)localObject2);
/*  632 */         ((ServletOutputStream)localObject2).flush();
/*      */       }
/*      */       catch (Exception localException1)
/*      */       {
/*  636 */         localObject4 = localException1.getClass().getCanonicalName();
/*  637 */         if (((String)localObject4).endsWith("org.apache.catalina.connector.ClientAbortException")) {
/*      */           return;
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/*  643 */         ((ServletOutputStream)localObject2).close();
/*      */       }
/*      */       return;
/*      */     }
/*      */     Object localObject3;
/*      */     Object localObject6;
/*  648 */     if ((paramObject instanceof File))
/*      */     {
/*  650 */       localObject1 = (File)paramObject;
/*  651 */       localObject2 = paramHttpServletResponse.getOutputStream();
/*  652 */       if (!((File)localObject1).exists())
/*      */       {
/*  655 */         localObject3 = "{title:\"提示信息\",message:\"文件不存在!\"}";
/*  656 */         ((ServletOutputStream)localObject2).write(((String)localObject3).getBytes("UTF-8"));
/*  657 */         ((ServletOutputStream)localObject2).flush();
/*  658 */         ((ServletOutputStream)localObject2).close();
/*  659 */         return;
/*      */       }
/*  661 */       localObject3 = ((File)localObject1).getName();
/*  662 */       localObject3 = new String(((String)localObject3).getBytes("GBK"), "ISO-8859-1");
/*  663 */       localObject4 = null;
/*      */       try
/*      */       {
/*  666 */         paramHttpServletResponse.setContentType("application/x-msdownload");
/*  667 */         paramHttpServletResponse.setHeader("Content-Disposition", "attachment;filename=" + (String)localObject3);
/*  668 */         if (((File)localObject1).length() < 2147483647L)
/*      */         {
/*  670 */           paramHttpServletResponse.setContentLength((int)((File)localObject1).length());
/*      */         }
/*  672 */         localObject4 = new FileInputStream((File)localObject1);
/*  673 */         localObject6 = new byte[10240];
/*  674 */         int j = -1;
/*  675 */         while ((j = ((FileInputStream)localObject4).read((byte[])localObject6)) != -1)
/*      */         {
/*  677 */           ((ServletOutputStream)localObject2).write((byte[])localObject6, 0, j);
/*      */         }
/*  679 */         ((ServletOutputStream)localObject2).flush();
/*      */       }
/*      */       catch (Exception localException2) {
/*      */         return;
/*      */       }
/*      */       finally {
/*  685 */         ((ServletOutputStream)localObject2).close();
/*  686 */         ((FileInputStream)localObject4).close();
/*      */       }
/*      */       return;
/*      */     }
/*      */     Object localObject7;
/*      */     Object localObject9;
/*  691 */     if ((paramObject instanceof CodeList))
/*      */     {
/*  693 */       localObject1 = (CodeList)paramObject;
/*  694 */       localObject2 = DataCenterFactory.getInstance().createDataStore(((CodeList)localObject1).getName());
/*  695 */       localObject3 = ((DataStore)localObject2).getRowSet();
/*  696 */       localObject4 = null;
/*  697 */       localObject6 = new ArrayList();
/*  698 */       localObject7 = ((CodeList)localObject1).getSoleCodeList();
/*  699 */       if (localObject7 != null)
/*      */       {
/*  701 */         ((List)localObject6).addAll((Collection)localObject7);
/*      */       }
/*  703 */       for (int k = 0; k < ((List)localObject6).size(); k++)
/*      */       {
/*  705 */         localObject4 = (Code)((List)localObject6).get(k);
/*  706 */         HashMap localHashMap = new HashMap();
/*  707 */         localHashMap.put("ID", ((Code)localObject4).getCodeValue());
/*  708 */         localHashMap.put("CODENAME", ((Code)localObject4).getCodeName());
/*  709 */         localHashMap.put("CODEVALUE", ((Code)localObject4).getCodeValue());
/*  710 */         localHashMap.put("PARENTID", ((Code)localObject4).getParent());
/*  711 */         ((RowSet)localObject3).addRowData(localHashMap);
/*      */       }
/*  713 */       paramDataCenter.addDataStore((DataStore)localObject2);
/*  714 */       localObject9 = CacheTaskUtil.getTimeStamp(((CodeList)localObject1).getName(), "codelist");
/*  715 */       if (localObject9 != null)
/*      */       {
/*  717 */         paramDataCenter.addParameter(((CodeList)localObject1).getName(), localObject9);
/*      */       }
/*  719 */       return;
/*      */     }
/*      */ 
/*  722 */     if (isCommonType(paramObject))
/*      */     {
/*  724 */       paramDataCenter.addParameter("result", paramObject);
/*  725 */     } else if ((paramObject instanceof BOContext))
/*      */     {
/*  727 */       localObject1 = (BOContext)paramObject;
/*  728 */       if (localObject1 != null)
/*      */       {
/*  730 */         localObject2 = ((BOContext)localObject1).entrySet().iterator();
/*  731 */         while (((Iterator)localObject2).hasNext())
/*      */         {
/*  733 */           localObject3 = (Map.Entry)((Iterator)localObject2).next();
/*  734 */           localObject4 = ((Map.Entry)localObject3).getKey();
/*  735 */           localObject6 = ((Map.Entry)localObject3).getValue();
/*  736 */           if (localObject6 == null)
/*      */           {
/*  738 */             paramDataCenter.addParameter(localObject4.toString(), null);
/*  739 */             localObject7 = DataCenterFactory.getInstance().createDataStore(localObject4.toString());
/*  740 */             paramDataCenter.addDataStore((DataStore)localObject7);
/*      */           }
/*  743 */           else if (isCommonType(localObject6))
/*      */           {
/*  745 */             paramDataCenter.addParameter(localObject4.toString(), localObject6);
/*      */           }
/*      */           else {
/*  748 */             localObject7 = DataCenterFactory.getInstance().createDataStore(localObject4.toString());
/*  749 */             if ((localObject6 instanceof List))
/*      */             {
/*  751 */               localObject9 = (List)localObject6;
/*  752 */               handleReturnList(paramDataCenter, (List)localObject9, localObject4.toString());
/*  753 */             } else if (localObject6.getClass().isArray())
/*      */             {
/*  756 */               localObject9 = new ArrayList();
/*  757 */               for (int m = 0; m < Array.getLength(localObject6); m++)
/*      */               {
/*  759 */                 Object localObject10 = Array.get(localObject6, m);
/*  760 */                 ((List)localObject9).add(localObject10);
/*      */               }
/*  762 */               handleReturnList(paramDataCenter, (List)localObject9, localObject4.toString());
/*  763 */             } else if ((localObject6 instanceof Map))
/*      */             {
/*  766 */               localObject9 = (Map)localObject6;
/*  767 */               handleReturnMap(paramDataCenter, (Map)localObject9, "result");
/*  768 */             } else if ((localObject6 instanceof QueryResult))
/*      */             {
/*  770 */               localObject9 = (QueryResult)localObject6;
/*  771 */               if (((QueryResult)localObject9).getResult() != null)
/*      */               {
/*  773 */                 localObject7 = PojoUtil.toDataStore(((QueryResult)localObject9).getResult(), (DataStore)localObject7);
/*      */               }
/*  775 */               ((DataStore)localObject7).setRecordCount(((QueryResult)localObject9).getRecordCount());
/*  776 */               if (((QueryResult)localObject9).getPageNumber() != 0)
/*      */               {
/*  778 */                 ((DataStore)localObject7).setPageNumber(((QueryResult)localObject9).getPageNumber());
/*      */               }
/*  780 */               if (((QueryResult)localObject9).getPageSize() != 0)
/*      */               {
/*  782 */                 ((DataStore)localObject7).setPageSize(((QueryResult)localObject9).getPageSize());
/*      */               }
/*  784 */               paramDataCenter.addDataStore((DataStore)localObject7);
/*      */             }
/*      */             else {
/*  787 */               localObject9 = new ArrayList();
/*  788 */               if (localObject6 != null)
/*      */               {
/*  790 */                 ((List)localObject9).add(localObject6);
/*      */               }
/*  792 */               localObject7 = PojoUtil.toDataStore((List)localObject9, (DataStore)localObject7);
/*  793 */               paramDataCenter.addDataStore((DataStore)localObject7);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  800 */       localObject1 = DataCenterFactory.getInstance().createDataStore("result");
/*  801 */       if ((paramObject instanceof QueryResult))
/*      */       {
/*  803 */         localObject2 = (QueryResult)paramObject;
/*  804 */         if (((QueryResult)localObject2).getResult() != null)
/*      */         {
/*  806 */           localObject1 = PojoUtil.toDataStore(((QueryResult)localObject2).getResult(), (DataStore)localObject1);
/*      */         }
/*  808 */         ((DataStore)localObject1).setRecordCount(((QueryResult)localObject2).getRecordCount());
/*  809 */         if (((QueryResult)localObject2).getPageNumber() != 0)
/*      */         {
/*  811 */           ((DataStore)localObject1).setPageNumber(((QueryResult)localObject2).getPageNumber());
/*      */         }
/*  813 */         if (((QueryResult)localObject2).getPageSize() != 0)
/*      */         {
/*  815 */           ((DataStore)localObject1).setPageSize(((QueryResult)localObject2).getPageSize());
/*      */         }
/*  817 */         paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       }
/*  821 */       else if ((paramObject instanceof List))
/*      */       {
/*  823 */         localObject2 = (List)paramObject;
/*  824 */         handleReturnList(paramDataCenter, (List)localObject2, "result");
/*      */       }
/*  826 */       else if (paramObject.getClass().isArray())
/*      */       {
/*  829 */         localObject2 = new ArrayList();
/*  830 */         for (int i = 0; i < Array.getLength(paramObject); i++)
/*      */         {
/*  832 */           localObject4 = Array.get(paramObject, i);
/*  833 */           ((List)localObject2).add(localObject4);
/*      */         }
/*  835 */         handleReturnList(paramDataCenter, (List)localObject2, "result");
/*  836 */       } else if ((paramObject instanceof Map))
/*      */       {
/*  839 */         localObject2 = (Map)paramObject;
/*  840 */         handleReturnMap(paramDataCenter, (Map)localObject2, "result");
/*      */       }
/*      */       else {
/*  843 */         localObject2 = new ArrayList();
/*  844 */         ((List)localObject2).add(paramObject);
/*  845 */         localObject1 = PojoUtil.toDataStore((List)localObject2, (DataStore)localObject1);
/*  846 */         paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handleReturnList(DataCenter paramDataCenter, List paramList, String paramString)
/*      */   {
/*  862 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore(paramString);
/*  863 */     if (paramList.size() > 0)
/*      */     {
/*  865 */       Object localObject = paramList.get(0);
/*  866 */       if (isCommonType(localObject))
/*      */       {
/*  868 */         JSONArray localJSONArray = JSONArray.fromObject(paramList);
/*  869 */         paramDataCenter.addParameter(paramString, localJSONArray);
/*      */       }
/*      */       else {
/*  872 */         localDataStore = PojoUtil.toDataStore(paramList, localDataStore);
/*  873 */         paramDataCenter.addDataStore(localDataStore);
/*      */       }
/*      */     }
/*      */     else {
/*  877 */       paramDataCenter.addParameter(paramString, "");
/*  878 */       localDataStore = PojoUtil.toDataStore(paramList, localDataStore);
/*  879 */       paramDataCenter.addDataStore(localDataStore);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handleReturnMap(DataCenter paramDataCenter, Map paramMap, String paramString)
/*      */   {
/*  893 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore(paramString);
/*  894 */     if (paramMap.size() > 0)
/*      */     {
/*  896 */       localDataStore = PojoUtil.toDataStore(paramMap, localDataStore);
/*  897 */       paramDataCenter.addDataStore(localDataStore);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Method getBOMethod(Object paramObject, String paramString, String[] paramArrayOfString)
/*      */     throws Exception
/*      */   {
/*  915 */     Method[] arrayOfMethod = paramObject.getClass().getMethods();
/*  916 */     int i = paramArrayOfString == null ? 0 : paramArrayOfString.length;
/*  917 */     Object localObject = null;
/*  918 */     ArrayList localArrayList = new ArrayList();
/*      */     Method localMethod;
/*  919 */     for (int j = 0; j < arrayOfMethod.length; j++)
/*      */     {
/*  921 */       localMethod = arrayOfMethod[j];
/*  922 */       if ((paramString.equals(localMethod.getName())) && (localMethod.getParameterTypes().length == i))
/*      */       {
/*  924 */         localArrayList.add(arrayOfMethod[j]);
/*      */       }
/*      */     }
/*  927 */     Class[][] arrayOfClass; = new Class[localArrayList.size()][];
/*  928 */     for (int k = 0; k < localArrayList.size(); k++)
/*      */     {
/*  930 */       localMethod = (Method)localArrayList.get(k);
/*  931 */       arrayOfClass;[k] = localMethod.getParameterTypes();
/*      */ 
/*  933 */       if ((paramArrayOfString == null) && (arrayOfClass;[k].length == 0))
/*      */       {
/*  935 */         localObject = localMethod;
/*  936 */         break;
/*      */       }
/*      */ 
/*  940 */       String[] arrayOfString = new String[arrayOfClass;[k].length];
/*  941 */       for (int m = 0; m < arrayOfClass;[k].length; m++)
/*      */       {
/*  943 */         arrayOfString[m] = arrayOfClass;[k][m].getName();
/*      */       }
/*      */ 
/*  946 */       if (Arrays.equals(paramArrayOfString, arrayOfString))
/*      */       {
/*  948 */         localObject = localMethod;
/*  949 */         break;
/*      */       }
/*      */     }
/*      */ 
/*  953 */     if (localObject == null)
/*      */     {
/*  956 */       for (k = 0; k < arrayOfClass;.length; k++)
/*      */       {
/*  958 */         if (compareParametersType(paramArrayOfString, arrayOfClass;[k]))
/*      */         {
/*  960 */           localObject = (Method)localArrayList.get(k);
/*  961 */           break;
/*      */         }
/*      */       }
/*      */     }
/*  965 */     return localObject;
/*      */   }
/*      */ 
/*      */   private static List initParameters(ViewContext paramViewContext, List<RestParameter> paramList, Class[] paramArrayOfClass)
/*      */     throws Exception
/*      */   {
/*  980 */     ArrayList localArrayList = new ArrayList();
/*  981 */     if ((paramList != null) && (paramList.size() > 0))
/*      */     {
/*  983 */       for (int i = 0; i < paramList.size(); i++)
/*      */       {
/*  985 */         localArrayList.add(getParam(paramArrayOfClass[i].getName(), (RestParameter)paramList.get(i)));
/*      */       }
/*      */     }
/*  988 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   private static boolean compareParametersType(String[] paramArrayOfString, Class[] paramArrayOfClass)
/*      */     throws ClassNotFoundException
/*      */   {
/* 1004 */     for (int i = 0; 
/* 1005 */       i < paramArrayOfClass.length; i++)
/*      */     {
/* 1007 */       if (paramArrayOfString[i] == null)
/*      */       {
/* 1009 */         return false;
/*      */       }
/*      */ 
/* 1021 */       String str = paramArrayOfString[i].trim();
/* 1022 */       if (!paramArrayOfClass[i].getName().equals(str))
/*      */       {
/*      */         Class localClass;
/* 1028 */         if (TYPEMAP.keySet().contains(str)) {
/* 1030 */           localClass = (Class)TYPEMAP.get(str);
/* 1031 */           str = localClass.getName();
/* 1032 */           if (paramArrayOfClass[i].equals(localClass));
/*      */         }
/*      */         else {
/* 1036 */           localClass = Class.forName(str).getSuperclass();
/* 1037 */           while (localClass != null)
/*      */           {
/* 1039 */             if (paramArrayOfClass[i] == localClass)
/*      */               break;
/* 1041 */             localClass = localClass.getSuperclass();
/*      */           }
/* 1043 */           if (localClass == null) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1049 */     if (i == paramArrayOfClass.length)
/*      */     {
/* 1051 */       return true;
/*      */     }
/* 1053 */     return false;
/*      */   }
/*      */ 
/*      */   public static void invokeStatement(ViewContext paramViewContext, DataCenter paramDataCenter)
/*      */     throws Exception
/*      */   {
/* 1067 */     String str1 = paramViewContext.getString("_statementRef");
/* 1068 */     String str2 = paramViewContext.getString("_dcId");
/* 1069 */     String str3 = DCRepository.getDevelopmentComponent(str2).getSoftwareComponent().getId();
/* 1070 */     String str4 = str3 + File.separator + str2 + File.separator + "statement" + File.separator + str1 + ".xml";
/*      */ 
/* 1073 */     CommonBO localCommonBO = (CommonBO)BeanUtil.getBean("core_commonBO_bo");
/*      */ 
/* 1076 */     if ((paramViewContext.getString("_pageNumber") != null) && (paramViewContext.getString("_pageSize") != null))
/*      */     {
/* 1078 */       localObject1 = new QueryResult();
/* 1079 */       ((QueryResult)localObject1).setPageNumber(Integer.valueOf(paramViewContext.getString("_pageNumber")).intValue());
/* 1080 */       ((QueryResult)localObject1).setPageSize(Integer.valueOf(paramViewContext.getString("_pageSize")).intValue());
/* 1081 */       if (paramViewContext.getString("_calcRecordCount") != null)
/*      */       {
/* 1083 */         ((QueryResult)localObject1).setAutoCalcCount(Boolean.valueOf(paramViewContext.getString("_calcRecordCount")).booleanValue());
/*      */       }
/* 1085 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", localObject1);
/*      */     }
/*      */ 
/* 1088 */     Object localObject1 = paramViewContext.getPOJOList("_advancedQueryConditionStore");
/* 1089 */     if (localObject1 != null)
/*      */     {
/* 1091 */       localObject2 = new QueryCondition();
/* 1092 */       ((QueryCondition)localObject2).setConditions((List)localObject1);
/* 1093 */       UnieapRequestContextHolder.getRequestContext().put("advanceQueryCondition", localObject2);
/*      */     }
/*      */ 
/* 1096 */     Object localObject2 = paramViewContext.getString("parameters");
/*      */ 
/* 1098 */     HashMap localHashMap = null;
/* 1099 */     if (localObject2 != null)
/*      */     {
/* 1101 */       localHashMap = new HashMap();
/* 1102 */       localObject3 = ((String)localObject2).split(",");
/*      */ 
/* 1104 */       for (int i = 0; i < localObject3.length; i++)
/*      */       {
/* 1106 */         localHashMap.put(localObject3[i], paramViewContext.getString(localObject3[i]));
/*      */       }
/*      */     }
/* 1109 */     Object localObject3 = new StatementImpl(str4);
/* 1110 */     String str5 = ((Statement)localObject3).getDataSourceID();
/* 1111 */     if ((str5 != null) && (!"".equals(str5)))
/*      */     {
/* 1113 */       DataSourceContextHolder.setDataSourceType(str5);
/*      */     }
/*      */ 
/* 1116 */     QueryResult localQueryResult = localCommonBO.findByStatement(str4, localHashMap);
/*      */ 
/* 1118 */     Class localClass = localQueryResult.getClass();
/* 1119 */     handleBoMethodReturn(paramDataCenter, localQueryResult, localClass, null);
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.util.RestUtil
 * JD-Core Version:    0.6.2
 */