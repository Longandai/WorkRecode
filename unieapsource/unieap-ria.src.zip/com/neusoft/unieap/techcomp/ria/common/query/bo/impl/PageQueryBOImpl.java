/*    */ package com.neusoft.unieap.techcomp.ria.common.query.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*    */ import com.neusoft.unieap.core.page.PageContext;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.bo.PageQueryBO;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.dao.PageQueryDAO;
/*    */ 
/*    */ @ModelFile("pageQueryBO.bo")
/*    */ public class PageQueryBOImpl
/*    */   implements PageQueryBO
/*    */ {
/*    */   private PageQueryDAO pageQueryDAO;
/*    */ 
/*    */   public void setPageQueryDAO(PageQueryDAO paramPageQueryDAO)
/*    */   {
/* 22 */     this.pageQueryDAO = paramPageQueryDAO;
/*    */   }
/*    */ 
/*    */   public PageQueryDAO getPageQueryDAO()
/*    */   {
/* 31 */     return this.pageQueryDAO;
/*    */   }
/*    */ 
/*    */   public QueryResult query(PageContext paramPageContext) {
/* 35 */     if (paramPageContext != null) {
/* 36 */       String str = paramPageContext.getType();
/* 37 */       if ("HQL".equals(str)) {
/* 38 */         return this.pageQueryDAO.queryByHQL(paramPageContext);
/*    */       }
/* 40 */       if ("SQL".equals(str)) {
/* 41 */         return this.pageQueryDAO.queryBySQL(paramPageContext);
/*    */       }
/* 43 */       if ("Statement".equals(str)) {
/* 44 */         return this.pageQueryDAO.queryBySQL(paramPageContext);
/*    */       }
/* 46 */       if ("SDMQ".equals(str)) {
/* 47 */         return this.pageQueryDAO.queryBySqlMapping(paramPageContext);
/*    */       }
/*    */     }
/* 50 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.impl.PageQueryBOImpl
 * JD-Core Version:    0.6.2
 */