/*    */ package com.neusoft.unieap.techcomp.ria.common.query.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.dao.QueryDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.entity.QueryCondition;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ public class QueryDAOImpl extends BaseHibernateDAO
/*    */   implements QueryDAO
/*    */ {
/*    */   private static final long serialVersionUID = -2789328028836243964L;
/*    */ 
/*    */   public List getQeurySegmentData(String paramString1, String paramString2, Object[] paramArrayOfObject, int paramInt1, int paramInt2, String paramString3)
/*    */   {
/* 19 */     String str = getQueryHql(paramString1, paramString2, paramString3);
/* 20 */     return queryObjects(str, paramArrayOfObject, paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   public List getQueryAllData(String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3)
/*    */   {
/* 25 */     String str = getQueryHql(paramString1, paramString2, paramString3);
/* 26 */     return queryObjects(str, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public int getRecordCount(String paramString1, String paramString2, Object[] paramArrayOfObject)
/*    */   {
/* 31 */     if (((paramString1 == null) || ("".equals(paramString1.trim()))) && ((paramString2 == null) || ("".equals(paramString2.trim())))) {
/* 32 */       return 0;
/*    */     }
/* 34 */     String str = "select count(*) from " + paramString1 + " where " + paramString2;
/* 35 */     Long localLong = (Long)queryObject(str, paramArrayOfObject);
/* 36 */     return localLong.intValue();
/*    */   }
/*    */ 
/*    */   private String getQueryHql(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 41 */     StringBuffer localStringBuffer = new StringBuffer();
/* 42 */     localStringBuffer.append(" from " + paramString1 + " where " + paramString2);
/* 43 */     if ((paramString3 != null) && (!paramString3.equals(""))) {
/* 44 */       localStringBuffer.append(" ORDER BY " + paramString3);
/*    */     }
/* 46 */     return localStringBuffer.toString();
/*    */   }
/*    */ 
/*    */   public QueryCondition saveQueryCondition(QueryCondition paramQueryCondition)
/*    */   {
/* 52 */     getHibernateTemplate().save(paramQueryCondition);
/* 53 */     return paramQueryCondition;
/*    */   }
/*    */ 
/*    */   public List queryHistoryConditions(String paramString1, String paramString2, String paramString3, String paramString4)
/*    */   {
/* 58 */     ArrayList localArrayList = new ArrayList();
/* 59 */     String str = "from QueryCondition condition where condition.viewId = ? and condition.controlId = ?";
/* 60 */     localArrayList.add(paramString1);
/* 61 */     localArrayList.add(paramString2);
/* 62 */     if (paramString3 != null) {
/* 63 */       str = str + " and condition.createdBy = ?";
/* 64 */       localArrayList.add(paramString3);
/*    */     }
/* 66 */     if ((paramString4 != null) && (!paramString4.equals(""))) {
/* 67 */       str = str + " and condition.label = ?";
/* 68 */       localArrayList.add(paramString4);
/*    */     }
/*    */ 
/* 71 */     return getHibernateTemplate().find(str, localArrayList.toArray());
/*    */   }
/*    */ 
/*    */   public void deleteHistoryCondition(String paramString) {
/* 75 */     String str = "delete from QueryCondition condition where condition.id = ?";
/* 76 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dao.impl.QueryDAOImpl
 * JD-Core Version:    0.6.2
 */