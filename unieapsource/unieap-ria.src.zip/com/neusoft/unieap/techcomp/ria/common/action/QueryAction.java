/*     */ package com.neusoft.unieap.techcomp.ria.common.action;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.bo.QueryBO;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.entity.QueryCondition;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import com.thoughtworks.xstream.io.xml.DomDriver;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.sf.json.JSONArray;
/*     */ 
/*     */ public class QueryAction extends BaseProcessor
/*     */ {
/*  19 */   private QueryBO queryBO = null;
/*     */   private static final String ENTITYCLASS = "_entityClass";
/*     */   public static final int NOPAGESIZE = 2000000;
/*  25 */   private static final String AdvancedQueryCondition = null;
/*     */ 
/*     */   public void doQuery()
/*     */     throws Exception
/*     */   {
/*  35 */     ViewContext localViewContext = generateContext();
/*  36 */     String str1 = localViewContext.getString("_entityClass");
/*  37 */     String str2 = "_queryResultStore";
/*  38 */     Class localClass = null;
/*  39 */     String str3 = "";
/*     */ 
/*  41 */     if (str1 != null) {
/*  42 */       localClass = Class.forName(str1);
/*  43 */       str3 = localClass.getSimpleName();
/*     */     }
/*     */ 
/*  46 */     DataCenter localDataCenter1 = localViewContext.getDataCenter();
/*  47 */     DataStore localDataStore = localDataCenter1.getDataStore(str2);
/*     */ 
/*  50 */     List localList1 = localViewContext.getPOJOList("_advancedQueryConditionStore");
/*     */ 
/*  53 */     int i = 1;
/*  54 */     int j = 2000001;
/*  55 */     if (localDataStore != null) {
/*  56 */       i = localDataStore.getPageNumber();
/*  57 */       j = localDataStore.getPageSize();
/*     */     } else {
/*  59 */       localDataStore = DataCenterFactory.getInstance().createDataStore(str2);
/*     */     }
/*     */ 
/*  62 */     List localList2 = getQueryBO().getQueryData(localList1, str3, 
/*  63 */       i, j);
/*  64 */     localDataStore = PojoUtil.toDataStore(localList2, localDataStore);
/*     */ 
/*  66 */     int k = 0;
/*  67 */     if (j < 2000000) {
/*  68 */       k = getQueryBO().getRecordCount(localList1, 
/*  69 */         str3);
/*     */     }
/*     */ 
/*  73 */     DataCenter localDataCenter2 = DataCenterFactory.getInstance().createDataCenter();
/*  74 */     localDataStore.setStoreName(str2);
/*  75 */     localDataStore.setRecordCount(k);
/*  76 */     if ((j <= 2000000) && (i > 0)) {
/*  77 */       localDataStore.setPageSize(j);
/*  78 */       localDataStore.setPageNumber(i);
/*     */     }
/*  80 */     localDataCenter2.addDataStore(localDataStore);
/*  81 */     super.write(localDataCenter2);
/*     */   }
/*     */ 
/*     */   public void doSave()
/*     */     throws Exception
/*     */   {
/*  90 */     ViewContext localViewContext = generateContext();
/*  91 */     List localList = localViewContext.getPOJOList("_advancedQueryConditionStore");
/*  92 */     String str1 = localViewContext.getString("_viewId");
/*  93 */     String str2 = localViewContext.getString("_conditionName");
/*  94 */     String str3 = localViewContext.getString("_controlId");
/*  95 */     String str4 = localViewContext.getString("_queryLabel");
/*  96 */     QueryCondition localQueryCondition = getQueryBO().saveQueryCondition(localList, str1, str2, str3, str4);
/*  97 */     localQueryCondition.setCondition(JSONArray.fromObject(localList).toString());
/*  98 */     DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/*  99 */     ArrayList localArrayList = new ArrayList();
/* 100 */     localArrayList.add(localQueryCondition);
/* 101 */     DataStore localDataStore = PojoUtil.toDataStore(localArrayList);
/* 102 */     localDataStore.setStoreName("_advancedQueryConditionStore");
/* 103 */     localDataCenter.addDataStore(localDataStore);
/* 104 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void doQueryHistoryConditions()
/*     */     throws Exception
/*     */   {
/* 113 */     ViewContext localViewContext = generateContext();
/* 114 */     String str1 = localViewContext.getString("_viewId");
/* 115 */     String str2 = localViewContext.getString("_controlId");
/* 116 */     String str3 = localViewContext.getString("_queryLabel");
/* 117 */     List localList1 = getQueryBO().queryHistoryConditions(str1, str2, str3);
/* 118 */     XStream localXStream = new XStream(new DomDriver());
/* 119 */     for (int i = 0; i < localList1.size(); i++) {
/* 120 */       localObject = (QueryCondition)localList1.get(i);
/* 121 */       String str4 = ((QueryCondition)localObject).getCondition();
/* 122 */       List localList2 = (List)localXStream.fromXML(str4);
/* 123 */       ((QueryCondition)localObject).setCondition(JSONArray.fromObject(localList2).toString());
/*     */     }
/* 125 */     DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/* 126 */     Object localObject = PojoUtil.toDataStore(localList1);
/* 127 */     ((DataStore)localObject).setStoreName("_advancedQueryHistoryConditions");
/* 128 */     localDataCenter.addDataStore((DataStore)localObject);
/* 129 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void doDelete()
/*     */     throws Exception
/*     */   {
/* 138 */     ViewContext localViewContext = generateContext();
/* 139 */     String str = localViewContext.getString("_advancedConditionId");
/* 140 */     getQueryBO().deleteHistoryCondition(str);
/* 141 */     DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/* 142 */     super.write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void setQueryBO(QueryBO paramQueryBO)
/*     */   {
/* 147 */     this.queryBO = paramQueryBO;
/*     */   }
/*     */ 
/*     */   public QueryBO getQueryBO() {
/* 151 */     return this.queryBO;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.action.QueryAction
 * JD-Core Version:    0.6.2
 */