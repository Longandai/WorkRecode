/*      */ package com.neusoft.unieap.techcomp.ria.common.util;
/*      */ 
/*      */ class RestParameter
/*      */ {
/*      */   private String type;
/*      */   private String value;
/*      */   private String clazz;
/*      */ 
/*      */   public String getType()
/*      */   {
/* 1132 */     return this.type;
/*      */   }
/*      */ 
/*      */   public void setType(String paramString)
/*      */   {
/* 1137 */     this.type = paramString;
/*      */   }
/*      */ 
/*      */   public String getValue()
/*      */   {
/* 1142 */     return this.value;
/*      */   }
/*      */ 
/*      */   public void setValue(String paramString)
/*      */   {
/* 1147 */     this.value = paramString;
/*      */   }
/*      */ 
/*      */   public void setClazz(String paramString)
/*      */   {
/* 1152 */     this.clazz = paramString;
/*      */   }
/*      */ 
/*      */   public String getClazz()
/*      */   {
/* 1157 */     return this.clazz;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.util.RestParameter
 * JD-Core Version:    0.6.2
 */