/*    */ package com.neusoft.unieap.techcomp.ria.common.query.pojo;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class QueryCondition
/*    */ {
/*    */   private List conditions;
/*    */ 
/*    */   public void setConditions(List paramList)
/*    */   {
/* 10 */     this.conditions = paramList;
/*    */   }
/*    */ 
/*    */   public List getConditions() {
/* 14 */     return this.conditions;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition
 * JD-Core Version:    0.6.2
 */