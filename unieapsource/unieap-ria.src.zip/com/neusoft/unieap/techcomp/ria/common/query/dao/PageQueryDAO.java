package com.neusoft.unieap.techcomp.ria.common.query.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.core.page.PageContext;
import org.hibernate.SessionFactory;

public abstract interface PageQueryDAO
{
  public abstract QueryResult queryByHQL(PageContext paramPageContext);

  public abstract QueryResult queryBySQL(PageContext paramPageContext);

  public abstract QueryResult queryBySqlMapping(PageContext paramPageContext);

  public abstract void setSessionFactory(SessionFactory paramSessionFactory);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dao.PageQueryDAO
 * JD-Core Version:    0.6.2
 */