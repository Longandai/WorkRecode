/*     */ package com.neusoft.unieap.techcomp.ria.common.query.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.bo.QueryBO;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.dao.QueryDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.entity.QueryCondition;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.util.ZipUtil;
/*     */ import com.thoughtworks.xstream.XStream;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ 
/*     */ public class QueryBOImpl
/*     */   implements QueryBO
/*     */ {
/*     */   private static final long serialVersionUID = 3463230858744544571L;
/*     */   public static final int NOPAGESIZE = 2000000;
/*  21 */   private QueryDAO queryDAO = null;
/*     */ 
/*     */   public final QueryDAO getQueryDAO() {
/*  24 */     return this.queryDAO;
/*     */   }
/*     */ 
/*     */   public final void setQueryDAO(QueryDAO paramQueryDAO) {
/*  28 */     this.queryDAO = paramQueryDAO;
/*     */   }
/*     */ 
/*     */   public List getQueryData(List paramList, String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  33 */     List localList = null;
/*     */ 
/*  36 */     String str1 = AdvanceQueryUtil.getHQLCondition(paramList, "");
/*  37 */     Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues(paramList);
/*  38 */     String str2 = AdvanceQueryUtil.getOrder();
/*  39 */     if ((str1 == null) || (str1.trim().equals(""))) {
/*  40 */       str1 = " 1 = 1 ";
/*     */     }
/*     */ 
/*  43 */     if ((paramInt2 > 2000000) || (paramInt2 < 0))
/*  44 */       localList = this.queryDAO.getQueryAllData(paramString, str1, arrayOfObject, str2);
/*     */     else {
/*  46 */       localList = this.queryDAO.getQeurySegmentData(paramString, str1, arrayOfObject, paramInt1, paramInt2, str2);
/*     */     }
/*  48 */     return localList;
/*     */   }
/*     */ 
/*     */   public int getRecordCount(List paramList, String paramString) {
/*  52 */     int i = 0;
/*     */ 
/*  54 */     String str = AdvanceQueryUtil.getHQLCondition(paramList, "");
/*  55 */     Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues(paramList);
/*     */ 
/*  57 */     if ((str == null) || (str.trim().equals(""))) {
/*  58 */       str = " 1 = 1 ";
/*     */     }
/*  60 */     i = this.queryDAO.getRecordCount(paramString, str, arrayOfObject);
/*  61 */     return i;
/*     */   }
/*     */ 
/*     */   public QueryCondition saveQueryCondition(List paramList, String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/*  66 */     QueryCondition localQueryCondition = new QueryCondition();
/*  67 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  68 */     String str1 = "";
/*  69 */     if (localUser != null) {
/*  70 */       str1 = localUser.getAccount();
/*     */     }
/*  72 */     localQueryCondition.setCreatedBy(str1);
/*  73 */     localQueryCondition.setName(paramString2);
/*  74 */     localQueryCondition.setViewId(paramString1);
/*  75 */     localQueryCondition.setControlId(paramString3);
/*  76 */     localQueryCondition.setLabel(paramString4);
/*  77 */     XStream localXStream = new XStream();
/*  78 */     String str2 = localXStream.toXML(paramList);
/*     */     try
/*     */     {
/*  81 */       str2 = ZipUtil.compress(str2);
/*     */     } catch (IOException localIOException) {
/*  83 */       return null;
/*     */     }
/*  85 */     localQueryCondition.setCondition(str2);
/*  86 */     return this.queryDAO.saveQueryCondition(localQueryCondition);
/*     */   }
/*     */ 
/*     */   public List queryHistoryConditions(String paramString1, String paramString2, String paramString3) {
/*  90 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  91 */     String str1 = "";
/*  92 */     if (localUser != null) {
/*  93 */       str1 = localUser.getAccount();
/*     */     }
/*  95 */     List localList = this.queryDAO.queryHistoryConditions(paramString1, paramString2, str1, paramString3);
/*     */ 
/*  97 */     for (int i = 0; i < localList.size(); i++) { QueryCondition localQueryCondition = (QueryCondition)localList.get(i);
/*  99 */       String str2 = localQueryCondition.getCondition();
/*     */       String str3;
/*     */       try { str3 = ZipUtil.uncompress(str2);
/*     */       } catch (IOException localIOException) {
/* 104 */         str3 = "";
/*     */       }
/* 106 */       localQueryCondition.setCondition(str3);
/*     */     }
/*     */ 
/* 109 */     return localList;
/*     */   }
/*     */ 
/*     */   public void deleteHistoryCondition(String paramString) {
/* 113 */     this.queryDAO.deleteHistoryCondition(paramString);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.impl.QueryBOImpl
 * JD-Core Version:    0.6.2
 */