/*      */ package com.neusoft.unieap.techcomp.ria.common.util;
/*      */ 
/*      */ import com.neusoft.unieap.core.CoreVariability;
/*      */ import com.neusoft.unieap.core.base.model.DCRepository;
/*      */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*      */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*      */ import com.neusoft.unieap.core.common.bo.CommonBO;
/*      */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*      */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*      */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*      */ import com.neusoft.unieap.core.common.form.Form;
/*      */ import com.neusoft.unieap.core.context.UniEAPContext;
/*      */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*      */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*      */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*      */ import com.neusoft.unieap.core.context.properties.User;
/*      */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*      */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*      */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*      */ import com.neusoft.unieap.core.i18n.GlobalService;
/*      */ import com.neusoft.unieap.core.page.PageContext;
/*      */ import com.neusoft.unieap.core.page.PageUtil;
/*      */ import com.neusoft.unieap.core.statement.Statement;
/*      */ import com.neusoft.unieap.core.statement.impl.StatementImpl;
/*      */ import com.neusoft.unieap.core.util.BeanUtil;
/*      */ import com.neusoft.unieap.core.util.InteractionUtil;
/*      */ import com.neusoft.unieap.techcomp.cache.EAPCache;
/*      */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*      */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.CacheTaskUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.CodeList;
/*      */ import com.neusoft.unieap.techcomp.ria.codelist.entity.Code;
/*      */ import com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition;
/*      */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*      */ import com.neusoft.unieap.techcomp.ria.context.util.ContextUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.Column;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.MetaData;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.impl.DataStoreImpl;
/*      */ import com.neusoft.unieap.techcomp.ria.ds.impl.MetaDataImpl;
/*      */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*      */ import com.neusoft.unieap.techcomp.ria.io.DataCenterReader;
/*      */ import com.neusoft.unieap.techcomp.ria.util.Base64;
/*      */ import com.neusoft.unieap.techcomp.ria.util.MetaDataUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.util.PojoUtil;
/*      */ import com.neusoft.unieap.techcomp.ria.util.ViewContextUtil;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.servlet.ServletOutputStream;
/*      */ import javax.servlet.http.HttpServletRequest;
/*      */ import javax.servlet.http.HttpServletResponse;
/*      */ import net.sf.json.JSONArray;
/*      */ import net.sf.json.JSONObject;
/*      */ import net.sf.json.util.JSONUtils;
/*      */ import org.apache.poi.ss.usermodel.Workbook;
/*      */ import org.apache.struts2.ServletActionContext;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.engine.NamedQueryDefinition;
/*      */ import org.hibernate.engine.SessionFactoryImplementor;
/*      */ 
/*      */ public class CommonUtil
/*      */ {
/*      */   public static final String POJO_INDEX_IN_CONTEXT = "_pojoIndexInContext";
/*      */   public static final String DATASTORE = "dataStore";
/*      */   public static final String MAP = "map";
/*      */   public static final String BOID = "_boId";
/*      */   public static final String METHODNAME = "_methodName";
/*      */   public static final String PARAMETERS = "_parameters";
/*      */   public static final String PARAMETERTYPES = "_parameterTypes";
/*      */   public static final String DATASOURCEID = "_dataSourceID";
/*      */   public static final String METHODPARAMETERTYPES = "_methodParameterTypes";
/*      */   public static final String RESULT = "result";
/*      */   public static final String DATASTORE_PRIMARY = "primary";
/*      */   public static final String FORM_PARAMETER_TYPE = "com.neusoft.unieap.core.common.form.Form";
/*      */   public static final String DATACENTER_PARAMETER_TYPE = "com.neusoft.unieap.techcomp.ria.ds.DataCenter";
/*      */   public static final String UPLOAD_FORM_STORE = "_uploadFormStore";
/*      */   public static final String PAGENUMBER = "_pageNumber";
/*      */   public static final String PAGESIZE = "_pageSize";
/*      */   public static final String CALCCOUNT = "_calcRecordCount";
/*      */   public static final String NAMED_QUERY = "_namedQuery";
/*      */   public static final String QUERYPARAMETERTYPES = "_queryParameterTypes";
/*      */   public static final String STATEMENT = "_statement";
/*      */   public static final String STATEMENT_REF = "_statementRef";
/*      */   public static final String STATEMENT_PAGESIZE = "_statementPageSize";
/*      */   public static final String STATEMENT_PAGENUMBER = "_statementPageNumber";
/*      */   public static final String DCID = "_dcId";
/*      */   public static final String POJO_CONTEXT = "pojoContext";
/*  127 */   public static final String[] PrimitiveTypes = { "int", "float", "double", 
/*  128 */     "boolean", "short", "byte", "char", "long" };
/*      */ 
/*      */   public static boolean isBaseDataType(String paramString)
/*      */   {
/*  131 */     for (int i = 0; i < PrimitiveTypes.length; i++) {
/*  132 */       if (PrimitiveTypes[i].equals(paramString)) {
/*  133 */         return true;
/*      */       }
/*      */     }
/*  136 */     return false;
/*      */   }
/*      */ 
/*      */   public static void invokeNamedQuery(ViewContext paramViewContext, DataCenter paramDataCenter, SessionFactory paramSessionFactory)
/*      */     throws Exception
/*      */   {
/*  151 */     String str1 = paramViewContext.getString("_namedQuery");
/*  152 */     String str2 = paramViewContext
/*  153 */       .getString("_queryParameterTypes");
/*      */ 
/*  155 */     CommonBO localCommonBO = (CommonBO)BeanUtil.getBean("core_commonBO_bo");
/*      */ 
/*  157 */     Object localObject1 = new ArrayList();
/*      */ 
/*  159 */     if ((paramViewContext.getString("_pageNumber") != null) && 
/*  160 */       (paramViewContext.getString("_pageSize") != null)) {
/*  161 */       localObject2 = new QueryResult();
/*  162 */       ((QueryResult)localObject2).setPageNumber(Integer.valueOf(paramViewContext
/*  163 */         .getString("_pageNumber")).intValue());
/*      */ 
/*  164 */       ((QueryResult)localObject2).setPageSize(Integer.valueOf(paramViewContext
/*  165 */         .getString("_pageSize")).intValue());
/*      */ 
/*  166 */       if (paramViewContext.getString("_calcRecordCount") != null) {
/*  167 */         ((QueryResult)localObject2).setAutoCalcCount(Boolean.valueOf(paramViewContext
/*  168 */           .getString("_calcRecordCount")).booleanValue());
/*      */       }
/*      */ 
/*  170 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  171 */         localObject2);
/*      */     }
/*      */ 
/*  174 */     Object localObject2 = paramViewContext.getPOJOList("_advancedQueryConditionStore");
/*  175 */     if (localObject2 != null) {
/*  176 */       localObject3 = new QueryCondition();
/*  177 */       ((QueryCondition)localObject3).setConditions((List)localObject2);
/*  178 */       UnieapRequestContextHolder.getRequestContext().put(
/*  179 */         "advanceQueryCondition", localObject3);
/*      */     }
/*      */ 
/*  182 */     Object localObject3 = (String[])null;
/*  183 */     if ((str2 != null) && 
/*  184 */       (!str2.trim().equals(""))) {
/*  185 */       localObject3 = str2.split(",");
/*      */     }
/*      */ 
/*  188 */     Class[] arrayOfClass = convertToClassTypes((String[])localObject3);
/*      */ 
/*  191 */     String str3 = paramViewContext.getString("_parameters");
/*      */ 
/*  193 */     if ((str3 != null) && (!str3.equals(""))) {
/*  194 */       localObject1 = initParameters(paramViewContext, str3, 
/*  195 */         arrayOfClass);
/*      */     }
/*      */ 
/*  198 */     if ((paramSessionFactory instanceof SessionFactoryImplementor)) {
/*  199 */       localObject4 = (SessionFactoryImplementor)paramSessionFactory;
/*  200 */       localObject5 = ((SessionFactoryImplementor)localObject4)
/*  201 */         .getNamedQuery(str1);
/*  202 */       if (localObject5 != null) {
/*  203 */         String str4 = ((NamedQueryDefinition)localObject5).getComment();
/*  204 */         if ((str4 != null) && (!"".equals(str4))) {
/*  205 */           DataSourceContextHolder.setDataSourceType(str4);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  210 */     Object localObject4 = localCommonBO.findByNamedQuery(str1, ((List)localObject1)
/*  211 */       .toArray());
/*      */ 
/*  213 */     Object localObject5 = localObject4.getClass();
/*  214 */     handleBoMethodReturn(paramDataCenter, localObject4, (Class)localObject5);
/*      */   }
/*      */ 
/*      */   public static Class[] convertToClassTypes(String[] paramArrayOfString)
/*      */   {
/*  219 */     ArrayList localArrayList = new ArrayList();
/*  220 */     if (paramArrayOfString != null) {
/*  221 */       for (int i = 0; i < paramArrayOfString.length; i++) {
/*  222 */         if (paramArrayOfString[i].equals("string"))
/*  223 */           localArrayList.add(String.class);
/*  224 */         else if (paramArrayOfString[i].equals("int"))
/*  225 */           localArrayList.add(Integer.class);
/*  226 */         else if (paramArrayOfString[i].equals("long"))
/*  227 */           localArrayList.add(Long.class);
/*  228 */         else if (paramArrayOfString[i].equals("float"))
/*  229 */           localArrayList.add(Float.class);
/*  230 */         else if (paramArrayOfString[i].equals("double"))
/*  231 */           localArrayList.add(Double.class);
/*      */         else
/*      */           try {
/*  234 */             Class localClass = Class.forName(paramArrayOfString[i]);
/*  235 */             if (localClass != null)
/*  236 */               localArrayList.add(localClass);
/*      */           }
/*      */           catch (ClassNotFoundException localClassNotFoundException)
/*      */           {
/*      */           }
/*      */       }
/*      */     }
/*  243 */     return (Class[])localArrayList.toArray(new Class[localArrayList.size()]);
/*      */   }
/*      */ 
/*      */   public static void invokeBoMethod(ViewContext paramViewContext, DataCenter paramDataCenter, Object paramObject)
/*      */     throws Exception
/*      */   {
/*  258 */     String str1 = paramViewContext.getString("_boId");
/*  259 */     String str2 = paramViewContext.getString("_methodName");
/*  260 */     String str3 = paramViewContext
/*  261 */       .getString("_methodParameterTypes");
/*      */ 
/*  263 */     if (str2 == null) {
/*  264 */       throw new RIAException("EAPTECH008010", null);
/*      */     }
/*      */ 
/*  268 */     String str4 = paramViewContext.getString("_dataSourceID");
/*      */ 
/*  271 */     if ((paramViewContext.getString("_pageNumber") != null) && 
/*  272 */       (paramViewContext.getString("_pageSize") != null)) {
/*  273 */       localObject1 = new QueryResult();
/*  274 */       ((QueryResult)localObject1).setPageNumber(Integer.valueOf(paramViewContext
/*  275 */         .getString("_pageNumber")).intValue());
/*      */ 
/*  276 */       ((QueryResult)localObject1).setPageSize(Integer.valueOf(paramViewContext
/*  277 */         .getString("_pageSize")).intValue());
/*      */ 
/*  278 */       if (paramViewContext.getString("_calcRecordCount") != null) {
/*  279 */         ((QueryResult)localObject1).setAutoCalcCount(Boolean.valueOf(paramViewContext
/*  280 */           .getString("_calcRecordCount")).booleanValue());
/*      */       }
/*      */ 
/*  282 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  283 */         localObject1);
/*      */     }
/*      */ 
/*  287 */     Object localObject1 = paramViewContext.getPOJOList("_advancedQueryConditionStore");
/*  288 */     if (localObject1 != null) {
/*  289 */       localObject2 = new QueryCondition();
/*  290 */       ((QueryCondition)localObject2).setConditions((List)localObject1);
/*  291 */       UnieapRequestContextHolder.getRequestContext().put(
/*  292 */         "advanceQueryCondition", localObject2);
/*      */     }
/*      */ 
/*  295 */     Object localObject2 = (String[])null;
/*  296 */     if ((str3 != null) && 
/*  297 */       (!str3.trim().equals(""))) {
/*  298 */       localObject2 = str3.split(",");
/*      */     }
/*  300 */     Method localMethod = getBOMethod(paramObject, str2, (String[])localObject2);
/*      */ 
/*  303 */     if (localMethod == null) {
/*  304 */       localObject3 = new Object[] { str1, str2, str3 };
/*  305 */       throw new RIAException("EAPTECH008008", (Object[])localObject3);
/*      */     }
/*      */ 
/*  309 */     Object localObject3 = InteractionUtil.getInteractionValue(paramObject, 
/*  310 */       localMethod);
/*  311 */     if (localObject3 == null) {
/*  312 */       if (CoreVariability.isPrecheckForInteraction())
/*      */       {
/*  314 */         throw new UniEAPBusinessException("EAPTECHRIA1001");
/*      */       }
/*      */ 
/*      */     }
/*  318 */     else if (ViewContextUtil.getViewContext() != null) {
/*  319 */       ViewContextUtil.getViewContext().put("BUSINESS_REQUEST_ID", 
/*  320 */         localObject3);
/*      */     }
/*      */ 
/*  324 */     if (ViewContextUtil.getViewContext() != null) {
/*  325 */       str5 = ViewContextUtil.getViewContext().getString("dcID");
/*  326 */       if ((str5 != null) && 
/*  327 */         (DCRepository.getDevelopmentComponent(str5) != null)) {
/*  328 */         localObject4 = DCRepository.getDevelopmentComponent(str5)
/*  329 */           .getSoftwareComponent().getId();
/*  330 */         if (localObject4 != null) {
/*  331 */           ViewContextUtil.getViewContext().put("scID", localObject4);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  337 */     String str5 = paramViewContext.getString("_parameters");
/*  338 */     Object localObject4 = localMethod.getParameterTypes();
/*  339 */     Object localObject5 = new ArrayList();
/*  340 */     String[] arrayOfString = new String[0];
/*  341 */     if ((str5 != null) && (!str5.equals("")))
/*      */     {
/*  343 */       localObject5 = initParameters(paramViewContext, str5, 
/*  344 */         (Class[])localObject4);
/*      */     }
/*      */ 
/*  348 */     Class[] arrayOfClass = localMethod.getParameterTypes();
/*  349 */     if ((arrayOfClass != null) && (arrayOfClass.length > 0)) {
/*  350 */       for (int i = 0; i < arrayOfClass.length; i++) {
/*  351 */         if ((!arrayOfClass[i].getName().equals(String.class.getName())) && 
/*  352 */           (((List)localObject5).get(i) == null) && 
/*  353 */           (isCommonType(arrayOfClass[i])))
/*      */         {
/*  357 */           Object[] arrayOfObject = { arrayOfString[i].toString(), arrayOfClass[i] };
/*  358 */           throw new RIAException("EAPTECH008009", arrayOfObject);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  364 */     Object localObject6 = null;
/*      */     try {
/*  366 */       if ((str4 != null) && (!"".equals(str4))) {
/*  367 */         DataSourceContextHolder.setDataSourceType(str4);
/*  368 */         localObject6 = localMethod.invoke(paramObject, ((List)localObject5).toArray());
/*      */       } else {
/*  370 */         localObject6 = localMethod.invoke(paramObject, ((List)localObject5).toArray());
/*      */       }
/*      */     }
/*      */     catch (InvocationTargetException localInvocationTargetException) {
/*  374 */       Throwable localThrowable1 = localInvocationTargetException.getCause();
/*      */ 
/*  376 */       if (localThrowable1 != null) {
/*  377 */         if ((localThrowable1 instanceof Exception))
/*  378 */           throw ((Exception)localThrowable1);
/*  379 */         if ((localThrowable1 instanceof Error))
/*  380 */           throw ((Error)localThrowable1);
/*      */         try
/*      */         {
/*  383 */           throw localThrowable1;
/*      */         } catch (Throwable localThrowable2) {
/*  385 */           localThrowable2.printStackTrace();
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception localException) {
/*  390 */       throw localException;
/*      */     }
/*      */ 
/*  394 */     Class localClass = localMethod.getReturnType();
/*  395 */     handleBoMethodReturn(paramDataCenter, localObject6, localClass);
/*      */ 
/*  397 */     handleDefaultResponseResult(paramDataCenter, paramViewContext);
/*      */   }
/*      */ 
/*      */   private static Object initFormParameters(ViewContext paramViewContext) throws Exception
/*      */   {
/*  402 */     Form localForm = new Form();
/*      */ 
/*  404 */     List localList = paramViewContext.getFileAttachments();
/*  405 */     if ((localList != null) && (localList.size() > 0)) {
/*  406 */       localForm.setFiles(localList);
/*      */     }
/*  408 */     DataStore localDataStore = paramViewContext.getDataStore("_uploadFormStore");
/*  409 */     Object localObject = null;
/*  410 */     if (localDataStore != null) {
/*  411 */       String str = localDataStore.getRowSetName();
/*  412 */       if ((str == null) || (str.trim().length() == 0))
/*  413 */         localObject = paramViewContext.getPojoWithContext("_uploadFormStore");
/*      */       else {
/*  415 */         localObject = paramViewContext.getPOJO("_uploadFormStore");
/*      */       }
/*      */     }
/*  418 */     localForm.setObject(localObject);
/*      */ 
/*  420 */     return localForm;
/*      */   }
/*      */ 
/*      */   private static Object initDataCenterParameters(String paramString)
/*      */     throws Exception
/*      */   {
/*  432 */     if (JSONUtils.mayBeJSON(paramString)) {
/*  433 */       DataCenter localDataCenter = DataCenterIOManager.createReader(paramString).parse();
/*  434 */       return localDataCenter;
/*      */     }
/*  436 */     return null;
/*      */   }
/*      */ 
/*      */   public static boolean isPrimitiveType(Object paramObject)
/*      */   {
/*  447 */     if ((paramObject instanceof String)) {
/*  448 */       return true;
/*      */     }
/*  450 */     if ((paramObject instanceof Number)) {
/*  451 */       return true;
/*      */     }
/*  453 */     if ((paramObject instanceof Character)) {
/*  454 */       return true;
/*      */     }
/*  456 */     if ((paramObject instanceof Boolean)) {
/*  457 */       return true;
/*      */     }
/*  459 */     return false;
/*      */   }
/*      */ 
/*      */   public static boolean isCommonType(Object paramObject)
/*      */   {
/*  469 */     if (isPrimitiveType(paramObject)) {
/*  470 */       return true;
/*      */     }
/*  472 */     if ((paramObject instanceof BigDecimal)) {
/*  473 */       return true;
/*      */     }
/*  475 */     if ((paramObject instanceof Date)) {
/*  476 */       return true;
/*      */     }
/*  478 */     return false;
/*      */   }
/*      */ 
/*      */   public static Object getParam(String paramString1, String paramString2, ViewContext paramViewContext)
/*      */   {
/*  491 */     Object localObject = paramViewContext.get(paramString2);
/*  492 */     if ((isBaseDataType(paramString1)) && (localObject == null)) {
/*  493 */       throw new IllegalArgumentException("The parameter of " + paramString2 + 
/*  494 */         " is null.");
/*      */     }
/*  496 */     if (localObject == null) {
/*  497 */       return null;
/*      */     }
/*  499 */     String str = paramViewContext.getString(paramString2);
/*      */     try {
/*  501 */       if (paramString1.equals(String.class.getName())) {
/*  502 */         return String.valueOf(str);
/*      */       }
/*  504 */       if ((paramString1.equals(Integer.class.getName())) || (paramString1.equals("int"))) {
/*  505 */         return Integer.valueOf(str);
/*      */       }
/*  507 */       if ((paramString1.equals(Float.class.getName())) || (paramString1.equals("float"))) {
/*  508 */         return Float.valueOf(str);
/*      */       }
/*  510 */       if ((paramString1.equals(Double.class.getName())) || (paramString1.equals("double"))) {
/*  511 */         return Double.valueOf(str);
/*      */       }
/*  513 */       if ((paramString1.equals(Boolean.class.getName())) || (paramString1.equals("boolean"))) {
/*  514 */         return Boolean.valueOf(str);
/*      */       }
/*  516 */       if ((paramString1.equals(Short.class.getName())) || (paramString1.equals("short"))) {
/*  517 */         return Short.valueOf(str);
/*      */       }
/*  519 */       if ((paramString1.equals(Long.class.getName())) || (paramString1.equals("long"))) {
/*  520 */         return Long.valueOf(str);
/*      */       }
/*  522 */       if (paramString1.equals(BigDecimal.class.getName()))
/*  523 */         return new BigDecimal(str);
/*      */     }
/*      */     catch (NumberFormatException localNumberFormatException) {
/*  526 */       throw new RIAException("EAPTECH008001", 
/*  527 */         new String[] { paramString2 });
/*      */     }
/*  529 */     return localObject;
/*      */   }
/*      */ 
/*      */   public static void handleDefaultResponseResult(DataCenter paramDataCenter, ViewContext paramViewContext)
/*      */   {
/*  540 */     if (paramViewContext.containsKey("_default_response_result")) {
/*  541 */       Object localObject = paramViewContext.get("_default_response_result");
/*  542 */       if (localObject != null)
/*  543 */         handleBoContextType(paramDataCenter, localObject);
/*      */     }
/*      */   }
/*      */ 
/*      */   public static void handleBoMethodReturn(DataCenter paramDataCenter, Object paramObject, Class paramClass)
/*      */     throws Exception
/*      */   {
/*  560 */     if (Void.TYPE.equals(paramClass))
/*      */       return;
/*      */     Object localObject1;
/*  563 */     if (paramObject == null) {
/*  564 */       paramDataCenter.addParameter("result", null);
/*  565 */       localObject1 = DataCenterFactory.getInstance().createDataStore(
/*  566 */         "result");
/*  567 */       paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       return;
/*      */     }
/*      */     Object localObject2;
/*      */     Object localObject3;
/*      */     Object localObject5;
/*  571 */     if ((paramObject instanceof Workbook))
/*      */     {
/*  573 */       ServletActionContext.getRequest().setAttribute(
/*  574 */         "eap_non_Json_Return_Type", "true");
/*  575 */       localObject1 = (Workbook)paramObject;
/*  576 */       localObject2 = ServletActionContext.getResponse();
/*  577 */       localObject3 = null;
/*      */       try {
/*  579 */         ((HttpServletResponse)localObject2).setContentType("application/msexcel;charset=UTF-8");
/*  580 */         ((HttpServletResponse)localObject2).setHeader("Content-Disposition", 
/*  581 */           "attachment;filename=export.xls");
/*  582 */         localObject3 = ((HttpServletResponse)localObject2).getOutputStream();
/*  583 */         ((Workbook)localObject1).write((OutputStream)localObject3);
/*  584 */         ((ServletOutputStream)localObject3).flush();
/*      */       }
/*      */       catch (Exception localException1) {
/*  587 */         localObject5 = localException1.getClass().getCanonicalName();
/*      */ 
/*  589 */         if (((String)localObject5)
/*  589 */           .endsWith("org.apache.catalina.connector.ClientAbortException"))
/*      */           return;
/*      */       }
/*      */       finally {
/*  593 */         ((ServletOutputStream)localObject3).close();
/*      */       }
/*      */       return;
/*      */     }
/*      */     Object localObject4;
/*      */     Object localObject7;
/*      */     Object localObject8;
/*      */     Object localObject9;
/*      */     int k;
/*  598 */     if ((paramObject instanceof File)) {
/*  599 */       localObject1 = (File)paramObject;
/*  600 */       localObject2 = ServletActionContext.getResponse();
/*  601 */       localObject3 = ServletActionContext.getRequest();
/*      */ 
/*  603 */       ((HttpServletRequest)localObject3).setAttribute("eap_non_Json_Return_Type", "true");
/*  604 */       localObject4 = ((HttpServletResponse)localObject2).getOutputStream();
/*  605 */       if (!((File)localObject1).exists())
/*      */       {
/*  607 */         localObject5 = "<script>window.parent.top.MessageBox.alert({title:\"提示信息\",message:\"文件不存在!\"});</script>";
/*  608 */         ((ServletOutputStream)localObject4).write(((String)localObject5).getBytes("UTF-8"));
/*  609 */         ((ServletOutputStream)localObject4).flush();
/*  610 */         ((ServletOutputStream)localObject4).close();
/*  611 */         return;
/*      */       }
/*  613 */       localObject5 = ((File)localObject1).getName();
/*  614 */       localObject7 = ((HttpServletRequest)localObject3).getHeader("USER-AGENT");
/*  615 */       if (localObject7 != null) {
/*  616 */         if ((((String)localObject7).indexOf("Firefox") > 0) || (((String)localObject7).indexOf("Chrome") > 0))
/*      */         {
/*  618 */           localObject5 = "=?UTF-8?B?" + 
/*  619 */             new String(Base64.encodeBase64(((String)localObject5)
/*  620 */             .getBytes("UTF-8"))) + "?=";
/*      */         }
/*      */         else {
/*  623 */           localObject5 = new String(((String)localObject5).getBytes("GBK"), "ISO-8859-1");
/*      */         }
/*      */       }
/*  626 */       localObject8 = null;
/*      */       try {
/*  628 */         ((HttpServletResponse)localObject2).setContentType("application/x-msdownload");
/*  629 */         ((HttpServletResponse)localObject2).setHeader("Content-Disposition", 
/*  630 */           "attachment;filename=" + (String)localObject5);
/*  631 */         if (((File)localObject1).length() < 2147483647L) {
/*  632 */           ((HttpServletResponse)localObject2).setContentLength((int)((File)localObject1).length());
/*      */         }
/*  634 */         localObject8 = new FileInputStream((File)localObject1);
/*  635 */         localObject9 = new byte[10240];
/*  636 */         k = -1;
/*  637 */         while ((k = ((FileInputStream)localObject8).read((byte[])localObject9)) != -1) {
/*  638 */           ((ServletOutputStream)localObject4).write((byte[])localObject9, 0, k);
/*      */         }
/*  640 */         ((ServletOutputStream)localObject4).flush();
/*      */       } catch (Exception localException2) {
/*  642 */         return;
/*      */       } finally {
/*  644 */         ((ServletOutputStream)localObject4).close();
/*  645 */         ((FileInputStream)localObject8).close();
/*      */       }
/*  647 */       return;
/*      */     }
/*      */ 
/*  650 */     if ((paramObject instanceof FileAttachment)) {
/*  651 */       localObject1 = (FileAttachment)paramObject;
/*  652 */       localObject2 = ServletActionContext.getResponse();
/*  653 */       localObject3 = ServletActionContext.getRequest();
/*      */ 
/*  655 */       ((HttpServletRequest)localObject3).setAttribute("eap_non_Json_Return_Type", "true");
/*  656 */       localObject4 = ((HttpServletResponse)localObject2).getOutputStream();
/*  657 */       localObject5 = ((FileAttachment)localObject1).getInputStream();
/*  658 */       if (localObject5 == null)
/*      */       {
/*  660 */         localObject7 = "<script>window.parent.top.MessageBox.alert({title:\"提示信息\",message:\"文件不存在!\"});</script>";
/*  661 */         ((ServletOutputStream)localObject4).write(((String)localObject7).getBytes("UTF-8"));
/*  662 */         ((ServletOutputStream)localObject4).flush();
/*  663 */         ((ServletOutputStream)localObject4).close();
/*  664 */         return;
/*      */       }
/*  666 */       localObject7 = ((FileAttachment)localObject1).getFileName();
/*  667 */       localObject8 = ((HttpServletRequest)localObject3).getHeader("USER-AGENT");
/*  668 */       if (localObject8 != null) {
/*  669 */         if ((((String)localObject8).indexOf("Firefox") > 0) || (((String)localObject8).indexOf("Chrome") > 0))
/*      */         {
/*  671 */           localObject7 = "=?UTF-8?B?" + 
/*  672 */             new String(Base64.encodeBase64(((String)localObject7)
/*  673 */             .getBytes("UTF-8"))) + "?=";
/*      */         }
/*      */         else
/*  676 */           localObject7 = new String(((String)localObject7).getBytes("GBK"), "ISO-8859-1");
/*      */       }
/*      */       try
/*      */       {
/*  680 */         if (((FileAttachment)localObject1).getContextType() != null)
/*      */         {
/*  682 */           ((HttpServletResponse)localObject2).setContentType(((FileAttachment)localObject1).getContextType());
/*  683 */           ((HttpServletResponse)localObject2).setHeader("Content-Disposition", 
/*  684 */             "inline;filename=" + (String)localObject7);
/*  685 */           localObject5 = ((FileAttachment)localObject1).getInputStream();
/*  686 */           localObject9 = new byte[10240];
/*  687 */           k = -1;
/*  688 */           while ((k = ((InputStream)localObject5).read((byte[])localObject9)) != -1) {
/*  689 */             ((ServletOutputStream)localObject4).write((byte[])localObject9, 0, k);
/*      */           }
/*  691 */           ((ServletOutputStream)localObject4).flush();
/*      */         }
/*      */         else {
/*  694 */           ((HttpServletResponse)localObject2).setContentType("application/x-msdownload");
/*  695 */           ((HttpServletResponse)localObject2).setHeader("Content-Disposition", 
/*  696 */             "attachment;filename=" + (String)localObject7);
/*  697 */           localObject5 = ((FileAttachment)localObject1).getInputStream();
/*  698 */           localObject9 = new byte[10240];
/*  699 */           k = -1;
/*  700 */           while ((k = ((InputStream)localObject5).read((byte[])localObject9)) != -1) {
/*  701 */             ((ServletOutputStream)localObject4).write((byte[])localObject9, 0, k);
/*      */           }
/*  703 */           ((ServletOutputStream)localObject4).flush();
/*      */         }
/*      */       } catch (Exception localException3) {
/*      */       } finally {
/*  707 */         ((ServletOutputStream)localObject4).close();
/*  708 */         ((InputStream)localObject5).close();
/*      */       }
/*  710 */       return;
/*      */     }
/*      */ 
/*  713 */     if ((paramObject instanceof CodeList)) {
/*  714 */       localObject1 = (CodeList)paramObject;
/*  715 */       localObject2 = DataCenterFactory.getInstance().createDataStore(
/*  716 */         ((CodeList)localObject1).getName());
/*  717 */       localObject3 = ((DataStore)localObject2).getRowSet();
/*  718 */       localObject4 = null;
/*  719 */       localObject5 = new ArrayList();
/*      */ 
/*  721 */       localObject7 = ((CodeList)localObject1).getCodeListByLocale(GlobalService.getUserI18nContext().getLocale().toString());
/*  722 */       if (localObject7 != null) {
/*  723 */         ((List)localObject5).addAll((Collection)localObject7);
/*      */       }
/*  725 */       for (int j = 0; j < ((List)localObject5).size(); j++) {
/*  726 */         localObject4 = (Code)((List)localObject5).get(j);
/*  727 */         localObject9 = new HashMap();
/*  728 */         ((Map)localObject9).put("ID", ((Code)localObject4).getCodeValue());
/*  729 */         ((Map)localObject9).put("CODENAME", ((Code)localObject4).getCodeName());
/*  730 */         ((Map)localObject9).put("CODEVALUE", ((Code)localObject4).getCodeValue());
/*  731 */         ((Map)localObject9).put("PARENTID", ((Code)localObject4).getParent());
/*  732 */         ((RowSet)localObject3).addRowData((Map)localObject9);
/*      */       }
/*  734 */       paramDataCenter.addDataStore((DataStore)localObject2);
/*  735 */       Long localLong = CacheTaskUtil.getTimeStamp(((CodeList)localObject1).getName(), 
/*  736 */         "codelist");
/*  737 */       if (localLong != null) {
/*  738 */         paramDataCenter.addParameter(((CodeList)localObject1).getName(), localLong);
/*      */       }
/*  740 */       return;
/*      */     }
/*      */ 
/*  743 */     if (isCommonType(paramObject)) {
/*  744 */       paramDataCenter.addParameter("result", paramObject);
/*  745 */     } else if ((paramObject instanceof BOContext)) {
/*  746 */       handleBoContextType(paramDataCenter, paramObject);
/*      */     } else {
/*  748 */       localObject1 = DataCenterFactory.getInstance().createDataStore(
/*  749 */         "result");
/*      */       int i;
/*  750 */       if ((paramObject instanceof QueryResult)) {
/*  751 */         localObject2 = (QueryResult)paramObject;
/*  752 */         i = 0;
/*  753 */         localObject4 = ((QueryResult)localObject2).getPageContext();
/*  754 */         if (localObject4 != null) {
/*  755 */           localObject5 = ((PageContext)localObject4).getType();
/*  756 */           if ((localObject5 != null) && (
/*  757 */             (((String)localObject5).equals("SQL")) || (((String)localObject5).equals("Statement")))) {
/*  758 */             i = 1;
/*      */           }
/*      */         }
/*  761 */         localObject5 = ((QueryResult)localObject2).getResult();
/*  762 */         if (localObject5 != null) {
/*  763 */           if (i != 0)
/*      */           {
/*  765 */             localObject1 = PojoUtil.toDataStore4SQL((List)localObject5, (DataStore)localObject1);
/*      */           }
/*  767 */           else localObject1 = PojoUtil.toDataStore((List)localObject5, (DataStore)localObject1);
/*      */         }
/*      */ 
/*  770 */         ((DataStore)localObject1).setRecordCount(((QueryResult)localObject2).getRecordCount());
/*  771 */         if (((QueryResult)localObject2).getPageNumber() != 0) {
/*  772 */           ((DataStore)localObject1).setPageNumber(((QueryResult)localObject2).getPageNumber());
/*      */         }
/*  774 */         if (((QueryResult)localObject2).getPageSize() != 0) {
/*  775 */           ((DataStore)localObject1).setPageSize(((QueryResult)localObject2).getPageSize());
/*      */         }
/*      */ 
/*  778 */         handlePageContext((DataStore)localObject1, (QueryResult)localObject2);
/*  779 */         generateQueryMetaData((DataStore)localObject1, (List)localObject5);
/*  780 */         paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       }
/*  783 */       else if ((paramObject instanceof List)) {
/*  784 */         localObject2 = (List)paramObject;
/*  785 */         handleReturnList(paramDataCenter, (List)localObject2, "result");
/*      */       }
/*  787 */       else if (paramObject.getClass().isArray())
/*      */       {
/*  789 */         localObject2 = new ArrayList();
/*  790 */         for (i = 0; i < Array.getLength(paramObject); i++) {
/*  791 */           localObject4 = Array.get(paramObject, i);
/*  792 */           ((List)localObject2).add(localObject4);
/*      */         }
/*  794 */         handleReturnList(paramDataCenter, (List)localObject2, "result");
/*  795 */       } else if ((paramObject instanceof Map))
/*      */       {
/*  797 */         localObject2 = (Map)paramObject;
/*  798 */         handleReturnMap(paramDataCenter, (Map)localObject2, "result");
/*      */       } else {
/*  800 */         localObject2 = new ArrayList();
/*  801 */         ((List)localObject2).add(paramObject);
/*  802 */         localObject1 = PojoUtil.toDataStore((List)localObject2, (DataStore)localObject1);
/*  803 */         paramDataCenter.addDataStore((DataStore)localObject1);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handleBoContextType(DataCenter paramDataCenter, Object paramObject)
/*      */   {
/*  810 */     BOContext localBOContext = (BOContext)paramObject;
/*  811 */     if (localBOContext != null) {
/*  812 */       Iterator localIterator = localBOContext.entrySet().iterator();
/*  813 */       while (localIterator.hasNext()) {
/*  814 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  815 */         Object localObject1 = localEntry.getKey();
/*  816 */         Object localObject2 = localEntry.getValue();
/*      */         DataStore localDataStore;
/*  817 */         if (localObject2 == null) {
/*  818 */           paramDataCenter.addParameter(localObject1.toString(), null);
/*  819 */           localDataStore = DataCenterFactory.getInstance()
/*  820 */             .createDataStore(localObject1.toString());
/*  821 */           paramDataCenter.addDataStore(localDataStore);
/*      */         }
/*  824 */         else if (isCommonType(localObject2)) {
/*  825 */           paramDataCenter.addParameter(localObject1.toString(), localObject2);
/*      */         } else {
/*  827 */           localDataStore = DataCenterFactory.getInstance()
/*  828 */             .createDataStore(localObject1.toString());
/*      */           Object localObject3;
/*  829 */           if ((localObject2 instanceof List)) {
/*  830 */             localObject3 = (List)localObject2;
/*  831 */             handleReturnList(paramDataCenter, (List)localObject3, localObject1.toString());
/*      */           }
/*      */           else
/*      */           {
/*      */             int i;
/*      */             Object localObject4;
/*  832 */             if (localObject2.getClass().isArray())
/*      */             {
/*  834 */               localObject3 = new ArrayList();
/*  835 */               for (i = 0; i < Array.getLength(localObject2); i++) {
/*  836 */                 localObject4 = Array.get(localObject2, i);
/*  837 */                 ((List)localObject3).add(localObject4);
/*      */               }
/*  839 */               handleReturnList(paramDataCenter, (List)localObject3, localObject1.toString());
/*  840 */             } else if ((localObject2 instanceof Map))
/*      */             {
/*  842 */               localObject3 = (Map)localObject2;
/*  843 */               handleReturnMap(paramDataCenter, (Map)localObject3, localObject1.toString());
/*  844 */             } else if ((localObject2 instanceof QueryResult)) {
/*  845 */               localObject3 = (QueryResult)localObject2;
/*  846 */               i = 0;
/*  847 */               localObject4 = ((QueryResult)localObject3).getPageContext();
/*  848 */               if (localObject4 != null) {
/*  849 */                 localObject5 = ((PageContext)localObject4).getType();
/*  850 */                 if ((localObject5 != null) && (
/*  851 */                   (((String)localObject5).equals("SQL")) || 
/*  852 */                   (((String)localObject5)
/*  852 */                   .equals("Statement")))) {
/*  853 */                   i = 1;
/*      */                 }
/*      */               }
/*  856 */               Object localObject5 = ((QueryResult)localObject3).getResult();
/*  857 */               if (localObject5 != null) {
/*  858 */                 if (i != 0)
/*      */                 {
/*  860 */                   localDataStore = PojoUtil.toDataStore4SQL((List)localObject5, localDataStore);
/*      */                 }
/*  862 */                 else localDataStore = PojoUtil.toDataStore((List)localObject5, localDataStore);
/*      */               }
/*      */ 
/*  865 */               localDataStore.setRecordCount(((QueryResult)localObject3).getRecordCount());
/*  866 */               if (((QueryResult)localObject3).getPageNumber() != 0) {
/*  867 */                 localDataStore.setPageNumber(((QueryResult)localObject3).getPageNumber());
/*      */               }
/*  869 */               if (((QueryResult)localObject3).getPageSize() != 0) {
/*  870 */                 localDataStore.setPageSize(((QueryResult)localObject3).getPageSize());
/*      */               }
/*      */ 
/*  873 */               handlePageContext(localDataStore, (QueryResult)localObject3);
/*  874 */               generateQueryMetaData(localDataStore, (List)localObject5);
/*  875 */               paramDataCenter.addDataStore(localDataStore);
/*      */             } else {
/*  877 */               localObject3 = new ArrayList();
/*  878 */               if (localObject2 != null) {
/*  879 */                 ((List)localObject3).add(localObject2);
/*      */               }
/*  881 */               localDataStore = PojoUtil.toDataStore((List)localObject3, localDataStore);
/*  882 */               paramDataCenter.addDataStore(localDataStore);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void generateQueryMetaData(DataStore paramDataStore, List paramList)
/*      */   {
/*  896 */     if (paramList != null) {
/*  897 */       List localList = 
/*  898 */         MetaDataUtil.getMetaDataInfo(paramList);
/*  899 */       if (localList != null) {
/*  900 */         Object localObject = paramDataStore.getMetaData();
/*  901 */         if (localObject == null) {
/*  902 */           localObject = new MetaDataImpl();
/*      */         }
/*  904 */         for (Column localColumn : localList) {
/*  905 */           ((MetaData)localObject).addColumn(localColumn);
/*      */         }
/*  907 */         paramDataStore.setMetaData((MetaData)localObject);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handleReturnList(DataCenter paramDataCenter, List paramList, String paramString)
/*      */   {
/*  922 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore(paramString);
/*  923 */     if (paramList.size() > 0) {
/*  924 */       Object localObject = paramList.get(0);
/*  925 */       if (isCommonType(localObject)) {
/*  926 */         JSONArray localJSONArray = JSONArray.fromObject(paramList);
/*  927 */         paramDataCenter.addParameter(paramString, localJSONArray);
/*      */       } else {
/*  929 */         localDataStore = PojoUtil.toDataStore(paramList, localDataStore);
/*  930 */         paramDataCenter.addDataStore(localDataStore);
/*      */       }
/*      */     } else {
/*  933 */       paramDataCenter.addParameter(paramString, "");
/*  934 */       localDataStore = PojoUtil.toDataStore(paramList, localDataStore);
/*  935 */       paramDataCenter.addDataStore(localDataStore);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handleReturnMap(DataCenter paramDataCenter, Map paramMap, String paramString)
/*      */   {
/*  949 */     DataStore localDataStore = DataCenterFactory.getInstance().createDataStore(paramString);
/*  950 */     if (paramMap.size() > 0) {
/*  951 */       localDataStore = PojoUtil.toDataStore(paramMap, localDataStore);
/*  952 */       paramDataCenter.addDataStore(localDataStore);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static void handlePageContext(DataStore paramDataStore, QueryResult paramQueryResult)
/*      */   {
/*  963 */     PageContext localPageContext = paramQueryResult.getPageContext();
/*  964 */     if (localPageContext != null) {
/*  965 */       String str = UniEAPContextHolder.getContext()
/*  966 */         .getCurrentUser().getAccount();
/*  967 */       paramDataStore.addParameter("_pageKey", localPageContext.getKey());
/*  968 */       Object localObject1 = ((EAPCacheManager)BeanUtil.getBean("eapCacheManager"))
/*  969 */         .getCache("pageContext").getObject(str);
/*  970 */       Object localObject2 = new HashMap();
/*  971 */       if (localObject1 != null) {
/*  972 */         localObject2 = (Map)localObject1;
/*      */       }
/*  974 */       ((Map)localObject2).put(localPageContext.getKey(), localPageContext);
/*  975 */       ((EAPCacheManager)BeanUtil.getBean("eapCacheManager")).getCache(
/*  976 */         "pageContext").putObject(str, localObject2);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static Method getBOMethod(Object paramObject, String paramString, String[] paramArrayOfString)
/*      */     throws Exception
/*      */   {
/*  994 */     Method[] arrayOfMethod = paramObject.getClass().getMethods();
/*  995 */     ArrayList localArrayList = new ArrayList();
/*  996 */     for (int i = 0; i < arrayOfMethod.length; i++) {
/*  997 */       if (paramString.equals(arrayOfMethod[i].getName())) {
/*  998 */         localArrayList.add(arrayOfMethod[i]);
/*      */       }
/*      */     }
/* 1001 */     Object localObject = null;
/* 1002 */     for (int j = 0; j < localArrayList.size(); j++) {
/* 1003 */       Method localMethod = (Method)localArrayList.get(j);
/* 1004 */       Class[] arrayOfClass = localMethod.getParameterTypes();
/* 1005 */       if ((paramArrayOfString != null) || (arrayOfClass.length == 0))
/*      */       {
/* 1008 */         if ((paramArrayOfString == null) && (arrayOfClass.length == 0)) {
/* 1009 */           localObject = localMethod;
/* 1010 */           break;
/* 1011 */         }if ((paramArrayOfString != null) && 
/* 1012 */           (arrayOfClass.length == paramArrayOfString.length) && 
/* 1013 */           (compareParametersType(paramArrayOfString, arrayOfClass))) {
/* 1014 */           localObject = localMethod;
/* 1015 */           break;
/*      */         }
/*      */       }
/*      */     }
/* 1019 */     return localObject;
/*      */   }
/*      */ 
/*      */   private static List initParameters(ViewContext paramViewContext, String paramString, Class[] paramArrayOfClass)
/*      */     throws Exception
/*      */   {
/* 1034 */     ArrayList localArrayList = new ArrayList();
/* 1035 */     String str1 = paramViewContext.getString("_parameterTypes");
/*      */ 
/* 1037 */     List localList1 = getProcessorParameterInfo(paramString);
/*      */     Object localObject1;
/*      */     String str3;
/* 1038 */     if ((str1 != null) && (!str1.equals("")))
/*      */     {
/* 1040 */       List localList2 = getProcessorParameterInfo(str1);
/* 1041 */       for (int j = 0; j < localList1.size(); j++) {
/* 1042 */         localObject1 = (String)localList1.get(j);
/* 1043 */         str3 = (String)localList2.get(j);
/* 1044 */         if ("pojoList".equals(str3)) {
/* 1045 */           localArrayList.add(paramViewContext.getPojoListWithContext((String)localObject1));
/*      */         }
/*      */         else
/*      */         {
/*      */           Object localObject2;
/* 1046 */           if ("pojo".equals(str3))
/*      */           {
/* 1048 */             if ("java.util.Map".equals(paramArrayOfClass[j].getName()))
/* 1049 */               localObject2 = paramViewContext.getPojoMap((String)localObject1);
/*      */             else {
/* 1051 */               localObject2 = paramViewContext.getPojoWithContext((String)localObject1);
/*      */             }
/* 1053 */             localArrayList.add(localObject2);
/* 1054 */           } else if ("string".equals(str3)) {
/* 1055 */             if ("com.neusoft.unieap.core.common.form.Form".equals(paramArrayOfClass[j]
/* 1056 */               .getName())) {
/* 1057 */               localArrayList.add(initFormParameters(paramViewContext));
/*      */             }
/* 1060 */             else if ("com.neusoft.unieap.techcomp.ria.ds.DataCenter"
/* 1060 */               .equals(paramArrayOfClass[j].getName()))
/* 1061 */               localArrayList.add(initDataCenterParameters(paramViewContext
/* 1062 */                 .getString((String)localObject1)));
/*      */             else
/* 1064 */               localArrayList.add(getParam(paramArrayOfClass[j]
/* 1065 */                 .getName(), (String)localObject1, paramViewContext));
/*      */           }
/* 1067 */           else if (str3.startsWith("map")) {
/* 1068 */             localObject2 = str3.substring(4, str3
/* 1069 */               .length() - 1);
/* 1070 */             String[] arrayOfString1 = ((String)localObject2).split(",");
/* 1071 */             String[] arrayOfString2 = ((String)localObject1).split("[(]");
/* 1072 */             if (arrayOfString2.length > 0) {
/* 1073 */               String str4 = arrayOfString2[0];
/* 1074 */               String[] arrayOfString3 = arrayOfString2[1].substring(0, 
/* 1075 */                 arrayOfString2[1].length() - 1).split(",");
/* 1076 */               localArrayList.add(initMapParameter(paramViewContext, str4, 
/* 1077 */                 arrayOfString1, arrayOfString3));
/*      */             } else {
/* 1079 */               localArrayList.add(null);
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     } else { for (int i = 0; i < localList1.size(); i++) {
/* 1085 */         String str2 = (String)localList1.get(i);
/* 1086 */         localObject1 = paramViewContext.get(str2);
/* 1087 */         if ((localObject1 instanceof DataStore)) {
/* 1088 */           str3 = ((DataStore)localObject1).getStoreName();
/*      */ 
/* 1090 */           if (((DataStore)localObject1).getRowSet().getRowCount(
/* 1090 */             "primary") > 1)
/* 1091 */             localArrayList.add(paramViewContext.getPOJOList(str3));
/*      */           else
/* 1093 */             localArrayList.add(paramViewContext.getPOJO(str3));
/*      */         }
/*      */         else
/*      */         {
/* 1097 */           localArrayList.add(localObject1);
/*      */         }
/*      */       }
/*      */     }
/* 1101 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   private static Map initMapParameter(ViewContext paramViewContext, String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
/*      */     throws Exception
/*      */   {
/* 1116 */     String str = paramViewContext.getString(paramString);
/* 1117 */     if (str == null) {
/* 1118 */       return null;
/*      */     }
/* 1120 */     JSONObject localJSONObject = JSONObject.fromObject(str);
/* 1121 */     if ((localJSONObject == null) || (localJSONObject.isNullObject())) {
/* 1122 */       return null;
/*      */     }
/* 1124 */     HashMap localHashMap = new HashMap();
/* 1125 */     for (int i = 0; i < paramArrayOfString2.length; i++) {
/* 1126 */       Object localObject1 = localJSONObject.get(paramArrayOfString2[i]);
/* 1127 */       Object localObject2 = getMapParameterObject(paramArrayOfString1[i], 
/* 1128 */         localObject1);
/* 1129 */       localHashMap.put(paramArrayOfString2[i], localObject2);
/*      */     }
/* 1131 */     return localHashMap;
/*      */   }
/*      */ 
/*      */   private static Object getMapParameterObject(String paramString, Object paramObject)
/*      */     throws Exception
/*      */   {
/* 1144 */     if ((paramString == null) || (paramObject == null)) {
/* 1145 */       return null;
/*      */     }
/* 1147 */     if ("pojoList".equals(paramString)) {
/* 1148 */       return getPojoListWithContext(paramObject);
/*      */     }
/* 1150 */     if ("pojo".equals(paramString)) {
/* 1151 */       Object localObject = getPojoWithContext(paramObject);
/* 1152 */       if (localObject == null) {
/* 1153 */         return null;
/*      */       }
/* 1155 */       return localObject;
/*      */     }
/*      */ 
/* 1158 */     if ("string".equals(paramString)) {
/* 1159 */       if (((paramObject instanceof JSONObject)) && 
/* 1160 */         (((JSONObject)paramObject).isNullObject())) {
/* 1161 */         return null;
/*      */       }
/* 1163 */       return String.valueOf(paramObject);
/*      */     }
/*      */ 
/* 1166 */     return null;
/*      */   }
/*      */ 
/*      */   private static List getPojoListWithContext(Object paramObject) throws Exception
/*      */   {
/* 1171 */     JSONObject localJSONObject = null;
/* 1172 */     if (!(paramObject instanceof JSONObject))
/* 1173 */       localJSONObject = JSONObject.fromObject(paramObject);
/*      */     else {
/* 1175 */       localJSONObject = (JSONObject)paramObject;
/*      */     }
/* 1177 */     DataStoreImpl localDataStoreImpl = new DataStoreImpl("", localJSONObject);
/* 1178 */     List localList = ContextUtil.getPojoListWithContext(localDataStoreImpl);
/* 1179 */     return localList;
/*      */   }
/*      */ 
/*      */   private static Object getPojoWithContext(Object paramObject) throws Exception
/*      */   {
/* 1184 */     JSONObject localJSONObject = null;
/* 1185 */     if (!(paramObject instanceof JSONObject))
/* 1186 */       localJSONObject = JSONObject.fromObject(paramObject);
/*      */     else {
/* 1188 */       localJSONObject = (JSONObject)paramObject;
/*      */     }
/* 1190 */     DataStoreImpl localDataStoreImpl = new DataStoreImpl("", localJSONObject);
/* 1191 */     Object localObject = ContextUtil.getPojoWithContext(localDataStoreImpl);
/* 1192 */     return localObject;
/*      */   }
/*      */ 
/*      */   private static List getProcessorParameterInfo(String paramString)
/*      */   {
/* 1202 */     String[] arrayOfString = paramString.split(",");
/* 1203 */     ArrayList localArrayList = new ArrayList();
/* 1204 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 1205 */       String str = arrayOfString[i];
/* 1206 */       if (str.indexOf("(") != -1) {
/* 1207 */         for (int j = i + 1; 
/* 1208 */           j < arrayOfString.length; j++) {
/* 1209 */           str = str.concat(",").concat(arrayOfString[j]);
/* 1210 */           if (arrayOfString[j].indexOf(")") != -1) {
/*      */             break;
/*      */           }
/*      */         }
/* 1214 */         i = j;
/*      */       }
/* 1216 */       localArrayList.add(str);
/*      */     }
/* 1218 */     return localArrayList;
/*      */   }
/*      */ 
/*      */   private static boolean compareParametersType(String[] paramArrayOfString, Class[] paramArrayOfClass)
/*      */   {
/* 1232 */     for (int i = 0; 
/* 1233 */       i < paramArrayOfClass.length; i++) {
/* 1234 */       if (paramArrayOfString[i] == null) {
/* 1235 */         return false;
/*      */       }
/*      */ 
/* 1247 */       String str = paramArrayOfString[i].trim();
/* 1248 */       if ((!paramArrayOfClass[i].getName().equals(str)) && 
/* 1251 */         ((!str.equals("Integer")) || 
/* 1252 */         (!paramArrayOfClass[i].equals(Integer.class))) && 
/* 1255 */         ((!str.equals("Float")) || 
/* 1256 */         (!paramArrayOfClass[i].equals(Float.class))) && 
/* 1259 */         ((!str.equals("Double")) || 
/* 1260 */         (!paramArrayOfClass[i].equals(Double.class))) && 
/* 1263 */         ((!str.equals("Boolean")) || 
/* 1264 */         (!paramArrayOfClass[i].equals(Boolean.class))) && 
/* 1267 */         ((!str.equals("Byte")) || 
/* 1268 */         (!paramArrayOfClass[i].equals(Byte.class))) && 
/* 1271 */         ((!str.equals("Character")) || 
/* 1272 */         (!paramArrayOfClass[i].equals(Character.class))) && 
/* 1275 */         ((!str.equals("Long")) || 
/* 1276 */         (!paramArrayOfClass[i].equals(Long.class))) && 
/* 1279 */         ((!str.equals("Short")) || 
/* 1280 */         (!paramArrayOfClass[i].equals(Short.class))) && 
/* 1283 */         ((!str.equals("String")) || 
/* 1284 */         (!paramArrayOfClass[i].equals(String.class))) && (
/* 1287 */         (!str.equals("Object")) || 
/* 1288 */         (!paramArrayOfClass[i].equals(Object.class))))
/*      */       {
/*      */         break;
/*      */       }
/*      */     }
/*      */ 
/* 1294 */     if (i == paramArrayOfClass.length) {
/* 1295 */       return true;
/*      */     }
/* 1297 */     return false;
/*      */   }
/*      */ 
/*      */   public static void invokeStatement(ViewContext paramViewContext, DataCenter paramDataCenter)
/*      */     throws Exception
/*      */   {
/* 1311 */     String[] arrayOfString1 = paramViewContext.getString("_statement")
/* 1312 */       .split(",");
/* 1313 */     String[] arrayOfString2 = paramViewContext.getString("_statementRef")
/* 1314 */       .split(",");
/* 1315 */     String[] arrayOfString3 = paramViewContext.getString("_dcId").split(",");
/* 1316 */     String[] arrayOfString4 = (String[])null;
/* 1317 */     String[] arrayOfString5 = (String[])null;
/* 1318 */     if (paramViewContext.getString("_statementPageNumber") != null) {
/* 1319 */       arrayOfString4 = paramViewContext.getString("_statementPageNumber")
/* 1320 */         .split(",");
/*      */     }
/* 1322 */     if (paramViewContext.getString("_statementPageSize") != null) {
/* 1323 */       arrayOfString5 = paramViewContext.getString("_statementPageSize").split(
/* 1324 */         ",");
/*      */     }
/*      */ 
/* 1328 */     CommonBO localCommonBO = (CommonBO)BeanUtil.getBean("core_commonBO_bo");
/*      */ 
/* 1331 */     List localList = paramViewContext.getPOJOList("_advancedQueryConditionStore");
/* 1332 */     if (localList != null) {
/* 1333 */       localObject1 = new QueryCondition();
/* 1334 */       ((QueryCondition)localObject1).setConditions(localList);
/* 1335 */       UnieapRequestContextHolder.getRequestContext().put(
/* 1336 */         "advanceQueryCondition", localObject1);
/*      */     }
/*      */ 
/* 1340 */     if ((paramViewContext.getString("_pageNumber") != null) && 
/* 1341 */       (paramViewContext.getString("_pageSize") != null)) {
/* 1342 */       localObject1 = new QueryResult();
/* 1343 */       ((QueryResult)localObject1).setPageNumber(Integer.valueOf(paramViewContext
/* 1344 */         .getString("_pageNumber")).intValue());
/*      */ 
/* 1345 */       ((QueryResult)localObject1).setPageSize(Integer.valueOf(paramViewContext
/* 1346 */         .getString("_pageSize")).intValue());
/*      */ 
/* 1347 */       if (paramViewContext.getString("_calcRecordCount") != null) {
/* 1348 */         ((QueryResult)localObject1).setAutoCalcCount(Boolean.valueOf(paramViewContext
/* 1349 */           .getString("_calcRecordCount")).booleanValue());
/*      */       }
/*      */ 
/* 1351 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/* 1352 */         localObject1);
/*      */     } else {
/* 1354 */       localObject1 = new QueryResult();
/* 1355 */       ((QueryResult)localObject1).setAutoCalcCount(true);
/* 1356 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/* 1357 */         localObject1);
/*      */     }
/* 1359 */     Object localObject1 = new BOContextImpl();
/*      */ 
/* 1361 */     String str1 = paramViewContext.getString("_parameterTypes");
/*      */ 
/* 1363 */     for (int i = 0; i < arrayOfString1.length; i++) {
/* 1364 */       String str2 = "";
/* 1365 */       DevelopmentComponent localDevelopmentComponent = 
/* 1366 */         DCRepository.getDevelopmentComponent(arrayOfString3[i]);
/* 1367 */       if (localDevelopmentComponent == null)
/*      */       {
/* 1369 */         str2 = arrayOfString3[i] + File.separator + "statement" + 
/* 1370 */           File.separator + arrayOfString2[i] + ".xml";
/*      */       }
/*      */       else {
/* 1373 */         str2 = localDevelopmentComponent.getSoftwareComponent().getId() + 
/* 1374 */           File.separator + arrayOfString3[i] + File.separator + 
/* 1375 */           "statement" + File.separator + arrayOfString2[i] + 
/* 1376 */           ".xml";
/*      */       }
/* 1378 */       if (arrayOfString2[i].contains("/")) {
/* 1379 */         arrayOfString2[i] = arrayOfString2[i].replace("/", ".");
/*      */       }
/* 1381 */       String str3 = arrayOfString3[i] + "." + arrayOfString2[i];
/* 1382 */       StatementImpl localStatementImpl = new StatementImpl(str2);
/* 1383 */       String str4 = localStatementImpl.getDataSourceID();
/* 1384 */       if ((str4 != null) && (!"".equals(str4))) {
/* 1385 */         DataSourceContextHolder.setDataSourceType(str4);
/*      */       }
/*      */ 
/* 1388 */       HashMap localHashMap = new HashMap();
/*      */       Object localObject3;
/* 1389 */       if ((str1 != null) && (str1.contains("map"))) {
/* 1390 */         localObject2 = paramViewContext.getString(arrayOfString1[i]);
/* 1391 */         if (localObject2 == null) {
/* 1392 */           localHashMap = null;
/*      */         } else {
/* 1394 */           localObject3 = 
/* 1395 */             JSONObject.fromObject(localObject2);
/* 1396 */           if ((localObject3 == null) || (((JSONObject)localObject3).isNullObject())) {
/* 1397 */             localHashMap = null;
/*      */           } else {
/* 1399 */             Iterator localIterator = ((JSONObject)localObject3).keys();
/* 1400 */             while (localIterator.hasNext()) {
/* 1401 */               String str5 = localIterator.next().toString();
/* 1402 */               Object localObject4 = ((JSONObject)localObject3).get(str5);
/* 1403 */               if ((!(localObject4 instanceof JSONObject)) || 
/* 1404 */                 (!((JSONObject)localObject4).isNullObject()))
/*      */               {
/* 1407 */                 localHashMap.put(str5, localObject4);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       } else { localObject2 = paramViewContext.getString("_parameters");
/* 1413 */         if (localObject2 != null) {
/* 1414 */           localObject3 = ((String)localObject2).split(",");
/* 1415 */           for (int j = 0; j < localObject3.length; j++) {
/* 1416 */             localHashMap.put(localObject3[j], paramViewContext.getString(localObject3[j]));
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1421 */       if ((arrayOfString4 != null) && (arrayOfString5 != null) && (
/* 1422 */         (arrayOfString4.length != 0) || (arrayOfString5.length != 0)))
/*      */       {
/* 1424 */         if ((arrayOfString4[i].length() == 0) || (arrayOfString4[i].equals("''"))) {
/* 1425 */           if (paramViewContext.getString("_pageNumber") != null) {
/* 1426 */             PageUtil.setPageNumber(Integer.valueOf(paramViewContext
/* 1427 */               .getString("_pageNumber")).intValue());
/*      */           }
/*      */           else
/* 1429 */             PageUtil.setPageNumber(1);
/*      */         }
/*      */         else {
/* 1432 */           PageUtil.setPageNumber(Integer.valueOf(arrayOfString4[i]).intValue());
/*      */         }
/*      */ 
/* 1435 */         if ((arrayOfString4[i].length() == 0) || (arrayOfString5[i].equals("''"))) {
/* 1436 */           if (paramViewContext.getString("_pageSize") != null) {
/* 1437 */             PageUtil.setPageSize(Integer.valueOf(paramViewContext
/* 1438 */               .getString("_pageSize")).intValue());
/*      */           }
/*      */           else
/* 1440 */             PageUtil.setPageSize(-1);
/*      */         }
/*      */         else {
/* 1443 */           PageUtil.setPageSize(Integer.valueOf(arrayOfString5[i]).intValue());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1448 */       Object localObject2 = localCommonBO.findByStatement(str3, localHashMap);
/* 1449 */       if (arrayOfString1.length == 1)
/* 1450 */         ((BOContext)localObject1).put("result", localObject2);
/*      */       else {
/* 1452 */         ((BOContext)localObject1).put(arrayOfString1[i], localObject2);
/*      */       }
/*      */     }
/*      */ 
/* 1456 */     Class localClass = localObject1.getClass();
/* 1457 */     handleBoMethodReturn(paramDataCenter, localObject1, localClass);
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.util.CommonUtil
 * JD-Core Version:    0.6.2
 */