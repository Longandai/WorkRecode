package com.neusoft.unieap.techcomp.ria.common.query.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import java.util.List;
import java.util.Map;

public abstract interface AutoQueryDAO
{
  public abstract QueryResult autoQueryByPage(Map paramMap);

  public abstract QueryResult autoQueryByPage(Map paramMap, int paramInt1, int paramInt2);

  public abstract List autoQuery(Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dao.AutoQueryDAO
 * JD-Core Version:    0.6.2
 */