/*     */ package com.neusoft.unieap.techcomp.ria.common.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.protection.Protection;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.io.CommonWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class CommonProcessor extends BaseProcessor
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ApplicationContext applicationContext;
/*     */   private SessionFactory sessionFactory;
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext)
/*     */     throws BeansException
/*     */   {
/*  36 */     this.applicationContext = paramApplicationContext;
/*     */   }
/*     */ 
/*     */   public void commonMethod()
/*     */     throws Exception
/*     */   {
/*  46 */     ViewContext localViewContext = generateContext();
/*  47 */     DataCenter localDataCenter = DataCenterFactory.getInstance()
/*  48 */       .createDataCenter();
/*     */ 
/*  54 */     String str1 = Protection.check(getRequest(), getResponse());
/*  55 */     if ((str1 != null) && (!"".equals(str1))) {
/*  56 */       localDataCenter.setCode(-1L);
/*  57 */       localDataCenter.setTitle(str1);
/*  58 */       localDataCenter.setDetail(str1);
/*  59 */       write(localDataCenter);
/*  60 */       return;
/*     */     }
/*     */ 
/*  63 */     UnieapRequestContextHolder.getRequestContext().put("viewContext", 
/*  64 */       localViewContext);
/*     */ 
/*  66 */     String str2 = localViewContext.getString("_namedQuery");
/*  67 */     if (str2 != null) {
/*  68 */       CommonUtil.invokeNamedQuery(localViewContext, localDataCenter, this.sessionFactory);
/*  69 */       write(localDataCenter);
/*  70 */       return;
/*     */     }
/*     */ 
/*  73 */     String str3 = localViewContext.getString("_statement");
/*  74 */     if (str3 != null) {
/*  75 */       CommonUtil.invokeStatement(localViewContext, localDataCenter);
/*  76 */       write(localDataCenter);
/*  77 */       return;
/*     */     }
/*  79 */     String str4 = localViewContext.getString("_boId");
/*  80 */     if (str4 == null) {
/*  81 */       throw new RIAException("EAPTECH008011", null);
/*     */     }
/*     */ 
/*  85 */     if (localViewContext.containsKey("_methodId")) {
/*  86 */       UnieapRequestContextHolder.getRequestContext().put("_methodId", 
/*  87 */         Boolean.valueOf(true));
/*  88 */       UnieapRequestContextHolder.getRequestContext().put("_boId", str4);
/*     */     }
/*     */ 
/*  92 */     if (localViewContext.containsKey("unieapMenuId")) {
/*  93 */       UnieapRequestContextHolder.getRequestContext().put("_unieapMenuId", 
/*  94 */         localViewContext.getString("unieapMenuId"));
/*  95 */       UnieapRequestContextHolder.getRequestContext().put(
/*  96 */         "_unieapMenuName", localViewContext.getString("unieapMenuName"));
/*     */     }
/*     */ 
/* 101 */     Object localObject = this.applicationContext.getBean(str4);
/* 102 */     if (localObject == null) {
/* 103 */       throw new RIAException("EAPTECH008012", new Object[] { str4 });
/*     */     }
/* 105 */     CommonUtil.invokeBoMethod(localViewContext, localDataCenter, localObject);
/*     */ 
/* 108 */     if (UnieapRequestContextHolder.getRequestContext().containsKey(
/* 109 */       "_testMethodId")) {
/* 110 */       localDataCenter.addParameter("_methodId", 
/* 111 */         UnieapRequestContextHolder.getRequestContext().get("_testMethodId"));
/* 112 */       localDataCenter.addParameter("_sessionVarString", 
/* 113 */         UnieapRequestContextHolder.getRequestContext().get(
/* 114 */         "_sessionVarString"));
/* 115 */       localDataCenter.addParameter("_requestVarString", 
/* 116 */         UnieapRequestContextHolder.getRequestContext().get(
/* 117 */         "_requestVarString"));
/*     */     }
/* 119 */     if (!"true".equals(getRequest().getAttribute(
/* 120 */       "eap_non_Json_Return_Type")))
/* 121 */       write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void login()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setSessionFactory(SessionFactory paramSessionFactory)
/*     */   {
/* 131 */     this.sessionFactory = paramSessionFactory;
/*     */   }
/*     */ 
/*     */   public SessionFactory getSessionFactory() {
/* 135 */     return this.sessionFactory;
/*     */   }
/*     */ 
/*     */   protected void write(DataCenter paramDataCenter)
/*     */     throws Exception
/*     */   {
/* 141 */     ByteArrayOutputStream localByteArrayOutputStream = null;
/* 142 */     String str = "";
/*     */     try {
/* 144 */       localByteArrayOutputStream = new ByteArrayOutputStream();
/* 145 */       localObject1 = 
/* 146 */         DataCenterIOManager.createWriter(localByteArrayOutputStream);
/* 147 */       ((DataCenterWriter)localObject1).write(paramDataCenter);
/* 148 */       ((DataCenterWriter)localObject1).close();
/* 149 */       str = IOUtils.toString(localByteArrayOutputStream.toByteArray(), 
/* 150 */         "UTF-8");
/*     */     } catch (Exception localException1) {
/*     */     } finally {
/* 153 */       localByteArrayOutputStream.close();
/*     */     }
/*     */ 
/* 156 */     Object localObject1 = 
/* 157 */       (ViewContext)UnieapRequestContextHolder.getRequestContext().get("viewContext");
/* 158 */     if (((ViewContext)localObject1).getString("_methodParameterTypes").contains(
/* 159 */       "com.neusoft.unieap.core.common.form.Form"))
/* 160 */       str = "<textarea>" + str + "</textarea>";
/*     */     try
/*     */     {
/* 163 */       Object localObject3 = BeanUtil.getBean("commonWriter");
/* 164 */       ((CommonWriter)localObject3).parseStream(getResponse().getWriter(), 
/* 165 */         getRequest(), str);
/*     */     } catch (Exception localException2) {
/* 167 */       getResponse().getWriter().write(str);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.action.CommonProcessor
 * JD-Core Version:    0.6.2
 */