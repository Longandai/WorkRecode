/*    */ package com.neusoft.unieap.techcomp.ria.common.query.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.bo.AutoQueryBO;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.dao.AutoQueryDAO;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ @ModelFile("autoQueryBO.bo")
/*    */ public class AutoQueryBOImpl
/*    */   implements AutoQueryBO
/*    */ {
/*    */   private AutoQueryDAO autoQueryDAO;
/*    */ 
/*    */   public QueryResult autoQueryByPage(Map paramMap)
/*    */   {
/* 33 */     return this.autoQueryDAO.autoQueryByPage(paramMap);
/*    */   }
/*    */ 
/*    */   public QueryResult autoQueryByPage(Map paramMap, int paramInt1, int paramInt2)
/*    */   {
/* 40 */     return this.autoQueryDAO.autoQueryByPage(paramMap, paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   public QueryResult autoQuery(Map paramMap)
/*    */   {
/* 46 */     QueryResult localQueryResult = new QueryResult();
/* 47 */     List localList = this.autoQueryDAO.autoQuery(paramMap);
/* 48 */     localQueryResult.setResult(localList);
/* 49 */     localQueryResult.setRecordCount(localList.size());
/* 50 */     return localQueryResult;
/*    */   }
/*    */ 
/*    */   public void setAutoQueryDAO(AutoQueryDAO paramAutoQueryDAO) {
/* 54 */     this.autoQueryDAO = paramAutoQueryDAO;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.impl.AutoQueryBOImpl
 * JD-Core Version:    0.6.2
 */