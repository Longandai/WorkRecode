/*    */ package com.neusoft.unieap.techcomp.ria.common.rest.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.common.rest.RestResultHandler;
/*    */ import com.neusoft.unieap.techcomp.ria.common.util.RestUtil;
/*    */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*    */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*    */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*    */ import java.io.BufferedWriter;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStreamWriter;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class EAPResultHandler
/*    */   implements RestResultHandler
/*    */ {
/*    */   public Object handleReuslt(ViewContext paramViewContext, Object paramObject, HttpServletResponse paramHttpServletResponse)
/*    */     throws IOException
/*    */   {
/* 29 */     if (paramObject != null)
/*    */     {
/* 31 */       String str = paramViewContext.getString("returnType");
/*    */ 
/* 33 */       if ((str == null) || (str.equals("json")))
/*    */       {
/* 35 */         return paramObject;
/*    */       }
/*    */       Object localObject1;
/* 38 */       if ((str.equals("string")) || (str.equals("String")))
/*    */       {
/* 40 */         localObject1 = new BufferedWriter(new OutputStreamWriter(paramHttpServletResponse.getOutputStream(), "UTF-8"));
/*    */         try
/*    */         {
/* 43 */           ((Writer)localObject1).write(paramObject.toString());
/*    */         }
/*    */         catch (UnsupportedEncodingException localUnsupportedEncodingException)
/*    */         {
/* 47 */           localUnsupportedEncodingException.printStackTrace();
/*    */         }
/*    */         finally {
/* 50 */           ((Writer)localObject1).close();
/*    */         }
/* 52 */         return null;
/*    */       }
/*    */ 
/* 55 */       if (str.equals("dataCenter"))
/*    */       {
/* 57 */         localObject1 = DataCenterFactory.getInstance().createDataCenter();
/*    */         try
/*    */         {
/* 60 */           RestUtil.handleBoMethodReturn((DataCenter)localObject1, paramObject, (Class)paramViewContext.get("boMethodType"), paramHttpServletResponse);
/*    */         }
/*    */         catch (Exception localException) {
/* 63 */           localException.printStackTrace();
/* 64 */           return null;
/*    */         }
/* 66 */         DataCenterWriter localDataCenterWriter = DataCenterIOManager.createWriter(paramHttpServletResponse.getOutputStream());
/* 67 */         localDataCenterWriter.write((DataCenter)localObject1);
/* 68 */         localDataCenterWriter.close();
/* 69 */         return null;
/*    */       }
/*    */     }
/* 72 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.rest.impl.EAPResultHandler
 * JD-Core Version:    0.6.2
 */