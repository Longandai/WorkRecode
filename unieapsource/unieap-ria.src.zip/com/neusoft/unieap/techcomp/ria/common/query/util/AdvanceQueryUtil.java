/*     */ package com.neusoft.unieap.techcomp.ria.common.query.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.dto.Condition;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class AdvanceQueryUtil
/*     */ {
/*  23 */   public static Properties props = new Properties();
/*     */ 
/*     */   static {
/*  26 */     props.setProperty("M", "LIKE");
/*  27 */     props.setProperty("LM", "LIKE");
/*  28 */     props.setProperty("RM", "LIKE");
/*  29 */     props.setProperty("NM", "NOT LIKE");
/*  30 */     props.setProperty("NLM", "NOT LIKE");
/*  31 */     props.setProperty("NRM", "NOT LIKE");
/*     */ 
/*  33 */     props.setProperty("E", "=");
/*  34 */     props.setProperty("NE", "!=");
/*  35 */     props.setProperty("G", ">");
/*  36 */     props.setProperty("S", "<");
/*  37 */     props.setProperty("GE", ">=");
/*  38 */     props.setProperty("SE", "<=");
/*     */   }
/*     */ 
/*     */   public static String getHQLCondition()
/*     */   {
/*  48 */     List localList = getCondition();
/*  49 */     if ((localList == null) || (localList.size() == 0)) {
/*  50 */       return "1=1";
/*     */     }
/*  52 */     Condition localCondition = null;
/*  53 */     StringBuffer localStringBuffer = new StringBuffer();
/*  54 */     for (int i = 0; i < localList.size(); i++) {
/*  55 */       if (i > 0) {
/*  56 */         localStringBuffer.append(" AND ");
/*     */       }
/*  58 */       localCondition = (Condition)localList.get(i);
/*  59 */       localStringBuffer.append(localCondition.getColumn());
/*  60 */       localStringBuffer.append(" ");
/*  61 */       localStringBuffer.append(getOption(localCondition.getOperation()));
/*  62 */       localStringBuffer.append(" ? ");
/*     */     }
/*  64 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getHQLCondition(String paramString)
/*     */   {
/*  73 */     if ((paramString == null) || (paramString.trim().equals(""))) {
/*  74 */       return getHQLCondition();
/*     */     }
/*  76 */     List localList = getCondition();
/*  77 */     if ((localList == null) || (localList.size() == 0)) {
/*  78 */       return "1=1";
/*     */     }
/*  80 */     Condition localCondition = null;
/*  81 */     StringBuffer localStringBuffer = new StringBuffer();
/*  82 */     for (int i = 0; i < localList.size(); i++) {
/*  83 */       if (i > 0) {
/*  84 */         localStringBuffer.append(" AND ");
/*     */       }
/*  86 */       localCondition = (Condition)localList.get(i);
/*  87 */       localStringBuffer.append(paramString + "." + localCondition.getColumn());
/*  88 */       localStringBuffer.append(" ");
/*  89 */       localStringBuffer.append(getOption(localCondition.getOperation()));
/*  90 */       localStringBuffer.append(" ? ");
/*     */     }
/*  92 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getHQLCondition(List paramList, String paramString)
/*     */   {
/* 100 */     String str = paramString;
/* 101 */     if ((paramString == null) || (paramString.trim().equals("")))
/* 102 */       str = "";
/*     */     else {
/* 104 */       str = paramString + ".";
/*     */     }
/* 106 */     if ((paramList == null) || (paramList.size() == 0)) {
/* 107 */       return "1=1";
/*     */     }
/* 109 */     Condition localCondition = null;
/* 110 */     StringBuffer localStringBuffer = new StringBuffer();
/* 111 */     for (int i = 0; i < paramList.size(); i++) {
/* 112 */       if (i > 0) {
/* 113 */         localStringBuffer.append(" AND ");
/*     */       }
/* 115 */       localCondition = (Condition)paramList.get(i);
/* 116 */       localStringBuffer.append(str + localCondition.getColumn());
/* 117 */       localStringBuffer.append(" ");
/* 118 */       localStringBuffer.append(getOption(localCondition.getOperation()));
/* 119 */       localStringBuffer.append(" ? ");
/*     */     }
/* 121 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static Object[] getHQLConditionValues()
/*     */   {
/* 130 */     List localList = getCondition();
/* 131 */     if ((localList == null) || (localList.size() == 0)) {
/* 132 */       return new Object[0];
/*     */     }
/* 134 */     Condition localCondition = null;
/* 135 */     Object[] arrayOfObject = new Object[localList.size()];
/* 136 */     for (int i = 0; i < localList.size(); i++) {
/* 137 */       localCondition = (Condition)localList.get(i);
/* 138 */       arrayOfObject[i] = getValue(localCondition.getOperation(), localCondition.getValue(), localCondition.getDataType());
/*     */     }
/* 140 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */   public static Object[] getHQLConditionValues(List paramList)
/*     */   {
/* 148 */     if ((paramList == null) || (paramList.size() == 0)) {
/* 149 */       return null;
/*     */     }
/* 151 */     Condition localCondition = null;
/* 152 */     Object[] arrayOfObject = new Object[paramList.size()];
/* 153 */     for (int i = 0; i < paramList.size(); i++) {
/* 154 */       localCondition = (Condition)paramList.get(i);
/* 155 */       arrayOfObject[i] = getValue(localCondition.getOperation(), localCondition.getValue(), localCondition.getDataType());
/*     */     }
/* 157 */     return arrayOfObject;
/*     */   }
/*     */ 
/*     */   public static QueryCondition getQueryCondition()
/*     */   {
/* 166 */     Object localObject = UnieapRequestContextHolder.getRequestContext().get("advanceQueryCondition");
/* 167 */     if (localObject == null) {
/* 168 */       return null;
/*     */     }
/* 170 */     return (QueryCondition)localObject;
/*     */   }
/*     */ 
/*     */   private static List getCondition() {
/* 174 */     QueryCondition localQueryCondition = getQueryCondition();
/* 175 */     if (localQueryCondition == null) {
/* 176 */       return null;
/*     */     }
/* 178 */     List localList = localQueryCondition.getConditions();
/* 179 */     return localList;
/*     */   }
/*     */ 
/*     */   public static String getOrder()
/*     */   {
/* 187 */     List localList = getCondition();
/* 188 */     if ((localList == null) || (localList.size() == 0)) {
/* 189 */       return "";
/*     */     }
/* 191 */     Condition localCondition = null;
/* 192 */     StringBuffer localStringBuffer = new StringBuffer();
/* 193 */     for (int i = 0; i < localList.size(); i++) {
/* 194 */       localCondition = (Condition)localList.get(i);
/* 195 */       if (i > 0) {
/* 196 */         localStringBuffer.append(",");
/*     */       }
/* 198 */       if (!localCondition.getOrder().equals("")) {
/* 199 */         localStringBuffer.append(localCondition.getColumn() + " " + localCondition.getOrder().trim().toLowerCase());
/*     */       }
/*     */     }
/* 202 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   public static String getOrder(String paramString)
/*     */   {
/* 210 */     String str = "";
/* 211 */     if ((paramString == null) || (paramString.trim().equals("")))
/* 212 */       str = "";
/*     */     else {
/* 214 */       str = paramString + ".";
/*     */     }
/* 216 */     List localList = getCondition();
/* 217 */     if ((localList == null) || (localList.size() == 0)) {
/* 218 */       return "";
/*     */     }
/* 220 */     Condition localCondition = null;
/* 221 */     StringBuffer localStringBuffer = new StringBuffer();
/* 222 */     for (int i = 0; i < localList.size(); i++) {
/* 223 */       localCondition = (Condition)localList.get(i);
/* 224 */       if (i > 0) {
/* 225 */         localStringBuffer.append(",");
/*     */       }
/* 227 */       if (!localCondition.getOrder().equals("")) {
/* 228 */         localStringBuffer.append(str + localCondition.getColumn() + " " + localCondition.getOrder().trim().toLowerCase());
/*     */       }
/*     */     }
/* 231 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   private static String getOption(String paramString)
/*     */   {
/* 240 */     String str = props.getProperty(paramString);
/* 241 */     if (str == null) {
/* 242 */       throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/* 244 */     return str;
/*     */   }
/*     */ 
/*     */   private static final Object getValue(String paramString, Object paramObject, int paramInt)
/*     */   {
/* 254 */     Object localObject = null;
/* 255 */     if (paramString.indexOf("M") != -1) {
/* 256 */       if (paramString.equalsIgnoreCase("M"))
/* 257 */         localObject = "%" + paramObject + "%";
/* 258 */       else if (paramString.equalsIgnoreCase("LM"))
/* 259 */         localObject = paramObject + "%";
/* 260 */       else if (paramString.equalsIgnoreCase("RM"))
/* 261 */         localObject = "%" + paramObject;
/* 262 */       else if (paramString.equalsIgnoreCase("NM"))
/* 263 */         localObject = "%" + paramObject + "%";
/* 264 */       else if (paramString.equalsIgnoreCase("NLM"))
/* 265 */         localObject = paramObject + "%";
/* 266 */       else if (paramString.equalsIgnoreCase("NRM"))
/* 267 */         localObject = "%" + paramObject;
/*     */       else
/* 269 */         throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/* 271 */     else if (props.getProperty(paramString) != null) {
/* 272 */       if (paramObject != null) {
/* 273 */         if (paramInt == 12)
/* 274 */           localObject = (String)paramObject;
/* 275 */         else if (paramInt == 91)
/* 276 */           localObject = new Date(Long.valueOf(paramObject.toString()).longValue());
/* 277 */         else if (paramInt == 93)
/* 278 */           localObject = new Date(Long.valueOf(paramObject.toString()).longValue());
/* 279 */         else if (paramInt == 92)
/* 280 */           localObject = new Time(Long.valueOf(paramObject.toString()).longValue());
/* 281 */         else if (paramInt == 4)
/* 282 */           localObject = Integer.valueOf(indexof((String)paramObject));
/* 283 */         else if (paramInt == 8)
/* 284 */           localObject = Double.valueOf(dealPoint((String)paramObject));
/* 285 */         else if (paramInt == 3)
/*     */         {
/* 287 */           localObject = new BigDecimal(dealPoint(String.valueOf(paramObject)));
/* 288 */         } else if (paramInt == 6)
/* 289 */           localObject = Float.valueOf(dealPoint((String)paramObject));
/* 290 */         else if (paramInt == -5)
/* 291 */           localObject = Long.valueOf(indexof((String)paramObject));
/* 292 */         else if (paramInt == 16)
/* 293 */           localObject = Boolean.valueOf((String)paramObject);
/*     */       }
/*     */     }
/*     */     else {
/* 297 */       throw new RIAException("EAPTECH008002", new Object[] { paramString });
/*     */     }
/* 299 */     return localObject;
/*     */   }
/*     */ 
/*     */   private static String indexof(String paramString)
/*     */   {
/* 307 */     int i = paramString.indexOf(".");
/* 308 */     if (i == -1)
/* 309 */       return paramString;
/* 310 */     if (i == 0)
/* 311 */       return "0";
/* 312 */     return paramString.substring(0, i);
/*     */   }
/*     */ 
/*     */   private static String dealPoint(String paramString)
/*     */   {
/* 321 */     int i = 1;
/* 322 */     char[] arrayOfChar1 = paramString.toCharArray();
/* 323 */     char[] arrayOfChar2 = new char[arrayOfChar1.length];
/* 324 */     int j = 0;
/* 325 */     for (int k = 0; k < arrayOfChar1.length; k++) {
/* 326 */       if (arrayOfChar1[k] == '.') {
/* 327 */         if (i != 0) {
/* 328 */           i = 0;
/*     */         }
/*     */       }
/*     */       else
/* 332 */         arrayOfChar2[(j++)] = arrayOfChar1[k];
/*     */     }
/* 334 */     return String.valueOf(arrayOfChar2);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil
 * JD-Core Version:    0.6.2
 */