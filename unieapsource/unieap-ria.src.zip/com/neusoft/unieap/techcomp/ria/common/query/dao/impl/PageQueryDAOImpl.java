/*    */ package com.neusoft.unieap.techcomp.ria.common.query.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*    */ import com.neusoft.unieap.core.page.PageContext;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.dao.PageQueryDAO;
/*    */ 
/*    */ @ModelFile("pageQueryDAO.dao")
/*    */ public class PageQueryDAOImpl extends BaseHibernateDAO
/*    */   implements PageQueryDAO
/*    */ {
/*    */   public QueryResult queryByHQL(PageContext paramPageContext)
/*    */   {
/* 23 */     QueryResult localQueryResult = queryObjectsByPage(paramPageContext
/* 24 */       .getQueryString(), paramPageContext.getParams());
/* 25 */     if (localQueryResult.getPageContext().getKey() == null) {
/* 26 */       localQueryResult.setPageContext(paramPageContext);
/*    */     }
/* 28 */     return localQueryResult;
/*    */   }
/*    */ 
/*    */   public QueryResult queryBySQL(PageContext paramPageContext)
/*    */   {
/* 35 */     QueryResult localQueryResult = query(paramPageContext.getQueryString(), 
/* 36 */       paramPageContext.getParams(), paramPageContext.getPojo());
/* 37 */     if (localQueryResult.getPageContext().getKey() == null) {
/* 38 */       localQueryResult.setPageContext(paramPageContext);
/*    */     }
/* 40 */     return localQueryResult;
/*    */   }
/*    */ 
/*    */   public QueryResult queryBySqlMapping(PageContext paramPageContext) {
/* 44 */     QueryResult localQueryResult = queryBySqlMapping(paramPageContext.getPojo(), 
/* 45 */       paramPageContext.getQueryString(), paramPageContext.getParams());
/*    */ 
/* 47 */     if (localQueryResult.getPageContext().getKey() == null) {
/* 48 */       localQueryResult.setPageContext(paramPageContext);
/*    */     }
/* 50 */     return localQueryResult;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dao.impl.PageQueryDAOImpl
 * JD-Core Version:    0.6.2
 */