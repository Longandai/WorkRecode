/*    */ package com.neusoft.unieap.techcomp.ria.common.query.dto;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Condition
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 3440547338326528449L;
/* 13 */   private String column = null;
/*    */ 
/* 15 */   private String operation = null;
/*    */ 
/* 17 */   private Object value = null;
/*    */ 
/* 19 */   private String order = null;
/*    */   private int dataType;
/*    */ 
/*    */   public String getColumn()
/*    */   {
/* 27 */     return this.column;
/*    */   }
/*    */ 
/*    */   public void setColumn(String paramString)
/*    */   {
/* 34 */     this.column = paramString;
/*    */   }
/*    */ 
/*    */   public String getOperation()
/*    */   {
/* 41 */     return this.operation;
/*    */   }
/*    */ 
/*    */   public void setOperation(String paramString)
/*    */   {
/* 48 */     this.operation = paramString;
/*    */   }
/*    */ 
/*    */   public Object getValue()
/*    */   {
/* 55 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(Object paramObject)
/*    */   {
/* 62 */     this.value = paramObject;
/*    */   }
/*    */ 
/*    */   public int getDataType()
/*    */   {
/* 69 */     return this.dataType;
/*    */   }
/*    */ 
/*    */   public void setDataType(int paramInt)
/*    */   {
/* 76 */     this.dataType = paramInt;
/*    */   }
/*    */ 
/*    */   public void setOrder(String paramString)
/*    */   {
/* 83 */     this.order = paramString;
/*    */   }
/*    */ 
/*    */   public String getOrder()
/*    */   {
/* 90 */     return this.order;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dto.Condition
 * JD-Core Version:    0.6.2
 */