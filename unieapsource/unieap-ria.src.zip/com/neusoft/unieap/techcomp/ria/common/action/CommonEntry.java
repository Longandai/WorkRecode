/*     */ package com.neusoft.unieap.techcomp.ria.common.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseEntry;
/*     */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class CommonEntry extends BaseEntry
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private ApplicationContext applicationContext;
/*     */   private String boMehtodName;
/*     */   private String boId;
/*     */   private String dataSourceID;
/*  38 */   private List boMehtodParameterTypes = new ArrayList();
/*     */ 
/*  40 */   private List parameters = new ArrayList();
/*     */ 
/*  42 */   private List parameterTypes = new ArrayList();
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext)
/*     */     throws BeansException
/*     */   {
/*  29 */     this.applicationContext = paramApplicationContext;
/*     */   }
/*     */ 
/*     */   public void setBoMehtodParameterTypes(List paramList)
/*     */   {
/*  45 */     this.boMehtodParameterTypes = paramList;
/*     */   }
/*     */ 
/*     */   public void setParameters(List paramList) {
/*  49 */     this.parameters = paramList;
/*     */   }
/*     */ 
/*     */   public void setParameterTypes(List paramList) {
/*  53 */     this.parameterTypes = paramList;
/*     */   }
/*     */ 
/*     */   public void setBoMehtodName(String paramString) {
/*  57 */     this.boMehtodName = paramString;
/*     */   }
/*     */ 
/*     */   public void setBoId(String paramString) {
/*  61 */     this.boId = paramString;
/*     */   }
/*     */ 
/*     */   public void setDataSourceID(String paramString) {
/*  65 */     this.dataSourceID = paramString;
/*     */   }
/*     */ 
/*     */   public String show()
/*     */     throws Exception
/*     */   {
/*  75 */     ViewContext localViewContext = generateContext();
/*  76 */     DataCenter localDataCenter = DataCenterFactory.getInstance()
/*  77 */       .createDataCenter();
/*     */     Object localObject2;
/*     */     Object localObject3;
/*     */     Object localObject4;
/*  91 */     if ((this.boId == null) || (this.boId.equals("")) || (this.boMehtodName == null) || 
/*  92 */       (this.boMehtodName.equals(""))) {
/*  93 */       if ((this.parameterTypes != null) && (this.parameters != null)) {
/*  94 */         for (int i = 0; i < this.parameters.size(); i++) {
/*  95 */           localObject2 = this.parameters.get(i).toString();
/*  96 */           localObject3 = this.parameterTypes.get(i).toString();
/*  97 */           if (("pojoList".equals(localObject3)) || ("pojo".equals(localObject3))) {
/*  98 */             localObject4 = localViewContext.getDataStore((String)localObject2);
/*  99 */             if (localObject4 == null) {
/* 100 */               localObject4 = DataCenterFactory.getInstance()
/* 101 */                 .createDataStore((String)localObject2);
/*     */             }
/* 103 */             localDataCenter.addDataStore((DataStore)localObject4);
/*     */           }
/*     */           else {
/* 106 */             localDataCenter.addParameter((String)localObject2, localViewContext
/* 107 */               .get(localObject2));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 114 */       Object localObject1 = this.applicationContext.getBean(this.boId);
/* 115 */       if (localObject1 == null) {
/* 116 */         throw new RIAException("EAPTECH008012", new Object[] { this.boId });
/*     */       }
/* 118 */       localObject2 = getBOMethod(localObject1, this.boMehtodName, 
/* 119 */         this.boMehtodParameterTypes);
/*     */ 
/* 122 */       if (localObject2 == null)
/*     */       {
/* 124 */         throw new RIAException("EAPTECH008008", new Object[] { this.boId, this.boMehtodName, this.boMehtodParameterTypes.toString() });
/*     */       }
/*     */ 
/* 128 */       localObject3 = ((Method)localObject2).getParameterTypes();
/* 129 */       localObject4 = new ArrayList();
/* 130 */       if (this.parameters != null) {
/* 131 */         localObject4 = initParameters(localViewContext, this.parameters, 
/* 132 */           (Class[])localObject3);
/*     */       }
/*     */ 
/* 136 */       Class[] arrayOfClass = ((Method)localObject2).getParameterTypes();
/* 137 */       if ((arrayOfClass != null) && (arrayOfClass.length > 0)) {
/* 138 */         for (int j = 0; j < arrayOfClass.length; j++) {
/* 139 */           if ((!arrayOfClass[j].getName().equals(String.class.getName())) && 
/* 140 */             (((List)localObject4).get(j) == null) && 
/* 141 */             (CommonUtil.isCommonType(arrayOfClass[j]))) {
/* 142 */             throw new RIAException("EAPTECH008009", new Object[] { this.parameters.get(j).toString(), arrayOfClass[j] });
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 148 */       Object localObject5 = null;
/*     */       try {
/* 150 */         if ((this.dataSourceID != null) && (!"".equals(this.dataSourceID))) {
/* 151 */           DataSourceContextHolder.setDataSourceType(this.dataSourceID);
/* 152 */           localObject5 = ((Method)localObject2).invoke(localObject1, ((List)localObject4).toArray());
/*     */         } else {
/* 154 */           localObject5 = ((Method)localObject2).invoke(localObject1, ((List)localObject4).toArray());
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException localInvocationTargetException) {
/* 158 */         Throwable localThrowable = localInvocationTargetException.getCause();
/* 159 */         throw new Exception(localThrowable);
/*     */       } catch (Exception localException) {
/* 161 */         throw localException;
/*     */       }
/*     */ 
/* 165 */       Class localClass = ((Method)localObject2).getReturnType();
/* 166 */       CommonUtil.handleBoMethodReturn(localDataCenter, localObject5, localClass);
/*     */     }
/*     */ 
/* 169 */     attach2Request(localDataCenter);
/* 170 */     return "success";
/*     */   }
/*     */ 
/*     */   private Method getBOMethod(Object paramObject, String paramString, List paramList)
/*     */     throws Exception
/*     */   {
/* 188 */     Method[] arrayOfMethod = paramObject.getClass().getMethods();
/* 189 */     ArrayList localArrayList = new ArrayList();
/* 190 */     for (int i = 0; i < arrayOfMethod.length; i++) {
/* 191 */       if (paramString.equals(arrayOfMethod[i].getName())) {
/* 192 */         localArrayList.add(arrayOfMethod[i]);
/*     */       }
/*     */     }
/* 195 */     Object localObject = null;
/* 196 */     for (int j = 0; j < localArrayList.size(); j++) {
/* 197 */       Method localMethod = (Method)localArrayList.get(j);
/* 198 */       Class[] arrayOfClass = localMethod.getParameterTypes();
/* 199 */       if (arrayOfClass.length == paramList.size())
/*     */       {
/* 202 */         if (compareParametersType(paramList, arrayOfClass)) {
/* 203 */           localObject = localMethod;
/* 204 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 207 */     return localObject;
/*     */   }
/*     */ 
/*     */   private List initParameters(ViewContext paramViewContext, List paramList, Class[] paramArrayOfClass)
/*     */     throws Exception
/*     */   {
/* 221 */     ArrayList localArrayList = new ArrayList();
/* 222 */     if (this.parameterTypes != null) {
/* 223 */       for (int i = 0; i < paramList.size(); i++) {
/* 224 */         String str1 = paramList.get(i).toString();
/* 225 */         String str2 = this.parameterTypes.get(i).toString();
/* 226 */         if ("pojoList".equals(str2)) {
/* 227 */           localArrayList.add(paramViewContext.getPOJOList(str1));
/*     */         }
/* 230 */         else if ("pojo".equals(str2)) {
/* 231 */           localArrayList.add(paramViewContext.getPOJO(str1));
/*     */         }
/*     */         else {
/* 234 */           localArrayList.add(CommonUtil.getParam(
/* 235 */             paramArrayOfClass[i].getName(), str1, paramViewContext));
/*     */         }
/*     */       }
/*     */     }
/* 239 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private boolean compareParametersType(List paramList, Class[] paramArrayOfClass)
/*     */   {
/* 253 */     for (int i = 0; 
/* 254 */       i < paramArrayOfClass.length; i++) {
/* 255 */       String str1 = paramList.get(i).toString();
/* 256 */       if (str1 == null) {
/* 257 */         return false;
/*     */       }
/* 259 */       if (paramArrayOfClass[i].isArray()) { int j = paramList.get(i).toString().indexOf('[');
/* 261 */         String str2 = str1.substring(0, j);
/* 262 */         if (paramArrayOfClass[i].getComponentType().getName().equals(
/* 263 */           str2.trim()));
/*     */       }
/*     */       else {
/* 267 */         if ((!paramArrayOfClass[i].getName().equals(str1.trim())) && 
/* 270 */           ((!str1.trim().equals("Integer")) || 
/* 271 */           (!paramArrayOfClass[i].equals(Integer.class))) && 
/* 274 */           ((!str1.trim().equals("Float")) || 
/* 275 */           (!paramArrayOfClass[i].equals(Float.class))) && 
/* 278 */           ((!str1.trim().equals("Double")) || 
/* 279 */           (!paramArrayOfClass[i].equals(Double.class))) && 
/* 282 */           ((!str1.trim().equals("Boolean")) || 
/* 283 */           (!paramArrayOfClass[i].equals(Boolean.class))) && 
/* 286 */           ((!str1.trim().equals("Byte")) || 
/* 287 */           (!paramArrayOfClass[i].equals(Byte.class))) && 
/* 290 */           ((!str1.trim().equals("Character")) || 
/* 291 */           (!paramArrayOfClass[i].equals(Character.class))) && 
/* 294 */           ((!str1.trim().equals("Long")) || 
/* 295 */           (!paramArrayOfClass[i].equals(Long.class))) && 
/* 298 */           ((!str1.trim().equals("Short")) || 
/* 299 */           (!paramArrayOfClass[i].equals(Short.class))) && 
/* 302 */           ((!str1.trim().equals("String")) || 
/* 303 */           (!paramArrayOfClass[i].equals(String.class))) && (
/* 306 */           (!str1.trim().equals("Object")) || 
/* 307 */           (!paramArrayOfClass[i].equals(Object.class))))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */     }
/* 313 */     if (i == paramArrayOfClass.length) {
/* 314 */       return true;
/*     */     }
/* 316 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.action.CommonEntry
 * JD-Core Version:    0.6.2
 */