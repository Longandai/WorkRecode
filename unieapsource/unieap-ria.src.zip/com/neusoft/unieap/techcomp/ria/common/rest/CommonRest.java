/*    */ package com.neusoft.unieap.techcomp.ria.common.rest;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*    */ import com.neusoft.unieap.techcomp.ria.RIAException;
/*    */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*    */ import com.neusoft.unieap.techcomp.ria.common.util.CommonUtil;
/*    */ import com.neusoft.unieap.techcomp.ria.common.util.RestUtil;
/*    */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*    */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*    */ import java.util.Map;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.ws.rs.GET;
/*    */ import javax.ws.rs.POST;
/*    */ import javax.ws.rs.Path;
/*    */ import javax.ws.rs.Produces;
/*    */ import javax.ws.rs.core.Context;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ @Path("/")
/*    */ @Produces({"application/json"})
/*    */ public class CommonRest extends BaseProcessor
/*    */   implements ApplicationContextAware
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private ApplicationContext applicationContext;
/*    */   private RestResultHandler resultHandler;
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext)
/*    */     throws BeansException
/*    */   {
/* 39 */     this.applicationContext = paramApplicationContext;
/*    */   }
/*    */ 
/*    */   @GET
/*    */   public Object commonRestGetMethod(@Context HttpServletRequest paramHttpServletRequest, @Context HttpServletResponse paramHttpServletResponse)
/*    */     throws Exception
/*    */   {
/* 47 */     setServletRequest(paramHttpServletRequest);
/* 48 */     setServletResponse(paramHttpServletResponse);
/* 49 */     ViewContext localViewContext = generateContext();
/* 50 */     UnieapRequestContextHolder.getRequestContext().put("viewContext", localViewContext);
/* 51 */     String str1 = localViewContext.getString("boId");
/* 52 */     String str2 = localViewContext.getString("_boId");
/* 53 */     Object localObject1 = null;
/*    */     try
/*    */     {
/*    */       Object localObject2;
/* 56 */       if ((str1 != null) && (!str1.equals("")))
/*    */       {
/* 58 */         localObject2 = this.applicationContext.getBean(str1);
/* 59 */         localObject1 = RestUtil.invokeBoMethod(localViewContext, localObject2);
/* 60 */         localObject1 = this.resultHandler.handleReuslt(localViewContext, localObject1, getResponse()); } else {
/* 61 */         if ((str2 != null) && (!str2.equals("")))
/*    */         {
/* 64 */           localObject2 = this.applicationContext.getBean(str2);
/* 65 */           if (localObject2 == null)
/*    */           {
/* 67 */             throw new RIAException("EAPTECH008012", new Object[] { str1 });
/*    */           }
/* 69 */           DataCenter localDataCenter = DataCenterFactory.getInstance().createDataCenter();
/* 70 */           CommonUtil.invokeBoMethod(localViewContext, localDataCenter, localObject2);
/* 71 */           write(localDataCenter);
/* 72 */           return null;
/*    */         }
/*    */ 
/* 75 */         throw new RIAException("EAPTECH008012", new Object[] { str1 });
/*    */       }
/*    */     }
/*    */     catch (Exception localException) {
/* 79 */       localObject1 = "调用失败，请检查请求参数是否正确，" + localException.getMessage();
/* 80 */       paramHttpServletResponse.sendError(400, (String)localObject1);
/*    */     }
/* 82 */     return localObject1;
/*    */   }
/*    */ 
/*    */   @POST
/*    */   public Object commonRestPostMethod(@Context HttpServletRequest paramHttpServletRequest, @Context HttpServletResponse paramHttpServletResponse) throws Exception
/*    */   {
/* 88 */     return commonRestGetMethod(paramHttpServletRequest, paramHttpServletResponse);
/*    */   }
/*    */ 
/*    */   public void setResultHandler(RestResultHandler paramRestResultHandler)
/*    */   {
/* 93 */     this.resultHandler = paramRestResultHandler;
/*    */   }
/*    */ 
/*    */   public RestResultHandler getResultHandler()
/*    */   {
/* 98 */     return this.resultHandler;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.rest.CommonRest
 * JD-Core Version:    0.6.2
 */