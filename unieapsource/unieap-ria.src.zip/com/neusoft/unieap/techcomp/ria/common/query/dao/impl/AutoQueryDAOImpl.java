/*    */ package com.neusoft.unieap.techcomp.ria.common.query.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*    */ import com.neusoft.unieap.techcomp.ria.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.common.query.dao.AutoQueryDAO;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ @ModelFile("autoQueryDAO.dao")
/*    */ public class AutoQueryDAOImpl extends BaseHibernateDAO
/*    */   implements AutoQueryDAO
/*    */ {
/*    */   public QueryResult autoQueryByPage(Map paramMap)
/*    */   {
/* 31 */     return super.autoQueryByPage(paramMap);
/*    */   }
/*    */ 
/*    */   public QueryResult autoQueryByPage(Map paramMap, int paramInt1, int paramInt2)
/*    */   {
/* 38 */     return super.autoQueryByPage(paramMap, Integer.valueOf(paramInt1), Integer.valueOf(paramInt2));
/*    */   }
/*    */ 
/*    */   public List autoQuery(Map paramMap)
/*    */   {
/* 44 */     return super.autoQuery(paramMap);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.dao.impl.AutoQueryDAOImpl
 * JD-Core Version:    0.6.2
 */