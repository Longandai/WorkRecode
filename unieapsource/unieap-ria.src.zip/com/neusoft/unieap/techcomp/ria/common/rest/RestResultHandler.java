package com.neusoft.unieap.techcomp.ria.common.rest;

import com.neusoft.unieap.techcomp.ria.context.ViewContext;
import java.io.IOException;
import javax.servlet.http.HttpServletResponse;

public abstract interface RestResultHandler
{
  public abstract Object handleReuslt(ViewContext paramViewContext, Object paramObject, HttpServletResponse paramHttpServletResponse)
    throws IOException;
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.rest.RestResultHandler
 * JD-Core Version:    0.6.2
 */