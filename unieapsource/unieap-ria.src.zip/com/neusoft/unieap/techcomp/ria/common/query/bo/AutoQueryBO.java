package com.neusoft.unieap.techcomp.ria.common.query.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import java.util.Map;

public abstract interface AutoQueryBO
{
  public abstract QueryResult autoQueryByPage(Map paramMap);

  public abstract QueryResult autoQueryByPage(Map paramMap, int paramInt1, int paramInt2);

  public abstract QueryResult autoQuery(Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.AutoQueryBO
 * JD-Core Version:    0.6.2
 */