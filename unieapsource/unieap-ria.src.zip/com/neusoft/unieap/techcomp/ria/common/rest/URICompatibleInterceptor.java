/*    */ package com.neusoft.unieap.techcomp.ria.common.rest;
/*    */ 
/*    */ import org.apache.cxf.interceptor.Fault;
/*    */ import org.apache.cxf.message.Message;
/*    */ import org.apache.cxf.phase.AbstractPhaseInterceptor;
/*    */ 
/*    */ public class URICompatibleInterceptor extends AbstractPhaseInterceptor<Message>
/*    */ {
/*    */   public URICompatibleInterceptor()
/*    */   {
/* 11 */     super("user-stream");
/*    */   }
/*    */ 
/*    */   public void handleMessage(Message paramMessage) throws Fault
/*    */   {
/* 16 */     String str1 = (String)paramMessage.get("org.apache.cxf.request.method");
/* 17 */     String str2 = (String)paramMessage.get("org.apache.cxf.request.uri");
/* 18 */     int i = str1.equals("GET") ? str2.indexOf("/unieapServices/rest/common/get") : -1;
/* 19 */     if (i == -1)
/*    */     {
/* 21 */       i = str1.equals("POST") ? str2.indexOf("/unieapServices/rest/common/post") : -1;
/*    */     }
/* 23 */     if (i != -1)
/*    */     {
/* 25 */       str2 = str2.substring(0, i) + "/unieapServices/rest/";
/* 26 */       paramMessage.put("org.apache.cxf.request.uri", str2);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.rest.URICompatibleInterceptor
 * JD-Core Version:    0.6.2
 */