/*    */ package com.neusoft.unieap.techcomp.ria.common.query.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("queryCondition.entity")
/*    */ public class QueryCondition
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String createdBy;
/*    */   private String viewId;
/*    */   private String condition;
/*    */   private String name;
/*    */   private String controlId;
/*    */   private String label;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 46 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 50 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setCreatedBy(String paramString) {
/* 54 */     this.createdBy = paramString;
/*    */   }
/*    */ 
/*    */   public String getCreatedBy() {
/* 58 */     return this.createdBy;
/*    */   }
/*    */ 
/*    */   public void setViewId(String paramString) {
/* 62 */     this.viewId = paramString;
/*    */   }
/*    */ 
/*    */   public String getViewId() {
/* 66 */     return this.viewId;
/*    */   }
/*    */ 
/*    */   public void setCondition(String paramString) {
/* 70 */     this.condition = paramString;
/*    */   }
/*    */ 
/*    */   public String getCondition() {
/* 74 */     return this.condition;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString) {
/* 78 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 82 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setControlId(String paramString) {
/* 86 */     this.controlId = paramString;
/*    */   }
/*    */ 
/*    */   public String getControlId() {
/* 90 */     return this.controlId;
/*    */   }
/*    */ 
/*    */   public void setLabel(String paramString) {
/* 94 */     this.label = paramString;
/*    */   }
/*    */ 
/*    */   public String getLabel() {
/* 98 */     return this.label;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.entity.QueryCondition
 * JD-Core Version:    0.6.2
 */