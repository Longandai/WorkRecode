package com.neusoft.unieap.techcomp.ria.common.query.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.core.page.PageContext;
import com.neusoft.unieap.techcomp.ria.common.query.dao.PageQueryDAO;

public abstract interface PageQueryBO
{
  public abstract QueryResult query(PageContext paramPageContext);

  public abstract PageQueryDAO getPageQueryDAO();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.common.query.bo.PageQueryBO
 * JD-Core Version:    0.6.2
 */