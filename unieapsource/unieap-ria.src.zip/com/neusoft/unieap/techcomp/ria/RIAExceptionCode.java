package com.neusoft.unieap.techcomp.ria;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class RIAExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "008";
  private static final String _P = "EAPTECH008";
  public static final String RIA_ARGUMENT_CONVERT_EXP = "EAPTECH008001";
  public static final String RIA_QUERY_CONDITION_CONVERT = "EAPTECH008002";
  public static final String RIA_REQUEST_PARAMETER_AND_DS_NAME_SAME = "EAPTECH008003";
  public static final String GET_IDENTIFIER_NAME_EXP = "EAPTECH008004";
  public static final String GET_BEAN_PROPERTY_EXP = "EAPTECH008005";
  public static final String CREATE_PROXY_POJO_HANDLER_EXP = "EAPTECH008006";
  public static final String REQUIRED_SERIALIZABLE_OBJECT_EXP = "EAPTECH008007";
  public static final String QUERY_FAIL_ILLEGAL_REQUEST = "EAPTECH008014";
  public static final String QUERY_FAIL_CONDITION_MISSING = "EAPTECH008015";
  public static final String TRACEDISABLED = "TRACEDISABLED";
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.RIAExceptionCode
 * JD-Core Version:    0.6.2
 */