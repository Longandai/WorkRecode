/*    */ package com.neusoft.unieap.techcomp.ria.individual.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ import org.hibernate.validator.constraints.Length;
/*    */ 
/*    */ @ModelFile("page.entity")
/*    */ public class Page
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String circumstanceId;
/*    */   private String description;
/*    */   private String url;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 33 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 37 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setCircumstanceId(String paramString) {
/* 41 */     this.circumstanceId = paramString;
/*    */   }
/*    */ 
/*    */   @Length(max=32, message="${techcomp.ria/techcomp.ria.entity.page.circumstanceId.length.message}")
/*    */   public String getCircumstanceId() {
/* 46 */     return this.circumstanceId;
/*    */   }
/*    */ 
/*    */   public void setDescription(String paramString) {
/* 50 */     this.description = paramString;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 54 */     return this.description;
/*    */   }
/*    */ 
/*    */   public void setUrl(String paramString) {
/* 58 */     this.url = paramString;
/*    */   }
/*    */ 
/*    */   public String getUrl() {
/* 62 */     return this.url;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.entity.Page
 * JD-Core Version:    0.6.2
 */