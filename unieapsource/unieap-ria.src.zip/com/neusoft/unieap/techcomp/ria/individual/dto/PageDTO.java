/*     */ package com.neusoft.unieap.techcomp.ria.individual.dto;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class PageDTO
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String label;
/*     */   private String type;
/*     */   private String url;
/*     */   private String parentID;
/*     */   private Boolean isLeaf;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  60 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/*  67 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setLabel(String paramString)
/*     */   {
/*  74 */     this.label = paramString;
/*     */   }
/*     */ 
/*     */   public String getLabel()
/*     */   {
/*  81 */     return this.label;
/*     */   }
/*     */ 
/*     */   public void setUrl(String paramString)
/*     */   {
/*  88 */     this.url = paramString;
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/*  95 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setType(String paramString)
/*     */   {
/* 102 */     this.type = paramString;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 109 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setParentID(String paramString)
/*     */   {
/* 116 */     this.parentID = paramString;
/*     */   }
/*     */ 
/*     */   public String getParentID()
/*     */   {
/* 123 */     return this.parentID;
/*     */   }
/*     */ 
/*     */   public void setIsLeaf(Boolean paramBoolean)
/*     */   {
/* 130 */     this.isLeaf = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getIsLeaf()
/*     */   {
/* 137 */     return this.isLeaf;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.dto.PageDTO
 * JD-Core Version:    0.6.2
 */