/*     */ package com.neusoft.unieap.techcomp.ria.individual.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.model.DCRepository;
/*     */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*     */ import com.neusoft.unieap.core.base.model.SCActivator;
/*     */ import com.neusoft.unieap.core.base.model.SCRepository;
/*     */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.bo.PageIndividualBO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.dao.PageIndividualDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.dto.PageDTO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.Page;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.io.filefilter.FileFilterUtils;
/*     */ 
/*     */ @ModelFile("pageIndividualBO.bo")
/*     */ public class PageIndividualBOImpl
/*     */   implements PageIndividualBO
/*     */ {
/*     */   private PageIndividualDAO pageIndividualDAO;
/*     */ 
/*     */   public void setPageIndividualDAO(PageIndividualDAO paramPageIndividualDAO)
/*     */   {
/*  39 */     this.pageIndividualDAO = paramPageIndividualDAO;
/*     */   }
/*     */ 
/*     */   public Page savePage(Page paramPage)
/*     */   {
/*  46 */     String str = paramPage.getCircumstanceId();
/*     */ 
/*  48 */     if (this.pageIndividualDAO.isCircumstanceExist(str)) {
/*  49 */       throw new UniEAPBusinessException("EAPTECHRIA1003", 
/*  50 */         new Object[] { str });
/*     */     }
/*  52 */     return this.pageIndividualDAO.savePage(paramPage);
/*     */   }
/*     */ 
/*     */   public Page updatePage(Page paramPage)
/*     */   {
/*  59 */     String str1 = paramPage.getCircumstanceId();
/*  60 */     String str2 = paramPage.getId();
/*     */ 
/*  62 */     if (this.pageIndividualDAO.isCircumstanceExistExceptCurrId(str2, 
/*  63 */       str1)) {
/*  64 */       throw new UniEAPBusinessException("EAPTECHRIA1003", 
/*  65 */         new Object[] { str1 });
/*     */     }
/*  67 */     Page localPage = getPageById(str2);
/*  68 */     if (localPage != null) {
/*  69 */       if (!localPage.getCircumstanceId().equals(str1))
/*     */       {
/*  71 */         this.pageIndividualDAO.updatePageIndividualInfo(localPage
/*  72 */           .getCircumstanceId(), str1);
/*     */       }
/*  74 */       localPage.setCircumstanceId(str1);
/*  75 */       localPage.setDescription(paramPage.getDescription());
/*     */     }
/*  77 */     return this.pageIndividualDAO.updatePage(localPage);
/*     */   }
/*     */ 
/*     */   public void deletePage(String paramString)
/*     */   {
/*  84 */     this.pageIndividualDAO.deletePage(paramString);
/*  85 */     this.pageIndividualDAO.deletePageIndividualInfo(paramString);
/*     */   }
/*     */ 
/*     */   public List getSCs()
/*     */   {
/*  92 */     List localList = SCRepository.getSoftwareComponents();
/*  93 */     ArrayList localArrayList = new ArrayList();
/*  94 */     if ((localList != null) && (localList.size() > 0)) {
/*  95 */       for (int i = 0; i < localList.size(); i++) {
/*  96 */         PageDTO localPageDTO = new PageDTO();
/*  97 */         localPageDTO.setId(((SCActivator)localList.get(i)).getId());
/*  98 */         localPageDTO.setLabel(((SCActivator)localList.get(i)).getId());
/*  99 */         localPageDTO.setParentID("-1");
/* 100 */         localPageDTO.setUrl("");
/* 101 */         localPageDTO.setType("SC");
/* 102 */         localArrayList.add(localPageDTO);
/*     */       }
/*     */     }
/* 105 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getDCsBySCId(String paramString)
/*     */   {
/* 112 */     List localList = DCRepository.getAvailableDevelopmentComponent();
/* 113 */     ArrayList localArrayList = new ArrayList();
/* 114 */     if ((localList != null) && (localList.size() > 0)) {
/* 115 */       DevelopmentComponent localDevelopmentComponent = null;
/* 116 */       for (int i = 0; i < localList.size(); i++) {
/* 117 */         localDevelopmentComponent = (DevelopmentComponent)localList.get(i);
/* 118 */         if (paramString.equals(localDevelopmentComponent.getSoftwareComponent().getId())) {
/* 119 */           PageDTO localPageDTO = new PageDTO();
/* 120 */           localPageDTO.setId(localDevelopmentComponent.getId());
/* 121 */           localPageDTO.setLabel(localDevelopmentComponent.getId());
/* 122 */           localPageDTO.setParentID(paramString);
/* 123 */           localPageDTO.setUrl("");
/* 124 */           localPageDTO.setType("DC");
/* 125 */           localArrayList.add(localPageDTO);
/*     */         }
/*     */       }
/*     */     }
/* 129 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getChildFilesByDCId(String paramString)
/*     */   {
/* 136 */     if (DCRepository.getDevelopmentComponent(paramString) == null)
/* 137 */       return null;
/* 138 */     String str1 = DCRepository.getDevelopmentComponent(paramString)
/* 139 */       .getSoftwareComponent().getId();
/* 140 */     String str2 = I18nGlobalContext.getInstance()
/* 141 */       .getServletContext().getRealPath(File.separator);
/* 142 */     str2 = 
/* 143 */       str2 + File.separator;
/* 144 */     File localFile1 = new File(str2 + str1 + File.separator + paramString);
/* 145 */     ArrayList localArrayList = new ArrayList();
/* 146 */     if (localFile1.isDirectory()) {
/* 147 */       File[] arrayOfFile1 = localFile1.listFiles();
/* 148 */       for (File localFile2 : arrayOfFile1)
/*     */       {
/*     */         Object localObject;
/* 149 */         if (localFile2.isDirectory()) {
/* 150 */           localObject = FileUtils.listFiles(localFile2, 
/* 151 */             FileFilterUtils.suffixFileFilter("-view.jsp"), 
/* 152 */             FileFilterUtils.directoryFileFilter());
/* 153 */           if ((localObject != null) && (((Collection)localObject).size() > 0)) {
/* 154 */             PageDTO localPageDTO = new PageDTO();
/* 155 */             localPageDTO.setId(UUID.randomUUID().toString());
/* 156 */             localPageDTO.setLabel(localFile2.getName());
/* 157 */             localPageDTO.setParentID(paramString);
/* 158 */             localPageDTO.setType("Folder");
/* 159 */             localPageDTO.setUrl(localFile2.getPath().substring(
/* 160 */               str2.length() - 1).replace(
/* 161 */               File.separator, "/"));
/* 162 */             localArrayList.add(localPageDTO);
/*     */           }
/* 164 */         } else if (localFile2.getName().endsWith("-view.jsp")) {
/* 165 */           localObject = new PageDTO();
/* 166 */           ((PageDTO)localObject).setId(UUID.randomUUID().toString());
/* 167 */           ((PageDTO)localObject).setLabel(localFile2.getName());
/* 168 */           ((PageDTO)localObject).setParentID(paramString);
/* 169 */           ((PageDTO)localObject).setType("Page");
/* 170 */           ((PageDTO)localObject).setUrl(localFile2.getPath().substring(
/* 171 */             str2.length() - 1).replace(File.separator, 
/* 172 */             "/"));
/* 173 */           localArrayList.add(localObject);
/*     */         }
/*     */       }
/*     */     }
/* 177 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getChildFilesByFolder(String paramString1, String paramString2)
/*     */   {
/* 184 */     String str = I18nGlobalContext.getInstance()
/* 185 */       .getServletContext().getRealPath(File.separator);
/* 186 */     str = 
/* 187 */       str + File.separator;
/* 188 */     File localFile1 = new File(str + paramString2.replace("/", File.separator));
/* 189 */     ArrayList localArrayList = new ArrayList();
/* 190 */     if (localFile1.isDirectory()) {
/* 191 */       File[] arrayOfFile1 = localFile1.listFiles();
/* 192 */       for (File localFile2 : arrayOfFile1)
/*     */       {
/*     */         Object localObject;
/* 193 */         if (localFile2.isDirectory()) {
/* 194 */           localObject = FileUtils.listFiles(localFile2, 
/* 195 */             FileFilterUtils.suffixFileFilter("-view.jsp"), 
/* 196 */             FileFilterUtils.directoryFileFilter());
/* 197 */           if ((localObject != null) && (((Collection)localObject).size() > 0)) {
/* 198 */             PageDTO localPageDTO = new PageDTO();
/* 199 */             localPageDTO.setId(UUID.randomUUID().toString());
/* 200 */             localPageDTO.setLabel(localFile2.getName());
/* 201 */             localPageDTO.setParentID(paramString1);
/* 202 */             localPageDTO.setType("Folder");
/* 203 */             localPageDTO.setUrl(localFile2.getPath().substring(
/* 204 */               str.length() - 1).replace(
/* 205 */               File.separator, "/"));
/* 206 */             localArrayList.add(localPageDTO);
/*     */           }
/* 208 */         } else if (localFile2.getName().endsWith("-view.jsp")) {
/* 209 */           localObject = new PageDTO();
/* 210 */           ((PageDTO)localObject).setId(UUID.randomUUID().toString());
/* 211 */           ((PageDTO)localObject).setLabel(localFile2.getName());
/* 212 */           ((PageDTO)localObject).setParentID(paramString1);
/* 213 */           ((PageDTO)localObject).setType("Page");
/* 214 */           ((PageDTO)localObject).setUrl(localFile2.getPath().substring(
/* 215 */             str.length() - 1).replace(File.separator, 
/* 216 */             "/"));
/* 217 */           localArrayList.add(localObject);
/*     */         }
/*     */       }
/*     */     }
/* 221 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getCircumstancesByPage(String paramString1, String paramString2)
/*     */   {
/* 229 */     List localList = this.pageIndividualDAO.getPagesByURL(paramString2);
/* 230 */     ArrayList localArrayList = new ArrayList();
/* 231 */     if ((localList != null) && (localList.size() > 0)) {
/* 232 */       for (int i = 0; i < localList.size(); i++) {
/* 233 */         PageDTO localPageDTO = new PageDTO();
/* 234 */         localPageDTO.setId(((Page)localList.get(i)).getId());
/* 235 */         localPageDTO.setLabel(((Page)localList.get(i)).getCircumstanceId());
/* 236 */         localPageDTO.setParentID(paramString1);
/* 237 */         localPageDTO.setUrl(((Page)localList.get(i)).getUrl());
/* 238 */         localPageDTO.setType("Circumstance");
/* 239 */         localPageDTO.setIsLeaf(Boolean.valueOf(true));
/* 240 */         localArrayList.add(localPageDTO);
/*     */       }
/*     */     }
/* 243 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public Page getPageById(String paramString)
/*     */   {
/* 250 */     return this.pageIndividualDAO.getPageById(paramString);
/*     */   }
/*     */ 
/*     */   public List getPageIndividualList(String paramString1, String paramString2)
/*     */   {
/* 257 */     return this.pageIndividualDAO.getPageIndividualList(paramString1, 
/* 258 */       paramString2);
/*     */   }
/*     */ 
/*     */   public List savePageIndividualList(List paramList)
/*     */   {
/* 265 */     ArrayList localArrayList = new ArrayList();
/* 266 */     if (paramList != null) {
/* 267 */       for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 268 */         PageIndividual localPageIndividual = (PageIndividual)localObject;
/* 269 */         String str1 = localPageIndividual.getId();
/* 270 */         String str2 = localPageIndividual.getIndividualType();
/* 271 */         if (str1 == null) {
/* 272 */           if (!str2.equals("writely")) {
/* 273 */             localPageIndividual = this.pageIndividualDAO
/* 274 */               .savePageIndividual(localPageIndividual);
/*     */           }
/*     */         }
/* 277 */         else if (str2.equals("writely"))
/* 278 */           localArrayList.add(localPageIndividual);
/*     */         else {
/* 280 */           this.pageIndividualDAO.updatePageIndividual(localPageIndividual);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 285 */     if (localArrayList.size() > 0) {
/* 286 */       this.pageIndividualDAO.deletePageIndividualList(localArrayList);
/* 287 */       paramList.removeAll(localArrayList);
/*     */     }
/* 289 */     return paramList;
/*     */   }
/*     */ 
/*     */   public String getSCIds()
/*     */   {
/* 296 */     StringBuilder localStringBuilder = new StringBuilder();
/* 297 */     List localList = SCRepository.getSoftwareComponents();
/* 298 */     if ((localList == null) || (localList.size() == 0)) {
/* 299 */       return "";
/*     */     }
/* 301 */     int i = localList.size();
/* 302 */     for (int j = 0; j < i; j++) {
/* 303 */       localStringBuilder.append(((SoftwareComponent)localList.get(j)).getId());
/* 304 */       if (j != i - 1) {
/* 305 */         localStringBuilder.append(",");
/*     */       }
/*     */     }
/* 308 */     return localStringBuilder.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.bo.impl.PageIndividualBOImpl
 * JD-Core Version:    0.6.2
 */