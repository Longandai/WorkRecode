/*     */ package com.neusoft.unieap.techcomp.ria.individual.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.dao.PageIndividualDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.Page;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("pageIndividualDAO.dao")
/*     */ public class PageIndividualDAOImpl extends BaseHibernateDAO
/*     */   implements PageIndividualDAO
/*     */ {
/*     */   public Page savePage(Page paramPage)
/*     */   {
/*  33 */     getHibernateTemplate().save(paramPage);
/*  34 */     return paramPage;
/*     */   }
/*     */ 
/*     */   public Page updatePage(Page paramPage)
/*     */   {
/*  41 */     getHibernateTemplate().update(paramPage);
/*  42 */     return paramPage;
/*     */   }
/*     */ 
/*     */   public void deletePage(String paramString)
/*     */   {
/*  50 */     getHibernateTemplate().bulkUpdate("delete from Page page where page.circumstanceId = ?", paramString);
/*     */   }
/*     */ 
/*     */   public List getPagesByURL(String paramString)
/*     */   {
/*  57 */     String str = "from Page page where page.url = ?";
/*  58 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public Page getPageById(String paramString)
/*     */   {
/*  65 */     String str = "from Page page where page.id = ?";
/*  66 */     List localList = getHibernateTemplate().find(str, paramString);
/*  67 */     if ((localList == null) || (localList.size() == 0)) {
/*  68 */       return null;
/*     */     }
/*  70 */     return (Page)localList.get(0);
/*     */   }
/*     */ 
/*     */   public boolean isCircumstanceExist(String paramString)
/*     */   {
/*  77 */     String str = "from Page page where page.circumstanceId = ?";
/*  78 */     List localList = getHibernateTemplate().find(str, paramString);
/*  79 */     if ((localList == null) || (localList.size() == 0)) {
/*  80 */       return false;
/*     */     }
/*  82 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isCircumstanceExistExceptCurrId(String paramString1, String paramString2)
/*     */   {
/*  90 */     String str = "from Page page where page.circumstanceId = ? and page.id <> ? ";
/*  91 */     List localList = getHibernateTemplate().find(str, 
/*  92 */       new Object[] { paramString2, paramString1 });
/*  93 */     if ((localList == null) || (localList.size() == 0)) {
/*  94 */       return false;
/*     */     }
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   public List getPageIndividualList(final String paramString1, final String paramString2)
/*     */   {
/* 104 */     List localList = (List)getHibernateTemplate().execute(
/* 105 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 108 */         String str = "from PageIndividual pageIndividual where pageIndividual.resourceId like ? and pageIndividual.circumstanceId = ? ";
/*     */ 
/* 111 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 112 */         localQuery.setParameter(0, paramString1 + "%");
/* 113 */         localQuery.setParameter(1, paramString2);
/* 114 */         return localQuery.list();
/*     */       }
/*     */     });
/* 117 */     return localList;
/*     */   }
/*     */ 
/*     */   public void deletePageIndividualList(final List paramList)
/*     */   {
/* 124 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 127 */         String str = "delete from PageIndividual pageIndividual where";
/* 128 */         str = str + " pageIndividual.id in (:ids)";
/* 129 */         int i = paramList.size();
/* 130 */         ArrayList localArrayList = new ArrayList();
/* 131 */         for (int j = 0; j < i; j++) {
/* 132 */           PageIndividual localPageIndividual = 
/* 133 */             (PageIndividual)paramList
/* 133 */             .get(j);
/* 134 */           localArrayList.add(localPageIndividual.getId());
/*     */         }
/* 136 */         Query localQuery = PageIndividualDAOImpl.this.getSession().createQuery(str);
/* 137 */         localQuery.setParameterList("ids", localArrayList);
/* 138 */         localQuery.executeUpdate();
/* 139 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public PageIndividual savePageIndividual(PageIndividual paramPageIndividual)
/*     */   {
/* 148 */     getHibernateTemplate().save(paramPageIndividual);
/* 149 */     return paramPageIndividual;
/*     */   }
/*     */ 
/*     */   public void updatePageIndividual(PageIndividual paramPageIndividual)
/*     */   {
/* 156 */     getHibernateTemplate().update(paramPageIndividual);
/*     */   }
/*     */ 
/*     */   public void deletePageIndividualInfo(final String paramString)
/*     */   {
/* 163 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 166 */         String str = "delete from PageIndividual pageIndividual where";
/* 167 */         str = str + " pageIndividual.circumstanceId = ?";
/* 168 */         Query localQuery = PageIndividualDAOImpl.this.getSession().createQuery(str);
/* 169 */         localQuery.setParameter(0, paramString);
/* 170 */         localQuery.executeUpdate();
/* 171 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void updatePageIndividualInfo(final String paramString1, final String paramString2)
/*     */   {
/* 181 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 184 */         String str = "update PageIndividual pageIndividual  set pageIndividual.circumstanceId = ? where pageIndividual.circumstanceId = ? ";
/*     */ 
/* 187 */         Query localQuery = PageIndividualDAOImpl.this.getSession().createQuery(str);
/* 188 */         localQuery.setParameter(0, paramString2);
/* 189 */         localQuery.setParameter(1, paramString1);
/* 190 */         localQuery.executeUpdate();
/* 191 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.dao.impl.PageIndividualDAOImpl
 * JD-Core Version:    0.6.2
 */