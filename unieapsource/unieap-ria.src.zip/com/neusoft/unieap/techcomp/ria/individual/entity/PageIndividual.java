/*    */ package com.neusoft.unieap.techcomp.ria.individual.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("pageIndividual.entity")
/*    */ public class PageIndividual
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String circumstanceId;
/*    */   private String resourceId;
/*    */   private String individualType;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 31 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 35 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setCircumstanceId(String paramString) {
/* 39 */     this.circumstanceId = paramString;
/*    */   }
/*    */ 
/*    */   public String getCircumstanceId() {
/* 43 */     return this.circumstanceId;
/*    */   }
/*    */ 
/*    */   public void setResourceId(String paramString) {
/* 47 */     this.resourceId = paramString;
/*    */   }
/*    */ 
/*    */   public String getResourceId() {
/* 51 */     return this.resourceId;
/*    */   }
/*    */ 
/*    */   public void setIndividualType(String paramString) {
/* 55 */     this.individualType = paramString;
/*    */   }
/*    */ 
/*    */   public String getIndividualType() {
/* 59 */     return this.individualType;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual
 * JD-Core Version:    0.6.2
 */