package com.neusoft.unieap.techcomp.ria.individual.dao;

import java.util.List;

public abstract interface GridIndividualDAO
{
  public abstract void saveIndividual(Object paramObject);

  public abstract void updateIndividual(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void delIndividual(String paramString1, String paramString2, String paramString3);

  public abstract List getIndividual(String paramString1, String paramString2, String paramString3);

  public abstract List getIndividualByUser(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.dao.GridIndividualDAO
 * JD-Core Version:    0.6.2
 */