/*    */ package com.neusoft.unieap.techcomp.ria.individual.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.individual.dao.GridIndividualDAO;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("gridIndividualDAO.dao")
/*    */ public class GridIndividualDAOImpl extends BaseHibernateDAO
/*    */   implements GridIndividualDAO
/*    */ {
/*    */   public List getIndividual(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 28 */     String str = "from Custom custom where custom.userId = ? and custom.path = ? and custom.cmpId = ?";
/* 29 */     return getHibernateTemplate().find(str, 
/* 30 */       new Object[] { paramString1, paramString2, paramString3 });
/*    */   }
/*    */   public List getIndividualByUser(String paramString) {
/* 33 */     String str = "from Custom custom where custom.userId = ? ";
/* 34 */     return getHibernateTemplate().find(str, 
/* 35 */       new Object[] { paramString });
/*    */   }
/*    */   public void delIndividual(String paramString1, String paramString2, String paramString3) {
/* 38 */     String str = "delete from Custom custom where custom.userId = ? and custom.path = ? and custom.cmpId = ?";
/* 39 */     getHibernateTemplate().bulkUpdate(str, 
/* 40 */       new Object[] { paramString1, paramString2, paramString3 });
/*    */   }
/*    */ 
/*    */   public void updateIndividual(String paramString1, String paramString2, String paramString3, String paramString4)
/*    */   {
/* 45 */     String str = "update Custom custom set custom.content = ? where custom.userId = ? and custom.path = ? and custom.cmpId = ? ";
/* 46 */     getHibernateTemplate().bulkUpdate(str, 
/* 47 */       new Object[] { paramString4, paramString1, paramString2, paramString3 });
/*    */   }
/*    */ 
/*    */   public void saveIndividual(Object paramObject) {
/* 51 */     getHibernateTemplate().save(paramObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.dao.impl.GridIndividualDAOImpl
 * JD-Core Version:    0.6.2
 */