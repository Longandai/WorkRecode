package com.neusoft.unieap.techcomp.ria.individual.dao;

import com.neusoft.unieap.techcomp.ria.individual.entity.Page;
import com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual;
import java.util.List;

public abstract interface PageIndividualDAO
{
  public abstract Page savePage(Page paramPage);

  public abstract Page updatePage(Page paramPage);

  public abstract void deletePage(String paramString);

  public abstract List getPagesByURL(String paramString);

  public abstract Page getPageById(String paramString);

  public abstract boolean isCircumstanceExist(String paramString);

  public abstract boolean isCircumstanceExistExceptCurrId(String paramString1, String paramString2);

  public abstract List getPageIndividualList(String paramString1, String paramString2);

  public abstract PageIndividual savePageIndividual(PageIndividual paramPageIndividual);

  public abstract void updatePageIndividual(PageIndividual paramPageIndividual);

  public abstract void deletePageIndividualList(List paramList);

  public abstract void deletePageIndividualInfo(String paramString);

  public abstract void updatePageIndividualInfo(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.dao.PageIndividualDAO
 * JD-Core Version:    0.6.2
 */