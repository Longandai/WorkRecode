/*    */ package com.neusoft.unieap.techcomp.ria.individual.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.techcomp.ria.individual.bo.GridIndividualBO;
/*    */ import com.neusoft.unieap.techcomp.ria.individual.dao.GridIndividualDAO;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("gridIndividualBO.bo")
/*    */ public class GridIndividualBOImpl
/*    */   implements GridIndividualBO
/*    */ {
/*    */   private GridIndividualDAO dao;
/*    */ 
/*    */   public GridIndividualDAO getDao()
/*    */   {
/* 22 */     return this.dao;
/*    */   }
/*    */ 
/*    */   public void setDao(GridIndividualDAO paramGridIndividualDAO) {
/* 26 */     this.dao = paramGridIndividualDAO;
/*    */   }
/*    */ 
/*    */   public List getIndividual(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 31 */     return this.dao.getIndividual(paramString1, paramString2, paramString3);
/*    */   }
/*    */ 
/*    */   public List getIndividualByUser(String paramString) {
/* 35 */     return this.dao.getIndividualByUser(paramString);
/*    */   }
/*    */ 
/*    */   public void delIndividual(String paramString1, String paramString2, String paramString3) {
/* 39 */     this.dao.delIndividual(paramString1, paramString2, paramString3);
/*    */   }
/*    */ 
/*    */   public void saveIndividual(Object paramObject) {
/* 43 */     this.dao.saveIndividual(paramObject);
/*    */   }
/*    */ 
/*    */   public void updateIndividual(String paramString1, String paramString2, String paramString3, String paramString4)
/*    */   {
/* 48 */     this.dao.updateIndividual(paramString1, paramString2, paramString3, paramString4);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.bo.impl.GridIndividualBOImpl
 * JD-Core Version:    0.6.2
 */