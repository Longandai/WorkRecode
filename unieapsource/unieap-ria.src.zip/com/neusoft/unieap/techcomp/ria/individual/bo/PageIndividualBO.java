package com.neusoft.unieap.techcomp.ria.individual.bo;

import com.neusoft.unieap.techcomp.ria.individual.entity.Page;
import java.util.List;

public abstract interface PageIndividualBO
{
  public abstract List getSCs();

  public abstract List getDCsBySCId(String paramString);

  public abstract List getChildFilesByDCId(String paramString);

  public abstract List getChildFilesByFolder(String paramString1, String paramString2);

  public abstract List getCircumstancesByPage(String paramString1, String paramString2);

  public abstract Page getPageById(String paramString);

  public abstract Page savePage(Page paramPage);

  public abstract Page updatePage(Page paramPage);

  public abstract void deletePage(String paramString);

  public abstract List getPageIndividualList(String paramString1, String paramString2);

  public abstract List savePageIndividualList(List paramList);

  public abstract String getSCIds();
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.individual.bo.PageIndividualBO
 * JD-Core Version:    0.6.2
 */