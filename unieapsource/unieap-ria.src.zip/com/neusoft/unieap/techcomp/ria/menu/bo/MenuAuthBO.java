package com.neusoft.unieap.techcomp.ria.menu.bo;

import java.util.List;

public abstract interface MenuAuthBO
{
  public abstract List getAllowedMenus(List paramList);

  public abstract List getAuthorityMenus(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract List getAuthorityMenus(String paramString1, String paramString2);

  public abstract List getAuthorityApps(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List getAuthorityApps(String paramString);

  public abstract void saveTreeResources(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8);

  public abstract List getAllowedMenus(String paramString1, String paramString2);

  public abstract List getAvaliableApps();

  public abstract List getAvaliableMenus(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO
 * JD-Core Version:    0.6.2
 */