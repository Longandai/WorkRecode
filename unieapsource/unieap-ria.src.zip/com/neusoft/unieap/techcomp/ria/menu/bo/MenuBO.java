package com.neusoft.unieap.techcomp.ria.menu.bo;

import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
import java.util.List;
import java.util.Map;

public abstract interface MenuBO
{
  public static final String CACHE_NAME = "menu";

  public abstract List<Menu> getMenuTree(String paramString1, String paramString2)
    throws Exception;

  public abstract Menu saveMenu(String paramString1, String paramString2, Map paramMap);

  public abstract Menu updateMenu(Menu paramMenu, Map paramMap);

  public abstract Menu updateMenu(Menu paramMenu);

  public abstract void deleteMenus(String paramString, List paramList);

  public abstract void deleteMenu(String paramString1, String paramString2);

  public abstract List getChildMenusById(String paramString1, String paramString2);

  public abstract void initCache();

  public abstract void initCache(String paramString);

  public abstract List getRootMenusByAppId(String paramString);

  public abstract List getMenusByAppId(String paramString);

  public abstract Menu getMenuById(String paramString1, String paramString2);

  public abstract void moveMenu(String paramString1, String paramString2, String paramString3);

  public abstract boolean isNameDuplicated(String paramString1, String paramString2, String paramString3);

  public abstract List getAvailableApplications();

  public abstract List getAllDescendantMenusById(String paramString1, String paramString2);

  public abstract boolean isInclude(Menu paramMenu, List paramList);

  public abstract boolean isUrlInclude(Menu paramMenu, List paramList);

  public abstract List getAllMenus();

  public abstract Map getExtInfo(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO
 * JD-Core Version:    0.6.2
 */