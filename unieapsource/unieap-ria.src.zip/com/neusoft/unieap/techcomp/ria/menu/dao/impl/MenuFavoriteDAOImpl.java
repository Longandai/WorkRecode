/*     */ package com.neusoft.unieap.techcomp.ria.menu.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.dao.MenuFavoriteDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("menuFavoriteDAO.dao")
/*     */ public class MenuFavoriteDAOImpl extends BaseHibernateDAO
/*     */   implements MenuFavoriteDAO
/*     */ {
/*     */   public MenuFavorite saveMenuFavorite(MenuFavorite paramMenuFavorite)
/*     */   {
/*  36 */     getHibernateTemplate().save(paramMenuFavorite);
/*  37 */     return paramMenuFavorite;
/*     */   }
/*     */ 
/*     */   public Menu getMenuById(String paramString)
/*     */   {
/*  44 */     String str = "from Menu m  where m.id = ? ";
/*  45 */     List localList = queryObjects(str, paramString);
/*  46 */     if (localList.size() > 0) {
/*  47 */       return (Menu)localList.get(0);
/*     */     }
/*  49 */     return null;
/*     */   }
/*     */ 
/*     */   public MenuFavorite updateMenuFavorite(MenuFavorite paramMenuFavorite)
/*     */   {
/*  56 */     getHibernateTemplate().update(paramMenuFavorite);
/*  57 */     return paramMenuFavorite;
/*     */   }
/*     */ 
/*     */   public void deleteMenuFavorite(final String[] paramArrayOfString)
/*     */   {
/*  65 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  68 */         paramAnonymousSession.createQuery("delete from MenuFavorite mf where  mf.id in(:ids) ").setParameterList("ids", paramArrayOfString)
/*  69 */           .executeUpdate();
/*  70 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public int getMaxMenuFavoriteDisplayOrder(String paramString)
/*     */   {
/*  79 */     String str = "select max(mf.displayOrder) from MenuFavorite mf where mf.userId = ?";
/*  80 */     getHibernateTemplate().find(str, paramString);
/*  81 */     List localList = getHibernateTemplate().find(str, paramString);
/*  82 */     if (localList.get(0) != null) {
/*  83 */       return ((Integer)localList.get(0)).intValue();
/*     */     }
/*  85 */     return -1;
/*     */   }
/*     */ 
/*     */   public List<MenuFavorite> getMenuFavoriteTree(String paramString)
/*     */   {
/*  92 */     String str = "from MenuFavorite mf where mf.userId = ? order by mf.displayOrder  ";
/*  93 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public MenuFavorite getMenuFavoriteById(String paramString)
/*     */   {
/* 100 */     String str = "from MenuFavorite mf where mf.id = ? ";
/* 101 */     List localList = getHibernateTemplate().find(str, paramString);
/* 102 */     if (localList.size() > 0) {
/* 103 */       return (MenuFavorite)localList.get(0);
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public List<MenuFavorite> getFavoriteMenuFolders(String paramString)
/*     */   {
/* 111 */     String str = "from MenuFavorite mf where mf.userId = ?  and mf.menuId is null order by mf.displayOrder  ";
/*     */ 
/* 113 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public boolean isExistMenuFavoriteTree(String paramString1, String paramString2)
/*     */   {
/* 119 */     String str = "from MenuFavorite mf where mf.menuId = ?  and mf.userId = ? ";
/* 120 */     List localList = getHibernateTemplate().find(str, new Object[] { paramString1, paramString2 });
/* 121 */     if (localList.size() > 0) {
/* 122 */       return true;
/*     */     }
/* 124 */     return false;
/*     */   }
/*     */ 
/*     */   public void deleteMenuFavoriteByMenuId(String paramString1, String paramString2)
/*     */   {
/* 130 */     String str = "delete from MenuFavorite mf where mf.menuId = ?  and mf.userId = ? ";
/* 131 */     getHibernateTemplate().bulkUpdate(str, new Object[] { paramString1, paramString2 });
/*     */   }
/*     */ 
/*     */   public MenuFavorite getMenuFavoriteByMenuId(String paramString1, String paramString2)
/*     */   {
/* 138 */     String str = "from MenuFavorite mf where mf.menuId = ? and mf.userId = ?";
/* 139 */     List localList = getHibernateTemplate().find(str, new Object[] { paramString1, paramString2 });
/* 140 */     if (localList.size() > 0) {
/* 141 */       return (MenuFavorite)localList.get(0);
/*     */     }
/* 143 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.dao.impl.MenuFavoriteDAOImpl
 * JD-Core Version:    0.6.2
 */