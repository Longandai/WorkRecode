/*    */ package com.neusoft.unieap.techcomp.ria.menu.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.menu.dao.MenuDAO;
/*    */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*    */ import java.util.List;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ public class MenuDAOImpl extends BaseHibernateDAO
/*    */   implements MenuDAO
/*    */ {
/*    */   public void saveMenu(Menu paramMenu)
/*    */   {
/* 17 */     super.getHibernateTemplate().save(paramMenu);
/*    */   }
/*    */ 
/*    */   public void updateMenu(Menu paramMenu)
/*    */   {
/* 24 */     super.getHibernateTemplate().saveOrUpdate(paramMenu);
/*    */   }
/*    */ 
/*    */   public void deleteMenus(List paramList)
/*    */   {
/* 31 */     StringBuffer localStringBuffer = new StringBuffer();
/* 32 */     localStringBuffer.append("DELETE FROM Menu menu WHERE menu.id in (:ids)");
/* 33 */     Query localQuery = super.getSession().createQuery(localStringBuffer.toString());
/* 34 */     localQuery.setParameterList("ids", paramList);
/* 35 */     localQuery.executeUpdate();
/*    */   }
/*    */ 
/*    */   public List getMenusByAppId(String paramString)
/*    */   {
/* 42 */     StringBuffer localStringBuffer = new StringBuffer();
/* 43 */     localStringBuffer.append("FROM Menu menu WHERE menu.appId = ? and menu.isEnabled='T' ORDER BY order_num ASC");
/* 44 */     List localList = super.queryObjects(localStringBuffer.toString(), paramString);
/*    */ 
/* 46 */     return localList;
/*    */   }
/*    */ 
/*    */   public void deleteHelpAttachmentsByHelpId(List paramList)
/*    */   {
/* 53 */     StringBuffer localStringBuffer = new StringBuffer();
/* 54 */     localStringBuffer.append("delete from HelpAttachment h where h.helpId in (:ids)");
/* 55 */     Query localQuery = super.getSession().createQuery(localStringBuffer.toString());
/* 56 */     localQuery.setParameterList("ids", paramList);
/* 57 */     localQuery.executeUpdate();
/*    */   }
/*    */ 
/*    */   public void deleteHelpInfoByMenuId(List paramList)
/*    */   {
/* 64 */     StringBuffer localStringBuffer = new StringBuffer();
/* 65 */     localStringBuffer.append("delete from Help h where h.id in (:ids)");
/* 66 */     Query localQuery = super.getSession().createQuery(localStringBuffer.toString());
/* 67 */     localQuery.setParameterList("ids", paramList);
/* 68 */     localQuery.executeUpdate();
/*    */   }
/*    */ 
/*    */   public List getSameTierMenusByMenuId(String paramString1, String paramString2)
/*    */   {
/* 75 */     StringBuffer localStringBuffer = new StringBuffer();
/* 76 */     localStringBuffer.append("FROM Menu menu WHERE menu.parentId = ? and menu.id != ? and isEnabled='T' ORDER BY order_num ASC");
/* 77 */     String[] arrayOfString = new String[2];
/* 78 */     arrayOfString[0] = paramString1;
/* 79 */     arrayOfString[1] = paramString2;
/* 80 */     List localList = super.queryObjects(localStringBuffer.toString(), arrayOfString);
/* 81 */     return localList;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.dao.impl.MenuDAOImpl
 * JD-Core Version:    0.6.2
 */