package com.neusoft.unieap.techcomp.ria.menu.bo;

import com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite;
import java.util.List;

public abstract interface MenuFavoriteBO
{
  public abstract MenuFavorite saveMenuFavorite(String paramString1, String paramString2, String paramString3);

  public abstract void updateMenuFavorite(String paramString1, String paramString2, String paramString3)
    throws Exception;

  public abstract void deleteMenuFavorite(String paramString);

  public abstract List<MenuFavorite> getMenuFavoriteTree();

  public abstract boolean isExistMenuFavoriteTree(String paramString);

  public abstract MenuFavorite saveMenuFavoriteNode(String paramString);

  public abstract void updateDragedMenuFavoriteNode(List<MenuFavorite> paramList);

  public abstract List<MenuFavorite> getFavoriteMenuFolders();

  public abstract void addOrUpdateFavoriteMenuTree(List<MenuFavorite> paramList, String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void deleteMenuFavoriteByMenuId(String paramString);

  public abstract MenuFavorite getFavoriteMenuByMenuId(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.MenuFavoriteBO
 * JD-Core Version:    0.6.2
 */