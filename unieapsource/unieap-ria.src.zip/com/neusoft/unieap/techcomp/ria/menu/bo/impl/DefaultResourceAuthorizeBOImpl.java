/*     */ package com.neusoft.unieap.techcomp.ria.menu.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DefaultResourceAuthorizeBOImpl
/*     */   implements ResourceAuthorizeBO
/*     */ {
/*     */   private MenuBO menuBO;
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO)
/*     */   {
/*  17 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList, String paramString1, String paramString2)
/*     */   {
/*  32 */     return null;
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(List paramList, String paramString)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getAuthorityType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*  71 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList1, List paramList2, String paramString1, String paramString2, String paramString3)
/*     */   {
/*  91 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 100 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5, String paramString6)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, List paramList1, String paramString3, List paramList2, String paramString4, String paramString5)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
/*     */   {
/*     */   }
/*     */ 
/*     */   public List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveTreeResources(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/*     */   }
/*     */ 
/*     */   public List getRoleIds(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 163 */     return null;
/*     */   }
/*     */ 
/*     */   public BOContext getRoleIds(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 171 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities4Cascade(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.impl.DefaultResourceAuthorizeBOImpl
 * JD-Core Version:    0.6.2
 */