/*     */ package com.neusoft.unieap.techcomp.ria.menu.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.bo.ExtInfoBO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class MenuNavigatorProcessor extends BaseProcessor
/*     */ {
/*     */   private static final long serialVersionUID = 7945566957998418477L;
/*     */   private MenuBO menuBO;
/*     */   private MenuAuthBO menuAuthBO;
/*     */   private ExtInfoBO extInfoBO;
/*     */ 
/*     */   public void setExtInfoBO(ExtInfoBO paramExtInfoBO)
/*     */   {
/*  31 */     this.extInfoBO = paramExtInfoBO;
/*     */   }
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO) {
/*  35 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public void setMenuAuthBO(MenuAuthBO paramMenuAuthBO) {
/*  39 */     this.menuAuthBO = paramMenuAuthBO;
/*     */   }
/*     */ 
/*     */   public void getChildMenusById()
/*     */     throws Exception
/*     */   {
/*  47 */     ViewContext localViewContext = generateContext();
/*  48 */     String str1 = localViewContext.getString("parentId");
/*  49 */     String str2 = localViewContext.getString("appId");
/*  50 */     List localList1 = this.menuBO.getChildMenusById(str2, str1);
/*     */ 
/*  53 */     List localList2 = this.menuAuthBO.getAllowedMenus(localList1);
/*     */ 
/*  55 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  56 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/*  57 */     DataStore localDataStore = localDataCenterFactory.createDataStore(str1);
/*  58 */     toRows(str2, localList2, localDataStore.getRowSet(), str1);
/*     */ 
/*  60 */     localDataCenter.addDataStore(localDataStore);
/*  61 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getAllDescendantMenusById()
/*     */     throws Exception
/*     */   {
/*  69 */     ViewContext localViewContext = generateContext();
/*  70 */     String str1 = localViewContext.getString("parentId");
/*  71 */     String str2 = localViewContext.getString("appId");
/*  72 */     List localList1 = this.menuBO.getAllDescendantMenusById(str2, str1);
/*     */ 
/*  74 */     List localList2 = this.menuAuthBO.getAllowedMenus(localList1);
/*     */ 
/*  76 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  77 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/*  78 */     DataStore localDataStore = localDataCenterFactory.createDataStore(str1);
/*  79 */     toRows(str2, localList2, localDataStore.getRowSet(), str1);
/*     */ 
/*  81 */     localDataCenter.addDataStore(localDataStore);
/*  82 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getRootMenusByAppId()
/*     */     throws Exception
/*     */   {
/*  90 */     ViewContext localViewContext = super.generateContext();
/*  91 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/*  92 */     String str = localViewContext.getString("appId");
/*     */ 
/*  94 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  95 */     DataStore localDataStore = localDataCenterFactory.createDataStore("appTree");
/*     */ 
/*  97 */     List localList1 = this.menuBO.getRootMenusByAppId(str);
/*     */ 
/*  99 */     List localList2 = this.menuAuthBO.getAllowedMenus(localList1);
/*     */ 
/* 101 */     for (int i = 0; i < localList2.size(); i++) {
/* 102 */       Menu localMenu = (Menu)localList2.get(i);
/* 103 */       Row localRow = localDataCenterFactory.createRow();
/* 104 */       localRow.setString("id", localMenu.getId());
/*     */ 
/* 107 */       localRow.setString("label", getI18nTitle(str, localMenu));
/*     */ 
/* 109 */       localRow.setString("name", localMenu.getName());
/* 110 */       localRow.setBoolean("isDefault", localMenu.getIsDefault());
/* 111 */       localRow.setString("rootId", localMenu.getId());
/* 112 */       localRow.setString("image", localMenu.getImage());
/*     */ 
/* 115 */       toExtRows(str, localMenu.getId(), localRow);
/*     */ 
/* 117 */       localDataStore.getRowSet().addRow(localRow);
/*     */     }
/* 119 */     localDataCenter.addDataStore(localDataStore);
/* 120 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private String getI18nTitle(String paramString, Menu paramMenu)
/*     */   {
/* 125 */     if (!GlobalService.isEnabled()) {
/* 126 */       return paramMenu.getTitle();
/*     */     }
/* 128 */     Map localMap = this.menuBO.getExtInfo(paramString, paramMenu.getId());
/* 129 */     if (localMap == null) {
/* 130 */       return paramMenu.getTitle();
/*     */     }
/*     */ 
/* 133 */     Locale localLocale1 = GlobalService.getDefaultI18nContext().getLocale();
/* 134 */     Locale localLocale2 = GlobalService.getUserI18nContext().getLocale();
/*     */     String str1;
/* 135 */     if ((localLocale2 == null) || (localLocale2.equals(localLocale1))) {
/* 136 */       str1 = paramMenu.getTitle();
/*     */     } else {
/* 138 */       String str2 = 
/* 139 */         localLocale2.getLanguage() + "_" + localLocale2.getCountry();
/* 140 */       str1 = (String)localMap.get("title_" + str2);
/* 141 */       if (str1 == null) {
/* 142 */         str1 = paramMenu.getTitle();
/*     */       }
/*     */     }
/* 145 */     return str1;
/*     */   }
/*     */ 
/*     */   public void getAllowedMenusByTitle()
/*     */     throws Exception
/*     */   {
/* 154 */     ViewContext localViewContext = generateContext();
/* 155 */     String str1 = localViewContext.getString("title");
/* 156 */     String str2 = localViewContext.getString("appId");
/*     */ 
/* 158 */     List localList = this.menuAuthBO.getAllowedMenus(str2, str1);
/*     */ 
/* 160 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 161 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 162 */     DataStore localDataStore = localDataCenterFactory.createDataStore(str1);
/* 163 */     toRows(str2, localList, localDataStore.getRowSet(), null);
/*     */ 
/* 165 */     localDataCenter.addDataStore(localDataStore);
/* 166 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getAllMenusByAppId()
/*     */     throws Exception
/*     */   {
/* 174 */     ViewContext localViewContext = super.generateContext();
/* 175 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/* 176 */     String str = localViewContext.getString("appId");
/*     */ 
/* 178 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 179 */     DataStore localDataStore1 = localDataCenterFactory.createDataStore("appTree");
/*     */ 
/* 181 */     List localList1 = this.menuBO.getRootMenusByAppId(str);
/*     */ 
/* 183 */     List localList2 = this.menuAuthBO.getAllowedMenus(localList1);
/*     */ 
/* 185 */     for (int i = 0; i < localList2.size(); i++) {
/* 186 */       Menu localMenu = (Menu)localList2.get(i);
/* 187 */       Row localRow = localDataCenterFactory.createRow();
/* 188 */       localRow.setString("id", localMenu.getId());
/* 189 */       localRow.setString("label", localMenu.getTitle());
/* 190 */       localRow.setString("name", localMenu.getName());
/* 191 */       localRow.setBoolean("isDefault", localMenu.getIsDefault());
/* 192 */       localRow.setString("rootId", localMenu.getId());
/* 193 */       localRow.setString("image", localMenu.getImage());
/*     */ 
/* 195 */       toExtRows(str, localMenu.getId(), localRow);
/* 196 */       localDataStore1.getRowSet().addRow(localRow);
/*     */ 
/* 198 */       List localList3 = this.menuBO.getAllDescendantMenusById(str, localMenu.getId());
/* 199 */       List localList4 = this.menuAuthBO.getAllowedMenus(localList3);
/* 200 */       DataStore localDataStore2 = localDataCenterFactory.createDataStore(localMenu.getId());
/* 201 */       toRows(str, localList4, localDataStore2.getRowSet(), localMenu.getId());
/* 202 */       localDataCenter.addDataStore(localDataStore2);
/*     */     }
/* 204 */     localDataCenter.addDataStore(localDataStore1);
/* 205 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private void toRows(String paramString1, List paramList, RowSet paramRowSet, String paramString2)
/*     */   {
/* 214 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*     */ 
/* 217 */     if (!paramList.isEmpty())
/* 218 */       for (int i = 0; i < paramList.size(); i++) {
/* 219 */         Menu localMenu = (Menu)paramList.get(i);
/* 220 */         Row localRow = localDataCenterFactory.createRow();
/* 221 */         localRow.setString("id", localMenu.getId());
/*     */ 
/* 224 */         localRow.setString("label", getI18nTitle(paramString1, localMenu));
/*     */ 
/* 226 */         localRow.setBoolean("isDefault", localMenu.getIsDefault());
/* 227 */         localRow.setString("rootId", paramString2);
/*     */ 
/* 229 */         localRow.setString("parentId", localMenu.getParentId());
/* 230 */         localRow.setBoolean("leaf", localMenu.getLeaf());
/*     */ 
/* 232 */         localRow.setString("location", localMenu.getUrl());
/*     */ 
/* 235 */         localRow.setString("title", getI18nTitle(paramString1, localMenu));
/*     */ 
/* 237 */         localRow.setString("image", localMenu.getImage());
/* 238 */         localRow.setString("name", localMenu.getName());
/*     */ 
/* 241 */         toExtRows(paramString1, localMenu.getId(), localRow);
/*     */ 
/* 243 */         paramRowSet.addRow(localRow);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void toExtRows(String paramString1, String paramString2, Row paramRow)
/*     */   {
/* 255 */     List localList = this.extInfoBO.getExtAttrDefinesByObjType("menu");
/*     */ 
/* 257 */     if ((localList != null) && (localList.size() > 0)) {
/* 258 */       Map localMap = this.menuBO.getExtInfo(paramString1, paramString2);
/*     */ 
/* 261 */       String str2 = null;
/*     */ 
/* 263 */       for (int i = 0; i < localList.size(); i++) {
/* 264 */         ExtAttrDefine localExtAttrDefine = (ExtAttrDefine)localList.get(i);
/* 265 */         String str1 = localExtAttrDefine.getAttrName();
/* 266 */         if (localMap != null)
/* 267 */           str2 = (String)localMap.get(str1);
/* 268 */         paramRow.setString(str1, str2);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.action.MenuNavigatorProcessor
 * JD-Core Version:    0.6.2
 */