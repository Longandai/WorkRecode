package com.neusoft.unieap.techcomp.ria.menu.exception;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class MenuExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "003";
  private static final String _P = "EAPBIZ003";
  public static final String MENU_NOT_EXIST = "EAPBIZ003001";
  public static final String MENU_INITIAL_FAILURE = "EAPBIZ003002";
  public static final String MENU_REPETED_SAVED = "EAPBIZ003003";
  public static final String MENU_REPETED_DUPLICATED = "EAPBIZ003004";
  public static final String MENU_VIEW_FAILURE = "EAPBIZ003501";
  public static final String MENU_ADD_FAILURE = "EAPBIZ003502";
  public static final String MENU_UPDATE_FAILURE = "EAPBIZ003503";
  public static final String MENU_DELETE_FAILURE = "EAPBIZ003504";
  public static final String MENU_MOVE_FAILURE = "EAPBIZ003504";
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.exception.MenuExceptionCode
 * JD-Core Version:    0.6.2
 */