/*     */ package com.neusoft.unieap.techcomp.ria.menu.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ @ModelFile("menuFavorite.entity")
/*     */ public class MenuFavorite
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String userId;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String image;
/*     */   private String url;
/*     */   private String menuId;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String title;
/*     */   private String parentId;
/*     */   private Integer displayOrder;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  73 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  77 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setUserId(String paramString) {
/*  81 */     this.userId = paramString;
/*     */   }
/*     */ 
/*     */   public String getUserId() {
/*  85 */     return this.userId;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/*  89 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/*  93 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/*  97 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/* 101 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setImage(String paramString) {
/* 105 */     this.image = paramString;
/*     */   }
/*     */ 
/*     */   public String getImage() {
/* 109 */     return this.image;
/*     */   }
/*     */ 
/*     */   public void setUrl(String paramString) {
/* 113 */     this.url = paramString;
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 117 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setMenuId(String paramString) {
/* 121 */     this.menuId = paramString;
/*     */   }
/*     */ 
/*     */   public String getMenuId() {
/* 125 */     return this.menuId;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 129 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/* 133 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/* 137 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/* 141 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/* 145 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/* 149 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setParentId(String paramString) {
/* 153 */     this.parentId = paramString;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/* 157 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setDisplayOrder(Integer paramInteger) {
/* 161 */     this.displayOrder = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getDisplayOrder() {
/* 165 */     return this.displayOrder;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite
 * JD-Core Version:    0.6.2
 */