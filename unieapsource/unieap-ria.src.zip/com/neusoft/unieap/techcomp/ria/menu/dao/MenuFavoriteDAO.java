package com.neusoft.unieap.techcomp.ria.menu.dao;

import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
import com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite;
import java.util.List;

public abstract interface MenuFavoriteDAO
{
  public abstract MenuFavorite saveMenuFavorite(MenuFavorite paramMenuFavorite);

  public abstract Menu getMenuById(String paramString);

  public abstract MenuFavorite updateMenuFavorite(MenuFavorite paramMenuFavorite);

  public abstract void deleteMenuFavorite(String[] paramArrayOfString);

  public abstract int getMaxMenuFavoriteDisplayOrder(String paramString);

  public abstract List<MenuFavorite> getMenuFavoriteTree(String paramString);

  public abstract MenuFavorite getMenuFavoriteByMenuId(String paramString1, String paramString2);

  public abstract List<MenuFavorite> getFavoriteMenuFolders(String paramString);

  public abstract boolean isExistMenuFavoriteTree(String paramString1, String paramString2);

  public abstract void deleteMenuFavoriteByMenuId(String paramString1, String paramString2);

  public abstract MenuFavorite getMenuFavoriteById(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.dao.MenuFavoriteDAO
 * JD-Core Version:    0.6.2
 */