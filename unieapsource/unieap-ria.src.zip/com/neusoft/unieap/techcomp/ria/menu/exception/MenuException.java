/*    */ package com.neusoft.unieap.techcomp.ria.menu.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class MenuException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = -1675748353212410327L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */ 
/*    */   public MenuException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject) {
/* 14 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public MenuException(String paramString, Object[] paramArrayOfObject) {
/* 18 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public MenuException(String paramString) {
/* 22 */     super(paramString, null);
/*    */   }
/*    */ 
/*    */   public MenuException(String paramString, Throwable paramThrowable) {
/* 26 */     super(paramString, paramThrowable, null);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.exception.MenuException
 * JD-Core Version:    0.6.2
 */