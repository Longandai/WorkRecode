/*     */ package com.neusoft.unieap.techcomp.ria.menu.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.model.Application;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.Role;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class MenuAuthBOImpl
/*     */   implements MenuAuthBO
/*     */ {
/*     */   private ResourceAuthorizeBO resourceAuthorizeBO;
/*     */   private EAPCacheManager eapCacheManager;
/*     */   private MenuBO menuBO;
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager)
/*     */   {
/*  38 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeBO(ResourceAuthorizeBO paramResourceAuthorizeBO) {
/*  42 */     this.resourceAuthorizeBO = paramResourceAuthorizeBO;
/*     */   }
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO) {
/*  46 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public List getAllowedMenus(List paramList) {
/*  50 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  51 */     String str = localUser.getAccount();
/*  52 */     Object localObject = new ArrayList();
/*     */     try {
/*  54 */       localObject = (List)this.eapCacheManager.get(
/*  55 */         str, "menuAuthority");
/*  56 */       if (localObject == null) {
/*  57 */         List localList = getCurrentRoleIds();
/*  58 */         localObject = this.resourceAuthorizeBO
/*  59 */           .getResourceIds(localList, 
/*  60 */           "menu", 
/*  61 */           "available");
/*  62 */         this.eapCacheManager.put(str, 
/*  63 */           localObject, "menuAuthority");
/*     */       }
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  68 */       localException.printStackTrace();
/*     */     }
/*  70 */     HashSet localHashSet = new HashSet();
/*  71 */     if (localObject != null) {
/*  72 */       for (int i = 0; i < ((List)localObject).size(); i++) {
/*  73 */         localHashSet
/*  74 */           .add(((List)localObject).get(i));
/*     */       }
/*     */     }
/*  77 */     ArrayList localArrayList = new ArrayList();
/*  78 */     for (int j = 0; j < paramList.size(); j++) {
/*  79 */       if (localHashSet.contains(
/*  80 */         ((Menu)paramList
/*  80 */         .get(j)).getId())) {
/*  81 */         localArrayList.add(paramList.get(j));
/*     */       }
/*     */     }
/*     */ 
/*  85 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private List getCurrentRoleIds()
/*     */   {
/*  92 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  93 */     return localUser.getRoleIds();
/*     */   }
/*     */ 
/*     */   public List getAuthorityMenus(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/* 101 */     List localList1 = this.resourceAuthorizeBO.getResourceIds(paramString2, paramString3, 
/* 102 */       "menu", paramString4, 
/* 103 */       paramString5);
/* 104 */     List localList2 = this.menuBO.getMenusByAppId(paramString1);
/* 105 */     ArrayList localArrayList = new ArrayList();
/* 106 */     if (localList2 != null) {
/* 107 */       for (Iterator localIterator = localList2.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 108 */         if (localList1.contains(((Menu)localObject).getId())) {
/* 109 */           localArrayList.add(localObject);
/*     */         }
/*     */       }
/*     */     }
/* 113 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getAuthorityApps(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 121 */     List localList1 = this.resourceAuthorizeBO.getResourceIds(paramString1, paramString2, 
/* 122 */       "application", paramString3, 
/* 123 */       paramString4);
/* 124 */     List localList2 = this.menuBO.getAvailableApplications();
/* 125 */     ArrayList localArrayList = new ArrayList();
/* 126 */     if (localList2 != null) {
/* 127 */       for (Iterator localIterator = localList2.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 128 */         if (localList1.contains(((Application)localObject).getId())) {
/* 129 */           localArrayList.add(localObject);
/*     */         }
/*     */       }
/*     */     }
/* 133 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void saveTreeResources(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
/*     */   {
/* 142 */     String str = "application";
/* 143 */     this.resourceAuthorizeBO.saveTreeResources(paramString1, paramString2, paramString5, 
/* 144 */       paramString6, str, paramString7, paramString8);
/* 145 */     str = "menu";
/* 146 */     this.resourceAuthorizeBO.saveTreeResources(paramString3, paramString4, 
/* 147 */       paramString5, paramString6, str, paramString7, 
/* 148 */       paramString8);
/*     */   }
/*     */ 
/*     */   public List getAuthorityApps(String paramString)
/*     */   {
/* 157 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 158 */     List localList = localUser.getRoles();
/* 159 */     Role localRole = null;
/* 160 */     String str = null;
/* 161 */     if ((localList != null) && (localList.size() > 0)) {
/* 162 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 163 */         localRole = (Role)localObject;
/* 164 */         str = localRole.getType();
/* 165 */         if (("secAdminRole".equals(str)) || 
/* 167 */           ("orgAdminRole"
/* 167 */           .equals(str))) {
/* 168 */           return getAuthorityApps(localRole.getId(), str, 
/* 169 */             paramString, null);
/*     */         }
/*     */ 
/* 172 */         if ("superAdminRole"
/* 172 */           .equals(str)) {
/* 173 */           return this.menuBO.getAvailableApplications();
/*     */         }
/*     */       }
/*     */     }
/* 177 */     return null;
/*     */   }
/*     */ 
/*     */   public List getAuthorityMenus(String paramString1, String paramString2)
/*     */   {
/* 185 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 186 */     List localList = localUser.getRoles();
/* 187 */     Role localRole = null;
/* 188 */     String str = null;
/* 189 */     if ((localList != null) && (localList.size() > 0)) {
/* 190 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 191 */         localRole = (Role)localObject;
/* 192 */         str = localRole.getType();
/* 193 */         if (("secAdminRole".equals(str)) || 
/* 195 */           ("orgAdminRole"
/* 195 */           .equals(str))) {
/* 196 */           return getAuthorityMenus(paramString1, localRole.getId(), str, 
/* 197 */             paramString2, null);
/*     */         }
/* 199 */         if ("superAdminRole"
/* 199 */           .equals(str)) {
/* 200 */           return this.menuBO.getMenusByAppId(paramString1);
/*     */         }
/*     */       }
/*     */     }
/* 204 */     return null;
/*     */   }
/*     */ 
/*     */   public List getAllowedMenus(String paramString1, String paramString2)
/*     */   {
/* 211 */     List localList1 = this.menuBO.getMenusByAppId(paramString1);
/* 212 */     List localList2 = getAllowedMenus(localList1);
/* 213 */     ArrayList localArrayList = new ArrayList();
/* 214 */     Menu localMenu = null;
/* 215 */     for (int i = 0; i < localList2.size(); i++) {
/* 216 */       localMenu = (Menu)localList2.get(i);
/* 217 */       if ((localMenu.getTitle().indexOf(paramString2) > -1) && 
/* 218 */         (localMenu.getUrl() != null))
/* 219 */         localArrayList.add(localMenu);
/*     */     }
/* 221 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getAvaliableMenus(String paramString)
/*     */   {
/* 229 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 230 */     List localList1 = localUser.getRoles();
/* 231 */     if ((localList1 != null) && (localList1.size() > 0)) {
/* 232 */       int i = localList1.size();
/* 233 */       ArrayList localArrayList1 = new ArrayList(i);
/* 234 */       for (int j = 0; j < i; j++) {
/* 235 */         localArrayList1.add(((Role)localList1.get(j)).getId());
/*     */       }
/* 237 */       List localList2 = this.resourceAuthorizeBO.getResourceIds(localArrayList1, "menu", "available");
/* 238 */       List localList3 = this.menuBO.getMenusByAppId(paramString);
/* 239 */       ArrayList localArrayList2 = new ArrayList();
/* 240 */       if (localList3 != null) {
/* 241 */         for (Iterator localIterator = localList3.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 242 */           if (localList2.contains(((Menu)localObject).getId())) {
/* 243 */             localArrayList2.add(localObject);
/*     */           }
/*     */         }
/*     */       }
/* 247 */       return localArrayList2;
/*     */     }
/* 249 */     return null;
/*     */   }
/*     */ 
/*     */   public List getAvaliableApps()
/*     */   {
/* 257 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 258 */     List localList1 = localUser.getRoles();
/* 259 */     if ((localList1 != null) && (localList1.size() > 0)) {
/* 260 */       int i = localList1.size();
/* 261 */       ArrayList localArrayList1 = new ArrayList(i);
/* 262 */       for (int j = 0; j < i; j++) {
/* 263 */         localArrayList1.add(((Role)localList1.get(j)).getId());
/*     */       }
/* 265 */       List localList2 = this.resourceAuthorizeBO.getResourceIds(localArrayList1, "application", "available");
/* 266 */       List localList3 = this.menuBO.getAvailableApplications();
/* 267 */       ArrayList localArrayList2 = new ArrayList();
/* 268 */       if (localList3 != null) {
/* 269 */         for (Iterator localIterator = localList3.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 270 */           if (localList2.contains(((Application)localObject).getId())) {
/* 271 */             localArrayList2.add(localObject);
/*     */           }
/*     */         }
/*     */       }
/* 275 */       return localArrayList2;
/*     */     }
/* 277 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.impl.MenuAuthBOImpl
 * JD-Core Version:    0.6.2
 */