/*     */ package com.neusoft.unieap.techcomp.ria.menu.action;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.base.model.Application;
/*     */ import com.neusoft.unieap.core.base.model.SCRepository;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.util.Assert;
/*     */ import com.neusoft.unieap.core.util.UrlBase64Util;
/*     */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenter;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataCenterFactory;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.DataStore;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.Row;
/*     */ import com.neusoft.unieap.techcomp.ria.ds.RowSet;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.bo.ExtInfoBO;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.entity.ExtAttrDefine;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterIOManager;
/*     */ import com.neusoft.unieap.techcomp.ria.io.DataCenterWriter;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuFavoriteBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.exception.MenuException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ 
/*     */ public class MenuProcessor extends BaseProcessor
/*     */ {
/*     */   private static final long serialVersionUID = 7945566957998418477L;
/*  36 */   private MenuBO menuBO = null;
/*     */   private ExtInfoBO extInfoBO;
/*     */   private MenuFavoriteBO menuFavoriteBO;
/*     */ 
/*     */   public void setMenuFavoriteBO(MenuFavoriteBO paramMenuFavoriteBO)
/*     */   {
/*  40 */     this.menuFavoriteBO = paramMenuFavoriteBO;
/*     */   }
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO) {
/*  44 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public void setExtInfoBO(ExtInfoBO paramExtInfoBO) {
/*  48 */     this.extInfoBO = paramExtInfoBO;
/*     */   }
/*     */ 
/*     */   public void saveMenu()
/*     */     throws Exception
/*     */   {
/*  57 */     String str1 = getRequest().getParameter("appId");
/*  58 */     String str2 = getRequest().getParameter("parentId");
/*  59 */     Menu localMenu = this.menuBO.saveMenu(str1, str2, null);
/*     */ 
/*  85 */     String str3 = "success:" + localMenu.getId() + ":" + localMenu.getTitle() + 
/*  86 */       ":" + localMenu.getName();
/*  87 */     DataCenterWriter localDataCenterWriter = DataCenterIOManager.createWriter(
/*  88 */       getResponse().getOutputStream());
/*  89 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/*  90 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/*  91 */     localDataCenter.setDetail(str3);
/*  92 */     localDataCenterWriter.write(localDataCenter);
/*  93 */     localDataCenterWriter.close();
/*     */   }
/*     */ 
/*     */   public void updateMenu()
/*     */     throws Exception
/*     */   {
/* 102 */     ViewContext localViewContext = generateContext();
/* 103 */     String str1 = localViewContext.getString("appId");
/* 104 */     String str2 = localViewContext.getString("id");
/* 105 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/*     */ 
/* 107 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 108 */     DataStore localDataStore = localDataCenterFactory.createDataStore("MenuInfoDS");
/*     */ 
/* 110 */     List localList = localDataCenter.getDataStore(str1).getRowDatas();
/* 111 */     if (localList.size() <= 0)
/* 112 */       throw new MenuException("EAPBIZ003503");
/* 113 */     Object localObject1 = null;
/*     */     Object localObject2;
/* 114 */     for (int i = 0; i < localList.size(); i++) {
/* 115 */       localObject2 = (Map)localList.get(i);
/* 116 */       if (((String)((Map)localObject2).get("id")).equals(str2)) {
/* 117 */         localObject1 = localObject2;
/* 118 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 122 */     if (localObject1 != null) {
/* 123 */       String str3 = localObject1.get("id").toString();
/* 124 */       localObject2 = localObject1.get("name").toString();
/* 125 */       String str4 = localObject1.get("title").toString();
/* 126 */       String str5 = localObject1.get("location") == null ? "" : localObject1
/* 127 */         .get("location").toString();
/* 128 */       String str6 = localObject1.get("image") == null ? "" : localObject1
/* 129 */         .get("image").toString();
/* 130 */       String str7 = localObject1.get("isDefault") == null ? "" : localObject1.get(
/* 131 */         "isDefault").toString();
/* 132 */       String str8 = localObject1.get("description") == null ? "" : localObject1.get(
/* 133 */         "description").toString();
/* 134 */       if (!isExistMenu(str1, str3)) {
/* 135 */         localObject3 = new String[] { str3 };
/* 136 */         throw new MenuException("EAPBIZ003503", 
/* 137 */           (Object[])localObject3);
/*     */       }
/*     */ 
/* 141 */       Object localObject3 = this.extInfoBO.getExtAttrDefinesByObjType("menu");
/* 142 */       HashMap localHashMap = null;
/*     */       Object localObject5;
/* 143 */       if ((localObject3 != null) && (((List)localObject3).size() > 0))
/*     */       {
/* 146 */         localHashMap = new HashMap();
/* 147 */         for (int j = 0; j < ((List)localObject3).size(); j++) {
/* 148 */           localObject4 = (ExtAttrDefine)((List)localObject3).get(j);
/* 149 */           localObject5 = ((ExtAttrDefine)localObject4).getAttrName();
/* 150 */           localHashMap.put(localObject5, localObject1.get(localObject5));
/*     */         }
/*     */       }
/*     */ 
/* 154 */       Object localObject4 = localDataCenterFactory.createDataCenter();
/* 155 */       if (this.menuBO.isNameDuplicated(str1, str3, (String)localObject2)) {
/* 156 */         ((DataCenter)localObject4).setDetail("duplicate");
/*     */       }
/*     */       else {
/* 159 */         localObject5 = this.menuBO.getMenuById(str1, str3);
/* 160 */         ((Menu)localObject5).setName((String)localObject2);
/* 161 */         ((Menu)localObject5).setTitle(str4);
/* 162 */         ((Menu)localObject5).setUrl(str5);
/* 163 */         ((Menu)localObject5).setImage(str6);
/* 164 */         boolean bool1 = Boolean.valueOf(str7).booleanValue();
/* 165 */         ((Menu)localObject5).setIsDefault(Boolean.valueOf(bool1));
/* 166 */         ((Menu)localObject5).setDescription(str8);
/* 167 */         this.menuBO.updateMenu((Menu)localObject5, localHashMap);
/*     */ 
/* 169 */         if (bool1) {
/* 170 */           localObject6 = localObject1.get("parentId").toString();
/*     */ 
/* 172 */           for (int k = 0; k < localList.size(); k++) {
/* 173 */             Map localMap = (Map)localList.get(k);
/* 174 */             if ((((String)localMap.get("parentId")).equals(localObject6)) && 
/* 175 */               (!localMap.equals(localObject1))) {
/* 176 */               String str9 = localObject1.get("isDefault") == null ? "" : 
/* 177 */                 localObject1.get("isDefault").toString();
/* 178 */               boolean bool2 = Boolean.valueOf(
/* 179 */                 str9).booleanValue();
/* 180 */               if (bool2) {
/* 181 */                 Menu localMenu = this.menuBO.getMenuById(str1, 
/* 182 */                   localMap.get("id").toString());
/* 183 */                 localMenu.setIsDefault(Boolean.valueOf(false));
/* 184 */                 this.menuBO.updateMenu(localMenu);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 190 */         Object localObject6 = localDataCenterFactory.createRow();
/* 191 */         ((Row)localObject6).setString("id", str1 + ":" + str3);
/* 192 */         ((Row)localObject6).setString("title", str4);
/* 193 */         ((Row)localObject6).setString("location", str5);
/* 194 */         ((Row)localObject6).setBoolean("isDefault", 
/* 195 */           Boolean.valueOf(Boolean.valueOf(str7)
/* 195 */           .booleanValue()));
/* 196 */         ((Row)localObject6).setString("description", str8);
/* 197 */         ((Row)localObject6).setString("appId", str1);
/* 198 */         ((Row)localObject6).setString("name", (String)localObject2);
/* 199 */         ((Row)localObject6).setString("image", str6);
/*     */ 
/* 201 */         localDataStore.getRowSet().addRow((Row)localObject6);
/* 202 */         ((DataCenter)localObject4).setDetail("success");
/* 203 */         ((DataCenter)localObject4).addDataStore(localDataStore);
/*     */       }
/* 205 */       write((DataCenter)localObject4);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteMenus()
/*     */     throws Exception
/*     */   {
/* 215 */     ViewContext localViewContext = generateContext();
/* 216 */     String str1 = localViewContext.getString("appId");
/* 217 */     String str2 = localViewContext.getString("id");
/* 218 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 219 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 220 */     ArrayList localArrayList = new ArrayList();
/* 221 */     localArrayList.add(str2);
/* 222 */     this.menuBO.deleteMenus(str1, localArrayList);
/* 223 */     DataCenterWriter localDataCenterWriter = 
/* 224 */       DataCenterIOManager.createWriter(getResponse().getOutputStream());
/* 225 */     localDataCenter.setDetail("success");
/* 226 */     localDataCenterWriter.write(localDataCenter);
/* 227 */     localDataCenterWriter.close();
/*     */   }
/*     */ 
/*     */   public void moveMenu()
/*     */     throws Exception
/*     */   {
/* 236 */     String str1 = getRequest().getParameter("appId");
/*     */ 
/* 238 */     String str2 = getRequest().getParameter("targetId");
/* 239 */     String str3 = getRequest().getParameter("sourceId");
/* 240 */     this.menuBO.moveMenu(str1, str3, str2);
/* 241 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 242 */     DataCenter localDataCenter = localDataCenterFactory.createDataCenter();
/* 243 */     localDataCenter.setDetail("success");
/* 244 */     DataCenterWriter localDataCenterWriter = DataCenterIOManager.createWriter(
/* 245 */       getResponse().getOutputStream());
/* 246 */     localDataCenterWriter.write(localDataCenter);
/* 247 */     localDataCenterWriter.close();
/*     */   }
/*     */ 
/*     */   public void getMenuTree()
/*     */     throws Exception
/*     */   {
/* 256 */     DataCenter localDataCenter = super.generateContext().getDataCenter();
/* 257 */     Object localObject1 = localDataCenter.getParameter("nodeType");
/* 258 */     String str1 = null;
/* 259 */     if (localObject1 != null)
/* 260 */       str1 = localObject1.toString();
/* 261 */     Assert.notNull(str1);
/* 262 */     String str2 = null;
/* 263 */     Object localObject2 = localDataCenter.getParameter("currentId");
/* 264 */     if (localObject2 != null)
/* 265 */       str2 = localObject2.toString();
/* 266 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 267 */     DataStore localDataStore = null;
/* 268 */     if ("root".equals(str1)) {
/* 269 */       localDataStore = localDataCenterFactory.createDataStore("appStore");
/* 270 */       getAppNodes(localDataStore, localDataCenterFactory);
/* 271 */     } else if ("application".equals(str1)) {
/* 272 */       localDataStore = localDataCenterFactory.createDataStore(str2);
/* 273 */       getMenuTreeByApp(str2, localDataStore, localDataCenterFactory);
/*     */     }
/* 275 */     localDataCenter.addDataStore(localDataStore);
/* 276 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void isExistExtInfo() throws Exception {
/* 280 */     DataCenter localDataCenter = super.generateContext().getDataCenter();
/* 281 */     boolean bool = this.extInfoBO.isExistExtInfo("menu");
/* 282 */     localDataCenter.addParameter("isExistExtInfo", Boolean.valueOf(bool));
/* 283 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   public void getExtInfoHTML() throws Exception {
/* 287 */     DataCenter localDataCenter = super.generateContext().getDataCenter();
/* 288 */     BOContext localBOContext = this.extInfoBO.getExtInfoHTML("menu");
/* 289 */     String str = (String)localBOContext.get("extInfoHTML");
/* 290 */     localDataCenter.addParameter("extInfoHTML", str);
/* 291 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private void getAppNodes(DataStore paramDataStore, DataCenterFactory paramDataCenterFactory)
/*     */   {
/* 301 */     List localList = SCRepository.getAvailableApplications();
/* 302 */     for (int i = 0; i < localList.size(); i++) {
/* 303 */       Application localApplication = (Application)localList.get(i);
/* 304 */       Row localRow = paramDataCenterFactory.createRow();
/* 305 */       localRow.setString("id", localApplication.getId());
/* 306 */       localRow.setString("label", localApplication.getTitle());
/* 307 */       localRow.setString("parentId", null);
/* 308 */       localRow.setString("nodeType", "application");
/* 309 */       localRow.setBoolean("leaf", Boolean.valueOf(false));
/* 310 */       localRow.setBoolean("hasExpand", Boolean.valueOf(false));
/* 311 */       localRow.setString("appId", localApplication.getId());
/*     */ 
/* 313 */       paramDataStore.getRowSet().addRow(localRow);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void getMenuTreeByApp(String paramString, DataStore paramDataStore, DataCenterFactory paramDataCenterFactory)
/*     */     throws Exception
/*     */   {
/* 326 */     List localList = this.menuBO.getMenusByAppId(paramString);
/* 327 */     for (int i = 0; i < localList.size(); i++) {
/* 328 */       Menu localMenu = (Menu)localList.get(i);
/* 329 */       paramDataStore.getRowSet().addRow(getMenuRow(paramDataCenterFactory, localMenu, paramString));
/*     */     }
/*     */   }
/*     */ 
/*     */   private Row getMenuRow(DataCenterFactory paramDataCenterFactory, Menu paramMenu, String paramString) throws Exception {
/* 334 */     Row localRow = paramDataCenterFactory.createRow();
/* 335 */     localRow.setString("id", paramMenu.getId());
/* 336 */     localRow.setString("label", paramMenu.getTitle());
/* 337 */     String str1 = paramMenu.getParentId();
/* 338 */     if (str1 != null)
/* 339 */       localRow.setString("parentId", str1);
/*     */     else
/* 341 */       localRow.setString("parentId", paramString);
/* 342 */     localRow.setBoolean("leaf", paramMenu.getLeaf());
/* 343 */     localRow.setBoolean("hasExpand", paramMenu.getLeaf());
/* 344 */     localRow.setString("nodeType", "menu");
/* 345 */     localRow.setString("title", paramMenu.getTitle());
/* 346 */     if (CoreVariability.isUrlPasswordEncrypt())
/* 347 */       localRow.setString("location", decodeURL(paramMenu.getUrl()));
/*     */     else
/* 349 */       localRow.setString("location", paramMenu.getUrl());
/* 350 */     localRow.setBoolean("isDefault", paramMenu.getIsDefault());
/* 351 */     localRow.setString("description", paramMenu.getDescription());
/* 352 */     localRow.setString("appId", paramString);
/* 353 */     localRow.setString("name", paramMenu.getName());
/* 354 */     localRow.setString("image", paramMenu.getImage());
/*     */ 
/* 358 */     List localList = this.extInfoBO.getExtAttrDefinesByObjType("menu");
/* 359 */     Map localMap = null;
/* 360 */     if ((localList != null) && (localList.size() > 0)) {
/* 361 */       localMap = this.menuBO.getExtInfo(paramString, paramMenu.getId());
/*     */ 
/* 364 */       for (int i = 0; i < localList.size(); i++) {
/* 365 */         ExtAttrDefine localExtAttrDefine = (ExtAttrDefine)localList.get(i);
/* 366 */         String str2 = localExtAttrDefine.getAttrName();
/*     */         String str3;
/* 367 */         if (localMap != null)
/* 368 */           str3 = (String)localMap.get(str2);
/*     */         else
/* 370 */           str3 = null;
/* 371 */         localRow.setString(str2, str3);
/*     */       }
/*     */     }
/*     */ 
/* 375 */     return localRow;
/*     */   }
/*     */ 
/*     */   private boolean isExistMenu(String paramString1, String paramString2) {
/* 379 */     boolean bool = false;
/* 380 */     if (!"".equalsIgnoreCase(paramString2)) {
/* 381 */       Menu localMenu = this.menuBO.getMenuById(paramString1, paramString2);
/* 382 */       if (localMenu != null) {
/* 383 */         bool = true;
/*     */       }
/*     */     }
/* 386 */     return bool;
/*     */   }
/*     */ 
/*     */   public void getMenuFavoriteTree()
/*     */     throws Exception
/*     */   {
/* 394 */     ViewContext localViewContext = super.generateContext();
/* 395 */     DataCenter localDataCenter = localViewContext.getDataCenter();
/* 396 */     DataCenterFactory localDataCenterFactory = DataCenterFactory.getInstance();
/* 397 */     DataStore localDataStore = localDataCenterFactory.createDataStore("menuFavoriteTree");
/* 398 */     List localList = this.menuFavoriteBO.getMenuFavoriteTree();
/* 399 */     for (int i = 0; i < localList.size(); i++) {
/* 400 */       MenuFavorite localMenuFavorite = (MenuFavorite)localList.get(i);
/* 401 */       Row localRow = localDataCenterFactory.createRow();
/* 402 */       localRow.setString("id", localMenuFavorite.getId());
/* 403 */       localRow.setString("menuId", localMenuFavorite.getMenuId());
/* 404 */       localRow.setString("parentId", localMenuFavorite.getParentId());
/* 405 */       localRow.setString("title", localMenuFavorite.getTitle());
/* 406 */       localDataStore.getRowSet().addRow(localRow);
/*     */     }
/* 408 */     localDataCenter.addDataStore(localDataStore);
/* 409 */     write(localDataCenter);
/*     */   }
/*     */ 
/*     */   private String decodeURL(String paramString) throws Exception {
/* 413 */     if ((paramString == null) || (paramString.indexOf("eap_username") == -1)) {
/* 414 */       return paramString;
/*     */     }
/*     */ 
/* 419 */     String str1 = paramString.substring(paramString.indexOf("?") + 1);
/* 420 */     String[] arrayOfString = str1.split("&");
/* 421 */     String str6 = "";
/* 422 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 423 */       if (arrayOfString[i].indexOf("eap_username") > -1) {
/* 424 */         String str4 = arrayOfString[i].split("=")[1];
/* 425 */         String str2 = UrlBase64Util.decode(str4);
/* 426 */         arrayOfString[i] = ("eap_username=" + str2);
/*     */       }
/* 428 */       if (arrayOfString[i].indexOf("eap_password") > -1) {
/* 429 */         String str5 = arrayOfString[i].split("=")[1];
/* 430 */         String str3 = UrlBase64Util.decode(str5);
/* 431 */         arrayOfString[i] = ("eap_password=" + str3);
/*     */       }
/* 433 */       if (i == 0)
/* 434 */         str6 = arrayOfString[i];
/*     */       else
/* 436 */         str6 = str6.concat("&" + arrayOfString[i]);
/*     */     }
/* 438 */     return paramString.substring(0, paramString.indexOf("eap_username") - 1).concat("?").concat(str6);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.action.MenuProcessor
 * JD-Core Version:    0.6.2
 */