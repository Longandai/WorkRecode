package com.neusoft.unieap.techcomp.ria.menu.dao;

import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
import java.util.List;

public abstract interface MenuDAO
{
  public abstract void saveMenu(Menu paramMenu);

  public abstract void updateMenu(Menu paramMenu);

  public abstract void deleteMenus(List paramList);

  public abstract List getMenusByAppId(String paramString);

  public abstract void deleteHelpInfoByMenuId(List paramList);

  public abstract void deleteHelpAttachmentsByHelpId(List paramList);

  public abstract List getSameTierMenusByMenuId(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.dao.MenuDAO
 * JD-Core Version:    0.6.2
 */