/*     */ package com.neusoft.unieap.techcomp.ria.menu.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ @ModelFile("menu.entity")
/*     */ public class Menu
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String name;
/*     */   private String title;
/*     */   private String appId;
/*     */   private String target;
/*     */   private String url;
/*     */   private String image;
/*     */   private Integer orderNum;
/*     */   private Boolean isDefault;
/*     */   private Boolean isEnabled;
/*     */   private String description;
/*     */   private String parentId;
/*  69 */   private Boolean leaf = Boolean.valueOf(true);
/*     */   private String type;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  73 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  77 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString) {
/*  81 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  85 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/*  89 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  93 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setAppId(String paramString) {
/*  97 */     this.appId = paramString;
/*     */   }
/*     */ 
/*     */   public String getAppId() {
/* 101 */     return this.appId;
/*     */   }
/*     */ 
/*     */   public void setTarget(String paramString) {
/* 105 */     this.target = paramString;
/*     */   }
/*     */ 
/*     */   public String getTarget() {
/* 109 */     return this.target;
/*     */   }
/*     */ 
/*     */   public void setUrl(String paramString) {
/* 113 */     this.url = paramString;
/*     */   }
/*     */ 
/*     */   public String getUrl() {
/* 117 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setImage(String paramString) {
/* 121 */     this.image = paramString;
/*     */   }
/*     */ 
/*     */   public String getImage() {
/* 125 */     return this.image;
/*     */   }
/*     */ 
/*     */   public void setOrderNum(Integer paramInteger) {
/* 129 */     this.orderNum = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getOrderNum() {
/* 133 */     return this.orderNum;
/*     */   }
/*     */ 
/*     */   public void setIsDefault(Boolean paramBoolean) {
/* 137 */     this.isDefault = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getIsDefault() {
/* 141 */     return this.isDefault;
/*     */   }
/*     */ 
/*     */   public void setIsEnabled(Boolean paramBoolean) {
/* 145 */     this.isEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getIsEnabled() {
/* 149 */     return this.isEnabled;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString) {
/* 153 */     this.description = paramString;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 157 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setParentId(String paramString) {
/* 161 */     this.parentId = paramString;
/*     */   }
/*     */ 
/*     */   public String getParentId() {
/* 165 */     return this.parentId;
/*     */   }
/*     */ 
/*     */   public void setLeaf(Boolean paramBoolean) {
/* 169 */     this.leaf = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getLeaf() {
/* 173 */     return this.leaf;
/*     */   }
/*     */ 
/*     */   public void setType(String paramString) {
/* 177 */     this.type = paramString;
/*     */   }
/*     */ 
/*     */   public String getType() {
/* 181 */     return this.type;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.entity.Menu
 * JD-Core Version:    0.6.2
 */