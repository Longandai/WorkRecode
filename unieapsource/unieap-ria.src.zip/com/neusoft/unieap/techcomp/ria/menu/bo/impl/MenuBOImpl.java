/*     */ package com.neusoft.unieap.techcomp.ria.menu.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.model.Application;
/*     */ import com.neusoft.unieap.core.base.model.SCRepository;
/*     */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*     */ import com.neusoft.unieap.core.util.Assert;
/*     */ import com.neusoft.unieap.core.util.UrlBase64Util;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.CacheSynchronizeManager;
/*     */ import com.neusoft.unieap.techcomp.ria.ext.bo.ExtInfoBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.dao.MenuDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.exception.MenuException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ @ModelFile("menuBO.bo")
/*     */ public class MenuBOImpl
/*     */   implements MenuBO
/*     */ {
/*     */   private EAPCacheManager eapCacheManager;
/*     */   private MenuDAO menuDAO;
/*     */   private ExtInfoBO extInfoBO;
/*     */   private ResourceAuthorizeBO resourceAuthorizeBO;
/*     */   private CacheSynchronizeManager cacheSynchronizeManager;
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager)
/*     */   {
/*  37 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public void setCacheSynchronizeManager(CacheSynchronizeManager paramCacheSynchronizeManager)
/*     */   {
/*  42 */     this.cacheSynchronizeManager = paramCacheSynchronizeManager;
/*     */   }
/*     */ 
/*     */   public void setMenuDAO(MenuDAO paramMenuDAO) {
/*  46 */     this.menuDAO = paramMenuDAO;
/*     */   }
/*     */ 
/*     */   public void setExtInfoBO(ExtInfoBO paramExtInfoBO) {
/*  50 */     this.extInfoBO = paramExtInfoBO;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeBO(ResourceAuthorizeBO paramResourceAuthorizeBO) {
/*  54 */     this.resourceAuthorizeBO = paramResourceAuthorizeBO;
/*     */   }
/*     */ 
/*     */   public void initCache()
/*     */   {
/*  61 */     List localList1 = SCRepository.getAvailableApplications();
/*  62 */     String str = null;
/*  63 */     List localList2 = null;
/*  64 */     Map localMap = null;
/*     */ 
/*  66 */     if (this.extInfoBO.isExistExtInfo("menu")) {
/*  67 */       localMap = this.extInfoBO.getAllExtInfoByObjType("menu");
/*     */     }
/*  69 */     for (int i = 0; i < localList1.size(); i++) {
/*  70 */       Application localApplication = (Application)localList1.get(i);
/*  71 */       str = localApplication.getId();
/*  72 */       localList2 = this.menuDAO.getMenusByAppId(str);
/*  73 */       setAppMenuLeaf(str, localList2);
/*  74 */       this.eapCacheManager.put(str, localList2, "menu", false);
/*     */ 
/*  77 */       if (this.extInfoBO.isExistExtInfo("menu"))
/*     */       {
/*  79 */         HashMap localHashMap = new HashMap();
/*  80 */         for (int j = 0; j < localList2.size(); j++) {
/*  81 */           Menu localMenu = (Menu)localList2.get(j);
/*  82 */           localHashMap.put(localMenu.getId(), localMap.get(localMenu.getId()));
/*     */         }
/*  84 */         this.eapCacheManager.put(str + "_ext", localHashMap, "menu", false);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initCache(String paramString)
/*     */   {
/*  93 */     List localList = this.menuDAO.getMenusByAppId(paramString);
/*  94 */     setAppMenuLeaf(paramString, localList);
/*  95 */     this.eapCacheManager.put(paramString, localList, "menu", false);
/*     */ 
/*  98 */     if (this.extInfoBO.isExistExtInfo("menu")) {
/*  99 */       Map localMap = this.extInfoBO.getAllExtInfoByObjType("menu");
/*     */ 
/* 101 */       HashMap localHashMap = new HashMap();
/* 102 */       for (int i = 0; i < localList.size(); i++) {
/* 103 */         Menu localMenu = (Menu)localList.get(i);
/* 104 */         localHashMap.put(localMenu.getId(), localMap.get(localMenu.getId()));
/*     */       }
/* 106 */       this.eapCacheManager.put(paramString + "_ext", localHashMap, "menu", false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<Menu> getMenuTree(String paramString1, String paramString2)
/*     */     throws Exception
/*     */   {
/* 114 */     Assert.notNull(paramString2);
/* 115 */     if ("root".equals(paramString2))
/* 116 */       return getAppNodes();
/* 117 */     if ("application".equals(paramString2)) {
/* 118 */       return getMenusByAppId(paramString1);
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */ 
/*     */   public List<Menu> getMenusByAppId(String paramString)
/*     */   {
/* 125 */     List localList = (List)this.eapCacheManager.get(paramString, "menu");
/* 126 */     if (localList == null) {
/* 127 */       localList = this.menuDAO.getMenusByAppId(paramString);
/* 128 */       this.eapCacheManager.put(paramString, localList, "menu", false);
/*     */     }
/*     */ 
/* 132 */     Menu localMenu = null;
/* 133 */     for (int i = 0; i < localList.size(); i++) {
/* 134 */       localMenu = (Menu)localList.get(i);
/* 135 */       localMenu.setType("menu");
/* 136 */       localMenu.setLeaf(Boolean.valueOf(isLeaf(localMenu.getId(), localList)));
/* 137 */       String str = localMenu.getParentId();
/* 138 */       if ((str == null) || ("null".equalsIgnoreCase(str))) {
/* 139 */         localMenu.setParentId(paramString);
/*     */       }
/*     */     }
/* 142 */     return localList;
/*     */   }
/*     */ 
/*     */   public Menu saveMenu(String paramString1, String paramString2, Map paramMap)
/*     */   {
/* 149 */     Menu localMenu = new Menu();
/* 150 */     List localList = null;
/* 151 */     if ((paramString2 != null) && (!paramString2.equals(""))) {
/* 152 */       localMenu.setParentId(paramString2);
/* 153 */       localList = getChildMenusById(paramString1, paramString2);
/*     */     } else {
/* 155 */       localList = getRootMenusByAppId(paramString1);
/*     */     }
/*     */ 
/* 158 */     int i = -1;
/* 159 */     int j = -1;
/* 160 */     for (int k = 0; k < localList.size(); k++) {
/* 161 */       j = ((Menu)localList.get(k)).getOrderNum().intValue();
/* 162 */       if (j > i)
/* 163 */         i = j;
/*     */     }
/* 165 */     i++;
/*     */ 
/* 167 */     localMenu.setAppId(paramString1);
/* 168 */     localMenu.setOrderNum(Integer.valueOf(i));
/* 169 */     localMenu.setName(String.valueOf(new Date().getTime()));
/* 170 */     localMenu.setTitle(String.valueOf(new Date().getTime()));
/* 171 */     localMenu.setUrl("");
/* 172 */     localMenu.setDescription("");
/*     */ 
/* 175 */     localMenu.setIsEnabled(Boolean.valueOf(true));
/* 176 */     localMenu.setIsDefault(Boolean.valueOf(false));
/* 177 */     String str = localMenu.getUrl();
/* 178 */     if ((CoreVariability.isUrlPasswordEncrypt()) && (str != null) && (str.indexOf("eap_username") > 0)) {
/* 179 */       localMenu.setUrl(encodeURL(str));
/*     */     }
/*     */ 
/* 182 */     this.menuDAO.saveMenu(localMenu);
/*     */ 
/* 184 */     if (paramMap != null)
/* 185 */       this.extInfoBO.saveExtInfo(localMenu.getId(), "menu", paramMap);
/* 186 */     initCache(localMenu.getAppId());
/*     */ 
/* 189 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/*     */ 
/* 192 */     new StringBuilder("success:").append(localMenu.getId()).append(":").append(localMenu.getTitle())
/* 193 */       .append(":").append(localMenu.getName()).toString();
/*     */ 
/* 194 */     return localMenu;
/*     */   }
/*     */ 
/*     */   public Menu updateMenu(Menu paramMenu, Map paramMap)
/*     */   {
/* 202 */     String str = paramMenu.getUrl();
/* 203 */     if ((CoreVariability.isUrlPasswordEncrypt()) && (str != null) && (str.indexOf("eap_username") > 0))
/* 204 */       paramMenu.setUrl(encodeURL(str));
/*     */     Object localObject;
/* 206 */     if (!isExistMenu(paramMenu.getAppId(), paramMenu.getId())) {
/* 207 */       localObject = new String[] { paramMenu.getId() };
/* 208 */       throw new MenuException("EAPBIZ003503", 
/* 209 */         (Object[])localObject);
/*     */     }
/* 211 */     if (isNameDuplicated(paramMenu.getAppId(), paramMenu.getId(), paramMenu.getName())) {
/* 212 */       localObject = new String[] { paramMenu.getName() };
/* 213 */       throw new MenuException("EAPBIZ003004", 
/* 214 */         (Object[])localObject);
/*     */     }
/* 216 */     this.menuDAO.updateMenu(paramMenu);
/*     */ 
/* 218 */     this.extInfoBO.updateExtInfo(paramMenu.getId(), "menu", paramMap);
/*     */ 
/* 220 */     if (paramMenu.getIsDefault().booleanValue()) {
/* 221 */       localObject = this.menuDAO.getSameTierMenusByMenuId(paramMenu.getParentId(), paramMenu.getId());
/* 222 */       for (Menu localMenu : (List)localObject) {
/* 223 */         localMenu.setIsDefault(Boolean.valueOf(false));
/* 224 */         this.menuDAO.updateMenu(localMenu);
/*     */       }
/*     */     }
/* 227 */     initCache(paramMenu.getAppId());
/*     */ 
/* 230 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/* 231 */     return paramMenu;
/*     */   }
/*     */ 
/*     */   public Menu updateMenu(Menu paramMenu)
/*     */   {
/* 238 */     String str = paramMenu.getUrl();
/* 239 */     if ((CoreVariability.isUrlPasswordEncrypt()) && (str != null) && (str.indexOf("eap_username") > 0))
/* 240 */       paramMenu.setUrl(encodeURL(str));
/*     */     Object localObject;
/* 242 */     if (!isExistMenu(paramMenu.getAppId(), paramMenu.getId())) {
/* 243 */       localObject = new String[] { paramMenu.getId() };
/* 244 */       throw new MenuException("EAPBIZ003503", 
/* 245 */         (Object[])localObject);
/*     */     }
/* 247 */     if (isNameDuplicated(paramMenu.getAppId(), paramMenu.getId(), paramMenu.getName())) {
/* 248 */       localObject = new String[] { paramMenu.getName() };
/* 249 */       throw new MenuException("EAPBIZ003004", 
/* 250 */         (Object[])localObject);
/*     */     }
/* 252 */     this.menuDAO.updateMenu(paramMenu);
/*     */ 
/* 254 */     if (paramMenu.getIsDefault().booleanValue()) {
/* 255 */       localObject = this.menuDAO.getSameTierMenusByMenuId(paramMenu.getParentId(), paramMenu.getId());
/* 256 */       for (Menu localMenu : (List)localObject) {
/* 257 */         localMenu.setIsDefault(Boolean.valueOf(false));
/* 258 */         this.menuDAO.updateMenu(localMenu);
/*     */       }
/*     */     }
/*     */ 
/* 262 */     initCache(paramMenu.getAppId());
/*     */ 
/* 265 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/* 266 */     return paramMenu;
/*     */   }
/*     */ 
/*     */   public boolean isNameDuplicated(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 273 */     List localList = getMenusByAppId(paramString1);
/* 274 */     String str1 = null;
/* 275 */     String str2 = null;
/* 276 */     for (int i = 0; i < localList.size(); i++) {
/* 277 */       str1 = ((Menu)localList.get(i)).getName();
/* 278 */       str2 = ((Menu)localList.get(i)).getId();
/* 279 */       if ((str2 != null) && (!str2.equals(paramString2)) && (str1 != null) && (str1.equalsIgnoreCase(paramString3))) {
/* 280 */         return true;
/*     */       }
/*     */     }
/* 283 */     return false;
/*     */   }
/*     */ 
/*     */   public void deleteMenus(String paramString, List paramList)
/*     */   {
/* 290 */     if ((paramList == null) || (paramList.isEmpty()))
/* 291 */       return;
/* 292 */     List localList = getMenuIds(paramString, paramList);
/* 293 */     this.menuDAO.deleteMenus(localList);
/*     */ 
/* 295 */     for (int i = 0; i < paramList.size(); i++) {
/* 296 */       this.extInfoBO.deleteExtInfo((String)paramList.get(i), "menu");
/*     */     }
/*     */ 
/* 299 */     this.resourceAuthorizeBO.deleteResourceAuthorities(paramList, "menu");
/*     */ 
/* 301 */     initCache(paramString);
/*     */ 
/* 304 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/*     */   }
/*     */ 
/*     */   public void deleteMenu(String paramString1, String paramString2)
/*     */   {
/* 311 */     if ((paramString2 == null) || ("".equals(paramString2)))
/* 312 */       return;
/* 313 */     ArrayList localArrayList = new ArrayList();
/* 314 */     localArrayList.add(paramString2);
/* 315 */     List localList = getMenuIds(paramString1, localArrayList);
/* 316 */     this.menuDAO.deleteMenus(localList);
/*     */ 
/* 318 */     for (int i = 0; i < localArrayList.size(); i++) {
/* 319 */       this.extInfoBO.deleteExtInfo((String)localArrayList.get(i), "menu");
/*     */     }
/*     */ 
/* 322 */     this.resourceAuthorizeBO.deleteResourceAuthorities(localArrayList, "menu");
/*     */ 
/* 324 */     initCache(paramString1);
/*     */ 
/* 327 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/*     */   }
/*     */ 
/*     */   public List getChildMenusById(String paramString1, String paramString2)
/*     */   {
/* 334 */     List localList = getMenusByAppId(paramString1);
/* 335 */     Menu localMenu = null;
/* 336 */     ArrayList localArrayList = new ArrayList();
/* 337 */     for (int i = 0; i < localList.size(); i++) {
/* 338 */       localMenu = (Menu)localList.get(i);
/* 339 */       String str = localMenu.getParentId();
/* 340 */       if ((str != null) && (str.equals(paramString2))) {
/* 341 */         localArrayList.add(localMenu);
/*     */       }
/*     */     }
/* 344 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRootMenusByAppId(String paramString)
/*     */   {
/* 351 */     List localList = getMenusByAppId(paramString);
/* 352 */     ArrayList localArrayList = new ArrayList();
/* 353 */     Menu localMenu = null;
/* 354 */     for (int i = 0; i < localList.size(); i++) {
/* 355 */       localMenu = (Menu)localList.get(i);
/* 356 */       String str = localMenu.getParentId();
/* 357 */       if ((str == null) || (str.equalsIgnoreCase(paramString)))
/* 358 */         localArrayList.add(localMenu);
/*     */     }
/* 360 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getAvailableApplications()
/*     */   {
/* 369 */     List localList = SCRepository.getAvailableApplications();
/* 370 */     return localList;
/*     */   }
/*     */ 
/*     */   public void moveMenu(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 378 */     Menu localMenu1 = getMenuById(paramString1, paramString2);
/* 379 */     if (localMenu1 == null)
/* 380 */       throw new MenuException("EAPBIZ003001", new Object[] { paramString2 });
/* 381 */     Menu localMenu2 = getMenuById(paramString1, paramString3);
/* 382 */     if (localMenu2 == null)
/* 383 */       throw new MenuException("EAPBIZ003001", new Object[] { paramString3 });
/* 384 */     int i = localMenu1.getOrderNum().intValue();
/* 385 */     int j = localMenu2.getOrderNum().intValue();
/* 386 */     localMenu1.setOrderNum(Integer.valueOf(j));
/* 387 */     localMenu2.setOrderNum(Integer.valueOf(i));
/* 388 */     this.menuDAO.updateMenu(localMenu1);
/* 389 */     this.menuDAO.updateMenu(localMenu2);
/* 390 */     initCache(paramString1);
/*     */ 
/* 393 */     this.cacheSynchronizeManager.updateCacheStatusBySysTime("menu");
/*     */   }
/*     */ 
/*     */   public Menu getMenuById(String paramString1, String paramString2)
/*     */   {
/* 400 */     List localList = getMenusByAppId(paramString1);
/* 401 */     Menu localMenu = null;
/* 402 */     for (int i = 0; i < localList.size(); i++) {
/* 403 */       localMenu = (Menu)localList.get(i);
/* 404 */       if (localMenu.getId().equals(paramString2))
/* 405 */         return localMenu;
/*     */     }
/* 407 */     return localMenu;
/*     */   }
/*     */ 
/*     */   public Map getExtInfo(String paramString1, String paramString2)
/*     */   {
/* 414 */     if (this.extInfoBO.isExistExtInfo("menu")) {
/* 415 */       Map localMap = (Map)this.eapCacheManager.get(paramString1 + "_ext", "menu");
/* 416 */       if (localMap != null)
/* 417 */         return (Map)localMap.get(paramString2);
/*     */     }
/* 419 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isInclude(Menu paramMenu, List paramList)
/*     */   {
/* 426 */     String str = paramMenu.getId();
/* 427 */     for (int i = 0; i < paramList.size(); i++) {
/* 428 */       if (str.equals(((Menu)paramList.get(i)).getId()))
/* 429 */         return true;
/*     */     }
/* 431 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isUrlInclude(Menu paramMenu, List paramList)
/*     */   {
/* 438 */     String str = paramMenu.getUrl();
/* 439 */     if (str != null) {
/* 440 */       for (int i = 0; i < paramList.size(); i++)
/* 441 */         if (str.equals(((Menu)paramList.get(i)).getUrl()))
/* 442 */           return true;
/*     */     }
/* 444 */     return false;
/*     */   }
/*     */ 
/*     */   public List getAllMenus()
/*     */   {
/* 452 */     List localList1 = SCRepository.getAvailableApplications();
/* 453 */     ArrayList localArrayList = new ArrayList();
/* 454 */     String str = null;
/* 455 */     List localList2 = null;
/* 456 */     for (int i = 0; i < localList1.size(); i++) {
/* 457 */       Application localApplication = (Application)localList1.get(i);
/* 458 */       str = localApplication.getId();
/* 459 */       localList2 = (List)this.eapCacheManager.get(str, "menu");
/* 460 */       if (localList2 != null)
/* 461 */         localArrayList.addAll(localList2);
/*     */     }
/* 463 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private String encodeURL(String paramString)
/*     */   {
/* 474 */     String str1 = paramString.substring(paramString.indexOf("?") + 1);
/* 475 */     String[] arrayOfString = str1.split("&");
/* 476 */     String str6 = "";
/* 477 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 478 */       if (arrayOfString[i].indexOf("eap_username") > -1) {
/* 479 */         String str2 = arrayOfString[i].split("=")[1];
/* 480 */         String str4 = UrlBase64Util.encode(str2);
/* 481 */         arrayOfString[i] = ("eap_username=" + str4);
/*     */       }
/* 483 */       if (arrayOfString[i].indexOf("eap_password") > -1) {
/* 484 */         String str3 = arrayOfString[i].split("=")[1];
/* 485 */         String str5 = UrlBase64Util.encode(str3);
/* 486 */         arrayOfString[i] = ("eap_password=" + str5);
/*     */       }
/* 488 */       if (i == 0)
/* 489 */         str6 = arrayOfString[i];
/*     */       else {
/* 491 */         str6 = str6.concat("&" + arrayOfString[i]);
/*     */       }
/*     */     }
/* 494 */     return paramString.substring(0, paramString.indexOf("eap_username") - 1).concat("?").concat(str6);
/*     */   }
/*     */ 
/*     */   private boolean isLeaf(String paramString, List paramList)
/*     */   {
/* 504 */     Menu localMenu = null;
/* 505 */     for (int i = 0; i < paramList.size(); i++) {
/* 506 */       localMenu = (Menu)paramList.get(i);
/* 507 */       String str = localMenu.getParentId();
/* 508 */       if ((str != null) && (str.equals(paramString))) {
/* 509 */         return false;
/*     */       }
/*     */     }
/* 512 */     return true;
/*     */   }
/*     */ 
/*     */   private List getAppNodes()
/*     */   {
/* 519 */     ArrayList localArrayList = new ArrayList();
/* 520 */     List localList = SCRepository.getAvailableApplications();
/* 521 */     for (int i = 0; i < localList.size(); i++) {
/* 522 */       Menu localMenu = new Menu();
/* 523 */       Application localApplication = (Application)localList.get(i);
/* 524 */       localMenu.setAppId(localApplication.getId());
/* 525 */       localMenu.setTitle(localApplication.getTitle());
/* 526 */       localMenu.setName(localApplication.getTitle());
/* 527 */       localMenu.setId(localApplication.getId());
/* 528 */       localMenu.setParentId(null);
/* 529 */       localMenu.setLeaf(Boolean.valueOf(false));
/* 530 */       localMenu.setType("application");
/* 531 */       localArrayList.add(localMenu);
/*     */     }
/* 533 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private List setAppMenuLeaf(String paramString, List paramList)
/*     */   {
/* 542 */     Menu localMenu = null;
/* 543 */     String str1 = null;
/* 544 */     String str2 = null;
/* 545 */     for (int i = 0; i < paramList.size(); i++) {
/* 546 */       localMenu = (Menu)paramList.get(i);
/* 547 */       str1 = localMenu.getId();
/* 548 */       for (int j = 0; j < paramList.size(); j++) {
/* 549 */         str2 = ((Menu)paramList.get(j)).getParentId();
/* 550 */         if ((str2 != null) && (str2.equals(str1))) {
/* 551 */           localMenu.setLeaf(Boolean.valueOf(false));
/* 552 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 556 */     return paramList;
/*     */   }
/*     */ 
/*     */   private List getMenuIds(String paramString, List paramList) {
/* 560 */     int i = 0;
/* 561 */     int j = 30;
/* 562 */     ArrayList localArrayList = new ArrayList();
/* 563 */     localArrayList.addAll(paramList);
/* 564 */     List localList = getDirectChildMenuIdsByIds(paramString, paramList);
/* 565 */     while ((!localList.isEmpty()) && (i++ < j)) {
/* 566 */       localArrayList.addAll(localList);
/* 567 */       localList = getDirectChildMenuIdsByIds(paramString, localList);
/*     */     }
/* 569 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private List getDirectChildMenuIdsByIds(String paramString, List paramList) {
/* 573 */     String str = null;
/* 574 */     ArrayList localArrayList1 = new ArrayList();
/* 575 */     ArrayList localArrayList2 = new ArrayList();
/* 576 */     for (int i = 0; i < paramList.size(); i++) {
/* 577 */       str = (String)paramList.get(i);
/* 578 */       localArrayList1.addAll(getChildMenusById(paramString, str));
/*     */     }
/* 580 */     for (i = 0; i < localArrayList1.size(); i++) {
/* 581 */       localArrayList2.add(((Menu)localArrayList1.get(i)).getId());
/*     */     }
/* 583 */     return localArrayList2;
/*     */   }
/*     */ 
/*     */   private boolean isExistMenu(String paramString1, String paramString2) {
/* 587 */     boolean bool = false;
/* 588 */     if (!"".equalsIgnoreCase(paramString2)) {
/* 589 */       Menu localMenu = getMenuById(paramString1, paramString2);
/* 590 */       if (localMenu != null) {
/* 591 */         bool = true;
/*     */       }
/*     */     }
/* 594 */     return bool;
/*     */   }
/*     */ 
/*     */   public List getAllDescendantMenusById(String paramString1, String paramString2)
/*     */   {
/* 601 */     return getDescendantMenusById(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   private List getDescendantMenusById(String paramString1, String paramString2) {
/* 605 */     List localList1 = getChildMenusById(paramString1, paramString2);
/* 606 */     ArrayList localArrayList = new ArrayList();
/* 607 */     localArrayList.addAll(localList1);
/* 608 */     Menu localMenu = null;
/*     */ 
/* 610 */     for (int i = 0; i < localList1.size(); i++) {
/* 611 */       localMenu = (Menu)localList1.get(i);
/* 612 */       List localList2 = getDescendantMenusById(paramString1, localMenu.getId());
/* 613 */       if ((localList2 != null) && (localList2.size() > 0)) {
/* 614 */         localArrayList.addAll(localList2);
/*     */       }
/*     */     }
/* 617 */     return localArrayList;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.impl.MenuBOImpl
 * JD-Core Version:    0.6.2
 */