/*     */ package com.neusoft.unieap.techcomp.ria.menu.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuFavoriteBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.dao.MenuFavoriteDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.MenuFavorite;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("menuFavoriteBO.bo")
/*     */ public class MenuFavoriteBOImpl
/*     */   implements MenuFavoriteBO
/*     */ {
/*     */   private MenuFavoriteDAO menuFavoriteDAO;
/*     */ 
/*     */   public void setMenuFavoriteDAO(MenuFavoriteDAO paramMenuFavoriteDAO)
/*     */   {
/*  34 */     this.menuFavoriteDAO = paramMenuFavoriteDAO;
/*     */   }
/*     */ 
/*     */   public MenuFavorite saveMenuFavorite(String paramString1, String paramString2, String paramString3)
/*     */   {
/*  41 */     Menu localMenu = this.menuFavoriteDAO.getMenuById(paramString1);
/*  42 */     if (localMenu == null) {
/*  43 */       throw new UniEAPBusinessException("EAPTECHRIA1023");
/*     */     }
/*  45 */     MenuFavorite localMenuFavorite = new MenuFavorite();
/*  46 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  47 */     localMenuFavorite.setUserId(localUser.getId());
/*  48 */     localMenuFavorite.setCreatedBy(localUser.getAccount());
/*  49 */     localMenuFavorite.setMenuId(paramString1);
/*  50 */     localMenuFavorite.setUrl(localMenu.getUrl());
/*  51 */     localMenuFavorite.setTitle(paramString3);
/*  52 */     localMenuFavorite.setImage(localMenu.getImage());
/*  53 */     localMenuFavorite.setParentId(paramString2);
/*  54 */     localMenuFavorite.setCreationDate(new Timestamp(System.currentTimeMillis()));
/*  55 */     int i = this.menuFavoriteDAO.getMaxMenuFavoriteDisplayOrder(localUser.getId());
/*  56 */     localMenuFavorite.setDisplayOrder(Integer.valueOf(i + 1));
/*  57 */     return this.menuFavoriteDAO.saveMenuFavorite(localMenuFavorite);
/*     */   }
/*     */ 
/*     */   public void deleteMenuFavorite(String paramString)
/*     */   {
/*  63 */     if ((paramString == null) || (paramString.length() == 0)) {
/*  64 */       return;
/*     */     }
/*  66 */     String[] arrayOfString = paramString.split(",");
/*  67 */     this.menuFavoriteDAO.deleteMenuFavorite(arrayOfString);
/*     */   }
/*     */ 
/*     */   public List<MenuFavorite> getMenuFavoriteTree()
/*     */   {
/*  74 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getId();
/*  75 */     List localList = this.menuFavoriteDAO.getMenuFavoriteTree(str);
/*  76 */     return localList;
/*     */   }
/*     */ 
/*     */   public boolean isExistMenuFavoriteTree(String paramString)
/*     */   {
/*  83 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getId();
/*  84 */     return this.menuFavoriteDAO.isExistMenuFavoriteTree(paramString, str);
/*     */   }
/*     */ 
/*     */   public MenuFavorite saveMenuFavoriteNode(String paramString)
/*     */   {
/*  91 */     MenuFavorite localMenuFavorite = new MenuFavorite();
/*  92 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  93 */     localMenuFavorite.setUserId(localUser.getId());
/*  94 */     localMenuFavorite.setCreatedBy(localUser.getAccount());
/*  95 */     localMenuFavorite.setMenuId(null);
/*  96 */     localMenuFavorite.setTitle("新建文件夹");
/*  97 */     localMenuFavorite.setParentId(paramString);
/*  98 */     localMenuFavorite.setCreationDate(new Timestamp(System.currentTimeMillis()));
/*  99 */     int i = this.menuFavoriteDAO.getMaxMenuFavoriteDisplayOrder(localUser.getId());
/* 100 */     localMenuFavorite.setDisplayOrder(Integer.valueOf(i + 1));
/* 101 */     return this.menuFavoriteDAO.saveMenuFavorite(localMenuFavorite);
/*     */   }
/*     */ 
/*     */   public void updateMenuFavorite(String paramString1, String paramString2, String paramString3)
/*     */     throws Exception
/*     */   {
/* 108 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 109 */     MenuFavorite localMenuFavorite = this.menuFavoriteDAO.getMenuFavoriteByMenuId(paramString1, localUser.getId());
/* 110 */     if (localMenuFavorite != null) {
/* 111 */       String str = localUser.getAccount();
/* 112 */       localMenuFavorite.setLastUpdatedBy(str);
/* 113 */       localMenuFavorite.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
/* 114 */       localMenuFavorite.setTitle(paramString2);
/* 115 */       localMenuFavorite.setParentId(paramString3);
/* 116 */       this.menuFavoriteDAO.updateMenuFavorite(localMenuFavorite);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateDragedMenuFavoriteNode(List<MenuFavorite> paramList)
/*     */   {
/* 127 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 128 */     String str1 = localUser.getId();
/* 129 */     String str2 = localUser.getAccount();
/*     */ 
/* 131 */     for (int i = 0; i < paramList.size(); i++) {
/* 132 */       MenuFavorite localMenuFavorite = (MenuFavorite)paramList.get(i);
/* 133 */       localMenuFavorite.setUserId(str1);
/* 134 */       localMenuFavorite.setLastUpdatedBy(str2);
/* 135 */       localMenuFavorite.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
/* 136 */       localMenuFavorite.setDisplayOrder(Integer.valueOf(i + 1));
/* 137 */       this.menuFavoriteDAO.updateMenuFavorite(localMenuFavorite);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List<MenuFavorite> getFavoriteMenuFolders()
/*     */   {
/* 145 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getId();
/* 146 */     List localList = this.menuFavoriteDAO.getFavoriteMenuFolders(str);
/* 147 */     return localList;
/*     */   }
/*     */ 
/*     */   public void addOrUpdateFavoriteMenuTree(List<MenuFavorite> paramList, String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 155 */     MenuFavorite localMenuFavorite = null;
/* 156 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 157 */     String str1 = localUser.getId();
/* 158 */     String str2 = localUser.getAccount();
/* 159 */     if (paramString4.equals("update")) {
/* 160 */       for (int i = 0; i < paramList.size(); i++) {
/* 161 */         localMenuFavorite = (MenuFavorite)paramList.get(i);
/* 162 */         localMenuFavorite.setUserId(str1);
/* 163 */         localMenuFavorite.setLastUpdatedBy(str2);
/* 164 */         localMenuFavorite.setLastUpdateDate(new Timestamp(System.currentTimeMillis()));
/* 165 */         if (paramString1.equals(localMenuFavorite.getMenuId())) {
/* 166 */           localMenuFavorite.setParentId(paramString3);
/*     */         }
/* 168 */         this.menuFavoriteDAO.updateMenuFavorite(localMenuFavorite);
/*     */       }
/* 170 */     } else if (paramString4.equals("add"))
/*     */     {
/* 172 */       Menu localMenu = this.menuFavoriteDAO.getMenuById(paramString1);
/* 173 */       if (localMenu == null) {
/* 174 */         throw new UniEAPBusinessException("EAPTECHRIA1023");
/*     */       }
/* 176 */       localMenuFavorite = new MenuFavorite();
/* 177 */       localMenuFavorite.setUserId(str1);
/* 178 */       localMenuFavorite.setCreatedBy(str2);
/* 179 */       localMenuFavorite.setMenuId(paramString1);
/* 180 */       localMenuFavorite.setUrl(localMenu.getUrl());
/* 181 */       localMenuFavorite.setTitle(paramString2);
/* 182 */       localMenuFavorite.setImage(localMenu.getImage());
/* 183 */       localMenuFavorite.setParentId(paramString3);
/* 184 */       localMenuFavorite.setCreationDate(new Timestamp(System.currentTimeMillis()));
/* 185 */       int j = this.menuFavoriteDAO.getMaxMenuFavoriteDisplayOrder(str1);
/* 186 */       localMenuFavorite.setDisplayOrder(Integer.valueOf(j + 1));
/* 187 */       this.menuFavoriteDAO.saveMenuFavorite(localMenuFavorite);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteMenuFavoriteByMenuId(String paramString)
/*     */   {
/* 194 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getId();
/* 195 */     this.menuFavoriteDAO.deleteMenuFavoriteByMenuId(paramString, str);
/*     */   }
/*     */ 
/*     */   public MenuFavorite getFavoriteMenuByMenuId(String paramString)
/*     */   {
/* 202 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getId();
/* 203 */     MenuFavorite localMenuFavorite = this.menuFavoriteDAO.getMenuFavoriteByMenuId(paramString, str);
/* 204 */     if (localMenuFavorite != null) {
/* 205 */       return localMenuFavorite;
/*     */     }
/*     */ 
/* 208 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.bo.impl.MenuFavoriteBOImpl
 * JD-Core Version:    0.6.2
 */