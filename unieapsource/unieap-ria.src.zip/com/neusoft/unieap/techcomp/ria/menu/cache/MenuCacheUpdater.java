/*    */ package com.neusoft.unieap.techcomp.ria.menu.cache;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.ICacheUpdater;
/*    */ import com.neusoft.unieap.techcomp.cache.cachesynchronize.util.CacheTaskUtil;
/*    */ import com.neusoft.unieap.techcomp.ria.codelist.cache.CodeListCacheUpdater;
/*    */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class MenuCacheUpdater
/*    */   implements ICacheUpdater
/*    */ {
/*    */   private CacheTaskUtil cacheTaskUtil;
/*    */   private MenuBO menuBO;
/* 15 */   private static final Logger logger = LoggerFactory.getLogger(CodeListCacheUpdater.class);
/*    */ 
/*    */   public void setCacheTaskUtil(CacheTaskUtil paramCacheTaskUtil) {
/* 18 */     this.cacheTaskUtil = paramCacheTaskUtil;
/*    */   }
/*    */ 
/*    */   public void setMenuBO(MenuBO paramMenuBO) {
/* 22 */     this.menuBO = paramMenuBO;
/*    */   }
/*    */ 
/*    */   public void update(String paramString)
/*    */     throws Exception
/*    */   {
/* 29 */     this.menuBO.initCache();
/* 30 */     CacheTaskUtil.updateCache(paramString);
/* 31 */     logger.info(paramString + " has updated...");
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-ria.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.ria.menu.cache.MenuCacheUpdater
 * JD-Core Version:    0.6.2
 */