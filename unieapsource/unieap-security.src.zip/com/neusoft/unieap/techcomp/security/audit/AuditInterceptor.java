/*     */ package com.neusoft.unieap.techcomp.security.audit;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.Audit;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*     */ import com.neusoft.unieap.core.security.entity.AdminRole;
/*     */ import com.neusoft.unieap.techcomp.org.entity.DimensionUnit;
/*     */ import com.neusoft.unieap.techcomp.org.entity.Station;
/*     */ import com.neusoft.unieap.techcomp.security.entity.BusiRole;
/*     */ import java.text.DateFormat;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ 
/*     */ public class AuditInterceptor
/*     */   implements MethodInterceptor
/*     */ {
/*     */   private AuditLogger logger;
/*     */ 
/*     */   public void setLogger(AuditLogger paramAuditLogger)
/*     */   {
/*  26 */     this.logger = paramAuditLogger;
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation paramMethodInvocation) throws Throwable
/*     */   {
/*  31 */     com.neusoft.unieap.core.context.properties.User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*  32 */     if (localUser == null)
/*  33 */       return null;
/*  34 */     String str1 = localUser.getAccount();
/*  35 */     Object localObject1 = null;
/*  36 */     localObject1 = paramMethodInvocation.proceed();
/*  37 */     Audit localAudit = null;
/*  38 */     Object[] arrayOfObject = paramMethodInvocation.getArguments();
/*  39 */     if ((paramMethodInvocation.getThis() instanceof UniEAPEventPublisher))
/*     */     {
/*  41 */       localAudit = (Audit)AnnotationUtils.findAnnotation(arrayOfObject[0]
/*  42 */         .getClass(), Audit.class);
/*     */     }
/*  44 */     else localAudit = (Audit)AnnotationUtils.findAnnotation(paramMethodInvocation
/*  45 */         .getMethod(), Audit.class);
/*     */ 
/*  47 */     if (localAudit != null) {
/*  48 */       String str2 = localAudit.value();
/*  49 */       if ((str2 != null) && (str2.length() > 0)) {
/*  50 */         Date localDate = new Date();
/*  51 */         SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
/*  52 */         String str3 = localSimpleDateFormat.format(localDate);
/*  53 */         if (str2.equals("loginSuccessful")) {
/*  54 */           this.logger.log("帐号" + str1 + "在" + str3 + 
/*  55 */             "登录成功。", str2);
/*  56 */         } else if (str2.equals("loginFail")) {
/*  57 */           this.logger.log("帐号" + str1 + "在" + str3 + 
/*  58 */             "登录失败。", str2);
/*  59 */         } else if (str2.equals("accountLocked")) {
/*  60 */           this.logger.log("帐号" + str1 + "在" + str3 + 
/*  61 */             "被系统锁定。", str2);
/*  62 */         } else if (str2.equals("accountAlreadyLocked")) {
/*  63 */           this.logger.log(str3 + "帐号" + str1 + "已经被系统锁定。", 
/*  64 */             str2);
/*  65 */         } else if (str2.equals("accountAlreadyKicked")) {
/*  66 */           this.logger.log(str3 + "帐号" + str1 + "已经被踢出。", 
/*  67 */             str2);
/*  68 */         } else if (str2.equals("logout")) {
/*  69 */           this.logger.log(str3 + "帐号" + str1 + "已经退出。", 
/*  70 */             str2);
/*     */         }
/*     */         else
/*     */         {
/*     */           Object localObject2;
/*  72 */           if ((str2.equals("saveUser")) || 
/*  73 */             (str2.equals("saveUserWithBlob"))) {
/*  74 */             localObject2 = (com.neusoft.unieap.techcomp.org.entity.User)arrayOfObject[0];
/*  75 */             this.logger.log(str1 + "在" + str3 + "新增id为" + 
/*  76 */               ((com.neusoft.unieap.techcomp.org.entity.User)localObject2).getId() + "的用户。", str2);
/*  77 */           } else if ((str2.equals("updateUser")) || 
/*  78 */             (str2.equals("updateUserWithBlob"))) {
/*  79 */             localObject2 = (com.neusoft.unieap.techcomp.org.entity.User)arrayOfObject[0];
/*  80 */             this.logger.log(str1 + "在" + str3 + "修改id为" + 
/*  81 */               ((com.neusoft.unieap.techcomp.org.entity.User)localObject2).getId() + "的用户。", str2);
/*  82 */           } else if (str2.equals("deleteUserById")) {
/*  83 */             localObject2 = (String)arrayOfObject[0];
/*  84 */             this.logger.log(str1 + "在" + str3 + "删除id为" + 
/*  85 */               (String)localObject2 + "的用户。", str2);
/*  86 */           } else if (str2.equals("addStationUsers")) {
/*  87 */             localObject2 = (String)arrayOfObject[0];
/*  88 */             this.logger.log(str1 + "在" + str3 + "id为" + 
/*  89 */               (String)localObject2 + "的用户增加与职位之间的关联。", str2);
/*  90 */           } else if (str2.equals("addUnitUsers")) {
/*  91 */             localObject2 = (String)arrayOfObject[0];
/*  92 */             this.logger.log(str1 + "在" + str3 + "id为" + 
/*  93 */               (String)localObject2 + "的用户增加与组织单元之间的关联。", str2);
/*  94 */           } else if (str2.equals("deleteStationUser")) {
/*  95 */             localObject2 = (String)arrayOfObject[0];
/*  96 */             this.logger.log(str1 + "在" + str3 + "删除id为" + 
/*  97 */               (String)localObject2 + "的用户与职位之间的关联。", str2);
/*  98 */           } else if (str2.equals("deleteUnitUser")) {
/*  99 */             localObject2 = (String)arrayOfObject[0];
/* 100 */             this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 101 */               (String)localObject2 + "的用户与组织单元之间的关联。", str2);
/* 102 */           } else if (str2.equals("updateUserLockState")) {
/* 103 */             localObject2 = (String)arrayOfObject[0];
/* 104 */             this.logger.log(str1 + "在" + str3 + "修改帐号为" + 
/* 105 */               (String)localObject2 + "的用户锁定状态。", str2);
/* 106 */           } else if (str2.equals("updateUserPassword")) {
/* 107 */             ((String)arrayOfObject[0]);
/* 108 */             this.logger
/* 109 */               .log(str1 + "在" + str3 + "修改密码。", 
/* 110 */               str2);
/*     */           }
/* 113 */           else if (str2.equals("deleteUnit")) {
/* 114 */             localObject2 = (String)arrayOfObject[0];
/* 115 */             this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 116 */               (String)localObject2 + "的维度组织单元。", str2);
/*     */           }
/*     */           else
/*     */           {
/*     */             Object localObject3;
/* 117 */             if (str2.equals("deleteUnitUser")) {
/* 118 */               localObject2 = (String)arrayOfObject[0];
/* 119 */               localObject3 = (String)arrayOfObject[1];
/* 120 */               this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 121 */                 (String)localObject2 + "的用户与id为" + (String)localObject3 + "组织单元之间的关联。", str2);
/* 122 */             } else if (str2.equals("deleteUnitUsers")) {
/* 123 */               localObject2 = (String)arrayOfObject[0];
/* 124 */               localObject3 = (String)arrayOfObject[1];
/* 125 */               this.logger
/* 126 */                 .log(str1 + "在" + str3 + "删除id为" + 
/* 127 */                 (String)localObject2 + "的用户与id为" + (String)localObject3 + 
/* 128 */                 "组织单元之间的关联。", str2);
/* 129 */             } else if (str2.equals("saveUnitAndDimensionUnit")) {
/* 130 */               localObject2 = (String)arrayOfObject[3];
/* 131 */               this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 132 */                 (String)localObject2 + "的维度组织单元。", str2);
/* 133 */             } else if (str2.equals("saveUnitUser")) {
/* 134 */               localObject2 = (String)arrayOfObject[0];
/* 135 */               localObject3 = (String)arrayOfObject[1];
/* 136 */               this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 137 */                 (String)localObject2 + "的用户与id为" + (String)localObject3 + "组织单元之间的关联。", str2);
/*     */             }
/*     */             else
/*     */             {
/*     */               String str4;
/* 138 */               if (str2.equals("saveUnitUsers")) {
/* 139 */                 localObject2 = (List)arrayOfObject[0];
/* 140 */                 localObject3 = userListToUserIds((List)localObject2);
/* 141 */                 str4 = (String)arrayOfObject[1];
/* 142 */                 this.logger
/* 143 */                   .log(str1 + "在" + str3 + "新增id为" + 
/* 144 */                   str4 + "的组织单元与id为" + (String)localObject3 + 
/* 145 */                   "用户之间的关联。", str2);
/* 146 */               } else if (str2.equals("updateUnitAndDimensionUnit")) {
/* 147 */                 localObject2 = (String)arrayOfObject[2];
/* 148 */                 this.logger.log(str1 + "在" + str3 + "修改id为" + 
/* 149 */                   (String)localObject2 + "的维度组织单元。", str2);
/* 150 */               } else if (str2.equals("updateUnitUsers")) {
/* 151 */                 localObject2 = (String)arrayOfObject[0];
/* 152 */                 localObject3 = (String)arrayOfObject[1];
/* 153 */                 str4 = (String)arrayOfObject[2];
/* 154 */                 if ((localObject3 != null) && (!((String)localObject3).equals("")))
/* 155 */                   this.logger.log(str1 + "在" + str3 + "增加id为" + 
/* 156 */                     (String)localObject2 + "的用户与id为" + (String)localObject3 + 
/* 157 */                     "的组织单元之间的关联。", str2);
/* 158 */                 if ((str4 != null) && (!str4.equals("")))
/* 159 */                   this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 160 */                     (String)localObject2 + "的用户与id为" + str4 + 
/* 161 */                     "的组织单元之间的关联。", str2);
/* 162 */               } else if (str2.equals("updateDragUnits")) {
/* 163 */                 localObject2 = (DimensionUnit)arrayOfObject[2];
/* 164 */                 localObject3 = (DimensionUnit)arrayOfObject[3];
/* 165 */                 str4 = (String)arrayOfObject[4];
/* 166 */                 if (str4.equalsIgnoreCase("over"))
/* 167 */                   this.logger.log(str1 + "在" + str3 + "将id为" + 
/* 168 */                     ((DimensionUnit)localObject2).getId() + "的组织单元(及其子孙节点)拖拽成为id为" + 
/* 169 */                     ((DimensionUnit)localObject3).getId() + "的下级组织单元。", str2);
/* 170 */                 else if (str4.equalsIgnoreCase("before"))
/* 171 */                   this.logger.log(str1 + "在" + str3 + "将id为" + 
/* 172 */                     ((DimensionUnit)localObject2).getId() + "的组织单元(及其子孙节点)拖拽成为id为" + 
/* 173 */                     ((DimensionUnit)localObject3).getId() + "的前一个节点。", str2);
/* 174 */                 else if (str4.equalsIgnoreCase("after")) {
/* 175 */                   this.logger.log(str1 + "在" + str3 + "将id为" + 
/* 176 */                     ((DimensionUnit)localObject2).getId() + "的组织单元(及其子孙节点)拖拽成为id为" + 
/* 177 */                     ((DimensionUnit)localObject3).getId() + "的后一个节点。", str2);
/*     */                 }
/*     */               }
/* 180 */               else if (str2.equals("deleteStationById")) {
/* 181 */                 localObject2 = (String)arrayOfObject[0];
/* 182 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 183 */                   (String)localObject2 + "的职位。", str2);
/* 184 */               } else if (str2.equals("deleteStationUser")) {
/* 185 */                 localObject2 = (String)arrayOfObject[0];
/* 186 */                 localObject3 = (String)arrayOfObject[1];
/* 187 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 188 */                   (String)localObject2 + "与id为" + (String)localObject3 + "的职位之间的关联。", str2);
/* 189 */               } else if (str2.equals("saveStation")) {
/* 190 */                 localObject2 = (Station)arrayOfObject[0];
/* 191 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 192 */                   ((Station)localObject2).getId() + "的职位。", str2);
/* 193 */               } else if (str2.equals("saveStationUser")) {
/* 194 */                 localObject2 = (String)arrayOfObject[0];
/* 195 */                 localObject3 = (String)arrayOfObject[1];
/* 196 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 197 */                   (String)localObject2 + "的用户与id为" + (String)localObject3 + "的职位之间的关联。", 
/* 198 */                   str2);
/* 199 */               } else if (str2.equals("saveStationUsers")) {
/* 200 */                 localObject2 = (List)arrayOfObject[0];
/* 201 */                 localObject3 = userListToUserIds((List)localObject2);
/* 202 */                 str4 = (String)arrayOfObject[1];
/* 203 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 204 */                   str4 + "的职位与id为" + (String)localObject3 + "用户之间的关联。", 
/* 205 */                   str2);
/* 206 */               } else if (str2.equals("updateStation")) {
/* 207 */                 localObject2 = (Station)arrayOfObject[0];
/* 208 */                 this.logger.log(str1 + "在" + str3 + "修改id为" + 
/* 209 */                   ((Station)localObject2).getId() + "的职位。", str2);
/*     */               }
/* 212 */               else if (str2.equals("deleteAdminRoleUsers")) {
/* 213 */                 localObject2 = (String)arrayOfObject[0];
/* 214 */                 localObject3 = (List)arrayOfObject[1];
/* 215 */                 str4 = userListToUserIds((List)localObject3);
/* 216 */                 this.logger.log(str1 + "在" + str3 + "增加id为" + 
/* 217 */                   (String)localObject2 + "管理角色与id为" + str4 + "用户之间的关联。", 
/* 218 */                   str2);
/* 219 */               } else if (str2.equals("deleteOrgAdminRole")) {
/* 220 */                 localObject2 = (String)arrayOfObject[0];
/* 221 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 222 */                   (String)localObject2 + "的管理角色。", str2);
/* 223 */               } else if (str2.equals("saveAdminRole")) {
/* 224 */                 localObject2 = (AdminRole)arrayOfObject[0];
/* 225 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 226 */                   ((AdminRole)localObject2).getId() + "的管理角色。", str2);
/* 227 */               } else if (str2.equals("saveAdminRoleUsers")) {
/* 228 */                 localObject2 = (String)arrayOfObject[0];
/* 229 */                 localObject3 = (List)arrayOfObject[2];
/* 230 */                 str4 = userListToUserIds((List)localObject3);
/* 231 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 232 */                   (String)localObject2 + "的管理角色与id为" + str4 + "用户之间的关联。", 
/* 233 */                   str2);
/* 234 */               } else if (str2.equals("updateAdminRole")) {
/* 235 */                 localObject2 = (AdminRole)arrayOfObject[0];
/* 236 */                 this.logger.log(str1 + "在" + str3 + "修改id为" + 
/* 237 */                   ((AdminRole)localObject2).getId() + "的管理角色。", str2);
/* 238 */               } else if (str2.equals("updateAdminRoleUnitStatus")) {
/* 239 */                 localObject2 = (String)arrayOfObject[0];
/* 240 */                 this.logger.log(str1 + "在" + str3 + "修改id为" + 
/* 241 */                   (String)localObject2 + "管理角色的组织范围权限。", str2);
/*     */               }
/* 244 */               else if (str2.equals("deleteBusiRoleById")) {
/* 245 */                 localObject2 = (String)arrayOfObject[0];
/* 246 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 247 */                   (String)localObject2 + "业务角色。", str2);
/* 248 */               } else if (str2.equals("deleteBusiRoleUser")) {
/* 249 */                 localObject2 = (String)arrayOfObject[0];
/* 250 */                 localObject3 = (String)arrayOfObject[1];
/* 251 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 252 */                   (String)localObject2 + "业务角色与id为" + (String)localObject3 + "用户之间的关联。", 
/* 253 */                   str2);
/* 254 */               } else if (str2.equals("deleteBusiRoleUserByUserId")) {
/* 255 */                 localObject2 = (String)arrayOfObject[0];
/* 256 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 257 */                   (String)localObject2 + "用户与业务角色之间的关联。", str2);
/* 258 */               } else if (str2.equals("saveBusiRole")) {
/* 259 */                 localObject2 = (BusiRole)arrayOfObject[0];
/* 260 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 261 */                   ((BusiRole)localObject2).getId() + "业务角色。", str2);
/* 262 */               } else if (str2.equals("saveBusiRoleUsers")) {
/* 263 */                 localObject2 = (String)arrayOfObject[0];
/* 264 */                 localObject3 = (List)arrayOfObject[1];
/* 265 */                 str4 = userListToUserIds((List)localObject3);
/* 266 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 267 */                   (String)localObject2 + "业务角色与id为" + str4 + "用户之间的关联。", 
/* 268 */                   str2);
/* 269 */               } else if (str2.equals("updateBusiRole")) {
/* 270 */                 localObject2 = (BusiRole)arrayOfObject[0];
/* 271 */                 this.logger.log(str1 + "在" + str3 + "修改id为" + 
/* 272 */                   ((BusiRole)localObject2).getId() + "业务角色。", str2);
/*     */               }
/* 275 */               else if (str2.equals("savePageAuthorities")) {
/* 276 */                 this.logger.log(str1 + "在" + str3 + "修改页面权限。", 
/* 277 */                   str2);
/*     */               }
/* 280 */               else if (str2.equals("deleteAdminRoleBusiRoles")) {
/* 281 */                 localObject2 = (String)arrayOfObject[0];
/* 282 */                 localObject3 = (List)arrayOfObject[1];
/* 283 */                 str4 = busiRoleListToBusiRoleIds((List)localObject3);
/* 284 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 285 */                   (String)localObject2 + "管理角色与id为" + str4 + 
/* 286 */                   "业务角色之间的关联。", str2);
/* 287 */               } else if (str2.equals("deleteSecAdminRole")) {
/* 288 */                 localObject2 = (String)arrayOfObject[0];
/* 289 */                 this.logger.log(str1 + "在" + str3 + "删除id为" + 
/* 290 */                   (String)localObject2 + "管理角色。", str2);
/* 291 */               } else if (str2.equals("saveAdminRoleBusiRoles")) {
/* 292 */                 localObject2 = (String)arrayOfObject[0];
/* 293 */                 localObject3 = (List)arrayOfObject[1];
/* 294 */                 str4 = busiRoleListToBusiRoleIds((List)localObject3);
/* 295 */                 this.logger.log(str1 + "在" + str3 + "新增id为" + 
/* 296 */                   (String)localObject2 + "管理角色与id为" + str4 + 
/* 297 */                   "业务角色之间的关联。", str2);
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 301 */     return localObject1;
/*     */   }
/*     */ 
/*     */   private String userListToUserIds(List paramList)
/*     */   {
/* 312 */     String str = "";
/* 313 */     for (int i = 0; i < paramList.size(); i++) {
/* 314 */       com.neusoft.unieap.techcomp.org.entity.User localUser = 
/* 315 */         (com.neusoft.unieap.techcomp.org.entity.User)paramList
/* 315 */         .get(i);
/* 316 */       if (i == 0)
/* 317 */         str = localUser.getId();
/*     */       else
/* 319 */         str = str + "," + localUser.getId();
/*     */     }
/* 321 */     return str;
/*     */   }
/*     */ 
/*     */   private String busiRoleListToBusiRoleIds(List paramList)
/*     */   {
/* 332 */     String str = "";
/* 333 */     for (int i = 0; i < paramList.size(); i++) {
/* 334 */       BusiRole localBusiRole = (BusiRole)paramList.get(i);
/* 335 */       if (i == 0)
/* 336 */         str = localBusiRole.getId();
/*     */       else
/* 338 */         str = str + "," + localBusiRole.getId();
/*     */     }
/* 340 */     return str;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.audit.AuditInterceptor
 * JD-Core Version:    0.6.2
 */