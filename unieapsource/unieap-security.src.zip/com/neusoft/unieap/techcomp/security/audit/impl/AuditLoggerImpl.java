/*    */ package com.neusoft.unieap.techcomp.security.audit.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.security.audit.AuditLogger;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class AuditLoggerImpl
/*    */   implements AuditLogger
/*    */ {
/* 10 */   final Log logger = LogFactory.getLog(AuditLogger.class);
/*    */ 
/*    */   public void log(String paramString1, String paramString2)
/*    */   {
/* 16 */     this.logger.info(paramString1);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.audit.impl.AuditLoggerImpl
 * JD-Core Version:    0.6.2
 */