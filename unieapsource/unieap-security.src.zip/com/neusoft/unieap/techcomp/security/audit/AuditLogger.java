package com.neusoft.unieap.techcomp.security.audit;

public abstract interface AuditLogger
{
  public abstract void log(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.audit.AuditLogger
 * JD-Core Version:    0.6.2
 */