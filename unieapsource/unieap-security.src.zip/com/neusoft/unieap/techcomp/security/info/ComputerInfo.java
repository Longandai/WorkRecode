/*    */ package com.neusoft.unieap.techcomp.security.info;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ 
/*    */ public class ComputerInfo
/*    */ {
/*    */   public void computerInfo(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 16 */     HttpSession localHttpSession = ServletActionContext.getRequest().getSession(false);
/* 17 */     if (localHttpSession != null) {
/* 18 */       localHttpSession.setAttribute("computerName", paramString1);
/* 19 */       localHttpSession.setAttribute("IpAddress", paramString2);
/* 20 */       localHttpSession.setAttribute("macAddress", paramString3);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.info.ComputerInfo
 * JD-Core Version:    0.6.2
 */