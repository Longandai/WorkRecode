/*    */ package com.neusoft.unieap.techcomp.security;
/*    */ 
/*    */ public class SecurityConfig
/*    */ {
/*  6 */   private boolean dialogRelogin = true;
/*    */ 
/*    */   public void setDialogRelogin(boolean paramBoolean) {
/*  9 */     this.dialogRelogin = paramBoolean;
/*    */   }
/*    */ 
/*    */   public boolean isDialogRelogin() {
/* 13 */     return this.dialogRelogin;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.SecurityConfig
 * JD-Core Version:    0.6.2
 */