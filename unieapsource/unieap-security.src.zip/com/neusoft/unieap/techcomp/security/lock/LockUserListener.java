/*    */ package com.neusoft.unieap.techcomp.security.lock;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.security.dao.providers.SecurityUser;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.security.Authentication;
/*    */ import org.springframework.security.event.authentication.AuthenticationFailureBadCredentialsEvent;
/*    */ import org.springframework.security.event.authentication.AuthenticationSuccessEvent;
/*    */ 
/*    */ public class LockUserListener
/*    */   implements ApplicationListener
/*    */ {
/* 16 */   private Map userFailLoginList = new HashMap();
/*    */   private boolean lock;
/*    */   private int lockNumber;
/*    */ 
/*    */   public void onApplicationEvent(ApplicationEvent paramApplicationEvent)
/*    */   {
/*    */     Object localObject1;
/*    */     Authentication localAuthentication;
/*    */     Object localObject2;
/* 24 */     if ((paramApplicationEvent instanceof AuthenticationFailureBadCredentialsEvent)) {
/* 25 */       localObject1 = (AuthenticationFailureBadCredentialsEvent)paramApplicationEvent;
/* 26 */       localAuthentication = (Authentication)((AuthenticationFailureBadCredentialsEvent)localObject1)
/* 27 */         .getSource();
/* 28 */       localObject2 = (String)localAuthentication.getPrincipal();
/* 29 */       addCount((String)localObject2);
/*    */     }
/*    */ 
/* 32 */     if ((paramApplicationEvent instanceof AuthenticationSuccessEvent)) {
/* 33 */       localObject1 = (AuthenticationSuccessEvent)paramApplicationEvent;
/* 34 */       localAuthentication = (Authentication)((AuthenticationSuccessEvent)localObject1)
/* 35 */         .getSource();
/* 36 */       localObject2 = (SecurityUser)localAuthentication
/* 37 */         .getPrincipal();
/* 38 */       String str = ((SecurityUser)localObject2).getUsername();
/* 39 */       cleanCount(str);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void addCount(String paramString) {
/* 44 */     Integer localInteger = (Integer)this.userFailLoginList.get(paramString);
/* 45 */     if (localInteger == null) {
/* 46 */       this.userFailLoginList.put(paramString, Integer.valueOf(1));
/*    */     } else {
/* 48 */       int i = localInteger.intValue() + 1;
/* 49 */       this.userFailLoginList.put(paramString, Integer.valueOf(i));
/*    */     }
/*    */   }
/*    */ 
/*    */   public void cleanCount(String paramString) {
/* 54 */     if (this.userFailLoginList.containsKey(paramString))
/* 55 */       this.userFailLoginList.remove(paramString);
/*    */   }
/*    */ 
/*    */   public Map getUserFailLoginList()
/*    */   {
/* 60 */     return this.userFailLoginList;
/*    */   }
/*    */ 
/*    */   public boolean isLock() {
/* 64 */     return this.lock;
/*    */   }
/*    */ 
/*    */   public void setLock(boolean paramBoolean) {
/* 68 */     this.lock = paramBoolean;
/*    */   }
/*    */ 
/*    */   public int getLockNumber() {
/* 72 */     return this.lockNumber;
/*    */   }
/*    */ 
/*    */   public void setLockNumber(int paramInt) {
/* 76 */     this.lockNumber = paramInt;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.lock.LockUserListener
 * JD-Core Version:    0.6.2
 */