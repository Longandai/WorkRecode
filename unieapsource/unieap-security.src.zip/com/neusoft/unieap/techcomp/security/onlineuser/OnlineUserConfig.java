/*    */ package com.neusoft.unieap.techcomp.security.onlineuser;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class OnlineUserConfig
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -7596423594999765846L;
/*  7 */   private boolean enabled = true;
/*    */ 
/*    */   public void setEnabled(boolean paramBoolean) {
/* 10 */     this.enabled = paramBoolean;
/*    */   }
/*    */ 
/*    */   public boolean isEnabled() {
/* 14 */     return this.enabled;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.onlineuser.OnlineUserConfig
 * JD-Core Version:    0.6.2
 */