/*    */ package com.neusoft.unieap.techcomp.security.context;
/*    */ 
/*    */ public class UniEAPSecurityContextHolder
/*    */ {
/* 11 */   private static ThreadLocal contextHolder = new ThreadLocal();
/*    */ 
/*    */   public static void setContext(UniEAPSecurityContext paramUniEAPSecurityContext)
/*    */   {
/* 18 */     contextHolder.set(paramUniEAPSecurityContext);
/*    */   }
/*    */ 
/*    */   public static UniEAPSecurityContext getContext()
/*    */   {
/* 26 */     return (UniEAPSecurityContext)contextHolder.get();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.context.UniEAPSecurityContextHolder
 * JD-Core Version:    0.6.2
 */