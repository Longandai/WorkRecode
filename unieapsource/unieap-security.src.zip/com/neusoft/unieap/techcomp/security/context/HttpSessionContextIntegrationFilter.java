/*     */ package com.neusoft.unieap.techcomp.security.context;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Method;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.AuthenticationTrustResolver;
/*     */ import org.springframework.security.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.context.SecurityContext;
/*     */ import org.springframework.security.context.SecurityContextHolder;
/*     */ import org.springframework.security.context.SecurityContextImpl;
/*     */ import org.springframework.security.ui.FilterChainOrder;
/*     */ import org.springframework.security.ui.SpringSecurityFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class HttpSessionContextIntegrationFilter extends SpringSecurityFilter
/*     */   implements InitializingBean
/*     */ {
/*     */   static final String FILTER_APPLIED = "__spring_security_session_integration_filter_applied";
/*     */   public static final String SPRING_SECURITY_CONTEXT_KEY = "SPRING_SECURITY_CONTEXT";
/* 116 */   private Class contextClass = SecurityContextImpl.class;
/*     */   private Object contextObject;
/* 128 */   private boolean allowSessionCreation = true;
/*     */ 
/* 144 */   private boolean forceEagerSessionCreation = false;
/*     */ 
/* 161 */   private boolean cloneFromHttpSession = false;
/*     */ 
/* 163 */   private AuthenticationTrustResolver authenticationTrustResolver = new AuthenticationTrustResolverImpl();
/*     */ 
/*     */   public boolean isCloneFromHttpSession() {
/* 166 */     return this.cloneFromHttpSession;
/*     */   }
/*     */ 
/*     */   public void setCloneFromHttpSession(boolean paramBoolean) {
/* 170 */     this.cloneFromHttpSession = paramBoolean;
/*     */   }
/*     */ 
/*     */   public HttpSessionContextIntegrationFilter() throws ServletException {
/* 174 */     this.contextObject = generateNewContext();
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 180 */     if ((this.contextClass == null) || (!SecurityContext.class.isAssignableFrom(this.contextClass))) {
/* 181 */       throw new IllegalArgumentException("context must be defined and implement SecurityContext (typically use org.springframework.security.context.SecurityContextImpl; existing class is " + 
/* 183 */         this.contextClass + ")");
/*     */     }
/*     */ 
/* 186 */     if ((this.forceEagerSessionCreation) && (!this.allowSessionCreation)) {
/* 187 */       throw new IllegalArgumentException(
/* 188 */         "If using forceEagerSessionCreation, you must set allowSessionCreation to also be true");
/*     */     }
/*     */ 
/* 191 */     this.contextObject = generateNewContext();
/*     */   }
/*     */ 
/*     */   public void doFilterHttp(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws IOException, ServletException
/*     */   {
/* 197 */     if (paramHttpServletRequest.getAttribute("__spring_security_session_integration_filter_applied") != null)
/*     */     {
/* 199 */       paramFilterChain.doFilter(paramHttpServletRequest, paramHttpServletResponse);
/* 200 */       return;
/*     */     }
/*     */ 
/* 203 */     HttpSession localHttpSession = safeGetSession(paramHttpServletRequest, this.forceEagerSessionCreation);
/* 204 */     boolean bool = localHttpSession != null;
/* 205 */     SecurityContext localSecurityContext1 = readSecurityContextFromSession(localHttpSession);
/*     */ 
/* 209 */     localHttpSession = null;
/*     */ 
/* 211 */     if (localSecurityContext1 == null) {
/* 212 */       localSecurityContext1 = generateNewContext();
/*     */ 
/* 214 */       if (this.logger.isDebugEnabled()) {
/* 215 */         this.logger.debug("New SecurityContext instance will be associated with SecurityContextHolder");
/*     */       }
/*     */     }
/* 218 */     else if (this.logger.isDebugEnabled()) {
/* 219 */       this.logger.debug("Obtained a valid SecurityContext from SPRING_SECURITY_CONTEXT to associate with SecurityContextHolder: '" + 
/* 220 */         localSecurityContext1 + "'");
/*     */     }
/*     */ 
/* 224 */     int i = localSecurityContext1.hashCode();
/* 225 */     paramHttpServletRequest.setAttribute("__spring_security_session_integration_filter_applied", Boolean.TRUE);
/*     */ 
/* 231 */     OnRedirectUpdateSessionResponseWrapper localOnRedirectUpdateSessionResponseWrapper = 
/* 232 */       new OnRedirectUpdateSessionResponseWrapper(paramHttpServletResponse, paramHttpServletRequest, 
/* 233 */       bool, i);
/*     */     SecurityContext localSecurityContext2;
/*     */     try
/*     */     {
/* 239 */       SecurityContextHolder.setContext(localSecurityContext1);
/*     */ 
/* 241 */       paramFilterChain.doFilter(paramHttpServletRequest, localOnRedirectUpdateSessionResponseWrapper);
/*     */     }
/*     */     finally
/*     */     {
/* 245 */       localSecurityContext2 = SecurityContextHolder.getContext();
/*     */ 
/* 248 */       SecurityContextHolder.clearContext();
/*     */ 
/* 250 */       localHttpSession = safeGetSession(paramHttpServletRequest, this.forceEagerSessionCreation);
/*     */ 
/* 252 */       paramHttpServletRequest.removeAttribute("__spring_security_session_integration_filter_applied");
/*     */ 
/* 257 */       if (!localOnRedirectUpdateSessionResponseWrapper.isSessionUpdateDone()) {
/* 258 */         storeSecurityContextInSession(localSecurityContext2, paramHttpServletRequest, 
/* 259 */           bool, i);
/*     */       }
/*     */ 
/* 262 */       if (this.logger.isDebugEnabled())
/* 263 */         this.logger.debug("SecurityContextHolder now cleared, as request processing completed");
/*     */     }
/*     */   }
/*     */ 
/*     */   private SecurityContext readSecurityContextFromSession(HttpSession paramHttpSession)
/*     */   {
/* 280 */     if (paramHttpSession == null) {
/* 281 */       if (this.logger.isDebugEnabled()) {
/* 282 */         this.logger.debug("No HttpSession currently exists");
/*     */       }
/*     */ 
/* 285 */       return null;
/*     */     }
/*     */ 
/* 290 */     Object localObject = paramHttpSession.getAttribute("SPRING_SECURITY_CONTEXT");
/*     */ 
/* 292 */     if (localObject == null) {
/* 293 */       if (this.logger.isDebugEnabled()) {
/* 294 */         this.logger.debug("HttpSession returned null object for SPRING_SECURITY_CONTEXT");
/*     */       }
/*     */ 
/* 297 */       return null;
/*     */     }
/*     */ 
/* 303 */     if (this.cloneFromHttpSession) {
/* 304 */       Assert.isInstanceOf(Cloneable.class, localObject, 
/* 305 */         "Context must implement Clonable and provide a Object.clone() method");
/*     */       try {
/* 307 */         Method localMethod = localObject.getClass().getMethod("clone", new Class[0]);
/* 308 */         if (!localMethod.isAccessible()) {
/* 309 */           localMethod.setAccessible(true);
/*     */         }
/* 311 */         localObject = localMethod.invoke(localObject, new Object[0]);
/*     */       }
/*     */       catch (Exception localException) {
/* 314 */         ReflectionUtils.handleReflectionException(localException);
/*     */       }
/*     */     }
/*     */ 
/* 318 */     if (!(localObject instanceof SecurityContext)) {
/* 319 */       if (this.logger.isWarnEnabled()) {
/* 320 */         this.logger.warn("SPRING_SECURITY_CONTEXT did not contain a SecurityContext but contained: '" + 
/* 321 */           localObject + 
/* 322 */           "'; are you improperly modifying the HttpSession directly " + 
/* 323 */           "(you should always use SecurityContextHolder) or using the HttpSession attribute " + 
/* 324 */           "reserved for this class?");
/*     */       }
/*     */ 
/* 327 */       return null;
/*     */     }
/*     */ 
/* 332 */     return (SecurityContext)localObject;
/*     */   }
/*     */ 
/*     */   private void storeSecurityContextInSession(SecurityContext paramSecurityContext, HttpServletRequest paramHttpServletRequest, boolean paramBoolean, int paramInt)
/*     */   {
/* 356 */     HttpSession localHttpSession = safeGetSession(paramHttpServletRequest, false);
/*     */ 
/* 358 */     if (localHttpSession == null) {
/* 359 */       if (paramBoolean) {
/* 360 */         if (this.logger.isDebugEnabled()) {
/* 361 */           this.logger.debug("HttpSession is now null, but was not null at start of request; session was invalidated, so do not create a new session");
/*     */         }
/*     */ 
/*     */       }
/* 367 */       else if (!this.allowSessionCreation) {
/* 368 */         if (this.logger.isDebugEnabled()) {
/* 369 */           this.logger.debug("The HttpSession is currently null, and the HttpSessionContextIntegrationFilter is prohibited from creating an HttpSession (because the allowSessionCreation property is false) - SecurityContext thus not stored for next request");
/*     */         }
/*     */ 
/*     */       }
/* 374 */       else if (!this.contextObject.equals(paramSecurityContext)) {
/* 375 */         if (this.logger.isDebugEnabled()) {
/* 376 */           this.logger.debug("HttpSession being created as SecurityContextHolder contents are non-default");
/*     */         }
/*     */ 
/* 379 */         localHttpSession = safeGetSession(paramHttpServletRequest, true);
/*     */       }
/* 382 */       else if (this.logger.isDebugEnabled()) {
/* 383 */         this.logger.debug("HttpSession is null, but SecurityContextHolder has not changed from default: ' " + 
/* 384 */           paramSecurityContext + 
/* 385 */           "'; not creating HttpSession or storing SecurityContextHolder contents");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 393 */     if ((localHttpSession != null) && (paramSecurityContext.hashCode() != paramInt))
/*     */     {
/* 395 */       if (this.authenticationTrustResolver.isAnonymous(paramSecurityContext.getAuthentication())) {
/* 396 */         if (this.logger.isDebugEnabled())
/* 397 */           this.logger.debug("SecurityContext contents are anonymous - context will not be stored in HttpSession. ");
/*     */       }
/*     */       else {
/* 400 */         localHttpSession.setAttribute("SPRING_SECURITY_CONTEXT", paramSecurityContext);
/*     */ 
/* 406 */         if (this.logger.isDebugEnabled())
/* 407 */           this.logger.debug("SecurityContext stored to HttpSession: '" + paramSecurityContext + "'");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private HttpSession safeGetSession(HttpServletRequest paramHttpServletRequest, boolean paramBoolean)
/*     */   {
/*     */     try {
/* 415 */       return paramHttpServletRequest.getSession(paramBoolean);
/*     */     } catch (IllegalStateException localIllegalStateException) {
/*     */     }
/* 418 */     return null;
/*     */   }
/*     */ 
/*     */   public SecurityContext generateNewContext() throws ServletException
/*     */   {
/*     */     try {
/* 424 */       return (SecurityContext)this.contextClass.newInstance();
/*     */     }
/*     */     catch (InstantiationException localInstantiationException) {
/* 427 */       throw new ServletException(localInstantiationException);
/*     */     }
/*     */     catch (IllegalAccessException localIllegalAccessException) {
/* 430 */       throw new ServletException(localIllegalAccessException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isAllowSessionCreation() {
/* 435 */     return this.allowSessionCreation;
/*     */   }
/*     */ 
/*     */   public void setAllowSessionCreation(boolean paramBoolean) {
/* 439 */     this.allowSessionCreation = paramBoolean;
/*     */   }
/*     */ 
/*     */   protected Class getContextClass() {
/* 443 */     return this.contextClass;
/*     */   }
/*     */ 
/*     */   public void setContextClass(Class paramClass) {
/* 447 */     this.contextClass = paramClass;
/*     */   }
/*     */ 
/*     */   public boolean isForceEagerSessionCreation() {
/* 451 */     return this.forceEagerSessionCreation;
/*     */   }
/*     */ 
/*     */   public void setForceEagerSessionCreation(boolean paramBoolean) {
/* 455 */     this.forceEagerSessionCreation = paramBoolean;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 459 */     return FilterChainOrder.HTTP_SESSION_CONTEXT_FILTER;
/*     */   }
/*     */ 
/*     */   private class OnRedirectUpdateSessionResponseWrapper extends HttpServletResponseWrapper
/*     */   {
/*     */     HttpServletRequest request;
/*     */     boolean httpSessionExistedAtStartOfRequest;
/*     */     int contextHashBeforeChainExecution;
/* 478 */     boolean sessionUpdateDone = false;
/*     */ 
/*     */     public OnRedirectUpdateSessionResponseWrapper(HttpServletResponse paramHttpServletRequest, HttpServletRequest paramBoolean, boolean paramInt, int arg5)
/*     */     {
/* 489 */       super();
/* 490 */       this.request = paramBoolean;
/* 491 */       this.httpSessionExistedAtStartOfRequest = paramInt;
/*     */       int i;
/* 492 */       this.contextHashBeforeChainExecution = i;
/*     */     }
/*     */ 
/*     */     public void sendError(int paramInt)
/*     */       throws IOException
/*     */     {
/* 500 */       doSessionUpdate();
/* 501 */       super.sendError(paramInt);
/*     */     }
/*     */ 
/*     */     public void sendError(int paramInt, String paramString)
/*     */       throws IOException
/*     */     {
/* 509 */       doSessionUpdate();
/* 510 */       super.sendError(paramInt, paramString);
/*     */     }
/*     */ 
/*     */     public void sendRedirect(String paramString)
/*     */       throws IOException
/*     */     {
/* 518 */       doSessionUpdate();
/* 519 */       super.sendRedirect(paramString);
/*     */     }
/*     */ 
/*     */     private void doSessionUpdate()
/*     */     {
/* 526 */       if (this.sessionUpdateDone) {
/* 527 */         return;
/*     */       }
/* 529 */       SecurityContext localSecurityContext = SecurityContextHolder.getContext();
/* 530 */       HttpSessionContextIntegrationFilter.this.storeSecurityContextInSession(localSecurityContext, this.request, 
/* 531 */         this.httpSessionExistedAtStartOfRequest, this.contextHashBeforeChainExecution);
/* 532 */       this.sessionUpdateDone = true;
/*     */     }
/*     */ 
/*     */     public boolean isSessionUpdateDone()
/*     */     {
/* 540 */       return this.sessionUpdateDone;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.context.HttpSessionContextIntegrationFilter
 * JD-Core Version:    0.6.2
 */