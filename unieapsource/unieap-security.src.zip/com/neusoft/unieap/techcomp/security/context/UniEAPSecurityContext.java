package com.neusoft.unieap.techcomp.security.context;

import com.neusoft.unieap.techcomp.org.entity.User;
import java.io.Serializable;
import java.util.Map;

public abstract interface UniEAPSecurityContext extends Serializable
{
  public static final String SECURITY_CONTEXT_KEY = "com.neusoft.unieap.service.security.context.securityContext";

  public abstract void setDimensionID(String paramString);

  public abstract String getDimensionID();

  public abstract void setCurrentUser(User paramUser);

  public abstract User getCurrentUser();

  public abstract Map getResourceContext();

  public abstract void setResourceContext(Map paramMap);

  public abstract Map getCustomProperties();

  public abstract void setCustomProperties(Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.context.UniEAPSecurityContext
 * JD-Core Version:    0.6.2
 */