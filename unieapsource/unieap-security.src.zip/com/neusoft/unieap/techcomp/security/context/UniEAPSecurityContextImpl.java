/*    */ package com.neusoft.unieap.techcomp.security.context;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.org.entity.User;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UniEAPSecurityContextImpl
/*    */   implements UniEAPSecurityContext
/*    */ {
/*    */   private static final long serialVersionUID = 2749571497048719280L;
/*    */   private String dimensionID;
/*    */   private User currentUser;
/* 25 */   private Map resourceContext = new HashMap();
/*    */ 
/* 27 */   private Map customProperties = new HashMap();
/*    */ 
/*    */   public String getDimensionID() {
/* 30 */     return this.dimensionID;
/*    */   }
/*    */ 
/*    */   public void setDimensionID(String paramString) {
/* 34 */     this.dimensionID = paramString;
/*    */   }
/*    */ 
/*    */   public User getCurrentUser() {
/* 38 */     return this.currentUser;
/*    */   }
/*    */ 
/*    */   public void setCurrentUser(User paramUser) {
/* 42 */     this.currentUser = paramUser;
/*    */   }
/*    */ 
/*    */   public Map getResourceContext() {
/* 46 */     return this.resourceContext;
/*    */   }
/*    */ 
/*    */   public void setResourceContext(Map paramMap) {
/* 50 */     this.resourceContext = paramMap;
/*    */   }
/*    */ 
/*    */   public Map getCustomProperties() {
/* 54 */     return this.customProperties;
/*    */   }
/*    */ 
/*    */   public void setCustomProperties(Map paramMap) {
/* 58 */     this.customProperties = paramMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.context.UniEAPSecurityContextImpl
 * JD-Core Version:    0.6.2
 */