/*    */ package com.neusoft.unieap.techcomp.security.i18n;
/*    */ 
/*    */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*    */ 
/*    */ public class I18nUtil
/*    */ {
/*    */   private static I18nUtil instance;
/*    */ 
/*    */   public static synchronized I18nUtil getInstance()
/*    */   {
/*  9 */     if (instance == null)
/* 10 */       instance = new I18nUtil();
/* 11 */     return instance;
/*    */   }
/*    */ 
/*    */   public String getValue(String paramString)
/*    */   {
/* 19 */     return I18nGlobalContext.getInstance().getValue(paramString, "security");
/*    */   }
/*    */ 
/*    */   public String getValue(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 28 */     return I18nGlobalContext.getInstance().getValue(paramString, paramArrayOfObject, "security");
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.i18n.I18nUtil
 * JD-Core Version:    0.6.2
 */