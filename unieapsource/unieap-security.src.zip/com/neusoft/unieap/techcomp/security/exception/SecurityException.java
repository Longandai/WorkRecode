/*    */ package com.neusoft.unieap.techcomp.security.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPException;
/*    */ 
/*    */ public class SecurityException extends UniEAPException
/*    */ {
/*    */   private static final long serialVersionUID = 3574721974874292526L;
/*    */ 
/*    */   public SecurityException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 15 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public SecurityException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 25 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.exception.SecurityException
 * JD-Core Version:    0.6.2
 */