package com.neusoft.unieap.techcomp.security.exception;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public final class SecurityExceptionCode extends UniEAPExceptionCode
{
  private static final String SECURITY_DC = "017";
  public static final String USER_EXISTED = "EAPBIZ017001";

  private SecurityExceptionCode(String paramString)
  {
  }
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.exception.SecurityExceptionCode
 * JD-Core Version:    0.6.2
 */