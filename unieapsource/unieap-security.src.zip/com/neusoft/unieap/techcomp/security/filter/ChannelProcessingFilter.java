/*    */ package com.neusoft.unieap.techcomp.security.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class ChannelProcessingFilter extends org.springframework.security.securechannel.ChannelProcessingFilter
/*    */ {
/* 12 */   private boolean enabled = false;
/*    */ 
/*    */   public void setEnabled(boolean paramBoolean) {
/* 15 */     this.enabled = paramBoolean;
/*    */   }
/*    */   public boolean isEnabled() {
/* 18 */     return this.enabled;
/*    */   }
/*    */ 
/*    */   public void doFilterHttp(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain) throws IOException, ServletException {
/* 22 */     if (this.enabled)
/* 23 */       super.doFilterHttp(paramHttpServletRequest, paramHttpServletResponse, paramFilterChain);
/*    */     else
/* 25 */       paramFilterChain.doFilter(paramHttpServletRequest, paramHttpServletResponse);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.filter.ChannelProcessingFilter
 * JD-Core Version:    0.6.2
 */