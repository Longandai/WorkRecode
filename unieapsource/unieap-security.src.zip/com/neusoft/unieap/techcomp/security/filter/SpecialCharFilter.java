/*     */ package com.neusoft.unieap.techcomp.security.filter;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import java.io.IOException;
/*     */ import java.util.UUID;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletRequestWrapper;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpServletResponseWrapper;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class SpecialCharFilter
/*     */   implements Filter
/*     */ {
/*  25 */   private boolean enabled = false;
/*     */   private String specialChars;
/*     */   private String excludeUrlPrefix;
/*     */   private String errorUrl;
/*     */   private String trustedsites;
/*     */   private String trustedIps;
/*     */ 
/*     */   public void setErrorUrl(String errorUrl)
/*     */   {
/*  35 */     this.errorUrl = errorUrl;
/*     */   }
/*     */   public void init(FilterConfig arg0) throws ServletException {
/*     */   }
/*     */   public void destroy() {
/*     */   }
/*     */   public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
/*  42 */     if (isEnabled())
/*     */     {
/*  44 */       HttpServletResponse httpResponse = (HttpServletResponse)response;
/*  45 */       HttpServletRequest httpRequest = (HttpServletRequest)request;
/*     */ 
/*  48 */       httpResponse.setHeader("Set-Cookie", "name=value; HttpOnly");
/*  49 */       httpResponse.setHeader("Cache-Control", "no-store");
/*  50 */       httpResponse.setHeader("Pragma", "no-cache");
/*  51 */       httpResponse.setDateHeader("Expires", 0L);
/*  52 */       Cookie cookie = new Cookie("timestamp", UUID.randomUUID().toString());
/*     */ 
/*  54 */       cookie.setSecure(true);
/*  55 */       httpResponse.addCookie(cookie);
/*     */ 
/*  58 */       if ((this.specialChars != null) && (!this.specialChars.equals(""))) {
/*  59 */         String contextPath = httpRequest.getContextPath();
/*     */ 
/*  61 */         Pattern patternIP = Pattern.compile("\\b((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\.((?!\\d\\d\\d)\\d+|1\\d\\d|2[0-4]\\d|25[0-5])\\b");
/*     */ 
/*  64 */         String xForwardedFor = httpRequest.getHeader("X-Forwarded-For");
/*  65 */         if (xForwardedFor != null) {
/*  66 */           xForwardedFor = xForwardedFor.split(",")[0];
/*  67 */           Matcher matcherIP = patternIP.matcher(xForwardedFor);
/*  68 */           if (!matcherIP.matches())
/*     */           {
/*  70 */             httpRequest.getRequestDispatcher(this.errorUrl).forward(httpRequest, httpResponse);
/*     */ 
/*  72 */             return;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  77 */         String xForwardedHost = httpRequest.getHeader("X-Forwarded-Host");
/*  78 */         boolean match = false;
/*     */         String str1;
/*     */         String site;
/*  79 */         if (xForwardedHost != null) {
/*  80 */           String[] split = xForwardedHost.split(":");
/*  81 */           if (split.length > 0) {
/*  82 */             Matcher matcherIP = patternIP.matcher(split[0]);
/*  83 */             if (matcherIP.matches())
/*     */             {
/*  85 */               match = true;
/*     */             }
/*  87 */             if ((!match) && 
/*  88 */               (this.trustedsites != null) && (!"".equals(this.trustedsites))) {
/*  89 */               String[] sites = this.trustedsites.split(",");
/*     */               String[] arrayOfString2;
/*  90 */               int i = (arrayOfString2 = sites).length; for (str1 = 0; str1 < i; str1++) { site = arrayOfString2[str1];
/*  91 */                 if (isMatch(site, split[0])) {
/*  92 */                   match = true;
/*  93 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*  99 */           if (!match) {
/* 100 */             httpRequest.getRequestDispatcher(this.errorUrl).forward(httpRequest, httpResponse);
/*     */ 
/* 102 */             return;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 107 */         String referer = httpRequest.getHeader("Referer");
/* 108 */         if (referer != null)
/*     */         {
/* 110 */           match = false;
/* 111 */           if ((this.trustedsites != null) && (!"".equals(this.trustedsites))) {
/* 112 */             String[] sites = this.trustedsites.split(",");
/*     */             String[] arrayOfString1;
/* 113 */             str1 = (arrayOfString1 = sites).length; for (site = 0; site < str1; site++) { String site = arrayOfString1[site];
/* 114 */               if (isMatch(site, referer)) {
/* 115 */                 match = true;
/* 116 */                 break;
/*     */               }
/*     */             }
/*     */           }
/* 120 */           if ((!match) && 
/* 121 */             (referer.indexOf(":") != -1))
/*     */           {
/* 123 */             referer = referer.substring(referer.indexOf(":"));
/* 124 */             String[] split = referer.split(":");
/* 125 */             String ip = split[1].substring(2, split[1].length());
/*     */ 
/* 127 */             if ((this.trustedIps != null) && (!"".equals(this.trustedIps))) {
/* 128 */               String[] ips = this.trustedIps.split(",");
/* 129 */               for (String data : ips) {
/* 130 */                 if (isMatch(data, ip)) {
/* 131 */                   match = true;
/* 132 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/* 136 */             if ((!match) && (
/* 137 */               (referer.indexOf("://" + httpRequest.getServerName()) == -1) || (referer.indexOf(contextPath) == -1))) {
/* 138 */               httpRequest.getRequestDispatcher(this.errorUrl).forward(httpRequest, httpResponse);
/*     */ 
/* 140 */               return;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 147 */         String uri = httpRequest.getRequestURI();
/* 148 */         Pattern pattern = Pattern.compile(".+;.+;.*");
/* 149 */         Matcher matcher = pattern.matcher(uri);
/* 150 */         if (matcher.find()) {
/* 151 */           return;
/*     */         }
/*     */       }
/*     */ 
/* 155 */       String method = request.getParameter("method");
/* 156 */       String url = ((HttpServletRequest)request).getServletPath();
/* 157 */       if ((this.excludeUrlPrefix != null) && (!this.excludeUrlPrefix.equals(""))) {
/* 158 */         String[] urlArr = this.excludeUrlPrefix.split(";");
/* 159 */         for (int i = 0; i < urlArr.length; i++) {
/* 160 */           if ((url.startsWith(urlArr[i])) || ("updateFormData".equalsIgnoreCase(method)) || ("insertFormData".equalsIgnoreCase(method))) {
/* 161 */             filterChain.doFilter(request, response);
/* 162 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 167 */       if ((!url.startsWith("/services")) && (!url.startsWith("/techcomp/ria/commonProcessor!login.action")) && (!url.startsWith("/Report-DocPrintAction")) && (url.indexOf("/jsp/show/Image3.jsp") < 0) && (
/* 168 */         (httpRequest.isRequestedSessionIdFromURL()) || (httpRequest.getParameter("JSESSIONID") != null))) {
/* 169 */         HttpSession session = httpRequest.getSession();
/* 170 */         if (session != null) session.invalidate();
/* 171 */         HttpServletResponseWrapper wrappedResponse = new HttpServletResponseWrapper(httpResponse)
/*     */         {
/*     */           public String encodeRedirectUrl(String url) {
/* 174 */             return url;
/*     */           }
/*     */ 
/*     */           public String encodeRedirectURL(String url) {
/* 178 */             return url;
/*     */           }
/*     */ 
/*     */           public String encodeUrl(String url) {
/* 182 */             return url;
/*     */           }
/*     */ 
/*     */           public String encodeURL(String url) {
/* 186 */             return url;
/*     */           }
/*     */         };
/* 189 */         filterChain.doFilter(new Wrapper((HttpServletRequest)request), wrappedResponse);
/*     */       } else {
/* 191 */         filterChain.doFilter(new Wrapper((HttpServletRequest)request), response);
/*     */       }
/*     */     } else {
/* 194 */       filterChain.doFilter(request, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSpecialChars(String specialChars) {
/* 199 */     this.specialChars = specialChars;
/*     */   }
/*     */ 
/*     */   public String getSpecialChars() {
/* 203 */     return this.specialChars;
/*     */   }
/*     */ 
/*     */   public void setEnabled(boolean enabled) {
/* 207 */     this.enabled = enabled;
/*     */   }
/*     */   public boolean isEnabled() {
/* 210 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public void setExcludeUrlPrefix(String excludeUrlPrefix) {
/* 214 */     this.excludeUrlPrefix = excludeUrlPrefix;
/*     */   }
/*     */   public String getExcludeUrlPrefix() {
/* 217 */     return this.excludeUrlPrefix;
/*     */   }
/*     */ 
/*     */   public void setTrustedsites(String trustedsites) {
/* 221 */     this.trustedsites = trustedsites;
/*     */   }
/*     */   public String getTrustedsites() {
/* 224 */     return this.trustedsites;
/*     */   }
/*     */ 
/*     */   public void setTrustedIps(String trustedIps) {
/* 228 */     this.trustedIps = trustedIps;
/*     */   }
/*     */   public String getTrustedIps() {
/* 231 */     return this.trustedIps;
/*     */   }
/*     */ 
/*     */   private boolean isMatch(String pattern, String str)
/*     */   {
/* 238 */     if ((pattern == null) || (str == null)) {
/* 239 */       return false;
/*     */     }
/* 241 */     int firstIndex = pattern.indexOf('*');
/* 242 */     if (firstIndex == -1) {
/* 243 */       return pattern.equals(str);
/*     */     }
/* 245 */     if (firstIndex == 0) {
/* 246 */       if (pattern.length() == 1) {
/* 247 */         return true;
/*     */       }
/* 249 */       int nextIndex = pattern.indexOf('*', firstIndex + 1);
/* 250 */       if (nextIndex == -1) {
/* 251 */         int locate = str.indexOf(pattern.substring(1));
/* 252 */         if (locate == -1) {
/* 253 */           return false;
/*     */         }
/* 255 */         return true;
/*     */       }
/* 257 */       String part = pattern.substring(1, nextIndex);
/* 258 */       int partIndex = str.indexOf(part);
/* 259 */       while (partIndex != -1) {
/* 260 */         if (isMatch(pattern.substring(nextIndex), str.substring(partIndex + part.length()))) {
/* 261 */           return true;
/*     */         }
/* 263 */         partIndex = str.indexOf(part, partIndex + 1);
/*     */       }
/* 265 */       return false;
/*     */     }
/*     */ 
/* 269 */     return (str.length() >= firstIndex) && 
/* 268 */       (pattern.substring(0, firstIndex).equals(str.substring(0, firstIndex))) && 
/* 269 */       (isMatch(pattern.substring(firstIndex), str.substring(firstIndex)));
/*     */   }
/*     */ 
/*     */   class Wrapper extends HttpServletRequestWrapper
/*     */   {
/*     */     public Wrapper(HttpServletRequest request) {
/* 275 */       super();
/*     */     }
/*     */ 
/*     */     public String getParameter(String name) {
/* 279 */       String value = super.getParameter(name);
/*     */ 
/* 281 */       if (("j_password".equals(name)) || ("eap_password".equals(name))) {
/* 282 */         return value;
/*     */       }
/*     */ 
/* 285 */       if ((CoreVariability.isUrlPasswordEncrypt()) && 
/* 286 */         ("eap_username".equals(name))) {
/* 287 */         return value;
/*     */       }
/*     */ 
/* 290 */       if (value != null)
/*     */       {
/* 292 */         if (("data".equals(name)) || ("dc".equals(name)) || ("_forwardDataCenter".equals(name))) {
/* 293 */           return value;
/*     */         }
/*     */ 
/* 297 */         String reg = "window|location|script|alert|SCRIPT|ALERT|select | from | on | and | or |SELECT | FROM | ON | AND | OR |%3C|%27|%22|%3E|%3D|%2F";
/* 298 */         value = value.replaceAll(reg, "_");
/*     */ 
/* 300 */         Pattern p = Pattern.compile("[" + SpecialCharFilter.this.specialChars + "]");
/* 301 */         Matcher m = p.matcher(value);
/* 302 */         if (m.find())
/* 303 */           value = m.replaceAll("_");
/*     */       }
/* 305 */       return value;
/*     */     }
/*     */ 
/*     */     public String[] getParameterValues(String name)
/*     */     {
/* 310 */       String[] valueArray = super.getParameterValues(name);
/* 311 */       String filterChars = "['`~!@#$^&*()+=\\<>/?~！@#￥……&*（）——+{}【】‘；”“’。，、？]";
/*     */ 
/* 313 */       if (valueArray != null)
/*     */       {
/* 315 */         if ("xmlStr".equalsIgnoreCase(name)) {
/* 316 */           filterChars = filterChars.replace("=", "");
/* 317 */           filterChars = filterChars.replace("/", "");
/* 318 */           filterChars = filterChars.replace("<", "");
/* 319 */           filterChars = filterChars.replace(">", "");
/* 320 */           filterChars = filterChars.replace("'", "");
/*     */         }
/* 322 */         if ("customProperties".equalsIgnoreCase(name)) {
/* 323 */           filterChars = filterChars.replace("=", "");
/* 324 */           filterChars = filterChars.replace("/", "");
/* 325 */           filterChars = filterChars.replace("<", "");
/* 326 */           filterChars = filterChars.replace(">", "");
/* 327 */           filterChars = filterChars.replace("'", "");
/*     */         }
/*     */ 
/* 330 */         String regex = filterChars + "|window|location|script|alert|SCRIPT|ALERT|select | from | on | and | or |SELECT | FROM | ON | AND | OR |%3C|%27|%22|%3E|%3D|%2F|%7C|%28|%29";
/* 331 */         for (int i = 0; i < valueArray.length; i++) {
/* 332 */           String value = valueArray[i];
/* 333 */           String notFilterStr1 = "alertDuration";
/* 334 */           String replaceStr1 = "replaceDuration";
/* 335 */           String notFilterStr2 = "alertAction";
/* 336 */           String replaceStr2 = "replaceAction";
/* 337 */           String notFilterStr3 = "description";
/* 338 */           String replaceStr3 = "dereplaceion";
/*     */ 
/* 340 */           value = value.replaceAll(notFilterStr1, replaceStr1);
/* 341 */           value = value.replaceAll(notFilterStr2, replaceStr2);
/* 342 */           value = value.replaceAll(notFilterStr3, replaceStr3);
/*     */ 
/* 344 */           value = value.replaceAll(regex, "_");
/*     */ 
/* 346 */           value = value.replaceAll(replaceStr1, notFilterStr1);
/* 347 */           value = value.replaceAll(replaceStr2, notFilterStr2);
/* 348 */           value = value.replaceAll(replaceStr3, notFilterStr3);
/*     */ 
/* 350 */           valueArray[i] = value;
/*     */         }
/*     */       }
/* 353 */       return valueArray;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.filter.SpecialCharFilter
 * JD-Core Version:    0.6.2
 */