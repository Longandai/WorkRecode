/*     */ package com.neusoft.unieap.techcomp.security.vote;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.ConfigAttribute;
/*     */ import org.springframework.security.ConfigAttributeDefinition;
/*     */ import org.springframework.security.GrantedAuthority;
/*     */ import org.springframework.security.intercept.web.FilterInvocation;
/*     */ import org.springframework.security.vote.AccessDecisionVoter;
/*     */ 
/*     */ public class UniEAPUrlVoter
/*     */   implements AccessDecisionVoter
/*     */ {
/*  67 */   private String rolePrefix = "UNIEAP";
/*     */   private MenuAuthBO menuAuthBO;
/*     */   private MenuBO menuBO;
/*     */   private String excludeUrlPrefix;
/*     */ 
/*     */   public void setExcludeUrlPrefix(String excludeUrlPrefix)
/*     */   {
/*  76 */     this.excludeUrlPrefix = excludeUrlPrefix;
/*     */   }
/*     */ 
/*     */   public void setMenuBO(MenuBO menuBO) {
/*  80 */     this.menuBO = menuBO;
/*     */   }
/*     */ 
/*     */   public String getRolePrefix() {
/*  84 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */   public void setRolePrefix(String rolePrefix)
/*     */   {
/*  95 */     this.rolePrefix = rolePrefix;
/*     */   }
/*     */ 
/*     */   public boolean supports(ConfigAttribute attribute) {
/*  99 */     if ((attribute.getAttribute() != null) && 
/* 100 */       (attribute.getAttribute().startsWith(getRolePrefix()))) {
/* 101 */       return true;
/*     */     }
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class clazz)
/*     */   {
/* 117 */     return true;
/*     */   }
/*     */ 
/*     */   public int vote(Authentication authentication, Object object, ConfigAttributeDefinition config)
/*     */   {
/* 122 */     if ((object instanceof FilterInvocation)) {
/* 123 */       FilterInvocation fi = (FilterInvocation)object;
/* 124 */       List menus = this.menuBO.getAllMenus();
/* 125 */       Collection collection = config.getConfigAttributes();
/* 126 */       Iterator iter = collection.iterator();
/* 127 */       while (iter.hasNext()) {
/* 128 */         ConfigAttribute attribute = (ConfigAttribute)iter.next();
/* 129 */         if (supports(attribute)) {
/* 130 */           int value = isinclude(fi.getHttpRequest(), menus);
/* 131 */           if (value == 2)
/* 132 */             return -1;
/* 133 */           if (value == 1) {
/* 134 */             return 1;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 139 */     return 1;
/*     */   }
/*     */ 
/*     */   GrantedAuthority[] extractAuthorities(Authentication authentication) {
/* 143 */     return authentication.getAuthorities();
/*     */   }
/*     */ 
/*     */   protected int isinclude(HttpServletRequest request, List menus)
/*     */   {
/* 156 */     String requestURL = request.getRequestURI();
/* 157 */     requestURL = requestURL.substring(1);
/*     */ 
/* 159 */     while (requestURL.indexOf("//") > -1) {
/* 160 */       requestURL = requestURL.replaceAll("//", "/");
/*     */     }
/* 162 */     requestURL = requestURL.substring(requestURL.indexOf("/") + 1);
/*     */ 
/* 164 */     int isincluded = 0;
/* 165 */     Menu menu = null;
/*     */ 
/* 167 */     List allowedAppMenus = this.menuAuthBO.getAllowedMenus(menus);
/*     */ 
/* 169 */     String tempLocation = "";
/* 170 */     String[] locations = new String[1];
/* 171 */     boolean isInMenu = false;
/* 172 */     for (int i = 0; i < menus.size(); i++) {
/* 173 */       menu = (Menu)menus.get(i);
/* 174 */       tempLocation = menu.getUrl();
/* 175 */       if ((tempLocation != null) && (!tempLocation.equalsIgnoreCase("")))
/*     */       {
/* 177 */         if ((this.excludeUrlPrefix != null) && (!this.excludeUrlPrefix.equals(""))) {
/* 178 */           String url = request.getServletPath();
/* 179 */           String queryString = request.getQueryString();
/* 180 */           String[] urlArr = this.excludeUrlPrefix.split(";");
/* 181 */           locations[0] = tempLocation;
/* 182 */           if ((!requestURL.equalsIgnoreCase("")) && (locations.length >= 1) && 
/* 183 */             (locations[0].indexOf("/" + requestURL) == 0)) {
/* 184 */             boolean flag = false;
/* 185 */             for (int j = 0; j < urlArr.length; j++)
/* 186 */               if (url.startsWith(urlArr[j])) {
/* 187 */                 isincluded = 2;
/* 188 */                 String queryString1 = queryString;
/* 189 */                 if ((queryString != null) && (!queryString.equals(""))) {
/* 190 */                   int index = queryString.indexOf("&unieapMenuId=");
/* 191 */                   if (index == -1)
/* 192 */                     index = queryString.indexOf("unieapMenuId=");
/* 193 */                   if (index != -1)
/* 194 */                     queryString1 = queryString.substring(0, index);
/*     */                 }
/* 196 */                 String requestURLWithParm = requestURL;
/* 197 */                 if ((queryString1 != null) && (!queryString1.equals(""))) {
/* 198 */                   requestURLWithParm = requestURL + "?" + queryString1;
/*     */                 }
/* 200 */                 if (locations[0].equals("/" + requestURLWithParm)) {
/* 201 */                   isInMenu = true;
/* 202 */                   if ((isInMenu) && (this.menuBO.isUrlInclude(menu, allowedAppMenus))) {
/* 203 */                     isincluded = 1;
/* 204 */                     break;
/*     */                   }
/*     */                 } else {
/* 207 */                   flag = true;
/*     */                 }
/*     */               }
/* 210 */             if (flag) break;
/*     */           }
/*     */         }
/* 213 */         if (isincluded != 1) {
/* 214 */           locations = tempLocation.split("\\?");
/* 215 */           if ((!requestURL.equalsIgnoreCase("")) && (locations.length >= 1) && 
/* 216 */             (locations[0].equals("/" + requestURL))) {
/* 217 */             isInMenu = true;
/* 218 */             if ((isInMenu) && (this.menuBO.isUrlInclude(menu, allowedAppMenus))) {
/* 219 */               isincluded = 1;
/* 220 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 227 */     if ((isInMenu) && (isincluded != 1)) {
/* 228 */       isincluded = 2;
/*     */     }
/* 230 */     return isincluded;
/*     */   }
/*     */ 
/*     */   public void setMenuAuthBO(MenuAuthBO menuAuthBO) {
/* 234 */     this.menuAuthBO = menuAuthBO;
/*     */   }
/*     */ 
/*     */   public MenuAuthBO getMenuAuthBO() {
/* 238 */     return this.menuAuthBO;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.vote.UniEAPUrlVoter
 * JD-Core Version:    0.6.2
 */