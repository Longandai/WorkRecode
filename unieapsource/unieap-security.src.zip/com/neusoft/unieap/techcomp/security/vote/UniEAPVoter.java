/*     */ package com.neusoft.unieap.techcomp.security.vote;
/*     */ 
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.ConfigAttribute;
/*     */ import org.springframework.security.ConfigAttributeDefinition;
/*     */ import org.springframework.security.GrantedAuthority;
/*     */ import org.springframework.security.vote.AccessDecisionVoter;
/*     */ 
/*     */ public class UniEAPVoter
/*     */   implements AccessDecisionVoter
/*     */ {
/*  55 */   private String rolePrefix = "UNIEAP";
/*     */ 
/*     */   public String getRolePrefix()
/*     */   {
/*  60 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */   public void setRolePrefix(String paramString)
/*     */   {
/*  70 */     this.rolePrefix = paramString;
/*     */   }
/*     */ 
/*     */   public boolean supports(ConfigAttribute paramConfigAttribute) {
/*  74 */     if ((paramConfigAttribute.getAttribute() != null) && (paramConfigAttribute.getAttribute().startsWith(getRolePrefix()))) {
/*  75 */       return true;
/*     */     }
/*     */ 
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class paramClass)
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   public int vote(Authentication paramAuthentication, Object paramObject, ConfigAttributeDefinition paramConfigAttributeDefinition) {
/*  95 */     int i = 1;
/*  96 */     return i;
/*     */   }
/*     */ 
/*     */   GrantedAuthority[] extractAuthorities(Authentication paramAuthentication) {
/* 100 */     return paramAuthentication.getAuthorities();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.vote.UniEAPVoter
 * JD-Core Version:    0.6.2
 */