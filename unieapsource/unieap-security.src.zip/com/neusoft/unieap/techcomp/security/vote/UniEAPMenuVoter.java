/*     */ package com.neusoft.unieap.techcomp.security.vote;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.model.Application;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuAuthBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.bo.MenuBO;
/*     */ import com.neusoft.unieap.techcomp.ria.menu.entity.Menu;
/*     */ import com.neusoft.unieap.techcomp.security.bo.ApplicationAuthBO;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.ConfigAttribute;
/*     */ import org.springframework.security.ConfigAttributeDefinition;
/*     */ import org.springframework.security.GrantedAuthority;
/*     */ import org.springframework.security.intercept.web.FilterInvocation;
/*     */ import org.springframework.security.vote.AccessDecisionVoter;
/*     */ 
/*     */ public class UniEAPMenuVoter
/*     */   implements AccessDecisionVoter
/*     */ {
/*  70 */   private String rolePrefix = "UNIEAP";
/*     */   private MenuAuthBO menuAuthBO;
/*     */   private MenuBO menuBO;
/*     */   private ApplicationAuthBO applicationAuthBO;
/*     */ 
/*     */   public void setMenuBO(MenuBO paramMenuBO)
/*     */   {
/*  79 */     this.menuBO = paramMenuBO;
/*     */   }
/*     */ 
/*     */   public void setApplicationAuthBO(ApplicationAuthBO paramApplicationAuthBO) {
/*  83 */     this.applicationAuthBO = paramApplicationAuthBO;
/*     */   }
/*     */ 
/*     */   public String getRolePrefix() {
/*  87 */     return this.rolePrefix;
/*     */   }
/*     */ 
/*     */   public void setRolePrefix(String paramString)
/*     */   {
/*  98 */     this.rolePrefix = paramString;
/*     */   }
/*     */ 
/*     */   public boolean supports(ConfigAttribute paramConfigAttribute) {
/* 102 */     if ((paramConfigAttribute.getAttribute() != null) && 
/* 103 */       (paramConfigAttribute.getAttribute().startsWith(getRolePrefix()))) {
/* 104 */       return true;
/*     */     }
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class paramClass)
/*     */   {
/* 120 */     return true;
/*     */   }
/*     */ 
/*     */   public int vote(Authentication paramAuthentication, Object paramObject, ConfigAttributeDefinition paramConfigAttributeDefinition)
/*     */   {
/* 125 */     String str = (String)UniEAPContextHolder.getContext()
/* 126 */       .getCustomProperty("currentAppName");
/*     */ 
/* 128 */     List localList = null;
/* 129 */     if ((str != null) && (!str.equals(""))) {
/* 130 */       localList = this.menuBO.getMenusByAppId(str);
/*     */     }
/*     */ 
/* 133 */     if ((paramObject instanceof FilterInvocation)) {
/* 134 */       FilterInvocation localFilterInvocation = (FilterInvocation)paramObject;
/*     */       Object localObject1;
/*     */       Object localObject2;
/* 136 */       if (localList == null) {
/* 137 */         localObject1 = this.applicationAuthBO
/* 138 */           .getAllowedAvailableApplications();
/* 139 */         localObject2 = null;
/* 140 */         for (int i = 0; i < ((List)localObject1).size(); i++) {
/* 141 */           localObject2 = this.menuBO.getMenusByAppId(
/* 142 */             ((Application)((List)localObject1)
/* 142 */             .get(i)).getId());
/* 143 */           if ((localObject2 == null) || (((List)localObject2).size() == 0))
/* 144 */             return 1;
/* 145 */           if (isinclude(localFilterInvocation.getHttpRequest(), (List)localObject2))
/* 146 */             return -1;
/*     */         }
/*     */       }
/*     */       else {
/* 150 */         localObject1 = paramConfigAttributeDefinition.getConfigAttributes();
/* 151 */         localObject2 = ((Collection)localObject1).iterator();
/* 152 */         while (((Iterator)localObject2).hasNext()) {
/* 153 */           ConfigAttribute localConfigAttribute = (ConfigAttribute)((Iterator)localObject2).next();
/* 154 */           if ((supports(localConfigAttribute)) && 
/* 155 */             (isinclude(localFilterInvocation.getHttpRequest(), localList))) {
/* 156 */             return -1;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 162 */     return 1;
/*     */   }
/*     */ 
/*     */   GrantedAuthority[] extractAuthorities(Authentication paramAuthentication) {
/* 166 */     return paramAuthentication.getAuthorities();
/*     */   }
/*     */ 
/*     */   protected boolean isinclude(HttpServletRequest paramHttpServletRequest, List paramList)
/*     */   {
/* 179 */     String str1 = paramHttpServletRequest.getRequestURI();
/*     */ 
/* 181 */     str1 = str1.substring(1);
/* 182 */     str1 = str1.substring(str1.indexOf("/") + 1);
/*     */ 
/* 184 */     boolean bool = false;
/* 185 */     Menu localMenu = null;
/*     */ 
/* 187 */     List localList = this.menuAuthBO.getAllowedMenus(paramList);
/*     */ 
/* 189 */     String str2 = "";
/* 190 */     for (int i = 0; i < paramList.size(); i++) {
/* 191 */       localMenu = (Menu)paramList.get(i);
/* 192 */       str2 = localMenu.getUrl();
/* 193 */       if ((str2 != null) && (!str2.equalsIgnoreCase(""))) {
/* 194 */         String[] arrayOfString = str2.split("&");
/* 195 */         if ((!str1.equalsIgnoreCase("")) && (arrayOfString.length >= 1) && 
/* 196 */           (arrayOfString[0].equals("/" + str1)) && 
/* 197 */           (!this.menuBO.isInclude(localMenu, localList))) {
/* 198 */           bool = true;
/* 199 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 203 */     return bool;
/*     */   }
/*     */ 
/*     */   public void setMenuAuthBO(MenuAuthBO paramMenuAuthBO) {
/* 207 */     this.menuAuthBO = paramMenuAuthBO;
/*     */   }
/*     */ 
/*     */   public MenuAuthBO getMenuAuthBO() {
/* 211 */     return this.menuAuthBO;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.vote.UniEAPMenuVoter
 * JD-Core Version:    0.6.2
 */