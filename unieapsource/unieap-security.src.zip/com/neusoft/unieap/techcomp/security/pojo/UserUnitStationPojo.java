/*    */ package com.neusoft.unieap.techcomp.security.pojo;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.Label;
/*    */ 
/*    */ public class UserUnitStationPojo
/*    */ {
/*    */   private String userId;
/*    */   private String userName;
/*    */   private String userAccount;
/*    */   private String userType;
/*    */   private String unitNames;
/*    */   private String stationNames;
/*    */ 
/*    */   public String getUserId()
/*    */   {
/* 20 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setUserId(String paramString) {
/* 24 */     this.userId = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserName() {
/* 28 */     return this.userName;
/*    */   }
/*    */ 
/*    */   public void setUserName(String paramString) {
/* 32 */     this.userName = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserAccount() {
/* 36 */     return this.userAccount;
/*    */   }
/*    */ 
/*    */   public void setUserAccount(String paramString) {
/* 40 */     this.userAccount = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserType() {
/* 44 */     return this.userType;
/*    */   }
/*    */ 
/*    */   public void setUserType(String paramString) {
/* 48 */     this.userType = paramString;
/*    */   }
/*    */ 
/*    */   @Label("组织单元")
/*    */   public String getUnitNames() {
/* 53 */     return this.unitNames;
/*    */   }
/*    */ 
/*    */   public void setUnitNames(String paramString) {
/* 57 */     this.unitNames = paramString;
/*    */   }
/*    */ 
/*    */   @Label("职位")
/*    */   public String getStationNames() {
/* 62 */     return this.stationNames;
/*    */   }
/*    */ 
/*    */   public void setStationNames(String paramString) {
/* 66 */     this.stationNames = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.pojo.UserUnitStationPojo
 * JD-Core Version:    0.6.2
 */