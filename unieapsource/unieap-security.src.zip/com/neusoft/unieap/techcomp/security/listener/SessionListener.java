/*    */ package com.neusoft.unieap.techcomp.security.listener;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.core.util.BeanUtil;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*    */ import javax.servlet.http.HttpSessionEvent;
/*    */ import javax.servlet.http.HttpSessionListener;
/*    */ 
/*    */ public class SessionListener
/*    */   implements HttpSessionListener
/*    */ {
/*    */   public void sessionCreated(HttpSessionEvent paramHttpSessionEvent)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void sessionDestroyed(HttpSessionEvent paramHttpSessionEvent)
/*    */   {
/* 18 */     EAPCacheManager localEAPCacheManager = (EAPCacheManager)BeanUtil.getBean("eapCacheManager");
/* 19 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*    */ 
/* 22 */     if (localUser.getId() != null)
/* 23 */       localEAPCacheManager.remove(localUser.getAccount(), "onlineCache");
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.listener.SessionListener
 * JD-Core Version:    0.6.2
 */