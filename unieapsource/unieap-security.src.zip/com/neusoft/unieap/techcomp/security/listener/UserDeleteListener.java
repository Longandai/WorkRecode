/*    */ package com.neusoft.unieap.techcomp.security.listener;
/*    */ 
/*    */ import com.neusoft.unieap.core.event.UserDeleteEvent;
/*    */ import com.neusoft.unieap.techcomp.security.bo.BusiRoleBO;
/*    */ import com.neusoft.unieap.techcomp.security.bo.OnlineUserBO;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ public class UserDeleteListener
/*    */   implements ApplicationListener
/*    */ {
/*    */   BusiRoleBO busiRoleBO;
/*    */   OnlineUserBO onlineUserBO;
/*    */ 
/*    */   public void setBusiRoleBO(BusiRoleBO paramBusiRoleBO)
/*    */   {
/* 15 */     this.busiRoleBO = paramBusiRoleBO;
/*    */   }
/*    */ 
/*    */   public void setOnlineUserBO(OnlineUserBO paramOnlineUserBO) {
/* 19 */     this.onlineUserBO = paramOnlineUserBO;
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ApplicationEvent paramApplicationEvent) {
/* 23 */     if ((paramApplicationEvent instanceof UserDeleteEvent)) {
/* 24 */       String str = ((UserDeleteEvent)paramApplicationEvent).getUserId();
/* 25 */       this.busiRoleBO.deleteBusiRoleUserByUserId(str);
/* 26 */       this.onlineUserBO.deleteOnlineUsersByUserId(str);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.listener.UserDeleteListener
 * JD-Core Version:    0.6.2
 */