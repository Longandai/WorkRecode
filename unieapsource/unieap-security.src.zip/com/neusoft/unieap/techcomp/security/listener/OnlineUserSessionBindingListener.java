/*    */ package com.neusoft.unieap.techcomp.security.listener;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.util.BeanUtil;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCache;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*    */ import com.neusoft.unieap.techcomp.security.bo.OnlineUserBO;
/*    */ import com.neusoft.unieap.techcomp.security.entity.OnlineUser;
/*    */ import com.neusoft.unieap.techcomp.security.onlineuser.OnlineUserConfig;
/*    */ import java.io.Serializable;
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Date;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import javax.servlet.http.HttpSessionBindingEvent;
/*    */ import javax.servlet.http.HttpSessionBindingListener;
/*    */ 
/*    */ public class OnlineUserSessionBindingListener
/*    */   implements HttpSessionBindingListener, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = -123882887345203057L;
/*    */   private String ip;
/*    */   private String account;
/* 26 */   private OnlineUserConfig onlineUserConfig = (OnlineUserConfig)BeanUtil.getBean("onlineUserConfig");
/*    */ 
/*    */   public OnlineUserSessionBindingListener(String ip, String account) {
/* 29 */     this.ip = ip;
/* 30 */     this.account = account;
/*    */   }
/*    */ 
/*    */   public void valueBound(HttpSessionBindingEvent event) {
/* 34 */     if (this.onlineUserConfig.isEnabled()) {
/* 35 */       com.neusoft.unieap.core.context.properties.User currUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 36 */       String loginType = (String)UniEAPContextHolder.getContext().getCustomProperty("loginType");
/* 37 */       String sessionId = event.getSession().getId();
/* 38 */       Timestamp loginTime = new Timestamp(new Date().getTime());
/*    */ 
/* 40 */       OnlineUserBO onlineUserBO = (OnlineUserBO)BeanUtil.getBean("security_onlineUserBO_bo");
/* 41 */       OnlineUser onlineUser = new OnlineUser();
/* 42 */       onlineUser.setLoginTime(loginTime);
/* 43 */       onlineUser.setClientIp(this.ip);
/* 44 */       com.neusoft.unieap.techcomp.org.entity.User user = new com.neusoft.unieap.techcomp.org.entity.User();
/* 45 */       user.setId(currUser.getId());
/* 46 */       onlineUser.setUser(user);
/* 47 */       onlineUser.setLoginType(loginType);
/* 48 */       onlineUser.setSessionId(sessionId);
/* 49 */       String serverIp = null;
/*    */       try {
/* 51 */         serverIp = InetAddress.getLocalHost().getHostAddress();
/*    */       } catch (UnknownHostException e) {
/* 53 */         e.printStackTrace();
/*    */       }
/* 55 */       onlineUser.setServerIp(serverIp);
/*    */ 
/* 57 */       onlineUserBO.saveOnlineUser(onlineUser);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void valueUnbound(HttpSessionBindingEvent event)
/*    */   {
/* 63 */     if (this.onlineUserConfig.isEnabled()) {
/* 64 */       String sessionId = event.getSession().getId();
/* 65 */       OnlineUserBO onlineUserBO = (OnlineUserBO)BeanUtil.getBean("security_onlineUserBO_bo");
/* 66 */       onlineUserBO.deleteOnlineUserBySessionId(sessionId);
/*    */     }
/*    */ 
/* 69 */     EAPCacheManager eapCacheManager = (EAPCacheManager)BeanUtil.getBean("eapCacheManager");
/* 70 */     eapCacheManager.remove(this.account, "onlineCache");
/* 71 */     eapCacheManager.getCache("pageContext").remove(this.account);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.listener.OnlineUserSessionBindingListener
 * JD-Core Version:    0.6.2
 */