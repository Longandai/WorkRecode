package com.neusoft.unieap.techcomp.security.data;

public abstract interface HQLSegmentParser
{
  public abstract String getRowAuthoritiesHQL(String paramString1, String paramString2);

  public abstract String getRowAuthoritiesHQL(String paramString1, String paramString2, String[] paramArrayOfString);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.data.HQLSegmentParser
 * JD-Core Version:    0.6.2
 */