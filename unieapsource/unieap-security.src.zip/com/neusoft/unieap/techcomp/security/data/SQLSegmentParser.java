package com.neusoft.unieap.techcomp.security.data;

public abstract interface SQLSegmentParser
{
  public abstract String getRowAuthoritiesSQL(String paramString1, String paramString2);

  public abstract String getRowAuthoritiesSQL(String paramString1, String paramString2, String[] paramArrayOfString);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.data.SQLSegmentParser
 * JD-Core Version:    0.6.2
 */