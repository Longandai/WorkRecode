/*     */ package com.neusoft.unieap.techcomp.security.concurrent;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.concurrent.SessionInformation;
/*     */ import org.springframework.security.concurrent.SessionRegistry;
/*     */ import org.springframework.security.context.SecurityContext;
/*     */ import org.springframework.security.context.SecurityContextHolder;
/*     */ import org.springframework.security.ui.FilterChainOrder;
/*     */ import org.springframework.security.ui.SpringSecurityFilter;
/*     */ import org.springframework.security.ui.logout.LogoutHandler;
/*     */ import org.springframework.security.ui.logout.SecurityContextLogoutHandler;
/*     */ import org.springframework.security.util.UrlUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ConcurrentSessionFilter extends SpringSecurityFilter
/*     */   implements InitializingBean
/*     */ {
/*     */   private SessionRegistry sessionRegistry;
/*     */   private String expiredUrl;
/*  53 */   private LogoutHandler[] handlers = { new SecurityContextLogoutHandler() };
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/*  59 */     Assert.notNull(this.sessionRegistry, "SessionRegistry required");
/*  60 */     Assert.isTrue(UrlUtils.isValidRedirectUrl(this.expiredUrl), this.expiredUrl + 
/*  61 */       " isn't a valid redirect URL");
/*     */   }
/*     */ 
/*     */   public void doFilterHttp(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, FilterChain paramFilterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  68 */     HttpSession localHttpSession = paramHttpServletRequest.getSession(false);
/*     */ 
/*  70 */     if (localHttpSession != null) {
/*  71 */       SessionInformation localSessionInformation = this.sessionRegistry
/*  72 */         .getSessionInformation(localHttpSession.getId());
/*     */ 
/*  74 */       if (localSessionInformation != null) {
/*  75 */         if (localSessionInformation.isExpired())
/*     */         {
/*  77 */           doLogout(paramHttpServletRequest, paramHttpServletResponse);
/*     */ 
/*  79 */           String str = determineExpiredUrl(paramHttpServletRequest, localSessionInformation);
/*     */ 
/*  81 */           if (str != null) {
/*  82 */             paramHttpServletRequest.setAttribute("loginErrorMsg", "用户已经在其他地方登陆。");
/*  83 */             paramHttpServletRequest.getRequestDispatcher(
/*  84 */               paramHttpServletResponse.encodeRedirectURL(str)).forward(
/*  85 */               paramHttpServletRequest, paramHttpServletResponse);
/*     */           } else {
/*  87 */             paramHttpServletResponse
/*  88 */               .getWriter()
/*  89 */               .print(
/*  90 */               "This session has been expired (possibly due to multiple concurrent logins being attempted as the same user).");
/*     */ 
/*  92 */             paramHttpServletResponse.flushBuffer();
/*     */           }
/*     */ 
/*  95 */           return;
/*     */         }
/*     */ 
/*  98 */         localSessionInformation.refreshLastRequest();
/*     */       }
/*     */     }
/*     */ 
/* 102 */     paramFilterChain.doFilter(paramHttpServletRequest, paramHttpServletResponse);
/*     */   }
/*     */ 
/*     */   protected String determineExpiredUrl(HttpServletRequest paramHttpServletRequest, SessionInformation paramSessionInformation)
/*     */   {
/* 107 */     return this.expiredUrl;
/*     */   }
/*     */ 
/*     */   private void doLogout(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*     */   {
/* 112 */     Authentication localAuthentication = SecurityContextHolder.getContext()
/* 113 */       .getAuthentication();
/* 114 */     for (int i = 0; i < this.handlers.length; i++)
/* 115 */       this.handlers[i].logout(paramHttpServletRequest, paramHttpServletResponse, localAuthentication);
/*     */   }
/*     */ 
/*     */   public void setExpiredUrl(String paramString)
/*     */   {
/* 120 */     this.expiredUrl = paramString;
/*     */   }
/*     */ 
/*     */   public void setSessionRegistry(SessionRegistry paramSessionRegistry) {
/* 124 */     this.sessionRegistry = paramSessionRegistry;
/*     */   }
/*     */ 
/*     */   public void setLogoutHandlers(LogoutHandler[] paramArrayOfLogoutHandler) {
/* 128 */     Assert.notNull(paramArrayOfLogoutHandler);
/* 129 */     this.handlers = paramArrayOfLogoutHandler;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 133 */     return FilterChainOrder.CONCURRENT_SESSION_FILTER;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.concurrent.ConcurrentSessionFilter
 * JD-Core Version:    0.6.2
 */