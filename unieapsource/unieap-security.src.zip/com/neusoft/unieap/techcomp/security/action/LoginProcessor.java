/*    */ package com.neusoft.unieap.techcomp.security.action;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.ria.action.BaseProcessor;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class LoginProcessor extends BaseProcessor
/*    */ {
/*    */   private static final long serialVersionUID = -8725012751677428788L;
/*    */ 
/*    */   public String begin()
/*    */     throws Exception
/*    */   {
/* 15 */     return "begin";
/*    */   }
/*    */ 
/*    */   public String kicked()
/*    */     throws Exception
/*    */   {
/* 24 */     return "kicked";
/*    */   }
/*    */ 
/*    */   public String relogin()
/*    */     throws Exception
/*    */   {
/* 33 */     return "relogin";
/*    */   }
/*    */ 
/*    */   public String success()
/*    */     throws Exception
/*    */   {
/* 42 */     getRequest().getParameter("j_username");
/* 43 */     return "success";
/*    */   }
/*    */ 
/*    */   public String error()
/*    */     throws Exception
/*    */   {
/* 52 */     return "error";
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.action.LoginProcessor
 * JD-Core Version:    0.6.2
 */