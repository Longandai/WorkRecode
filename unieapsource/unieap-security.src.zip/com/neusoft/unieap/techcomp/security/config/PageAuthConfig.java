/*    */ package com.neusoft.unieap.techcomp.security.config;
/*    */ 
/*    */ public class PageAuthConfig
/*    */ {
/*  5 */   private String controlType = "all";
/*    */ 
/*    */   public void setControlType(String paramString) {
/*  8 */     this.controlType = paramString;
/*    */   }
/*    */ 
/*    */   public String getControlType() {
/* 12 */     return this.controlType;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.config.PageAuthConfig
 * JD-Core Version:    0.6.2
 */