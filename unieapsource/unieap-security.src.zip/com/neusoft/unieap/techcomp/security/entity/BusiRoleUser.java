/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.techcomp.org.entity.User;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ @ModelFile("busiRoleUser.entity")
/*     */ public class BusiRoleUser
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String activeFlag;
/*     */   private BusiRole role;
/*     */   private User user;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  47 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  51 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/*  55 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/*  59 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/*  63 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/*  67 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/*  71 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/*  75 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/*  79 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/*  83 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setActiveFlag(String paramString) {
/*  87 */     this.activeFlag = paramString;
/*     */   }
/*     */ 
/*     */   public String getActiveFlag() {
/*  91 */     return this.activeFlag;
/*     */   }
/*     */ 
/*     */   public void setRole(BusiRole paramBusiRole) {
/*  95 */     this.role = paramBusiRole;
/*     */   }
/*     */ 
/*     */   public BusiRole getRole() {
/*  99 */     return this.role;
/*     */   }
/*     */ 
/*     */   public void setUser(User paramUser) {
/* 103 */     this.user = paramUser;
/*     */   }
/*     */ 
/*     */   public User getUser() {
/* 107 */     return this.user;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.BusiRoleUser
 * JD-Core Version:    0.6.2
 */