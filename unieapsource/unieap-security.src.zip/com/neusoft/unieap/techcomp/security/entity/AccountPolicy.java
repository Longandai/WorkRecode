/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ @ModelFile("accountPolicy.entity")
/*     */ public class AccountPolicy
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String account;
/*     */   private String ip;
/*     */   private Timestamp loginTime;
/*     */   private String state;
/*     */   private Integer failedCount;
/*     */   private String sessionId;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  48 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  52 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setAccount(String paramString) {
/*  56 */     this.account = paramString;
/*     */   }
/*     */ 
/*     */   public String getAccount() {
/*  60 */     return this.account;
/*     */   }
/*     */ 
/*     */   public void setIp(String paramString) {
/*  64 */     this.ip = paramString;
/*     */   }
/*     */ 
/*     */   public String getIp() {
/*  68 */     return this.ip;
/*     */   }
/*     */ 
/*     */   public void setLoginTime(Timestamp paramTimestamp) {
/*  72 */     this.loginTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLoginTime() {
/*  76 */     return this.loginTime;
/*     */   }
/*     */ 
/*     */   public void setState(String paramString) {
/*  80 */     this.state = paramString;
/*     */   }
/*     */ 
/*     */   public String getState() {
/*  84 */     return this.state;
/*     */   }
/*     */ 
/*     */   public void setFailedCount(Integer paramInteger) {
/*  88 */     this.failedCount = paramInteger;
/*     */   }
/*     */ 
/*     */   public Integer getFailedCount() {
/*  92 */     return this.failedCount;
/*     */   }
/*     */ 
/*     */   public void setSessionId(String paramString) {
/*  96 */     this.sessionId = paramString;
/*     */   }
/*     */ 
/*     */   public String getSessionId() {
/* 100 */     return this.sessionId;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.AccountPolicy
 * JD-Core Version:    0.6.2
 */