/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.techcomp.org.entity.User;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ 
/*     */ @ModelFile("onlineUser.entity")
/*     */ public class OnlineUser
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String loginType;
/*     */   private Timestamp loginTime;
/*     */   private String sessionId;
/*     */   private String serverIp;
/*     */   private String clientIp;
/*     */   private Map pojoContext;
/*     */   private User user;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  48 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  52 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setLoginType(String paramString) {
/*  56 */     this.loginType = paramString;
/*     */   }
/*     */ 
/*     */   public String getLoginType() {
/*  60 */     return this.loginType;
/*     */   }
/*     */ 
/*     */   public void setLoginTime(Timestamp paramTimestamp) {
/*  64 */     this.loginTime = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLoginTime() {
/*  68 */     return this.loginTime;
/*     */   }
/*     */ 
/*     */   public void setSessionId(String paramString) {
/*  72 */     this.sessionId = paramString;
/*     */   }
/*     */ 
/*     */   public String getSessionId() {
/*  76 */     return this.sessionId;
/*     */   }
/*     */ 
/*     */   public void setServerIp(String paramString) {
/*  80 */     this.serverIp = paramString;
/*     */   }
/*     */ 
/*     */   public String getServerIp() {
/*  84 */     return this.serverIp;
/*     */   }
/*     */ 
/*     */   public void setClientIp(String paramString) {
/*  88 */     this.clientIp = paramString;
/*     */   }
/*     */ 
/*     */   public String getClientIp() {
/*  92 */     return this.clientIp;
/*     */   }
/*     */ 
/*     */   public void setUser(User paramUser) {
/*  96 */     this.user = paramUser;
/*     */   }
/*     */ 
/*     */   public User getUser() {
/* 100 */     return this.user;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.OnlineUser
 * JD-Core Version:    0.6.2
 */