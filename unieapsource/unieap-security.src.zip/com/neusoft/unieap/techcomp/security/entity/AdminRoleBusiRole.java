/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.security.entity.AdminRole;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ 
/*     */ @ModelFile("adminRoleBusiRole.entity")
/*     */ public class AdminRoleBusiRole
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String activeFlag;
/*     */   private AdminRole adminRole;
/*     */   private BusiRole busiRole;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  47 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  51 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/*  55 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/*  59 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/*  63 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/*  67 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/*  71 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/*  75 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/*  79 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/*  83 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setActiveFlag(String paramString) {
/*  87 */     this.activeFlag = paramString;
/*     */   }
/*     */ 
/*     */   public String getActiveFlag() {
/*  91 */     return this.activeFlag;
/*     */   }
/*     */ 
/*     */   public void setAdminRole(AdminRole paramAdminRole) {
/*  95 */     this.adminRole = paramAdminRole;
/*     */   }
/*     */ 
/*     */   public AdminRole getAdminRole() {
/*  99 */     return this.adminRole;
/*     */   }
/*     */ 
/*     */   public void setBusiRole(BusiRole paramBusiRole) {
/* 103 */     this.busiRole = paramBusiRole;
/*     */   }
/*     */ 
/*     */   public BusiRole getBusiRole() {
/* 107 */     return this.busiRole;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.AdminRoleBusiRole
 * JD-Core Version:    0.6.2
 */