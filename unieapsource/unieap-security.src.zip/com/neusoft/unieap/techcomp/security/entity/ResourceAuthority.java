/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ @ModelFile("resourceAuthority.entity")
/*     */ public class ResourceAuthority
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String description;
/*     */   private String roleId;
/*     */   private String roleType;
/*     */   private String resourceId;
/*     */   private String resourceType;
/*     */   private String authorityType;
/*     */   private String dimensionConstraint;
/*     */   private String circumstanceId;
/*     */   private String circumstanceType;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  61 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  65 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString) {
/*  69 */     this.description = paramString;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  73 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setRoleId(String paramString) {
/*  77 */     this.roleId = paramString;
/*     */   }
/*     */ 
/*     */   public String getRoleId() {
/*  81 */     return this.roleId;
/*     */   }
/*     */ 
/*     */   public void setRoleType(String paramString) {
/*  85 */     this.roleType = paramString;
/*     */   }
/*     */ 
/*     */   public String getRoleType() {
/*  89 */     return this.roleType;
/*     */   }
/*     */ 
/*     */   public void setResourceId(String paramString) {
/*  93 */     this.resourceId = paramString;
/*     */   }
/*     */ 
/*     */   public String getResourceId() {
/*  97 */     return this.resourceId;
/*     */   }
/*     */ 
/*     */   public void setResourceType(String paramString) {
/* 101 */     this.resourceType = paramString;
/*     */   }
/*     */ 
/*     */   public String getResourceType() {
/* 105 */     return this.resourceType;
/*     */   }
/*     */ 
/*     */   public void setAuthorityType(String paramString) {
/* 109 */     this.authorityType = paramString;
/*     */   }
/*     */ 
/*     */   public String getAuthorityType() {
/* 113 */     return this.authorityType;
/*     */   }
/*     */ 
/*     */   public void setDimensionConstraint(String paramString) {
/* 117 */     this.dimensionConstraint = paramString;
/*     */   }
/*     */ 
/*     */   public String getDimensionConstraint() {
/* 121 */     return this.dimensionConstraint;
/*     */   }
/*     */ 
/*     */   public void setCircumstanceId(String paramString) {
/* 125 */     this.circumstanceId = paramString;
/*     */   }
/*     */ 
/*     */   public String getCircumstanceId() {
/* 129 */     return this.circumstanceId;
/*     */   }
/*     */ 
/*     */   public void setCircumstanceType(String paramString) {
/* 133 */     this.circumstanceType = paramString;
/*     */   }
/*     */ 
/*     */   public String getCircumstanceType() {
/* 137 */     return this.circumstanceType;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.ResourceAuthority
 * JD-Core Version:    0.6.2
 */