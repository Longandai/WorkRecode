/*     */ package com.neusoft.unieap.techcomp.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Timestamp;
/*     */ import org.hibernate.validator.constraints.Length;
/*     */ 
/*     */ @ModelFile("busiRole.entity")
/*     */ public class BusiRole
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String name;
/*     */   private String description;
/*     */   private Timestamp timeBegin;
/*     */   private Timestamp timeEnd;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String activeFlag;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  65 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  69 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString) {
/*  73 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  77 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString) {
/*  81 */     this.description = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=255, message="${techcomp.security/techcomp.security.entity.busiRole.description.length.message}")
/*     */   public String getDescription() {
/*  86 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setTimeBegin(Timestamp paramTimestamp) {
/*  90 */     this.timeBegin = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getTimeBegin() {
/*  94 */     return this.timeBegin;
/*     */   }
/*     */ 
/*     */   public void setTimeEnd(Timestamp paramTimestamp) {
/*  98 */     this.timeEnd = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getTimeEnd() {
/* 102 */     return this.timeEnd;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 106 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/* 110 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/* 114 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/* 118 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 122 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/* 126 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/* 130 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/* 134 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setActiveFlag(String paramString) {
/* 138 */     this.activeFlag = paramString;
/*     */   }
/*     */ 
/*     */   public String getActiveFlag() {
/* 142 */     return this.activeFlag;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.entity.BusiRole
 * JD-Core Version:    0.6.2
 */