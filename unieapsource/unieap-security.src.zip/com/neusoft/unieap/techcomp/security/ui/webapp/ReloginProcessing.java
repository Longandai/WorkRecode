/*    */ package com.neusoft.unieap.techcomp.security.ui.webapp;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.BeanUtil;
/*    */ import com.neusoft.unieap.techcomp.security.SecurityConfig;
/*    */ import java.io.IOException;
/*    */ import java.util.Enumeration;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import javax.servlet.RequestDispatcher;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import net.sf.json.JSONObject;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ 
/*    */ public class ReloginProcessing
/*    */ {
/*    */   private String[] processesUrl;
/*    */   private String targetUrl;
/*    */   private SecurityConfig securityConfig;
/*    */ 
/*    */   public SecurityConfig getSecurityConfig()
/*    */   {
/* 24 */     return this.securityConfig;
/*    */   }
/*    */ 
/*    */   public void setSecurityConfig(SecurityConfig securityConfig) {
/* 28 */     this.securityConfig = securityConfig;
/*    */   }
/*    */ 
/*    */   public String[] getProcessesUrl() {
/* 32 */     return this.processesUrl;
/*    */   }
/*    */ 
/*    */   public void setProcessesUrl(String[] processesUrl) {
/* 36 */     this.processesUrl = processesUrl;
/*    */   }
/*    */ 
/*    */   public String getTargetUrl() {
/* 40 */     return this.targetUrl;
/*    */   }
/*    */ 
/*    */   public void setTargetUrl(String targetUrl) {
/* 44 */     this.targetUrl = targetUrl;
/*    */   }
/*    */ 
/*    */   public boolean isValidProcesses(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
/* 48 */     if (this.securityConfig.isDialogRelogin()) {
/* 49 */       String url = request.getServletPath();
/* 50 */       for (int index = 0; index < this.processesUrl.length; index++) {
/* 51 */         if (url.equals(this.processesUrl[index])) {
/* 52 */           return false;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 60 */       Object bean = BeanUtil.getBean("specialCharFilter");
/* 61 */       Boolean isEnabled = Boolean.valueOf(false);
/*    */       try {
/* 63 */         isEnabled = (Boolean)PropertyUtils.getProperty(bean, "enabled");
/*    */       }
/*    */       catch (Exception localException)
/*    */       {
/*    */       }
/* 68 */       request.setAttribute("path", request.getContextPath() + url);
/*    */ 
/* 71 */       Map inputParamMap = new HashMap();
/* 72 */       Enumeration enumNames = request.getParameterNames();
/* 73 */       while (enumNames.hasMoreElements()) {
/* 74 */         String parameterName = (String)enumNames.nextElement();
/* 75 */         String value = request.getParameter(parameterName);
/* 76 */         if (isEnabled.booleanValue())
/*    */         {
/* 78 */           String reg = "window|location|script|alert|SCRIPT|ALERT|select | from | on | and | or |SELECT | FROM | ON | AND | OR |%3C|%27|%22|%3E|%3D|%2F";
/* 79 */           value = value.replaceAll(reg, "_");
/*    */         }
/* 81 */         inputParamMap.put(parameterName, value);
/*    */       }
/*    */ 
/* 84 */       request.setAttribute("inputParamJson", JSONObject.fromObject(inputParamMap).toString());
/* 85 */       request.getRequestDispatcher(getTargetUrl()).forward(request, response);
/* 86 */       return true;
/*    */     }
/* 88 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.webapp.ReloginProcessing
 * JD-Core Version:    0.6.2
 */