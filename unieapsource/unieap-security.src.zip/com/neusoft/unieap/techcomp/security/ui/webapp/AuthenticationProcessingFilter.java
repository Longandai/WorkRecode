/*     */ package com.neusoft.unieap.techcomp.security.ui.webapp;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.event.AttemptAuthenticationEvent;
/*     */ import com.neusoft.unieap.core.event.SuccessfulAuthenticationEvent;
/*     */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*     */ import com.neusoft.unieap.core.event.UnsuccessfulAuthenticationEvent;
/*     */ import com.neusoft.unieap.core.util.ClientUtil;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.org.bootstrap.OrgActivator;
/*     */ import com.neusoft.unieap.techcomp.org.util.CrytogramUtil;
/*     */ import com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyConfig;
/*     */ import com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyService;
/*     */ import com.neusoft.unieap.techcomp.security.bo.AccountPolicyBO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
/*     */ import com.neusoft.unieap.techcomp.security.i18n.I18nUtil;
/*     */ import com.neusoft.unieap.techcomp.security.listener.OnlineUserSessionBindingListener;
/*     */ import com.neusoft.unieap.techcomp.security.onlineuser.OnlineUserConfig;
/*     */ import com.neusoft.unieap.techcomp.security.rsa.RSAConfig;
/*     */ import com.neusoft.unieap.techcomp.security.rsa.RSAUtils;
/*     */ import java.io.IOException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import javax.servlet.ServletContext;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.Cookie;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.AuthenticationException;
/*     */ import org.springframework.security.AuthenticationManager;
/*     */ import org.springframework.security.BadCredentialsException;
/*     */ import org.springframework.security.DisabledException;
/*     */ import org.springframework.security.LockedException;
/*     */ import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.providers.dao.UserCache;
/*     */ import org.springframework.security.ui.AuthenticationDetailsSource;
/*     */ import org.springframework.security.ui.FilterChainOrder;
/*     */ import org.springframework.security.util.TextUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public class AuthenticationProcessingFilter extends org.springframework.security.ui.webapp.AuthenticationProcessingFilter
/*     */ {
/*     */   public static final String SPRING_SECURITY_FORM_USERNAME_KEY = "j_username";
/*     */   public static final String SPRING_SECURITY_FORM_PASSWORD_KEY = "j_password";
/*     */   public static final String SPRING_SECURITY_LAST_USERNAME_KEY = "SPRING_SECURITY_LAST_USERNAME";
/*  81 */   private String usernameParameter = "j_username";
/*  82 */   private String passwordParameter = "j_password";
/*     */   private OrgActivator orgActivator;
/*     */   private EAPCacheManager eapCacheManager;
/*     */   private AccountPolicyService accountPolicyService;
/*     */   private AccountPolicyBO accountPolicyBO;
/*     */   private OnlineUserConfig onlineUserConfig;
/*     */   private AccountPolicyConfig accountPolicyConfig;
/*     */   private UniEAPEventPublisher publisher;
/*     */ 
/*     */   public Authentication attemptAuthentication(HttpServletRequest paramHttpServletRequest)
/*     */     throws AuthenticationException
/*     */   {
/*  95 */     String str1 = obtainUsername(paramHttpServletRequest);
/*  96 */     String str2 = obtainPassword(paramHttpServletRequest);
/*     */ 
/*  98 */     if (RSAConfig.enabled)
/*     */       try
/*     */       {
/* 101 */         str2 = RSAUtils.decryptStringByJs(str2);
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/*     */       }
/* 106 */     this.publisher.publish(new AttemptAuthenticationEvent(str1, paramHttpServletRequest));
/*     */ 
/* 108 */     UserCache localUserCache = (UserCache)WebApplicationContextUtils.getWebApplicationContext(
/* 109 */       paramHttpServletRequest.getSession().getServletContext()).getBean(
/* 110 */       "userCache");
/* 111 */     if ((localUserCache != null) && (str1 != null)) {
/* 112 */       localUserCache.removeUserFromCache(str1);
/*     */     }
/* 114 */     if (str1 != null) {
/* 115 */       this.eapCacheManager.remove(str1, "menuAuthority");
/* 116 */       this.eapCacheManager.remove(str1, "pageAuthority");
/* 117 */       this.eapCacheManager.remove(str1, "applicationAuthority");
/* 118 */       this.eapCacheManager.remove(str1, "loginUsers");
/*     */     }
/*     */ 
/* 121 */     this.eapCacheManager.clear("circumstanceAuthority");
/*     */ 
/* 123 */     if (str1 == null) {
/* 124 */       str1 = "";
/*     */     }
/*     */ 
/* 127 */     if (str2 == null) {
/* 128 */       str2 = "";
/*     */     }
/*     */ 
/* 131 */     str1 = str1.trim();
/*     */ 
/* 134 */     UsernamePasswordAuthenticationToken localUsernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(str1, 
/* 135 */       CrytogramUtil.encrypt(str2, 
/* 136 */       this.orgActivator.getCrytogramAlgorithm()));
/*     */ 
/* 140 */     HttpSession localHttpSession = paramHttpServletRequest.getSession(false);
/*     */ 
/* 142 */     if ((localHttpSession != null) || (getAllowSessionCreation())) {
/* 143 */       paramHttpServletRequest.getSession().setAttribute("SPRING_SECURITY_LAST_USERNAME", TextUtils.escapeEntities(str1));
/*     */     }
/*     */ 
/* 147 */     setDetails(paramHttpServletRequest, localUsernamePasswordAuthenticationToken);
/*     */ 
/* 149 */     return getAuthenticationManager().authenticate(localUsernamePasswordAuthenticationToken);
/*     */   }
/*     */ 
/*     */   public String getDefaultFilterProcessesUrl()
/*     */   {
/* 158 */     return "/j_spring_security_check";
/*     */   }
/*     */ 
/*     */   protected void successfulAuthentication(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Authentication paramAuthentication)
/*     */     throws IOException, ServletException
/*     */   {
/* 164 */     if ("https".equals(paramHttpServletRequest.getScheme())) {
/* 165 */       localObject1 = paramHttpServletRequest.getSession(false);
/* 166 */       if (localObject1 != null) {
/* 167 */         localObject2 = new Cookie("JSESSIONID", ((HttpSession)localObject1).getId());
/* 168 */         localObject3 = ((HttpSession)localObject1).getServletContext();
/* 169 */         ((ServletContext)localObject3).setAttribute(((HttpSession)localObject1).getId(), paramHttpServletRequest.getSession());
/* 170 */         paramHttpServletResponse.addCookie((Cookie)localObject2);
/*     */       }
/*     */     }
/* 173 */     Object localObject1 = obtainUsername(paramHttpServletRequest);
/* 174 */     Object localObject2 = (User)this.eapCacheManager.get(localObject1, "loginUsers");
/* 175 */     UniEAPContextHolder.getContext().getCurrentUser().setId(((User)localObject2).getId());
/* 176 */     UniEAPContextHolder.getContext().getCurrentUser().setName(((User)localObject2).getName());
/* 177 */     UniEAPContextHolder.getContext().getCurrentUser().setAccount(((User)localObject2).getAccount());
/* 178 */     UniEAPContextHolder.getContext().getCurrentUser().setRoles(((User)localObject2).getRoles());
/*     */ 
/* 180 */     if (((User)localObject2).getAdminRoleType() != null)
/* 181 */       UniEAPContextHolder.getContext().addCustomProperty("loginType", "1");
/*     */     else {
/* 183 */       UniEAPContextHolder.getContext().addCustomProperty("loginType", "0");
/*     */     }
/*     */ 
/* 187 */     this.publisher.publish(new SuccessfulAuthenticationEvent((User)localObject2, paramHttpServletRequest, paramHttpServletResponse));
/*     */ 
/* 191 */     Object localObject3 = new OnlineUserSessionBindingListener(ClientUtil.getClientIp(paramHttpServletRequest), ((User)localObject2).getAccount());
/* 192 */     paramHttpServletRequest.getSession().setAttribute("onlineUserListener", localObject3);
/*     */ 
/* 195 */     successfulAuthentication((User)localObject2, paramHttpServletRequest);
/*     */ 
/* 197 */     if (this.logger.isInfoEnabled()) {
/* 198 */       this.logger.info(I18nUtil.getInstance().getValue("techcomp.security.accountLoginSuccessful", new Object[] { paramAuthentication.getName() }));
/*     */     }
/* 200 */     super.successfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthentication);
/*     */   }
/*     */ 
/*     */   protected void unsuccessfulAuthentication(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, AuthenticationException paramAuthenticationException) throws IOException, ServletException
/*     */   {
/* 205 */     String str1 = obtainUsername(paramHttpServletRequest);
/* 206 */     String str2 = obtainPassword(paramHttpServletRequest);
/*     */ 
/* 208 */     this.publisher.publish(new UnsuccessfulAuthenticationEvent(obtainUsername(paramHttpServletRequest), paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException));
/* 209 */     this.eapCacheManager.remove(str1, "loginUsers");
/*     */ 
/* 211 */     String str3 = null;
/* 212 */     if ((str1 == null) || (str2 == null)) {
/* 213 */       str3 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordNotNull");
/* 214 */       paramHttpServletRequest.setAttribute("loginErrorMsg", str3);
/* 215 */       super.unsuccessfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException);
/* 216 */       return;
/*     */     }
/* 218 */     if ((str1.getBytes().length > 32) || (str2.getBytes().length > 32)) {
/* 219 */       str3 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordOverLength");
/* 220 */       paramHttpServletRequest.setAttribute("loginErrorMsg", str3);
/* 221 */       super.unsuccessfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException);
/* 222 */       return;
/*     */     }
/* 224 */     if ((paramAuthenticationException instanceof BadCredentialsException)) {
/* 225 */       str3 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordError");
/* 226 */       paramHttpServletRequest.setAttribute("loginErrorMsg", str3);
/* 227 */       if (this.logger.isInfoEnabled())
/* 228 */         this.logger.info(str3);
/*     */     }
/*     */     else
/*     */     {
/*     */       String str4;
/* 230 */       if ((paramAuthenticationException instanceof LockedException)) {
/* 231 */         str4 = obtainUsername(paramHttpServletRequest);
/* 232 */         str3 = I18nUtil.getInstance().getValue("techcomp.security.accountLockedByAdministrator", new Object[] { str4 });
/* 233 */         paramHttpServletRequest.setAttribute("loginErrorMsg", str3);
/* 234 */         if (this.logger.isInfoEnabled()) {
/* 235 */           this.logger.info(str3);
/*     */         }
/* 237 */         super.unsuccessfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException);
/* 238 */         return;
/*     */       }
/* 240 */       if ((paramAuthenticationException instanceof DisabledException)) {
/* 241 */         str4 = obtainUsername(paramHttpServletRequest);
/* 242 */         str3 = I18nUtil.getInstance().getValue("techcomp.security.accountDisabled", new Object[] { str4 });
/* 243 */         paramHttpServletRequest.setAttribute("loginErrorMsg", str3);
/* 244 */         if (this.logger.isInfoEnabled()) {
/* 245 */           this.logger.info(str3);
/*     */         }
/* 247 */         super.unsuccessfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException);
/* 248 */         return;
/*     */       }
/*     */     }
/* 251 */     unsuccessfulAuthentication(paramHttpServletRequest);
/*     */ 
/* 253 */     super.unsuccessfulAuthentication(paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException);
/*     */   }
/*     */ 
/*     */   protected String obtainPassword(HttpServletRequest paramHttpServletRequest)
/*     */   {
/* 268 */     return paramHttpServletRequest.getParameter(this.passwordParameter);
/*     */   }
/*     */ 
/*     */   protected String obtainUsername(HttpServletRequest paramHttpServletRequest)
/*     */   {
/* 281 */     return paramHttpServletRequest.getParameter(this.usernameParameter);
/*     */   }
/*     */ 
/*     */   protected void setDetails(HttpServletRequest paramHttpServletRequest, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken)
/*     */   {
/* 292 */     paramUsernamePasswordAuthenticationToken.setDetails(this.authenticationDetailsSource.buildDetails(paramHttpServletRequest));
/*     */   }
/*     */ 
/*     */   public void setUsernameParameter(String paramString)
/*     */   {
/* 301 */     Assert.hasText(paramString, "Username parameter must not be empty or null");
/* 302 */     this.usernameParameter = paramString;
/*     */   }
/*     */ 
/*     */   public void setPasswordParameter(String paramString)
/*     */   {
/* 311 */     Assert.hasText(paramString, "Password parameter must not be empty or null");
/* 312 */     this.passwordParameter = paramString;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 316 */     return FilterChainOrder.AUTHENTICATION_PROCESSING_FILTER;
/*     */   }
/*     */ 
/*     */   String getUsernameParameter() {
/* 320 */     return this.usernameParameter;
/*     */   }
/*     */ 
/*     */   String getPasswordParameter() {
/* 324 */     return this.passwordParameter;
/*     */   }
/*     */ 
/*     */   public void setOrgActivator(OrgActivator paramOrgActivator) {
/* 328 */     this.orgActivator = paramOrgActivator;
/*     */   }
/*     */ 
/*     */   public OrgActivator getOrgActivator() {
/* 332 */     return this.orgActivator;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/* 336 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public EAPCacheManager getEapCacheManager() {
/* 340 */     return this.eapCacheManager;
/*     */   }
/*     */ 
/*     */   public void setPublisher(UniEAPEventPublisher paramUniEAPEventPublisher) {
/* 344 */     this.publisher = paramUniEAPEventPublisher;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyService(AccountPolicyService paramAccountPolicyService)
/*     */   {
/* 349 */     this.accountPolicyService = paramAccountPolicyService;
/*     */   }
/*     */ 
/*     */   public AccountPolicyService getAccountPolicyService() {
/* 353 */     return this.accountPolicyService;
/*     */   }
/*     */ 
/*     */   private void successfulAuthentication(User paramUser, HttpServletRequest paramHttpServletRequest)
/*     */   {
/*     */     Object localObject;
/* 363 */     if (this.accountPolicyConfig.isAccountKicked()) {
/* 364 */       str1 = paramUser.getAccount();
/* 365 */       this.eapCacheManager.remove(str1, "onlineCache");
/*     */ 
/* 367 */       localObject = new AccountPolicy();
/* 368 */       ((AccountPolicy)localObject).setAccount(paramUser.getAccount());
/* 369 */       ((AccountPolicy)localObject).setLoginTime(new Timestamp(new Date().getTime()));
/* 370 */       ((AccountPolicy)localObject).setIp(paramHttpServletRequest.getRemoteAddr());
/* 371 */       ((AccountPolicy)localObject).setSessionId(paramHttpServletRequest.getSession().getId());
/*     */ 
/* 373 */       this.eapCacheManager.put(str1, localObject, "onlineCache");
/*     */     }
/*     */ 
/* 376 */     String str1 = this.accountPolicyConfig.getLockedPolicy();
/* 377 */     if (!str1.equalsIgnoreCase("unlocked")) {
/* 378 */       localObject = paramHttpServletRequest.getRemoteAddr();
/* 379 */       String str2 = paramHttpServletRequest.getParameter("j_username");
/* 380 */       String str3 = this.accountPolicyConfig.getKey(str1, (String)localObject, str2);
/* 381 */       AccountPolicy localAccountPolicy = (AccountPolicy)this.eapCacheManager.get(str3, "lockingCache");
/* 382 */       if (localAccountPolicy != null) {
/* 383 */         this.accountPolicyBO.deleteAccountPolicy(localAccountPolicy);
/*     */       }
/* 385 */       this.eapCacheManager.remove(str3, "lockedCache");
/* 386 */       this.eapCacheManager.remove(str3, "lockingCache");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void unsuccessfulAuthentication(HttpServletRequest paramHttpServletRequest)
/*     */   {
/* 396 */     String str1 = this.accountPolicyConfig.getLockedPolicy();
/* 397 */     if (!str1.equalsIgnoreCase("unlocked")) {
/* 398 */       String str2 = paramHttpServletRequest.getRemoteAddr();
/* 399 */       String str3 = paramHttpServletRequest.getParameter("j_username");
/* 400 */       String str4 = this.accountPolicyConfig.getKey(str1, str2, str3);
/* 401 */       AccountPolicy localAccountPolicy1 = (AccountPolicy)this.eapCacheManager.get(str4, "lockedCache");
/* 402 */       AccountPolicy localAccountPolicy2 = (AccountPolicy)this.eapCacheManager.get(str4, "lockingCache");
/* 403 */       String str5 = paramHttpServletRequest.getSession().getId();
/* 404 */       String str6 = null;
/* 405 */       if (localAccountPolicy1 != null) {
/* 406 */         if (this.accountPolicyService.isUnLocked(localAccountPolicy1.getLoginTime())) {
/* 407 */           this.eapCacheManager.remove(str4, "lockedCache");
/* 408 */           localAccountPolicy1.setFailedCount(Integer.valueOf(1));
/* 409 */           localAccountPolicy1.setSessionId(str5);
/* 410 */           localAccountPolicy1.setLoginTime(new Timestamp(new Date().getTime()));
/* 411 */           localAccountPolicy1.setState("locking");
/* 412 */           this.eapCacheManager.put(str4, localAccountPolicy1, "lockingCache");
/*     */ 
/* 414 */           this.accountPolicyBO.saveAccountPolicy(localAccountPolicy1);
/*     */ 
/* 416 */           int i = this.accountPolicyConfig.getFailedCount() - localAccountPolicy1.getFailedCount().intValue();
/* 417 */           str6 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordError1", new Object[] { Integer.valueOf(i) });
/*     */         }
/*     */         else {
/* 420 */           long l = new Date().getTime() - localAccountPolicy1.getLoginTime().getTime();
/* 421 */           int m = this.accountPolicyConfig.getLockedTimeInterval() - Integer.parseInt(String.valueOf(l / 60L / 1000L));
/* 422 */           str6 = this.accountPolicyService.getLockedErrorMessage(str1, str2, str3, m);
/*     */         }
/*     */       }
/*     */ 
/* 426 */       if (localAccountPolicy2 != null) {
/* 427 */         localAccountPolicy2.setFailedCount(Integer.valueOf(localAccountPolicy2.getFailedCount().intValue() + 1));
/* 428 */         localAccountPolicy2.setLoginTime(new Timestamp(new Date().getTime()));
/*     */         int j;
/* 429 */         if (this.accountPolicyConfig.getFailedCount() <= localAccountPolicy2.getFailedCount().intValue()) {
/* 430 */           this.eapCacheManager.remove(str3, "onlineCache");
/* 431 */           this.eapCacheManager.remove(str4, "lockingCache");
/* 432 */           localAccountPolicy2.setState("locked");
/* 433 */           this.accountPolicyService.putLockedToCache(str4, localAccountPolicy2);
/*     */ 
/* 435 */           j = this.accountPolicyConfig.getLockedTimeInterval();
/* 436 */           str6 = this.accountPolicyService.getLockedErrorMessage(str1, str2, str3, j);
/*     */         }
/*     */         else {
/* 439 */           j = this.accountPolicyConfig.getFailedCount() - localAccountPolicy2.getFailedCount().intValue();
/* 440 */           str6 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordError1", new Object[] { Integer.valueOf(j) });
/*     */         }
/*     */ 
/* 443 */         this.accountPolicyBO.updateAccountPolicy(localAccountPolicy2);
/*     */       }
/*     */ 
/* 446 */       if ((localAccountPolicy1 == null) && (localAccountPolicy2 == null)) {
/* 447 */         AccountPolicy localAccountPolicy3 = new AccountPolicy();
/* 448 */         localAccountPolicy3.setAccount(str3);
/* 449 */         localAccountPolicy3.setFailedCount(Integer.valueOf(1));
/* 450 */         localAccountPolicy3.setId(str4);
/* 451 */         localAccountPolicy3.setIp(str2);
/* 452 */         localAccountPolicy3.setLoginTime(new Timestamp(new Date().getTime()));
/* 453 */         localAccountPolicy3.setSessionId(str5);
/* 454 */         localAccountPolicy3.setState("locking");
/*     */ 
/* 456 */         this.eapCacheManager.put(str4, localAccountPolicy3, "lockingCache");
/* 457 */         int k = this.accountPolicyConfig.getFailedCount() - 1;
/* 458 */         str6 = I18nUtil.getInstance().getValue("techcomp.security.accountOrPasswordError1", new Object[] { Integer.valueOf(k) });
/*     */ 
/* 460 */         this.accountPolicyBO.saveAccountPolicy(localAccountPolicy3);
/*     */       }
/* 462 */       paramHttpServletRequest.setAttribute("loginErrorMsg", str6);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setOnlineUserConfig(OnlineUserConfig paramOnlineUserConfig) {
/* 467 */     this.onlineUserConfig = paramOnlineUserConfig;
/*     */   }
/*     */ 
/*     */   public OnlineUserConfig getOnlineUserConfig() {
/* 471 */     return this.onlineUserConfig;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyConfig(AccountPolicyConfig paramAccountPolicyConfig) {
/* 475 */     this.accountPolicyConfig = paramAccountPolicyConfig;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyBO(AccountPolicyBO paramAccountPolicyBO) {
/* 479 */     this.accountPolicyBO = paramAccountPolicyBO;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.webapp.AuthenticationProcessingFilter
 * JD-Core Version:    0.6.2
 */