/*    */ package com.neusoft.unieap.techcomp.security.ui.cas;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.core.event.SuccessfulAuthenticationEvent;
/*    */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*    */ import com.neusoft.unieap.core.event.UnsuccessfulAuthenticationEvent;
/*    */ import com.neusoft.unieap.core.util.ClientUtil;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*    */ import com.neusoft.unieap.techcomp.security.listener.OnlineUserSessionBindingListener;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.springframework.security.Authentication;
/*    */ import org.springframework.security.AuthenticationException;
/*    */ import org.springframework.security.providers.dao.UserCache;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*    */ 
/*    */ public class CasProcessingFilter extends org.springframework.security.ui.cas.CasProcessingFilter
/*    */ {
/*    */   private EAPCacheManager eapCacheManager;
/*    */   private UniEAPEventPublisher publisher;
/*    */ 
/*    */   public Authentication attemptAuthentication(HttpServletRequest paramHttpServletRequest)
/*    */     throws AuthenticationException
/*    */   {
/* 37 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 38 */     String str = localUser.getAccount();
/* 39 */     UserCache localUserCache = (UserCache)WebApplicationContextUtils.getWebApplicationContext(
/* 40 */       paramHttpServletRequest.getSession().getServletContext()).getBean(
/* 41 */       "userCache");
/* 42 */     if ((localUserCache != null) && (str != null)) {
/* 43 */       localUserCache.removeUserFromCache(str);
/*    */     }
/* 45 */     if (str != null) {
/* 46 */       this.eapCacheManager.remove(str, "menuAuthority");
/* 47 */       this.eapCacheManager.remove(str, "pageAuthority");
/* 48 */       this.eapCacheManager.remove(str, "applicationAuthority");
/*    */     }
/*    */ 
/* 51 */     this.eapCacheManager.clear("circumstanceAuthority");
/* 52 */     return super.attemptAuthentication(paramHttpServletRequest);
/*    */   }
/*    */ 
/*    */   protected void onSuccessfulAuthentication(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Authentication paramAuthentication)
/*    */     throws IOException
/*    */   {
/* 58 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/*    */ 
/* 60 */     this.publisher.publish(new SuccessfulAuthenticationEvent(localUser, paramHttpServletRequest, paramHttpServletResponse));
/*    */ 
/* 62 */     OnlineUserSessionBindingListener localOnlineUserSessionBindingListener = new OnlineUserSessionBindingListener(ClientUtil.getClientIp(paramHttpServletRequest), localUser.getAccount());
/* 63 */     paramHttpServletRequest.getSession().setAttribute("onlineUserListener", localOnlineUserSessionBindingListener);
/*    */   }
/*    */ 
/*    */   protected void onUnsuccessfulAuthentication(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, AuthenticationException paramAuthenticationException)
/*    */     throws IOException
/*    */   {
/* 71 */     this.publisher.publish(new UnsuccessfulAuthenticationEvent("_cas_stateful_", paramHttpServletRequest, paramHttpServletResponse, paramAuthenticationException));
/*    */   }
/*    */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/* 74 */     this.eapCacheManager = paramEAPCacheManager;
/*    */   }
/*    */ 
/*    */   public EAPCacheManager getEapCacheManager() {
/* 78 */     return this.eapCacheManager;
/*    */   }
/*    */ 
/*    */   public void setPublisher(UniEAPEventPublisher paramUniEAPEventPublisher) {
/* 82 */     this.publisher = paramUniEAPEventPublisher;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.cas.CasProcessingFilter
 * JD-Core Version:    0.6.2
 */