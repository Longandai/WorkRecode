/*     */ package com.neusoft.unieap.techcomp.security.ui.webapp;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.security.jcaptcha.CaptchaService;
/*     */ import com.neusoft.unieap.techcomp.security.jcaptcha.JCaptchaConfig;
/*     */ import com.octo.captcha.service.CaptchaServiceException;
/*     */ import com.octo.captcha.service.image.ImageCaptchaService;
/*     */ import java.io.IOException;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class JCaptchaProcessingFilter
/*     */   implements Filter
/*     */ {
/*  24 */   Log logger = LogFactory.getLog(JCaptchaProcessingFilter.class);
/*     */   CaptchaService captchaService;
/*     */   String[] processesUrl;
/*     */   String[] targetUrl;
/*     */ 
/*     */   public void init(FilterConfig paramFilterConfig)
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  41 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)paramServletRequest;
/*  42 */     HttpServletResponse localHttpServletResponse = (HttpServletResponse)paramServletResponse;
/*  43 */     String str1 = localHttpServletRequest.getParameter("jcaptcha_response");
/*  44 */     String str2 = localHttpServletRequest.getServletPath();
/*     */ 
/*  47 */     if (JCaptchaConfig.enabled) {
/*  48 */       for (int i = 0; i < this.processesUrl.length; i++) {
/*  49 */         if (this.processesUrl[i].equals(str2))
/*     */         {
/*  51 */           if (str1 == null) {
/*  52 */             localHttpServletResponse.setContentType("text/html");
/*  53 */             localHttpServletRequest.setAttribute("jcaptchaMsg", "error");
/*  54 */             localHttpServletRequest.setAttribute("loginErrorMsg", "错误的验证码。");
/*  55 */             localObject = localHttpServletRequest.getRequestDispatcher(this.targetUrl[i]);
/*  56 */             ((RequestDispatcher)localObject).forward(localHttpServletRequest, localHttpServletResponse);
/*     */           }
/*     */ 
/*  59 */           Object localObject = Boolean.FALSE;
/*  60 */           String str3 = localHttpServletRequest.getSession().getId();
/*     */           try {
/*  62 */             localObject = CaptchaService.getInstance()
/*  63 */               .validateResponseForID(str3, str1);
/*     */           } catch (CaptchaServiceException localCaptchaServiceException) {
/*  65 */             this.logger.error("", localCaptchaServiceException);
/*     */           }
/*  67 */           if (!((Boolean)localObject).booleanValue())
/*     */           {
/*  69 */             localHttpServletResponse.setContentType("text/html");
/*  70 */             localHttpServletRequest.setAttribute("jcaptchaMsg", "error");
/*  71 */             localHttpServletRequest.setAttribute("loginErrorMsg", "错误的验证码。");
/*  72 */             RequestDispatcher localRequestDispatcher = localHttpServletRequest.getRequestDispatcher(this.targetUrl[i]);
/*  73 */             localRequestDispatcher.forward(localHttpServletRequest, localHttpServletResponse);
/*     */           }
/*     */           else {
/*  76 */             paramFilterChain.doFilter(localHttpServletRequest, localHttpServletResponse);
/*  77 */             return;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  82 */     paramFilterChain.doFilter(localHttpServletRequest, localHttpServletResponse);
/*     */   }
/*     */ 
/*     */   public CaptchaService getCaptchaService() {
/*  86 */     return this.captchaService;
/*     */   }
/*     */   public void setCaptchaService(CaptchaService paramCaptchaService) {
/*  89 */     this.captchaService = paramCaptchaService;
/*     */   }
/*     */ 
/*     */   public String[] getTargetUrl() {
/*  93 */     return this.targetUrl;
/*     */   }
/*     */ 
/*     */   public void setTargetUrl(String[] paramArrayOfString) {
/*  97 */     this.targetUrl = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   public String[] getProcessesUrl() {
/* 101 */     return this.processesUrl;
/*     */   }
/*     */ 
/*     */   public void setProcessesUrl(String[] paramArrayOfString) {
/* 105 */     this.processesUrl = paramArrayOfString;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.webapp.JCaptchaProcessingFilter
 * JD-Core Version:    0.6.2
 */