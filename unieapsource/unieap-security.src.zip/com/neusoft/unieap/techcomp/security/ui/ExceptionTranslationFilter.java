/*     */ package com.neusoft.unieap.techcomp.security.ui;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.event.SuccessfulAuthenticationEvent;
/*     */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*     */ import com.neusoft.unieap.core.event.UnsuccessfulAuthenticationEvent;
/*     */ import com.neusoft.unieap.core.util.ClientUtil;
/*     */ import com.neusoft.unieap.core.util.UrlBase64Util;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.org.bootstrap.OrgActivator;
/*     */ import com.neusoft.unieap.techcomp.org.util.CrytogramUtil;
/*     */ import com.neusoft.unieap.techcomp.ria.context.ViewContext;
/*     */ import com.neusoft.unieap.techcomp.ria.context.impl.ViewContextImpl;
/*     */ import com.neusoft.unieap.techcomp.security.listener.OnlineUserSessionBindingListener;
/*     */ import com.neusoft.unieap.techcomp.security.onlineuser.OnlineUserConfig;
/*     */ import com.neusoft.unieap.techcomp.security.ui.webapp.ReloginProcessing;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.security.AccessDeniedException;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.AuthenticationException;
/*     */ import org.springframework.security.AuthenticationManager;
/*     */ import org.springframework.security.AuthenticationTrustResolver;
/*     */ import org.springframework.security.AuthenticationTrustResolverImpl;
/*     */ import org.springframework.security.InsufficientAuthenticationException;
/*     */ import org.springframework.security.SpringSecurityException;
/*     */ import org.springframework.security.context.SecurityContext;
/*     */ import org.springframework.security.context.SecurityContextHolder;
/*     */ import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.providers.dao.UserCache;
/*     */ import org.springframework.security.ui.AccessDeniedHandler;
/*     */ import org.springframework.security.ui.AccessDeniedHandlerImpl;
/*     */ import org.springframework.security.ui.AuthenticationDetailsSource;
/*     */ import org.springframework.security.ui.AuthenticationEntryPoint;
/*     */ import org.springframework.security.ui.FilterChainOrder;
/*     */ import org.springframework.security.ui.WebAuthenticationDetails;
/*     */ import org.springframework.security.ui.WebAuthenticationDetailsSource;
/*     */ import org.springframework.security.ui.savedrequest.SavedRequest;
/*     */ import org.springframework.security.util.PortResolver;
/*     */ import org.springframework.security.util.PortResolverImpl;
/*     */ import org.springframework.security.util.ThrowableAnalyzer;
/*     */ import org.springframework.security.util.ThrowableCauseExtractor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import org.springframework.web.context.support.WebApplicationContextUtils;
/*     */ 
/*     */ public class ExceptionTranslationFilter extends org.springframework.security.ui.ExceptionTranslationFilter
/*     */   implements InitializingBean
/*     */ {
/* 115 */   private AccessDeniedHandler accessDeniedHandler = new AccessDeniedHandlerImpl();
/*     */   private AuthenticationEntryPoint authenticationEntryPoint;
/* 117 */   private AuthenticationTrustResolver authenticationTrustResolver = new AuthenticationTrustResolverImpl();
/* 118 */   private PortResolver portResolver = new PortResolverImpl();
/* 119 */   private ThrowableAnalyzer throwableAnalyzer = new DefaultThrowableAnalyzer(null);
/* 120 */   private boolean createSessionAllowed = true;
/*     */   private AuthenticationManager authenticationManager;
/*     */   private ReloginProcessing reloginProcessing;
/*     */   private OrgActivator orgActivator;
/*     */   private OnlineUserConfig onlineUserConfig;
/* 126 */   protected AuthenticationDetailsSource authenticationDetailsSource = new WebAuthenticationDetailsSource();
/*     */   private UniEAPEventPublisher publisher;
/*     */   private EAPCacheManager eapCacheManager;
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 133 */     Assert.notNull(this.authenticationEntryPoint, "authenticationEntryPoint must be specified");
/* 134 */     Assert.notNull(this.portResolver, "portResolver must be specified");
/* 135 */     Assert.notNull(this.authenticationTrustResolver, "authenticationTrustResolver must be specified");
/* 136 */     Assert.notNull(this.throwableAnalyzer, "throwableAnalyzer must be specified");
/*     */   }
/*     */ 
/*     */   public void doFilterHttp(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException
/*     */   {
/*     */     try
/*     */     {
/* 143 */       chain.doFilter(request, response);
/*     */ 
/* 145 */       if (this.logger.isDebugEnabled())
/* 146 */         this.logger.debug("Chain processed normally");
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 150 */       throw ex;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 154 */       Throwable[] causeChain = this.throwableAnalyzer.determineCauseChain(ex);
/* 155 */       SpringSecurityException ase = (SpringSecurityException)
/* 156 */         this.throwableAnalyzer.getFirstThrowableOfType(SpringSecurityException.class, causeChain);
/*     */ 
/* 158 */       if (ase != null) {
/* 159 */         handleException(request, response, chain, ase);
/*     */       }
/*     */       else
/*     */       {
/* 163 */         if ((ex instanceof ServletException)) {
/* 164 */           throw ((ServletException)ex);
/*     */         }
/* 166 */         if ((ex instanceof RuntimeException)) {
/* 167 */           throw ((RuntimeException)ex);
/*     */         }
/*     */ 
/* 171 */         throw new RuntimeException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public AuthenticationEntryPoint getAuthenticationEntryPoint() {
/* 177 */     return this.authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */   public AuthenticationTrustResolver getAuthenticationTrustResolver() {
/* 181 */     return this.authenticationTrustResolver;
/*     */   }
/*     */ 
/*     */   public PortResolver getPortResolver() {
/* 185 */     return this.portResolver;
/*     */   }
/*     */ 
/*     */   private void handleException(ServletRequest request, ServletResponse response, FilterChain chain, SpringSecurityException exception) throws IOException, ServletException
/*     */   {
/* 190 */     if ((exception instanceof AuthenticationException)) {
/* 191 */       if (this.logger.isDebugEnabled()) {
/* 192 */         this.logger.debug("Authentication exception occurred; redirecting to authentication entry point", exception);
/*     */       }
/* 194 */       sendStartAuthentication(request, response, chain, (AuthenticationException)exception);
/*     */     }
/* 196 */     else if ((exception instanceof AccessDeniedException)) {
/* 197 */       if (this.authenticationTrustResolver.isAnonymous(SecurityContextHolder.getContext().getAuthentication())) {
/* 198 */         if (this.logger.isDebugEnabled()) {
/* 199 */           this.logger.debug("Access is denied (user is anonymous); redirecting to authentication entry point", 
/* 200 */             exception);
/*     */         }
/*     */ 
/* 203 */         sendStartAuthentication(request, response, chain, new InsufficientAuthenticationException(
/* 204 */           "Full authentication is required to access this resource"));
/*     */       }
/*     */       else {
/* 207 */         if (this.logger.isDebugEnabled()) {
/* 208 */           this.logger.debug("Access is denied (user is not anonymous); delegating to AccessDeniedHandler", 
/* 209 */             exception);
/*     */         }
/*     */ 
/* 212 */         this.accessDeniedHandler.handle(request, response, (AccessDeniedException)exception);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCreateSessionAllowed()
/*     */   {
/* 231 */     return this.createSessionAllowed;
/*     */   }
/*     */ 
/*     */   protected void sendStartAuthentication(ServletRequest request, ServletResponse response, FilterChain chain, AuthenticationException reason) throws ServletException, IOException
/*     */   {
/* 236 */     HttpServletRequest httpRequest = (HttpServletRequest)request;
/* 237 */     HttpServletResponse httpResponse = (HttpServletResponse)response;
/*     */ 
/* 239 */     SavedRequest savedRequest = new SavedRequest(httpRequest, this.portResolver);
/*     */ 
/* 241 */     if (this.logger.isDebugEnabled()) {
/* 242 */       this.logger.debug("Authentication entry point being called; SavedRequest added to Session: " + savedRequest);
/*     */     }
/*     */ 
/* 245 */     if (this.createSessionAllowed)
/*     */     {
/* 248 */       httpRequest.getSession().setAttribute("SPRING_SECURITY_SAVED_REQUEST_KEY", savedRequest);
/*     */     }
/*     */ 
/* 251 */     String targetUrl = savedRequest.getFullRequestUrl();
/* 252 */     String eap_username = httpRequest.getParameter("eap_username");
/* 253 */     String eap_password = httpRequest.getParameter("eap_password");
/* 254 */     String eap_authentication = httpRequest.getParameter("eap_authentication");
/* 255 */     if ((eap_username != null) && (eap_password != null)) {
/* 256 */       if (CoreVariability.isUrlPasswordEncrypt()) {
/* 257 */         eap_username = UrlBase64Util.decode(eap_username);
/* 258 */         eap_password = UrlBase64Util.decode(eap_password);
/*     */       }
/* 260 */       UserCache uc = (UserCache)
/* 261 */         WebApplicationContextUtils.getWebApplicationContext(
/* 262 */         httpRequest.getSession().getServletContext()).getBean(
/* 263 */         "userCache");
/* 264 */       if ((uc != null) && (eap_username != null))
/* 265 */         uc.removeUserFromCache(eap_username);
/* 266 */       UsernamePasswordAuthenticationToken authRequest = null;
/* 267 */       authRequest = new UsernamePasswordAuthenticationToken(
/* 268 */         eap_username, CrytogramUtil.encrypt(eap_password, 
/* 269 */         this.orgActivator.getCrytogramAlgorithm()));
/* 270 */       authRequest.setDetails(this.authenticationDetailsSource.buildDetails(httpRequest));
/*     */       try
/*     */       {
/* 273 */         Authentication authentication = getAuthenticationManager().authenticate(authRequest);
/* 274 */         SecurityContext sc = SecurityContextHolder.getContext();
/* 275 */         sc.setAuthentication(authentication);
/* 276 */         SecurityContextHolder.setContext(sc);
/*     */ 
/* 278 */         String encodeUrl = httpResponse.encodeRedirectURL(targetUrl);
/* 279 */         String jSessionId = ((WebAuthenticationDetails)authRequest.getDetails()).getSessionId();
/*     */ 
/* 281 */         User user = (User)this.eapCacheManager.get(eap_username, "loginUsers");
/* 282 */         UniEAPContextHolder.getContext().getCurrentUser().setId(user.getId());
/* 283 */         UniEAPContextHolder.getContext().getCurrentUser().setName(user.getName());
/* 284 */         UniEAPContextHolder.getContext().getCurrentUser().setAccount(user.getAccount());
/* 285 */         UniEAPContextHolder.getContext().getCurrentUser().setRoles(user.getRoles());
/*     */ 
/* 287 */         if (user.getAdminRoleType() != null)
/* 288 */           UniEAPContextHolder.getContext().addCustomProperty("loginType", "1");
/*     */         else {
/* 290 */           UniEAPContextHolder.getContext().addCustomProperty("loginType", "0");
/*     */         }
/*     */ 
/* 294 */         this.publisher.publish(new SuccessfulAuthenticationEvent(user, httpRequest, httpResponse));
/*     */ 
/* 297 */         OnlineUserSessionBindingListener onlineUserListener = new OnlineUserSessionBindingListener(ClientUtil.getClientIp(httpRequest), user.getAccount());
/* 298 */         httpRequest.getSession().setAttribute("onlineUserListener", onlineUserListener);
/*     */ 
/* 301 */         if ((eap_authentication != null) && 
/* 302 */           (eap_authentication.equalsIgnoreCase("true"))) {
/* 303 */           httpResponse.setHeader("jsessionid", jSessionId);
/* 304 */           httpResponse.setStatus(201, "CREATED");
/* 305 */           return;
/*     */         }
/*     */ 
/* 309 */         if (httpRequest.getHeader("soapaction") != null) {
/* 310 */           ViewContext context = new ViewContextImpl();
/* 311 */           Map parameterMap = request.getParameterMap();
/* 312 */           Iterator it = parameterMap.entrySet().iterator();
/* 313 */           while (it.hasNext()) {
/* 314 */             Map.Entry entry = (Map.Entry)it.next();
/* 315 */             String key = entry.getKey().toString();
/* 316 */             Object value = entry.getValue();
/* 317 */             if (value.getClass().isArray()) {
/* 318 */               if (Array.getLength(value) == 1)
/* 319 */                 context.put(key, request.getParameter(key));
/*     */               else {
/* 321 */                 context.put(key, value);
/*     */               }
/*     */             }
/*     */           }
/* 325 */           UnieapRequestContextHolder.getRequestContext().put(
/* 326 */             "viewContext", context);
/*     */         }
/*     */ 
/* 330 */         String contentPath = httpRequest.getContextPath();
/* 331 */         String requestURI = httpRequest.getRequestURI();
/* 332 */         httpRequest.getRequestDispatcher(requestURI.substring(requestURI.indexOf(contentPath) + contentPath.length())).forward(httpRequest, httpResponse);
/*     */ 
/* 337 */         return;
/*     */       }
/*     */       catch (AuthenticationException e) {
/* 340 */         if ((eap_username != null) && (!eap_username.equals(""))) {
/* 341 */           this.publisher.publish(new UnsuccessfulAuthenticationEvent(eap_username, httpRequest, httpResponse, e));
/*     */         }
/* 343 */         if (this.reloginProcessing.isValidProcesses(httpRequest, httpResponse)) {
/* 344 */           return;
/*     */         }
/*     */ 
/* 347 */         httpResponse.addHeader("authentication", "error");
/* 348 */         httpResponse.sendError(401, "UNAUTHORIZED");
/* 349 */         SecurityContext sc = SecurityContextHolder.getContext();
/* 350 */         sc.setAuthentication(null);
/* 351 */         SecurityContextHolder.setContext(sc);
/* 352 */         if (!this.logger.isDebugEnabled()) return; 
/* 353 */       }this.logger
/* 354 */         .debug("Updated ContextHolder to contain null Authentication");
/*     */     }
/*     */     else
/*     */     {
/* 359 */       if (this.reloginProcessing.isValidProcesses(httpRequest, httpResponse)) {
/* 360 */         return;
/*     */       }
/*     */ 
/* 365 */       SecurityContextHolder.getContext().setAuthentication(null);
/*     */ 
/* 367 */       this.authenticationEntryPoint.commence(httpRequest, httpResponse, reason);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAccessDeniedHandler(AccessDeniedHandler accessDeniedHandler) {
/* 372 */     Assert.notNull(accessDeniedHandler, "AccessDeniedHandler required");
/* 373 */     this.accessDeniedHandler = accessDeniedHandler;
/*     */   }
/*     */ 
/*     */   public void setAuthenticationEntryPoint(AuthenticationEntryPoint authenticationEntryPoint) {
/* 377 */     this.authenticationEntryPoint = authenticationEntryPoint;
/*     */   }
/*     */ 
/*     */   public void setAuthenticationTrustResolver(AuthenticationTrustResolver authenticationTrustResolver) {
/* 381 */     this.authenticationTrustResolver = authenticationTrustResolver;
/*     */   }
/*     */ 
/*     */   public void setCreateSessionAllowed(boolean createSessionAllowed) {
/* 385 */     this.createSessionAllowed = createSessionAllowed;
/*     */   }
/*     */ 
/*     */   public void setPortResolver(PortResolver portResolver) {
/* 389 */     this.portResolver = portResolver;
/*     */   }
/*     */ 
/*     */   public void setThrowableAnalyzer(ThrowableAnalyzer throwableAnalyzer) {
/* 393 */     this.throwableAnalyzer = throwableAnalyzer;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 397 */     return FilterChainOrder.EXCEPTION_TRANSLATION_FILTER;
/*     */   }
/*     */ 
/*     */   public void setReloginProcessing(ReloginProcessing reloginProcessing) {
/* 401 */     this.reloginProcessing = reloginProcessing;
/*     */   }
/*     */ 
/*     */   public ReloginProcessing getReloginProcessing() {
/* 405 */     return this.reloginProcessing;
/*     */   }
/*     */ 
/*     */   public void setOrgActivator(OrgActivator orgActivator) {
/* 409 */     this.orgActivator = orgActivator;
/*     */   }
/*     */ 
/*     */   public OrgActivator getOrgActivator() {
/* 413 */     return this.orgActivator;
/*     */   }
/*     */ 
/*     */   public void setAuthenticationManager(AuthenticationManager authenticationManager) {
/* 417 */     this.authenticationManager = authenticationManager;
/*     */   }
/*     */ 
/*     */   public AuthenticationManager getAuthenticationManager() {
/* 421 */     return this.authenticationManager;
/*     */   }
/*     */ 
/*     */   public void setPublisher(UniEAPEventPublisher publisher) {
/* 425 */     this.publisher = publisher;
/*     */   }
/*     */   public void setOnlineUserConfig(OnlineUserConfig onlineUserConfig) {
/* 428 */     this.onlineUserConfig = onlineUserConfig;
/*     */   }
/*     */ 
/*     */   public OnlineUserConfig getOnlineUserConfig() {
/* 432 */     return this.onlineUserConfig;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager eapCacheManager) {
/* 436 */     this.eapCacheManager = eapCacheManager;
/*     */   }
/*     */ 
/*     */   private static final class DefaultThrowableAnalyzer extends ThrowableAnalyzer
/*     */   {
/*     */     protected void initExtractorMap()
/*     */     {
/* 448 */       super.initExtractorMap();
/*     */ 
/* 450 */       registerExtractor(ServletException.class, new ThrowableCauseExtractor() {
/*     */         public Throwable extractCause(Throwable throwable) {
/* 452 */           ThrowableAnalyzer.verifyThrowableHierarchy(throwable, ServletException.class);
/* 453 */           return ((ServletException)throwable).getRootCause();
/*     */         }
/*     */       });
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.ExceptionTranslationFilter
 * JD-Core Version:    0.6.2
 */