/*     */ package com.neusoft.unieap.techcomp.security.ui.sso;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.jasig.cas.client.session.HashMapBackedSessionMappingStorage;
/*     */ import org.jasig.cas.client.session.SessionMappingStorage;
/*     */ import org.jasig.cas.client.util.AbstractConfigurationFilter;
/*     */ import org.jasig.cas.client.util.CommonUtils;
/*     */ import org.jasig.cas.client.util.XmlUtils;
/*     */ 
/*     */ public final class SingleSignOutFilter extends AbstractConfigurationFilter
/*     */ {
/*     */   private String artifactParameterName;
/*  28 */   private static SessionMappingStorage SESSION_MAPPING_STORAGE = new HashMapBackedSessionMappingStorage();
/*  29 */   private static Log log = LogFactory.getLog(SingleSignOutFilter.class);
/*     */ 
/*     */   public SingleSignOutFilter()
/*     */   {
/*  34 */     this.artifactParameterName = "ticket";
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig paramFilterConfig)
/*     */     throws ServletException
/*     */   {
/*  41 */     setArtifactParameterName(getPropertyFromInitParams(paramFilterConfig, "artifactParameterName", "ticket"));
/*  42 */     init();
/*     */   }
/*     */ 
/*     */   public void init()
/*     */   {
/*  47 */     CommonUtils.assertNotNull(this.artifactParameterName, "artifactParameterName cannot be null.");
/*  48 */     CommonUtils.assertNotNull(SESSION_MAPPING_STORAGE, "sessionMappingStorage cannote be null.");
/*     */   }
/*     */ 
/*     */   public void setArtifactParameterName(String paramString)
/*     */   {
/*  53 */     this.artifactParameterName = paramString;
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException
/*     */   {
/*  58 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)paramServletRequest;
/*  59 */     String str1 = localHttpServletRequest.getParameter("logoutRequest");
/*  60 */     localHttpServletRequest.getParameterNames();
/*  61 */     localHttpServletRequest.getQueryString();
/*     */     String str2;
/*     */     HttpSession localHttpSession;
/*  62 */     if (CommonUtils.isNotBlank(str1)) {
/*  63 */       str2 = XmlUtils.getTextForElement(str1, "SessionIndex");
/*     */ 
/*  66 */       if (CommonUtils.isNotBlank(str2)) {
/*  67 */         localHttpSession = SESSION_MAPPING_STORAGE.removeSessionByMappingId(str2);
/*     */ 
/*  70 */         if (localHttpSession != null) {
/*  71 */           localHttpSession.getId();
/*     */           try {
/*  73 */             localHttpSession.invalidate();
/*     */           }
/*     */           catch (IllegalStateException localIllegalStateException)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/*  82 */       str2 = localHttpServletRequest.getParameter(this.artifactParameterName);
/*  83 */       localHttpSession = localHttpServletRequest.getSession(false);
/*     */ 
/*  85 */       if ((CommonUtils.isNotBlank(str2)) && (localHttpSession != null)) {
/*     */         try {
/*  87 */           SESSION_MAPPING_STORAGE.removeBySessionById(localHttpSession.getId());
/*     */         }
/*     */         catch (Exception localException) {
/*     */         }
/*  91 */         SESSION_MAPPING_STORAGE.addSessionById(str2, localHttpSession);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  96 */     paramFilterChain.doFilter(paramServletRequest, paramServletResponse);
/*     */   }
/*     */ 
/*     */   public static synchronized void setSessionMappingStorage(SessionMappingStorage paramSessionMappingStorage)
/*     */   {
/* 101 */     SESSION_MAPPING_STORAGE = paramSessionMappingStorage;
/*     */   }
/*     */ 
/*     */   public static SessionMappingStorage getSessionMappingStorage()
/*     */   {
/* 106 */     return SESSION_MAPPING_STORAGE;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.sso.SingleSignOutFilter
 * JD-Core Version:    0.6.2
 */