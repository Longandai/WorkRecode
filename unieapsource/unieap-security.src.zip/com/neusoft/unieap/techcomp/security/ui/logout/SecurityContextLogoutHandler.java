/*     */ package com.neusoft.unieap.techcomp.security.ui.logout;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.event.LogoutEvent;
/*     */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.security.dao.providers.SecurityUser;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.context.SecurityContext;
/*     */ import org.springframework.security.context.SecurityContextHolder;
/*     */ import org.springframework.security.providers.dao.UserCache;
/*     */ import org.springframework.security.ui.logout.LogoutHandler;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SecurityContextLogoutHandler
/*     */   implements LogoutHandler
/*     */ {
/*  46 */   private boolean invalidateHttpSession = true;
/*     */   private UserCache userCache;
/*     */   private EAPCacheManager eapCacheManager;
/*     */   private UniEAPEventPublisher publisher;
/*     */ 
/*     */   public UserCache getUserCache()
/*     */   {
/*  52 */     return this.userCache;
/*     */   }
/*     */ 
/*     */   public void setUserCache(UserCache paramUserCache) {
/*  56 */     this.userCache = paramUserCache;
/*     */   }
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/*  59 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */   public EAPCacheManager getEapCacheManager() {
/*  62 */     return this.eapCacheManager;
/*     */   }
/*     */ 
/*     */   public void logout(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Authentication paramAuthentication)
/*     */   {
/*  72 */     Assert.notNull(paramHttpServletRequest, "HttpServletRequest required");
/*  73 */     if (this.invalidateHttpSession) {
/*  74 */       localObject = paramHttpServletRequest.getSession(false);
/*  75 */       if (localObject != null) {
/*  76 */         ((HttpSession)localObject).invalidate();
/*     */       }
/*     */     }
/*     */ 
/*  80 */     Object localObject = UniEAPContextHolder.getContext().getCurrentUser();
/*  81 */     String str = ((User)localObject).getAccount();
/*  82 */     if (str != null) {
/*  83 */       this.publisher.publish(new LogoutEvent((User)localObject, paramHttpServletRequest, paramHttpServletResponse));
/*  84 */       UniEAPContextHolder.getContext().removeAllCustomProperties();
/*  85 */       UniEAPContextHolder.getContext().removeCurrentUser();
/*     */     }
/*     */ 
/*  89 */     SecurityContext localSecurityContext = SecurityContextHolder.getContext();
/*  90 */     if (localSecurityContext == null)
/*  91 */       return;
/*  92 */     Authentication localAuthentication = localSecurityContext.getAuthentication();
/*  93 */     if (localAuthentication == null) {
/*  94 */       return;
/*     */     }
/*  96 */     SecurityUser localSecurityUser = (SecurityUser)localAuthentication.getPrincipal();
/*  97 */     if (localSecurityUser == null) {
/*  98 */       return;
/*     */     }
/*     */ 
/* 101 */     str = localSecurityUser.getUsername();
/* 102 */     this.userCache.removeUserFromCache(str);
/*     */ 
/* 104 */     SecurityContextHolder.clearContext();
/*     */   }
/*     */ 
/*     */   public boolean isInvalidateHttpSession() {
/* 108 */     return this.invalidateHttpSession;
/*     */   }
/*     */ 
/*     */   public void setInvalidateHttpSession(boolean paramBoolean)
/*     */   {
/* 118 */     this.invalidateHttpSession = paramBoolean;
/*     */   }
/*     */ 
/*     */   public void setPublisher(UniEAPEventPublisher paramUniEAPEventPublisher) {
/* 122 */     this.publisher = paramUniEAPEventPublisher;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.ui.logout.SecurityContextLogoutHandler
 * JD-Core Version:    0.6.2
 */