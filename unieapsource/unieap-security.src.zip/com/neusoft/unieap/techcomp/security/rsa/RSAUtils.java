/*     */ package com.neusoft.unieap.techcomp.security.rsa;
/*     */ 
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.math.BigInteger;
/*     */ import java.security.InvalidParameterException;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.Provider;
/*     */ import java.security.PublicKey;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.InvalidKeySpecException;
/*     */ import java.security.spec.RSAPrivateKeySpec;
/*     */ import java.security.spec.RSAPublicKeySpec;
/*     */ import java.util.Date;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.codec.DecoderException;
/*     */ import org.apache.commons.codec.binary.Hex;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.commons.io.IOUtils;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ import org.apache.commons.lang.time.DateFormatUtils;
/*     */ import org.bouncycastle.jce.provider.BouncyCastleProvider;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public abstract class RSAUtils
/*     */ {
/*  47 */   private static final Logger LOGGER = LoggerFactory.getLogger(RSAUtils.class);
/*     */   private static final String ALGORITHOM = "RSA";
/*     */   private static final String RSA_PAIR_FILENAME = "__RSA_PAIR.txt";
/*     */   private static final int KEY_SIZE = 1024;
/*  56 */   private static final Provider DEFAULT_PROVIDER = new BouncyCastleProvider();
/*     */ 
/*  58 */   private static KeyPairGenerator keyPairGen = null;
/*  59 */   private static KeyFactory keyFactory = null;
/*     */ 
/*  61 */   private static KeyPair oneKeyPair = null;
/*     */ 
/*  72 */   private static File rsaPairFile = new File(getRSAPairFilePath());
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  67 */       keyPairGen = KeyPairGenerator.getInstance("RSA", DEFAULT_PROVIDER);
/*  68 */       keyFactory = KeyFactory.getInstance("RSA", DEFAULT_PROVIDER);
/*     */     } catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {
/*  70 */       LOGGER.error(localNoSuchAlgorithmException.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String getModulusOrExponent(String paramString)
/*     */   {
/*  79 */     RSAPublicKey localRSAPublicKey = getDefaultPublicKey();
/*  80 */     if (paramString.equals("modulus"))
/*  81 */       return new String(Hex.encodeHex(localRSAPublicKey.getModulus().toByteArray()));
/*  82 */     if (paramString.equals("exponent")) {
/*  83 */       return new String(Hex.encodeHex(localRSAPublicKey.getPublicExponent().toByteArray()));
/*     */     }
/*  85 */     return null;
/*     */   }
/*     */ 
/*     */   private static synchronized KeyPair generateKeyPair()
/*     */   {
/*     */     try
/*     */     {
/*  94 */       keyPairGen.initialize(1024, new SecureRandom(DateFormatUtils.format(new Date(), "yyyyMMdd").getBytes()));
/*  95 */       oneKeyPair = keyPairGen.generateKeyPair();
/*  96 */       saveKeyPair(oneKeyPair);
/*  97 */       return oneKeyPair;
/*     */     } catch (InvalidParameterException localInvalidParameterException) {
/*  99 */       LOGGER.error("KeyPairGenerator does not support a key length of 1024.", localInvalidParameterException);
/*     */     } catch (NullPointerException localNullPointerException) {
/* 101 */       LOGGER.error("RSAUtils#KEY_PAIR_GEN is null, can not generate KeyPairGenerator instance.", 
/* 102 */         localNullPointerException);
/*     */     }
/* 104 */     return null;
/*     */   }
/*     */ 
/*     */   private static String getRSAPairFilePath()
/*     */   {
/* 116 */     return I18nGlobalContext.getInstance().getServletContext().getRealPath(File.separator) + "WEB-INF" + File.separator + "__RSA_PAIR.txt";
/*     */   }
/*     */ 
/*     */   private static boolean isCreateKeyPairFile()
/*     */   {
/* 125 */     boolean bool = false;
/* 126 */     if ((!rsaPairFile.exists()) || (rsaPairFile.isDirectory())) {
/* 127 */       bool = true;
/*     */     }
/* 129 */     return bool;
/*     */   }
/*     */ 
/*     */   private static void saveKeyPair(KeyPair paramKeyPair)
/*     */   {
/* 138 */     FileOutputStream localFileOutputStream = null;
/* 139 */     ObjectOutputStream localObjectOutputStream = null;
/*     */     try {
/* 141 */       localFileOutputStream = FileUtils.openOutputStream(rsaPairFile);
/* 142 */       localObjectOutputStream = new ObjectOutputStream(localFileOutputStream);
/* 143 */       localObjectOutputStream.writeObject(paramKeyPair);
/*     */     } catch (Exception localException) {
/* 145 */       localException.printStackTrace();
/*     */     } finally {
/* 147 */       IOUtils.closeQuietly(localObjectOutputStream);
/* 148 */       IOUtils.closeQuietly(localFileOutputStream);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static KeyPair getKeyPair()
/*     */   {
/* 157 */     if (isCreateKeyPairFile())
/*     */     {
/* 159 */       return generateKeyPair();
/*     */     }
/* 161 */     if (oneKeyPair != null) {
/* 162 */       return oneKeyPair;
/*     */     }
/* 164 */     return readKeyPair();
/*     */   }
/*     */ 
/*     */   private static KeyPair readKeyPair()
/*     */   {
/* 169 */     FileInputStream localFileInputStream = null;
/* 170 */     ObjectInputStream localObjectInputStream = null;
/*     */     try {
/* 172 */       localFileInputStream = FileUtils.openInputStream(rsaPairFile);
/* 173 */       localObjectInputStream = new ObjectInputStream(localFileInputStream);
/* 174 */       oneKeyPair = (KeyPair)localObjectInputStream.readObject();
/* 175 */       return oneKeyPair;
/*     */     } catch (Exception localException) {
/* 177 */       localException.printStackTrace();
/*     */     } finally {
/* 179 */       IOUtils.closeQuietly(localObjectInputStream);
/* 180 */       IOUtils.closeQuietly(localFileInputStream);
/*     */     }
/* 182 */     return null;
/*     */   }
/*     */ 
/*     */   public static RSAPublicKey generateRSAPublicKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */   {
/* 193 */     RSAPublicKeySpec localRSAPublicKeySpec = new RSAPublicKeySpec(new BigInteger(paramArrayOfByte1), 
/* 194 */       new BigInteger(paramArrayOfByte2));
/*     */     try {
/* 196 */       return (RSAPublicKey)keyFactory.generatePublic(localRSAPublicKeySpec);
/*     */     } catch (InvalidKeySpecException localInvalidKeySpecException) {
/* 198 */       LOGGER.error("RSAPublicKeySpec is unavailable.", localInvalidKeySpecException);
/*     */     } catch (NullPointerException localNullPointerException) {
/* 200 */       LOGGER.error("RSAUtils#KEY_FACTORY is null, can not generate KeyFactory instance.", localNullPointerException);
/*     */     }
/* 202 */     return null;
/*     */   }
/*     */ 
/*     */   public static RSAPrivateKey generateRSAPrivateKey(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */   {
/* 213 */     RSAPrivateKeySpec localRSAPrivateKeySpec = new RSAPrivateKeySpec(new BigInteger(paramArrayOfByte1), 
/* 214 */       new BigInteger(paramArrayOfByte2));
/*     */     try {
/* 216 */       return (RSAPrivateKey)keyFactory.generatePrivate(localRSAPrivateKeySpec);
/*     */     } catch (InvalidKeySpecException localInvalidKeySpecException) {
/* 218 */       LOGGER.error("RSAPrivateKeySpec is unavailable.", localInvalidKeySpecException);
/*     */     } catch (NullPointerException localNullPointerException) {
/* 220 */       LOGGER.error("RSAUtils#KEY_FACTORY is null, can not generate KeyFactory instance.", localNullPointerException);
/*     */     }
/* 222 */     return null;
/*     */   }
/*     */ 
/*     */   public static RSAPrivateKey getRSAPrivateKey(String paramString1, String paramString2)
/*     */   {
/* 233 */     if ((StringUtils.isBlank(paramString1)) || (StringUtils.isBlank(paramString2))) {
/* 234 */       if (LOGGER.isDebugEnabled()) {
/* 235 */         LOGGER.debug("hexModulus and hexPrivateExponent cannot be empty. RSAPrivateKey value is null to return.");
/*     */       }
/* 237 */       return null;
/*     */     }
/* 239 */     byte[] arrayOfByte1 = (byte[])null;
/* 240 */     byte[] arrayOfByte2 = (byte[])null;
/*     */     try {
/* 242 */       arrayOfByte1 = Hex.decodeHex(paramString1.toCharArray());
/* 243 */       arrayOfByte2 = Hex.decodeHex(paramString2.toCharArray());
/*     */     } catch (DecoderException localDecoderException) {
/* 245 */       LOGGER.error("hexModulus or hexPrivateExponent value is invalid. return null(RSAPrivateKey).");
/*     */     }
/* 247 */     if ((arrayOfByte1 != null) && (arrayOfByte2 != null)) {
/* 248 */       return generateRSAPrivateKey(arrayOfByte1, arrayOfByte2);
/*     */     }
/* 250 */     return null;
/*     */   }
/*     */ 
/*     */   public static RSAPublicKey getRSAPublidKey(String paramString1, String paramString2)
/*     */   {
/* 261 */     if ((StringUtils.isBlank(paramString1)) || (StringUtils.isBlank(paramString2))) {
/* 262 */       if (LOGGER.isDebugEnabled()) {
/* 263 */         LOGGER.debug("hexModulus and hexPublicExponent cannot be empty. return null(RSAPublicKey).");
/*     */       }
/* 265 */       return null;
/*     */     }
/* 267 */     byte[] arrayOfByte1 = (byte[])null;
/* 268 */     byte[] arrayOfByte2 = (byte[])null;
/*     */     try {
/* 270 */       arrayOfByte1 = Hex.decodeHex(paramString1.toCharArray());
/* 271 */       arrayOfByte2 = Hex.decodeHex(paramString2.toCharArray());
/*     */     } catch (DecoderException localDecoderException) {
/* 273 */       LOGGER.error("hexModulus or hexPublicExponent value is invalid. return null(RSAPublicKey).");
/*     */     }
/* 275 */     if ((arrayOfByte1 != null) && (arrayOfByte2 != null)) {
/* 276 */       return generateRSAPublicKey(arrayOfByte1, arrayOfByte2);
/*     */     }
/* 278 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encrypt(PublicKey paramPublicKey, byte[] paramArrayOfByte)
/*     */     throws Exception
/*     */   {
/* 289 */     Cipher localCipher = Cipher.getInstance("RSA", DEFAULT_PROVIDER);
/* 290 */     localCipher.init(1, paramPublicKey);
/* 291 */     return localCipher.doFinal(paramArrayOfByte);
/*     */   }
/*     */ 
/*     */   public static byte[] decrypt(PrivateKey paramPrivateKey, byte[] paramArrayOfByte)
/*     */     throws Exception
/*     */   {
/* 302 */     Cipher localCipher = Cipher.getInstance("RSA", DEFAULT_PROVIDER);
/* 303 */     localCipher.init(2, paramPrivateKey);
/* 304 */     return localCipher.doFinal(paramArrayOfByte);
/*     */   }
/*     */ 
/*     */   public static String encryptString(PublicKey paramPublicKey, String paramString)
/*     */   {
/* 318 */     if ((paramPublicKey == null) || (paramString == null)) {
/* 319 */       return null;
/*     */     }
/* 321 */     byte[] arrayOfByte1 = paramString.getBytes();
/*     */     try {
/* 323 */       byte[] arrayOfByte2 = encrypt(paramPublicKey, arrayOfByte1);
/* 324 */       return new String(Hex.encodeHex(arrayOfByte2));
/*     */     } catch (Exception localException) {
/* 326 */       LOGGER.error(localException.getCause().getMessage());
/*     */     }
/* 328 */     return null;
/*     */   }
/*     */ 
/*     */   public static String encryptString(String paramString)
/*     */   {
/* 340 */     if (paramString == null) {
/* 341 */       return null;
/*     */     }
/* 343 */     byte[] arrayOfByte1 = paramString.getBytes();
/* 344 */     KeyPair localKeyPair = getKeyPair();
/*     */     try {
/* 346 */       byte[] arrayOfByte2 = encrypt((RSAPublicKey)localKeyPair.getPublic(), arrayOfByte1);
/* 347 */       return new String(Hex.encodeHex(arrayOfByte2));
/*     */     } catch (NullPointerException localNullPointerException) {
/* 349 */       LOGGER.error("keyPair cannot be null.");
/*     */     } catch (Exception localException) {
/* 351 */       LOGGER.error(localException.getCause().getMessage());
/*     */     }
/* 353 */     return null;
/*     */   }
/*     */ 
/*     */   public static String decryptString(PrivateKey paramPrivateKey, String paramString)
/*     */   {
/* 367 */     if ((paramPrivateKey == null) || (StringUtils.isBlank(paramString)))
/* 368 */       return null;
/*     */     try
/*     */     {
/* 371 */       byte[] arrayOfByte1 = Hex.decodeHex(paramString.toCharArray());
/* 372 */       byte[] arrayOfByte2 = decrypt(paramPrivateKey, arrayOfByte1);
/* 373 */       return new String(arrayOfByte2);
/*     */     } catch (Exception localException) {
/* 375 */       LOGGER.error(String.format("\"%s\" Decryption failed. Cause: %s", new Object[] { paramString, localException.getCause().getMessage() }));
/*     */     }
/* 377 */     return null;
/*     */   }
/*     */ 
/*     */   public static String decryptString(String paramString)
/*     */   {
/* 390 */     if (StringUtils.isBlank(paramString)) {
/* 391 */       return null;
/*     */     }
/* 393 */     KeyPair localKeyPair = getKeyPair();
/*     */     try {
/* 395 */       byte[] arrayOfByte1 = Hex.decodeHex(paramString.toCharArray());
/* 396 */       byte[] arrayOfByte2 = decrypt((RSAPrivateKey)localKeyPair.getPrivate(), arrayOfByte1);
/* 397 */       return new String(arrayOfByte2);
/*     */     } catch (NullPointerException localNullPointerException) {
/* 399 */       LOGGER.error("keyPair cannot be null.");
/*     */     } catch (Exception localException) {
/* 401 */       LOGGER.error(String.format("\"%s\" Decryption failed. Cause: %s", new Object[] { paramString, localException.getMessage() }));
/*     */     }
/* 403 */     return null;
/*     */   }
/*     */ 
/*     */   public static String decryptStringByJs(String paramString)
/*     */   {
/* 413 */     String str = decryptString(paramString);
/* 414 */     if (str == null) {
/* 415 */       return null;
/*     */     }
/* 417 */     return StringUtils.reverse(str);
/*     */   }
/*     */ 
/*     */   public static RSAPublicKey getDefaultPublicKey()
/*     */   {
/* 422 */     KeyPair localKeyPair = getKeyPair();
/* 423 */     if (localKeyPair != null) {
/* 424 */       return (RSAPublicKey)localKeyPair.getPublic();
/*     */     }
/* 426 */     return null;
/*     */   }
/*     */ 
/*     */   public static RSAPrivateKey getDefaultPrivateKey()
/*     */   {
/* 431 */     KeyPair localKeyPair = getKeyPair();
/* 432 */     if (localKeyPair != null) {
/* 433 */       return (RSAPrivateKey)localKeyPair.getPrivate();
/*     */     }
/* 435 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.rsa.RSAUtils
 * JD-Core Version:    0.6.2
 */