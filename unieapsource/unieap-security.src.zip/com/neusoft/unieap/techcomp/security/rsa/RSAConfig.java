/*    */ package com.neusoft.unieap.techcomp.security.rsa;
/*    */ 
/*    */ public class RSAConfig
/*    */ {
/*  5 */   public static boolean enabled = false;
/*    */ 
/*    */   public boolean isEnabled() {
/*  8 */     return enabled;
/*    */   }
/*    */   public void setEnabled(boolean paramBoolean) {
/* 11 */     enabled = paramBoolean;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.rsa.RSAConfig
 * JD-Core Version:    0.6.2
 */