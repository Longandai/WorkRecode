/*    */ package com.neusoft.unieap.techcomp.security.jcaptcha;
/*    */ 
/*    */ import com.octo.captcha.service.captchastore.MapCaptchaStore;
/*    */ import com.octo.captcha.service.image.DefaultManageableImageCaptchaService;
/*    */ import com.octo.captcha.service.image.ImageCaptchaService;
/*    */ 
/*    */ public class CaptchaService
/*    */ {
/*    */   private static ImageCaptchaService instance;
/* 10 */   private static ImageCaptchaEngine engine1 = new ImageCaptchaEngine();
/*    */   private String acceptedChars;
/*    */ 
/*    */   public String getAcceptedChars()
/*    */   {
/* 14 */     return this.acceptedChars;
/*    */   }
/*    */ 
/*    */   public void setAcceptedChars(String paramString) {
/* 18 */     this.acceptedChars = paramString;
/*    */   }
/*    */ 
/*    */   public static ImageCaptchaService getInstance() {
/* 22 */     MapCaptchaStore localMapCaptchaStore = new MapCaptchaStore();
/* 23 */     if (instance == null) {
/* 24 */       instance = new DefaultManageableImageCaptchaService(localMapCaptchaStore, engine1, 
/* 25 */         10, 100000, 75000);
/*    */     }
/* 27 */     return instance;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.jcaptcha.CaptchaService
 * JD-Core Version:    0.6.2
 */