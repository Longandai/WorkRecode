/*     */ package com.neusoft.unieap.techcomp.security.jcaptcha;
/*     */ 
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.octo.captcha.component.image.backgroundgenerator.FunkyBackgroundGenerator;
/*     */ import com.octo.captcha.component.image.color.SingleColorGenerator;
/*     */ import com.octo.captcha.component.image.fontgenerator.RandomFontGenerator;
/*     */ import com.octo.captcha.component.image.textpaster.RandomTextPaster;
/*     */ import com.octo.captcha.component.image.wordtoimage.ComposedWordToImage;
/*     */ import com.octo.captcha.component.word.wordgenerator.RandomWordGenerator;
/*     */ import com.octo.captcha.engine.image.ListImageCaptchaEngine;
/*     */ import com.octo.captcha.image.gimpy.GimpyFactory;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.lang.reflect.Constructor;
/*     */ 
/*     */ public class ImageCaptchaEngine extends ListImageCaptchaEngine
/*     */ {
/*     */   protected void buildInitialFactories()
/*     */   {
/*  27 */     JCaptchaConfig localJCaptchaConfig = (JCaptchaConfig)BeanUtil.getBean("jcaptchaConfig");
/*  28 */     String str1 = localJCaptchaConfig.getAcceptedChars();
/*  29 */     Integer localInteger1 = localJCaptchaConfig.getMinWordLength();
/*  30 */     Integer localInteger2 = localJCaptchaConfig.getMaxWordLength();
/*  31 */     Integer localInteger3 = localJCaptchaConfig.getMinFontSize();
/*  32 */     Integer localInteger4 = localJCaptchaConfig.getMaxFontSize();
/*  33 */     Integer localInteger5 = localJCaptchaConfig.getBgWidth();
/*  34 */     Integer localInteger6 = localJCaptchaConfig.getBgHeight();
/*  35 */     String str2 = localJCaptchaConfig.getTextColor();
/*  36 */     String str3 = localJCaptchaConfig.getBgColor();
/*     */ 
/*  38 */     RandomWordGenerator localRandomWordGenerator = new RandomWordGenerator(str1);
/*     */ 
/*  40 */     RandomTextPaster localRandomTextPaster = new RandomTextPaster(
/*  41 */       localInteger1, localInteger2, getColorByString(str2));
/*     */ 
/*  43 */     FunkyBackgroundGenerator localFunkyBackgroundGenerator = new FunkyBackgroundGenerator(
/*  44 */       localInteger5, localInteger6, new SingleColorGenerator(
/*  45 */       getColorByString(str3)));
/*     */ 
/*  47 */     Font[] arrayOfFont = { new Font("Arial", 0, 10) };
/*  48 */     RandomFontGenerator localRandomFontGenerator = new RandomFontGenerator(
/*  49 */       localInteger3, localInteger4, arrayOfFont);
/*  50 */     ComposedWordToImage localComposedWordToImage = new ComposedWordToImage(
/*  51 */       localRandomFontGenerator, localFunkyBackgroundGenerator, localRandomTextPaster);
/*  52 */     addFactory(new GimpyFactory(localRandomWordGenerator, localComposedWordToImage));
/*     */   }
/*     */ 
/*     */   private Color getColorByString(String paramString)
/*     */   {
/*  61 */     Color localColor = null;
/*  62 */     if ("lightGray".equalsIgnoreCase(paramString.trim())) {
/*  63 */       localColor = Color.lightGray;
/*  64 */     } else if ("CYAN".equalsIgnoreCase(paramString.trim())) {
/*  65 */       localColor = Color.CYAN;
/*  66 */     } else if ("BLUE".equalsIgnoreCase(paramString.trim())) {
/*  67 */       localColor = Color.BLUE;
/*  68 */     } else if ("BLACK".equalsIgnoreCase(paramString.trim())) {
/*  69 */       localColor = Color.BLACK;
/*  70 */     } else if ("darkGray".equalsIgnoreCase(paramString.trim())) {
/*  71 */       localColor = Color.darkGray;
/*  72 */     } else if ("GRAY".equalsIgnoreCase(paramString.trim())) {
/*  73 */       localColor = Color.GRAY;
/*  74 */     } else if ("GREEN".equalsIgnoreCase(paramString.trim())) {
/*  75 */       localColor = Color.GREEN;
/*  76 */     } else if ("LIGHT_GRAY".equalsIgnoreCase(paramString.trim())) {
/*  77 */       localColor = Color.LIGHT_GRAY;
/*  78 */     } else if ("MAGENTA".equalsIgnoreCase(paramString.trim())) {
/*  79 */       localColor = Color.MAGENTA;
/*  80 */     } else if ("ORANGE".equalsIgnoreCase(paramString.trim())) {
/*  81 */       localColor = Color.ORANGE;
/*  82 */     } else if ("PINK".equalsIgnoreCase(paramString.trim())) {
/*  83 */       localColor = Color.PINK;
/*  84 */     } else if ("RED".equalsIgnoreCase(paramString.trim())) {
/*  85 */       localColor = Color.RED;
/*  86 */     } else if ("WHITE".equalsIgnoreCase(paramString.trim())) {
/*  87 */       localColor = Color.WHITE;
/*  88 */     } else if ("YELLOW".equalsIgnoreCase(paramString.trim())) {
/*  89 */       localColor = Color.YELLOW;
/*     */     } else {
/*  91 */       String[] arrayOfString = paramString.trim().split(",");
/*  92 */       Class[] arrayOfClass = new Class[arrayOfString.length];
/*  93 */       Integer[] arrayOfInteger = new Integer[arrayOfString.length];
/*  94 */       for (int i = 0; i < arrayOfString.length; i++) {
/*  95 */         arrayOfClass[i] = Integer.TYPE;
/*  96 */         arrayOfInteger[i] = Integer.valueOf(arrayOfString[i].trim());
/*     */       }
/*     */       try {
/*  99 */         localColor = 
/* 100 */           (Color)Class.forName("java.awt.Color")
/* 100 */           .getConstructor(arrayOfClass).newInstance(arrayOfInteger);
/*     */       } catch (Exception localException) {
/* 102 */         localException.printStackTrace();
/*     */       }
/*     */     }
/* 105 */     return localColor;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.jcaptcha.ImageCaptchaEngine
 * JD-Core Version:    0.6.2
 */