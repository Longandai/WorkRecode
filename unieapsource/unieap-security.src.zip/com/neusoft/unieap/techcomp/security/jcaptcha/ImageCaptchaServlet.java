/*    */ package com.neusoft.unieap.techcomp.security.jcaptcha;
/*    */ 
/*    */ import com.octo.captcha.service.CaptchaServiceException;
/*    */ import com.octo.captcha.service.image.ImageCaptchaService;
/*    */ import com.sun.image.codec.jpeg.JPEGCodec;
/*    */ import com.sun.image.codec.jpeg.JPEGImageEncoder;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.ServletConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletOutputStream;
/*    */ import javax.servlet.http.HttpServlet;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class ImageCaptchaServlet extends HttpServlet
/*    */ {
/*    */   private static final long serialVersionUID = 3258417209566116145L;
/* 28 */   Log logger = LogFactory.getLog(ImageCaptchaServlet.class);
/*    */ 
/*    */   public void init(ServletConfig paramServletConfig) throws ServletException {
/* 31 */     super.init(paramServletConfig);
/*    */   }
/*    */ 
/*    */   protected void doGet(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws ServletException, IOException
/*    */   {
/* 37 */     doPost(paramHttpServletRequest, paramHttpServletResponse);
/*    */   }
/*    */ 
/*    */   protected void doPost(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */     throws ServletException, IOException
/*    */   {
/* 44 */     byte[] arrayOfByte = (byte[])null;
/*    */ 
/* 46 */     ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
/*    */     try
/*    */     {
/* 49 */       String str = paramHttpServletRequest.getSession().getId();
/*    */ 
/* 51 */       BufferedImage localBufferedImage = CaptchaService.getInstance()
/* 52 */         .getImageChallengeForID(str, 
/* 53 */         paramHttpServletRequest.getLocale());
/*    */ 
/* 55 */       JPEGImageEncoder localJPEGImageEncoder = 
/* 56 */         JPEGCodec.createJPEGEncoder(localByteArrayOutputStream);
/* 57 */       localJPEGImageEncoder.encode(localBufferedImage);
/*    */     } catch (IllegalArgumentException localIllegalArgumentException) {
/* 59 */       paramHttpServletResponse.sendError(404);
/* 60 */       this.logger.error("", localIllegalArgumentException);
/* 61 */       return;
/*    */     } catch (CaptchaServiceException localCaptchaServiceException) {
/* 63 */       paramHttpServletResponse
/* 64 */         .sendError(500);
/* 65 */       this.logger.error("", localCaptchaServiceException);
/* 66 */       return;
/*    */     } catch (Exception localException) {
/* 68 */       paramHttpServletResponse
/* 69 */         .sendError(500);
/* 70 */       this.logger.error("", localException);
/* 71 */       return;
/*    */     }
/* 73 */     arrayOfByte = localByteArrayOutputStream.toByteArray();
/* 74 */     paramHttpServletResponse.setHeader("Cache-Control", "no-store");
/* 75 */     paramHttpServletResponse.setHeader("Pragma", "no-cache");
/* 76 */     paramHttpServletResponse.setDateHeader("Expires", 0L);
/* 77 */     paramHttpServletResponse.setContentType("image/jpeg");
/* 78 */     ServletOutputStream localServletOutputStream = paramHttpServletResponse
/* 79 */       .getOutputStream();
/* 80 */     localServletOutputStream.write(arrayOfByte);
/* 81 */     localServletOutputStream.flush();
/* 82 */     localServletOutputStream.close();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.jcaptcha.ImageCaptchaServlet
 * JD-Core Version:    0.6.2
 */