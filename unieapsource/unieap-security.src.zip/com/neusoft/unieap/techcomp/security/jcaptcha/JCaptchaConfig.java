/*    */ package com.neusoft.unieap.techcomp.security.jcaptcha;
/*    */ 
/*    */ public class JCaptchaConfig
/*    */ {
/*  5 */   public static boolean enabled = false;
/*  6 */   private String acceptedChars = "0123456789";
/*  7 */   private Integer minWordLength = Integer.valueOf(4);
/*  8 */   private Integer maxWordLength = Integer.valueOf(4);
/*  9 */   private Integer minFontSize = Integer.valueOf(15);
/* 10 */   private Integer maxFontSize = Integer.valueOf(15);
/* 11 */   private Integer bgWidth = Integer.valueOf(90);
/* 12 */   private Integer bgHeight = Integer.valueOf(30);
/* 13 */   private String textColor = "BLACK";
/* 14 */   private String bgColor = "WHITE";
/*    */ 
/*    */   public boolean isEnabled() {
/* 17 */     return enabled;
/*    */   }
/*    */   public void setEnabled(boolean paramBoolean) {
/* 20 */     enabled = paramBoolean;
/*    */   }
/*    */ 
/*    */   public String getAcceptedChars() {
/* 24 */     return this.acceptedChars;
/*    */   }
/*    */   public void setAcceptedChars(String paramString) {
/* 27 */     this.acceptedChars = paramString;
/*    */   }
/*    */   public Integer getMinWordLength() {
/* 30 */     return this.minWordLength;
/*    */   }
/*    */   public void setMinWordLength(Integer paramInteger) {
/* 33 */     this.minWordLength = paramInteger;
/*    */   }
/*    */   public Integer getMaxWordLength() {
/* 36 */     return this.maxWordLength;
/*    */   }
/*    */   public void setMaxWordLength(Integer paramInteger) {
/* 39 */     this.maxWordLength = paramInteger;
/*    */   }
/*    */   public Integer getMinFontSize() {
/* 42 */     return this.minFontSize;
/*    */   }
/*    */   public void setMinFontSize(Integer paramInteger) {
/* 45 */     this.minFontSize = paramInteger;
/*    */   }
/*    */   public Integer getMaxFontSize() {
/* 48 */     return this.maxFontSize;
/*    */   }
/*    */   public void setMaxFontSize(Integer paramInteger) {
/* 51 */     this.maxFontSize = paramInteger;
/*    */   }
/*    */   public Integer getBgWidth() {
/* 54 */     return this.bgWidth;
/*    */   }
/*    */   public void setBgWidth(Integer paramInteger) {
/* 57 */     this.bgWidth = paramInteger;
/*    */   }
/*    */   public Integer getBgHeight() {
/* 60 */     return this.bgHeight;
/*    */   }
/*    */   public void setBgHeight(Integer paramInteger) {
/* 63 */     this.bgHeight = paramInteger;
/*    */   }
/*    */   public String getTextColor() {
/* 66 */     return this.textColor;
/*    */   }
/*    */   public void setTextColor(String paramString) {
/* 69 */     this.textColor = paramString;
/*    */   }
/*    */   public String getBgColor() {
/* 72 */     return this.bgColor;
/*    */   }
/*    */   public void setBgColor(String paramString) {
/* 75 */     this.bgColor = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.jcaptcha.JCaptchaConfig
 * JD-Core Version:    0.6.2
 */