/*    */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.event.HostInfoEvent;
/*    */ import com.neusoft.unieap.techcomp.security.bo.ComputerInfoBO;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpSession;
/*    */ import org.apache.struts2.ServletActionContext;
/*    */ import org.springframework.web.context.ContextLoader;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ @ModelFile("computerInfoBO.bo")
/*    */ public class ComputerInfoBOImpl
/*    */   implements ComputerInfoBO
/*    */ {
/*    */   public void computerInfo(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 31 */     HttpSession localHttpSession = ServletActionContext.getRequest().getSession(false);
/* 32 */     if (localHttpSession != null) {
/* 33 */       localHttpSession.setAttribute("computerName", paramString3);
/* 34 */       localHttpSession.setAttribute("ipAddress", paramString1);
/* 35 */       localHttpSession.setAttribute("macAddress", paramString2);
/*    */     }
/* 37 */     if (ContextLoader.getCurrentWebApplicationContext() != null) {
/* 38 */       WebApplicationContext localWebApplicationContext = ContextLoader.getCurrentWebApplicationContext();
/* 39 */       HostInfoEvent localHostInfoEvent = new HostInfoEvent(new Object(), paramString3, paramString1, paramString2);
/* 40 */       localWebApplicationContext.publishEvent(localHostInfoEvent);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.ComputerInfoBOImpl
 * JD-Core Version:    0.6.2
 */