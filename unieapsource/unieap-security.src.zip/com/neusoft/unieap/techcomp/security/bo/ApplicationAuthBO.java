package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.common.bo.context.BOContext;
import java.util.List;

public abstract interface ApplicationAuthBO
{
  public abstract List getAllowedAvailableApplications();

  public abstract BOContext getAllowedAvailableInfo();
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.ApplicationAuthBO
 * JD-Core Version:    0.6.2
 */