package com.neusoft.unieap.techcomp.security.bo;

public abstract interface ComputerInfoBO
{
  public abstract void computerInfo(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.ComputerInfoBO
 * JD-Core Version:    0.6.2
 */