/*    */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*    */ import com.neusoft.unieap.core.security.entity.RoleUser;
/*    */ import com.neusoft.unieap.techcomp.org.dao.UserDAO;
/*    */ import com.neusoft.unieap.techcomp.security.bo.UserBusiRoleBO;
/*    */ import com.neusoft.unieap.techcomp.security.dao.BusiRoleDAO;
/*    */ import com.neusoft.unieap.techcomp.security.dao.UserBusiRoleDAO;
/*    */ import com.neusoft.unieap.techcomp.security.entity.BusiRole;
/*    */ import com.neusoft.unieap.techcomp.security.entity.BusiRoleUser;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Date;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("userBusiRoleBO.bo")
/*    */ public class UserBusiRoleBOImpl
/*    */   implements UserBusiRoleBO
/*    */ {
/*    */   private UserBusiRoleDAO userBusiRoleDAO;
/*    */   private BusiRoleDAO busiRoleDAO;
/*    */   private RoleUserDAO roleUserDAO;
/*    */   private UserDAO userDAO;
/*    */ 
/*    */   public void setUserBusiRoleDAO(UserBusiRoleDAO paramUserBusiRoleDAO)
/*    */   {
/* 35 */     this.userBusiRoleDAO = paramUserBusiRoleDAO;
/*    */   }
/*    */   public void setBusiRoleDAO(BusiRoleDAO paramBusiRoleDAO) {
/* 38 */     this.busiRoleDAO = paramBusiRoleDAO;
/*    */   }
/*    */   public void setRoleUserDAO(RoleUserDAO paramRoleUserDAO) {
/* 41 */     this.roleUserDAO = paramRoleUserDAO;
/*    */   }
/*    */   public void setUserDAO(UserDAO paramUserDAO) {
/* 44 */     this.userDAO = paramUserDAO;
/*    */   }
/*    */ 
/*    */   public List getBusiRolesByUserId(String paramString)
/*    */   {
/* 51 */     List localList = this.userBusiRoleDAO.getBusiRolesByUserId(paramString);
/* 52 */     return localList;
/*    */   }
/*    */ 
/*    */   public void saveUserBusiRoles(String paramString, List<BusiRole> paramList)
/*    */   {
/* 78 */     com.neusoft.unieap.techcomp.org.entity.User localUser = this.userDAO.getUserById(paramString);
/* 79 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getAccount();
/* 80 */     Timestamp localTimestamp = new Timestamp(new Date()
/* 81 */       .getTime());
/* 82 */     for (BusiRole localBusiRole : paramList)
/*    */     {
/* 84 */       BusiRoleUser localBusiRoleUser = new BusiRoleUser();
/* 85 */       localBusiRoleUser.setUser(localUser);
/* 86 */       localBusiRoleUser.setRole(localBusiRole);
/* 87 */       localBusiRoleUser.setCreatedBy(str);
/* 88 */       localBusiRoleUser.setCreationDate(localTimestamp);
/*    */ 
/* 90 */       this.busiRoleDAO.saveBusiRoleUser(localBusiRoleUser);
/*    */ 
/* 93 */       RoleUser localRoleUser = new RoleUser();
/* 94 */       localRoleUser.setRoleId(localBusiRole.getId());
/* 95 */       localRoleUser.setRoleName(localBusiRole.getName());
/* 96 */       localRoleUser.setRoleType("busiRole");
/* 97 */       localRoleUser.setUserId(localUser.getId());
/* 98 */       this.roleUserDAO.saveRoleUser(localRoleUser);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.UserBusiRoleBOImpl
 * JD-Core Version:    0.6.2
 */