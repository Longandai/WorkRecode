/*     */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*     */ import com.neusoft.unieap.core.security.entity.AdminRole;
/*     */ import com.neusoft.unieap.core.security.entity.RoleUser;
/*     */ import com.neusoft.unieap.techcomp.org.dao.UnitDAO;
/*     */ import com.neusoft.unieap.techcomp.security.bo.BusiRoleBO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.BusiRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.ResourceAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.SecurityAdminRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AdminRoleBusiRole;
/*     */ import com.neusoft.unieap.techcomp.security.entity.BusiRole;
/*     */ import com.neusoft.unieap.techcomp.security.entity.BusiRoleUser;
/*     */ import com.neusoft.unieap.techcomp.security.pojo.UserUnitStationPojo;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("busiRoleBO.bo")
/*     */ public class BusiRoleBOImpl
/*     */   implements BusiRoleBO
/*     */ {
/*     */   private BusiRoleDAO busiRoleDAO;
/*     */   private ResourceAuthorizeDAO resourceAuthorizeDAO;
/*     */   private UnitDAO unitDAO;
/*     */   private RoleUserDAO roleUserDAO;
/*     */   private SecurityAdminRoleDAO securityAdminRoleDAO;
/*     */ 
/*     */   public void setSecurityAdminRoleDAO(SecurityAdminRoleDAO paramSecurityAdminRoleDAO)
/*     */   {
/*  43 */     this.securityAdminRoleDAO = paramSecurityAdminRoleDAO;
/*     */   }
/*     */ 
/*     */   public void setBusiRoleDAO(BusiRoleDAO paramBusiRoleDAO) {
/*  47 */     this.busiRoleDAO = paramBusiRoleDAO;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeDAO(ResourceAuthorizeDAO paramResourceAuthorizeDAO)
/*     */   {
/*  52 */     this.resourceAuthorizeDAO = paramResourceAuthorizeDAO;
/*     */   }
/*     */ 
/*     */   public void setUnitDAO(UnitDAO paramUnitDAO) {
/*  56 */     this.unitDAO = paramUnitDAO;
/*     */   }
/*     */ 
/*     */   public void setRoleUserDAO(RoleUserDAO paramRoleUserDAO) {
/*  60 */     this.roleUserDAO = paramRoleUserDAO;
/*     */   }
/*     */ 
/*     */   public QueryResult getAllBusiRoles(int paramInt1, int paramInt2)
/*     */   {
/*  68 */     com.neusoft.unieap.core.context.properties.User localUser = 
/*  69 */       UniEAPContextHolder.getContext().getCurrentUser();
/*  70 */     QueryResult localQueryResult = new QueryResult();
/*     */     List localList;
/*     */     int i;
/*  71 */     if (localUser.getRoles("superAdminRole") != null)
/*     */     {
/*  73 */       if (localUser.getRoles("superAdminRole")
/*  73 */         .size() > 0) {
/*  74 */         localList = null;
/*  75 */         localList = this.busiRoleDAO.getAllBusiRoles(paramInt1, paramInt2);
/*  76 */         localQueryResult.setResult(localList);
/*  77 */         i = this.busiRoleDAO.getAllBusiRolesNumber();
/*  78 */         localQueryResult.setRecordCount(i);
/*  79 */         localQueryResult.setPageNumber(paramInt1);
/*  80 */         localQueryResult.setPageSize(paramInt2); break label203; } 
/*  81 */     }if (localUser.getRoles("secAdminRole") != null)
/*     */     {
/*  83 */       if (localUser.getRoles("secAdminRole")
/*  83 */         .size() > 0) {
/*  84 */         localList = null;
/*  85 */         localList = this.busiRoleDAO.getAllBusiRolesBySecurityRoleId(
/*  86 */           localUser
/*  87 */           .getRoleIds("secAdminRole")
/*  88 */           .get(0).toString(), paramInt1, paramInt2);
/*  89 */         localQueryResult.setResult(localList);
/*  90 */         i = this.busiRoleDAO
/*  91 */           .getAllBusiRolesNumberBySecurityRoleId(localUser
/*  92 */           .getRoleIds("secAdminRole")
/*  93 */           .get(0).toString());
/*  94 */         localQueryResult.setRecordCount(i);
/*  95 */         localQueryResult.setPageNumber(paramInt1);
/*  96 */         localQueryResult.setPageSize(paramInt2);
/*     */       }
/*     */     }
/*  99 */     label203: return localQueryResult;
/*     */   }
/*     */ 
/*     */   public BusiRole saveBusiRole(BusiRole paramBusiRole)
/*     */   {
/* 111 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getAccount();
/* 112 */     Timestamp localTimestamp = new Timestamp(new Date()
/* 113 */       .getTime());
/*     */ 
/* 116 */     com.neusoft.unieap.core.context.properties.User localUser = 
/* 117 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 118 */     paramBusiRole.setCreationDate(localTimestamp);
/* 119 */     paramBusiRole.setCreatedBy(str);
/* 120 */     paramBusiRole.setLastUpdateDate(localTimestamp);
/* 121 */     paramBusiRole.setLastUpdatedBy(str);
/* 122 */     if (localUser.getRoles("superAdminRole").size() > 0)
/*     */     {
/* 124 */       return this.busiRoleDAO.saveBusiRole(paramBusiRole);
/*     */     }
/*     */ 
/* 128 */     BusiRole localBusiRole = this.busiRoleDAO.saveBusiRole(paramBusiRole);
/*     */ 
/* 130 */     AdminRoleBusiRole localAdminRoleBusiRole = new AdminRoleBusiRole();
/* 131 */     AdminRole localAdminRole = new AdminRole();
/* 132 */     localAdminRole.setId(localUser.getRoleIds(
/* 133 */       "secAdminRole").get(0).toString());
/* 134 */     localAdminRoleBusiRole.setAdminRole(localAdminRole);
/* 135 */     localAdminRoleBusiRole.setBusiRole(localBusiRole);
/* 136 */     localAdminRoleBusiRole.setCreationDate(localTimestamp);
/* 137 */     localAdminRoleBusiRole.setCreatedBy(str);
/* 138 */     localAdminRoleBusiRole.setLastUpdateDate(localTimestamp);
/* 139 */     localAdminRoleBusiRole.setLastUpdatedBy(str);
/* 140 */     this.securityAdminRoleDAO.saveAdminRoleBusiRole(localAdminRoleBusiRole);
/* 141 */     return localBusiRole;
/*     */   }
/*     */ 
/*     */   public BusiRole updateBusiRole(BusiRole paramBusiRole, boolean paramBoolean)
/*     */   {
/* 152 */     if ((paramBoolean) && (this.busiRoleDAO.isNameAlreadyExist(paramBusiRole.getName()))) {
/* 153 */       throw new UniEAPBusinessException("EAPTECHSECURITY0001", new Object[] { paramBusiRole.getName() });
/*     */     }
/*     */ 
/* 156 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getAccount();
/* 157 */     Timestamp localTimestamp = new Timestamp(new Date()
/* 158 */       .getTime());
/* 159 */     paramBusiRole.setLastUpdateDate(localTimestamp);
/* 160 */     paramBusiRole.setLastUpdatedBy(str);
/*     */ 
/* 162 */     return this.busiRoleDAO.updateBusiRole(paramBusiRole);
/*     */   }
/*     */ 
/*     */   public void deleteBusiRoleById(String paramString)
/*     */   {
/* 170 */     this.resourceAuthorizeDAO.deleteResourceAuthorities(paramString);
/*     */ 
/* 172 */     this.busiRoleDAO.deleteAdminRoleBusiRoleByBusiRoleId(paramString);
/*     */ 
/* 174 */     this.busiRoleDAO.deleteBusiRoleUserByBusiRoleId(paramString);
/*     */ 
/* 176 */     this.roleUserDAO.deleteRoleUsersByRoleId(paramString);
/*     */ 
/* 178 */     this.busiRoleDAO.deleteBusiRoleById(paramString);
/*     */   }
/*     */ 
/*     */   public void saveBusiRoleUsers(String paramString, List<com.neusoft.unieap.techcomp.org.entity.User> paramList)
/*     */   {
/* 185 */     BusiRole localBusiRole = this.busiRoleDAO.getBusiRoleById(paramString);
/* 186 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getAccount();
/* 187 */     Timestamp localTimestamp = new Timestamp(new Date()
/* 188 */       .getTime());
/* 189 */     for (com.neusoft.unieap.techcomp.org.entity.User localUser : paramList)
/*     */     {
/* 191 */       BusiRoleUser localBusiRoleUser = new BusiRoleUser();
/* 192 */       localBusiRoleUser.setUser(localUser);
/* 193 */       localBusiRoleUser.setRole(localBusiRole);
/* 194 */       localBusiRoleUser.setCreatedBy(str);
/* 195 */       localBusiRoleUser.setCreationDate(localTimestamp);
/*     */ 
/* 197 */       this.busiRoleDAO.saveBusiRoleUser(localBusiRoleUser);
/*     */ 
/* 200 */       RoleUser localRoleUser = new RoleUser();
/* 201 */       localRoleUser.setRoleId(paramString);
/* 202 */       localRoleUser.setRoleName(localBusiRole.getName());
/* 203 */       localRoleUser.setRoleType("busiRole");
/* 204 */       localRoleUser.setUserId(localUser.getId());
/* 205 */       this.roleUserDAO.saveRoleUser(localRoleUser);
/*     */     }
/*     */   }
/*     */ 
/*     */   public QueryResult getUsersByBusiRoleId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 214 */     QueryResult localQueryResult = new QueryResult();
/*     */ 
/* 216 */     com.neusoft.unieap.core.context.properties.User localUser = 
/* 217 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 218 */     List localList1 = localUser
/* 219 */       .getRoleIds("secAdminRole");
/* 220 */     new ArrayList();
/*     */ 
/* 222 */     if ((localList1 == null) || (localList1.size() == 0)) {
/* 223 */       return localQueryResult;
/*     */     }
/*     */ 
/* 227 */     if (((String)localList1.get(0)).equalsIgnoreCase("adminRole")) {
/* 228 */       localList2 = this.busiRoleDAO.getUsersByBusiRoleId(paramString, paramInt1, paramInt2);
/* 229 */       i = this.busiRoleDAO.getUsersByBusiRoleIdNumber(paramString);
/* 230 */       localList3 = getUserUnitStationPojos(localList2);
/* 231 */       localQueryResult.setResult(localList3);
/* 232 */       localQueryResult.setRecordCount(i);
/* 233 */       localQueryResult.setPageNumber(paramInt1);
/* 234 */       localQueryResult.setPageSize(paramInt2);
/* 235 */       return localQueryResult;
/*     */     }
/* 237 */     List localList2 = this.busiRoleDAO.getUsersByBusiRoleId((String)localList1.get(0), paramString, paramInt1, 
/* 238 */       paramInt2);
/* 239 */     int i = this.busiRoleDAO.getUsersByBusiRoleIdNumber((String)localList1.get(0), paramString);
/*     */ 
/* 241 */     List localList3 = getUserUnitStationPojos(localList2);
/*     */ 
/* 243 */     localQueryResult.setResult(localList3);
/* 244 */     localQueryResult.setPageNumber(paramInt1);
/* 245 */     localQueryResult.setPageSize(paramInt2);
/* 246 */     localQueryResult.setRecordCount(i);
/*     */ 
/* 248 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public List<UserUnitStationPojo> getUserUnitStationPojos(List<com.neusoft.unieap.techcomp.org.entity.User> paramList)
/*     */   {
/* 256 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 258 */     for (com.neusoft.unieap.techcomp.org.entity.User localUser : paramList) {
/* 259 */       UserUnitStationPojo localUserUnitStationPojo = new UserUnitStationPojo();
/*     */ 
/* 261 */       localUserUnitStationPojo.setUserId(localUser.getId());
/*     */ 
/* 263 */       localUserUnitStationPojo.setUserAccount(localUser.getAccount());
/*     */ 
/* 265 */       localUserUnitStationPojo.setUserName(localUser.getName());
/*     */ 
/* 267 */       localUserUnitStationPojo.setUserType(localUser.getType());
/*     */ 
/* 269 */       List localList = this.unitDAO.getUnitNamesByuserId(localUser.getId());
/* 270 */       if (localList.size() > 0) {
/* 271 */         StringBuilder localStringBuilder = new StringBuilder("");
/* 272 */         for (int i = 0; i < localList.size() - 1; i++) {
/* 273 */           localStringBuilder.append((String)localList.get(i));
/* 274 */           localStringBuilder.append("，");
/*     */         }
/* 276 */         localStringBuilder.append((String)localList.get(localList.size() - 1));
/* 277 */         localUserUnitStationPojo.setUnitNames(localStringBuilder.toString());
/*     */       } else {
/* 279 */         localUserUnitStationPojo.setUnitNames("");
/*     */       }
/* 281 */       localArrayList.add(localUserUnitStationPojo);
/*     */     }
/* 283 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void deleteBusiRoleUser(String paramString1, String paramString2)
/*     */   {
/* 290 */     this.busiRoleDAO.deleteBusiRoleUser(paramString1, paramString2);
/*     */ 
/* 292 */     this.roleUserDAO.deleteRoleUser(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   public List getBusiRolesByUserId(String paramString)
/*     */   {
/* 299 */     return this.busiRoleDAO.getBusiRolesByUserId(paramString);
/*     */   }
/*     */ 
/*     */   public BusiRole getBusiRoleById(String paramString)
/*     */   {
/* 306 */     return this.busiRoleDAO.getBusiRoleById(paramString);
/*     */   }
/*     */ 
/*     */   public QueryResult getUsersByUnitIdExceptedBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2)
/*     */   {
/* 332 */     List localList = this.busiRoleDAO.getUsersByUnitIdExceptedBusiRoleId(paramString1, 
/* 333 */       paramString2, paramInt1, paramInt2);
/* 334 */     int i = this.busiRoleDAO.getUsersNumberByUnitIdExceptedBusiRoleId(
/* 335 */       paramString1, paramString2);
/* 336 */     QueryResult localQueryResult = new QueryResult();
/* 337 */     localQueryResult.setPageNumber(paramInt1);
/* 338 */     localQueryResult.setPageSize(paramInt2);
/* 339 */     localQueryResult.setResult(localList);
/* 340 */     localQueryResult.setRecordCount(i);
/* 341 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public void deleteBusiRoleUserByUserId(String paramString)
/*     */   {
/* 347 */     this.busiRoleDAO.deleteBusiRoleUserByUserId(paramString);
/*     */   }
/*     */ 
/*     */   public QueryResult getUsersByBusiRoleIdWithAdvancedQuery(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 355 */     QueryResult localQueryResult = new QueryResult();
/*     */ 
/* 357 */     com.neusoft.unieap.core.context.properties.User localUser = 
/* 358 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 359 */     List localList1 = localUser
/* 360 */       .getRoleIds("secAdminRole");
/* 361 */     new ArrayList();
/*     */ 
/* 363 */     if ((localList1 == null) || (localList1.size() == 0)) {
/* 364 */       return localQueryResult;
/*     */     }
/*     */ 
/* 368 */     if (((String)localList1.get(0)).equalsIgnoreCase("adminRole")) {
/* 369 */       localList2 = this.busiRoleDAO.getUsersByBusiRoleIdWithAdvanceQuery(paramString, paramInt1, paramInt2);
/* 370 */       i = this.busiRoleDAO.getUsersByBusiRoleIdNumberWithAdvanceQuery(paramString);
/* 371 */       localList3 = getUserUnitStationPojos(localList2);
/* 372 */       localQueryResult.setResult(localList3);
/* 373 */       localQueryResult.setRecordCount(i);
/* 374 */       localQueryResult.setPageNumber(paramInt1);
/* 375 */       localQueryResult.setPageSize(paramInt2);
/* 376 */       return localQueryResult;
/*     */     }
/* 378 */     List localList2 = this.busiRoleDAO.getUsersByBusiRoleIdWithAdvanceQuery((String)localList1.get(0), paramString, paramInt1, 
/* 379 */       paramInt2);
/* 380 */     int i = this.busiRoleDAO.getUsersByBusiRoleIdNumberWithAdvanceQuery((String)localList1.get(0), paramString);
/*     */ 
/* 382 */     List localList3 = getUserUnitStationPojos(localList2);
/*     */ 
/* 384 */     localQueryResult.setResult(localList3);
/* 385 */     localQueryResult.setPageNumber(paramInt1);
/* 386 */     localQueryResult.setPageSize(paramInt2);
/* 387 */     localQueryResult.setRecordCount(i);
/*     */ 
/* 389 */     return localQueryResult;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.BusiRoleBOImpl
 * JD-Core Version:    0.6.2
 */