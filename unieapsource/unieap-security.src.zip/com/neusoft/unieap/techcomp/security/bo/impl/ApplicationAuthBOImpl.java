/*    */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.annotation.RestService;
/*    */ import com.neusoft.unieap.core.base.model.Application;
/*    */ import com.neusoft.unieap.core.base.model.SCRepository;
/*    */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*    */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*    */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*    */ import com.neusoft.unieap.techcomp.security.bo.ApplicationAuthBO;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("applicationAuthBO.bo")
/*    */ public class ApplicationAuthBOImpl
/*    */   implements ApplicationAuthBO
/*    */ {
/*    */   private ResourceAuthorizeBO resourceAuthorizeBO;
/*    */   private EAPCacheManager eapCacheManager;
/*    */ 
/*    */   public void setResourceAuthorizeBO(ResourceAuthorizeBO paramResourceAuthorizeBO)
/*    */   {
/* 34 */     this.resourceAuthorizeBO = paramResourceAuthorizeBO;
/*    */   }
/*    */ 
/*    */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/* 38 */     this.eapCacheManager = paramEAPCacheManager;
/*    */   }
/*    */ 
/*    */   public List getAllowedAvailableApplications()
/*    */   {
/* 45 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 46 */     Object localObject = (List)this.eapCacheManager.get(
/* 47 */       localUser.getAccount(), "applicationAuthority");
/* 48 */     if (localObject == null) {
/* 49 */       localObject = new ArrayList();
/* 50 */       List localList1 = localUser.getRoleIds();
/* 51 */       List localList2 = SCRepository.getAvailableApplications();
/* 52 */       List localList3 = this.resourceAuthorizeBO.getResourceIds(localList1, "application", "available");
/*    */ 
/* 54 */       for (int i = 0; i < localList2.size(); i++) {
/* 55 */         Application localApplication = (Application)localList2.get(i);
/* 56 */         for (int j = 0; j < localList3.size(); j++) {
/* 57 */           if (localApplication.getId().equals(localList3.get(j))) {
/* 58 */             ((List)localObject).add(localApplication);
/* 59 */             break;
/*    */           }
/*    */         }
/*    */       }
/* 63 */       this.eapCacheManager.put(localUser.getAccount(), 
/* 64 */         localObject, "applicationAuthority");
/*    */     }
/* 66 */     return localObject;
/*    */   }
/*    */ 
/*    */   @RestService
/*    */   public BOContext getAllowedAvailableInfo()
/*    */   {
/* 72 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 73 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 74 */     if (localUser != null) {
/* 75 */       localBOContextImpl.put("user", localUser.getName());
/* 76 */       List localList = getAllowedAvailableApplications();
/* 77 */       localBOContextImpl.put("apps", localList);
/* 78 */       return localBOContextImpl;
/*    */     }
/* 80 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.ApplicationAuthBOImpl
 * JD-Core Version:    0.6.2
 */