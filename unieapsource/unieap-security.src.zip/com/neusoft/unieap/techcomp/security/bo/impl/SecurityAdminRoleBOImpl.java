/*     */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.Role;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*     */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*     */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*     */ import com.neusoft.unieap.core.security.entity.AdminRole;
/*     */ import com.neusoft.unieap.techcomp.org.bo.UnitBO;
/*     */ import com.neusoft.unieap.techcomp.org.dao.AdminRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.org.dao.UserDAO;
/*     */ import com.neusoft.unieap.techcomp.org.entity.AdminRoleUnit;
/*     */ import com.neusoft.unieap.techcomp.org.entity.DimensionUnit;
/*     */ import com.neusoft.unieap.techcomp.org.entity.Unit;
/*     */ import com.neusoft.unieap.techcomp.security.bo.BusiRoleBO;
/*     */ import com.neusoft.unieap.techcomp.security.bo.SecurityAdminRoleBO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.BusiRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.SecurityAdminRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AdminRoleBusiRole;
/*     */ import com.neusoft.unieap.techcomp.security.entity.BusiRole;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("securityAdminRoleBO.bo")
/*     */ public class SecurityAdminRoleBOImpl
/*     */   implements SecurityAdminRoleBO
/*     */ {
/*     */   private SecurityAdminRoleDAO securityAdminRoleDAO;
/*     */   private BusiRoleBO busiRoleBO;
/*     */   private UnitBO unitBO;
/*     */   private AdminRoleDAO adminRoleDAO;
/*     */   private RoleUserDAO roleUserDAO;
/*     */   private ResourceAuthorizeBO resourceAuthorizeBO;
/*     */   private BusiRoleDAO busiRoleDAO;
/*     */   private UserDAO userDAO;
/*     */ 
/*     */   public void setUserDAO(UserDAO paramUserDAO)
/*     */   {
/*  55 */     this.userDAO = paramUserDAO;
/*     */   }
/*     */ 
/*     */   public void setBusiRoleDAO(BusiRoleDAO paramBusiRoleDAO) {
/*  59 */     this.busiRoleDAO = paramBusiRoleDAO;
/*     */   }
/*     */ 
/*     */   public void setSecurityAdminRoleDAO(SecurityAdminRoleDAO paramSecurityAdminRoleDAO)
/*     */   {
/*  64 */     this.securityAdminRoleDAO = paramSecurityAdminRoleDAO;
/*     */   }
/*     */ 
/*     */   public void setBusiRoleBO(BusiRoleBO paramBusiRoleBO) {
/*  68 */     this.busiRoleBO = paramBusiRoleBO;
/*     */   }
/*     */ 
/*     */   public void setUnitBO(UnitBO paramUnitBO) {
/*  72 */     this.unitBO = paramUnitBO;
/*     */   }
/*     */ 
/*     */   public void setAdminRoleDAO(AdminRoleDAO paramAdminRoleDAO) {
/*  76 */     this.adminRoleDAO = paramAdminRoleDAO;
/*     */   }
/*     */ 
/*     */   public void setRoleUserDAO(RoleUserDAO paramRoleUserDAO) {
/*  80 */     this.roleUserDAO = paramRoleUserDAO;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeBO(ResourceAuthorizeBO paramResourceAuthorizeBO) {
/*  84 */     this.resourceAuthorizeBO = paramResourceAuthorizeBO;
/*     */   }
/*     */ 
/*     */   public void saveAdminRoleBusiRoles(String paramString, List<BusiRole> paramList)
/*     */   {
/*  92 */     String str = UniEAPContextHolder.getContext().getCurrentUser().getAccount();
/*  93 */     Timestamp localTimestamp = new Timestamp(new Date()
/*  94 */       .getTime());
/*  95 */     for (BusiRole localBusiRole : paramList) {
/*  96 */       AdminRoleBusiRole localAdminRoleBusiRole = new AdminRoleBusiRole();
/*  97 */       AdminRole localAdminRole = new AdminRole();
/*  98 */       localAdminRole.setId(paramString);
/*  99 */       localAdminRoleBusiRole.setAdminRole(localAdminRole);
/* 100 */       localAdminRoleBusiRole.setBusiRole(localBusiRole);
/* 101 */       localAdminRoleBusiRole.setCreatedBy(str);
/* 102 */       localAdminRoleBusiRole.setCreationDate(localTimestamp);
/* 103 */       localAdminRoleBusiRole.setLastUpdateDate(localTimestamp);
/* 104 */       localAdminRoleBusiRole.setLastUpdatedBy(str);
/* 105 */       this.securityAdminRoleDAO.saveAdminRoleBusiRole(localAdminRoleBusiRole);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteAdminRoleBusiRoles(String paramString, List paramList)
/*     */   {
/* 113 */     ArrayList localArrayList = new ArrayList();
/* 114 */     for (Object localObject2 = paramList.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject1 = ((Iterator)localObject2).next();
/* 115 */       BusiRole localBusiRole = (BusiRole)localObject1;
/* 116 */       localArrayList.add(localBusiRole.getId());
/*     */     }
/*     */ 
/* 119 */     Object localObject1 = this.securityAdminRoleDAO.getRolePath(paramString);
/*     */ 
/* 121 */     localObject2 = this.securityAdminRoleDAO
/* 122 */       .getDescendantAdminRoleIds(localObject1 + paramString + "/");
/*     */ 
/* 124 */     ((List)localObject2).add(paramString);
/*     */ 
/* 128 */     this.securityAdminRoleDAO.deleteAdminRoleBusiRoles((List)localObject2, localArrayList);
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedBusiRoles(int paramInt1, int paramInt2)
/*     */   {
/* 158 */     User localUser = 
/* 159 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 160 */     List localList = localUser.getRoles("secAdminRole");
/* 161 */     if ((localList == null) || (localList.size() == 0)) {
/* 162 */       localList = localUser.getRoles("superAdminRole");
/* 163 */       if ((localList == null) || (localList.size() == 0))
/* 164 */         return null;
/*     */     }
/* 166 */     Role localRole = (Role)localList.get(0);
/* 167 */     String str = localRole.getId();
/* 168 */     if ((str == null) || (str.equals("")))
/* 169 */       return null;
/* 170 */     return getManagedBusiRoles(str, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedBusiRoles(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 178 */     if (paramString.equals("adminRole"))
/* 179 */       return this.busiRoleBO.getAllBusiRoles(paramInt1, paramInt2);
/* 180 */     QueryResult localQueryResult = new QueryResult();
/* 181 */     List localList = null;
/* 182 */     localList = this.securityAdminRoleDAO.getManagedBusiRoles(paramString, 
/* 183 */       paramInt1, paramInt2);
/* 184 */     localQueryResult.setResult(localList);
/* 185 */     int i = this.securityAdminRoleDAO.getManagedBusiRolesNumber(paramString);
/* 186 */     localQueryResult.setRecordCount(i);
/* 187 */     localQueryResult.setPageNumber(paramInt1);
/* 188 */     localQueryResult.setPageSize(paramInt2);
/* 189 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedBusiRolesExceptUserId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 196 */     User localUser = 
/* 197 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 198 */     List localList1 = localUser.getRoles("secAdminRole");
/* 199 */     if ((localList1 == null) || (localList1.size() == 0)) {
/* 200 */       localList1 = localUser.getRoles("superAdminRole");
/* 201 */       if ((localList1 == null) || (localList1.size() == 0))
/* 202 */         return null;
/*     */     }
/* 204 */     Role localRole = (Role)localList1.get(0);
/* 205 */     String str = localRole.getId();
/* 206 */     if ((str == null) || (str.equals("")))
/* 207 */       return null;
/* 208 */     QueryResult localQueryResult = new QueryResult();
/* 209 */     List localList2 = null;
/* 210 */     int i = -1;
/* 211 */     if (str.equals("adminRole")) {
/* 212 */       localList2 = this.busiRoleDAO.getAllBusiRolesExceptUserId(paramString, paramInt1, paramInt2);
/* 213 */       i = this.busiRoleDAO.getAllBusiRolesNumberExceptUserId(paramString);
/*     */     }
/*     */     else {
/* 216 */       localList2 = this.securityAdminRoleDAO.getManagedBusiRolesExceptUserId(str, paramString, paramInt1, paramInt2);
/* 217 */       i = this.securityAdminRoleDAO.getManagedBusiRolesNumberExceptUserId(str, paramString);
/*     */     }
/*     */ 
/* 220 */     localQueryResult.setResult(localList2);
/* 221 */     localQueryResult.setRecordCount(i);
/* 222 */     localQueryResult.setPageNumber(paramInt1);
/* 223 */     localQueryResult.setPageSize(paramInt2);
/* 224 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public boolean deleteSecAdminRole(String paramString)
/*     */   {
/* 231 */     boolean bool = true;
/* 232 */     List localList = this.adminRoleDAO.getDirectAdminRoles(paramString, 
/* 233 */       "secAdminRole");
/*     */ 
/* 235 */     if ((localList != null) && (localList.size() > 0)) {
/* 236 */       bool = false;
/*     */     } else {
/* 238 */       this.adminRoleDAO.deleteAdminRoleUserByAdminRoleId(paramString);
/* 239 */       this.adminRoleDAO.deleteAdminRoleUnitByAdminRoleId(paramString);
/*     */ 
/* 241 */       this.securityAdminRoleDAO.deleteAdminRoleBusiRoles(paramString);
/* 242 */       this.adminRoleDAO.deleteAdminRoleById(paramString);
/*     */ 
/* 244 */       this.roleUserDAO.deleteRoleUsersByRoleId(paramString);
/*     */ 
/* 246 */       this.resourceAuthorizeBO.deleteResourceAuthorities(paramString);
/*     */     }
/* 248 */     return bool;
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 256 */     User localUser = 
/* 257 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 258 */     List localList1 = localUser.getRoles("secAdminRole");
/* 259 */     if ((localList1 == null) || (localList1.size() == 0))
/* 260 */       localList1 = localUser.getRoles("superAdminRole");
/* 261 */     Role localRole = (Role)localList1.get(0);
/* 262 */     String str = localRole.getId();
/* 263 */     if ((str == null) || (str.equals("")))
/* 264 */       return null;
/* 265 */     if (str.equals("adminRole"))
/* 266 */       return getAllBusiRolesExceptAdminRoleId(paramString, paramInt1, 
/* 267 */         paramInt2);
/* 268 */     QueryResult localQueryResult = new QueryResult();
/* 269 */     List localList2 = null;
/* 270 */     localList2 = this.securityAdminRoleDAO
/* 271 */       .getManagedBusiRolesExceptAdminRoleId(str, paramString, 
/* 272 */       paramInt1, paramInt2);
/* 273 */     localQueryResult.setResult(localList2);
/* 274 */     int i = this.securityAdminRoleDAO
/* 275 */       .getManagedBusiRolesNumberExceptAdminRoleId(str, paramString);
/* 276 */     localQueryResult.setRecordCount(i);
/* 277 */     localQueryResult.setPageNumber(paramInt1);
/* 278 */     localQueryResult.setPageSize(paramInt2);
/* 279 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public QueryResult getAllBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 287 */     List localList = null;
/* 288 */     QueryResult localQueryResult = new QueryResult();
/* 289 */     localList = this.securityAdminRoleDAO.getAllBusiRolesExceptAdminRoleId(
/* 290 */       paramString, paramInt1, paramInt2);
/* 291 */     localQueryResult.setResult(localList);
/* 292 */     int i = this.securityAdminRoleDAO
/* 293 */       .getAllBusiRolesNumberExceptAdminRoleId(paramString);
/* 294 */     localQueryResult.setRecordCount(i);
/* 295 */     localQueryResult.setPageNumber(paramInt1);
/* 296 */     localQueryResult.setPageSize(paramInt2);
/* 297 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedUsersExceptBusiRoleId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 305 */     QueryResult localQueryResult = new QueryResult();
/*     */ 
/* 307 */     User localUser = 
/* 308 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 309 */     List localList1 = localUser
/* 310 */       .getRoleIds("secAdminRole");
/* 311 */     new ArrayList();
/*     */ 
/* 313 */     if ((localList1 == null) || (localList1.size() == 0)) {
/* 314 */       return localQueryResult;
/*     */     }
/*     */ 
/* 318 */     if (((String)localList1.get(0)).equalsIgnoreCase("adminRole")) {
/* 319 */       localList2 = this.busiRoleDAO.getUsersExceptedBusiRoleIdWithAdvanceQuery(
/* 320 */         paramString, paramInt1, paramInt2);
/* 321 */       localQueryResult.setResult(localList2);
/* 322 */       i = this.busiRoleDAO
/* 323 */         .getUsersNumberExceptedBusiRoleIdWithAdvanceQuery(paramString);
/* 324 */       localQueryResult.setRecordCount(i);
/* 325 */       localQueryResult.setPageNumber(paramInt1);
/* 326 */       localQueryResult.setPageSize(paramInt2);
/* 327 */       return localQueryResult;
/*     */     }
/* 329 */     List localList2 = this.busiRoleDAO.getManagedUsersExceptBusiRoleId((String)localList1.get(0), paramString, paramInt1, paramInt2);
/* 330 */     int i = this.busiRoleDAO.getManagedUsersNumberExceptBusiRoleId((String)localList1.get(0), paramString);
/*     */ 
/* 332 */     localQueryResult.setResult(localList2);
/* 333 */     localQueryResult.setRecordCount(i);
/* 334 */     localQueryResult.setPageNumber(paramInt1);
/* 335 */     localQueryResult.setPageSize(paramInt2);
/* 336 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public boolean isSecAdminRole()
/*     */   {
/* 343 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 344 */     String str = localUser.getAdminRoleType();
/* 345 */     if ((str != null) && ((str.equalsIgnoreCase("secAdminRole")) || 
/* 346 */       (str.equalsIgnoreCase("superAdminRole")))) {
/* 347 */       return true;
/*     */     }
/* 349 */     throw new UniEAPBusinessException("EAPTECHORG0001", new Object[] { localUser.getAccount() });
/*     */   }
/*     */ 
/*     */   public QueryResult getUsersByResourceId(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2)
/*     */   {
/* 358 */     QueryResult localQueryResult = new QueryResult();
/*     */ 
/* 360 */     User localUser = 
/* 361 */       UniEAPContextHolder.getContext().getCurrentUser();
/* 362 */     String str = localUser.getAdminRoleType();
/* 363 */     if (str == null) {
/* 364 */       return localQueryResult;
/*     */     }
/* 366 */     List localList1 = localUser.getRoleIds(str);
/* 367 */     ArrayList localArrayList = new ArrayList();
/* 368 */     if ((localList1 == null) || (localList1.size() == 0)) {
/* 369 */       return localQueryResult;
/*     */     }
/*     */ 
/* 372 */     List localList2 = this.resourceAuthorizeBO.getRoleIds(paramString1, 
/* 373 */       paramString2, paramString3);
/* 374 */     if ((localList2 == null) || (localList2.size() == 0)) {
/* 375 */       return localQueryResult;
/*     */     }
/*     */ 
/* 383 */     if (((String)localList1.get(0)).equalsIgnoreCase("adminRole"))
/*     */     {
/* 386 */       localList3 = this.busiRoleDAO.getUsersByBusiRoleIds(localList2, paramInt1, paramInt2);
/* 387 */       int i = this.busiRoleDAO.getUsersNumberByBusiRoleIds(localList2);
/* 388 */       localQueryResult.setResult(localList3);
/* 389 */       localQueryResult.setRecordCount(i);
/* 390 */       localQueryResult.setPageNumber(paramInt1);
/* 391 */       localQueryResult.setPageSize(paramInt2);
/* 392 */       return localQueryResult;
/*     */     }
/*     */ 
/* 396 */     List localList3 = this.adminRoleDAO
/* 397 */       .getAdminRoleUnitsByAdminRoleIds(localList1);
/* 398 */     for (Object localObject2 = localList3.iterator(); ((Iterator)localObject2).hasNext(); ) { localObject1 = (AdminRoleUnit)((Iterator)localObject2).next();
/* 399 */       localArrayList.add(((AdminRoleUnit)localObject1).getUnit().getId());
/*     */     }
/*     */ 
/* 402 */     Object localObject1 = new ArrayList();
/* 403 */     for (Object localObject3 = localList3.iterator(); ((Iterator)localObject3).hasNext(); ) { localObject2 = (AdminRoleUnit)((Iterator)localObject3).next();
/* 404 */       if (((AdminRoleUnit)localObject2).getIsCascade().booleanValue()) {
/* 405 */         ((List)localObject1).add(((AdminRoleUnit)localObject2).getDimensionUnit().getUnitPath() + 
/* 406 */           ((AdminRoleUnit)localObject2).getDimensionUnit().getId());
/*     */       }
/*     */     }
/*     */ 
/* 410 */     localObject2 = this.adminRoleDAO.getDimensionUnits((List)localObject1);
/* 411 */     for (Iterator localIterator = ((List)localObject2).iterator(); localIterator.hasNext(); ) { localObject3 = (DimensionUnit)localIterator.next();
/* 412 */       localArrayList.add(((DimensionUnit)localObject3).getUnit().getId());
/*     */     }
/*     */ 
/* 447 */     localObject3 = this.busiRoleDAO.getMixedUsers(localArrayList, localList2, paramInt1, paramInt2);
/* 448 */     int j = this.busiRoleDAO.getMixedUsersNumber(localArrayList, localList2);
/* 449 */     localQueryResult.setResult((List)localObject3);
/* 450 */     localQueryResult.setRecordCount(j);
/* 451 */     localQueryResult.setPageNumber(paramInt1);
/* 452 */     localQueryResult.setPageSize(paramInt2);
/* 453 */     return localQueryResult;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.SecurityAdminRoleBOImpl
 * JD-Core Version:    0.6.2
 */