package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.annotation.Audit;
import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.techcomp.security.entity.BusiRole;
import java.util.List;

public abstract interface SecurityAdminRoleBO
{
  @Audit("saveAdminRoleBusiRoles")
  public abstract void saveAdminRoleBusiRoles(String paramString, List<BusiRole> paramList);

  @Audit("deleteAdminRoleBusiRoles")
  public abstract void deleteAdminRoleBusiRoles(String paramString, List paramList);

  public abstract QueryResult getManagedBusiRoles(int paramInt1, int paramInt2);

  public abstract QueryResult getManagedBusiRoles(String paramString, int paramInt1, int paramInt2);

  public abstract QueryResult getManagedBusiRolesExceptUserId(String paramString, int paramInt1, int paramInt2);

  @Audit("deleteSecAdminRole")
  public abstract boolean deleteSecAdminRole(String paramString);

  public abstract QueryResult getManagedBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract QueryResult getAllBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract QueryResult getManagedUsersExceptBusiRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract boolean isSecAdminRole();

  public abstract QueryResult getUsersByResourceId(String paramString1, String paramString2, String paramString3, int paramInt1, int paramInt2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.SecurityAdminRoleBO
 * JD-Core Version:    0.6.2
 */