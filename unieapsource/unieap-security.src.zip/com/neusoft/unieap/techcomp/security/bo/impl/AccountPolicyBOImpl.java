/*     */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyConfig;
/*     */ import com.neusoft.unieap.techcomp.security.bo.AccountPolicyBO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.AccountPolicyDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("accountPolicyBO.bo")
/*     */ public class AccountPolicyBOImpl
/*     */   implements AccountPolicyBO
/*     */ {
/*     */   private AccountPolicyDAO accountPolicyDAO;
/*     */   private AccountPolicyConfig accountPolicyConfig;
/*     */   private EAPCacheManager eapCacheManager;
/*     */ 
/*     */   public void setAccountPolicyDAO(AccountPolicyDAO paramAccountPolicyDAO)
/*     */   {
/*  31 */     this.accountPolicyDAO = paramAccountPolicyDAO;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyConfig(AccountPolicyConfig paramAccountPolicyConfig)
/*     */   {
/*  36 */     this.accountPolicyConfig = paramAccountPolicyConfig;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/*  40 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public List getLockedAccounts()
/*     */   {
/*  47 */     int i = this.accountPolicyConfig.getLockedTimeInterval();
/*  48 */     return this.accountPolicyDAO.getLockedAccounts(i);
/*     */   }
/*     */ 
/*     */   public void unlockAccount(String paramString)
/*     */   {
/*  55 */     this.eapCacheManager.remove(paramString, "lockedCache");
/*  56 */     this.accountPolicyDAO.unlockAccount(paramString);
/*     */   }
/*     */ 
/*     */   public QueryResult getUsers(String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  63 */     QueryResult localQueryResult = new QueryResult();
/*  64 */     List localList = null;
/*  65 */     localList = this.accountPolicyDAO.getUsers(paramString, paramInt1, paramInt2, 
/*  66 */       this.accountPolicyConfig.getLockedTimeInterval());
/*  67 */     localQueryResult.setResult(localList);
/*  68 */     int i = this.accountPolicyDAO.getUsersNumber(paramString, 
/*  69 */       this.accountPolicyConfig.getLockedTimeInterval());
/*  70 */     localQueryResult.setRecordCount(i);
/*  71 */     localQueryResult.setPageNumber(paramInt1);
/*  72 */     localQueryResult.setPageSize(paramInt2);
/*     */ 
/*  74 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public QueryResult getManagedUsers(int paramInt1, int paramInt2)
/*     */   {
/*  81 */     QueryResult localQueryResult = new QueryResult();
/*     */ 
/*  83 */     User localUser = 
/*  84 */       UniEAPContextHolder.getContext().getCurrentUser();
/*  85 */     String str = localUser.getAdminRoleType();
/*  86 */     if (str == null) {
/*  87 */       return localQueryResult;
/*     */     }
/*  89 */     List localList1 = localUser.getRoleIds(str);
/*  90 */     new ArrayList();
/*  91 */     if ((localList1 == null) || (localList1.size() == 0)) {
/*  92 */       return localQueryResult;
/*     */     }
/*     */ 
/*  96 */     if (((String)localList1.get(0)).equalsIgnoreCase("adminRole")) {
/*  97 */       localList2 = this.accountPolicyDAO.getAllUsers(paramInt1, paramInt2, 
/*  98 */         this.accountPolicyConfig.getLockedTimeInterval());
/*  99 */       i = this.accountPolicyDAO.getAllUsersNumber(this.accountPolicyConfig
/* 100 */         .getLockedTimeInterval());
/* 101 */       localQueryResult.setResult(localList2);
/* 102 */       localQueryResult.setRecordCount(i);
/* 103 */       localQueryResult.setPageNumber(paramInt1);
/* 104 */       localQueryResult.setPageSize(paramInt2);
/* 105 */       return localQueryResult;
/*     */     }
/*     */ 
/* 108 */     List localList2 = this.accountPolicyDAO.getManagedUsers((String)localList1.get(0), paramInt1, paramInt2, 
/* 109 */       this.accountPolicyConfig.getLockedTimeInterval());
/* 110 */     int i = this.accountPolicyDAO.getManagedUsersNumber((String)localList1.get(0), this.accountPolicyConfig
/* 111 */       .getLockedTimeInterval());
/*     */ 
/* 113 */     localQueryResult.setResult(localList2);
/* 114 */     localQueryResult.setRecordCount(i);
/* 115 */     localQueryResult.setPageNumber(paramInt1);
/* 116 */     localQueryResult.setPageSize(paramInt2);
/* 117 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public void initCache()
/*     */   {
/* 124 */     List localList = null;
/* 125 */     if (this.accountPolicyConfig.getLockedTimeInterval() == -1)
/* 126 */       localList = this.accountPolicyDAO.getActiveAccountPolicies();
/*     */     else
/* 128 */       localList = this.accountPolicyDAO
/* 129 */         .getActiveAccountPolicies(this.accountPolicyConfig
/* 130 */         .getLockedTimeInterval());
/* 131 */     AccountPolicy localAccountPolicy = null;
/* 132 */     String str1 = this.accountPolicyConfig.getLockedPolicy();
/* 133 */     String str2 = null;
/* 134 */     for (int i = 0; i < localList.size(); i++) {
/* 135 */       localAccountPolicy = (AccountPolicy)localList.get(i);
/* 136 */       str2 = this.accountPolicyConfig.getKey(str1, localAccountPolicy
/* 137 */         .getIp(), localAccountPolicy.getAccount());
/* 138 */       if (localAccountPolicy.getState().equals(
/* 139 */         "locked"))
/* 140 */         this.eapCacheManager.put(str2, localAccountPolicy, 
/* 141 */           "lockedCache");
/*     */       else
/* 143 */         this.eapCacheManager.put(str2, localAccountPolicy, 
/* 144 */           "lockingCache");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/* 152 */     this.accountPolicyDAO.saveAccountPolicy(paramAccountPolicy);
/*     */   }
/*     */ 
/*     */   public void updateAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/* 159 */     this.accountPolicyDAO.updateAccountPolicy(paramAccountPolicy);
/*     */   }
/*     */ 
/*     */   public void deleteAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/* 166 */     this.accountPolicyDAO.deleteAccountPolicy(paramAccountPolicy);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.AccountPolicyBOImpl
 * JD-Core Version:    0.6.2
 */