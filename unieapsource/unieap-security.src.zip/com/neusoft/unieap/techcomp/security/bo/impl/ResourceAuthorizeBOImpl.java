/*     */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*     */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*     */ import com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO;
/*     */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.ResourceAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.SecurityAdminRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ @ModelFile("resourceAuthorizeBO.bo")
/*     */ public class ResourceAuthorizeBOImpl
/*     */   implements ResourceAuthorizeBO
/*     */ {
/*     */   private ResourceAuthorizeDAO resourceAuthorizeDAO;
/*     */   private RoleUserDAO roleUserDAO;
/*     */   private SecurityAdminRoleDAO securityAdminRoleDAO;
/*     */ 
/*     */   public void setRoleUserDAO(RoleUserDAO paramRoleUserDAO)
/*     */   {
/*  28 */     this.roleUserDAO = paramRoleUserDAO;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeDAO(ResourceAuthorizeDAO paramResourceAuthorizeDAO)
/*     */   {
/*  33 */     this.resourceAuthorizeDAO = paramResourceAuthorizeDAO;
/*     */   }
/*     */ 
/*     */   public void setSecurityAdminRoleDAO(SecurityAdminRoleDAO paramSecurityAdminRoleDAO)
/*     */   {
/*  38 */     this.securityAdminRoleDAO = paramSecurityAdminRoleDAO;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList, String paramString1, String paramString2)
/*     */   {
/*  47 */     return this.resourceAuthorizeDAO.getResourceIds(paramList, paramString1, 
/*  48 */       paramString2);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString)
/*     */   {
/*  55 */     this.resourceAuthorizeDAO.deleteResourceAuthorities(paramString);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(List paramList, String paramString)
/*     */   {
/*  62 */     this.resourceAuthorizeDAO.deleteResourceAuthorities(paramList, paramString);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5)
/*     */   {
/*  71 */     this.resourceAuthorizeDAO.deleteResourceAuthorities(paramString1, paramString2, 
/*  72 */       paramList, paramString3, paramString4, paramString5);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getAuthorityType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*  88 */     return this.resourceAuthorizeDAO.getAuthorityType(paramString1, paramString2, 
/*  89 */       paramString3, paramString4, paramString5);
/*     */   }
/*     */ 
/*     */   public List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*  99 */     return this.resourceAuthorizeDAO.getResourceIds(paramString1, paramString2, 
/* 100 */       paramString3, paramString4, paramString5);
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList1, List paramList2, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 119 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5, String paramString6)
/*     */   {
/* 128 */     ArrayList localArrayList = new ArrayList();
/* 129 */     for (int i = 0; i < paramList.size(); i++) {
/* 130 */       ResourceAuthority localResourceAuthority = new ResourceAuthority();
/* 131 */       localResourceAuthority.setResourceId(paramList.get(i).toString());
/* 132 */       localResourceAuthority.setResourceType(paramString3);
/* 133 */       localResourceAuthority.setRoleId(paramString1);
/* 134 */       localResourceAuthority.setRoleType(paramString2);
/* 135 */       localResourceAuthority.setAuthorityType(paramString4);
/* 136 */       localResourceAuthority.setDimensionConstraint(paramString5);
/* 137 */       localArrayList.add(localResourceAuthority);
/*     */     }
/* 139 */     this.resourceAuthorizeDAO.saveResourceAuthorities(localArrayList);
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, List paramList1, String paramString3, List paramList2, String paramString4, String paramString5)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8)
/*     */   {
/*     */   }
/*     */ 
/*     */   public List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 178 */     if ((paramString2 != null) && (paramString2.equals("user"))) {
/* 179 */       return getResourceIds(this.roleUserDAO.getRoleIdsByUserId(paramString1), 
/* 180 */         paramString3, paramString4);
/*     */     }
/* 182 */     return getResourceIds(paramString1, paramString2, paramString3, 
/* 183 */       paramString4, null);
/*     */   }
/*     */ 
/*     */   public void saveTreeResources(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/* 195 */     ArrayList localArrayList = new ArrayList();
/*     */     String[] arrayOfString1;
/*     */     Object localObject;
/* 198 */     if ((paramString1 != null) && (paramString1.length() > 0)) {
/* 199 */       arrayOfString1 = paramString1.split(",");
/* 200 */       for (localObject : arrayOfString1) {
/* 201 */         ResourceAuthority localResourceAuthority = new ResourceAuthority();
/* 202 */         localResourceAuthority.setResourceId((String)localObject);
/* 203 */         localResourceAuthority.setResourceType(paramString5);
/* 204 */         localResourceAuthority.setRoleId(paramString3);
/* 205 */         localResourceAuthority.setRoleType(paramString4);
/* 206 */         localResourceAuthority.setAuthorityType(paramString6);
/* 207 */         localResourceAuthority.setDimensionConstraint(paramString7);
/* 208 */         localArrayList.add(localResourceAuthority);
/*     */       }
/* 210 */       this.resourceAuthorizeDAO.saveResourceAuthorities(localArrayList);
/*     */     }
/*     */ 
/* 213 */     if ((paramString2 != null) && (paramString2.length() > 0)) {
/* 214 */       arrayOfString1 = paramString2.split(",");
/* 215 */       localObject = new ArrayList(Arrays.asList(arrayOfString1));
/*     */ 
/* 219 */       String str = this.securityAdminRoleDAO.getRolePath(paramString3);
/* 220 */       List localList = this.securityAdminRoleDAO
/* 221 */         .getDescendantAdminRoleIds(str + paramString3 + "/");
/* 222 */       localList.add(paramString3);
/* 223 */       this.resourceAuthorizeDAO.deleteResourceAuthorities(localList, paramString4, 
/* 224 */         (List)localObject, paramString5, paramString6, paramString7);
/*     */     }
/*     */   }
/*     */ 
/*     */   public List getRoleIds(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 233 */     return this.resourceAuthorizeDAO.getRoleIds(paramString1, paramString2, 
/* 234 */       paramString3);
/*     */   }
/*     */ 
/*     */   public BOContext getRoleIds(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 242 */     String[] arrayOfString = paramString1.split(",");
/* 243 */     BOContextImpl localBOContextImpl = new BOContextImpl();
/* 244 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 245 */       List localList = this.resourceAuthorizeDAO.getRoleIds(arrayOfString[i], 
/* 246 */         paramString2, paramString3, paramString4);
/* 247 */       localBOContextImpl.put(arrayOfString[i], localList);
/*     */     }
/* 249 */     return localBOContextImpl;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/* 259 */     ArrayList localArrayList1 = new ArrayList();
/*     */     String[] arrayOfString1;
/*     */     Object localObject;
/* 262 */     if ((paramString1 != null) && (paramString1.length() > 0)) {
/* 263 */       arrayOfString1 = paramString1.split(",");
/* 264 */       for (localObject : arrayOfString1) {
/* 265 */         ResourceAuthority localResourceAuthority = new ResourceAuthority();
/* 266 */         localResourceAuthority.setResourceId(paramString3);
/* 267 */         localResourceAuthority.setResourceType(paramString5);
/* 268 */         localResourceAuthority.setRoleId((String)localObject);
/* 269 */         localResourceAuthority.setRoleType(paramString4);
/* 270 */         localResourceAuthority.setAuthorityType(paramString6);
/* 271 */         localResourceAuthority.setDimensionConstraint(paramString7);
/* 272 */         localArrayList1.add(localResourceAuthority);
/*     */       }
/* 274 */       this.resourceAuthorizeDAO.saveResourceAuthorities(localArrayList1);
/*     */     }
/*     */ 
/* 277 */     if ((paramString2 != null) && (paramString2.length() > 0)) {
/* 278 */       arrayOfString1 = paramString2.split(",");
/* 279 */       localObject = new ArrayList();
/* 280 */       ((List)localObject).add(paramString3);
/* 281 */       ArrayList localArrayList2 = new ArrayList(Arrays.asList(arrayOfString1));
/* 282 */       this.resourceAuthorizeDAO.deleteResourceAuthorities(localArrayList2, paramString4, 
/* 283 */         (List)localObject, paramString5, paramString6, 
/* 284 */         paramString7);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities4Cascade(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7)
/*     */   {
/* 295 */     ArrayList localArrayList1 = new ArrayList();
/* 296 */     String[] arrayOfString1 = paramString3.split(",");
/*     */     String[] arrayOfString2;
/*     */     Object localObject;
/* 298 */     if ((paramString1 != null) && (paramString1.length() > 0)) {
/* 299 */       arrayOfString2 = paramString1.split(",");
/* 300 */       for (int i = 0; i < arrayOfString1.length; i++) {
/* 301 */         for (localObject : arrayOfString2)
/*     */         {
/*     */           ResourceAuthority localResourceAuthority;
/* 303 */           if (i == 0) {
/* 304 */             localResourceAuthority = new ResourceAuthority();
/* 305 */             localResourceAuthority.setResourceId(arrayOfString1[i]);
/* 306 */             localResourceAuthority.setResourceType(paramString5);
/* 307 */             localResourceAuthority.setRoleId((String)localObject);
/* 308 */             localResourceAuthority.setRoleType(paramString4);
/* 309 */             localResourceAuthority.setAuthorityType(paramString6);
/* 310 */             localResourceAuthority
/* 311 */               .setDimensionConstraint(paramString7);
/* 312 */             localArrayList1.add(localResourceAuthority);
/* 313 */           } else if (i == arrayOfString1.length - 1)
/*     */           {
/* 315 */             if (!this.resourceAuthorizeDAO.isExistInResourceAuthority(
/* 316 */               (String)localObject, paramString4, arrayOfString1[i], 
/* 317 */               "application", 
/* 318 */               paramString6)) {
/* 319 */               localResourceAuthority = new ResourceAuthority();
/* 320 */               localResourceAuthority.setResourceId(arrayOfString1[i]);
/* 321 */               localResourceAuthority
/* 322 */                 .setResourceType("application");
/* 323 */               localResourceAuthority.setRoleId((String)localObject);
/* 324 */               localResourceAuthority.setRoleType(paramString4);
/* 325 */               localResourceAuthority.setAuthorityType(paramString6);
/* 326 */               localResourceAuthority
/* 327 */                 .setDimensionConstraint(paramString7);
/* 328 */               localArrayList1.add(localResourceAuthority);
/*     */             }
/*     */ 
/*     */           }
/* 332 */           else if (!this.resourceAuthorizeDAO.isExistInResourceAuthority(
/* 333 */             (String)localObject, paramString4, arrayOfString1[i], 
/* 334 */             "menu", 
/* 335 */             paramString6)) {
/* 336 */             localResourceAuthority = new ResourceAuthority();
/* 337 */             localResourceAuthority.setResourceId(arrayOfString1[i]);
/* 338 */             localResourceAuthority.setResourceType(paramString5);
/* 339 */             localResourceAuthority.setRoleId((String)localObject);
/* 340 */             localResourceAuthority.setRoleType(paramString4);
/* 341 */             localResourceAuthority.setAuthorityType(paramString6);
/* 342 */             localResourceAuthority
/* 343 */               .setDimensionConstraint(paramString7);
/* 344 */             localArrayList1.add(localResourceAuthority);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 349 */       this.resourceAuthorizeDAO.saveResourceAuthorities(localArrayList1);
/*     */     }
/*     */ 
/* 353 */     if ((paramString2 != null) && (paramString2.length() > 0)) {
/* 354 */       arrayOfString2 = paramString2.split(",");
/* 355 */       ArrayList localArrayList2 = new ArrayList();
/* 356 */       localArrayList2.add(arrayOfString1[0]);
/* 357 */       localObject = new ArrayList(Arrays.asList(arrayOfString2));
/* 358 */       this.resourceAuthorizeDAO.deleteResourceAuthorities((List)localObject, paramString4, 
/* 359 */         localArrayList2, paramString5, paramString6, 
/* 360 */         paramString7);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.ResourceAuthorizeBOImpl
 * JD-Core Version:    0.6.2
 */