package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.annotation.Audit;
import java.util.List;

public abstract interface PageAuthorizeBO
{
  @Audit("savePageAuthorities")
  public abstract List savePageAuthorities(List paramList);

  public abstract List getPageAuthorities(String paramString1, String paramString2, String paramString3);

  public abstract List getPageAuthorities(List paramList, String paramString1, String paramString2, String paramString3);

  public abstract List getPageAuthorities(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract String getControlType();

  public abstract String getSCIds();

  public abstract List filterPageAuthorites(List paramList);

  public abstract List filterAuthorityIndividual(List paramList);

  public abstract void copyAuthoritiesByCirId(String paramString1, String paramString2, String paramString3);

  public abstract String getI18nTitle(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.PageAuthorizeBO
 * JD-Core Version:    0.6.2
 */