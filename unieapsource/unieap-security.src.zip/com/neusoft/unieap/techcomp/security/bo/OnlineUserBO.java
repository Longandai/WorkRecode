package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.techcomp.security.entity.OnlineUser;

public abstract interface OnlineUserBO
{
  public abstract void saveOnlineUser(OnlineUser paramOnlineUser);

  public abstract void updateOnlineUser(OnlineUser paramOnlineUser);

  public abstract void deleteOnlineUserBySessionId(String paramString);

  public abstract void deleteOnlineUsersByUserId(String paramString);

  public abstract void deleteOnlineUsersByServerIp(String paramString);

  public abstract QueryResult getAllOnlineUsers(int paramInt1, int paramInt2);

  public abstract QueryResult getOnlineUsers(int paramInt1, int paramInt2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.OnlineUserBO
 * JD-Core Version:    0.6.2
 */