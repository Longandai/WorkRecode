/*     */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.model.SCRepository;
/*     */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual;
/*     */ import com.neusoft.unieap.techcomp.security.bo.PageAuthorizeBO;
/*     */ import com.neusoft.unieap.techcomp.security.config.PageAuthConfig;
/*     */ import com.neusoft.unieap.techcomp.security.dao.PageAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.ResourceAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
/*     */ import com.opensymphony.xwork2.util.LocalizedTextUtil;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.Set;
/*     */ 
/*     */ @ModelFile("pageAuthorizeBO.bo")
/*     */ public class PageAuthorizeBOImpl
/*     */   implements PageAuthorizeBO
/*     */ {
/*     */   private PageAuthorizeDAO pageAuthorizeDAO;
/*     */   private ResourceAuthorizeDAO resourceAuthorizeDAO;
/*     */   private PageAuthConfig pageAuthConfig;
/*     */ 
/*     */   public void setPageAuthorizeDAO(PageAuthorizeDAO paramPageAuthorizeDAO)
/*     */   {
/*  42 */     this.pageAuthorizeDAO = paramPageAuthorizeDAO;
/*     */   }
/*     */ 
/*     */   public void setResourceAuthorizeDAO(ResourceAuthorizeDAO paramResourceAuthorizeDAO)
/*     */   {
/*  47 */     this.resourceAuthorizeDAO = paramResourceAuthorizeDAO;
/*     */   }
/*     */ 
/*     */   public void setPageAuthConfig(PageAuthConfig paramPageAuthConfig) {
/*  51 */     this.pageAuthConfig = paramPageAuthConfig;
/*     */   }
/*     */ 
/*     */   public List savePageAuthorities(List paramList)
/*     */   {
/*  58 */     ArrayList localArrayList = new ArrayList();
/*  59 */     if (paramList != null) {
/*  60 */       for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/*  61 */         ResourceAuthority localResourceAuthority = (ResourceAuthority)localObject;
/*  62 */         String str1 = localResourceAuthority.getId();
/*  63 */         String str2 = localResourceAuthority.getAuthorityType();
/*  64 */         if (str1 == null) {
/*  65 */           if (!str2.equals("writely")) {
/*  66 */             localResourceAuthority = this.resourceAuthorizeDAO
/*  67 */               .saveResourceAuthority(localResourceAuthority);
/*     */           }
/*     */         }
/*  70 */         else if (str2.equals("writely"))
/*  71 */           localArrayList.add(localResourceAuthority);
/*     */         else {
/*  73 */           this.resourceAuthorizeDAO
/*  74 */             .updateResourceAuthority(localResourceAuthority);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  79 */     if (localArrayList.size() > 0) {
/*  80 */       this.resourceAuthorizeDAO.deleteResourceAuthorityList(localArrayList);
/*  81 */       paramList.removeAll(localArrayList);
/*     */     }
/*  83 */     return paramList;
/*     */   }
/*     */ 
/*     */   public List getPageAuthorities(String paramString1, String paramString2, String paramString3)
/*     */   {
/*  91 */     return this.pageAuthorizeDAO.getPageAuthorities(paramString1, paramString2, 
/*  92 */       paramString3);
/*     */   }
/*     */ 
/*     */   public List getPageAuthorities(List paramList, String paramString1, String paramString2, String paramString3)
/*     */   {
/*  99 */     return filterPageAuthorites(this.pageAuthorizeDAO.getPageAuthorities(
/* 100 */       paramList, paramString1, paramString2, paramString3));
/*     */   }
/*     */ 
/*     */   public List getPageAuthorities(String paramString1, String paramString2, String paramString3, String paramString4)
/*     */   {
/* 107 */     return this.pageAuthorizeDAO.getPageAuthorities(paramString1, paramString2, paramString3, paramString4);
/*     */   }
/*     */ 
/*     */   public String getControlType()
/*     */   {
/* 114 */     return this.pageAuthConfig.getControlType();
/*     */   }
/*     */ 
/*     */   public String getSCIds()
/*     */   {
/* 122 */     StringBuilder localStringBuilder = new StringBuilder();
/* 123 */     List localList = SCRepository.getSoftwareComponents();
/* 124 */     if ((localList == null) || (localList.size() == 0)) {
/* 125 */       return "";
/*     */     }
/* 127 */     int i = localList.size();
/* 128 */     for (int j = 0; j < i; j++) {
/* 129 */       localStringBuilder.append(((SoftwareComponent)localList.get(j)).getId());
/* 130 */       if (j != i - 1) {
/* 131 */         localStringBuilder.append(",");
/*     */       }
/*     */     }
/* 134 */     return localStringBuilder.toString();
/*     */   }
/*     */ 
/*     */   public List filterPageAuthorites(List paramList)
/*     */   {
/* 141 */     if ((paramList == null) || (paramList.size() == 0))
/* 142 */       return null;
/* 143 */     HashMap localHashMap = new HashMap();
/* 144 */     int i = paramList.size();
/* 145 */     ResourceAuthority localResourceAuthority = null;
/* 146 */     String str = "";
/* 147 */     for (int j = 0; j < i; j++) {
/* 148 */       localResourceAuthority = (ResourceAuthority)paramList.get(j);
/* 149 */       str = localResourceAuthority.getResourceId();
/* 150 */       if (localHashMap.containsKey(str)) {
/* 151 */         localObject = (ResourceAuthority)localHashMap.get(str);
/* 152 */         if ((localResourceAuthority.getAuthorityType().equals("hidden")) && 
/* 153 */           (((ResourceAuthority)localObject).getAuthorityType().equals("disabled")))
/* 154 */           localHashMap.put(str, localResourceAuthority);
/*     */       }
/*     */       else {
/* 157 */         localHashMap.put(str, localResourceAuthority);
/*     */       }
/*     */     }
/* 160 */     ArrayList localArrayList = new ArrayList();
/* 161 */     Object localObject = localHashMap.entrySet().iterator();
/* 162 */     while (((Iterator)localObject).hasNext()) {
/* 163 */       localArrayList.add(((Map.Entry)((Iterator)localObject).next()).getValue());
/*     */     }
/* 165 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List filterAuthorityIndividual(List paramList)
/*     */   {
/* 172 */     if ((paramList == null) || (paramList.size() == 0))
/* 173 */       return null;
/* 174 */     HashMap localHashMap = new HashMap();
/* 175 */     int i = paramList.size();
/* 176 */     String str1 = "";
/* 177 */     String str2 = "";
/* 178 */     String str3 = "";
/* 179 */     for (int j = 0; j < i; j++) {
/* 180 */       localObject1 = paramList.get(j);
/*     */       Object localObject2;
/* 181 */       if ((localObject1 instanceof ResourceAuthority)) {
/* 182 */         localObject2 = (ResourceAuthority)localObject1;
/* 183 */         str1 = ((ResourceAuthority)localObject2).getResourceId();
/* 184 */         str2 = ((ResourceAuthority)localObject2).getAuthorityType();
/* 185 */       } else if ((localObject1 instanceof PageIndividual)) {
/* 186 */         localObject2 = (PageIndividual)localObject1;
/* 187 */         str1 = ((PageIndividual)localObject2).getResourceId();
/* 188 */         str2 = ((PageIndividual)localObject2).getIndividualType();
/*     */       }
/* 190 */       if (localHashMap.containsKey(str1)) {
/* 191 */         localObject2 = localHashMap.get(str1);
/* 192 */         if ((localObject2 instanceof ResourceAuthority))
/* 193 */           str3 = ((ResourceAuthority)localObject2).getAuthorityType();
/* 194 */         else if ((localObject2 instanceof PageIndividual)) {
/* 195 */           str3 = ((PageIndividual)localObject2).getIndividualType();
/*     */         }
/* 197 */         if ((str2.equals("hidden")) && (str3.equals("disabled")))
/* 198 */           localHashMap.put(str1, localObject2);
/*     */       }
/*     */       else {
/* 201 */         localHashMap.put(str1, localObject1);
/*     */       }
/*     */     }
/* 204 */     ArrayList localArrayList = new ArrayList();
/* 205 */     Object localObject1 = localHashMap.entrySet().iterator();
/* 206 */     while (((Iterator)localObject1).hasNext()) {
/* 207 */       localArrayList.add(((Map.Entry)((Iterator)localObject1).next()).getValue());
/*     */     }
/* 209 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void copyAuthoritiesByCirId(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 218 */     this.pageAuthorizeDAO.delPageAuthoritiesByCirId(paramString2, paramString3);
/*     */ 
/* 220 */     this.pageAuthorizeDAO.copyAuthoritiesByCirId(paramString1, paramString2, paramString3);
/*     */   }
/*     */ 
/*     */   public String getI18nTitle(String paramString1, String paramString2)
/*     */   {
/* 227 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/* 228 */     ResourceBundle localResourceBundle = LocalizedTextUtil.findResourceBundle(
/* 229 */       paramString2, localLocale);
/* 230 */     return LocalizedTextUtil.findText(localResourceBundle, paramString1, localLocale);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.PageAuthorizeBOImpl
 * JD-Core Version:    0.6.2
 */