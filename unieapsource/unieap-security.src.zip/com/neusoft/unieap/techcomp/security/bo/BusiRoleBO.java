package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.annotation.Audit;
import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.techcomp.org.entity.User;
import com.neusoft.unieap.techcomp.security.entity.BusiRole;
import com.neusoft.unieap.techcomp.security.pojo.UserUnitStationPojo;
import java.util.List;

public abstract interface BusiRoleBO
{
  public abstract QueryResult getAllBusiRoles(int paramInt1, int paramInt2);

  @Audit("saveBusiRole")
  public abstract BusiRole saveBusiRole(BusiRole paramBusiRole);

  @Audit("updateBusiRole")
  public abstract BusiRole updateBusiRole(BusiRole paramBusiRole, boolean paramBoolean);

  @Audit("deleteBusiRoleById")
  public abstract void deleteBusiRoleById(String paramString);

  @Audit("saveBusiRoleUsers")
  public abstract void saveBusiRoleUsers(String paramString, List<User> paramList);

  public abstract QueryResult getUsersByBusiRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract List<UserUnitStationPojo> getUserUnitStationPojos(List<User> paramList);

  @Audit("deleteBusiRoleUser")
  public abstract void deleteBusiRoleUser(String paramString1, String paramString2);

  public abstract List getBusiRolesByUserId(String paramString);

  public abstract BusiRole getBusiRoleById(String paramString);

  public abstract QueryResult getUsersByUnitIdExceptedBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  @Audit("deleteBusiRoleUserByUserId")
  public abstract void deleteBusiRoleUserByUserId(String paramString);

  public abstract QueryResult getUsersByBusiRoleIdWithAdvancedQuery(String paramString, int paramInt1, int paramInt2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.BusiRoleBO
 * JD-Core Version:    0.6.2
 */