package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.annotation.Audit;
import com.neusoft.unieap.techcomp.security.entity.BusiRole;
import java.util.List;

public abstract interface UserBusiRoleBO
{
  public abstract List getBusiRolesByUserId(String paramString);

  @Audit("saveUserBusiRoles")
  public abstract void saveUserBusiRoles(String paramString, List<BusiRole> paramList);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.UserBusiRoleBO
 * JD-Core Version:    0.6.2
 */