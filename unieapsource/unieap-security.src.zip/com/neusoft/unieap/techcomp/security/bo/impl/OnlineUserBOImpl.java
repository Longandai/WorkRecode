/*    */ package com.neusoft.unieap.techcomp.security.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*    */ import com.neusoft.unieap.techcomp.security.bo.OnlineUserBO;
/*    */ import com.neusoft.unieap.techcomp.security.dao.OnlineUserDAO;
/*    */ import com.neusoft.unieap.techcomp.security.entity.OnlineUser;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("onlineUserBO.bo")
/*    */ public class OnlineUserBOImpl
/*    */   implements OnlineUserBO
/*    */ {
/*    */   private OnlineUserDAO onlineUserDAO;
/*    */ 
/*    */   public void setOnlineUserDAO(OnlineUserDAO paramOnlineUserDAO)
/*    */   {
/* 24 */     this.onlineUserDAO = paramOnlineUserDAO;
/*    */   }
/*    */ 
/*    */   public OnlineUserDAO getOnlineUserDAO() {
/* 28 */     return this.onlineUserDAO;
/*    */   }
/*    */ 
/*    */   public void saveOnlineUser(OnlineUser paramOnlineUser)
/*    */   {
/* 35 */     this.onlineUserDAO.saveOnlineUser(paramOnlineUser);
/*    */   }
/*    */ 
/*    */   public void updateOnlineUser(OnlineUser paramOnlineUser)
/*    */   {
/* 42 */     this.onlineUserDAO.updateOnlineUser(paramOnlineUser);
/*    */   }
/*    */ 
/*    */   public void deleteOnlineUserBySessionId(String paramString)
/*    */   {
/* 49 */     this.onlineUserDAO.deleteOnlineUserBySessionId(paramString);
/*    */   }
/*    */ 
/*    */   public void deleteOnlineUsersByUserId(String paramString)
/*    */   {
/* 56 */     this.onlineUserDAO.deleteOnlineUsersByUserId(paramString);
/*    */   }
/*    */ 
/*    */   public void deleteOnlineUsersByServerIp(String paramString)
/*    */   {
/* 63 */     this.onlineUserDAO.deleteOnlineUsersByServerIp(paramString);
/*    */   }
/*    */ 
/*    */   public QueryResult getAllOnlineUsers(int paramInt1, int paramInt2)
/*    */   {
/* 70 */     QueryResult localQueryResult = new QueryResult();
/* 71 */     List localList = this.onlineUserDAO.getAllOnlineUsers(paramInt1, paramInt2);
/* 72 */     localQueryResult.setResult(localList);
/* 73 */     int i = this.onlineUserDAO.getAllOnlineUsersNumber();
/* 74 */     localQueryResult.setRecordCount(i);
/* 75 */     localQueryResult.setPageNumber(paramInt1);
/* 76 */     localQueryResult.setPageSize(paramInt2);
/*    */ 
/* 78 */     return localQueryResult;
/*    */   }
/*    */ 
/*    */   public QueryResult getOnlineUsers(int paramInt1, int paramInt2)
/*    */   {
/* 85 */     QueryResult localQueryResult = new QueryResult();
/* 86 */     List localList = this.onlineUserDAO.getOnlineUsers(paramInt1, paramInt2);
/* 87 */     localQueryResult.setResult(localList);
/* 88 */     int i = this.onlineUserDAO.getOnlineUsersNumber();
/* 89 */     localQueryResult.setRecordCount(i);
/* 90 */     localQueryResult.setPageNumber(paramInt1);
/* 91 */     localQueryResult.setPageSize(paramInt2);
/*    */ 
/* 93 */     return localQueryResult;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.impl.OnlineUserBOImpl
 * JD-Core Version:    0.6.2
 */