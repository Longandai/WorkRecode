package com.neusoft.unieap.techcomp.security.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
import java.util.List;

public abstract interface AccountPolicyBO
{
  public abstract List getLockedAccounts();

  public abstract void unlockAccount(String paramString);

  public abstract QueryResult getUsers(String paramString, int paramInt1, int paramInt2);

  public abstract QueryResult getManagedUsers(int paramInt1, int paramInt2);

  public abstract void initCache();

  public abstract void saveAccountPolicy(AccountPolicy paramAccountPolicy);

  public abstract void updateAccountPolicy(AccountPolicy paramAccountPolicy);

  public abstract void deleteAccountPolicy(AccountPolicy paramAccountPolicy);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bo.AccountPolicyBO
 * JD-Core Version:    0.6.2
 */