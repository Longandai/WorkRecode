/*     */ package com.neusoft.unieap.techcomp.security.accountpolicy;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.Audit;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.security.bo.AccountPolicyBO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
/*     */ import com.neusoft.unieap.techcomp.security.i18n.I18nUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import javax.servlet.RequestDispatcher;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.servlet.http.HttpSession;
/*     */ 
/*     */ public class AccountPolicyService
/*     */ {
/*     */   private AccountPolicyConfig accountPolicyConfig;
/*     */   private EAPCacheManager eapCacheManager;
/*     */   private AccountPolicyBO accountPolicyBO;
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager)
/*     */   {
/*  29 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyConfig(AccountPolicyConfig paramAccountPolicyConfig) {
/*  33 */     this.accountPolicyConfig = paramAccountPolicyConfig;
/*     */   }
/*     */ 
/*     */   public void setAccountPolicyBO(AccountPolicyBO paramAccountPolicyBO) {
/*  37 */     this.accountPolicyBO = paramAccountPolicyBO;
/*     */   }
/*     */ 
/*     */   public boolean isUnLocked(Date paramDate)
/*     */   {
/*  50 */     long l = new Date().getTime() - paramDate.getTime();
/*  51 */     if ((this.accountPolicyConfig.getLockedTimeInterval() == -1) || 
/*  52 */       (l <= Long.valueOf(this.accountPolicyConfig.getLockedTimeInterval()).longValue() * 60L * 1000L))
/*  53 */       return false;
/*  54 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isLocked(String paramString1, String paramString2, String paramString3)
/*     */   {
/*  67 */     if ((paramString3 == null) || (paramString3.equals("")))
/*  68 */       return false;
/*  69 */     String str = this.accountPolicyConfig.getKey(paramString1, paramString2, paramString3);
/*  70 */     AccountPolicy localAccountPolicy = (AccountPolicy)this.eapCacheManager.get(str, 
/*  71 */       "lockedCache");
/*  72 */     if (localAccountPolicy == null)
/*  73 */       return false;
/*  74 */     return !isUnLocked(localAccountPolicy.getLoginTime());
/*     */   }
/*     */ 
/*     */   public boolean isKicked(String paramString1, String paramString2)
/*     */   {
/*  89 */     AccountPolicy localAccountPolicy = (AccountPolicy)this.eapCacheManager.get(
/*  90 */       paramString1, "onlineCache");
/*  91 */     if (localAccountPolicy == null)
/*  92 */       return false;
/*  93 */     if ((localAccountPolicy.getSessionId() == null) || 
/*  94 */       (!localAccountPolicy.getSessionId().equals(paramString2)))
/*  95 */       return true;
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   public String getLockedErrorMessage(String paramString1, String paramString2, String paramString3, int paramInt)
/*     */   {
/* 109 */     String str = null;
/* 110 */     if (paramInt < 0) {
/* 111 */       return I18nUtil.getInstance().getValue(
/* 112 */         "techcomp.security.accountLocked1", 
/* 113 */         new Object[] { paramString3 });
/*     */     }
/*     */ 
/* 116 */     if (paramString1.equalsIgnoreCase("ipAccountLocked"))
/* 117 */       str = I18nUtil.getInstance().getValue(
/* 118 */         "techcomp.security.ipAccountLocked", 
/* 119 */         new Object[] { paramString2, paramString3, Integer.valueOf(paramInt) });
/* 120 */     else if (paramString1.equalsIgnoreCase("accountLocked"))
/* 121 */       str = I18nUtil.getInstance().getValue(
/* 122 */         "techcomp.security.accountLocked", 
/* 123 */         new Object[] { paramString3, Integer.valueOf(paramInt) });
/* 124 */     else if (paramString1.equalsIgnoreCase("ipLocked"))
/* 125 */       str = I18nUtil.getInstance().getValue(
/* 126 */         "techcomp.security.ipLocked", 
/* 127 */         new Object[] { paramString2, Integer.valueOf(paramInt) });
/* 128 */     return str;
/*     */   }
/*     */ 
/*     */   @Audit("accountLocked")
/*     */   public void putLockedToCache(String paramString, AccountPolicy paramAccountPolicy)
/*     */   {
/* 139 */     this.eapCacheManager.put(paramString, paramAccountPolicy, "lockedCache");
/*     */   }
/*     */ 
/*     */   @Audit("accountAlreadyLocked")
/*     */   public void lockedProcess(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */     throws IOException, ServletException
/*     */   {
/* 152 */     String str1 = this.accountPolicyConfig.getLockedPolicy();
/* 153 */     String str2 = paramHttpServletRequest
/* 154 */       .getParameter("j_username");
/* 155 */     String str3 = paramHttpServletRequest.getRemoteAddr();
/* 156 */     HttpSession localHttpSession = paramHttpServletRequest.getSession();
/* 157 */     removeSession(localHttpSession);
/* 158 */     String str4 = this.accountPolicyConfig.getKey(str1, str3, str2);
/* 159 */     AccountPolicy localAccountPolicy = (AccountPolicy)this.eapCacheManager.get(str4, 
/* 160 */       "lockedCache");
/* 161 */     long l = new Date().getTime() - 
/* 162 */       localAccountPolicy.getLoginTime().getTime();
/* 163 */     int i = this.accountPolicyConfig.getLockedTimeInterval() - 
/* 164 */       Integer.parseInt(String.valueOf(l / 60L / 1000L));
/* 165 */     String str5 = getLockedErrorMessage(str1, str3, 
/* 166 */       str2, i);
/*     */ 
/* 168 */     paramHttpServletRequest.setAttribute("loginErrorMsg", str5);
/* 169 */     paramHttpServletRequest.getRequestDispatcher(paramString).forward(paramHttpServletRequest, 
/* 170 */       paramHttpServletResponse);
/*     */   }
/*     */ 
/*     */   @Audit("accountAlreadyKicked")
/*     */   public void kickedProcess(HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, String paramString)
/*     */     throws IOException, ServletException
/*     */   {
/* 186 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 187 */     String str1 = paramHttpServletRequest.getRemoteAddr();
/* 188 */     HttpSession localHttpSession = paramHttpServletRequest.getSession();
/* 189 */     String str2 = localHttpSession.getId();
/*     */ 
/* 191 */     AccountPolicy localAccountPolicy = new AccountPolicy();
/* 192 */     localAccountPolicy.setAccount(localUser.getAccount());
/* 193 */     localAccountPolicy.setIp(str1);
/* 194 */     localAccountPolicy.setLoginTime(new Timestamp(new Date()
/* 195 */       .getTime()));
/* 196 */     localAccountPolicy.setState("kicked");
/* 197 */     localAccountPolicy.setSessionId(str2);
/* 198 */     this.accountPolicyBO.saveAccountPolicy(localAccountPolicy);
/* 199 */     removeSession(localHttpSession);
/*     */ 
/* 201 */     if (paramHttpServletRequest.getMethod().equals("POST"))
/* 202 */       paramHttpServletRequest.getRequestDispatcher(
/* 203 */         paramHttpServletResponse
/* 204 */         .encodeRedirectURL(paramString)).forward(
/* 205 */         paramHttpServletRequest, paramHttpServletResponse);
/*     */     else
/* 207 */       paramHttpServletResponse.getWriter().write(
/* 208 */         "<script language=\"javascript\">window.location.href='" + 
/* 209 */         paramHttpServletRequest.getContextPath() + 
/* 210 */         paramString + "'</script>");
/*     */   }
/*     */ 
/*     */   public void removeSession(HttpSession paramHttpSession)
/*     */   {
/* 220 */     Vector localVector = new Vector();
/* 221 */     for (int i = 0; i < localVector.size(); i++)
/* 222 */       paramHttpSession.removeAttribute(localVector.elementAt(i).toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyService
 * JD-Core Version:    0.6.2
 */