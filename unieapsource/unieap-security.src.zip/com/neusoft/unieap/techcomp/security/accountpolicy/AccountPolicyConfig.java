/*    */ package com.neusoft.unieap.techcomp.security.accountpolicy;
/*    */ 
/*    */ public class AccountPolicyConfig
/*    */ {
/*  6 */   private boolean accountLocked = false;
/*  7 */   private boolean ipLocked = false;
/*  8 */   private int failedCount = 5;
/*  9 */   private int lockedTimeInterval = 20;
/* 10 */   private boolean accountKicked = false;
/*    */   public static final String LOCKED_CACHE = "lockedCache";
/*    */   public static final String LOCKING_CACHE = "lockingCache";
/*    */   public static final String ONLINE_CACHE = "onlineCache";
/*    */   public static final String ONLINE_STATE = "online";
/*    */   public static final String LOCKING_STATE = "locking";
/*    */   public static final String LOCKED_STATE = "locked";
/*    */   public static final String UNLOCK_STATE = "unlock";
/*    */   public static final String KICKED_STATE = "kicked";
/*    */ 
/*    */   public String getLockedPolicy()
/*    */   {
/* 33 */     if ((isAccountLocked()) && (isIpLocked()))
/* 34 */       return "ipAccountLocked";
/* 35 */     if (isAccountLocked())
/* 36 */       return "accountLocked";
/* 37 */     if (isIpLocked()) {
/* 38 */       return "ipLocked";
/*    */     }
/* 40 */     return "unlocked";
/*    */   }
/*    */ 
/*    */   public String getKey(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 52 */     String str = null;
/* 53 */     if (paramString1.equalsIgnoreCase("ipAccountLocked"))
/* 54 */       str = paramString2 + "_" + paramString3;
/* 55 */     else if (paramString1.equalsIgnoreCase("accountLocked"))
/* 56 */       str = paramString3;
/* 57 */     else if (paramString1.equalsIgnoreCase("ipLocked"))
/* 58 */       str = paramString2;
/* 59 */     return str;
/*    */   }
/*    */ 
/*    */   public boolean isAccountLocked() {
/* 63 */     return this.accountLocked;
/*    */   }
/*    */   public void setAccountLocked(boolean paramBoolean) {
/* 66 */     this.accountLocked = paramBoolean;
/*    */   }
/*    */   public boolean isIpLocked() {
/* 69 */     return this.ipLocked;
/*    */   }
/*    */   public void setIpLocked(boolean paramBoolean) {
/* 72 */     this.ipLocked = paramBoolean;
/*    */   }
/*    */   public int getFailedCount() {
/* 75 */     return this.failedCount;
/*    */   }
/*    */   public void setFailedCount(int paramInt) {
/* 78 */     this.failedCount = paramInt;
/*    */   }
/*    */   public int getLockedTimeInterval() {
/* 81 */     return this.lockedTimeInterval;
/*    */   }
/*    */   public void setLockedTimeInterval(int paramInt) {
/* 84 */     this.lockedTimeInterval = paramInt;
/*    */   }
/*    */   public boolean isAccountKicked() {
/* 87 */     return this.accountKicked;
/*    */   }
/*    */   public void setAccountKicked(boolean paramBoolean) {
/* 90 */     this.accountKicked = paramBoolean;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyConfig
 * JD-Core Version:    0.6.2
 */