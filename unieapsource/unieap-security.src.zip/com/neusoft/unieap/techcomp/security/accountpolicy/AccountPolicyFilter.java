/*    */ package com.neusoft.unieap.techcomp.security.accountpolicy;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.techcomp.security.i18n.I18nUtil;
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ import javax.servlet.http.HttpSession;
/*    */ 
/*    */ public class AccountPolicyFilter
/*    */   implements Filter
/*    */ {
/*    */   private AccountPolicyService accountPolicyService;
/*    */   private String kickedFailureUrl;
/*    */   private String lockedFailureUrl;
/*    */   private AccountPolicyConfig accountPolicyConfig;
/*    */ 
/*    */   public void setAccountPolicyConfig(AccountPolicyConfig paramAccountPolicyConfig)
/*    */   {
/* 29 */     this.accountPolicyConfig = paramAccountPolicyConfig;
/*    */   }
/*    */   public void init(FilterConfig paramFilterConfig) throws ServletException {
/*    */   }
/*    */   public void destroy() {
/*    */   }
/* 35 */   public void setAccountPolicyService(AccountPolicyService paramAccountPolicyService) { this.accountPolicyService = paramAccountPolicyService; }
/*    */ 
/*    */   public void setKickedFailureUrl(String paramString)
/*    */   {
/* 39 */     this.kickedFailureUrl = paramString;
/*    */   }
/*    */ 
/*    */   public void setLockedFailureUrl(String paramString) {
/* 43 */     this.lockedFailureUrl = paramString;
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain) throws IOException, ServletException
/*    */   {
/* 48 */     String str1 = this.accountPolicyConfig.getLockedPolicy();
/* 49 */     boolean bool = this.accountPolicyConfig.isAccountKicked();
/*    */ 
/* 51 */     if ((str1.equalsIgnoreCase("unlocked")) && 
/* 52 */       (!bool)) {
/* 53 */       paramFilterChain.doFilter(paramServletRequest, paramServletResponse);
/* 54 */       return;
/*    */     }
/*    */ 
/* 57 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)paramServletRequest;
/* 58 */     HttpServletResponse localHttpServletResponse = (HttpServletResponse)paramServletResponse;
/*    */ 
/* 60 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 61 */     HttpSession localHttpSession = localHttpServletRequest.getSession();
/* 62 */     String str2 = localHttpSession.getId();
/* 63 */     String str3 = localHttpServletRequest.getParameter("j_username");
/* 64 */     String str4 = localHttpServletRequest.getRemoteAddr();
/* 65 */     String str5 = null;
/*    */ 
/* 67 */     if (this.accountPolicyService.isLocked(str1, str4, str3)) {
/* 68 */       this.accountPolicyService.lockedProcess(localHttpServletRequest, localHttpServletResponse, this.lockedFailureUrl);
/* 69 */       return;
/*    */     }
/* 71 */     if ((bool) && (str3 == null))
/*    */     {
/* 73 */       if (this.accountPolicyService.isKicked(localUser.getAccount(), str2)) {
/* 74 */         if (localHttpServletRequest.getRequestURL().indexOf(this.kickedFailureUrl) == -1) {
/* 75 */           this.accountPolicyService.kickedProcess(localHttpServletRequest, localHttpServletResponse, this.kickedFailureUrl);
/* 76 */           return;
/*    */         }
/* 78 */         str5 = I18nUtil.getInstance().getValue("techcomp.security.accountKicked", new Object[] { localUser.getAccount() });
/* 79 */         localHttpServletRequest.setAttribute("loginErrorMsg", str5);
/*    */       }
/*    */     }
/* 82 */     paramFilterChain.doFilter(localHttpServletRequest, localHttpServletResponse);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.accountpolicy.AccountPolicyFilter
 * JD-Core Version:    0.6.2
 */