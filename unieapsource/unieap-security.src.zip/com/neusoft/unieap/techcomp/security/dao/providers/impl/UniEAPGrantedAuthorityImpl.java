/*    */ package com.neusoft.unieap.techcomp.security.dao.providers.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.security.dao.providers.UniEAPGrantedAuthority;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class UniEAPGrantedAuthorityImpl
/*    */   implements UniEAPGrantedAuthority, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 5685935054296922351L;
/*    */   private String roleID;
/*    */   private String roleType;
/*    */ 
/*    */   public UniEAPGrantedAuthorityImpl()
/*    */   {
/*    */   }
/*    */ 
/*    */   public UniEAPGrantedAuthorityImpl(String paramString1, String paramString2)
/*    */   {
/* 26 */     this.roleID = paramString1;
/* 27 */     this.roleType = paramString2;
/*    */   }
/*    */ 
/*    */   public void setRoleID(String paramString) {
/* 31 */     this.roleID = paramString;
/*    */   }
/*    */ 
/*    */   public void setRoleType(String paramString) {
/* 35 */     this.roleType = paramString;
/*    */   }
/*    */ 
/*    */   public String getRoleID() {
/* 39 */     return this.roleID;
/*    */   }
/*    */ 
/*    */   public String getRoleType() {
/* 43 */     return this.roleType;
/*    */   }
/*    */ 
/*    */   public String getAuthority() {
/* 47 */     return null;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object paramObject) {
/* 51 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.impl.UniEAPGrantedAuthorityImpl
 * JD-Core Version:    0.6.2
 */