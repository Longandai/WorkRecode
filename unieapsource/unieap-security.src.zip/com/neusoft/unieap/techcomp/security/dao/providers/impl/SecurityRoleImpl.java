/*    */ package com.neusoft.unieap.techcomp.security.dao.providers.impl;
/*    */ 
/*    */ import com.neusoft.unieap.techcomp.security.dao.providers.SecurityRole;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class SecurityRoleImpl
/*    */   implements SecurityRole, Serializable
/*    */ {
/*    */   static final long serialVersionUID = 33222221L;
/*    */   private String authority;
/*    */ 
/*    */   public SecurityRoleImpl(Object paramObject)
/*    */   {
/* 25 */     this.authority = paramObject.toString();
/*    */   }
/*    */ 
/*    */   public String getAuthority()
/*    */   {
/* 30 */     return this.authority;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 35 */     return this.authority;
/*    */   }
/*    */ 
/*    */   public int compareTo(Object paramObject) {
/* 39 */     return -1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.impl.SecurityRoleImpl
 * JD-Core Version:    0.6.2
 */