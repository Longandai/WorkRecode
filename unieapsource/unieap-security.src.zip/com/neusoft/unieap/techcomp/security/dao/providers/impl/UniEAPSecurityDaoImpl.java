/*     */ package com.neusoft.unieap.techcomp.security.dao.providers.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.Role;
/*     */ import com.neusoft.unieap.core.security.entity.RoleUser;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.org.bo.UserBO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.providers.SecurityUser;
/*     */ import com.neusoft.unieap.techcomp.security.lock.LockUserListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.security.GrantedAuthority;
/*     */ import org.springframework.security.userdetails.UserDetails;
/*     */ import org.springframework.security.userdetails.UserDetailsService;
/*     */ import org.springframework.security.userdetails.UsernameNotFoundException;
/*     */ 
/*     */ public class UniEAPSecurityDaoImpl
/*     */   implements UserDetailsService
/*     */ {
/*  32 */   private static Log log = LogFactory.getLog(UniEAPSecurityDaoImpl.class);
/*     */   private LockUserListener lockUserListener;
/*     */   private UserBO userBO;
/*     */   private EAPCacheManager eapCacheManager;
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void setLockUserListener(LockUserListener paramLockUserListener)
/*     */   {
/*  41 */     this.lockUserListener = paramLockUserListener;
/*     */   }
/*     */ 
/*     */   public LockUserListener getLockUserListener() {
/*  45 */     return this.lockUserListener;
/*     */   }
/*     */ 
/*     */   public UserDetails loadUserByUsername(String paramString) throws UsernameNotFoundException, DataAccessException
/*     */   {
/*  50 */     com.neusoft.unieap.techcomp.org.entity.User localUser = this.userBO.getUserByAccount(paramString);
/*  51 */     if (localUser == null) {
/*  52 */       throw new UsernameNotFoundException("User not found");
/*     */     }
/*  54 */     List localList = this.userBO.getRoleUsersByUserId(localUser.getId());
/*     */ 
/*  56 */     com.neusoft.unieap.core.context.properties.User localUser1 = newUser(localUser, localList);
/*     */ 
/*  58 */     if (localUser1 == null) {
/*  59 */       throw new UsernameNotFoundException("User not found");
/*     */     }
/*     */ 
/*  72 */     GrantedAuthority[] arrayOfGrantedAuthority = new GrantedAuthority[0];
/*     */ 
/*  74 */     if ((this.lockUserListener != null) && 
/*  75 */       (!localUser1.getAccountLocked().booleanValue()) && (this.lockUserListener.isLock()) && (this.lockUserListener.getLockNumber() > 0)) {
/*  76 */       String str = localUser1.getAccount();
/*  77 */       Map localMap = this.lockUserListener.getUserFailLoginList();
/*  78 */       Integer localInteger = (Integer)localMap.get(str);
/*     */ 
/*  80 */       if ((localInteger != null) && (localInteger.intValue() >= this.lockUserListener.getLockNumber())) {
/*  81 */         this.userBO.updateUserLockState(str, true);
/*  82 */         this.lockUserListener.cleanCount(str);
/*     */ 
/*  84 */         localUser1.setAccountLocked(Boolean.valueOf(true));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  89 */     this.eapCacheManager.put(paramString, localUser1, "loginUsers");
/*     */ 
/*  91 */     return new SecurityUser(localUser1.getAccount(), localUser1.getPassword(), localUser1.getAccountEnabled().booleanValue(), 
/*  92 */       true, true, !localUser1.getAccountLocked().booleanValue(), arrayOfGrantedAuthority);
/*     */   }
/*     */ 
/*     */   public void setUserBO(UserBO paramUserBO) {
/*  96 */     this.userBO = paramUserBO;
/*     */   }
/*     */ 
/*     */   public UserBO getUserBO() {
/* 100 */     return this.userBO;
/*     */   }
/*     */ 
/*     */   protected com.neusoft.unieap.core.context.properties.User newUser(com.neusoft.unieap.techcomp.org.entity.User paramUser, List paramList)
/*     */   {
/* 110 */     com.neusoft.unieap.core.context.properties.User localUser = new com.neusoft.unieap.core.context.properties.User();
/* 111 */     localUser.setId(paramUser.getId());
/* 112 */     localUser.setAccount(paramUser.getAccount());
/* 113 */     localUser.setAccountEnabled(paramUser.getAccountEnabled());
/* 114 */     localUser.setAccountLocked(paramUser.getAccountLocked());
/* 115 */     localUser.setName(paramUser.getName());
/* 116 */     localUser.setPassword(paramUser.getPassword());
/* 117 */     localUser.setType(paramUser.getType());
/*     */ 
/* 120 */     ArrayList localArrayList = new ArrayList();
/* 121 */     for (int i = 0; i < paramList.size(); i++) {
/* 122 */       RoleUser localRoleUser = (RoleUser)paramList.get(i);
/* 123 */       Role localRole = new Role();
/* 124 */       localRole.setId(localRoleUser.getRoleId());
/* 125 */       localRole.setName(localRoleUser.getRoleName());
/* 126 */       localRole.setType(localRoleUser.getRoleType());
/* 127 */       localArrayList.add(localRole);
/*     */     }
/* 129 */     localUser.setRoles(localArrayList);
/* 130 */     return localUser;
/*     */   }
/*     */ 
/*     */   public void setEapCacheManager(EAPCacheManager paramEAPCacheManager) {
/* 134 */     this.eapCacheManager = paramEAPCacheManager;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.impl.UniEAPSecurityDaoImpl
 * JD-Core Version:    0.6.2
 */