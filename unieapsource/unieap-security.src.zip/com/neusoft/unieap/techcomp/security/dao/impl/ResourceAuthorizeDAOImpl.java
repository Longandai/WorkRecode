/*     */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.ResourceAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ public class ResourceAuthorizeDAOImpl extends BaseHibernateDAO
/*     */   implements ResourceAuthorizeDAO
/*     */ {
/*     */   public List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*     */     String str;
/*     */     List localList;
/*  35 */     if (paramString5 == null) {
/*  36 */       str = "select resourceAuthority.resourceId from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? and resourceAuthority.dimensionConstraint is null ";
/*  37 */       localList = getHibernateTemplate().find(
/*  38 */         str, 
/*  39 */         new Object[] { paramString1, paramString2, paramString3, 
/*  40 */         paramString4 });
/*     */     } else {
/*  42 */       str = "select resourceAuthority.resourceId from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? and resourceAuthority.dimensionConstraint = ? ";
/*  43 */       localList = getHibernateTemplate().find(
/*  44 */         str, 
/*  45 */         new Object[] { paramString1, paramString2, paramString3, 
/*  46 */         paramString4, paramString5 });
/*     */     }
/*     */ 
/*  49 */     return localList;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthoritys(List paramList)
/*     */   {
/*  56 */     if (paramList.size() == 0)
/*  57 */       return;
/*  58 */     for (int i = 0; i < paramList.size(); i++)
/*  59 */       saveResourceAuthority((ResourceAuthority)paramList.get(i));
/*     */   }
/*     */ 
/*     */   public ResourceAuthority saveResourceAuthority(ResourceAuthority paramResourceAuthority)
/*     */   {
/*  68 */     super.getHibernateTemplate().save(paramResourceAuthority);
/*  69 */     return paramResourceAuthority;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(final List paramList, final String paramString1, final String paramString2)
/*     */   {
/*  77 */     if ((paramList == null) || (paramList.size() == 0)) {
/*  78 */       return new ArrayList();
/*     */     }
/*  80 */     List localList = (List)getHibernateTemplate().execute(
/*  81 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  84 */         String str = "select distinct resourceAuthority.resourceId from ResourceAuthority resourceAuthority where resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? ";
/*     */ 
/*  88 */         str = str + "and resourceAuthority.roleId in (:roleIds)";
/*     */ 
/*  90 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  91 */         localQuery.setParameterList("roleIds", paramList);
/*  92 */         localQuery.setParameter(0, paramString1);
/*  93 */         localQuery.setParameter(1, paramString2);
/*     */ 
/*  95 */         return localQuery.list();
/*     */       }
/*     */     });
/*  98 */     return localList;
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString)
/*     */   {
/* 105 */     String str = "delete ResourceAuthority resourceAuthority where resourceAuthority.roleId = ?";
/*     */ 
/* 107 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(List paramList)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(final List paramList, final String paramString)
/*     */   {
/* 127 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/* 131 */         paramAnonymousSession.createQuery("delete from ResourceAuthority resourceAuthority where (resourceAuthority.resourceId in (:resourceIds) and resourceAuthority.resourceType = :resourceType ) or(resourceAuthority.circumstanceId in (:resourceIds) and resourceAuthority.circumstanceType = :resourceType )").setParameterList("resourceIds", paramList)
/* 132 */           .setParameter("resourceType", paramString)
/* 133 */           .executeUpdate();
/* 134 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(List paramList, String paramString1, String paramString2)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5)
/*     */   {
/* 154 */     String str1 = "delete from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ?and resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? ";
/*     */ 
/* 160 */     String str2 = "";
/* 161 */     if (paramString5 == null)
/* 162 */       str2 = "and resourceAuthority.dimensionConstraint is null";
/*     */     else {
/* 164 */       str2 = "and resourceAuthority.dimensionConstraint = '" + 
/* 165 */         paramString5 + "'";
/*     */     }
/*     */ 
/* 168 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 169 */       String str3 = localObject.toString();
/* 170 */       if (paramString5 == null) {
/* 171 */         paramString5 = "";
/*     */       }
/* 173 */       getHibernateTemplate().bulkUpdate(
/* 174 */         str1 + str2, 
/* 175 */         new Object[] { paramString1, paramString2, str3, paramString3, 
/* 176 */         paramString4 });
/*     */     }
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(final List paramList1, final String paramString1, final List paramList2, final String paramString2, final String paramString3, String paramString4)
/*     */   {
/* 193 */     String str1 = "";
/* 194 */     if (paramString4 == null)
/* 195 */       str1 = "and resourceAuthority.dimensionConstraint is null";
/*     */     else {
/* 197 */       str1 = "and resourceAuthority.dimensionConstraint = '" + 
/* 198 */         paramString4 + "'";
/*     */     }
/* 200 */     final String str2 = str1;
/* 201 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/* 205 */         paramAnonymousSession.createQuery("delete from ResourceAuthority resourceAuthority where resourceAuthority.roleId in (:roleIds) and resourceAuthority.roleType = :roleType and resourceAuthority.resourceId in (:resourceIds) and resourceAuthority.resourceType = :resourceType and resourceAuthority.authorityType = :authorityType " + str2).setParameterList("roleIds", 
/* 206 */           paramList1).setParameter("roleType", paramString1)
/* 207 */           .setParameterList("resourceIds", paramList2)
/* 208 */           .setParameter("resourceType", paramString2)
/* 209 */           .setParameter("authorityType", paramString3)
/* 210 */           .executeUpdate();
/* 211 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorities(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/* 229 */     String str1 = "delete from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ?and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? ";
/*     */ 
/* 234 */     String str2 = "";
/* 235 */     if (paramString5 == null)
/* 236 */       str2 = "and resourceAuthority.dimensionConstraint is null";
/*     */     else {
/* 238 */       str2 = "and resourceAuthority.dimensionConstraint = '" + 
/* 239 */         paramString5 + "'";
/*     */     }
/*     */ 
/* 242 */     getHibernateTemplate().bulkUpdate(
/* 243 */       str1 + str2, 
/* 244 */       new Object[] { paramString1, paramString2, paramString3, paramString4 });
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthority(ResourceAuthority paramResourceAuthority)
/*     */   {
/* 251 */     super.getHibernateTemplate().delete(paramResourceAuthority);
/*     */   }
/*     */ 
/*     */   public String getAuthorityType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
/*     */   {
/*     */     String str;
/*     */     List localList;
/* 261 */     if (paramString5 == null) {
/* 262 */       str = "select resourceAuthority.authorityType from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ? and resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and (resourceAuthority.dimensionConstraint is null or resourceAuthority.dimensionConstraint='')";
/*     */ 
/* 268 */       localList = getHibernateTemplate().find(str, new Object[] { paramString1, paramString2, paramString3, paramString4 });
/* 269 */       if ((localList != null) && (localList.size() > 0))
/* 270 */         return localList.get(0).toString();
/*     */     } else {
/* 272 */       str = "select resourceAuthority.authorityType from ResourceAuthority resourceAuthority where resourceAuthority.roleId = ? and resourceAuthority.roleType = ? and resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and resourceAuthority.dimensionConstraint = ?";
/*     */ 
/* 278 */       localList = getHibernateTemplate().find(str, new Object[] { paramString1, paramString2, paramString3, paramString4, paramString5 });
/* 279 */       if ((localList != null) && (localList.size() > 0))
/* 280 */         return localList.get(0).toString();
/*     */     }
/* 282 */     return null;
/*     */   }
/*     */ 
/*     */   public List getAuthorityType(List paramList, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList1, List paramList2, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 301 */     return null;
/*     */   }
/*     */ 
/*     */   public List getResourceIds(List paramList, String paramString1, String paramString2, String paramString3)
/*     */   {
/* 310 */     return null;
/*     */   }
/*     */ 
/*     */   public void saveResourceAuthorities(List paramList)
/*     */   {
/* 317 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 318 */       ResourceAuthority localResourceAuthority = (ResourceAuthority)localObject;
/* 319 */       getHibernateTemplate().save(localResourceAuthority);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void updateAuthorityType(String paramString1, String paramString2)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void updateResourceAuthority(ResourceAuthority paramResourceAuthority)
/*     */   {
/* 336 */     super.getHibernateTemplate().update(paramResourceAuthority);
/*     */   }
/*     */ 
/*     */   public void deleteResourceAuthorityList(final List paramList)
/*     */   {
/* 343 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 346 */         String str = "delete from ResourceAuthority resourceAuthority where";
/* 347 */         str = str + " resourceAuthority.id in (:resourceIds)";
/* 348 */         int i = paramList.size();
/* 349 */         ArrayList localArrayList = new ArrayList();
/* 350 */         for (int j = 0; j < i; j++) {
/* 351 */           ResourceAuthority localResourceAuthority = 
/* 352 */             (ResourceAuthority)paramList
/* 352 */             .get(j);
/* 353 */           localArrayList.add(localResourceAuthority.getId());
/*     */         }
/* 355 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 356 */         localQuery.setParameterList("resourceIds", localArrayList);
/* 357 */         localQuery.executeUpdate();
/* 358 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getRoleIds(final String paramString1, final String paramString2, final String paramString3, final String paramString4)
/*     */   {
/* 368 */     List localList = (List)getHibernateTemplate().execute(
/* 369 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 372 */         String str = "select distinct resourceAuthority.roleId from ResourceAuthority resourceAuthority where resourceAuthority.roleType = ? and resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? ";
/*     */ 
/* 378 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 379 */         localQuery.setParameter(0, paramString1);
/* 380 */         localQuery.setParameter(1, paramString2);
/* 381 */         localQuery.setParameter(2, paramString3);
/* 382 */         localQuery.setParameter(3, paramString4);
/* 383 */         return localQuery.list();
/*     */       }
/*     */     });
/* 386 */     return localList;
/*     */   }
/*     */ 
/*     */   public List getRoleIds(final String paramString1, final String paramString2, final String paramString3)
/*     */   {
/* 394 */     List localList = (List)getHibernateTemplate().execute(
/* 395 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 398 */         String str = "select distinct resourceAuthority.roleId from ResourceAuthority resourceAuthority where resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? and resourceAuthority.roleType in (:roleTypes)";
/*     */ 
/* 404 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 405 */         ArrayList localArrayList = new ArrayList();
/* 406 */         localArrayList.add("busiRole");
/* 407 */         localArrayList.add("unit");
/* 408 */         localQuery.setParameter(0, paramString1);
/* 409 */         localQuery.setParameter(1, paramString2);
/* 410 */         localQuery.setParameter(2, paramString3);
/* 411 */         localQuery.setParameterList("roleTypes", localArrayList);
/* 412 */         return localQuery.list();
/*     */       }
/*     */     });
/* 415 */     return localList;
/*     */   }
/*     */ 
/*     */   public boolean isExistInResourceAuthority(final String paramString1, final String paramString2, final String paramString3, final String paramString4, final String paramString5)
/*     */   {
/* 424 */     List localList = (List)getHibernateTemplate().execute(
/* 425 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 428 */         String str = "from ResourceAuthority resourceAuthority where  resourceAuthority.roleId = ? and resourceAuthority.roleType = ? and resourceAuthority.resourceId = ? and resourceAuthority.resourceType = ? and resourceAuthority.authorityType = ? ";
/*     */ 
/* 434 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 435 */         localQuery.setParameter(0, paramString1);
/* 436 */         localQuery.setParameter(1, paramString2);
/* 437 */         localQuery.setParameter(2, paramString3);
/* 438 */         localQuery.setParameter(3, paramString4);
/* 439 */         localQuery.setParameter(4, paramString5);
/* 440 */         return localQuery.list();
/*     */       }
/*     */     });
/* 443 */     if ((localList == null) || (localList.size() == 0)) {
/* 444 */       return false;
/*     */     }
/* 446 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.ResourceAuthorizeDAOImpl
 * JD-Core Version:    0.6.2
 */