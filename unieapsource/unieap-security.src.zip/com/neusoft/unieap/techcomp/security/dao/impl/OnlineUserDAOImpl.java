/*     */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*     */ import com.neusoft.unieap.techcomp.security.dao.OnlineUserDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.OnlineUser;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("onlineUserDAO.dao")
/*     */ public class OnlineUserDAOImpl extends BaseHibernateDAO
/*     */   implements OnlineUserDAO
/*     */ {
/*     */   public void saveOnlineUser(OnlineUser paramOnlineUser)
/*     */   {
/*  32 */     getHibernateTemplate().save(paramOnlineUser);
/*     */   }
/*     */ 
/*     */   public void updateOnlineUser(OnlineUser paramOnlineUser)
/*     */   {
/*  39 */     getHibernateTemplate().update(paramOnlineUser);
/*     */   }
/*     */ 
/*     */   public void deleteOnlineUserBySessionId(String paramString)
/*     */   {
/*  46 */     String str = "delete from OnlineUser onlineUser where onlineUser.sessionId = ?";
/*  47 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public void deleteOnlineUsersByUserId(String paramString)
/*     */   {
/*  54 */     String str = "delete from OnlineUser onlineUser where onlineUser.user.id = ?";
/*  55 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public void deleteOnlineUsersByServerIp(String paramString)
/*     */   {
/*  62 */     String str = "delete from OnlineUser onlineUser where onlineUser.serverIp = ?";
/*  63 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public List getAllOnlineUsers(final int paramInt1, final int paramInt2)
/*     */   {
/*  70 */     List localList = (List)getHibernateTemplate().execute(
/*  71 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  74 */         String str = "from OnlineUser onlineUser left join fetch onlineUser.user";
/*  75 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  76 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  77 */         localQuery.setMaxResults(paramInt2);
/*  78 */         return localQuery.list();
/*     */       }
/*     */     });
/*  81 */     return localList;
/*     */   }
/*     */ 
/*     */   public int getAllOnlineUsersNumber()
/*     */   {
/*  88 */     String str = "select count(onlineUser.id) from OnlineUser onlineUser";
/*  89 */     return Integer.parseInt(getHibernateTemplate().find(str).get(0)
/*  90 */       .toString());
/*     */   }
/*     */ 
/*     */   public List getOnlineUsers(final int paramInt1, final int paramInt2)
/*     */   {
/*  97 */     List localList = (List)getHibernateTemplate().execute(
/*  98 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 101 */         String str = "from OnlineUser onlineUser left join fetch onlineUser.user where " + 
/* 102 */           AdvanceQueryUtil.getHQLCondition("onlineUser");
/* 103 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 104 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 105 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 106 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 108 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 109 */         localQuery.setMaxResults(paramInt2);
/* 110 */         return localQuery.list();
/*     */       }
/*     */     });
/* 113 */     return localList;
/*     */   }
/*     */ 
/*     */   public int getOnlineUsersNumber()
/*     */   {
/* 120 */     int i = ((Integer)getHibernateTemplate().execute(
/* 121 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 124 */         String str = "select count(onlineUser.id) from OnlineUser onlineUser where " + 
/* 125 */           AdvanceQueryUtil.getHQLCondition("onlineUser");
/* 126 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*     */ 
/* 128 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 129 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 130 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 132 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*     */       }
/*     */     })).intValue();
/*     */ 
/* 135 */     return i;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.OnlineUserDAOImpl
 * JD-Core Version:    0.6.2
 */