package com.neusoft.unieap.techcomp.security.dao;

import com.neusoft.unieap.techcomp.org.entity.User;
import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
import java.util.List;

public abstract interface AccountPolicyDAO
{
  public abstract void saveAccountPolicy(AccountPolicy paramAccountPolicy);

  public abstract void updateAccountPolicy(AccountPolicy paramAccountPolicy);

  public abstract void deleteAccountPolicy(AccountPolicy paramAccountPolicy);

  public abstract List getLockedAccounts(int paramInt);

  public abstract void unlockAccount(String paramString);

  public abstract List getAllUsers(int paramInt1, int paramInt2, int paramInt3);

  public abstract int getAllUsersNumber(int paramInt);

  public abstract List getUsers(String paramString, int paramInt1, int paramInt2, int paramInt3);

  public abstract int getUsersNumber(String paramString, int paramInt);

  public abstract List getActiveAccountPolicies(int paramInt);

  public abstract List getActiveAccountPolicies();

  public abstract List<User> getManagedUsers(String paramString, int paramInt1, int paramInt2, int paramInt3);

  public abstract int getManagedUsersNumber(String paramString, int paramInt);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.AccountPolicyDAO
 * JD-Core Version:    0.6.2
 */