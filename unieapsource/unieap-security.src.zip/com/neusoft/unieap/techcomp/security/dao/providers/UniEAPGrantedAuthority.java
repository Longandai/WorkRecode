package com.neusoft.unieap.techcomp.security.dao.providers;

public abstract interface UniEAPGrantedAuthority extends SecurityRole
{
  public abstract String getRoleID();

  public abstract String getRoleType();
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.UniEAPGrantedAuthority
 * JD-Core Version:    0.6.2
 */