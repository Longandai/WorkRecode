package com.neusoft.unieap.techcomp.security.dao;

import java.util.List;

public abstract interface PageAuthorizeDAO
{
  public abstract List getPageAuthorities(String paramString1, String paramString2, String paramString3);

  public abstract List getPageAuthorities(List paramList, String paramString1, String paramString2, String paramString3);

  public abstract List getPageAuthorities(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void delPageAuthoritiesByCirId(String paramString1, String paramString2);

  public abstract void copyAuthoritiesByCirId(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.PageAuthorizeDAO
 * JD-Core Version:    0.6.2
 */