package com.neusoft.unieap.techcomp.security.dao;

import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
import java.util.List;

public abstract interface ResourceAuthorizeDAO
{
  public abstract List getResourceIds(List paramList, String paramString1, String paramString2);

  public abstract ResourceAuthority saveResourceAuthority(ResourceAuthority paramResourceAuthority);

  public abstract void saveResourceAuthorities(List paramList);

  public abstract void deleteResourceAuthorities(String paramString);

  public abstract void deleteResourceAuthorities(List paramList);

  public abstract void deleteResourceAuthorities(List paramList, String paramString);

  public abstract void deleteResourceAuthorities(List paramList, String paramString1, String paramString2);

  public abstract void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5);

  public abstract void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4);

  public abstract void deleteResourceAuthorities(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract void deleteResourceAuthorities(List paramList1, String paramString1, List paramList2, String paramString2, String paramString3, String paramString4);

  public abstract void deleteResourceAuthority(ResourceAuthority paramResourceAuthority);

  public abstract List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract String getAuthorityType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract List getResourceIds(List paramList1, List paramList2, String paramString1, String paramString2, String paramString3);

  public abstract List getResourceIds(List paramList, String paramString1, String paramString2, String paramString3);

  public abstract List getAuthorityType(List paramList, String paramString1, String paramString2, String paramString3);

  public abstract void updateAuthorityType(String paramString1, String paramString2);

  public abstract void updateResourceAuthority(ResourceAuthority paramResourceAuthority);

  public abstract void deleteResourceAuthorityList(List paramList);

  public abstract List getRoleIds(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract List getRoleIds(String paramString1, String paramString2, String paramString3);

  public abstract boolean isExistInResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.ResourceAuthorizeDAO
 * JD-Core Version:    0.6.2
 */