/*    */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.techcomp.security.dao.UserBusiRoleDAO;
/*    */ import java.util.List;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ @ModelFile("userBusiRoleDAO.dao")
/*    */ public class UserBusiRoleDAOImpl extends BaseHibernateDAO
/*    */   implements UserBusiRoleDAO
/*    */ {
/*    */   public List getBusiRolesByUserId(String paramString)
/*    */   {
/* 24 */     String str = "select busiRoleUser.role from BusiRoleUser busiRoleUser where busiRoleUser.user.id = ?";
/*    */ 
/* 26 */     return getHibernateTemplate().find(str, paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.UserBusiRoleDAOImpl
 * JD-Core Version:    0.6.2
 */