package com.neusoft.unieap.techcomp.security.dao;

import java.util.List;

public abstract interface UserBusiRoleDAO
{
  public abstract List getBusiRolesByUserId(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.UserBusiRoleDAO
 * JD-Core Version:    0.6.2
 */