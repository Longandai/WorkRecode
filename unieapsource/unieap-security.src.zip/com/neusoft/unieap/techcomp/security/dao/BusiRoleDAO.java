package com.neusoft.unieap.techcomp.security.dao;

import com.neusoft.unieap.techcomp.org.entity.User;
import com.neusoft.unieap.techcomp.security.entity.BusiRole;
import com.neusoft.unieap.techcomp.security.entity.BusiRoleUser;
import java.util.List;

public abstract interface BusiRoleDAO
{
  public abstract List getAllBusiRoles(int paramInt1, int paramInt2);

  public abstract int getAllBusiRolesNumber();

  public abstract List getAllBusiRolesBySecurityRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract int getAllBusiRolesNumberBySecurityRoleId(String paramString);

  public abstract List getAllBusiRolesExceptUserId(String paramString, int paramInt1, int paramInt2);

  public abstract int getAllBusiRolesNumberExceptUserId(String paramString);

  public abstract boolean isNameAlreadyExist(String paramString);

  public abstract BusiRole saveBusiRole(BusiRole paramBusiRole);

  public abstract BusiRole updateBusiRole(BusiRole paramBusiRole);

  public abstract void deleteAdminRoleBusiRoleByBusiRoleId(String paramString);

  public abstract void deleteBusiRoleUserByBusiRoleId(String paramString);

  public abstract void deleteBusiRoleById(String paramString);

  public abstract BusiRoleUser saveBusiRoleUser(BusiRoleUser paramBusiRoleUser);

  public abstract void deleteBusiRoleUser(String paramString1, String paramString2);

  public abstract BusiRole getBusiRoleById(String paramString);

  public abstract List getBusiRolesByUserId(String paramString);

  public abstract List<User> getUsersByBusiRoleId(String paramString);

  public abstract List getUsersByBusiRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract int getUsersByBusiRoleIdNumber(String paramString);

  public abstract List getUsersByBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getUsersByBusiRoleIdNumber(String paramString1, String paramString2);

  public abstract List getUsersByUnitIdExceptedBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getUsersNumberByUnitIdExceptedBusiRoleId(String paramString1, String paramString2);

  public abstract List<User> getUsersExceptedBusiRoleIdWithAdvanceQuery(String paramString, int paramInt1, int paramInt2);

  public abstract int getUsersNumberExceptedBusiRoleIdWithAdvanceQuery(String paramString);

  public abstract void deleteBusiRoleUserByUserId(String paramString);

  public abstract List getUsersByBusiRoleIds(List paramList, int paramInt1, int paramInt2);

  public abstract int getUsersNumberByBusiRoleIds(List paramList);

  public abstract List getMixedUsers(List paramList1, List paramList2, int paramInt1, int paramInt2);

  public abstract int getMixedUsersNumber(List paramList1, List paramList2);

  public abstract List getManagedUsersExceptBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getManagedUsersNumberExceptBusiRoleId(String paramString1, String paramString2);

  public abstract List getUsersByBusiRoleIdWithAdvanceQuery(String paramString, int paramInt1, int paramInt2);

  public abstract int getUsersByBusiRoleIdNumberWithAdvanceQuery(String paramString);

  public abstract List getUsersByBusiRoleIdWithAdvanceQuery(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getUsersByBusiRoleIdNumberWithAdvanceQuery(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.BusiRoleDAO
 * JD-Core Version:    0.6.2
 */