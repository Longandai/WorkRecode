/*     */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.security.dao.PageAuthorizeDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("pageAuthorizeDAO.dao")
/*     */ public class PageAuthorizeDAOImpl extends BaseHibernateDAO
/*     */   implements PageAuthorizeDAO
/*     */ {
/*     */   public List getPageAuthorities(final String paramString1, final String paramString2, final String paramString3)
/*     */   {
/*  33 */     List localList = (List)getHibernateTemplate().execute(
/*  34 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  37 */         String str = "from ResourceAuthority resourceAuthority where resourceAuthority.resourceId like ? and resourceAuthority.circumstanceId = ? and resourceAuthority.circumstanceType = ? and resourceAuthority.resourceType = ?";
/*     */ 
/*  42 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  43 */         localQuery.setParameter(0, paramString1 + "%");
/*  44 */         localQuery.setParameter(1, paramString2);
/*  45 */         localQuery.setParameter(2, paramString3);
/*  46 */         localQuery.setParameter(3, "page");
/*  47 */         return localQuery.list();
/*     */       }
/*     */     });
/*  50 */     return localList;
/*     */   }
/*     */ 
/*     */   public List getPageAuthorities(final List paramList, final String paramString1, final String paramString2, final String paramString3)
/*     */   {
/*  57 */     List localList = (List)getHibernateTemplate().execute(
/*  58 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  61 */         String str = "select distinct resourceAuthority from ResourceAuthority resourceAuthority where resourceAuthority.resourceId like ? and resourceAuthority.resourceType = ? ";
/*     */ 
/*  65 */         str = str + "and((resourceAuthority.circumstanceId = ? and resourceAuthority.circumstanceType = ?)  or (resourceAuthority.circumstanceId is null and resourceAuthority.circumstanceType is null))";
/*     */ 
/*  67 */         str = str + "and resourceAuthority.roleId in (:roleIds)";
/*  68 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  69 */         localQuery.setParameter(0, paramString1 + "%");
/*  70 */         localQuery.setParameter(1, "page");
/*  71 */         localQuery.setParameter(2, paramString2);
/*  72 */         localQuery.setParameter(3, paramString3);
/*  73 */         localQuery.setParameterList("roleIds", paramList);
/*  74 */         return localQuery.list();
/*     */       }
/*     */     });
/*  77 */     return localList;
/*     */   }
/*     */ 
/*     */   public List getPageAuthorities(final String paramString1, final String paramString2, final String paramString3, final String paramString4)
/*     */   {
/*  84 */     List localList = (List)getHibernateTemplate().execute(
/*  85 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/*  89 */         String str = "select distinct resourceAuthority from ResourceAuthority resourceAuthority where resourceAuthority.resourceId like ? and resourceAuthority.roleId = ? and resourceAuthority.resourceType = ? and((resourceAuthority.circumstanceId = ? and resourceAuthority.circumstanceType = ?)  or (resourceAuthority.circumstanceId is null and resourceAuthority.circumstanceType is null))";
/*     */ 
/*  95 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  96 */         localQuery.setParameter(0, paramString2 + "%");
/*  97 */         localQuery.setParameter(1, paramString1);
/*  98 */         localQuery.setParameter(2, "page");
/*  99 */         localQuery.setParameter(3, paramString3);
/* 100 */         localQuery.setParameter(4, paramString4);
/* 101 */         return localQuery.list();
/*     */       }
/*     */     });
/* 104 */     return localList;
/*     */   }
/*     */ 
/*     */   public void copyAuthoritiesByCirId(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 112 */     String str = "from ResourceAuthority resourceAuthority where resourceAuthority.circumstanceId = ? and resourceAuthority.circumstanceType = ? and resourceAuthority.resourceType = ?";
/*     */ 
/* 116 */     List localList = getHibernateTemplate().find(str, new Object[] { paramString1, paramString3, "page" });
/*     */ 
/* 118 */     if ((localList != null) && (localList.size() > 0)) {
/* 119 */       int i = localList.size();
/* 120 */       for (int j = 0; j < i; j++) {
/* 121 */         ResourceAuthority localResourceAuthority1 = (ResourceAuthority)localList.get(j);
/* 122 */         ResourceAuthority localResourceAuthority2 = new ResourceAuthority();
/* 123 */         localResourceAuthority2.setCircumstanceId(paramString2);
/* 124 */         localResourceAuthority2.setCircumstanceType(localResourceAuthority1.getCircumstanceType());
/* 125 */         localResourceAuthority2.setRoleId(localResourceAuthority1.getRoleId());
/* 126 */         localResourceAuthority2.setRoleType(localResourceAuthority1.getRoleType());
/* 127 */         localResourceAuthority2.setResourceId(localResourceAuthority1.getResourceId());
/* 128 */         localResourceAuthority2.setResourceType(localResourceAuthority1.getResourceType());
/* 129 */         localResourceAuthority2.setAuthorityType(localResourceAuthority1.getAuthorityType());
/* 130 */         getHibernateTemplate().save(localResourceAuthority2);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void delPageAuthoritiesByCirId(String paramString1, String paramString2)
/*     */   {
/* 140 */     String str = "delete from ResourceAuthority resourceAuthority where resourceAuthority.circumstanceId = ? and resourceAuthority.circumstanceType = ?";
/* 141 */     getHibernateTemplate().bulkUpdate(str, new Object[] { paramString1, paramString2 });
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.PageAuthorizeDAOImpl
 * JD-Core Version:    0.6.2
 */