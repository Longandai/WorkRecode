/*     */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.org.entity.AdminRoleUnit;
/*     */ import com.neusoft.unieap.techcomp.org.entity.DimensionUnit;
/*     */ import com.neusoft.unieap.techcomp.org.entity.User;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.dto.Condition;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.pojo.QueryCondition;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*     */ import com.neusoft.unieap.techcomp.security.dao.AccountPolicyDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AccountPolicy;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("AccountPolicyDAO.dao")
/*     */ public class AccountPolicyDAOImpl extends BaseHibernateDAO
/*     */   implements AccountPolicyDAO
/*     */ {
/*     */   public void saveAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/*  40 */     getHibernateTemplate().save(paramAccountPolicy);
/*     */   }
/*     */ 
/*     */   public void updateAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/*  47 */     getHibernateTemplate().update(paramAccountPolicy);
/*     */   }
/*     */ 
/*     */   public void deleteAccountPolicy(AccountPolicy paramAccountPolicy)
/*     */   {
/*  54 */     getHibernateTemplate().delete(paramAccountPolicy);
/*     */   }
/*     */ 
/*     */   public List getLockedAccounts(final int paramInt)
/*     */   {
/*  61 */     List localList = (List)getHibernateTemplate().execute(
/*  62 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  65 */         Long localLong = Long.valueOf(new Date().getTime());
/*  66 */         String str = "from AccountPolicy ap where ap.state = ? ";
/*  67 */         if (paramInt != -1) {
/*  68 */           str = str + " and ap.loginTime > ? ";
/*     */         }
/*  70 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  71 */         localQuery.setParameter(0, "locked");
/*  72 */         if (paramInt != -1) {
/*  73 */           localQuery.setParameter(1, 
/*  74 */             new Timestamp(localLong.longValue() - paramInt * 60 * 1000));
/*     */         }
/*  76 */         return localQuery.list();
/*     */       }
/*     */     });
/*  79 */     return localList;
/*     */   }
/*     */ 
/*     */   public void unlockAccount(String paramString)
/*     */   {
/*  86 */     String str = "update AccountPolicy ap set ap.state = ? where ap.account = ? ";
/*  87 */     getHibernateTemplate().bulkUpdate(str, 
/*  88 */       new Object[] { "unlock", paramString });
/*     */   }
/*     */ 
/*     */   public List getAllUsers(final int paramInt1, final int paramInt2, final int paramInt3)
/*     */   {
/*  95 */     String str1 = "";
/*  96 */     Condition localCondition1 = 0;
/*  97 */     String str2 = AdvanceQueryUtil.getHQLCondition("user");
/*  98 */     str1 = "select count(*) from AccountPolicy ap";
/*  99 */     List localList = getHibernateTemplate().find(str1);
/* 100 */     if ((localList != null) && (((Long)localList.get(0)).intValue() > 0)) {
/* 101 */       if (str2.indexOf("accountLocked") != -1) {
/* 102 */         localObject1 = 
/* 103 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 104 */         for (localObject2 = ((List)localObject1).iterator(); ((Iterator)localObject2).hasNext(); ) { localCondition2 = (Condition)((Iterator)localObject2).next();
/* 105 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 106 */             if (localCondition2.getValue().equals("true")) {
/* 107 */               localCondition1 = 1;
/* 108 */               str1 = "select distinct user from User user, AccountPolicy ap where (( " + 
/* 109 */                 str2 + 
/* 110 */                 " ) or ( user.account = ap.account and ap.loginTime > ? and ap.state = ? ))";
/*     */ 
/* 108 */               break;
/*     */             }
/*     */ 
/* 112 */             str1 = "from User user where " + str2;
/*     */ 
/* 114 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 118 */         str1 = "from User user where " + str2;
/*     */       }
/*     */     }
/* 121 */     else str1 = "from User user where " + str2;
/*     */ 
/* 123 */     str1 = str1 + " and user.activeFlag = ?";
/*     */ 
/* 125 */     Object localObject1 = str1;
/* 126 */     final Condition localCondition2 = localCondition1;
/* 127 */     Object localObject2 = (List)getHibernateTemplate().execute(
/* 128 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 131 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 132 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 133 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 134 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 136 */         if (localCondition2) {
/* 137 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 138 */             .getTime() - 
/* 139 */             paramInt3 * 60 * 1000));
/* 140 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 141 */             "locked");
/* 142 */           localQuery.setParameter(arrayOfObject.length + 2, Boolean.valueOf(true));
/*     */         } else {
/* 144 */           localQuery.setParameter(arrayOfObject.length, Boolean.valueOf(true));
/*     */         }
/* 146 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 147 */         localQuery.setMaxResults(paramInt2);
/* 148 */         return localQuery.list();
/*     */       }
/*     */     });
/* 151 */     return localObject2;
/*     */   }
/*     */ 
/*     */   public int getAllUsersNumber(final int paramInt)
/*     */   {
/* 158 */     String str1 = "";
/* 159 */     Condition localCondition1 = 0;
/* 160 */     String str2 = AdvanceQueryUtil.getHQLCondition("user");
/* 161 */     str1 = "select count(*) from AccountPolicy ap";
/* 162 */     List localList = getHibernateTemplate().find(str1);
/* 163 */     if ((localList != null) && (((Long)localList.get(0)).intValue() > 0)) {
/* 164 */       if (str2.indexOf("accountLocked") != -1) {
/* 165 */         localObject = 
/* 166 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 167 */         for (Iterator localIterator = ((List)localObject).iterator(); localIterator.hasNext(); ) { localCondition2 = (Condition)localIterator.next();
/* 168 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 169 */             if (localCondition2.getValue().equals("true")) {
/* 170 */               localCondition1 = 1;
/* 171 */               str1 = "select count(distinct user) from User user, AccountPolicy ap where (( " + 
/* 172 */                 str2 + 
/* 173 */                 " ) or ( user.account = ap.account and ap.loginTime > ? and ap.state = ? ))";
/*     */ 
/* 171 */               break;
/*     */             }
/*     */ 
/* 175 */             str1 = "select count(user.id) from User user where " + 
/* 176 */               str2;
/*     */ 
/* 178 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 182 */         str1 = "select count(user.id) from User user where " + 
/* 183 */           str2;
/*     */       }
/*     */     }
/* 186 */     else str1 = "select count(user.id) from User user where " + str2;
/*     */ 
/* 189 */     str1 = str1 + " and user.activeFlag = ?";
/*     */ 
/* 191 */     Object localObject = str1;
/* 192 */     final Condition localCondition2 = localCondition1;
/* 193 */     int i = ((Integer)getHibernateTemplate().execute(
/* 194 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 197 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 198 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 199 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 200 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 202 */         if (localCondition2) {
/* 203 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 204 */             .getTime() - 
/* 205 */             paramInt * 60 * 1000));
/* 206 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 207 */             "locked");
/* 208 */           localQuery.setParameter(arrayOfObject.length + 2, Boolean.valueOf(true));
/*     */         } else {
/* 210 */           localQuery.setParameter(arrayOfObject.length, Boolean.valueOf(true));
/* 211 */         }return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*     */       }
/*     */     })).intValue();
/*     */ 
/* 214 */     return i;
/*     */   }
/*     */ 
/*     */   public List getUsers(final String paramString, final int paramInt1, final int paramInt2, final int paramInt3)
/*     */   {
/* 222 */     if ((paramString == null) && (paramString.length() == 0))
/* 223 */       return new ArrayList();
/* 224 */     String[] arrayOfString = paramString.split(",");
/* 225 */     String str1 = "";
/* 226 */     Condition localCondition1 = 0;
/* 227 */     String str2 = AdvanceQueryUtil.getHQLCondition("unitUser.user");
/* 228 */     str1 = "select count(*) from AccountPolicy ap";
/* 229 */     List localList1 = getHibernateTemplate().find(str1);
/* 230 */     if ((localList1 != null) && (((Long)localList1.get(0)).intValue() > 0)) {
/* 231 */       if (str2.indexOf("accountLocked") != -1) {
/* 232 */         localObject1 = 
/* 233 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 234 */         for (localObject2 = ((List)localObject1).iterator(); ((Iterator)localObject2).hasNext(); ) { localCondition2 = (Condition)((Iterator)localObject2).next();
/* 235 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 236 */             if (localCondition2.getValue().equals("true")) {
/* 237 */               localCondition1 = 1;
/* 238 */               str1 = "select distinct(unitUser.user) from UnitUser unitUser, AccountPolicy ap where (" + 
/* 239 */                 str2 + 
/* 240 */                 " ) or ( unitUser.user.account = ap.account and ap.loginTime > ? and ap.state = ? )";
/*     */ 
/* 238 */               break;
/*     */             }
/*     */ 
/* 242 */             str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 243 */               str2;
/*     */ 
/* 245 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 249 */         str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 250 */           str2;
/*     */       }
/*     */     }
/* 253 */     else str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 254 */         str2;
/*     */ 
/* 257 */     if ((paramString != null) && (paramString.length() > 0))
/* 258 */       str1 = str1 + " and unitUser.unit.id in (:unitIds)";
/* 259 */     Object localObject1 = str1;
/* 260 */     final Condition localCondition2 = localCondition1;
/* 261 */     Object localObject2 = arrayOfString;
/* 262 */     List localList2 = (List)getHibernateTemplate().execute(
/* 263 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 266 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 267 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 268 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 269 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 271 */         if (localCondition2) {
/* 272 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 273 */             .getTime() - 
/* 274 */             paramInt3 * 60 * 1000));
/* 275 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 276 */             "locked");
/*     */         }
/* 278 */         if ((paramString != null) && (paramString.length() > 0)) {
/* 279 */           localQuery.setParameterList("unitIds", this.val$unitIdArrFinal);
/*     */         }
/* 281 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 282 */         localQuery.setMaxResults(paramInt2);
/* 283 */         return localQuery.list();
/*     */       }
/*     */     });
/* 286 */     return localList2;
/*     */   }
/*     */ 
/*     */   public int getUsersNumber(final String paramString, final int paramInt)
/*     */   {
/* 293 */     String[] arrayOfString = paramString.split(",");
/* 294 */     String str1 = "";
/* 295 */     Condition localCondition1 = 0;
/* 296 */     String str2 = AdvanceQueryUtil.getHQLCondition("unitUser.user");
/* 297 */     str1 = "select count(*) from AccountPolicy ap";
/* 298 */     List localList = getHibernateTemplate().find(str1);
/* 299 */     if ((localList != null) && (((Long)localList.get(0)).intValue() > 0)) {
/* 300 */       if (str2.indexOf("accountLocked") != -1) {
/* 301 */         localObject1 = 
/* 302 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 303 */         for (localObject2 = ((List)localObject1).iterator(); ((Iterator)localObject2).hasNext(); ) { localCondition2 = (Condition)((Iterator)localObject2).next();
/* 304 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 305 */             if (localCondition2.getValue().equals("true")) {
/* 306 */               localCondition1 = 1;
/* 307 */               str1 = "select distinct(unitUser.user) from UnitUser unitUser, AccountPolicy ap where (" + 
/* 308 */                 str2 + 
/* 309 */                 " ) or ( unitUser.user.account = ap.account and ap.loginTime > ? and ap.state = ? )";
/*     */ 
/* 307 */               break;
/*     */             }
/*     */ 
/* 311 */             str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 312 */               str2;
/*     */ 
/* 314 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 318 */         str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 319 */           str2;
/*     */       }
/*     */     }
/* 322 */     else str1 = "select distinct(unitUser.user) from UnitUser unitUser where " + 
/* 323 */         str2;
/*     */ 
/* 326 */     if ((paramString != null) && (paramString.length() > 0)) {
/* 327 */       str1 = str1 + " and unitUser.unit.id in (:unitIds)";
/*     */     }
/* 329 */     Object localObject1 = str1;
/* 330 */     final Condition localCondition2 = localCondition1;
/* 331 */     Object localObject2 = arrayOfString;
/* 332 */     int i = ((Integer)getHibernateTemplate().execute(
/* 333 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 336 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 337 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 338 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 339 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/* 341 */         if (localCondition2) {
/* 342 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 343 */             .getTime() - 
/* 344 */             paramInt * 60 * 1000));
/* 345 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 346 */             "locked");
/*     */         }
/* 348 */         if ((paramString != null) && (paramString.length() > 0)) {
/* 349 */           localQuery.setParameterList("unitIds", this.val$unitIdArrFinal);
/*     */         }
/* 351 */         return Integer.valueOf(localQuery.list().size());
/*     */       }
/*     */     })).intValue();
/*     */ 
/* 354 */     return i;
/*     */   }
/*     */ 
/*     */   public List getActiveAccountPolicies(int paramInt)
/*     */   {
/* 526 */     String str = "from AccountPolicy accountPolicy where accountPolicy.loginTime > ? and accountPolicy.state in(?,?)";
/* 527 */     Object[] arrayOfObject = new Object[3];
/* 528 */     arrayOfObject[0] = new Timestamp(new Date().getTime() - paramInt * 60 * 
/* 529 */       1000);
/* 530 */     arrayOfObject[1] = "locked";
/* 531 */     arrayOfObject[2] = "locking";
/* 532 */     return queryObjects(str, arrayOfObject);
/*     */   }
/*     */ 
/*     */   public List getActiveAccountPolicies()
/*     */   {
/* 539 */     String str = "from AccountPolicy accountPolicy where accountPolicy.state in(?,?)";
/* 540 */     Object[] arrayOfObject = new Object[2];
/* 541 */     arrayOfObject[0] = "locked";
/* 542 */     arrayOfObject[1] = "locking";
/* 543 */     return queryObjects(str, arrayOfObject);
/*     */   }
/*     */ 
/*     */   public List<User> getManagedUsers(final String paramString, final int paramInt1, final int paramInt2, final int paramInt3)
/*     */   {
/* 552 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*     */ 
/* 555 */     List localList1 = getHibernateTemplate().find(str1, paramString);
/*     */ 
/* 560 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag =:activeFlag and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id = :adminRoleId) ";
/*     */ 
/* 562 */     final ArrayList localArrayList = new ArrayList();
/* 563 */     if (localList1.size() > 0) {
/* 564 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*     */ 
/* 568 */       for (int i = 0; i < localList1.size(); i++) {
/* 569 */         AdminRoleUnit localAdminRoleUnit = (AdminRoleUnit)localList1.get(i);
/* 570 */         if (localAdminRoleUnit.getIsCascade().booleanValue()) {
/* 571 */           localArrayList.add(localAdminRoleUnit.getDimensionUnit().getUnitPath() + localAdminRoleUnit.getDimensionUnit().getId());
/* 572 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*     */         }
/*     */       }
/* 575 */       str2 = str2 + ")";
/*     */     }
/* 577 */     str2 = str2 + "))";
/*     */ 
/* 579 */     Condition localCondition1 = 0;
/* 580 */     String str3 = AdvanceQueryUtil.getHQLCondition("user");
/* 581 */     str1 = "select count(*) from AccountPolicy ap";
/* 582 */     List localList2 = getHibernateTemplate().find(str1);
/* 583 */     if ((localList2 != null) && (((Long)localList2.get(0)).intValue() > 0)) {
/* 584 */       if (str3.indexOf("accountLocked") != -1) {
/* 585 */         localObject1 = 
/* 586 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 587 */         for (localObject2 = ((List)localObject1).iterator(); ((Iterator)localObject2).hasNext(); ) { localCondition2 = (Condition)((Iterator)localObject2).next();
/* 588 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 589 */             if (localCondition2.getValue().equals("true")) {
/* 590 */               localCondition1 = 1;
/* 591 */               str1 = "select distinct user from User user, AccountPolicy ap where (( " + 
/* 592 */                 str3 + 
/* 593 */                 " ) or ( user.account = ap.account and ap.loginTime > ? and ap.state = ? ))";
/*     */ 
/* 591 */               break;
/*     */             }
/*     */ 
/* 595 */             str1 = "from User user where " + str3;
/*     */ 
/* 597 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 601 */         str1 = "from User user where " + str3;
/*     */       }
/*     */     }
/* 604 */     else str1 = "from User user where " + str3;
/*     */ 
/* 607 */     str1 = str1 + " and (user.id in (";
/* 608 */     str1 = str1 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/* 609 */     str1 = str1 + ")";
/* 610 */     str1 = str1 + " or user.id in (";
/* 611 */     str1 = str1 + str2;
/* 612 */     str1 = str1 + "))";
/*     */ 
/* 614 */     str1 = str1 + " and user.activeFlag = :activeFlag";
/*     */ 
/* 616 */     Object localObject1 = str1;
/* 617 */     final Condition localCondition2 = localCondition1;
/* 618 */     Object localObject2 = (List)getHibernateTemplate().execute(
/* 619 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 622 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 623 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 624 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 625 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/*     */ 
/* 628 */         if (localCondition2) {
/* 629 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 630 */             .getTime() - 
/* 631 */             paramInt3 * 60 * 1000));
/* 632 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 633 */             "locked");
/*     */         }
/*     */ 
/* 636 */         localQuery.setParameter("adminRoleId", paramString);
/* 637 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/* 638 */         for (i = 0; i < localArrayList.size(); i++) {
/* 639 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*     */         }
/* 641 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 642 */         localQuery.setMaxResults(paramInt2);
/* 643 */         return localQuery.list();
/*     */       }
/*     */     });
/* 646 */     return localObject2;
/*     */   }
/*     */ 
/*     */   public int getManagedUsersNumber(final String paramString, final int paramInt)
/*     */   {
/* 654 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*     */ 
/* 657 */     List localList1 = getHibernateTemplate().find(str1, paramString);
/*     */ 
/* 662 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag =:activeFlag and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id = :adminRoleId) ";
/*     */ 
/* 664 */     final ArrayList localArrayList = new ArrayList();
/* 665 */     if (localList1.size() > 0) {
/* 666 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*     */ 
/* 670 */       for (int i = 0; i < localList1.size(); i++) {
/* 671 */         AdminRoleUnit localAdminRoleUnit = (AdminRoleUnit)localList1.get(i);
/* 672 */         if (localAdminRoleUnit.getIsCascade().booleanValue()) {
/* 673 */           localArrayList.add(localAdminRoleUnit.getDimensionUnit().getUnitPath() + localAdminRoleUnit.getDimensionUnit().getId());
/* 674 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*     */         }
/*     */       }
/* 677 */       str2 = str2 + ")";
/*     */     }
/* 679 */     str2 = str2 + "))";
/*     */ 
/* 681 */     Condition localCondition1 = 0;
/* 682 */     String str3 = AdvanceQueryUtil.getHQLCondition("user");
/* 683 */     str1 = "select count(*) from AccountPolicy ap";
/* 684 */     List localList2 = getHibernateTemplate().find(str1);
/* 685 */     if ((localList2 != null) && (((Long)localList2.get(0)).intValue() > 0)) {
/* 686 */       if (str3.indexOf("accountLocked") != -1) {
/* 687 */         localObject = 
/* 688 */           AdvanceQueryUtil.getQueryCondition().getConditions();
/* 689 */         for (Iterator localIterator = ((List)localObject).iterator(); localIterator.hasNext(); ) { localCondition2 = (Condition)localIterator.next();
/* 690 */           if (localCondition2.getColumn().equals("accountLocked")) {
/* 691 */             if (localCondition2.getValue().equals("true")) {
/* 692 */               localCondition1 = 1;
/* 693 */               str1 = "select count(distinct user) from User user, AccountPolicy ap where (( " + 
/* 694 */                 str3 + 
/* 695 */                 " ) or ( user.account = ap.account and ap.loginTime > ? and ap.state = ? ))";
/*     */ 
/* 693 */               break;
/*     */             }
/*     */ 
/* 697 */             str1 = "select count(distinct user) from User user where " + str3;
/*     */ 
/* 699 */             break;
/*     */           } }
/*     */       }
/*     */       else {
/* 703 */         str1 = "select count(distinct user) from User user where " + str3;
/*     */       }
/*     */     }
/* 706 */     else str1 = "select count(distinct user) from User user where " + str3;
/*     */ 
/* 709 */     str1 = str1 + " and (user.id in (";
/* 710 */     str1 = str1 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/* 711 */     str1 = str1 + ")";
/* 712 */     str1 = str1 + " or user.id in (";
/* 713 */     str1 = str1 + str2;
/* 714 */     str1 = str1 + "))";
/*     */ 
/* 716 */     str1 = str1 + " and user.activeFlag = :activeFlag";
/*     */ 
/* 718 */     Object localObject = str1;
/* 719 */     final Condition localCondition2 = localCondition1;
/* 720 */     int j = ((Integer)getHibernateTemplate().execute(
/* 721 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 724 */         Query localQuery = paramAnonymousSession.createQuery(this.val$hqlFinal);
/* 725 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 726 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 727 */           localQuery.setParameter(i, arrayOfObject[i]);
/*     */         }
/*     */ 
/* 730 */         if (localCondition2) {
/* 731 */           localQuery.setParameter(arrayOfObject.length, new Timestamp(new Date()
/* 732 */             .getTime() - 
/* 733 */             paramInt * 60 * 1000));
/* 734 */           localQuery.setParameter(arrayOfObject.length + 1, 
/* 735 */             "locked");
/*     */         }
/*     */ 
/* 738 */         localQuery.setParameter("adminRoleId", paramString);
/* 739 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/* 740 */         for (i = 0; i < localArrayList.size(); i++) {
/* 741 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*     */         }
/* 743 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*     */       }
/*     */     })).intValue();
/*     */ 
/* 746 */     return j;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.AccountPolicyDAOImpl
 * JD-Core Version:    0.6.2
 */