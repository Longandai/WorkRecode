/*     */ package com.neusoft.unieap.techcomp.security.dao.providers;
/*     */ 
/*     */ import com.neusoft.unieap.techcomp.org.bo.UserBO;
/*     */ import com.neusoft.unieap.techcomp.security.lock.LockUserListener;
/*     */ import java.util.Map;
/*     */ import org.springframework.context.support.MessageSourceAccessor;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.security.Authentication;
/*     */ import org.springframework.security.AuthenticationException;
/*     */ import org.springframework.security.AuthenticationServiceException;
/*     */ import org.springframework.security.BadCredentialsException;
/*     */ import org.springframework.security.LockedException;
/*     */ import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
/*     */ import org.springframework.security.providers.dao.AbstractUserDetailsAuthenticationProvider;
/*     */ import org.springframework.security.providers.dao.SaltSource;
/*     */ import org.springframework.security.providers.dao.UserCache;
/*     */ import org.springframework.security.providers.encoding.PasswordEncoder;
/*     */ import org.springframework.security.providers.encoding.PlaintextPasswordEncoder;
/*     */ import org.springframework.security.userdetails.UserDetails;
/*     */ import org.springframework.security.userdetails.UserDetailsChecker;
/*     */ import org.springframework.security.userdetails.UserDetailsService;
/*     */ import org.springframework.security.userdetails.UsernameNotFoundException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DaoAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider
/*     */ {
/*  50 */   private PasswordEncoder passwordEncoder = new PlaintextPasswordEncoder();
/*     */   private SaltSource saltSource;
/*     */   private UserDetailsService userDetailsService;
/*  56 */   private boolean includeDetailsObject = true;
/*     */   private LockUserListener lockUserListener;
/*     */   private UserBO userBO;
/*     */ 
/*     */   public void setLockUserListener(LockUserListener paramLockUserListener)
/*     */   {
/*  66 */     this.lockUserListener = paramLockUserListener;
/*     */   }
/*     */ 
/*     */   public LockUserListener getLockUserListener() {
/*  70 */     return this.lockUserListener;
/*     */   }
/*     */ 
/*     */   public void setUserBO(UserBO paramUserBO) {
/*  74 */     this.userBO = paramUserBO;
/*     */   }
/*     */ 
/*     */   public UserBO getUserBO() {
/*  78 */     return this.userBO;
/*     */   }
/*     */ 
/*     */   protected void additionalAuthenticationChecks(UserDetails paramUserDetails, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException
/*     */   {
/*  83 */     Object localObject = null;
/*     */ 
/*  85 */     if (this.saltSource != null) {
/*  86 */       localObject = this.saltSource.getSalt(paramUserDetails);
/*     */     }
/*     */ 
/*  89 */     if (paramUsernamePasswordAuthenticationToken.getCredentials() == null) {
/*  90 */       throw new BadCredentialsException(this.messages.getMessage(
/*  91 */         "AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"), 
/*  92 */         this.includeDetailsObject ? paramUserDetails : null);
/*     */     }
/*     */ 
/*  95 */     String str = paramUsernamePasswordAuthenticationToken.getCredentials().toString();
/*     */ 
/*  97 */     if (!this.passwordEncoder.isPasswordValid(paramUserDetails.getPassword(), str, localObject))
/*  98 */       throw new BadCredentialsException(this.messages.getMessage(
/*  99 */         "AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"), 
/* 100 */         this.includeDetailsObject ? paramUserDetails : null);
/*     */   }
/*     */ 
/*     */   protected void doAfterPropertiesSet() throws Exception
/*     */   {
/* 105 */     Assert.notNull(this.userDetailsService, "A UserDetailsService must be set");
/*     */   }
/*     */ 
/*     */   protected final UserDetails retrieveUser(String paramString, UsernamePasswordAuthenticationToken paramUsernamePasswordAuthenticationToken) throws AuthenticationException
/*     */   {
/*     */     UserDetails localUserDetails;
/*     */     try
/*     */     {
/* 113 */       localUserDetails = getUserDetailsService().loadUserByUsername(paramString);
/*     */     }
/*     */     catch (DataAccessException localDataAccessException) {
/* 116 */       throw new AuthenticationServiceException(localDataAccessException.getMessage(), localDataAccessException);
/*     */     }
/*     */ 
/* 119 */     if (localUserDetails == null) {
/* 120 */       throw new AuthenticationServiceException(
/* 121 */         "UserDetailsService returned null, which is an interface contract violation");
/*     */     }
/* 123 */     return localUserDetails;
/*     */   }
/*     */ 
/*     */   public void setPasswordEncoder(PasswordEncoder paramPasswordEncoder)
/*     */   {
/* 133 */     this.passwordEncoder = paramPasswordEncoder;
/*     */   }
/*     */ 
/*     */   protected PasswordEncoder getPasswordEncoder() {
/* 137 */     return this.passwordEncoder;
/*     */   }
/*     */ 
/*     */   public void setSaltSource(SaltSource paramSaltSource)
/*     */   {
/* 148 */     this.saltSource = paramSaltSource;
/*     */   }
/*     */ 
/*     */   protected SaltSource getSaltSource() {
/* 152 */     return this.saltSource;
/*     */   }
/*     */ 
/*     */   public void setUserDetailsService(UserDetailsService paramUserDetailsService) {
/* 156 */     this.userDetailsService = paramUserDetailsService;
/*     */   }
/*     */ 
/*     */   protected UserDetailsService getUserDetailsService() {
/* 160 */     return this.userDetailsService;
/*     */   }
/*     */ 
/*     */   protected boolean isIncludeDetailsObject() {
/* 164 */     return this.includeDetailsObject;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setIncludeDetailsObject(boolean paramBoolean)
/*     */   {
/* 175 */     this.includeDetailsObject = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Authentication authenticate(Authentication paramAuthentication)
/*     */     throws AuthenticationException
/*     */   {
/* 182 */     Assert.isInstanceOf(UsernamePasswordAuthenticationToken.class, paramAuthentication, 
/* 183 */       this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.onlySupports", 
/* 184 */       "Only UsernamePasswordAuthenticationToken is supported"));
/*     */ 
/* 187 */     String str1 = paramAuthentication.getPrincipal() == null ? "NONE_PROVIDED" : paramAuthentication.getName();
/*     */ 
/* 189 */     int i = 1;
/*     */ 
/* 191 */     UserDetails localUserDetails = super.getUserCache().getUserFromCache(str1);
/*     */ 
/* 193 */     if (localUserDetails == null) {
/* 194 */       i = 0;
/*     */       try
/*     */       {
/* 197 */         localUserDetails = retrieveUser(str1, (UsernamePasswordAuthenticationToken)paramAuthentication);
/*     */       } catch (UsernameNotFoundException localUsernameNotFoundException) {
/* 199 */         if (this.hideUserNotFoundExceptions) {
/* 200 */           throw new BadCredentialsException(this.messages.getMessage(
/* 201 */             "AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
/*     */         }
/* 203 */         throw localUsernameNotFoundException;
/*     */       }
/*     */ 
/* 207 */       Assert.notNull(localUserDetails, "retrieveUser returned null - a violation of the interface contract");
/*     */     }
/*     */ 
/* 210 */     super.getPreAuthenticationChecks().check(localUserDetails);
/*     */     try
/*     */     {
/* 213 */       additionalAuthenticationChecks(localUserDetails, (UsernamePasswordAuthenticationToken)paramAuthentication);
/*     */     } catch (AuthenticationException localAuthenticationException) {
/* 215 */       if (i != 0)
/*     */       {
/* 218 */         i = 0;
/* 219 */         localUserDetails = retrieveUser(str1, (UsernamePasswordAuthenticationToken)paramAuthentication);
/* 220 */         additionalAuthenticationChecks(localUserDetails, (UsernamePasswordAuthenticationToken)paramAuthentication);
/*     */       }
/*     */       else {
/* 223 */         if ((this.lockUserListener != null) && 
/* 224 */           (this.lockUserListener.isLock()) && (this.lockUserListener.getLockNumber() > 0)) {
/* 225 */           String str2 = localUserDetails.getUsername();
/* 226 */           Map localMap = this.lockUserListener.getUserFailLoginList();
/* 227 */           Integer localInteger = (Integer)localMap.get(str2);
/*     */ 
/* 229 */           if (((localInteger != null) && (localInteger.intValue() >= this.lockUserListener.getLockNumber() - 1)) || (this.lockUserListener.getLockNumber() == 1)) {
/* 230 */             this.userBO.updateUserLockState(str2, true);
/* 231 */             this.lockUserListener.cleanCount(str2);
/*     */ 
/* 233 */             throw new LockedException(this.messages.getMessage("AbstractUserDetailsAuthenticationProvider.locked", 
/* 234 */               "User account is locked"), localUserDetails);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 239 */         throw localAuthenticationException;
/*     */       }
/*     */     }
/*     */ 
/* 243 */     super.getPostAuthenticationChecks().check(localUserDetails);
/*     */ 
/* 245 */     if (i == 0) {
/* 246 */       super.getUserCache().putUserInCache(localUserDetails);
/*     */     }
/*     */ 
/* 249 */     Object localObject = localUserDetails;
/*     */ 
/* 251 */     if (super.isForcePrincipalAsString()) {
/* 252 */       localObject = localUserDetails.getUsername();
/*     */     }
/*     */ 
/* 255 */     return createSuccessAuthentication(localObject, paramAuthentication, localUserDetails);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.DaoAuthenticationProvider
 * JD-Core Version:    0.6.2
 */