/*     */ package com.neusoft.unieap.techcomp.security.dao.providers;
/*     */ 
/*     */ import java.util.SortedSet;
/*     */ import java.util.TreeSet;
/*     */ import org.springframework.security.GrantedAuthority;
/*     */ import org.springframework.security.userdetails.UserDetails;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SecurityUser
/*     */   implements UserDetails
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String password;
/*     */   private String username;
/*     */   private GrantedAuthority[] authorities;
/*     */   private boolean accountNonExpired;
/*     */   private boolean accountNonLocked;
/*     */   private boolean credentialsNonExpired;
/*     */   private boolean enabled;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SecurityUser(String paramString1, String paramString2, boolean paramBoolean, GrantedAuthority[] paramArrayOfGrantedAuthority)
/*     */     throws IllegalArgumentException
/*     */   {
/*  71 */     this(paramString1, paramString2, paramBoolean, true, true, paramArrayOfGrantedAuthority);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SecurityUser(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, GrantedAuthority[] paramArrayOfGrantedAuthority)
/*     */     throws IllegalArgumentException
/*     */   {
/* 101 */     this(paramString1, paramString2, paramBoolean1, paramBoolean2, paramBoolean3, true, paramArrayOfGrantedAuthority);
/*     */   }
/*     */ 
/*     */   public SecurityUser(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, GrantedAuthority[] paramArrayOfGrantedAuthority)
/*     */     throws IllegalArgumentException
/*     */   {
/* 130 */     if ((paramString1 == null) || ("".equals(paramString1)) || (paramString2 == null)) {
/* 131 */       throw new IllegalArgumentException("Cannot pass null or empty values to constructor");
/*     */     }
/*     */ 
/* 134 */     this.username = paramString1;
/* 135 */     this.password = paramString2;
/* 136 */     this.enabled = paramBoolean1;
/* 137 */     this.accountNonExpired = paramBoolean2;
/* 138 */     this.credentialsNonExpired = paramBoolean3;
/* 139 */     this.accountNonLocked = paramBoolean4;
/* 140 */     setAuthorities(paramArrayOfGrantedAuthority);
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject)
/*     */   {
/* 146 */     if ((!(paramObject instanceof SecurityUser)) || (paramObject == null)) {
/* 147 */       return false;
/*     */     }
/*     */ 
/* 150 */     SecurityUser localSecurityUser = (SecurityUser)paramObject;
/*     */ 
/* 154 */     if (localSecurityUser.getAuthorities().length != getAuthorities().length) {
/* 155 */       return false;
/*     */     }
/*     */ 
/* 158 */     for (int i = 0; i < getAuthorities().length; i++) {
/* 159 */       if (!getAuthorities()[i].equals(localSecurityUser.getAuthorities()[i])) {
/* 160 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 169 */     return (getPassword().equals(localSecurityUser.getPassword())) && (getUsername().equals(localSecurityUser.getUsername())) && 
/* 166 */       (isAccountNonExpired() == localSecurityUser.isAccountNonExpired()) && 
/* 167 */       (isAccountNonLocked() == localSecurityUser.isAccountNonLocked()) && 
/* 168 */       (isCredentialsNonExpired() == localSecurityUser.isCredentialsNonExpired()) && 
/* 169 */       (isEnabled() == localSecurityUser.isEnabled());
/*     */   }
/*     */ 
/*     */   public GrantedAuthority[] getAuthorities() {
/* 173 */     return this.authorities;
/*     */   }
/*     */ 
/*     */   public String getPassword() {
/* 177 */     return this.password;
/*     */   }
/*     */ 
/*     */   public String getUsername() {
/* 181 */     return this.username;
/*     */   }
/*     */ 
/*     */   public int hashCode() {
/* 185 */     int i = 9792;
/*     */ 
/* 187 */     if (getAuthorities() != null) {
/* 188 */       for (int j = 0; j < getAuthorities().length; j++) {
/* 189 */         i *= getAuthorities()[j].hashCode() % 7;
/*     */       }
/*     */     }
/*     */ 
/* 193 */     if (getPassword() != null) {
/* 194 */       i *= getPassword().hashCode() % 7;
/*     */     }
/*     */ 
/* 197 */     if (getUsername() != null) {
/* 198 */       i *= getUsername().hashCode() % 7;
/*     */     }
/*     */ 
/* 201 */     if (isAccountNonExpired()) {
/* 202 */       i *= -2;
/*     */     }
/*     */ 
/* 205 */     if (isAccountNonLocked()) {
/* 206 */       i *= -3;
/*     */     }
/*     */ 
/* 209 */     if (isCredentialsNonExpired()) {
/* 210 */       i *= -5;
/*     */     }
/*     */ 
/* 213 */     if (isEnabled()) {
/* 214 */       i *= -7;
/*     */     }
/*     */ 
/* 217 */     return i;
/*     */   }
/*     */ 
/*     */   public boolean isAccountNonExpired() {
/* 221 */     return this.accountNonExpired;
/*     */   }
/*     */ 
/*     */   public boolean isAccountNonLocked() {
/* 225 */     return this.accountNonLocked;
/*     */   }
/*     */ 
/*     */   public boolean isCredentialsNonExpired() {
/* 229 */     return this.credentialsNonExpired;
/*     */   }
/*     */ 
/*     */   public boolean isEnabled() {
/* 233 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   protected void setAuthorities(GrantedAuthority[] paramArrayOfGrantedAuthority) {
/* 237 */     Assert.notNull(paramArrayOfGrantedAuthority, "Cannot pass a null GrantedAuthority array");
/*     */ 
/* 239 */     TreeSet localTreeSet = new TreeSet();
/* 240 */     for (int i = 0; i < paramArrayOfGrantedAuthority.length; i++) {
/* 241 */       Assert.notNull(paramArrayOfGrantedAuthority[i], 
/* 242 */         "Granted authority element " + i + " is null - GrantedAuthority[] cannot contain any null elements");
/* 243 */       localTreeSet.add(paramArrayOfGrantedAuthority[i]);
/*     */     }
/*     */ 
/* 246 */     this.authorities = ((GrantedAuthority[])localTreeSet.toArray(new GrantedAuthority[localTreeSet.size()]));
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 250 */     StringBuffer localStringBuffer = new StringBuffer();
/* 251 */     localStringBuffer.append(super.toString()).append(": ");
/* 252 */     localStringBuffer.append("Username: ").append(this.username).append("; ");
/* 253 */     localStringBuffer.append("Password: [PROTECTED]; ");
/* 254 */     localStringBuffer.append("Enabled: ").append(this.enabled).append("; ");
/* 255 */     localStringBuffer.append("AccountNonExpired: ").append(this.accountNonExpired).append("; ");
/* 256 */     localStringBuffer.append("credentialsNonExpired: ").append(this.credentialsNonExpired).append("; ");
/* 257 */     localStringBuffer.append("AccountNonLocked: ").append(this.accountNonLocked).append("; ");
/*     */ 
/* 259 */     if (getAuthorities() != null) {
/* 260 */       localStringBuffer.append("Granted Authorities: ");
/*     */ 
/* 262 */       for (int i = 0; i < getAuthorities().length; i++) {
/* 263 */         if (i > 0) {
/* 264 */           localStringBuffer.append(", ");
/*     */         }
/*     */ 
/* 267 */         localStringBuffer.append(getAuthorities()[i].toString());
/*     */       }
/*     */     } else {
/* 270 */       localStringBuffer.append("Not granted any authorities");
/*     */     }
/*     */ 
/* 273 */     return localStringBuffer.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.SecurityUser
 * JD-Core Version:    0.6.2
 */