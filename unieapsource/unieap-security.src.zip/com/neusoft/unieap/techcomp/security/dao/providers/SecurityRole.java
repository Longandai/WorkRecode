package com.neusoft.unieap.techcomp.security.dao.providers;

import org.springframework.security.GrantedAuthority;

public abstract interface SecurityRole extends GrantedAuthority
{
  public abstract String getAuthority();
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.providers.SecurityRole
 * JD-Core Version:    0.6.2
 */