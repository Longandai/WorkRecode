package com.neusoft.unieap.techcomp.security.dao;

import com.neusoft.unieap.techcomp.security.entity.OnlineUser;
import java.util.List;

public abstract interface OnlineUserDAO
{
  public abstract void saveOnlineUser(OnlineUser paramOnlineUser);

  public abstract void updateOnlineUser(OnlineUser paramOnlineUser);

  public abstract void deleteOnlineUserBySessionId(String paramString);

  public abstract void deleteOnlineUsersByUserId(String paramString);

  public abstract void deleteOnlineUsersByServerIp(String paramString);

  public abstract List getAllOnlineUsers(int paramInt1, int paramInt2);

  public abstract int getAllOnlineUsersNumber();

  public abstract List getOnlineUsers(int paramInt1, int paramInt2);

  public abstract int getOnlineUsersNumber();
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.OnlineUserDAO
 * JD-Core Version:    0.6.2
 */