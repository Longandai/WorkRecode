/*      */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*      */ 
/*      */ import com.neusoft.unieap.core.annotation.ModelFile;
/*      */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*      */ import com.neusoft.unieap.techcomp.org.entity.AdminRoleUnit;
/*      */ import com.neusoft.unieap.techcomp.org.entity.DimensionUnit;
/*      */ import com.neusoft.unieap.techcomp.org.entity.User;
/*      */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*      */ import com.neusoft.unieap.techcomp.security.dao.BusiRoleDAO;
/*      */ import com.neusoft.unieap.techcomp.security.entity.BusiRole;
/*      */ import com.neusoft.unieap.techcomp.security.entity.BusiRoleUser;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import org.hibernate.HibernateException;
/*      */ import org.hibernate.Query;
/*      */ import org.hibernate.Session;
/*      */ import org.springframework.orm.hibernate3.HibernateCallback;
/*      */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*      */ 
/*      */ @ModelFile("busiRoleDAO.dao")
/*      */ public class BusiRoleDAOImpl extends BaseHibernateDAO
/*      */   implements BusiRoleDAO
/*      */ {
/*      */   public List getAllBusiRoles(int paramInt1, int paramInt2)
/*      */   {
/*   35 */     String str1 = "from BusiRole busiRole where ";
/*      */ 
/*   37 */     String str2 = AdvanceQueryUtil.getHQLCondition("busiRole");
/*   38 */     Object[] arrayOfObject1 = AdvanceQueryUtil.getHQLConditionValues();
/*   39 */     str1 = str1 + str2;
/*   40 */     str1 = str1 + " order by busiRole.name";
/*   41 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length];
/*   42 */     for (int i = 0; i < arrayOfObject2.length; i++) {
/*   43 */       arrayOfObject2[i] = arrayOfObject1[i];
/*      */     }
/*   45 */     return queryObjects(str1, arrayOfObject2, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public int getAllBusiRolesNumber()
/*      */   {
/*   52 */     String str = "select count(busiRole.id) from BusiRole busiRole";
/*   53 */     return Integer.parseInt(getHibernateTemplate().find(str).get(0)
/*   54 */       .toString());
/*      */   }
/*      */ 
/*      */   public List getAllBusiRolesBySecurityRoleId(String paramString, int paramInt1, int paramInt2)
/*      */   {
/*   62 */     String str1 = "select adminRoleBusiRole.busiRole from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ? and ";
/*      */ 
/*   65 */     String str2 = 
/*   66 */       AdvanceQueryUtil.getHQLCondition("adminRoleBusiRole.busiRole");
/*   67 */     Object[] arrayOfObject1 = AdvanceQueryUtil.getHQLConditionValues();
/*   68 */     str1 = str1 + str2;
/*   69 */     str1 = str1 + " order by busiRole.name";
/*   70 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/*   71 */     arrayOfObject2[0] = paramString;
/*   72 */     for (int i = 1; i < arrayOfObject2.length; i++) {
/*   73 */       arrayOfObject2[i] = arrayOfObject1[(i - 1)];
/*      */     }
/*   75 */     return queryObjects(str1, arrayOfObject2, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public int getAllBusiRolesNumberBySecurityRoleId(String paramString)
/*      */   {
/*   82 */     String str = "select count(adminRoleBusiRole.busiRole.id) from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ? ";
/*      */ 
/*   85 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*   86 */       paramString).get(0).toString());
/*      */   }
/*      */ 
/*      */   public List getAllBusiRolesExceptUserId(String paramString, int paramInt1, int paramInt2)
/*      */   {
/*   93 */     String str = "from BusiRole busiRole where busiRole.id not in( select busiRoleUser.role.id from BusiRoleUser busiRoleUser where busiRoleUser.user.id = ? )";
/*      */ 
/*   98 */     str = str + " order by busiRole.name";
/*   99 */     return queryObjects(str, new Object[] { paramString }, paramInt1, 
/*  100 */       paramInt2);
/*      */   }
/*      */ 
/*      */   public int getAllBusiRolesNumberExceptUserId(String paramString)
/*      */   {
/*  107 */     String str = "select count(busiRole.id) from BusiRole busiRole where busiRole.id not in( select busiRoleUser.role.id from BusiRoleUser busiRoleUser where busiRoleUser.user.id = ? )";
/*      */ 
/*  112 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*  113 */       new Object[] { paramString }).get(0).toString());
/*      */   }
/*      */ 
/*      */   public boolean isNameAlreadyExist(String paramString)
/*      */   {
/*  120 */     String str = "from BusiRole busiRole where busiRole.name = ?";
/*  121 */     if (getHibernateTemplate().find(str, paramString).size() > 0) {
/*  122 */       return true;
/*      */     }
/*  124 */     return false;
/*      */   }
/*      */ 
/*      */   public BusiRole saveBusiRole(BusiRole paramBusiRole)
/*      */   {
/*  132 */     getHibernateTemplate().save(paramBusiRole);
/*  133 */     return paramBusiRole;
/*      */   }
/*      */ 
/*      */   public BusiRole updateBusiRole(BusiRole paramBusiRole)
/*      */   {
/*  140 */     getHibernateTemplate().update(paramBusiRole);
/*  141 */     return paramBusiRole;
/*      */   }
/*      */ 
/*      */   public void deleteAdminRoleBusiRoleByBusiRoleId(String paramString)
/*      */   {
/*  148 */     String str = "delete from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.busiRole.id = ?";
/*      */ 
/*  150 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*      */   }
/*      */ 
/*      */   public void deleteBusiRoleUserByBusiRoleId(String paramString)
/*      */   {
/*  157 */     String str = "delete from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ?";
/*      */ 
/*  159 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*      */   }
/*      */ 
/*      */   public void deleteBusiRoleById(String paramString)
/*      */   {
/*  166 */     String str = "delete from BusiRole busiRole where busiRole.id = ?";
/*  167 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*      */   }
/*      */ 
/*      */   public BusiRoleUser saveBusiRoleUser(BusiRoleUser paramBusiRoleUser)
/*      */   {
/*  175 */     getHibernateTemplate().save(paramBusiRoleUser);
/*  176 */     return paramBusiRoleUser;
/*      */   }
/*      */ 
/*      */   public void deleteBusiRoleUser(String paramString1, String paramString2)
/*      */   {
/*  184 */     String str = "delete from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ? and busiRoleUser.user.id = ?";
/*      */ 
/*  187 */     getHibernateTemplate().bulkUpdate(str, 
/*  188 */       new Object[] { paramString1, paramString2 });
/*      */   }
/*      */ 
/*      */   public BusiRole getBusiRoleById(String paramString) {
/*  192 */     return (BusiRole)getHibernateTemplate().get(BusiRole.class, 
/*  193 */       paramString);
/*      */   }
/*      */ 
/*      */   public List getBusiRolesByUserId(String paramString)
/*      */   {
/*  200 */     String str = "select busiRoleUser.role from BusiRoleUser busiRoleUser where busiRoleUser.user.id = ?";
/*      */ 
/*  202 */     return getHibernateTemplate().find(str, paramString);
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleId(String paramString)
/*      */   {
/*  209 */     String str = "select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ?";
/*  210 */     return getHibernateTemplate().find(str, paramString);
/*      */   }
/*      */ 
/*      */   public void deleteBusiRoleUserByUserId(String paramString)
/*      */   {
/*  217 */     String str = "delete BusiRoleUser busiRoleUser where busiRoleUser.user.id = ?";
/*  218 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleId(String paramString, int paramInt1, int paramInt2)
/*      */   {
/*  226 */     String str = "select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ?";
/*      */ 
/*  229 */     return queryObjects(str, new Object[] { paramString }, paramInt1, 
/*  230 */       paramInt2);
/*      */   }
/*      */ 
/*      */   public int getUsersByBusiRoleIdNumber(String paramString)
/*      */   {
/*  237 */     String str = "select count(busiRoleUser.user.id) from BusiRoleUser busiRoleUser,User user where busiRoleUser.role.id = ? and user.id = busiRoleUser.user.id";
/*      */ 
/*  241 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*  242 */       paramString).get(0).toString());
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleId(final String paramString1, final String paramString2, final int paramInt1, final int paramInt2)
/*      */   {
/*  252 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  255 */     List localList1 = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  260 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where unitUser2.user.activeFlag = :activeFlag and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id =:adminRoleId) ";
/*      */ 
/*  262 */     final ArrayList localArrayList = new ArrayList();
/*  263 */     if (localList1.size() > 0) {
/*  264 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  266 */       for (int i = 0; i < localList1.size(); i++) {
/*  267 */         localObject = (AdminRoleUnit)localList1.get(i);
/*      */ 
/*  269 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  270 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  271 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*      */         }
/*      */       }
/*  274 */       str2 = str2 + ")";
/*      */     }
/*  276 */     str2 = str2 + ")";
/*      */ 
/*  278 */     Object localObject = str2;
/*      */ 
/*  280 */     List localList2 = (List)getHibernateTemplate().execute(
/*  281 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/*  285 */         String str = "select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = :busiRoleId and (";
/*      */ 
/*  288 */         str = str + " busiRoleUser.user.id in (";
/*  289 */         str = str + this.val$hql3;
/*  290 */         str = str + ") or busiRoleUser.user.id in(";
/*  291 */         str = str + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  292 */         str = str + "))";
/*  293 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*      */ 
/*  295 */         localQuery.setParameter("busiRoleId", paramString2);
/*  296 */         localQuery.setParameter("adminRoleId", paramString1);
/*  297 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/*      */ 
/*  299 */         for (int i = 0; i < localArrayList.size(); i++) {
/*  300 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*      */         }
/*      */ 
/*  303 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  304 */         localQuery.setMaxResults(paramInt2);
/*  305 */         return localQuery.list();
/*      */       }
/*      */     });
/*  308 */     return localList2;
/*      */   }
/*      */ 
/*      */   public int getUsersByBusiRoleIdNumber(final String paramString1, final String paramString2)
/*      */   {
/*  318 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  321 */     List localList = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  326 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where unitUser2.user.activeFlag = :activeFlag and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id =:adminRoleId) ";
/*      */ 
/*  328 */     final ArrayList localArrayList = new ArrayList();
/*  329 */     if (localList.size() > 0) {
/*  330 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  332 */       for (i = 0; i < localList.size(); i++) {
/*  333 */         localObject = (AdminRoleUnit)localList.get(i);
/*      */ 
/*  335 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  336 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  337 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*      */         }
/*      */       }
/*  340 */       str2 = str2 + ")";
/*      */     }
/*  342 */     str2 = str2 + ")";
/*      */ 
/*  344 */     Object localObject = str2;
/*      */ 
/*  346 */     int i = ((Integer)getHibernateTemplate().execute(
/*  347 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/*  351 */         String str = "select count(busiRoleUser.user.id) from BusiRoleUser busiRoleUser where busiRoleUser.role.id = :busiRoleId and (";
/*      */ 
/*  354 */         str = str + " busiRoleUser.user.id in (";
/*  355 */         str = str + this.val$hql3;
/*  356 */         str = str + ") or busiRoleUser.user.id in(";
/*  357 */         str = str + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  358 */         str = str + "))";
/*  359 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*      */ 
/*  361 */         localQuery.setParameter("busiRoleId", paramString2);
/*  362 */         localQuery.setParameter("adminRoleId", paramString1);
/*  363 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/*      */ 
/*  365 */         for (int i = 0; i < localArrayList.size(); i++) {
/*  366 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*      */         }
/*      */ 
/*  369 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  372 */     return i;
/*      */   }
/*      */ 
/*      */   public List getUsersByUnitIdExceptedBusiRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2)
/*      */   {
/*  381 */     String str = "select unitUser.user from UnitUser unitUser where unitUser.unit.id = ? and unitUser.user not in ( select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ? )";
/*      */ 
/*  386 */     return queryObjects(str, new Object[] { paramString1, paramString2 }, 
/*  387 */       paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public int getUsersNumberByUnitIdExceptedBusiRoleId(String paramString1, String paramString2)
/*      */   {
/*  395 */     String str = "select count(unitUser.user.id) from UnitUser unitUser where unitUser.unit.id = ? and unitUser.user not in ( select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ? )";
/*      */ 
/*  400 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*  401 */       new Object[] { paramString1, paramString2 }).get(0).toString());
/*      */   }
/*      */ 
/*      */   public List<User> getUsersExceptedBusiRoleIdWithAdvanceQuery(final String paramString, final int paramInt1, final int paramInt2)
/*      */   {
/*  454 */     List localList = (List)getHibernateTemplate().execute(
/*  455 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  458 */         String str = "from User user where user.id not in (select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ?) and " + 
/*  461 */           AdvanceQueryUtil.getHQLCondition("user") + 
/*  462 */           " and user.activeFlag = ?";
/*  463 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  464 */         localQuery.setParameter(0, paramString);
/*  465 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/*  466 */         for (int i = 0; i < arrayOfObject.length; i++) {
/*  467 */           localQuery.setParameter(i + 1, arrayOfObject[i]);
/*      */         }
/*  469 */         localQuery.setParameter(arrayOfObject.length + 1, Boolean.valueOf(true));
/*  470 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  471 */         localQuery.setMaxResults(paramInt2);
/*  472 */         return localQuery.list();
/*      */       }
/*      */     });
/*  475 */     return localList;
/*      */   }
/*      */ 
/*      */   public int getUsersNumberExceptedBusiRoleIdWithAdvanceQuery(final String paramString)
/*      */   {
/*  483 */     int i = ((Integer)getHibernateTemplate().execute(
/*  484 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  487 */         String str = "select count(user.id) from User user where user.id not in (select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ?) and " + 
/*  491 */           AdvanceQueryUtil.getHQLCondition("user") + 
/*  492 */           " and user.activeFlag = ?";
/*  493 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  494 */         localQuery.setParameter(0, paramString);
/*  495 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/*  496 */         for (int i = 0; i < arrayOfObject.length; i++) {
/*  497 */           localQuery.setParameter(i + 1, arrayOfObject[i]);
/*      */         }
/*  499 */         localQuery.setParameter(arrayOfObject.length + 1, Boolean.valueOf(true));
/*  500 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  503 */     return i;
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleIds(final List paramList, final int paramInt1, final int paramInt2)
/*      */   {
/*  603 */     if ((paramList == null) || (paramList.size() == 0))
/*  604 */       return new ArrayList();
/*  605 */     List localList = (List)getHibernateTemplate().execute(
/*  606 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  609 */         String str = "select distinct(busiRoleUser.user) from BusiRoleUser busiRoleUser where busiRoleUser.role.id in(:busiRoleIds)";
/*  610 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  611 */         localQuery.setParameterList("busiRoleIds", paramList);
/*  612 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  613 */         localQuery.setMaxResults(paramInt2);
/*  614 */         return localQuery.list();
/*      */       }
/*      */     });
/*  617 */     return localList;
/*      */   }
/*      */ 
/*      */   public int getUsersNumberByBusiRoleIds(final List paramList)
/*      */   {
/*  624 */     if ((paramList == null) || (paramList.size() == 0))
/*  625 */       return 0;
/*  626 */     int i = ((Integer)getHibernateTemplate().execute(
/*  627 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  630 */         String str = "select count(distinct busiRoleUser.user.id) from BusiRoleUser busiRoleUser where busiRoleUser.role.id in(:busiRoleIds)";
/*  631 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  632 */         localQuery.setParameterList("busiRoleIds", paramList);
/*  633 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  636 */     return i;
/*      */   }
/*      */ 
/*      */   public List getMixedUsers(final List paramList1, final List paramList2, final int paramInt1, final int paramInt2)
/*      */   {
/*  643 */     if ((paramList2 == null) || (paramList2.size() == 0))
/*  644 */       return new ArrayList();
/*  645 */     List localList = (List)getHibernateTemplate().execute(
/*  646 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  649 */         String str1 = "from User user where user.id in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id in (:resourceBusiRoleIds))";
/*  650 */         str1 = str1 + " and (user.id in(";
/*      */ 
/*  657 */         String str2 = "select user.id from User user where ";
/*  658 */         if ((paramList1 == null) || (paramList1.size() == 0)) {
/*  659 */           str2 = str2 + "user.id in (";
/*  660 */           str2 = str2 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  661 */           str2 = str2 + ")";
/*      */         }
/*      */         else {
/*  664 */           str2 = str2 + " user.id in (";
/*  665 */           str2 = str2 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  666 */           str2 = str2 + ")";
/*  667 */           str2 = str2 + " or user.id in (";
/*  668 */           str2 = str2 + "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag = :activeFlag and unitUser2.unit.id in (:unitIds)) ";
/*  669 */           str2 = str2 + ")";
/*      */         }
/*  671 */         str1 = str1 + str2 + "))";
/*      */ 
/*  673 */         Query localQuery = paramAnonymousSession.createQuery(str1);
/*  674 */         localQuery.setParameterList("resourceBusiRoleIds", paramList2);
/*  675 */         localQuery.setParameterList("unitIds", paramList1);
/*  676 */         localQuery.setBoolean("activeFlag", true);
/*  677 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  678 */         localQuery.setMaxResults(paramInt2);
/*  679 */         return localQuery.list();
/*      */       }
/*      */     });
/*  682 */     return localList;
/*      */   }
/*      */ 
/*      */   public int getMixedUsersNumber(final List paramList1, final List paramList2)
/*      */   {
/*  689 */     if ((paramList2 == null) || (paramList2.size() == 0))
/*  690 */       return 0;
/*  691 */     int i = ((Integer)getHibernateTemplate().execute(
/*  692 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/*  695 */         String str1 = "select count(user.id) from User user where user.id in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id in (:resourceBusiRoleIds))";
/*  696 */         str1 = str1 + " and (user.id in(";
/*      */ 
/*  703 */         String str2 = "select user.id from User user where ";
/*  704 */         if ((paramList1 == null) || (paramList1.size() == 0)) {
/*  705 */           str2 = str2 + "user.id in (";
/*  706 */           str2 = str2 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  707 */           str2 = str2 + ")";
/*      */         }
/*      */         else {
/*  710 */           str2 = str2 + " user.id in (";
/*  711 */           str2 = str2 + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.activeFlag=:activeFlag";
/*  712 */           str2 = str2 + ")";
/*  713 */           str2 = str2 + " or user.id in (";
/*  714 */           str2 = str2 + "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag = :activeFlag and unitUser2.unit.id in (:unitIds)) ";
/*  715 */           str2 = str2 + ")";
/*      */         }
/*  717 */         str1 = str1 + str2 + "))";
/*      */ 
/*  719 */         Query localQuery = paramAnonymousSession.createQuery(str1);
/*  720 */         localQuery.setParameterList("resourceBusiRoleIds", paramList2);
/*  721 */         localQuery.setParameterList("unitIds", paramList1);
/*  722 */         localQuery.setBoolean("activeFlag", true);
/*  723 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  726 */     return i;
/*      */   }
/*      */ 
/*      */   public List getManagedUsersExceptBusiRoleId(final String paramString1, final String paramString2, final int paramInt1, final int paramInt2)
/*      */   {
/*  734 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  737 */     List localList1 = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  742 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag = :activeFlag and unitUser2.user.id not in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id=:busiRoleId) and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id =:adminRoleId) ";
/*      */ 
/*  744 */     final ArrayList localArrayList = new ArrayList();
/*  745 */     if (localList1.size() > 0) {
/*  746 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  748 */       for (int i = 0; i < localList1.size(); i++) {
/*  749 */         localObject = (AdminRoleUnit)localList1.get(i);
/*      */ 
/*  751 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  752 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  753 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*      */         }
/*      */       }
/*  756 */       str2 = str2 + ")";
/*      */     }
/*  758 */     str2 = str2 + "))";
/*      */ 
/*  760 */     Object localObject = str2;
/*      */ 
/*  762 */     List localList2 = (List)getHibernateTemplate().execute(
/*  763 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/*  767 */         String str = "from User user where " + 
/*  768 */           AdvanceQueryUtil.getHQLCondition("user");
/*      */ 
/*  770 */         str = str + " and (user.id in (";
/*  771 */         str = str + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.id not in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id=:busiRoleId) and user1.activeFlag=:activeFlag";
/*  772 */         str = str + ")";
/*  773 */         str = str + " or user.id in (";
/*  774 */         str = str + this.val$hql3;
/*  775 */         str = str + "))";
/*  776 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  777 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/*  778 */         for (int i = 0; i < arrayOfObject.length; i++) {
/*  779 */           localQuery.setParameter(i, arrayOfObject[i]);
/*      */         }
/*      */ 
/*  782 */         localQuery.setParameter("adminRoleId", paramString1);
/*  783 */         localQuery.setParameter("busiRoleId", paramString2);
/*  784 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/*      */ 
/*  786 */         for (i = 0; i < localArrayList.size(); i++) {
/*  787 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*      */         }
/*      */ 
/*  790 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/*  791 */         localQuery.setMaxResults(paramInt2);
/*  792 */         return localQuery.list();
/*      */       }
/*      */     });
/*  795 */     return localList2;
/*      */   }
/*      */ 
/*      */   public int getManagedUsersNumberExceptBusiRoleId(final String paramString1, final String paramString2)
/*      */   {
/*  803 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  806 */     List localList = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  811 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where (unitUser2.user.activeFlag = :activeFlag and unitUser2.user.id not in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id=:busiRoleId) and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id =:adminRoleId) ";
/*      */ 
/*  813 */     final ArrayList localArrayList = new ArrayList();
/*  814 */     if (localList.size() > 0) {
/*  815 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  817 */       for (i = 0; i < localList.size(); i++) {
/*  818 */         localObject = (AdminRoleUnit)localList.get(i);
/*      */ 
/*  820 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  821 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  822 */           str2 = str2 + " or dimensionUnit.unitPath like :unitPath" + (localArrayList.size() - 1);
/*      */         }
/*      */       }
/*  825 */       str2 = str2 + ")";
/*      */     }
/*  827 */     str2 = str2 + "))";
/*      */ 
/*  829 */     Object localObject = str2;
/*      */ 
/*  831 */     int i = ((Integer)getHibernateTemplate().execute(
/*  832 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/*  836 */         String str = "select count(user.id) from User user where " + 
/*  837 */           AdvanceQueryUtil.getHQLCondition("user");
/*      */ 
/*  839 */         str = str + " and (user.id in (";
/*  840 */         str = str + "select user1.id from User user1 where user1.id not in(select unitUser1.user.id from UnitUser unitUser1) and user1.id not in(select busiRoleUser.user.id from BusiRoleUser busiRoleUser where busiRoleUser.role.id=:busiRoleId) and user1.activeFlag=:activeFlag";
/*  841 */         str = str + ")";
/*  842 */         str = str + " or user.id in (";
/*  843 */         str = str + this.val$hql3;
/*  844 */         str = str + "))";
/*  845 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  846 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/*  847 */         for (int i = 0; i < arrayOfObject.length; i++) {
/*  848 */           localQuery.setParameter(i, arrayOfObject[i]);
/*      */         }
/*      */ 
/*  851 */         localQuery.setParameter("adminRoleId", paramString1);
/*  852 */         localQuery.setParameter("busiRoleId", paramString2);
/*  853 */         localQuery.setParameter("activeFlag", Boolean.valueOf(true));
/*      */ 
/*  855 */         for (i = 0; i < localArrayList.size(); i++) {
/*  856 */           localQuery.setParameter("unitPath" + i, (String)localArrayList.get(i) + "%");
/*      */         }
/*      */ 
/*  859 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  862 */     return i;
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleIdWithAdvanceQuery(String paramString, int paramInt1, int paramInt2)
/*      */   {
/*  870 */     String str = "select busiRoleUser.user from BusiRoleUser busiRoleUser where busiRoleUser.role.id = ? and " + AdvanceQueryUtil.getHQLCondition("busiRoleUser");
/*  871 */     Object[] arrayOfObject1 = AdvanceQueryUtil.getHQLConditionValues();
/*  872 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/*  873 */     arrayOfObject2[0] = paramString;
/*  874 */     for (int i = 1; i < arrayOfObject2.length; i++) {
/*  875 */       arrayOfObject2[i] = arrayOfObject1[(i - 1)];
/*      */     }
/*  877 */     return queryObjects(str, arrayOfObject2, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public int getUsersByBusiRoleIdNumberWithAdvanceQuery(String paramString)
/*      */   {
/*  884 */     String str = "select count(busiRoleUser.user.id) from BusiRoleUser busiRoleUser,User user where busiRoleUser.role.id = ? and user.id = busiRoleUser.user.id and " + 
/*  887 */       AdvanceQueryUtil.getHQLCondition("busiRoleUser");
/*  888 */     Object[] arrayOfObject1 = AdvanceQueryUtil.getHQLConditionValues();
/*  889 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/*  890 */     arrayOfObject2[0] = paramString;
/*  891 */     for (int i = 1; i < arrayOfObject2.length; i++) {
/*  892 */       arrayOfObject2[i] = arrayOfObject1[(i - 1)];
/*      */     }
/*  894 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*  895 */       arrayOfObject2).get(0).toString());
/*      */   }
/*      */ 
/*      */   public int getUsersByBusiRoleIdNumberWithAdvanceQuery(final String paramString1, final String paramString2)
/*      */   {
/*  905 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  908 */     List localList = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  911 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where unitUser2.user.activeFlag = ? and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id = ?) ";
/*      */ 
/*  913 */     final ArrayList localArrayList = new ArrayList();
/*  914 */     if (localList.size() > 0) {
/*  915 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  917 */       for (i = 0; i < localList.size(); i++) {
/*  918 */         localObject = (AdminRoleUnit)localList.get(i);
/*      */ 
/*  920 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  921 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  922 */           str2 = str2 + " or dimensionUnit.unitPath like ?";
/*      */         }
/*      */       }
/*  925 */       str2 = str2 + ")";
/*      */     }
/*  927 */     str2 = str2 + ")";
/*      */ 
/*  929 */     Object localObject = str2;
/*      */ 
/*  931 */     int i = ((Integer)getHibernateTemplate().execute(
/*  932 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/*  936 */         String str = "select count(busiRoleUser.user.id) from BusiRoleUser busiRoleUser where " + 
/*  938 */           AdvanceQueryUtil.getHQLCondition("busiRoleUser");
/*  939 */         str = str + " and busiRoleUser.role.id = ? and ";
/*  940 */         str = str + " busiRoleUser.user.id in (";
/*  941 */         str = str + this.val$hql3;
/*  942 */         str = str + ")";
/*  943 */         Query localQuery = paramAnonymousSession.createQuery(str);
/*  944 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/*  945 */         for (int i = 0; i < arrayOfObject.length; i++) {
/*  946 */           localQuery.setParameter(i, arrayOfObject[i]);
/*      */         }
/*  948 */         localQuery.setParameter(arrayOfObject.length, paramString2);
/*  949 */         localQuery.setParameter(arrayOfObject.length + 1, Boolean.valueOf(true));
/*  950 */         localQuery.setParameter(arrayOfObject.length + 2, paramString1);
/*      */ 
/*  952 */         for (i = 0; i < localArrayList.size(); i++) {
/*  953 */           localQuery.setParameter(arrayOfObject.length + 3 + i, (String)localArrayList.get(i) + "%");
/*      */         }
/*  955 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*      */       }
/*      */     })).intValue();
/*      */ 
/*  958 */     return i;
/*      */   }
/*      */ 
/*      */   public List getUsersByBusiRoleIdWithAdvanceQuery(final String paramString1, final String paramString2, final int paramInt1, final int paramInt2)
/*      */   {
/*  969 */     String str1 = "from AdminRoleUnit adminRoleUnit left join fetch adminRoleUnit.dimensionUnit  where adminRoleUnit.role.id =?";
/*      */ 
/*  972 */     List localList1 = getHibernateTemplate().find(str1, paramString1);
/*      */ 
/*  975 */     String str2 = "select distinct unitUser2.user.id from UnitUser unitUser2 where unitUser2.user.activeFlag = ? and (unitUser2.unit.id in (select adminRoleUnit.unit.id from AdminRoleUnit adminRoleUnit where adminRoleUnit.role.id = ?) ";
/*      */ 
/*  977 */     final ArrayList localArrayList = new ArrayList();
/*  978 */     if (localList1.size() > 0) {
/*  979 */       str2 = str2 + "or unitUser2.unit.id in(select dimensionUnit.unit.id from DimensionUnit dimensionUnit where 1=2";
/*      */ 
/*  981 */       for (int i = 0; i < localList1.size(); i++) {
/*  982 */         localObject = (AdminRoleUnit)localList1.get(i);
/*      */ 
/*  984 */         if (((AdminRoleUnit)localObject).getIsCascade().booleanValue()) {
/*  985 */           localArrayList.add(((AdminRoleUnit)localObject).getDimensionUnit().getUnitPath() + ((AdminRoleUnit)localObject).getDimensionUnit().getId());
/*  986 */           str2 = str2 + " or dimensionUnit.unitPath like ?";
/*      */         }
/*      */       }
/*  989 */       str2 = str2 + ")";
/*      */     }
/*  991 */     str2 = str2 + ")";
/*      */ 
/*  993 */     Object localObject = str2;
/*      */ 
/*  995 */     List localList2 = (List)getHibernateTemplate().execute(
/*  996 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*      */       {
/* 1000 */         String str = "select busiRoleUser.user from BusiRoleUser busiRoleUser where " + 
/* 1002 */           AdvanceQueryUtil.getHQLCondition("busiRoleUser");
/* 1003 */         str = str + " and busiRoleUser.role.id = ? and ";
/* 1004 */         str = str + " busiRoleUser.user.id in (";
/* 1005 */         str = str + this.val$hql3;
/* 1006 */         str = str + ")";
/* 1007 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 1008 */         Object[] arrayOfObject = AdvanceQueryUtil.getHQLConditionValues();
/* 1009 */         for (int i = 0; i < arrayOfObject.length; i++) {
/* 1010 */           localQuery.setParameter(i, arrayOfObject[i]);
/*      */         }
/* 1012 */         localQuery.setParameter(arrayOfObject.length, paramString2);
/* 1013 */         localQuery.setParameter(arrayOfObject.length + 1, Boolean.valueOf(true));
/* 1014 */         localQuery.setParameter(arrayOfObject.length + 2, paramString1);
/*      */ 
/* 1016 */         for (i = 0; i < localArrayList.size(); i++) {
/* 1017 */           localQuery.setParameter(arrayOfObject.length + 3 + i, (String)localArrayList.get(i) + "%");
/*      */         }
/* 1019 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 1020 */         localQuery.setMaxResults(paramInt2);
/* 1021 */         return localQuery.list();
/*      */       }
/*      */     });
/* 1024 */     return localList2;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.BusiRoleDAOImpl
 * JD-Core Version:    0.6.2
 */