/*     */ package com.neusoft.unieap.techcomp.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.techcomp.ria.common.query.util.AdvanceQueryUtil;
/*     */ import com.neusoft.unieap.techcomp.security.dao.SecurityAdminRoleDAO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.AdminRoleBusiRole;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("securityAdminRoleDAO.dao")
/*     */ public class SecurityAdminRoleDAOImpl extends BaseHibernateDAO
/*     */   implements SecurityAdminRoleDAO
/*     */ {
/*     */   public void saveAdminRoleBusiRole(AdminRoleBusiRole paramAdminRoleBusiRole)
/*     */   {
/*  32 */     getHibernateTemplate().save(paramAdminRoleBusiRole);
/*     */   }
/*     */ 
/*     */   public void deleteAdminRoleBusiRoles(final List<String> paramList1, final List<String> paramList2)
/*     */   {
/*  43 */     getHibernateTemplate().execute(new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/*  47 */         paramAnonymousSession.createQuery("delete from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id in (:adminRoleIds) and adminRoleBusiRole.busiRole.id in (:busiRoleIds)").setParameterList("adminRoleIds", 
/*  48 */           paramList1).setParameterList("busiRoleIds", 
/*  49 */           paramList2).executeUpdate();
/*  50 */         return null;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List getManagedBusiRoles(String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  68 */     String str1 = "select adminRoleBusiRole.busiRole from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ? and ";
/*     */ 
/*  71 */     String str2 = 
/*  72 */       AdvanceQueryUtil.getHQLCondition("adminRoleBusiRole.busiRole");
/*  73 */     Object[] arrayOfObject1 = AdvanceQueryUtil.getHQLConditionValues();
/*  74 */     str1 = str1 + str2;
/*  75 */     str1 = str1 + " order by adminRoleBusiRole.busiRole.name";
/*  76 */     Object[] arrayOfObject2 = new Object[arrayOfObject1.length + 1];
/*  77 */     arrayOfObject2[0] = paramString;
/*  78 */     for (int i = 1; i < arrayOfObject2.length; i++) {
/*  79 */       arrayOfObject2[i] = arrayOfObject1[(i - 1)];
/*     */     }
/*  81 */     if (paramInt2 < 0) {
/*  82 */       return queryObjects(str1, arrayOfObject2);
/*     */     }
/*  84 */     return queryObjects(str1, arrayOfObject2, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public int getManagedBusiRolesNumber(String paramString)
/*     */   {
/*  91 */     String str = "select count(adminRoleBusiRole.busiRole.id) from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ?";
/*     */ 
/*  93 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/*  94 */       new Object[] { paramString }).get(0).toString());
/*     */   }
/*     */ 
/*     */   public void deleteAdminRoleBusiRoles(String paramString)
/*     */   {
/* 101 */     String str = "delete from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ?";
/*     */ 
/* 103 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public List getManagedBusiRolesExceptAdminRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2)
/*     */   {
/* 111 */     String str = "select adminRoleBusiRole.busiRole from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ? and adminRoleBusiRole.busiRole.id not in (select adminBusiRole.busiRole.id from AdminRoleBusiRole adminBusiRole where adminBusiRole.adminRole.id = ?)";
/*     */ 
/* 114 */     str = str + " order by adminRoleBusiRole.busiRole.name";
/* 115 */     return queryObjects(str, new Object[] { paramString1, 
/* 116 */       paramString2 }, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   public int getManagedBusiRolesNumberExceptAdminRoleId(String paramString1, String paramString2)
/*     */   {
/* 124 */     String str = "select count(adminRoleBusiRole.busiRole.id) from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ? and adminRoleBusiRole.busiRole.id not in (select adminBusiRole.busiRole.id from AdminRoleBusiRole adminBusiRole where adminBusiRole.adminRole.id = ?)";
/*     */ 
/* 127 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/* 128 */       new Object[] { paramString1, paramString2 }).get(0)
/* 129 */       .toString());
/*     */   }
/*     */ 
/*     */   public List getAllBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2)
/*     */   {
/* 137 */     String str = "from BusiRole busiRole where busiRole.id not in (select adminRoleBusiRole.busiRole.id from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ?)";
/*     */ 
/* 140 */     str = str + " order by busiRole.name";
/* 141 */     return queryObjects(str, new Object[] { paramString }, paramInt1, 
/* 142 */       paramInt2);
/*     */   }
/*     */ 
/*     */   public int getAllBusiRolesNumberExceptAdminRoleId(String paramString)
/*     */   {
/* 149 */     String str = "select count(busiRole.id) from BusiRole busiRole where busiRole.id not in (select adminRoleBusiRole.busiRole.id from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = ?)";
/*     */ 
/* 152 */     return Integer.parseInt(getHibernateTemplate().find(str, 
/* 153 */       paramString).get(0).toString());
/*     */   }
/*     */ 
/*     */   public String getRolePath(String paramString)
/*     */   {
/* 160 */     String str = "select adminRole.rolePath from AdminRole adminRole where adminRole.id = ?";
/* 161 */     List localList = getHibernateTemplate().find(str, paramString);
/* 162 */     if ((localList != null) && (localList.size() > 0)) {
/* 163 */       return localList.get(0).toString();
/*     */     }
/* 165 */     return null;
/*     */   }
/*     */ 
/*     */   public List<String> getDescendantAdminRoleIds(String paramString)
/*     */   {
/* 173 */     String str = "select adminRole.id from AdminRole adminRole where adminRole.rolePath like ?";
/* 174 */     return getHibernateTemplate().find(str, 
/* 175 */       new Object[] { paramString + "%" });
/*     */   }
/*     */ 
/*     */   public List getManagedBusiRolesExceptUserId(final String paramString1, final String paramString2, final int paramInt1, final int paramInt2)
/*     */   {
/* 200 */     List localList = (List)getHibernateTemplate().execute(
/* 201 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 204 */         String str = "select adminRoleBusiRole.busiRole from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = :adminRoleId and adminRoleBusiRole.busiRole.id not in (select busiRoleUser.role.id from BusiRoleUser busiRoleUser where busiRoleUser.user.id = :userId)";
/*     */ 
/* 208 */         str = str + " order by adminRoleBusiRole.busiRole.name";
/* 209 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 210 */         localQuery.setParameter("adminRoleId", paramString1);
/* 211 */         localQuery.setParameter("userId", paramString2);
/* 212 */         localQuery.setFirstResult((paramInt1 - 1) * paramInt2);
/* 213 */         localQuery.setMaxResults(paramInt2);
/* 214 */         return localQuery.list();
/*     */       }
/*     */     });
/* 217 */     return localList;
/*     */   }
/*     */ 
/*     */   public int getManagedBusiRolesNumberExceptUserId(final String paramString1, final String paramString2)
/*     */   {
/* 224 */     int i = ((Integer)getHibernateTemplate().execute(
/* 225 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 228 */         String str = "select count(adminRoleBusiRole.busiRole.id) from AdminRoleBusiRole adminRoleBusiRole where adminRoleBusiRole.adminRole.id = :adminRoleId and adminRoleBusiRole.busiRole.id not in (select busiRoleUser.role.id from BusiRoleUser busiRoleUser where busiRoleUser.user.id = :userId)";
/*     */ 
/* 233 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 234 */         localQuery.setParameter("adminRoleId", paramString1);
/* 235 */         localQuery.setParameter("userId", paramString2);
/* 236 */         return Integer.valueOf(Integer.parseInt(localQuery.list().get(0).toString()));
/*     */       }
/*     */     })).intValue();
/*     */ 
/* 239 */     return i;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.impl.SecurityAdminRoleDAOImpl
 * JD-Core Version:    0.6.2
 */