package com.neusoft.unieap.techcomp.security.dao;

import com.neusoft.unieap.techcomp.security.entity.AdminRoleBusiRole;
import java.util.List;

public abstract interface SecurityAdminRoleDAO
{
  public abstract void saveAdminRoleBusiRole(AdminRoleBusiRole paramAdminRoleBusiRole);

  public abstract List getManagedBusiRoles(String paramString, int paramInt1, int paramInt2);

  public abstract List getManagedBusiRolesExceptAdminRoleId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getManagedBusiRolesNumberExceptAdminRoleId(String paramString1, String paramString2);

  public abstract List getAllBusiRolesExceptAdminRoleId(String paramString, int paramInt1, int paramInt2);

  public abstract int getAllBusiRolesNumberExceptAdminRoleId(String paramString);

  public abstract int getManagedBusiRolesNumber(String paramString);

  public abstract void deleteAdminRoleBusiRoles(String paramString);

  public abstract String getRolePath(String paramString);

  public abstract List<String> getDescendantAdminRoleIds(String paramString);

  public abstract void deleteAdminRoleBusiRoles(List<String> paramList1, List<String> paramList2);

  public abstract List getManagedBusiRolesExceptUserId(String paramString1, String paramString2, int paramInt1, int paramInt2);

  public abstract int getManagedBusiRolesNumberExceptUserId(String paramString1, String paramString2);
}

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.dao.SecurityAdminRoleDAO
 * JD-Core Version:    0.6.2
 */