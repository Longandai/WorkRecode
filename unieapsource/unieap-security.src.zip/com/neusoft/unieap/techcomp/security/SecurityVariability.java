/*    */ package com.neusoft.unieap.techcomp.security;
/*    */ 
/*    */ import com.neusoft.unieap.core.variability.VarManager;
/*    */ import com.neusoft.unieap.core.variability.VarManagerFactory;
/*    */ 
/*    */ public class SecurityVariability
/*    */ {
/*    */   private static final String SECURITY_CATEGORY = "SECURITY";
/*    */   private static final String SECURITY_EXECUTIVEACCOUNTENABLED_PARAM = "EXECUTIVEACCOUNT_ENABLED";
/* 17 */   private static VarManager varManager = VarManagerFactory.getVarManager(SecurityVariability.class);
/*    */ 
/*    */   public static boolean getExecutiveAccountEnabled()
/*    */   {
/* 28 */     return false;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.SecurityVariability
 * JD-Core Version:    0.6.2
 */