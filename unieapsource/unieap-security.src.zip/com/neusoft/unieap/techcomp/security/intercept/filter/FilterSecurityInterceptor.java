/*     */ package com.neusoft.unieap.techcomp.security.intercept.filter;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import org.springframework.security.ConfigAttribute;
/*     */ import org.springframework.security.ConfigAttributeDefinition;
/*     */ import org.springframework.security.intercept.InterceptorStatusToken;
/*     */ import org.springframework.security.intercept.ObjectDefinitionSource;
/*     */ import org.springframework.security.intercept.web.FilterInvocation;
/*     */ import org.springframework.security.intercept.web.FilterInvocationDefinitionSource;
/*     */ import org.springframework.security.ui.FilterChainOrder;
/*     */ 
/*     */ public class FilterSecurityInterceptor extends org.springframework.security.intercept.web.FilterSecurityInterceptor
/*     */ {
/*     */   private static final String FILTER_APPLIED = "__spring_security_filterSecurityInterceptor_filterApplied";
/*     */   private FilterInvocationDefinitionSource objectDefinitionSource;
/*  54 */   private boolean observeOncePerRequest = true;
/*     */ 
/*     */   public void init(FilterConfig paramFilterConfig)
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  85 */     FilterInvocation localFilterInvocation = new FilterInvocation(paramServletRequest, paramServletResponse, paramFilterChain);
/*  86 */     invoke(localFilterInvocation);
/*     */   }
/*     */ 
/*     */   public FilterInvocationDefinitionSource getObjectDefinitionSource() {
/*  90 */     return this.objectDefinitionSource;
/*     */   }
/*     */ 
/*     */   public Class getSecureObjectClass() {
/*  94 */     return FilterInvocation.class;
/*     */   }
/*     */ 
/*     */   public void invoke(FilterInvocation paramFilterInvocation) throws IOException, ServletException {
/*  98 */     if ((paramFilterInvocation.getRequest() != null) && (paramFilterInvocation.getRequest().getAttribute("__spring_security_filterSecurityInterceptor_filterApplied") != null) && 
/*  99 */       (this.observeOncePerRequest))
/*     */     {
/* 102 */       paramFilterInvocation.getChain().doFilter(paramFilterInvocation.getRequest(), paramFilterInvocation.getResponse());
/*     */     }
/*     */     else {
/* 105 */       if (paramFilterInvocation.getRequest() != null) {
/* 106 */         paramFilterInvocation.getRequest().setAttribute("__spring_security_filterSecurityInterceptor_filterApplied", Boolean.TRUE);
/*     */       }
/*     */ 
/* 109 */       int i = 1;
/*     */ 
/* 111 */       ConfigAttributeDefinition localConfigAttributeDefinition = obtainObjectDefinitionSource().getAttributes(paramFilterInvocation);
/*     */       Object localObject1;
/* 113 */       if (localConfigAttributeDefinition != null) {
/* 114 */         localObject1 = localConfigAttributeDefinition.getConfigAttributes();
/* 115 */         Iterator localIterator = ((Collection)localObject1).iterator();
/* 116 */         while (localIterator.hasNext()) {
/* 117 */           ConfigAttribute localConfigAttribute = (ConfigAttribute)localIterator.next();
/* 118 */           if (localConfigAttribute.getAttribute().equalsIgnoreCase("UNIEAP_PASS"))
/* 119 */             i = 0;
/*     */         }
/*     */       }
/* 122 */       if (i != 0) {
/* 123 */         localObject1 = super.beforeInvocation(paramFilterInvocation);
/*     */         try {
/* 125 */           paramFilterInvocation.getChain().doFilter(paramFilterInvocation.getRequest(), paramFilterInvocation.getResponse());
/*     */         } finally {
/* 127 */           super.afterInvocation((InterceptorStatusToken)localObject1, null);
/*     */         }
/*     */       }
/*     */       else {
/* 131 */         paramFilterInvocation.getChain().doFilter(paramFilterInvocation.getRequest(), paramFilterInvocation.getResponse());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isObserveOncePerRequest()
/*     */   {
/* 146 */     return this.observeOncePerRequest;
/*     */   }
/*     */ 
/*     */   public ObjectDefinitionSource obtainObjectDefinitionSource() {
/* 150 */     return this.objectDefinitionSource;
/*     */   }
/*     */ 
/*     */   public void setObjectDefinitionSource(FilterInvocationDefinitionSource paramFilterInvocationDefinitionSource) {
/* 154 */     this.objectDefinitionSource = paramFilterInvocationDefinitionSource;
/*     */   }
/*     */ 
/*     */   public void setObserveOncePerRequest(boolean paramBoolean) {
/* 158 */     this.observeOncePerRequest = paramBoolean;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 162 */     return FilterChainOrder.FILTER_SECURITY_INTERCEPTOR;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.intercept.filter.FilterSecurityInterceptor
 * JD-Core Version:    0.6.2
 */