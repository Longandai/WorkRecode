/*     */ package com.neusoft.unieap.techcomp.security.tld;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.Role;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.util.BeanUtil;
/*     */ import com.neusoft.unieap.techcomp.cache.EAPCacheManager;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.bo.PageIndividualBO;
/*     */ import com.neusoft.unieap.techcomp.ria.individual.entity.PageIndividual;
/*     */ import com.neusoft.unieap.techcomp.security.bo.PageAuthorizeBO;
/*     */ import com.neusoft.unieap.techcomp.security.entity.ResourceAuthority;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.jsp.JspException;
/*     */ import javax.servlet.jsp.JspWriter;
/*     */ import javax.servlet.jsp.PageContext;
/*     */ import javax.servlet.jsp.tagext.BodyContent;
/*     */ import javax.servlet.jsp.tagext.BodyTagSupport;
/*     */ import net.sf.json.JSONArray;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.dom4j.Attribute;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.Node;
/*     */ import org.dom4j.Text;
/*     */ import org.dom4j.io.HTMLWriter;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.SAXReader;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class AuthorityTag extends BodyTagSupport
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   public int doEndTag()
/*     */     throws JspException
/*     */   {
/*  52 */     JspWriter localJspWriter = this.pageContext.getOut();
/*     */ 
/*  54 */     String str1 = getBodyContent().getString();
/*  55 */     str1 = str1 + 
/*  56 */       "<div id=\"hasUniEAPAuthTag\" style=\"display:none;width:0px;height:0px\"></div>";
/*  57 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)this.pageContext
/*  58 */       .getRequest();
/*  59 */     String str2 = null;
/*  60 */     String str3 = localHttpServletRequest.getParameter("actID");
/*  61 */     String str4 = localHttpServletRequest.getParameter("unieapMenuId");
/*     */ 
/*  64 */     String str5 = localHttpServletRequest.getServletPath();
/*  65 */     String str6 = ((PageAuthorizeBO)
/*  66 */       BeanUtil.getBean("security_pageAuthorizeBO_bo")).getSCIds();
/*  67 */     String str7 = getViewModelId(str5, str6);
/*  68 */     Object localObject1 = null;
/*  69 */     List localList1 = null;
/*     */     Object localObject5;
/*     */     Object localObject7;
/*     */     Object localObject6;
/*  71 */     if (str3 == null) {
/*  72 */       if ((localHttpServletRequest.getParameter("pageAuthority") == null) && 
/*  73 */         (str4 != null)) {
/*  74 */         localObject2 = null;
/*  75 */         localObject3 = UniEAPContextHolder.getContext().getCurrentUser();
/*  76 */         localObject4 = ((User)localObject3).getAccount();
/*  77 */         List localList2 = ((User)localObject3).getRoles();
/*  78 */         Role localRole = null;
/*  79 */         localObject5 = new ArrayList();
/*  80 */         String str8 = null;
/*  81 */         localObject1 = (Map)((EAPCacheManager)
/*  82 */           BeanUtil.getBean("eapCacheManager")).get(localObject4, 
/*  83 */           "pageAuthority");
/*  84 */         if (localObject1 == null) {
/*  85 */           localObject1 = new HashMap();
/*     */         }
/*     */ 
/*  88 */         if (((Map)localObject1).containsKey(str4)) {
/*  89 */           localObject2 = (Map)((Map)localObject1).get(str4);
/*  90 */           if (localObject2 == null)
/*  91 */             localObject2 = new HashMap();
/*     */         }
/*     */         else {
/*  94 */           localObject2 = new HashMap();
/*     */         }
/*     */ 
/*  97 */         if (((Map)localObject2).containsKey(str7)) {
/*  98 */           localList1 = (List)((Map)localObject2).get(str7);
/*     */         }
/* 100 */         else if ((localList2 != null) && (localList2.size() > 0)) {
/* 101 */           for (localObject7 = localList2.iterator(); ((Iterator)localObject7).hasNext(); ) { localObject6 = ((Iterator)localObject7).next();
/* 102 */             localRole = (Role)localObject6;
/* 103 */             str8 = localRole.getType();
/* 104 */             str2 = localRole.getId();
/* 105 */             if (("busiRole".equals(str8)) || 
/* 107 */               ("unit"
/* 107 */               .equals(str8)) || 
/* 109 */               ("station"
/* 109 */               .equals(str8)))
/* 110 */               ((List)localObject5).add(str2);
/*     */           }
/* 112 */           if ((localObject5 != null) && (((List)localObject5).size() > 0))
/*     */           {
/* 114 */             localList1 = ((PageAuthorizeBO)
/* 115 */               BeanUtil.getBean("security_pageAuthorizeBO_bo"))
/* 116 */               .getPageAuthorities((List)localObject5, str7, str4, "menu");
/* 117 */             ((Map)localObject2).put(str7, localList1);
/* 118 */             ((Map)localObject1).put(str4, localObject2);
/* 119 */             ((EAPCacheManager)BeanUtil.getBean("eapCacheManager"))
/* 120 */               .put(localObject4, localObject1, "pageAuthority");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*     */       try
/*     */       {
/* 129 */         localObject2 = localHttpServletRequest.getHeader("USER-AGENT");
/* 130 */         if (localObject2 != null)
/* 131 */           if ((((String)localObject2).indexOf("Firefox") > 0) || (((String)localObject2).indexOf("Chrome") > 0))
/*     */           {
/* 133 */             str3 = new String(str3
/* 134 */               .getBytes("ISO-8859-1"));
/*     */           }
/*     */           else
/* 137 */             str3 = new String(str3
/* 138 */               .getBytes("ISO-8859-1"), "GBK");
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException1)
/*     */       {
/*     */       }
/* 143 */       localObject1 = (Map)((EAPCacheManager)
/* 144 */         BeanUtil.getBean("eapCacheManager")).get(str3, 
/* 145 */         "circumstanceAuthority");
/* 146 */       if (localObject1 == null) {
/* 147 */         localObject1 = new HashMap();
/*     */       }
/* 149 */       if (((Map)localObject1).containsKey(str7)) {
/* 150 */         localList1 = (List)((Map)localObject1).get(str7);
/*     */       }
/*     */       else {
/* 153 */         localList1 = ((PageAuthorizeBO)
/* 154 */           BeanUtil.getBean("security_pageAuthorizeBO_bo"))
/* 155 */           .getPageAuthorities(str7, str3, 
/* 156 */           "workflow");
/* 157 */         ((Map)localObject1).put(str7, localList1);
/* 158 */         ((EAPCacheManager)BeanUtil.getBean("eapCacheManager")).put(
/* 159 */           str3, localObject1, "circumstanceAuthority");
/*     */       }
/*     */     }
/* 162 */     Object localObject2 = null;
/* 163 */     Object localObject3 = null;
/*     */ 
/* 165 */     str3 = localHttpServletRequest.getParameter("circumstanceId");
/* 166 */     if (str3 != null)
/*     */     {
/*     */       try {
/* 169 */         localObject4 = localHttpServletRequest.getHeader("USER-AGENT");
/* 170 */         if (localObject4 != null)
/* 171 */           if ((((String)localObject4).indexOf("Firefox") > 0) || (((String)localObject4).indexOf("Chrome") > 0))
/*     */           {
/* 173 */             str3 = new String(str3
/* 174 */               .getBytes("ISO-8859-1"));
/*     */           }
/*     */           else
/* 177 */             str3 = new String(str3
/* 178 */               .getBytes("ISO-8859-1"), "GBK");
/*     */       }
/*     */       catch (UnsupportedEncodingException localUnsupportedEncodingException2)
/*     */       {
/*     */       }
/* 183 */       localObject3 = (Map)((EAPCacheManager)
/* 184 */         BeanUtil.getBean("eapCacheManager")).get(str3, 
/* 185 */         "pageIndividual");
/* 186 */       if (localObject3 == null) {
/* 187 */         localObject3 = new HashMap();
/*     */       }
/* 189 */       if (((Map)localObject3).containsKey(str7)) {
/* 190 */         localObject2 = (List)((Map)localObject3).get(str7);
/*     */       } else {
/* 192 */         localObject2 = ((PageIndividualBO)
/* 193 */           BeanUtil.getBean("ria_pageIndividualBO_bo"))
/* 194 */           .getPageIndividualList(str7, str3);
/* 195 */         ((Map)localObject3).put(str7, localObject2);
/* 196 */         ((EAPCacheManager)BeanUtil.getBean("eapCacheManager")).put(
/* 197 */           str3, localObject3, "pageIndividual");
/*     */       }
/*     */     }
/* 200 */     Object localObject4 = new ArrayList();
/* 201 */     int i = 0;
/* 202 */     int j = 0;
/* 203 */     if ((localList1 != null) && (localList1.size() > 0)) {
/* 204 */       ((List)localObject4).addAll(localList1);
/* 205 */       i = 1;
/*     */     }
/* 207 */     if ((localObject2 != null) && (((List)localObject2).size() > 0)) {
/* 208 */       ((List)localObject4).addAll((Collection)localObject2);
/* 209 */       j = 1;
/*     */     }
/*     */ 
/* 212 */     if ((i != 0) && (j != 0)) {
/* 213 */       localObject4 = ((PageAuthorizeBO)
/* 214 */         BeanUtil.getBean("security_pageAuthorizeBO_bo"))
/* 215 */         .filterAuthorityIndividual((List)localObject4);
/*     */     }
/*     */ 
/* 218 */     if ((localObject4 != null) && (((List)localObject4).size() > 0)) {
/* 219 */       localObject5 = null;
/*     */ 
/* 221 */       str1 = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"><root>" + 
/* 223 */         str1 + "</root>";
/*     */       try {
/* 225 */         localObject5 = str2Xml(str1);
/*     */       }
/*     */       catch (DocumentException localDocumentException) {
/* 228 */         localDocumentException.printStackTrace();
/*     */       }
/* 230 */       if (localObject5 != null)
/*     */       {
/* 232 */         String str9 = ((PageAuthorizeBO)
/* 233 */           BeanUtil.getBean("security_pageAuthorizeBO_bo"))
/* 234 */           .getControlType();
/* 235 */         localObject6 = "";
/* 236 */         localObject7 = "";
/* 237 */         for (Iterator localIterator = ((List)localObject4).iterator(); localIterator.hasNext(); ) { Object localObject8 = localIterator.next();
/* 238 */           if ((localObject8 instanceof ResourceAuthority)) {
/* 239 */             localObject6 = ((ResourceAuthority)localObject8).getResourceId();
/* 240 */             localObject7 = ((ResourceAuthority)localObject8).getAuthorityType();
/* 241 */           } else if ((localObject8 instanceof PageIndividual)) {
/* 242 */             localObject6 = ((PageIndividual)localObject8).getResourceId();
/* 243 */             localObject7 = ((PageIndividual)localObject8).getIndividualType();
/*     */           }
/* 245 */           if (((String)localObject7).equals("hidden"))
/* 246 */             hiddenControl((Document)localObject5, ((String)localObject6)
/* 247 */               .substring(str7.length() + 1), 
/* 248 */               str9);
/* 249 */           else if (((String)localObject7).equals("disabled")) {
/* 250 */             disableControl((Document)localObject5, ((String)localObject6).substring(str7
/* 251 */               .length() + 1), str9);
/*     */           }
/*     */         }
/*     */ 
/* 255 */         layoutHiddenControl((Document)localObject5);
/* 256 */         str1 = xml2Str((Document)localObject5);
/* 257 */         int k = str1.indexOf("<root>") + "<root>".length();
/* 258 */         int m = str1.lastIndexOf("</root>");
/* 259 */         str1 = str1.substring(k, m);
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 265 */       localJspWriter.print(str1);
/* 266 */       localJspWriter.flush();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/*     */     }
/* 271 */     return 6;
/*     */   }
/*     */ 
/*     */   private void hiddenControl(Document paramDocument, String paramString1, String paramString2)
/*     */   {
/* 282 */     if (paramString1 == null) {
/* 283 */       return;
/*     */     }
/* 285 */     int i = 0;
/* 286 */     if (paramString1.endsWith("_unieapGridExportButton")) {
/* 287 */       paramString1 = paramString1.substring(0, paramString1
/* 288 */         .indexOf("_unieapGridExportButton"));
/* 289 */       i = 1;
/*     */     }
/* 291 */     int j = 0;
/* 292 */     if (paramString1.endsWith("_unieapGridImportButton")) {
/* 293 */       paramString1 = paramString1.substring(0, paramString1
/* 294 */         .indexOf("_unieapGridImportButton"));
/* 295 */       j = 1;
/*     */     }
/*     */ 
/* 298 */     String str1 = null;
/* 299 */     if (paramString1.indexOf("_unieapUploader") != -1) {
/* 300 */       str1 = paramString1.substring(paramString1.indexOf("_unieapUploader") + "_unieapUploader".length());
/* 301 */       paramString1 = paramString1.substring(0, paramString1.indexOf("_unieapUploader"));
/*     */     }
/* 303 */     Node localNode = paramDocument.selectSingleNode("//*[@id='" + paramString1 + "']");
/* 304 */     if (localNode != null) {
/* 305 */       Element localElement = (Element)localNode;
/* 306 */       if ((!"all".equalsIgnoreCase(paramString2)) && 
/* 307 */         (!isControlAuthoried(paramString2, localElement)))
/*     */         return;
/*     */       Object localObject1;
/* 310 */       if (localElement.getName().equals("cell")) {
/* 311 */         localObject1 = localElement.getParent();
/* 312 */         ((Element)localObject1).remove(localNode);
/*     */       } else {
/* 314 */         localObject1 = localElement.attribute("dojoType");
/* 315 */         if (localObject1 != null) {
/* 316 */           String str2 = ((Attribute)localObject1).getText();
/*     */           Object localObject2;
/*     */           Object localObject3;
/* 317 */           if (("unieap.grid.Grid".equals(str2)) || 
/* 318 */             ("unieap.xgrid.Grid".equals(str2))) {
/* 319 */             if (i != 0) {
/* 320 */               localObject2 = localElement.element("toolbar");
/* 321 */               if (localObject2 != null) {
/* 322 */                 localObject3 = ((Element)localObject2).attribute("export");
/* 323 */                 if (localObject3 != null)
/* 324 */                   ((Element)localObject2).remove((Attribute)localObject3);
/*     */               }
/*     */             }
/* 327 */             else if (j != 0) {
/* 328 */               localObject2 = localElement.element("toolbar");
/* 329 */               if (localObject2 != null) {
/* 330 */                 localObject3 = ((Element)localObject2).attribute("import");
/* 331 */                 if (localObject3 != null)
/* 332 */                   ((Element)localObject2).remove((Attribute)localObject3);
/*     */               }
/*     */             }
/*     */             else {
/* 336 */               localElement.setAttributeValue("style", "display:none");
/*     */             }
/* 338 */           } else if ("unieap.layout.ContentPane".equals(str2)) {
/* 339 */             localElement.setAttributeValue("hidden", "true");
/* 340 */           } else if ("unieap.form.Uploader".equals(str2))
/*     */           {
/* 342 */             localObject2 = localElement.attribute("displayButtons");
/* 343 */             if (localObject2 != null) {
/* 344 */               localObject3 = JSONArray.fromObject(((Attribute)localObject2).getText());
/* 345 */               if (localObject3 != null) {
/* 346 */                 for (int k = 0; k < ((JSONArray)localObject3).size(); k++) {
/* 347 */                   JSONObject localJSONObject = (JSONObject)((JSONArray)localObject3).get(k);
/* 348 */                   if ((localJSONObject != null) && (str1.equals(String.valueOf(localJSONObject.get("type"))))) {
/* 349 */                     localJSONObject.put("visible", "false");
/* 350 */                     break;
/*     */                   }
/*     */                 }
/*     */               }
/* 354 */               ((Attribute)localObject2).setText(((JSONArray)localObject3).toString());
/*     */             } else {
/* 356 */               localObject3 = new JSONObject();
/* 357 */               ((JSONObject)localObject3).put("type", str1);
/* 358 */               ((JSONObject)localObject3).put("visible", "false");
/* 359 */               JSONArray localJSONArray = new JSONArray();
/* 360 */               localJSONArray.add(localObject3);
/* 361 */               localElement.addAttribute("displayButtons", localJSONArray.toString());
/*     */             }
/*     */           } else {
/* 364 */             localElement.setAttributeValue("style", "display:none");
/*     */           }
/*     */         } else {
/* 367 */           localElement.setAttributeValue("style", "display:none");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void disableControl(Document paramDocument, String paramString1, String paramString2)
/*     */   {
/* 381 */     if (paramString1 == null)
/* 382 */       return;
/* 383 */     Node localNode = paramDocument.selectSingleNode("//*[@id='" + paramString1 + "']");
/* 384 */     if (localNode != null) {
/* 385 */       Element localElement = (Element)localNode;
/* 386 */       if ((!"all".equalsIgnoreCase(paramString2)) && 
/* 387 */         (isControlAuthoried(paramString2, localElement)))
/*     */         return;
/*     */       Attribute localAttribute1;
/* 390 */       if (localElement.getName().equals("cell")) {
/* 391 */         localElement.setAttributeValue("enable", "false");
/* 392 */         localAttribute1 = localElement.attribute("editor");
/* 393 */         if (localAttribute1 != null)
/* 394 */           localElement.remove(localAttribute1);
/*     */       }
/*     */       else {
/* 397 */         localAttribute1 = localElement.attribute("dojoType");
/* 398 */         if (localAttribute1 != null) {
/* 399 */           String str = localAttribute1.getText();
/* 400 */           if (("unieap.grid.Grid".equals(str)) || 
/* 401 */             ("unieap.xgrid.Grid".equals(str))) {
/* 402 */             Attribute localAttribute2 = localElement.attribute("edit");
/* 403 */             if (localAttribute2 != null)
/* 404 */               localElement.remove(localAttribute2);
/*     */           }
/*     */           else {
/* 407 */             localElement.setAttributeValue("disabled", "true");
/*     */           }
/*     */         } else {
/* 410 */           localElement.setAttributeValue("disabled", "true");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private Document str2Xml(String paramString) throws DocumentException
/*     */   {
/* 418 */     if ((paramString.contains("<br>")) || (paramString.contains("</br>"))) {
/* 419 */       paramString = paramString.replaceAll("<br>", "<br/>");
/* 420 */       paramString = paramString.replaceAll("</br>", "<br/>");
/*     */     }
/* 422 */     SAXReader localSAXReader = new SAXReader();
/*     */     try {
/* 424 */       localSAXReader
/* 425 */         .setFeature(
/* 426 */         "http://apache.org/xml/features/nonvalidating/load-external-dtd", 
/* 427 */         false);
/* 428 */       return localSAXReader.read(new ByteArrayInputStream(paramString
/* 429 */         .getBytes("UTF-8")));
/*     */     } catch (SAXException localSAXException) {
/* 431 */       localSAXException.printStackTrace();
/*     */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 433 */       localUnsupportedEncodingException.printStackTrace();
/*     */     }
/* 435 */     return null;
/*     */   }
/*     */ 
/*     */   private String xml2Str(Document paramDocument) {
/* 439 */     StringWriter localStringWriter = new StringWriter();
/* 440 */     OutputFormat localOutputFormat = OutputFormat.createPrettyPrint();
/* 441 */     localOutputFormat.setEncoding("utf-8");
/* 442 */     localOutputFormat.setXHTML(true);
/* 443 */     HTMLWriter localHTMLWriter = new HTMLWriter(localStringWriter, localOutputFormat);
/*     */ 
/* 445 */     localOutputFormat.setExpandEmptyElements(true);
/*     */     try {
/* 447 */       localHTMLWriter.write(paramDocument);
/* 448 */       localHTMLWriter.flush();
/*     */     } catch (IOException localIOException) {
/* 450 */       localIOException.printStackTrace();
/*     */     }
/*     */ 
/* 453 */     return localStringWriter.toString();
/*     */   }
/*     */ 
/*     */   private String getViewModelId(String paramString1, String paramString2)
/*     */   {
/* 464 */     String str1 = "";
/* 465 */     String str2 = "";
/* 466 */     String str3 = "";
/* 467 */     String str4 = "";
/*     */ 
/* 469 */     if (paramString1.charAt(0) == '/')
/* 470 */       paramString1 = paramString1.substring(1);
/* 471 */     String[] arrayOfString = paramString1.split("/");
/* 472 */     int i = arrayOfString.length;
/*     */     Object localObject;
/*     */     int j;
/* 474 */     if (i >= 3) {
/* 475 */       localObject = paramString2.split(",");
/* 476 */       j = 0;
/* 477 */       for (int k = 0; k < localObject.length; k++)
/* 478 */         if (localObject[k].equals(arrayOfString[0])) {
/* 479 */           j = 1;
/* 480 */           break;
/*     */         }
/*     */       String str5;
/*     */       int m;
/*     */       int n;
/* 483 */       if (j != 0) {
/* 484 */         str1 = arrayOfString[1];
/* 485 */         str5 = arrayOfString[(i - 1)];
/* 486 */         m = str5.lastIndexOf("-view.jsp");
/* 487 */         if (m == -1) {
/* 488 */           m = str5.lastIndexOf("_entry.action");
/*     */         }
/* 490 */         if (m != -1) {
/* 491 */           str3 = str5.substring(0, m);
/* 492 */           if (i > 3) {
/* 493 */             str2 = arrayOfString[2];
/* 494 */             for (n = 3; n < i - 1; n++)
/* 495 */               str2 = str2 + "/" + arrayOfString[n];
/*     */           }
/*     */           else {
/* 498 */             str2 = "";
/*     */           }
/* 500 */           if (str2.equals(""))
/* 501 */             str4 = str1 + "_" + str3 + "_view";
/*     */           else
/* 503 */             str4 = str1 + "_" + str2.replace("/", "_") + 
/* 504 */               "_" + str3 + "_view";
/*     */         }
/*     */       }
/*     */       else {
/* 508 */         str1 = arrayOfString[0];
/* 509 */         str5 = arrayOfString[(i - 1)];
/* 510 */         m = str5.lastIndexOf("-view.jsp");
/* 511 */         if (m == -1) {
/* 512 */           m = str5.lastIndexOf("_entry.action");
/*     */         }
/* 514 */         if (m != -1) {
/* 515 */           str3 = str5.substring(0, m);
/* 516 */           if (i > 2) {
/* 517 */             str2 = arrayOfString[1];
/* 518 */             for (n = 2; n < i - 1; n++)
/* 519 */               str2 = str2 + "/" + arrayOfString[n];
/*     */           }
/*     */           else {
/* 522 */             str2 = "";
/*     */           }
/* 524 */           if (str2.equals(""))
/* 525 */             str4 = str1 + "_" + str3 + "_view";
/*     */           else
/* 527 */             str4 = str1 + "_" + str2.replace("/", "_") + 
/* 528 */               "_" + str3 + "_view";
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 533 */       if (i < 2) {
/* 534 */         return str4;
/*     */       }
/* 536 */       str1 = arrayOfString[0];
/* 537 */       localObject = arrayOfString[(i - 1)];
/* 538 */       j = ((String)localObject).lastIndexOf("-view.jsp");
/* 539 */       if (j == -1) {
/* 540 */         j = ((String)localObject).lastIndexOf("_entry.action");
/*     */       }
/* 542 */       if (j != -1) {
/* 543 */         str3 = ((String)localObject).substring(0, j);
/* 544 */         str4 = str1 + "_" + str3 + "_view";
/*     */       }
/*     */     }
/* 547 */     return str4;
/*     */   }
/*     */ 
/*     */   public boolean isControlAuthoried(String paramString, Element paramElement) {
/* 551 */     if (paramString == "all") {
/* 552 */       return true;
/*     */     }
/* 554 */     String[] arrayOfString = paramString.split(",");
/* 555 */     String str1 = paramElement.attributeValue("dojoType");
/* 556 */     String str2 = "";
/* 557 */     if (str1 == null) {
/* 558 */       str1 = "";
/* 559 */       str2 = paramElement.getName();
/*     */     }
/*     */ 
/* 562 */     for (int i = 0; i < arrayOfString.length; i++) {
/* 563 */       if (arrayOfString[i].equals("button")) {
/* 564 */         if (str1.equals("unieap.form.Button"))
/* 565 */           return true;
/*     */       }
/* 567 */       else if (arrayOfString[i].equals("textBox")) {
/* 568 */         if ((str1.equals("unieap.form.TextBox")) || 
/* 569 */           (str1.equals("unieap.form.DateTextBox")) || 
/* 570 */           (str1.equals("unieap.form.NumberTextBox")) || 
/* 571 */           (str1.equals("unieap.form.TextBoxWithIcon")) || 
/* 572 */           (str1.equals("unieap.form.InlineEditBox")) || 
/* 573 */           (str1.equals("unieap.form.Textarea")))
/* 574 */           return true;
/*     */       }
/* 576 */       else if (arrayOfString[i].equals("combobox")) {
/* 577 */         if ((str1.equals("unieap.form.ComboBox")) || 
/* 578 */           (str1.equals("unieap.form.ComboBoxTree")))
/* 579 */           return true;
/*     */       }
/* 581 */       else if (arrayOfString[i].equals("checkBox")) {
/* 582 */         if ((str1.equals("unieap.form.CheckBox")) || 
/* 583 */           (str1.equals("unieap.form.CheckBoxGroup")))
/* 584 */           return true;
/*     */       }
/* 586 */       else if (arrayOfString[i].equals("radioButton")) {
/* 587 */         if ((str1.equals("unieap.form.RadioButton")) || 
/* 588 */           (str1.equals("unieap.form.RadioButtonGroup")))
/* 589 */           return true;
/*     */       }
/* 591 */       else if (arrayOfString[i].equals("tree")) {
/* 592 */         if (str1.equals("unieap.tree.Tree"))
/* 593 */           return true;
/*     */       }
/* 595 */       else if (arrayOfString[i].equals("grid")) {
/* 596 */         if ((str1.equals("unieap.grid.Grid")) || 
/* 597 */           (str1.equals("unieap.xgrid.Grid")) || 
/* 598 */           (str2.equalsIgnoreCase("cell")))
/* 599 */           return true;
/*     */       }
/* 601 */       else if (arrayOfString[i].equals("container")) {
/* 602 */         if ((str1.indexOf("unieap.layout") != -1) || 
/* 603 */           (str1.equals("unieap.form.Form")) || 
/* 604 */           (str1.equals("unieapx.form.FormList")) || 
/* 605 */           (str2.equalsIgnoreCase("div")))
/* 606 */           return true;
/*     */       }
/* 608 */       else if ((arrayOfString[i].equals("image")) && 
/* 609 */         (str2.equalsIgnoreCase("img"))) {
/* 610 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 614 */     return false;
/*     */   }
/*     */ 
/*     */   private void layoutHiddenControl(Document paramDocument)
/*     */   {
/* 623 */     List localList = paramDocument.selectNodes("//table");
/* 624 */     if ((localList != null) && (localList.size() > 0))
/* 625 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 626 */         layoutTable((Node)localObject);
/*     */       }
/*     */   }
/*     */ 
/*     */   private void layoutTable(Node paramNode)
/*     */   {
/* 640 */     Element localElement1 = getChildElement((Element)paramNode, "tbody");
/* 641 */     List localList1 = getChildElements(localElement1, "tr");
/* 642 */     if (localList1.size() != 1) {
/* 643 */       return;
/*     */     }
/*     */ 
/* 647 */     int i = 0;
/* 648 */     Element localElement2 = getChildElement((Element)paramNode, "colgroup");
/* 649 */     List localList2 = getChildElements(localElement2, "col");
/* 650 */     if ((localList2 != null) && (localList2.size() > 0)) {
/* 651 */       for (j = 0; j < localList2.size(); j++) {
/* 652 */         i++;
/* 653 */         localObject1 = (Element)localList2.get(j);
/* 654 */         localObject2 = ((Element)localObject1).attribute("span");
/* 655 */         if (localObject2 != null) {
/* 656 */           i += Integer.valueOf(((Attribute)localObject2).getValue()).intValue();
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 662 */     int j = 1;
/* 663 */     Object localObject1 = new HashMap();
/* 664 */     Object localObject2 = getChildElements((Element)localList1.get(0), "td");
/* 665 */     if ((localObject2 != null) && (((List)localObject2).size() > 0)) {
/* 666 */       for (int k = 0; k < ((List)localObject2).size(); k++)
/*     */       {
/* 677 */         if (!isIncludeButtonOnly((Element)((List)localObject2).get(k), k, (Map)localObject1)) {
/* 678 */           j = 0;
/*     */         }
/*     */       }
/* 681 */       if (j != 0) {
/* 682 */         if (((Map)localObject1).size() > 0) {
/* 683 */           Iterator localIterator = ((Map)localObject1).entrySet().iterator();
/* 684 */           while (localIterator.hasNext()) {
/* 685 */             Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 686 */             ((Element)localEntry.getValue()).getParent().remove(
/* 687 */               (Element)localEntry.getValue());
/* 688 */             int m = ((Integer)localEntry.getKey()).intValue();
/* 689 */             localElement2.remove((Element)localList2.get(m));
/*     */           }
/*     */         }
/*     */       }
/* 693 */       else ((Map)localObject1).clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<Element> getChildElements(Element paramElement, String paramString)
/*     */   {
/* 699 */     ArrayList localArrayList = new ArrayList();
/* 700 */     List localList = paramElement.content();
/* 701 */     if ((localList != null) && (localList.size() > 0)) {
/* 702 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 703 */         if ((localObject instanceof Element)) {
/* 704 */           Element localElement = (Element)localObject;
/* 705 */           if (localElement.getName().equals(paramString)) {
/* 706 */             localArrayList.add(localElement);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 711 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   private Element getChildElement(Element paramElement, String paramString) {
/* 715 */     List localList = getChildElements(paramElement, paramString);
/* 716 */     if (localList.size() > 0)
/* 717 */       return (Element)localList.get(0);
/* 718 */     return null;
/*     */   }
/*     */ 
/*     */   private boolean isIncludeButtonOnly(Element paramElement, int paramInt, Map paramMap) {
/* 722 */     List localList = paramElement.content();
/* 723 */     if ((localList != null) && (localList.size() > 0)) {
/* 724 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 725 */         if ((localObject instanceof Text)) {
/* 726 */           String str = ((Text)localObject).getText();
/* 727 */           if ((str != null) && (str.trim().length() > 0))
/* 728 */             return false;
/* 729 */         } else if ((localObject instanceof Element)) {
/* 730 */           if (((Element)localObject).attributeValue("dojoType") != null)
/*     */           {
/* 732 */             if (((Element)localObject).attributeValue("dojoType")
/* 732 */               .equals("unieap.form.Button")) {
/* 733 */               if (((Element)localObject).attributeValue("style") == null)
/*     */                 continue;
/* 735 */               if (!((Element)localObject).attributeValue("style")
/* 735 */                 .contains("display:none")) continue;
/* 736 */               paramMap.put(Integer.valueOf(paramInt), paramElement); continue;
/*     */             }
/*     */           }
/* 739 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 744 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.tld.AuthorityTag
 * JD-Core Version:    0.6.2
 */