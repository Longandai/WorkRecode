/*    */ package com.neusoft.unieap.techcomp.security.bootstrap;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.model.DCActivator;
/*    */ import com.neusoft.unieap.techcomp.security.bo.AccountPolicyBO;
/*    */ import com.neusoft.unieap.techcomp.security.bo.OnlineUserBO;
/*    */ import com.neusoft.unieap.techcomp.security.onlineuser.OnlineUserConfig;
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ 
/*    */ public class SecurityActivator extends DCActivator
/*    */ {
/*    */   private AccountPolicyBO accountPolicyBO;
/*    */   private OnlineUserBO onlineUserBO;
/*    */   private OnlineUserConfig onlineUserConfig;
/*    */ 
/*    */   public void shutdown()
/*    */     throws Exception
/*    */   {
/*    */   }
/*    */ 
/*    */   public void startup()
/*    */     throws Exception
/*    */   {
/* 22 */     this.accountPolicyBO.initCache();
/* 23 */     if (this.onlineUserConfig.isEnabled()) {
/* 24 */       String str = null;
/*    */       try {
/* 26 */         str = InetAddress.getLocalHost().getHostAddress();
/* 27 */         this.onlineUserBO.deleteOnlineUsersByServerIp(str);
/*    */       } catch (UnknownHostException localUnknownHostException) {
/* 29 */         localUnknownHostException.printStackTrace();
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setAccountPolicyBO(AccountPolicyBO paramAccountPolicyBO) {
/* 35 */     this.accountPolicyBO = paramAccountPolicyBO;
/*    */   }
/*    */ 
/*    */   public AccountPolicyBO getAccountPolicyBO() {
/* 39 */     return this.accountPolicyBO;
/*    */   }
/*    */ 
/*    */   public OnlineUserBO getOnlineUserBO() {
/* 43 */     return this.onlineUserBO;
/*    */   }
/*    */ 
/*    */   public void setOnlineUserBO(OnlineUserBO paramOnlineUserBO) {
/* 47 */     this.onlineUserBO = paramOnlineUserBO;
/*    */   }
/*    */ 
/*    */   public OnlineUserConfig getOnlineUserConfig() {
/* 51 */     return this.onlineUserConfig;
/*    */   }
/*    */ 
/*    */   public void setOnlineUserConfig(OnlineUserConfig paramOnlineUserConfig) {
/* 55 */     this.onlineUserConfig = paramOnlineUserConfig;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-security.jar
 * Qualified Name:     com.neusoft.unieap.techcomp.security.bootstrap.SecurityActivator
 * JD-Core Version:    0.6.2
 */