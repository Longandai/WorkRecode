/*     */ package com.neusoft.unieap.core;
/*     */ 
/*     */ import com.neusoft.unieap.core.variability.context.CoreVariabilityEntity;
/*     */ import java.io.File;
/*     */ 
/*     */ public class CoreVariability
/*     */ {
/*  15 */   private static CoreVariabilityEntity variabilityEntity = null;
/*     */ 
/*     */   public static void initVariabilityEntity(CoreVariabilityEntity paramCoreVariabilityEntity)
/*     */   {
/*  19 */     if (variabilityEntity == null)
/*  20 */       variabilityEntity = paramCoreVariabilityEntity;
/*     */   }
/*     */ 
/*     */   public static String getDatabaseCharset() {
/*  24 */     return variabilityEntity.getDatabaseCharset();
/*     */   }
/*     */ 
/*     */   public static boolean isValidationEnabled()
/*     */   {
/*  33 */     return variabilityEntity.isValidationEnabled();
/*     */   }
/*     */ 
/*     */   public static boolean isShowStack()
/*     */   {
/*  42 */     return variabilityEntity.isShowStack();
/*     */   }
/*     */ 
/*     */   public static int getGridPageSize()
/*     */   {
/*  51 */     return variabilityEntity.getGridPageSize();
/*     */   }
/*     */ 
/*     */   public static File getUploadFilePath()
/*     */   {
/*  60 */     return variabilityEntity.getUploadFilepath();
/*     */   }
/*     */ 
/*     */   public static boolean isReadTimeFromDB()
/*     */   {
/*  69 */     return variabilityEntity.isReadTimeFromDB();
/*     */   }
/*     */ 
/*     */   public static int getDefaultTimeStyle()
/*     */   {
/*  78 */     return variabilityEntity.getDefaultTimeStyle();
/*     */   }
/*     */ 
/*     */   public static int getDefaultDateStyle()
/*     */   {
/*  87 */     return variabilityEntity.getDefaultDateStyle();
/*     */   }
/*     */ 
/*     */   public static String getDefaultTimeZone()
/*     */   {
/*  96 */     return variabilityEntity.getDefaultTimeZone();
/*     */   }
/*     */ 
/*     */   public static String getDefaultLocaleLanguage()
/*     */   {
/* 105 */     return variabilityEntity.getDefaultLocaleLanguage();
/*     */   }
/*     */ 
/*     */   public static boolean isGlobalEnabled()
/*     */   {
/* 114 */     return variabilityEntity.isGlobalEnabled();
/*     */   }
/*     */ 
/*     */   public static boolean isPrecheckForInteraction()
/*     */   {
/* 132 */     return variabilityEntity.isPrecheckForInteraction();
/*     */   }
/*     */ 
/*     */   public static int getMaxPageSize()
/*     */   {
/* 141 */     return variabilityEntity.getMaxPageSize();
/*     */   }
/*     */ 
/*     */   public static String getSupportLocaleLanguage()
/*     */   {
/* 150 */     return variabilityEntity.getSupportLocaleLanguage();
/*     */   }
/*     */ 
/*     */   public static boolean isUrlPasswordEncrypt()
/*     */   {
/* 159 */     return variabilityEntity.isUrlPasswordEncrypt();
/*     */   }
/*     */ 
/*     */   public static boolean isReadSkinFromCookie()
/*     */   {
/* 168 */     return variabilityEntity.isReadSkinFromCookie();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.CoreVariability
 * JD-Core Version:    0.6.2
 */