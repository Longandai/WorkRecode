/*     */ package com.neusoft.unieap.core.page;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.core.dataSource.DynamicDataSource;
/*     */ import com.neusoft.unieap.core.listener.ContextLoader;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.hibernate.SessionFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.web.context.WebApplicationContext;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public class PageUtil
/*     */ {
/*     */   public static QueryResult getQueryResult()
/*     */   {
/*  31 */     Object localObject = UnieapRequestContextHolder.getRequestContext().get(
/*  32 */       "queryResult");
/*  33 */     if (localObject == null) {
/*  34 */       return null;
/*     */     }
/*  36 */     return (QueryResult)localObject;
/*     */   }
/*     */ 
/*     */   public static void setPageSize(int paramInt)
/*     */   {
/*  46 */     QueryResult localQueryResult = getQueryResult();
/*  47 */     if (localQueryResult != null) {
/*  48 */       ((QueryResult)localQueryResult).setPageSize(paramInt);
/*  49 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  50 */         localQueryResult);
/*     */     } else {
/*  52 */       localQueryResult = new QueryResult();
/*  53 */       ((QueryResult)localQueryResult).setPageSize(paramInt);
/*  54 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  55 */         localQueryResult);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setPageNumber(int paramInt)
/*     */   {
/*  66 */     QueryResult localQueryResult = getQueryResult();
/*  67 */     if (localQueryResult != null) {
/*  68 */       ((QueryResult)localQueryResult).setPageNumber(paramInt);
/*  69 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  70 */         localQueryResult);
/*     */     } else {
/*  72 */       localQueryResult = new QueryResult();
/*  73 */       ((QueryResult)localQueryResult).setPageNumber(paramInt);
/*  74 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  75 */         localQueryResult);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void setAutoCalcCount(boolean paramBoolean)
/*     */   {
/*  86 */     QueryResult localQueryResult = getQueryResult();
/*  87 */     if (localQueryResult != null) {
/*  88 */       ((QueryResult)localQueryResult).setAutoCalcCount(paramBoolean);
/*  89 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  90 */         localQueryResult);
/*     */     } else {
/*  92 */       localQueryResult = new QueryResult();
/*  93 */       ((QueryResult)localQueryResult).setAutoCalcCount(paramBoolean);
/*  94 */       UnieapRequestContextHolder.getRequestContext().put("queryResult", 
/*  95 */         localQueryResult);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static PageContext initPageContext(Class paramClass, String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3, String paramString4, DataSource paramDataSource, SessionFactory paramSessionFactory)
/*     */   {
/* 123 */     PageContext localPageContext = new PageContext();
/*     */ 
/* 126 */     if (!paramClass.getName()
/* 126 */       .equals("com.neusoft.unieap.techcomp.ria.common.query.dao.impl.PageQueryDAOImpl"))
/*     */     {
/* 128 */       String str1 = UniEAPContextHolder.getContext().getCurrentUser()
/* 129 */         .getId();
/* 130 */       StackTraceElement[] arrayOfStackTraceElement = Thread.currentThread().getStackTrace();
/*     */ 
/* 132 */       String str2 = getClassNameExceptBaseHibernateDAO(arrayOfStackTraceElement[3]
/* 133 */         .getClassName(), arrayOfStackTraceElement, 3);
/*     */ 
/* 136 */       String str3 = getMethodNameExceptBaseHibernateDAO(arrayOfStackTraceElement[3]
/* 137 */         .getClassName(), arrayOfStackTraceElement, 3);
/*     */ 
/* 140 */       if ((paramString4 == null) && 
/* 141 */         (ContextLoader.getCurrentWebApplicationContext() != null)) {
/* 142 */         paramString4 = getDataSourceID(paramDataSource);
/*     */       }
/*     */ 
/* 146 */       StringBuilder localStringBuilder = new StringBuilder();
/* 147 */       localStringBuilder.append(str1).append(str2).append(str3).append(
/* 148 */         paramString2);
/* 149 */       if ((paramArrayOfObject != null) && (paramArrayOfObject.length > 0)) {
/* 150 */         localPageContext.setParams(paramArrayOfObject);
/* 151 */         for (int i = 0; i < paramArrayOfObject.length; i++) {
/* 152 */           if (paramArrayOfObject[i] != null)
/* 153 */             localStringBuilder.append(String.valueOf(paramArrayOfObject[i]));
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 158 */         localPageContext.setKey(encrypt(localStringBuilder.toString(), "MD5"));
/*     */       } catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {
/* 160 */         localNoSuchAlgorithmException.printStackTrace();
/*     */       }
/* 162 */       localPageContext.setType(paramString1);
/* 163 */       localPageContext.setQueryString(paramString2);
/* 164 */       if (paramString3 != null) {
/* 165 */         localPageContext.setPojo(paramString3);
/*     */       }
/* 167 */       if (paramString4 != null) {
/* 168 */         localPageContext.setDataSourceID(paramString4);
/*     */       }
/* 170 */       if ((paramSessionFactory != null) && 
/* 171 */         (ContextLoader.getCurrentWebApplicationContext() != null))
/*     */       {
/* 174 */         DefaultListableBeanFactory localDefaultListableBeanFactory = (DefaultListableBeanFactory)
/* 175 */           ContextLoader.getCurrentWebApplicationContext()
/* 176 */           .getAutowireCapableBeanFactory();
/* 177 */         String[] arrayOfString1 = localDefaultListableBeanFactory
/* 178 */           .getBeanNamesForType(paramSessionFactory.getClass());
/* 179 */         if ((arrayOfString1 != null) && 
/* 180 */           (arrayOfString1.length > 0)) {
/* 181 */           for (String str4 : arrayOfString1) {
/* 182 */             if (localDefaultListableBeanFactory.getBean(str4) == paramSessionFactory) {
/* 183 */               localPageContext
/* 184 */                 .setSessionFactoryId(str4);
/* 185 */               break;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 191 */     return localPageContext;
/*     */   }
/*     */ 
/*     */   private static String encrypt(String paramString1, String paramString2)
/*     */     throws NoSuchAlgorithmException
/*     */   {
/* 204 */     MessageDigest localMessageDigest = MessageDigest.getInstance(paramString2);
/* 205 */     localMessageDigest.reset();
/* 206 */     byte[] arrayOfByte1 = paramString1.getBytes();
/* 207 */     byte[] arrayOfByte2 = localMessageDigest.digest(arrayOfByte1);
/* 208 */     BASE64Encoder localBASE64Encoder = new BASE64Encoder();
/* 209 */     return localBASE64Encoder.encode(arrayOfByte2);
/*     */   }
/*     */ 
/*     */   private static String getClassNameExceptBaseHibernateDAO(String paramString, StackTraceElement[] paramArrayOfStackTraceElement, int paramInt)
/*     */   {
/* 215 */     if (paramString
/* 215 */       .equals("com.neusoft.unieap.core.base.dao.BaseHibernateDAO")) {
/* 216 */       paramInt++;
/* 217 */       paramString = paramArrayOfStackTraceElement[paramInt].getClassName();
/* 218 */       return getClassNameExceptBaseHibernateDAO(paramString, paramArrayOfStackTraceElement, paramInt);
/*     */     }
/* 220 */     return paramString;
/*     */   }
/*     */ 
/*     */   private static String getMethodNameExceptBaseHibernateDAO(String paramString, StackTraceElement[] paramArrayOfStackTraceElement, int paramInt)
/*     */   {
/* 227 */     if (paramString
/* 227 */       .equals("com.neusoft.unieap.core.base.dao.BaseHibernateDAO")) {
/* 228 */       paramInt++;
/* 229 */       paramString = paramArrayOfStackTraceElement[paramInt].getClassName();
/* 230 */       return getMethodNameExceptBaseHibernateDAO(paramString, paramArrayOfStackTraceElement, paramInt);
/*     */     }
/* 232 */     return paramArrayOfStackTraceElement[paramInt].getMethodName();
/*     */   }
/*     */ 
/*     */   private static String getDataSourceID(DataSource paramDataSource)
/*     */   {
/* 243 */     String str1 = null;
/*     */ 
/* 245 */     if ((paramDataSource == null) || ((paramDataSource instanceof DynamicDataSource))) {
/* 246 */       return str1;
/*     */     }
/* 248 */     DefaultListableBeanFactory localDefaultListableBeanFactory = (DefaultListableBeanFactory)
/* 249 */       ContextLoader.getCurrentWebApplicationContext()
/* 250 */       .getAutowireCapableBeanFactory();
/*     */ 
/* 252 */     Map localMap = 
/* 253 */       DataSourceContextHolder.getDataSources();
/* 254 */     if (!localMap.isEmpty()) {
/* 255 */       Set localSet = localMap.keySet();
/* 256 */       Iterator localIterator = localSet.iterator();
/* 257 */       while (localIterator.hasNext()) {
/* 258 */         String str2 = localIterator.next().toString();
/* 259 */         if (paramDataSource.equals(localDefaultListableBeanFactory.getBean(str2))) {
/* 260 */           str1 = (String)localMap.get(str2);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 265 */     return str1;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.PageUtil
 * JD-Core Version:    0.6.2
 */