package com.neusoft.unieap.core.page;

import java.util.List;

public abstract interface PageResult
{
  public abstract List getResultSet();

  public abstract long getTotalCount();

  public abstract long getTotalPage();

  public abstract Page getPage();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.PageResult
 * JD-Core Version:    0.6.2
 */