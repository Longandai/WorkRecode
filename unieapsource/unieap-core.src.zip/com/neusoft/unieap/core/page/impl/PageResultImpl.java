/*    */ package com.neusoft.unieap.core.page.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.page.Page;
/*    */ import com.neusoft.unieap.core.page.PageResult;
/*    */ import java.util.List;
/*    */ 
/*    */ public class PageResultImpl
/*    */   implements PageResult
/*    */ {
/*  9 */   private Page page = null;
/* 10 */   private List resultSet = null;
/* 11 */   private long totalCount = 0L;
/* 12 */   private long totalPage = 0L;
/*    */ 
/*    */   public Page getPage() {
/* 15 */     return this.page;
/*    */   }
/*    */   public long getTotalPage() {
/* 18 */     return this.totalPage;
/*    */   }
/*    */ 
/*    */   public Page setPage(Page paramPage) {
/* 22 */     return this.page = paramPage;
/*    */   }
/*    */   public void setTotalPage(long paramLong) {
/* 25 */     this.totalPage = paramLong;
/*    */   }
/*    */   public List getResultSet() {
/* 28 */     return this.resultSet;
/*    */   }
/*    */   public long getTotalCount() {
/* 31 */     return this.totalCount;
/*    */   }
/*    */   public void setResultSet(List paramList) {
/* 34 */     this.resultSet = paramList;
/*    */   }
/*    */ 
/*    */   public void setTotalCount(long paramLong) {
/* 38 */     this.totalCount = paramLong;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.impl.PageResultImpl
 * JD-Core Version:    0.6.2
 */