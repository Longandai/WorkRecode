/*    */ package com.neusoft.unieap.core.page;
/*    */ 
/*    */ public class PageInfo
/*    */ {
/*    */   private int pageNumber;
/*    */   private int pageSize;
/* 12 */   private boolean autoCalcCount = false;
/*    */ 
/*    */   public void setPageNumber(int paramInt) {
/* 15 */     this.pageNumber = paramInt;
/*    */   }
/*    */ 
/*    */   public int getPageNumber() {
/* 19 */     return this.pageNumber;
/*    */   }
/*    */ 
/*    */   public void setPageSize(int paramInt) {
/* 23 */     this.pageSize = paramInt;
/*    */   }
/*    */ 
/*    */   public int getPageSize() {
/* 27 */     return this.pageSize;
/*    */   }
/*    */ 
/*    */   public void setAutoCalcCount(boolean paramBoolean) {
/* 31 */     this.autoCalcCount = paramBoolean;
/*    */   }
/*    */ 
/*    */   public boolean isAutoCalcCount() {
/* 35 */     return this.autoCalcCount;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.PageInfo
 * JD-Core Version:    0.6.2
 */