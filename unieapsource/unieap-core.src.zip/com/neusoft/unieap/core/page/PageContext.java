/*    */ package com.neusoft.unieap.core.page;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class PageContext
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String key;
/*    */   private String type;
/*    */   private String queryString;
/*    */   private Object[] params;
/*    */   private String pojo;
/*    */   private String dataSourceID;
/*    */   private String sessionFactoryId;
/*    */ 
/*    */   public String getSessionFactoryId()
/*    */   {
/* 42 */     return this.sessionFactoryId;
/*    */   }
/*    */ 
/*    */   public void setSessionFactoryId(String paramString) {
/* 46 */     this.sessionFactoryId = paramString;
/*    */   }
/*    */ 
/*    */   public String getKey() {
/* 50 */     return this.key;
/*    */   }
/*    */ 
/*    */   public void setKey(String paramString) {
/* 54 */     this.key = paramString;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 58 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String paramString) {
/* 62 */     this.type = paramString;
/*    */   }
/*    */ 
/*    */   public void setQueryString(String paramString) {
/* 66 */     this.queryString = paramString;
/*    */   }
/*    */ 
/*    */   public String getQueryString() {
/* 70 */     return this.queryString;
/*    */   }
/*    */ 
/*    */   public Object[] getParams() {
/* 74 */     return this.params;
/*    */   }
/*    */ 
/*    */   public void setParams(Object[] paramArrayOfObject) {
/* 78 */     this.params = paramArrayOfObject;
/*    */   }
/*    */ 
/*    */   public void setPojo(String paramString) {
/* 82 */     this.pojo = paramString;
/*    */   }
/*    */ 
/*    */   public String getPojo() {
/* 86 */     return this.pojo;
/*    */   }
/*    */ 
/*    */   public void setDataSourceID(String paramString) {
/* 90 */     this.dataSourceID = paramString;
/*    */   }
/*    */ 
/*    */   public String getDataSourceID() {
/* 94 */     return this.dataSourceID;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.PageContext
 * JD-Core Version:    0.6.2
 */