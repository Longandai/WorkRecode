package com.neusoft.unieap.core.page;

import java.io.Serializable;

public abstract interface Order extends Serializable
{
  public abstract String getPropertyName();

  public abstract String getOrderStyle();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.page.Order
 * JD-Core Version:    0.6.2
 */