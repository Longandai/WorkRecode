/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ public class VarValueUpdateEvent extends UniEAPEvent
/*    */ {
/*    */   private static final long serialVersionUID = 5446267215211486383L;
/*    */   private String parameterCode;
/*    */   private String value;
/*    */   private String userId;
/*    */ 
/*    */   public VarValueUpdateEvent(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 12 */     this.parameterCode = paramString1;
/* 13 */     this.value = paramString2;
/* 14 */     this.userId = paramString3;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 18 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public String getParameterCode() {
/* 22 */     return this.parameterCode;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 26 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setParameterCode(String paramString) {
/* 30 */     this.parameterCode = paramString;
/*    */   }
/*    */ 
/*    */   public void setValue(String paramString) {
/* 34 */     this.value = paramString;
/*    */   }
/*    */ 
/*    */   public void setUserId(String paramString) {
/* 38 */     this.userId = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.VarValueUpdateEvent
 * JD-Core Version:    0.6.2
 */