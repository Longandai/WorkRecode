/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ public class HostInfoEvent extends ApplicationEvent
/*    */ {
/*    */   private String computerName;
/*    */   private String ipAddress;
/*    */   private String mac;
/*    */ 
/*    */   public HostInfoEvent(Object paramObject, String paramString1, String paramString2, String paramString3)
/*    */   {
/* 14 */     super(paramObject);
/* 15 */     this.computerName = paramString1;
/* 16 */     this.ipAddress = paramString2;
/* 17 */     this.mac = paramString3;
/*    */   }
/*    */ 
/*    */   public void setComputerName(String paramString) {
/* 21 */     this.computerName = paramString;
/*    */   }
/*    */ 
/*    */   public String getComputerName() {
/* 25 */     return this.computerName;
/*    */   }
/*    */ 
/*    */   public void setIpAddress(String paramString) {
/* 29 */     this.ipAddress = paramString;
/*    */   }
/*    */ 
/*    */   public String getIpAddress() {
/* 33 */     return this.ipAddress;
/*    */   }
/*    */ 
/*    */   public void setMac(String paramString) {
/* 37 */     this.mac = paramString;
/*    */   }
/*    */ 
/*    */   public String getMac() {
/* 41 */     return this.mac;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.HostInfoEvent
 * JD-Core Version:    0.6.2
 */