/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class AttemptAuthenticationEvent extends UniEAPEvent
/*    */ {
/*    */   private static final long serialVersionUID = -2091260645221735644L;
/*    */   private String account;
/*    */   private HttpServletRequest request;
/*    */ 
/*    */   public AttemptAuthenticationEvent(String paramString, HttpServletRequest paramHttpServletRequest)
/*    */   {
/* 12 */     this.account = paramString;
/* 13 */     this.request = paramHttpServletRequest;
/*    */   }
/*    */ 
/*    */   public String getAccount() {
/* 17 */     return this.account;
/*    */   }
/*    */ 
/*    */   public HttpServletRequest getHttpServletRequest() {
/* 21 */     return this.request;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.AttemptAuthenticationEvent
 * JD-Core Version:    0.6.2
 */