/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ public class UserDeleteEvent extends UniEAPEvent
/*    */ {
/*    */   private static final long serialVersionUID = -3241864663781010947L;
/*    */   private String userId;
/*    */ 
/*    */   public UserDeleteEvent(String paramString)
/*    */   {
/* 12 */     this.userId = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 16 */     return this.userId;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.UserDeleteEvent
 * JD-Core Version:    0.6.2
 */