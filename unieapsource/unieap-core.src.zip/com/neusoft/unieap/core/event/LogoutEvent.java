/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.Audit;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ @Audit("logout")
/*    */ public class LogoutEvent extends UniEAPEvent
/*    */ {
/*    */   private static final long serialVersionUID = 4934962058696867767L;
/*    */   private User user;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */ 
/*    */   public LogoutEvent(User paramUser, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse)
/*    */   {
/* 19 */     this.user = paramUser;
/* 20 */     this.request = paramHttpServletRequest;
/* 21 */     this.response = paramHttpServletResponse;
/*    */   }
/*    */ 
/*    */   public User getUser() {
/* 25 */     return this.user;
/*    */   }
/*    */ 
/*    */   public HttpServletRequest getHttpServletRequest() {
/* 29 */     return this.request;
/*    */   }
/*    */ 
/*    */   public HttpServletResponse getHttpServletResponse() {
/* 33 */     return this.response;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.LogoutEvent
 * JD-Core Version:    0.6.2
 */