/*    */ package com.neusoft.unieap.core.event.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.event.UniEAPEvent;
/*    */ import com.neusoft.unieap.core.event.UniEAPEventPublisher;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ 
/*    */ public class UniEAPEventPublisherImpl
/*    */   implements UniEAPEventPublisher, ApplicationContextAware
/*    */ {
/*    */   private ApplicationContext context;
/*    */ 
/*    */   public void publish(UniEAPEvent paramUniEAPEvent)
/*    */   {
/* 16 */     this.context.publishEvent(paramUniEAPEvent);
/*    */   }
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext paramApplicationContext) throws BeansException
/*    */   {
/* 21 */     this.context = paramApplicationContext;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.impl.UniEAPEventPublisherImpl
 * JD-Core Version:    0.6.2
 */