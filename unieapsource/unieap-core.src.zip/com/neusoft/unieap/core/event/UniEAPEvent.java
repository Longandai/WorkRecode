/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ 
/*    */ public abstract class UniEAPEvent extends ApplicationEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public UniEAPEvent()
/*    */   {
/*  8 */     super(new Object());
/*    */   }
/*    */ 
/*    */   public UniEAPEvent(Object paramObject) {
/* 12 */     super(paramObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.UniEAPEvent
 * JD-Core Version:    0.6.2
 */