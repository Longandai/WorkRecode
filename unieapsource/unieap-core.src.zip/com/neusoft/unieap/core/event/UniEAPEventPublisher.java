package com.neusoft.unieap.core.event;

public abstract interface UniEAPEventPublisher
{
  public abstract void publish(UniEAPEvent paramUniEAPEvent);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.UniEAPEventPublisher
 * JD-Core Version:    0.6.2
 */