/*    */ package com.neusoft.unieap.core.event;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.Audit;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ @Audit("loginFail")
/*    */ public class UnsuccessfulAuthenticationEvent extends UniEAPEvent
/*    */ {
/*    */   private static final long serialVersionUID = 4934962058696867767L;
/*    */   private String account;
/*    */   private HttpServletRequest request;
/*    */   private HttpServletResponse response;
/*    */   private Exception failed;
/*    */ 
/*    */   public UnsuccessfulAuthenticationEvent(String paramString, HttpServletRequest paramHttpServletRequest, HttpServletResponse paramHttpServletResponse, Exception paramException)
/*    */   {
/* 20 */     this.account = paramString;
/* 21 */     this.request = paramHttpServletRequest;
/* 22 */     this.response = paramHttpServletResponse;
/* 23 */     this.failed = paramException;
/*    */   }
/*    */ 
/*    */   public String getAccount() {
/* 27 */     return this.account;
/*    */   }
/*    */ 
/*    */   public HttpServletRequest getHttpServletRequest() {
/* 31 */     return this.request;
/*    */   }
/*    */ 
/*    */   public HttpServletResponse getHttpServletResponse() {
/* 35 */     return this.response;
/*    */   }
/*    */ 
/*    */   public Exception getFailed() {
/* 39 */     return this.failed;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.event.UnsuccessfulAuthenticationEvent
 * JD-Core Version:    0.6.2
 */