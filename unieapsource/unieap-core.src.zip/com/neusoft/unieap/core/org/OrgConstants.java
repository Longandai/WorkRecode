package com.neusoft.unieap.core.org;

public class OrgConstants
{
  public static final String DEFAULT_DIMENSION_ID = "defaultDimension";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.org.OrgConstants
 * JD-Core Version:    0.6.2
 */