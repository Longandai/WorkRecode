/*     */ package com.neusoft.unieap.core.usertype;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.type.NullableType;
/*     */ import org.hibernate.type.TypeFactory;
/*     */ import org.hibernate.usertype.ParameterizedType;
/*     */ import org.hibernate.usertype.UserType;
/*     */ 
/*     */ public class GenericEnumUserType
/*     */   implements UserType, ParameterizedType
/*     */ {
/*     */   private static final String DEFAULT_IDENTIFIER_METHOD_NAME = "name";
/*     */   private static final String DEFAULT_VALUE_OF_METHOD_NAME = "valueOf";
/*     */   private Class<? extends Enum> enumClass;
/*     */   private Class<?> identifierType;
/*     */   private Method identifierMethod;
/*     */   private Method valueOfMethod;
/*     */   private NullableType type;
/*     */   private int[] sqlTypes;
/*     */ 
/*     */   public void setParameterValues(Properties paramProperties)
/*     */   {
/*  85 */     String str1 = paramProperties.getProperty("enumClass");
/*     */     try {
/*  87 */       this.enumClass = Class.forName(str1).asSubclass(Enum.class);
/*     */     } catch (ClassNotFoundException localClassNotFoundException) {
/*  89 */       throw new HibernateException("Enum class not found", localClassNotFoundException);
/*     */     }
/*     */ 
/*  92 */     String str2 = paramProperties.getProperty(
/*  93 */       "identifierMethod", "name");
/*     */     try
/*     */     {
/*  96 */       this.identifierMethod = this.enumClass.getMethod(str2, 
/*  97 */         new Class[0]);
/*  98 */       this.identifierType = this.identifierMethod.getReturnType();
/*     */     } catch (Exception localException1) {
/* 100 */       throw new HibernateException("Failed to obtain identifier method", 
/* 101 */         localException1);
/*     */     }
/*     */ 
/* 104 */     this.type = ((NullableType)TypeFactory.basic(this.identifierType.getName()));
/*     */ 
/* 106 */     if (this.type == null) {
/* 107 */       throw new HibernateException("Unsupported identifier type " + 
/* 108 */         this.identifierType.getName());
/*     */     }
/* 110 */     this.sqlTypes = new int[] { this.type.sqlType() };
/*     */ 
/* 112 */     String str3 = paramProperties.getProperty("valueOfMethod", 
/* 113 */       "valueOf");
/*     */     try
/*     */     {
/* 116 */       this.valueOfMethod = this.enumClass.getMethod(str3, 
/* 117 */         new Class[] { this.identifierType });
/*     */     } catch (Exception localException2) {
/* 119 */       throw new HibernateException("Failed to obtain valueOf method", localException2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> returnedClass() {
/* 124 */     return this.enumClass;
/*     */   }
/*     */ 
/*     */   public Object nullSafeGet(ResultSet paramResultSet, String[] paramArrayOfString, Object paramObject) throws HibernateException, SQLException
/*     */   {
/* 129 */     Object localObject = this.type.get(paramResultSet, paramArrayOfString[0]);
/* 130 */     if (localObject == null) {
/* 131 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 135 */       return this.valueOfMethod.invoke(this.enumClass, new Object[] { localObject });
/*     */     } catch (Exception localException) {
/* 137 */       throw new HibernateException(
/* 138 */         "Exception while invoking valueOf method '" + 
/* 139 */         this.valueOfMethod.getName() + "' of " + 
/* 140 */         "enumeration class '" + this.enumClass + "'", localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void nullSafeSet(PreparedStatement paramPreparedStatement, Object paramObject, int paramInt) throws HibernateException, SQLException
/*     */   {
/*     */     try {
/* 147 */       if (paramObject == null) {
/* 148 */         paramPreparedStatement.setNull(paramInt, this.type.sqlType());
/*     */       } else {
/* 150 */         Object localObject = this.identifierMethod.invoke(paramObject, 
/* 151 */           new Object[0]);
/* 152 */         this.type.set(paramPreparedStatement, localObject, paramInt);
/*     */       }
/*     */     } catch (Exception localException) {
/* 155 */       throw new HibernateException(
/* 156 */         "Exception while invoking identifierMethod '" + 
/* 157 */         this.identifierMethod.getName() + "' of " + 
/* 158 */         "enumeration class '" + this.enumClass + "'", localException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int[] sqlTypes() {
/* 163 */     return this.sqlTypes;
/*     */   }
/*     */ 
/*     */   public Object assemble(Serializable paramSerializable, Object paramObject) throws HibernateException
/*     */   {
/* 168 */     return paramSerializable;
/*     */   }
/*     */ 
/*     */   public Object deepCopy(Object paramObject) throws HibernateException {
/* 172 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public Serializable disassemble(Object paramObject) throws HibernateException {
/* 176 */     return (Serializable)paramObject;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object paramObject1, Object paramObject2) throws HibernateException {
/* 180 */     return paramObject1 == paramObject2;
/*     */   }
/*     */ 
/*     */   public int hashCode(Object paramObject) throws HibernateException {
/* 184 */     return paramObject.hashCode();
/*     */   }
/*     */ 
/*     */   public boolean isMutable() {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   public Object replace(Object paramObject1, Object paramObject2, Object paramObject3) throws HibernateException
/*     */   {
/* 193 */     return paramObject1;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.usertype.GenericEnumUserType
 * JD-Core Version:    0.6.2
 */