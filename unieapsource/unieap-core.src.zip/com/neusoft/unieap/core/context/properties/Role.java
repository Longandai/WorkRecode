/*    */ package com.neusoft.unieap.core.context.properties;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Role
/*    */   implements Serializable
/*    */ {
/*    */   private String id;
/*    */   private String name;
/*    */   private String type;
/*    */ 
/*    */   public void setType(String paramString)
/*    */   {
/* 16 */     this.type = paramString;
/*    */   }
/*    */ 
/*    */   public String getType()
/*    */   {
/* 24 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString)
/*    */   {
/* 32 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 40 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 48 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 56 */     return this.id;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.properties.Role
 * JD-Core Version:    0.6.2
 */