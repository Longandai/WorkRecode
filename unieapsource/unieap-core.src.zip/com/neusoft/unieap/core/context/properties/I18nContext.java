/*     */ package com.neusoft.unieap.core.context.properties;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class I18nContext
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3780163500620117978L;
/*  17 */   private Locale locale = Locale.getDefault();
/*     */ 
/*  19 */   private String area = "";
/*     */ 
/*  21 */   private TimeZone timeZone = TimeZone.getDefault();
/*     */ 
/*  23 */   private int dateStyle = 2;
/*     */ 
/*  25 */   private int timeStyle = 2;
/*     */ 
/*     */   public Locale getLocale()
/*     */   {
/*  31 */     return this.locale;
/*     */   }
/*     */ 
/*     */   public void setLocale(Locale paramLocale)
/*     */   {
/*  38 */     this.locale = paramLocale;
/*     */   }
/*     */ 
/*     */   public String getArea()
/*     */   {
/*  46 */     return this.area;
/*     */   }
/*     */ 
/*     */   public void setArea(String paramString)
/*     */   {
/*  54 */     this.area = paramString;
/*     */   }
/*     */ 
/*     */   public TimeZone getTimeZone()
/*     */   {
/*  61 */     return this.timeZone;
/*     */   }
/*     */ 
/*     */   public void setTimeZone(TimeZone paramTimeZone)
/*     */   {
/*  68 */     this.timeZone = paramTimeZone;
/*     */   }
/*     */ 
/*     */   public int getDateStyle()
/*     */   {
/*  76 */     return this.dateStyle;
/*     */   }
/*     */ 
/*     */   public void setDateStyle(int paramInt)
/*     */   {
/*  90 */     this.dateStyle = paramInt;
/*     */   }
/*     */ 
/*     */   public int getTimeStyle()
/*     */   {
/*  97 */     return this.timeStyle;
/*     */   }
/*     */ 
/*     */   public void setTimeStyle(int paramInt)
/*     */   {
/* 111 */     this.timeStyle = paramInt;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.properties.I18nContext
 * JD-Core Version:    0.6.2
 */