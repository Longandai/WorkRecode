/*     */ package com.neusoft.unieap.core.context.properties;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class User
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1556733517405587688L;
/*     */   private String id;
/*     */   private String account;
/*     */   private String name;
/*     */   private String password;
/*     */   private Boolean accountLocked;
/*     */   private Boolean accountEnabled;
/*     */   private List roles;
/*     */   private String type;
/*     */ 
/*     */   public List getRoles(String paramString)
/*     */   {
/*  42 */     ArrayList localArrayList = new ArrayList();
/*  43 */     if (this.roles == null) return null;
/*     */ 
/*  45 */     for (int i = 0; i < this.roles.size(); i++) {
/*  46 */       if ((paramString.equals("orgAdminRole")) || 
/*  47 */         (paramString.equals("secAdminRole"))) {
/*  48 */         if ((((Role)this.roles.get(i)).getType().equals(paramString)) || 
/*  49 */           (((Role)this.roles.get(i)).getType().equals("superAdminRole"))) {
/*  50 */           localArrayList.add(this.roles.get(i));
/*     */         }
/*     */       }
/*  53 */       else if (((Role)this.roles.get(i)).getType().equals(paramString)) {
/*  54 */         localArrayList.add((Role)this.roles.get(i));
/*     */       }
/*     */     }
/*     */ 
/*  58 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRoles(List paramList)
/*     */   {
/*  67 */     if (this.roles == null) return null;
/*     */ 
/*  69 */     ArrayList localArrayList = new ArrayList();
/*  70 */     for (int i = 0; i < this.roles.size(); i++) {
/*  71 */       for (int j = 0; j < paramList.size(); j++) {
/*  72 */         String str = paramList.get(j).toString();
/*  73 */         if ((str.equals("orgAdminRole")) || 
/*  74 */           (str.equals("secAdminRole"))) {
/*  75 */           if ((((Role)this.roles.get(i)).getType().equals(str)) || 
/*  76 */             (((Role)this.roles.get(i)).getType().equals("superAdminRole"))) {
/*  77 */             localArrayList.add(this.roles.get(i));
/*     */           }
/*     */         }
/*  80 */         else if (((Role)this.roles.get(i)).getType().equals(str)) {
/*  81 */           localArrayList.add((Role)this.roles.get(i));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  86 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRoleIds()
/*     */   {
/*  94 */     if (this.roles == null) return null;
/*  95 */     ArrayList localArrayList = new ArrayList();
/*  96 */     for (int i = 0; i < this.roles.size(); i++) {
/*  97 */       localArrayList.add(((Role)this.roles.get(i)).getId());
/*     */     }
/*  99 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRoleIds(String paramString)
/*     */   {
/* 108 */     if (this.roles == null) return null;
/*     */ 
/* 110 */     ArrayList localArrayList = new ArrayList();
/* 111 */     for (int i = 0; i < this.roles.size(); i++) {
/* 112 */       if ((paramString.equals("orgAdminRole")) || 
/* 113 */         (paramString.equals("secAdminRole"))) {
/* 114 */         if ((((Role)this.roles.get(i)).getType().equals(paramString)) || 
/* 115 */           (((Role)this.roles.get(i)).getType().equals("superAdminRole"))) {
/* 116 */           localArrayList.add(((Role)this.roles.get(i)).getId());
/*     */         }
/*     */       }
/* 119 */       else if (((Role)this.roles.get(i)).getType().equals(paramString)) {
/* 120 */         localArrayList.add(((Role)this.roles.get(i)).getId());
/*     */       }
/*     */     }
/*     */ 
/* 124 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public List getRoleTypes()
/*     */   {
/* 132 */     ArrayList localArrayList = new ArrayList();
/* 133 */     for (int i = 0; i < this.roles.size(); i++) {
/* 134 */       localArrayList.add(((Role)this.roles.get(i)).getType());
/*     */     }
/* 136 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public String getAdminRoleType()
/*     */   {
/* 144 */     String str = null;
/* 145 */     for (int i = 0; i < this.roles.size(); i++) {
/* 146 */       str = ((Role)this.roles.get(i)).getType();
/* 147 */       if ((str.indexOf("secAdminRole") >= 0) || 
/* 148 */         (str.indexOf("superAdminRole") >= 0) || 
/* 149 */         (str.indexOf("orgAdminRole") >= 0)) {
/* 150 */         return str;
/*     */       }
/*     */     }
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   public List getBusiRoleTypes()
/*     */   {
/* 161 */     ArrayList localArrayList = new ArrayList();
/* 162 */     String str = null;
/* 163 */     for (int i = 0; i < this.roles.size(); i++) {
/* 164 */       str = ((Role)this.roles.get(i)).getType();
/* 165 */       if ((str.indexOf("secAdminRole") < 0) && 
/* 166 */         (str.indexOf("superAdminRole") < 0) && 
/* 167 */         (str.indexOf("orgAdminRole") < 0)) {
/* 168 */         localArrayList.add(str);
/*     */       }
/*     */     }
/* 171 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 179 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString)
/*     */   {
/* 187 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public String getAccount()
/*     */   {
/* 195 */     return this.account;
/*     */   }
/*     */ 
/*     */   public void setAccount(String paramString)
/*     */   {
/* 203 */     this.account = paramString;
/*     */   }
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/* 211 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/* 219 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setPassword(String paramString)
/*     */   {
/* 227 */     this.password = paramString;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 235 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setAccountLocked(Boolean paramBoolean)
/*     */   {
/* 243 */     this.accountLocked = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getAccountLocked()
/*     */   {
/* 251 */     return this.accountLocked;
/*     */   }
/*     */ 
/*     */   public void setAccountEnabled(Boolean paramBoolean)
/*     */   {
/* 259 */     this.accountEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Boolean getAccountEnabled()
/*     */   {
/* 267 */     return this.accountEnabled;
/*     */   }
/*     */ 
/*     */   public void setRoles(List paramList)
/*     */   {
/* 275 */     this.roles = paramList;
/*     */   }
/*     */ 
/*     */   public List getRoles()
/*     */   {
/* 283 */     return this.roles;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/* 295 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(String paramString)
/*     */   {
/* 307 */     this.type = paramString;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.properties.User
 * JD-Core Version:    0.6.2
 */