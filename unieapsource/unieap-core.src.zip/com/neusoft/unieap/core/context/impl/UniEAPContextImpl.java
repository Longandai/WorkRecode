/*    */ package com.neusoft.unieap.core.context.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UniEAPContextImpl
/*    */   implements UniEAPContext
/*    */ {
/*    */   private User currentUser;
/* 23 */   private Map customProperties = new HashMap();
/*    */ 
/*    */   public UniEAPContextImpl() {
/* 26 */     this.currentUser = new User();
/*    */   }
/*    */ 
/*    */   public User getCurrentUser()
/*    */   {
/* 35 */     return this.currentUser;
/*    */   }
/*    */ 
/*    */   public void addCustomProperty(Object paramObject1, Object paramObject2)
/*    */   {
/* 42 */     this.customProperties.put(paramObject1, paramObject2);
/*    */   }
/*    */ 
/*    */   public Object getCustomProperty(Object paramObject)
/*    */   {
/* 49 */     return this.customProperties.get(paramObject);
/*    */   }
/*    */ 
/*    */   public void removeCustomProperty(Object paramObject)
/*    */   {
/* 56 */     this.customProperties.remove(paramObject);
/*    */   }
/*    */ 
/*    */   public void removeAllCustomProperties()
/*    */   {
/* 63 */     this.customProperties.clear();
/*    */   }
/*    */ 
/*    */   public void removeCurrentUser()
/*    */   {
/* 70 */     this.currentUser.setId(null);
/* 71 */     this.currentUser.setName(null);
/* 72 */     this.currentUser.setAccount(null);
/* 73 */     this.currentUser.setRoles(null);
/*    */   }
/*    */ 
/*    */   public Map getCustomProperties()
/*    */   {
/* 80 */     return this.customProperties;
/*    */   }
/*    */ 
/*    */   public void setCustomProperties(Map paramMap)
/*    */   {
/* 87 */     this.customProperties = paramMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.impl.UniEAPContextImpl
 * JD-Core Version:    0.6.2
 */