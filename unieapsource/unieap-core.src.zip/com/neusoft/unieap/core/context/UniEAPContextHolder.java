/*    */ package com.neusoft.unieap.core.context;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.impl.UniEAPContextImpl;
/*    */ 
/*    */ public class UniEAPContextHolder
/*    */ {
/* 18 */   private static ThreadLocal contextHolder = new ThreadLocal();
/*    */ 
/*    */   public static void setContext(UniEAPContext paramUniEAPContext)
/*    */   {
/* 39 */     contextHolder.set(paramUniEAPContext);
/*    */   }
/*    */ 
/*    */   public static UniEAPContext getContext()
/*    */   {
/* 59 */     Object localObject = (UniEAPContext)contextHolder.get();
/* 60 */     if (localObject == null) {
/* 61 */       localObject = new UniEAPContextImpl();
/* 62 */       setContext((UniEAPContext)localObject);
/*    */     }
/* 64 */     return localObject;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.UniEAPContextHolder
 * JD-Core Version:    0.6.2
 */