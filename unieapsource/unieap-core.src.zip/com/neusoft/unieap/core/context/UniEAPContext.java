package com.neusoft.unieap.core.context;

import com.neusoft.unieap.core.context.properties.User;
import java.io.Serializable;
import java.util.Map;

public abstract interface UniEAPContext extends Serializable
{
  public static final String UNIEAP_CONTEXT_KEY = "com.neusoft.unieap.core.context.UniEAPContext";

  public abstract User getCurrentUser();

  public abstract void addCustomProperty(Object paramObject1, Object paramObject2);

  public abstract Object getCustomProperty(Object paramObject);

  public abstract void removeCustomProperty(Object paramObject);

  public abstract void removeAllCustomProperties();

  public abstract void removeCurrentUser();

  public abstract Map getCustomProperties();

  public abstract void setCustomProperties(Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.UniEAPContext
 * JD-Core Version:    0.6.2
 */