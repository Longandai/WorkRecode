/*    */ package com.neusoft.unieap.core.context;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class UnieapRequestContextHolder
/*    */ {
/*  7 */   private static final ThreadLocal contextHolder = new ThreadLocal();
/*    */ 
/*    */   public static void setRequestContext(Map paramMap)
/*    */   {
/* 11 */     contextHolder.set(paramMap);
/*    */   }
/*    */ 
/*    */   public static Map getRequestContext()
/*    */   {
/* 19 */     Object localObject = (Map)contextHolder.get();
/* 20 */     if (localObject == null) {
/* 21 */       localObject = new HashMap();
/* 22 */       setRequestContext((Map)localObject);
/*    */     }
/* 24 */     return localObject;
/*    */   }
/*    */ 
/*    */   public static void clearPojoContext() {
/* 28 */     contextHolder.set(null);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.context.UnieapRequestContextHolder
 * JD-Core Version:    0.6.2
 */