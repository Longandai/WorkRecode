/*    */ package com.neusoft.unieap.core.fileupload;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class FileUploadException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = -8068384102943206140L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */ 
/*    */   public FileUploadException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 18 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public FileUploadException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 29 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fileupload.FileUploadException
 * JD-Core Version:    0.6.2
 */