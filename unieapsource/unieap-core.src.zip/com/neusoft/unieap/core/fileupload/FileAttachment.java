package com.neusoft.unieap.core.fileupload;

import java.io.InputStream;
import java.io.Serializable;

public abstract interface FileAttachment extends Serializable
{
  public static final String REQUEST_ATTRIBUTE_NAME = "UNIEAP_FILEATTACHMENT";

  public abstract String getName();

  public abstract byte[] getBytes();

  public abstract InputStream getInputStream();

  public abstract long getSize();

  public abstract String getFileName();

  public abstract String getContextType();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fileupload.FileAttachment
 * JD-Core Version:    0.6.2
 */