/*     */ package com.neusoft.unieap.core.fileupload.interceptor;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileUploadException;
/*     */ import com.neusoft.unieap.core.fileupload.impl.FileAttachmentImpl;
/*     */ import com.neusoft.unieap.core.statement.util.StringUtil;
/*     */ import com.opensymphony.xwork2.ActionContext;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.inject.Inject;
/*     */ import com.opensymphony.xwork2.interceptor.MethodFilterInterceptor;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class FileUploadInterceptor extends MethodFilterInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = -4764627478894962479L;
/*  32 */   private String maxFileSize = null;
/*     */ 
/*  34 */   private String processorFileSize = null;
/*     */ 
/*     */   @Inject("struts.multipart.maxSize")
/*     */   public void setMaxFileSize(String paramString)
/*     */   {
/*  39 */     this.maxFileSize = paramString;
/*     */   }
/*     */ 
/*     */   public String doIntercept(ActionInvocation paramActionInvocation) throws Exception
/*     */   {
/*  44 */     ActionContext localActionContext = paramActionInvocation.getInvocationContext();
/*  45 */     HttpServletRequest localHttpServletRequest = (HttpServletRequest)localActionContext
/*  46 */       .get("com.opensymphony.xwork2.dispatcher.HttpServletRequest");
/*  47 */     if (!(localHttpServletRequest instanceof MultiPartRequestWrapper))
/*     */     {
/*  49 */       return paramActionInvocation.invoke();
/*     */     }
/*     */ 
/*  60 */     MultiPartRequestWrapper localMultiPartRequestWrapper = (MultiPartRequestWrapper)localHttpServletRequest;
/*  61 */     if (localMultiPartRequestWrapper.hasErrors())
/*     */     {
/*  63 */       localObject1 = new StringBuffer();
/*  64 */       localObject2 = localMultiPartRequestWrapper.getErrors().iterator();
/*  65 */       while (((Iterator)localObject2).hasNext()) {
/*  66 */         ((StringBuffer)localObject1).append((String)((Iterator)localObject2).next());
/*  67 */         ((StringBuffer)localObject1).append("\n");
/*     */       }
/*     */ 
/*  70 */       if (((StringBuffer)localObject1).toString().contains("exceeds the configured maximum"))
/*  71 */         handleFileExceededException(this.maxFileSize);
/*     */       else {
/*  73 */         throw new FileUploadException(
/*  74 */           "EAPTECH003700", 
/*  75 */           new String[] { ((StringBuffer)localObject1).toString() });
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  80 */     Object localObject1 = localMultiPartRequestWrapper.getParameter("dc");
/*  81 */     Object localObject2 = JSONObject.fromObject(localObject1);
/*     */     Object localObject3;
/*     */     Object localObject4;
/*  82 */     if (!((JSONObject)localObject2).isNullObject()) {
/*  83 */       localObject3 = ((JSONObject)localObject2).getJSONObject("body")
/*  84 */         .getJSONObject("parameters");
/*  85 */       localObject4 = ((JSONObject)localObject3).get("fileSize");
/*  86 */       if ((localObject4 == null) || (
/*  87 */         ((localObject4 instanceof JSONObject)) && 
/*  88 */         (((JSONObject)localObject4)
/*  88 */         .isNullObject()))) {
/*  89 */         localObject4 = "";
/*     */       }
/*  91 */       this.processorFileSize = localObject4.toString();
/*  92 */       if ((this.processorFileSize != null) && (this.processorFileSize.length() > 0)) {
/*  93 */         this.processorFileSize = this.processorFileSize.toLowerCase();
/*  94 */         if (this.processorFileSize.endsWith("g")) {
/*  95 */           this.processorFileSize = this.processorFileSize.substring(0, 
/*  96 */             this.processorFileSize.length() - 1);
/*  97 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/*  98 */             this.processorFileSize, 0L) * 1024L * 1024L * 1024L);
/*  99 */         } else if (this.processorFileSize.endsWith("m")) {
/* 100 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 101 */             this.processorFileSize.length() - 1);
/* 102 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/* 103 */             this.processorFileSize, 0L) * 1024L * 1024L);
/* 104 */         } else if (this.processorFileSize.endsWith("k")) {
/* 105 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 106 */             this.processorFileSize.length() - 1);
/* 107 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/* 108 */             this.processorFileSize, 0L) * 1024L);
/* 109 */         } else if (this.processorFileSize.endsWith("b")) {
/* 110 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 111 */             this.processorFileSize.length() - 1);
/* 112 */         } else if (this.processorFileSize.endsWith("gb")) {
/* 113 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 114 */             this.processorFileSize.length() - 2);
/* 115 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/* 116 */             this.processorFileSize, 0L) * 1024L * 1024L * 1024L);
/* 117 */         } else if (this.processorFileSize.endsWith("mb")) {
/* 118 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 119 */             this.processorFileSize.length() - 2);
/* 120 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/* 121 */             this.processorFileSize, 0L) * 1024L * 1024L);
/* 122 */         } else if (this.processorFileSize.endsWith("kb")) {
/* 123 */           this.processorFileSize = this.processorFileSize.substring(0, 
/* 124 */             this.processorFileSize.length() - 2);
/* 125 */           this.processorFileSize = String.valueOf(StringUtil.getLong(
/* 126 */             this.processorFileSize, 0L) * 1024L);
/*     */         }
/*     */       } else {
/* 129 */         this.processorFileSize = null;
/*     */       }
/*     */     }
/*     */ 
/* 133 */     localObject1 = localMultiPartRequestWrapper.getFileParameterNames();
/* 134 */     if ((localObject1 != null) && (((Enumeration)localObject1).hasMoreElements())) {
/* 135 */       localObject2 = new ArrayList();
/*     */       File[] arrayOfFile;
/*     */       int i;
/* 136 */       for (; ((Enumeration)localObject1).hasMoreElements(); 
/* 141 */         i < arrayOfFile.length)
/*     */       {
/* 137 */         localObject3 = (String)((Enumeration)localObject1).nextElement();
/* 138 */         localObject4 = localMultiPartRequestWrapper.getFileNames((String)localObject3);
/* 139 */         arrayOfFile = localMultiPartRequestWrapper.getFiles((String)localObject3);
/*     */ 
/* 141 */         i = 0; continue;
/* 142 */         if (arrayOfFile[i].exists()) {
/* 143 */           if ((this.processorFileSize != null) && 
/* 144 */             (arrayOfFile[i].length() > StringUtil.getLong(
/* 145 */             this.processorFileSize, 0L))) {
/* 146 */             handleFileExceededException(this.processorFileSize);
/*     */           }
/* 148 */           FileAttachmentImpl localFileAttachmentImpl = new FileAttachmentImpl(
/* 149 */             (String)localObject3, new FileInputStream(arrayOfFile[i]), 
/* 150 */             arrayOfFile[i].length(), localObject4[i]);
/* 151 */           ((List)localObject2).add(localFileAttachmentImpl);
/* 152 */           arrayOfFile[i].delete();
/*     */         }
/* 141 */         i++;
/*     */       }
/*     */ 
/* 156 */       localHttpServletRequest.setAttribute("UNIEAP_FILEATTACHMENT", 
/* 157 */         localObject2);
/*     */     }
/*     */ 
/* 160 */     return paramActionInvocation.invoke();
/*     */   }
/*     */ 
/*     */   private void handleFileExceededException(String paramString)
/*     */   {
/* 167 */     throw new FileUploadException(
/* 168 */       "EAPTECH003703", 
/* 169 */       new String[] { paramString });
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fileupload.interceptor.FileUploadInterceptor
 * JD-Core Version:    0.6.2
 */