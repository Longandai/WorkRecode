package com.neusoft.unieap.core.fileupload;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class FileUploadExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "003";
  private static final String _P = "EAPTECH003";
  public static final String PARSE_UPLOAD_FILE_REQUEST_ERROR = "EAPTECH003700";
  public static final String PARSE_UPLOAD_FILE_SIZE_REQUEST_ERROR = "EAPTECH003703";
  public static final String COPY_FILE_ERROR = "EAPTECH003701";
  public static final String TARGET_DIR_IS_NULL = "EAPTECH003702";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fileupload.FileUploadExceptionCode
 * JD-Core Version:    0.6.2
 */