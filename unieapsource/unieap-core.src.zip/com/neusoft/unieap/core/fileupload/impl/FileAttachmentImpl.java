/*     */ package com.neusoft.unieap.core.fileupload.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.fileupload.FileAttachment;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class FileAttachmentImpl
/*     */   implements FileAttachment
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*  11 */   private String name = null;
/*     */   private long size;
/*  13 */   private InputStream inputStream = null;
/*  14 */   private String fileName = null;
/*  15 */   private String contentType = null;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  21 */     return this.name;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  28 */     byte[] arrayOfByte1 = (byte[])null;
/*  29 */     if (this.inputStream != null) {
/*  30 */       ByteArrayOutputStream localByteArrayOutputStream = null;
/*     */       try {
/*  32 */         localByteArrayOutputStream = new ByteArrayOutputStream(1000);
/*  33 */         byte[] arrayOfByte2 = new byte[1000];
/*     */         int i;
/*  35 */         while ((i = this.inputStream.read(arrayOfByte2)) != -1) {
/*  36 */           localByteArrayOutputStream.write(arrayOfByte2, 0, i);
/*     */         }
/*  38 */         arrayOfByte1 = localByteArrayOutputStream.toByteArray();
/*     */       } catch (Exception localException) {
/*  40 */         localException.printStackTrace();
/*     */ 
/*  42 */         if (localByteArrayOutputStream != null)
/*     */           try {
/*  44 */             localByteArrayOutputStream.close();
/*  45 */             this.inputStream.close();
/*     */           } catch (IOException localIOException1) {
/*  47 */             localIOException1.printStackTrace();
/*     */           }
/*     */       }
/*     */       finally
/*     */       {
/*  42 */         if (localByteArrayOutputStream != null) {
/*     */           try {
/*  44 */             localByteArrayOutputStream.close();
/*  45 */             this.inputStream.close();
/*     */           } catch (IOException localIOException2) {
/*  47 */             localIOException2.printStackTrace();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*  52 */     return arrayOfByte1;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */   {
/*  59 */     return this.inputStream;
/*     */   }
/*     */ 
/*     */   public long getSize()
/*     */   {
/*  66 */     return this.size;
/*     */   }
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  73 */     return this.fileName;
/*     */   }
/*     */ 
/*     */   public FileAttachmentImpl(String paramString, InputStream paramInputStream) {
/*  77 */     this.inputStream = paramInputStream;
/*  78 */     this.fileName = paramString;
/*     */   }
/*     */ 
/*     */   public FileAttachmentImpl(String paramString1, InputStream paramInputStream, String paramString2)
/*     */   {
/*  83 */     this.inputStream = paramInputStream;
/*  84 */     this.fileName = paramString1;
/*  85 */     this.contentType = paramString2;
/*     */   }
/*     */ 
/*     */   public FileAttachmentImpl(String paramString1, InputStream paramInputStream, long paramLong, String paramString2)
/*     */   {
/*  90 */     this.name = paramString1;
/*  91 */     this.inputStream = paramInputStream;
/*  92 */     this.size = paramLong;
/*  93 */     this.fileName = paramString2;
/*     */   }
/*     */ 
/*     */   public String getContextType()
/*     */   {
/* 100 */     return this.contentType;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fileupload.impl.FileAttachmentImpl
 * JD-Core Version:    0.6.2
 */