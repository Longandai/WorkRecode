/*    */ package com.neusoft.unieap.core.dataSource;
/*    */ 
/*    */ import com.neusoft.unieap.core.listener.ContextLoader;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Properties;
/*    */ import java.util.Set;
/*    */ import org.springframework.beans.MutablePropertyValues;
/*    */ import org.springframework.beans.PropertyValue;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*    */ import org.springframework.beans.factory.config.TypedStringValue;
/*    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*    */ import org.springframework.beans.factory.support.ManagedMap;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class DataSourceContextHolder
/*    */ {
/*    */   private static Map<String, String> dataSourceMap;
/*    */   private static String dialect;
/* 23 */   private static final ThreadLocal contextHolder = new ThreadLocal();
/*    */ 
/*    */   public static void setDataSourceType(String paramString) {
/* 26 */     contextHolder.set(paramString);
/*    */   }
/*    */ 
/*    */   public static String getDataSourceType() {
/* 30 */     return (String)contextHolder.get();
/*    */   }
/*    */ 
/*    */   public static void clearDataSourceType() {
/* 34 */     contextHolder.set(null);
/*    */   }
/*    */ 
/*    */   public static Map<String, String> getDataSources() {
/* 38 */     if (dataSourceMap == null) {
/* 39 */       dataSourceMap = new HashMap();
/* 40 */       DefaultListableBeanFactory localDefaultListableBeanFactory = (DefaultListableBeanFactory)
/* 41 */         ContextLoader.getCurrentWebApplicationContext()
/* 42 */         .getAutowireCapableBeanFactory();
/* 43 */       String str1 = ((RuntimeBeanReference)localDefaultListableBeanFactory
/* 44 */         .getBeanDefinition("sessionFactory").getPropertyValues()
/* 45 */         .getPropertyValue("dataSource").getValue()).getBeanName();
/* 46 */       PropertyValue localPropertyValue1 = localDefaultListableBeanFactory.getBeanDefinition(
/* 47 */         str1).getPropertyValues().getPropertyValue(
/* 48 */         "targetDataSources");
/* 49 */       PropertyValue localPropertyValue2 = localDefaultListableBeanFactory.getBeanDefinition(
/* 50 */         str1).getPropertyValues().getPropertyValue(
/* 51 */         "defaultTargetDataSource");
/*    */       Map.Entry localEntry;
/*    */       String str2;
/*    */       String str3;
/* 52 */       if ((localPropertyValue1 != null) && (localPropertyValue2 != null)) {
/* 53 */         localObject = (ManagedMap)localPropertyValue1.getValue();
/* 54 */         localSet = ((ManagedMap)localObject).entrySet();
/* 55 */         for (localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/* 56 */           localEntry = (Map.Entry)localIterator.next();
/* 57 */           str2 = ((TypedStringValue)localEntry.getKey()).getValue();
/* 58 */           str3 = ((RuntimeBeanReference)localEntry.getValue())
/* 59 */             .getBeanName();
/* 60 */           dataSourceMap.put(str3, str2);
/*    */         }
/*    */       }
/* 63 */       Object localObject = (Properties)localDefaultListableBeanFactory.getBeanDefinition(
/* 64 */         "sessionFactory").getPropertyValues().getPropertyValue(
/* 65 */         "hibernateProperties").getValue();
/*    */ 
/* 67 */       Set localSet = ((Properties)localObject).entrySet();
/* 68 */       for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/* 69 */         localEntry = (Map.Entry)localIterator.next();
/* 70 */         str2 = ((TypedStringValue)localEntry.getKey()).getValue();
/* 71 */         str3 = ((TypedStringValue)localEntry.getValue()).getValue();
/* 72 */         if (str2.equals("hibernate.dialect")) {
/* 73 */           dialect = str3;
/*    */         }
/*    */       }
/*    */     }
/* 77 */     return dataSourceMap;
/*    */   }
/*    */ 
/*    */   public static void setDialect(String paramString) {
/* 81 */     dialect = paramString;
/*    */   }
/*    */ 
/*    */   public static String getDialect() {
/* 85 */     return dialect;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.dataSource.DataSourceContextHolder
 * JD-Core Version:    0.6.2
 */