/*    */ package com.neusoft.unieap.core.dataSource;
/*    */ 
/*    */ import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
/*    */ 
/*    */ public class DynamicDataSource extends AbstractRoutingDataSource
/*    */ {
/*    */   protected Object determineCurrentLookupKey()
/*    */   {
/* 10 */     return DataSourceContextHolder.getDataSourceType();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.dataSource.DynamicDataSource
 * JD-Core Version:    0.6.2
 */