/*    */ package com.neusoft.unieap.core.sql;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.apache.commons.collections.map.HashedMap;
/*    */ 
/*    */ public class SqlMappingContext
/*    */ {
/* 15 */   private static SqlMappingContext context = new SqlMappingContext();
/*    */ 
/* 17 */   private Map<String, SqlMapping> mappingMap = new HashedMap();
/*    */ 
/* 19 */   private Map<String, Map<String, String>> realColumnsMap = new HashedMap();
/*    */ 
/*    */   public static SqlMappingContext getSqlMappingContext() {
/* 22 */     return context;
/*    */   }
/*    */ 
/*    */   public SqlMapping getSqlMappingByName(String paramString)
/*    */   {
/* 32 */     return (SqlMapping)this.mappingMap.get(paramString);
/*    */   }
/*    */ 
/*    */   public String getSqlByName(String paramString)
/*    */   {
/* 42 */     SqlMapping localSqlMapping = (SqlMapping)this.mappingMap.get(paramString);
/* 43 */     if (localSqlMapping != null) {
/* 44 */       return localSqlMapping.getSql();
/*    */     }
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public Column getColumnByProperty(String paramString1, String paramString2)
/*    */   {
/* 58 */     String str1 = "";
/* 59 */     String str2 = "";
/* 60 */     if ((paramString1 != null) && (paramString1.length() > 0) && 
/* 61 */       (paramString2 != null) && (paramString2.length() > 0))
/*    */     {
/* 63 */       SqlMapping localSqlMapping = getSqlMappingByName(paramString1);
/* 64 */       if (localSqlMapping != null) {
/* 65 */         Map localMap = localSqlMapping.getMappingMap();
/*    */         Object localObject;
/* 66 */         if ((localMap != null) && (localMap.size() > 0)) {
/* 67 */           localObject = localMap
/* 68 */             .entrySet().iterator();
/* 69 */           while (((Iterator)localObject).hasNext()) {
/* 70 */             Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
/* 71 */             if (((Property)localEntry.getValue()).getName().equals(paramString2)) {
/* 72 */               str1 = (String)localEntry.getKey();
/* 73 */               str2 = ((Property)localEntry.getValue()).getType();
/* 74 */               break;
/*    */             }
/*    */           }
/*    */         }
/* 78 */         if ((str1 != null) && (str1.length() > 0) && 
/* 79 */           (this.realColumnsMap.containsKey(paramString1))) {
/* 80 */           localObject = 
/* 81 */             (Map)this.realColumnsMap
/* 81 */             .get(paramString1);
/* 82 */           if (((Map)localObject).containsKey(str1)) {
/* 83 */             return new Column((String)((Map)localObject).get(str1), 
/* 84 */               str2);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 90 */     return new Column(str1, str2);
/*    */   }
/*    */ 
/*    */   public Map<String, SqlMapping> getMappingMap() {
/* 94 */     return this.mappingMap;
/*    */   }
/*    */ 
/*    */   public Map<String, Map<String, String>> getRealColumnsMap() {
/* 98 */     return this.realColumnsMap;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.sql.SqlMappingContext
 * JD-Core Version:    0.6.2
 */