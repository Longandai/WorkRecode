/*    */ package com.neusoft.unieap.core.sql;
/*    */ 
/*    */ public class Column
/*    */ {
/*    */   private String name;
/*    */   private String type;
/*    */ 
/*    */   public Column(String paramString1, String paramString2)
/*    */   {
/*  6 */     this.name = paramString1;
/*  7 */     this.type = paramString2;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 20 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString) {
/* 24 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 28 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void setType(String paramString) {
/* 32 */     this.type = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.sql.Column
 * JD-Core Version:    0.6.2
 */