/*    */ package com.neusoft.unieap.core.sql;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.property.ChainedPropertyAccessor;
/*    */ import org.hibernate.property.PropertyAccessor;
/*    */ import org.hibernate.property.PropertyAccessorFactory;
/*    */ import org.hibernate.property.Setter;
/*    */ import org.hibernate.transform.ResultTransformer;
/*    */ 
/*    */ public class AliasToDtoResultTransformer
/*    */   implements ResultTransformer
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private final Class resultClass;
/*    */   private Setter[] setters;
/*    */   private PropertyAccessor propertyAccessor;
/*    */   private Map<String, Property> mapping;
/*    */ 
/*    */   public AliasToDtoResultTransformer(Class paramClass, Map<String, Property> paramMap)
/*    */   {
/* 29 */     if (paramClass == null)
/* 30 */       throw new IllegalArgumentException("resultClass cannot be null");
/* 31 */     this.resultClass = paramClass;
/* 32 */     this.mapping = paramMap;
/* 33 */     this.propertyAccessor = new ChainedPropertyAccessor(new PropertyAccessor[] { 
/* 34 */       PropertyAccessorFactory.getPropertyAccessor(paramClass, null), 
/* 35 */       PropertyAccessorFactory.getPropertyAccessor("field") });
/*    */   }
/*    */ 
/*    */   public Object transformTuple(Object[] paramArrayOfObject, String[] paramArrayOfString)
/*    */   {
/* 40 */     HashMap localHashMap = new HashMap();
/*    */     Object localObject1;
/*    */     try
/*    */     {
/*    */       Object localObject2;
/* 42 */       for (int i = 0; i < paramArrayOfString.length; i++) {
/* 43 */         localObject2 = paramArrayOfString[i];
/* 44 */         if ((localObject2 != null) && (this.mapping.containsKey(localObject2))) {
/* 45 */           localHashMap.put(this.propertyAccessor.getSetter(this.resultClass, 
/* 46 */             ((Property)this.mapping
/* 46 */             .get(localObject2)).getName()), paramArrayOfObject[i]);
/*    */         }
/*    */       }
/* 49 */       localObject1 = this.resultClass.newInstance();
/* 50 */       Iterator localIterator = localHashMap.entrySet().iterator();
/* 51 */       while (localIterator.hasNext()) {
/* 52 */         localObject2 = (Map.Entry)localIterator.next();
/* 53 */         ((Setter)((Map.Entry)localObject2).getKey()).set(localObject1, ((Map.Entry)localObject2).getValue(), null);
/*    */       }
/*    */     } catch (InstantiationException localInstantiationException) {
/* 56 */       throw new HibernateException("Could not instantiate resultclass: " + 
/* 57 */         this.resultClass.getName());
/*    */     } catch (IllegalAccessException localIllegalAccessException) {
/* 59 */       throw new HibernateException("Could not instantiate resultclass: " + 
/* 60 */         this.resultClass.getName());
/*    */     }
/*    */ 
/* 63 */     return localObject1;
/*    */   }
/*    */ 
/*    */   public List transformList(List paramList) {
/* 67 */     return paramList;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.sql.AliasToDtoResultTransformer
 * JD-Core Version:    0.6.2
 */