/*    */ package com.neusoft.unieap.core.sql;
/*    */ 
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SqlMapping
/*    */ {
/*    */   private String name;
/*    */   private String sql;
/*    */   private Map<String, Property> mappingMap;
/*    */   private String clazz;
/*    */ 
/*    */   public SqlMapping(String paramString1, String paramString2, String paramString3, Map paramMap)
/*    */   {
/*  8 */     this.name = paramString1;
/*  9 */     this.sql = paramString2;
/* 10 */     this.clazz = paramString3;
/* 11 */     this.mappingMap = paramMap;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 32 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getSql() {
/* 36 */     return this.sql;
/*    */   }
/*    */ 
/*    */   public void setSql(String paramString) {
/* 40 */     this.sql = paramString;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString) {
/* 44 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public Map<String, Property> getMappingMap() {
/* 48 */     return this.mappingMap;
/*    */   }
/*    */ 
/*    */   public void setMappingMap(Map<String, Property> paramMap) {
/* 52 */     this.mappingMap = paramMap;
/*    */   }
/*    */ 
/*    */   public String getClazz() {
/* 56 */     return this.clazz;
/*    */   }
/*    */ 
/*    */   public void setClazz(String paramString) {
/* 60 */     this.clazz = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.sql.SqlMapping
 * JD-Core Version:    0.6.2
 */