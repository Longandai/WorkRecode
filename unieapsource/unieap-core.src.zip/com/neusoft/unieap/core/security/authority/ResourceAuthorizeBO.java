package com.neusoft.unieap.core.security.authority;

import com.neusoft.unieap.core.common.bo.context.BOContext;
import java.util.List;

public abstract interface ResourceAuthorizeBO
{
  public abstract List getResourceIds(List paramList, String paramString1, String paramString2);

  public abstract void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);

  public abstract void saveResourceAuthority(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7, String paramString8);

  public abstract void saveResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5, String paramString6);

  public abstract void saveResourceAuthorities(String paramString1, String paramString2, List paramList1, String paramString3, List paramList2, String paramString4, String paramString5);

  public abstract void deleteResourceAuthorities(String paramString);

  public abstract void deleteResourceAuthorities(List paramList, String paramString);

  public abstract void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4, String paramString5);

  public abstract void deleteResourceAuthorities(String paramString1, String paramString2, List paramList, String paramString3, String paramString4);

  public abstract List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract String getAuthorityType(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5);

  public abstract List getResourceIds(List paramList1, List paramList2, String paramString1, String paramString2, String paramString3);

  public abstract List getResourceIds(List paramList, String paramString1, String paramString2, String paramString3);

  public abstract List getResourceIds(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void saveTreeResources(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);

  public abstract List getRoleIds(String paramString1, String paramString2, String paramString3);

  public abstract BOContext getRoleIds(String paramString1, String paramString2, String paramString3, String paramString4);

  public abstract void saveResourceAuthorities(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);

  public abstract void saveResourceAuthorities4Cascade(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6, String paramString7);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.authority.ResourceAuthorizeBO
 * JD-Core Version:    0.6.2
 */