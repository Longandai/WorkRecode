/*    */ package com.neusoft.unieap.core.security.entity;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ @ModelFile("roleUser.entity")
/*    */ public class RoleUser
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String userId;
/*    */   private String roleId;
/*    */   private String roleType;
/*    */   private String roleName;
/*    */ 
/*    */   public void setId(String paramString)
/*    */   {
/* 36 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 40 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setUserId(String paramString) {
/* 44 */     this.userId = paramString;
/*    */   }
/*    */ 
/*    */   public String getUserId() {
/* 48 */     return this.userId;
/*    */   }
/*    */ 
/*    */   public void setRoleId(String paramString) {
/* 52 */     this.roleId = paramString;
/*    */   }
/*    */ 
/*    */   public String getRoleId() {
/* 56 */     return this.roleId;
/*    */   }
/*    */ 
/*    */   public void setRoleType(String paramString) {
/* 60 */     this.roleType = paramString;
/*    */   }
/*    */ 
/*    */   public String getRoleType() {
/* 64 */     return this.roleType;
/*    */   }
/*    */ 
/*    */   public void setRoleName(String paramString) {
/* 68 */     this.roleName = paramString;
/*    */   }
/*    */ 
/*    */   public String getRoleName() {
/* 72 */     return this.roleName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.entity.RoleUser
 * JD-Core Version:    0.6.2
 */