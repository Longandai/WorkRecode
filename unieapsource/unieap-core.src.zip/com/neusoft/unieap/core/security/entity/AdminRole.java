/*     */ package com.neusoft.unieap.core.security.entity;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import org.hibernate.validator.constraints.Length;
/*     */ 
/*     */ @ModelFile("adminRole.entity")
/*     */ public class AdminRole
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String id;
/*     */   private String name;
/*     */   private String description;
/*     */   private Timestamp timeBegin;
/*     */   private Timestamp timeEnd;
/*     */   private String createdBy;
/*     */   private Timestamp creationDate;
/*     */   private String lastUpdatedBy;
/*     */   private Timestamp lastUpdateDate;
/*     */   private String parentRoleId;
/*     */   private String roleType;
/*     */   private String rolePath;
/*     */   private BigDecimal depth;
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  82 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getId() {
/*  86 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString) {
/*  90 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  94 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setDescription(String paramString) {
/*  98 */     this.description = paramString;
/*     */   }
/*     */ 
/*     */   @Length(max=255, message="${platform.core/platform.core.entity.adminRole.description.length.message}")
/*     */   public String getDescription() {
/* 103 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setTimeBegin(Timestamp paramTimestamp) {
/* 107 */     this.timeBegin = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getTimeBegin() {
/* 111 */     return this.timeBegin;
/*     */   }
/*     */ 
/*     */   public void setTimeEnd(Timestamp paramTimestamp) {
/* 115 */     this.timeEnd = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getTimeEnd() {
/* 119 */     return this.timeEnd;
/*     */   }
/*     */ 
/*     */   public void setCreatedBy(String paramString) {
/* 123 */     this.createdBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getCreatedBy() {
/* 127 */     return this.createdBy;
/*     */   }
/*     */ 
/*     */   public void setCreationDate(Timestamp paramTimestamp) {
/* 131 */     this.creationDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getCreationDate() {
/* 135 */     return this.creationDate;
/*     */   }
/*     */ 
/*     */   public void setLastUpdatedBy(String paramString) {
/* 139 */     this.lastUpdatedBy = paramString;
/*     */   }
/*     */ 
/*     */   public String getLastUpdatedBy() {
/* 143 */     return this.lastUpdatedBy;
/*     */   }
/*     */ 
/*     */   public void setLastUpdateDate(Timestamp paramTimestamp) {
/* 147 */     this.lastUpdateDate = paramTimestamp;
/*     */   }
/*     */ 
/*     */   public Timestamp getLastUpdateDate() {
/* 151 */     return this.lastUpdateDate;
/*     */   }
/*     */ 
/*     */   public void setParentRoleId(String paramString) {
/* 155 */     this.parentRoleId = paramString;
/*     */   }
/*     */ 
/*     */   public String getParentRoleId() {
/* 159 */     return this.parentRoleId;
/*     */   }
/*     */ 
/*     */   public void setRoleType(String paramString) {
/* 163 */     this.roleType = paramString;
/*     */   }
/*     */ 
/*     */   public String getRoleType() {
/* 167 */     return this.roleType;
/*     */   }
/*     */ 
/*     */   public void setRolePath(String paramString) {
/* 171 */     this.rolePath = paramString;
/*     */   }
/*     */ 
/*     */   public String getRolePath() {
/* 175 */     return this.rolePath;
/*     */   }
/*     */ 
/*     */   public void setDepth(BigDecimal paramBigDecimal) {
/* 179 */     this.depth = paramBigDecimal;
/*     */   }
/*     */ 
/*     */   public BigDecimal getDepth() {
/* 183 */     return this.depth;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.entity.AdminRole
 * JD-Core Version:    0.6.2
 */