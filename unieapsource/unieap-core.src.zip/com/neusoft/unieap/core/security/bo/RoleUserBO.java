package com.neusoft.unieap.core.security.bo;

import com.neusoft.unieap.core.common.bo.context.BOContext;

public abstract interface RoleUserBO
{
  public abstract BOContext getUserInfoByCurrentUser();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.bo.RoleUserBO
 * JD-Core Version:    0.6.2
 */