/*    */ package com.neusoft.unieap.core.security.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.ModelFile;
/*    */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*    */ import com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl;
/*    */ import com.neusoft.unieap.core.context.UniEAPContext;
/*    */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.User;
/*    */ import com.neusoft.unieap.core.security.bo.RoleUserBO;
/*    */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*    */ import com.neusoft.unieap.core.security.entity.RoleUser;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ 
/*    */ @ModelFile("roleUserBO.bo")
/*    */ public class RoleUserBOImpl
/*    */   implements RoleUserBO
/*    */ {
/*    */   private RoleUserDAO roleUserDAO;
/*    */ 
/*    */   public void setRoleUserDAO(RoleUserDAO paramRoleUserDAO)
/*    */   {
/* 28 */     this.roleUserDAO = paramRoleUserDAO;
/*    */   }
/*    */ 
/*    */   public BOContext getUserInfoByCurrentUser() {
/* 32 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 33 */     List localList = this.roleUserDAO.getRoleUsersByUserId(localUser
/* 34 */       .getId());
/* 35 */     StringBuilder localStringBuilder1 = new StringBuilder();
/* 36 */     StringBuilder localStringBuilder2 = new StringBuilder();
/* 37 */     StringBuilder localStringBuilder3 = new StringBuilder();
/* 38 */     StringBuilder localStringBuilder4 = new StringBuilder();
/* 39 */     String str1 = "";
/* 40 */     String str2 = "";
/* 41 */     for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { localObject = (RoleUser)localIterator.next();
/* 42 */       str1 = ((RoleUser)localObject).getRoleType();
/* 43 */       str2 = ((RoleUser)localObject).getRoleName();
/* 44 */       if (str2 != null) {
/* 45 */         if (str1.equalsIgnoreCase("unit")) {
/* 46 */           localStringBuilder1.append(str2).append(",");
/*    */         }
/* 48 */         else if (str1
/* 48 */           .equalsIgnoreCase("station")) {
/* 49 */           localStringBuilder2.append(str2).append(",");
/*    */         }
/* 51 */         else if (str1
/* 51 */           .equalsIgnoreCase("busiRole"))
/* 52 */           localStringBuilder4.append(str2).append(",");
/*    */         else {
/* 54 */           localStringBuilder3.append(str2);
/*    */         }
/*    */       }
/*    */     }
/* 58 */     Object localObject = new BOContextImpl();
/* 59 */     ((BOContext)localObject).put("id", localUser.getId());
/* 60 */     ((BOContext)localObject).put("account", localUser.getAccount());
/* 61 */     ((BOContext)localObject).put("name", localUser.getName());
/* 62 */     int i = localStringBuilder1.toString().length();
/* 63 */     int j = localStringBuilder2.toString().length();
/* 64 */     int k = localStringBuilder4.toString().length();
/* 65 */     int m = localStringBuilder3.toString().length();
/* 66 */     if (i > 0) {
/* 67 */       ((BOContext)localObject).put("unit", localStringBuilder1.toString().substring(0, i - 1));
/*    */     }
/* 69 */     if (j > 0) {
/* 70 */       ((BOContext)localObject).put("station", localStringBuilder2.toString().substring(0, 
/* 71 */         j - 1));
/*    */     }
/* 73 */     if (k > 0) {
/* 74 */       ((BOContext)localObject).put("busiRole", localStringBuilder4.toString().substring(0, 
/* 75 */         k - 1));
/*    */     }
/* 77 */     if (m > 0) {
/* 78 */       ((BOContext)localObject).put("adminRole", localStringBuilder3.toString());
/*    */     }
/*    */ 
/* 81 */     return localObject;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.bo.impl.RoleUserBOImpl
 * JD-Core Version:    0.6.2
 */