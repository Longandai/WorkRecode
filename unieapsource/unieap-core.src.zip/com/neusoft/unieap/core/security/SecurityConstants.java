package com.neusoft.unieap.core.security;

public class SecurityConstants
{
  public static final String BUSI_ROLE_TYPE = "busiRole";
  public static final String SUPER_ADMIN_ROLE_TYPE = "superAdminRole";
  public static final String SUPER_ADMIN_ROLE_ID = "adminRole";
  public static final String ORG_ADMIN_ROLE_TYPE = "orgAdminRole";
  public static final String SEC_ADMIN_ROLE_TYPE = "secAdminRole";
  public static final String DIMENSION_ROLE_TYPE = "dimension";
  public static final String STATION_ROLE_TYPE = "station";
  public static final String UNIT_ROLE_TYPE = "unit";
  public static final String USER_ROLE_TYPE = "user";
  public static final String APP_RESOURCE_TYPE = "application";
  public static final String MENU_RESOURCE_TYPE = "menu";
  public static final String PAGE_RESOURCE_TYPE = "page";
  public static final String VARIABILITY_RESOURCE_TYPE = "variability";
  public static final String AVAILABLE_AUTHORITY_TYPE = "available";
  public static final String ASSIGNABLE_AUTHORITY_TYPE = "assignable";
  public static final String ACCOUNT_LOCKED = "accountLocked";
  public static final String IP_LOCKED = "ipLocked";
  public static final String IP_ACCOUNT_LOCKED = "ipAccountLocked";
  public static final String UNLOCKED = "unlocked";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.SecurityConstants
 * JD-Core Version:    0.6.2
 */