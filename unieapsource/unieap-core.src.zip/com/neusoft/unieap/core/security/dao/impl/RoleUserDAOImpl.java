/*     */ package com.neusoft.unieap.core.security.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.ModelFile;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.core.security.dao.RoleUserDAO;
/*     */ import com.neusoft.unieap.core.security.entity.RoleUser;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ @ModelFile("roleUserDAO.dao")
/*     */ public class RoleUserDAOImpl extends BaseHibernateDAO
/*     */   implements RoleUserDAO
/*     */ {
/*     */   public RoleUser saveRoleUser(RoleUser paramRoleUser)
/*     */   {
/*  30 */     getHibernateTemplate().save(paramRoleUser);
/*  31 */     return paramRoleUser;
/*     */   }
/*     */ 
/*     */   public void deleteRoleUser(String paramString1, String paramString2)
/*     */   {
/*  38 */     String str = "delete from RoleUser roleUser where roleUser.roleId = ? and roleUser.userId = ?";
/*  39 */     getHibernateTemplate().bulkUpdate(str, 
/*  40 */       new Object[] { paramString1, paramString2 });
/*     */   }
/*     */ 
/*     */   public void deleteRoleUsers(String paramString, List paramList)
/*     */   {
/*  47 */     String str = "delete from RoleUser roleUser where roleUser.roleId = ? and roleUser.userId in ( ";
/*  48 */     Object[] arrayOfObject = new Object[1 + paramList.size()];
/*  49 */     arrayOfObject[0] = paramString;
/*  50 */     for (int i = 0; i < paramList.size(); i++) {
/*  51 */       if (i < paramList.size() - 1)
/*  52 */         str = str + "?,";
/*     */       else
/*  54 */         str = str + "?)";
/*  55 */       arrayOfObject[(1 + i)] = paramList.get(i);
/*     */     }
/*     */ 
/*  58 */     getHibernateTemplate().bulkUpdate(str, arrayOfObject);
/*     */   }
/*     */ 
/*     */   public void deleteRoleUsersByRoleId(String paramString)
/*     */   {
/*  65 */     String str = "delete from RoleUser roleUser where roleUser.roleId = ?";
/*  66 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public void deleteRoleUsersByUserId(String paramString)
/*     */   {
/*  73 */     String str = "delete from RoleUser roleUser where roleUser.userId = ?";
/*  74 */     getHibernateTemplate().bulkUpdate(str, paramString);
/*     */   }
/*     */ 
/*     */   public List getRoleUsersByUserId(String paramString)
/*     */   {
/*  81 */     String str = "from RoleUser roleUser where roleUser.userId = ?";
/*  82 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public List getRoleIdsByUserId(String paramString)
/*     */   {
/*  89 */     String str = "select distinct(roleUser.roleId) from RoleUser roleUser where roleUser.userId = ?";
/*  90 */     return getHibernateTemplate().find(str, paramString);
/*     */   }
/*     */ 
/*     */   public List getUserIdsByRoleIds(final List paramList)
/*     */   {
/*  97 */     List localList = (List)getHibernateTemplate().execute(
/*  98 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException {
/* 101 */         String str = "select distinct roleUser.userId from RoleUser roleUser where roleUser.roleId in (:roleIds)";
/* 102 */         Query localQuery = paramAnonymousSession.createQuery(str);
/* 103 */         localQuery.setParameterList("roleIds", paramList);
/* 104 */         return localQuery.list();
/*     */       }
/*     */     });
/* 107 */     return localList;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.dao.impl.RoleUserDAOImpl
 * JD-Core Version:    0.6.2
 */