package com.neusoft.unieap.core.security.dao;

import com.neusoft.unieap.core.security.entity.RoleUser;
import java.util.List;

public abstract interface RoleUserDAO
{
  public abstract RoleUser saveRoleUser(RoleUser paramRoleUser);

  public abstract void deleteRoleUsers(String paramString, List paramList);

  public abstract void deleteRoleUser(String paramString1, String paramString2);

  public abstract void deleteRoleUsersByRoleId(String paramString);

  public abstract void deleteRoleUsersByUserId(String paramString);

  public abstract List getRoleUsersByUserId(String paramString);

  public abstract List getRoleIdsByUserId(String paramString);

  public abstract List getUserIdsByRoleIds(List paramList);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.security.dao.RoleUserDAO
 * JD-Core Version:    0.6.2
 */