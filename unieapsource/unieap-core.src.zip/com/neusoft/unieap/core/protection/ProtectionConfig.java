/*    */ package com.neusoft.unieap.core.protection;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ 
/*    */ public class ProtectionConfig
/*    */ {
/*  6 */   public static HashSet accessIPs = new HashSet();
/*  7 */   public static String rejectInfo = "NsZ1;%0*I-bm*}`b.g.#csK`&mN2Y>`r?[(YYN=+J4-#&A%D3;5(bx^J.I={bk/E[?^CF2?[b0\\d?[Y<R64$0_G1Z7";
/*    */ 
/*  9 */   public static String errMsg = null;
/*    */ 
/* 15 */   public static String err1 = "Bg3#$RTX9^W3ab?[;%agOJ+$L?)$9PE]-Y";
/* 16 */   public static String err2 = "RpB0L YK:(J?G1?[L8MN*#[C=}+{YJ";
/* 17 */   public static String err3 = "b`>^\\GabSJ+%UZ3;UKL1ML5(SGS:<%";
/* 18 */   public static String err4 = "\\jI]$R?#K4)#XJ?[9^F8.#?[K=]CX=W?ZH";
/* 19 */   public static String err5 = "YjcfFZPX?)-QXK?[U?/F;%3%?[J87%Y<I:0Q[8%Q?&da&_";
/* 20 */   public static String err6 = "@dI]F4F2\\CD<\\??[GX7_U6T61%E9`g*a/E(E%)TNE8WH]?";
/* 21 */   public static String filePath = null;
/* 22 */   public static boolean isWriteStorage = true;
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.ProtectionConfig
 * JD-Core Version:    0.6.2
 */