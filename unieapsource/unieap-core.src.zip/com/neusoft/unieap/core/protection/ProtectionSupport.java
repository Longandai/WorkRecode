/*     */ package com.neusoft.unieap.core.protection;
/*     */ 
/*     */ import com.jp.protection.pub.FileSecretStorage.Provider;
/*     */ import com.jp.protection.pub.License;
/*     */ import com.jp.protection.pub.LicenseAdapter;
/*     */ import com.jp.protection.pub.LicenseHost;
/*     */ import com.jp.protection.pub.LicenseListener;
/*     */ import com.jp.protection.pub.LicenseReader;
/*     */ import com.jp.protection.pub.ProductInfo;
/*     */ import com.jp.protection.pub.ProtectionFactory;
/*     */ import com.jp.protection.pub.pro.LicenseHostPro;
/*     */ import com.neusoft.unieap.core.protection.custom.CustomCheck;
/*     */ import java.io.File;
/*     */ import java.util.UUID;
/*     */ 
/*     */ public class ProtectionSupport
/*     */ {
/*  21 */   public static final String UU_FORDER = ".unieap" + File.separator + 
/*  21 */     UUID.randomUUID().toString();
/*     */   public static final String STORAGE_NAME = "storage.dat";
/*     */   private LicenseListener fLicenseListener;
/*  24 */   protected ProductInfo fProductInfo = new ProductInfo();
/*     */   private LicenseReader fLicenseReader;
/*     */   private LicenseHost fLicenseHost;
/*     */ 
/*     */   public ProtectionSupport()
/*     */   {
/*  29 */     init();
/*     */   }
/*     */ 
/*     */   private ProductInfo getProductInfo() {
/*  33 */     return this.fProductInfo;
/*     */   }
/*     */ 
/*     */   private void initProductInfo() {
/*  37 */     this.fProductInfo.setShortName("UniEAP");
/*     */ 
/*  39 */     this.fProductInfo.setID("unieap");
/*     */ 
/*  41 */     this.fProductInfo.setMajorVersion(3);
/*  42 */     this.fProductInfo.setMinorVersion(0);
/*     */ 
/*  44 */     this.fProductInfo.setCompany("");
/*  45 */     this.fProductInfo.setCopyright("");
/*     */   }
/*     */ 
/*     */   private void initLicenseReader() {
/*  49 */     this.fLicenseReader = ProtectionFactory.createLicenseReader();
/*  50 */     this.fLicenseReader.addLicenseReaderListener(this.fLicenseListener);
/*  51 */     this.fLicenseReader.setLicenseResourceFolder("");
/*  52 */     this.fLicenseReader.setLicenseFileName("unieap.license");
/*  53 */     this.fLicenseReader.setLicenseFolder(ProtectionConfig.filePath);
/*  54 */     this.fLicenseReader.setUserHomeRelative(false);
/*  55 */     this.fLicenseReader.setDecryptKeyBytes(new byte[] { -84, -19, 0, 5, 115, 
/*  56 */       114, 0, 45, 111, 114, 103, 46, 98, 111, 117, 110, 99, 121, 99, 
/*  57 */       97, 115, 116, 108, 101, 46, 106, 99, 101, 46, 112, 114, 111, 
/*  58 */       118, 105, 100, 101, 114, 46, 74, 67, 69, 82, 83, 65, 80, 117, 
/*  59 */       98, 108, 105, 99, 75, 101, 121, 37, 34, 106, 14, 91, -6, 108, 
/*  60 */       -124, 2, 0, 2, 76, 0, 7, 109, 111, 100, 117, 108, 117, 115, 
/*  61 */       116, 0, 22, 76, 106, 97, 118, 97, 47, 109, 97, 116, 104, 47, 
/*  62 */       66, 105, 103, 73, 110, 116, 101, 103, 101, 114, 59, 76, 0, 14, 
/*  63 */       112, 117, 98, 108, 105, 99, 69, 120, 112, 111, 110, 101, 110, 
/*  64 */       116, 113, 0, 126, 0, 1, 120, 112, 115, 114, 0, 20, 106, 97, 
/*  65 */       118, 97, 46, 109, 97, 116, 104, 46, 66, 105, 103, 73, 110, 116, 
/*  66 */       101, 103, 101, 114, -116, -4, -97, 31, -87, 59, -5, 29, 3, 
/*  67 */       0, 6, 73, 0, 8, 98, 105, 116, 67, 111, 117, 110, 116, 73, 0, 9, 
/*  68 */       98, 105, 116, 76, 101, 110, 103, 116, 104, 73, 0, 19, 102, 105, 
/*  69 */       114, 115, 116, 78, 111, 110, 122, 101, 114, 111, 66, 121, 116, 
/*  70 */       101, 78, 117, 109, 73, 0, 12, 108, 111, 119, 101, 115, 116, 83, 
/*  71 */       101, 116, 66, 105, 116, 73, 0, 6, 115, 105, 103, 110, 117, 109, 
/*  72 */       91, 0, 9, 109, 97, 103, 110, 105, 116, 117, 100, 101, 116, 
/*  73 */       0, 2, 91, 66, 120, 114, 0, 16, 106, 97, 118, 97, 46, 108, 97, 110, 
/*  74 */       103, 46, 78, 117, 109, 98, 101, 114, -122, -84, -107, 29, 11, 
/*  75 */       -108, -32, -117, 2, 0, 0, 120, 112, -1, -1, -1, -1, -1, -1, -1, 
/*  76 */       -1, -1, -1, -1, -2, -1, -1, -1, -2, 0, 0, 0, 1, 117, 114, 0, 2, 
/*  77 */       91, 66, -84, -13, 23, -8, 6, 8, 84, -32, 2, 0, 0, 120, 112, 
/*  78 */       0, 0, 0, 64, -86, -109, -12, -87, 23, -104, 93, -17, 112, 1, -102, 
/*  79 */       36, -126, 55, 77, -11, -93, -99, -110, -7, 76, -113, -22, -112, 
/*  80 */       96, -25, -112, 18, -98, -1, -73, 111, 26, -75, -35, 114, -29, 
/*  81 */       27, -4, 125, -38, -48, 108, 20, 48, -44, -52, 18, 31, 46, 8, 
/*  82 */       15, 18, -81, -101, 106, 28, 17, 17, 37, -124, -52, -6, 71, 120, 
/*  83 */       115, 113, 0, 126, 0, 3, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
/*  84 */       -1, -2, -1, -1, -1, -2, 0, 0, 0, 1, 117, 113, 0, 126, 0, 7, 
/*  85 */       0, 0, 0, 3, 1, 0, 1, 120 });
/*  86 */     this.fLicenseReader.setSecurityAlgorithm("RSA - 512");
/*     */   }
/*     */ 
/*     */   private void initLicenseListener() {
/*  90 */     this.fLicenseListener = new LicenseAdapter() {
/*  91 */       protected boolean fLicenseAccepted = false;
/*     */ 
/*     */       public void featureChecked(LicenseHost paramAnonymousLicenseHost, License paramAnonymousLicense, String paramAnonymousString, boolean paramAnonymousBoolean)
/*     */       {
/*     */       }
/*     */ 
/*     */       public void licenseAccepted(LicenseHost paramAnonymousLicenseHost, License paramAnonymousLicense, boolean paramAnonymousBoolean)
/*     */       {
/*  99 */         this.fLicenseAccepted = paramAnonymousBoolean;
/*     */       }
/*     */ 
/*     */       public void licenseCorrupted(LicenseReader paramAnonymousLicenseReader, String paramAnonymousString)
/*     */       {
/* 104 */         super.licenseCorrupted(paramAnonymousLicenseReader, paramAnonymousString);
/* 105 */         ProtectionConfig.errMsg = 
/* 106 */           Encipher.decodePasswd(ProtectionConfig.err1);
/* 107 */         exit();
/*     */       }
/*     */ 
/*     */       public void licenseExpired(LicenseHost paramAnonymousLicenseHost, License paramAnonymousLicense) {
/* 111 */         String str = CustomCheck.getInstance().getProperty(
/* 112 */           "common.type", "development");
/* 113 */         if (str.equalsIgnoreCase("development")) {
/* 114 */           super.licenseExpired(paramAnonymousLicenseHost, paramAnonymousLicense);
/* 115 */           ProtectionConfig.errMsg = 
/* 116 */             Encipher.decodePasswd(ProtectionConfig.err2);
/* 117 */           exit();
/*     */         }
/*     */       }
/*     */ 
/*     */       public void licenseInvalid(LicenseHost paramAnonymousLicenseHost, License paramAnonymousLicense) {
/* 122 */         super.licenseInvalid(paramAnonymousLicenseHost, paramAnonymousLicense);
/* 123 */         ProtectionConfig.errMsg = 
/* 124 */           Encipher.decodePasswd(ProtectionConfig.err3);
/* 125 */         exit();
/*     */       }
/*     */ 
/*     */       public void licenseMissing(LicenseReader paramAnonymousLicenseReader, String paramAnonymousString)
/*     */       {
/* 130 */         super.licenseMissing(paramAnonymousLicenseReader, paramAnonymousString);
/* 131 */         ProtectionConfig.errMsg = 
/* 132 */           Encipher.decodePasswd(ProtectionConfig.err4);
/* 133 */         exit();
/*     */       }
/*     */ 
/*     */       private void exit()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void licenseLockViolation(LicenseHost paramAnonymousLicenseHost, License paramAnonymousLicense) {
/* 141 */         super.licenseLockViolation(paramAnonymousLicenseHost, paramAnonymousLicense);
/* 142 */         ProtectionConfig.errMsg = 
/* 143 */           Encipher.decodePasswd(ProtectionConfig.err5);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private void initLicenseHost() {
/* 149 */     this.fLicenseHost = new LicenseHostProEx();
/* 150 */     this.fLicenseHost.setVerbose(true);
/* 151 */     this.fLicenseHost.addLicenseHostListener(this.fLicenseListener);
/* 152 */     this.fLicenseHost.setLicenseReader(this.fLicenseReader);
/*     */ 
/* 154 */     this.fLicenseHost.setLicenseAcceptanceDelegate(
/* 155 */       ProtectionFactory.createLicenseAcceptanceDelegate());
/*     */ 
/* 157 */     this.fLicenseHost.setAllowFlexibleExpirationDate(true);
/*     */ 
/* 159 */     ((LicenseHostPro)this.fLicenseHost)
/* 160 */       .setActivationLockOptions(4);
/*     */ 
/* 162 */     ((LicenseHostPro)this.fLicenseHost).setCheckPreviousShutdownDate(false);
/*     */ 
/* 164 */     ((LicenseHostPro)this.fLicenseHost).setMaintainPreviousShutdownDate(false);
/* 165 */     ((LicenseHostPro)this.fLicenseHost).setUseStrippedActivationKeyChars(true);
/*     */   }
/*     */ 
/*     */   private void init() {
/* 169 */     ProtectionFactory.initProfessional();
/*     */ 
/* 171 */     initProductInfo();
/* 172 */     initLicenseListener();
/* 173 */     initLicenseReader();
/* 174 */     initLicenseHost();
/* 175 */     initSecretStorages();
/* 176 */     initLicensingFacades();
/*     */   }
/*     */ 
/*     */   private void initSecretStorages() {
/* 180 */     this.fLicenseHost.addSecretStorage(new FileSecretStorage.Provider(UU_FORDER, 
/* 181 */       "storage.dat", true).create());
/*     */   }
/*     */ 
/*     */   private void initLicensingFacades()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean checkLicense(boolean paramBoolean)
/*     */   {
/* 193 */     ProductInfo localProductInfo = getProductInfo();
/* 194 */     this.fLicenseHost.checkLicense(localProductInfo.getID(), localProductInfo
/* 195 */       .getMajorVersion(), localProductInfo.getMinorVersion(), 
/* 196 */       paramBoolean);
/*     */ 
/* 198 */     License localLicense = this.fLicenseHost.getLicense();
/*     */ 
/* 200 */     if (localLicense == null) {
/* 201 */       ProtectionConfig.errMsg = 
/* 202 */         Encipher.decodePasswd(ProtectionConfig.err4);
/* 203 */       return false;
/*     */     }
/*     */ 
/* 206 */     return (localLicense != null) && (localLicense.getLicenseState() == 2);
/*     */   }
/*     */ 
/*     */   public boolean checkLicense() {
/* 210 */     return checkLicense(false);
/*     */   }
/*     */ 
/*     */   public void setLicenseFolder(String paramString) {
/* 214 */     this.fLicenseReader.setLicenseFolder(paramString);
/*     */   }
/*     */ 
/*     */   public void setLicenseFileName(String paramString) {
/* 218 */     this.fLicenseReader.setLicenseFileName(paramString);
/*     */   }
/*     */ 
/*     */   public LicenseHost getLicenseHost() {
/* 222 */     return this.fLicenseHost;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.ProtectionSupport
 * JD-Core Version:    0.6.2
 */