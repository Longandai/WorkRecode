package com.neusoft.unieap.core.protection;

public class EncipherConst
{
  public static final String m_strKey1 = "zxcvbnm,./asdfg";
  public static final String m_strKeya = "cjk;";
  public static final String m_strKey2 = "hjkl;'qwertyuiop";
  public static final String m_strKeyb = "cai2";
  public static final String m_strKey3 = "[]\\1234567890-";
  public static final String m_strKeyc = "%^@#";
  public static final String m_strKey4 = "=` ZXCVBNM<>?:LKJ";
  public static final String m_strKeyd = "*(N";
  public static final String m_strKey5 = "HGFDSAQWERTYUI";
  public static final String m_strKeye = "%^HJ";
  public static final String m_strKey6 = "OP{}|+_)(*&^%$#@!~";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.EncipherConst
 * JD-Core Version:    0.6.2
 */