/*     */ package com.neusoft.unieap.core.protection;
/*     */ 
/*     */ import com.jp.protection.pub.LicenseImpl;
/*     */ import com.jp.protection.pub.pro.LicenseHostPro;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class LicenseHostProEx extends LicenseHostPro
/*     */ {
/*     */   public static final String IP_ADDRESSES = "IPs";
/*     */   public static final String SEPERATOR = ";";
/*     */   private static final String MAC_ADDRESSES = "MACs";
/*  30 */   private static final String[] WINDOWS_COMMAND = { "ipconfig", "/all" };
/*     */ 
/*  32 */   private static final String[] LINUX_COMMAND = { "/sbin/ifconfig", "-a" };
/*     */ 
/*  35 */   private static final Pattern macPattern = Pattern.compile(".*((:?[0-9a-f]{2}[-:]){5}[0-9a-f]{2}).*", 
/*  36 */     2);
/*     */ 
/*     */   protected int getActivationNumber(String paramString)
/*     */   {
/*  39 */     return 0;
/*     */   }
/*     */ 
/*     */   protected void checkCommercial(LicenseImpl paramLicenseImpl, String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  44 */     super.checkCommercial(paramLicenseImpl, paramString, paramInt1, 
/*  45 */       paramInt2);
/*     */ 
/*  47 */     String str1 = paramLicenseImpl.getProperty("IPs", "");
/*  48 */     if ((!str1.trim().equals("")) && (!checkIPAddress(str1))) {
/*  49 */       setLicenseState(paramLicenseImpl, 6);
/*  50 */       return;
/*     */     }
/*     */ 
/*  53 */     String str2 = paramLicenseImpl.getProperty("MACs", "");
/*  54 */     if ((!str2.trim().equals("")) && (!checkMacAddress(str2))) {
/*  55 */       setLicenseState(paramLicenseImpl, 6);
/*  56 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isInStrings(List paramList, String[] paramArrayOfString) {
/*  61 */     if ((paramList == null) || (paramList.isEmpty())) {
/*  62 */       return false;
/*     */     }
/*  64 */     Iterator localIterator = paramList.iterator();
/*     */     int i;
/*  65 */     for (; localIterator.hasNext(); 
/*  67 */       i < paramArrayOfString.length)
/*     */     {
/*  66 */       String str = localIterator.next().toString();
/*  67 */       i = 0; continue;
/*  68 */       if (str.equals(paramArrayOfString[i]))
/*  69 */         return true;
/*  67 */       i++;
/*     */     }
/*     */ 
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean checkIPAddress(String paramString)
/*     */   {
/*  84 */     List localList = null;
/*     */     try {
/*  86 */       localList = getLocalIPAddress();
/*     */     } catch (UnknownHostException localUnknownHostException) {
/*  88 */       localUnknownHostException.printStackTrace();
/*  89 */       return false;
/*     */     } catch (SocketException localSocketException) {
/*  91 */       localSocketException.printStackTrace();
/*  92 */       return false;
/*     */     }
/*  94 */     String[] arrayOfString = paramString.split(";");
/*  95 */     return isInStrings(localList, arrayOfString);
/*     */   }
/*     */ 
/*     */   private List getLocalIPAddress()
/*     */     throws UnknownHostException, SocketException
/*     */   {
/* 101 */     LinkedList localLinkedList = new LinkedList();
/* 102 */     Enumeration localEnumeration1 = NetworkInterface.getNetworkInterfaces();
/*     */     Enumeration localEnumeration2;
/* 104 */     for (; localEnumeration1.hasMoreElements(); 
/* 110 */       localEnumeration2.hasMoreElements())
/*     */     {
/* 105 */       NetworkInterface localNetworkInterface = 
/* 106 */         (NetworkInterface)localEnumeration1
/* 106 */         .nextElement();
/* 107 */       localEnumeration2 = localNetworkInterface.getInetAddresses();
/* 108 */       InetAddress localInetAddress = null;
/* 109 */       String str = null;
/* 110 */       continue;
/* 111 */       localInetAddress = (InetAddress)localEnumeration2.nextElement();
/* 112 */       str = localInetAddress.getHostAddress();
/*     */ 
/* 114 */       if (!"127.0.0.1".equals(str))
/*     */       {
/* 117 */         localLinkedList.add(str);
/*     */       }
/*     */     }
/* 120 */     return localLinkedList;
/*     */   }
/*     */ 
/*     */   private boolean checkMacAddress(String paramString)
/*     */   {
/* 131 */     List localList = null;
/*     */     try {
/* 133 */       localList = getLocalMACAddresses();
/*     */     } catch (UnknownHostException localUnknownHostException) {
/* 135 */       localUnknownHostException.printStackTrace();
/* 136 */       return false;
/*     */     } catch (SocketException localSocketException) {
/* 138 */       localSocketException.printStackTrace();
/* 139 */       return false;
/*     */     } catch (IOException localIOException) {
/* 141 */       localIOException.printStackTrace();
/* 142 */       return false;
/*     */     }
/* 144 */     String[] arrayOfString = paramString.split(";");
/* 145 */     return isInStrings(localList, arrayOfString);
/*     */   }
/*     */ 
/*     */   private final List getLocalMACAddresses() throws IOException {
/* 149 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 151 */     String str = System.getProperty("os.name").toLowerCase();
/*     */     String[] arrayOfString;
/* 154 */     if (str.startsWith("windows"))
/* 155 */       arrayOfString = WINDOWS_COMMAND;
/* 156 */     else if (str.startsWith("linux"))
/* 157 */       arrayOfString = LINUX_COMMAND;
/*     */     else {
/* 159 */       throw new IOException("Unknown operating system: " + str);
/*     */     }
/*     */ 
/* 162 */     final Process localProcess = Runtime.getRuntime().exec(arrayOfString);
/* 163 */     new Thread() {
/*     */       public void run() {
/*     */         try {
/* 166 */           InputStream localInputStream = localProcess.getErrorStream();
/* 167 */           while (localInputStream.read() != -1);
/* 169 */           localInputStream.close();
/*     */         } catch (IOException localIOException) {
/* 171 */           localIOException.printStackTrace();
/*     */         }
/*     */       }
/*     */     }
/* 174 */     .start();
/*     */ 
/* 176 */     BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(
/* 177 */       localProcess.getInputStream()));
/* 178 */     for (Object localObject = null; (localObject = localBufferedReader.readLine()) != null; ) {
/* 179 */       Matcher localMatcher = macPattern.matcher((CharSequence)localObject);
/* 180 */       if (localMatcher.matches()) {
/* 181 */         localArrayList.add(localMatcher.group(1));
/*     */       }
/*     */     }
/* 184 */     localBufferedReader.close();
/* 185 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void setLicenseAccepted(boolean paramBoolean)
/*     */   {
/* 190 */     if (ProtectionConfig.isWriteStorage)
/*     */     {
/* 199 */       super.setLicenseAccepted(paramBoolean);
/* 200 */       ProtectionConfig.isWriteStorage = false;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.LicenseHostProEx
 * JD-Core Version:    0.6.2
 */