/*    */ package com.neusoft.unieap.core.protection;
/*    */ 
/*    */ public class Encipher
/*    */ {
/*    */   public static String encodePasswd(String paramString)
/*    */   {
/*  9 */     Object localObject = "";
/*    */ 
/* 12 */     String str1 = "";
/* 13 */     String str2 = "";
/*    */ 
/* 15 */     if ((paramString == null) || (paramString.length() == 0))
/*    */     {
/* 17 */       localObject = "";
/* 18 */       return localObject;
/*    */     }
/* 20 */     str2 = "zxcvbnm,./asdfghjkl;'qwertyuiop[]\\1234567890-=` ZXCVBNM<>?:LKJHGFDSAQWERTYUIOP{}|+_)(*&^%$#@!~";
/* 21 */     while (paramString.length() < 8)
/*    */     {
/* 23 */       paramString = paramString + '\001';
/*    */     }
/* 25 */     str1 = "";
/* 26 */     for (int i = 0; i <= paramString.length() - 1; i++)
/*    */     {
/*    */       char c1;
/*    */       do {
/* 30 */         c1 = (char)(int)Math.rint(Math.random() * 100.0D);
/* 31 */         while ((c1 > 0) && (((c1 ^ paramString.charAt(i)) < 0) || ((c1 ^ paramString.charAt(i)) > 'Z')))
/*    */         {
/* 33 */           c1 = (char)(c1 - '\001');
/*    */         }
/* 35 */         c2 = '\000';
/*    */ 
/* 37 */         int j = c1 ^ paramString.charAt(i);
/* 38 */         if (j > 93)
/*    */         {
/* 40 */           c2 = '\000';
/*    */         }
/*    */         else
/*    */         {
/* 44 */           c2 = str2.charAt(j);
/*    */         }
/*    */       }
/* 46 */       while (((c1 > '#' ? 1 : 0) & (c1 < 'z' ? 1 : 0) & (c1 != '|' ? 1 : 0) & (c1 != '\'' ? 1 : 0) & (c1 != ',' ? 1 : 0) & (c2 != '|' ? 1 : 0) & (c2 != '\'' ? 1 : 0) & (c2 != ',' ? 1 : 0)) == 0);
/*    */ 
/* 52 */       char c2 = '\000';
/* 53 */       c2 = str2.charAt(c1 ^ paramString.charAt(i));
/* 54 */       str1 = str1 + c1 + c2;
/*    */     }
/* 56 */     localObject = str1;
/* 57 */     return localObject;
/*    */   }
/*    */ 
/*    */   public static String decodePasswd(String paramString)
/*    */   {
/* 63 */     String str1 = "";
/* 64 */     String str2 = "";
/* 65 */     if ((paramString == null) || (paramString.length() == 0))
/*    */     {
/* 67 */       return "";
/*    */     }
/* 69 */     str2 = "zxcvbnm,./asdfghjkl;'qwertyuiop[]\\1234567890-=` ZXCVBNM<>?:LKJHGFDSAQWERTYUIOP{}|+_)(*&^%$#@!~";
/* 70 */     if (paramString.length() % 2 != 0)
/*    */     {
/* 72 */       paramString = paramString + "?";
/*    */     }
/* 74 */     str1 = "";
/* 75 */     for (int i = 0; i <= paramString.length() / 2 - 1; i++)
/*    */     {
/* 78 */       int j = paramString.charAt(i * 2);
/*    */ 
/* 80 */       int k = str2.indexOf(paramString.charAt(i * 2 + 1));
/* 81 */       str1 = str1 + (char)(j ^ k);
/*    */     }
/* 83 */     i = str1.indexOf(1);
/* 84 */     if (i > 0)
/*    */     {
/* 86 */       return str1.substring(0, i);
/*    */     }
/*    */ 
/* 90 */     return str1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.Encipher
 * JD-Core Version:    0.6.2
 */