/*    */ package com.neusoft.unieap.core.protection;
/*    */ 
/*    */ import com.neusoft.unieap.core.protection.custom.CustomCheck;
/*    */ import org.slf4j.Logger;
/*    */ import org.slf4j.LoggerFactory;
/*    */ 
/*    */ public class ProtectionCheckTask extends Thread
/*    */ {
/*    */   private CustomCheck customCheck;
/*    */ 
/*    */   public ProtectionCheckTask()
/*    */   {
/* 12 */     this.customCheck = CustomCheck.getInstance();
/*    */   }
/*    */ 
/*    */   public void run() {
/*    */     while (true) {
/* 17 */       this.customCheck.check(false);
/*    */       try {
/* 19 */         sleep(259200000L);
/*    */       } catch (InterruptedException localInterruptedException) {
/* 21 */         LoggerFactory.getLogger(ProtectionCheckTask.class).error("", localInterruptedException);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.protection.ProtectionCheckTask
 * JD-Core Version:    0.6.2
 */