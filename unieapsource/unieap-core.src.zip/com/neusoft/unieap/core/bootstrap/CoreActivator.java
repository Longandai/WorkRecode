/*     */ package com.neusoft.unieap.core.bootstrap;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.model.DCActivator;
/*     */ import com.neusoft.unieap.core.sql.Property;
/*     */ import com.neusoft.unieap.core.sql.SqlMapping;
/*     */ import com.neusoft.unieap.core.sql.SqlMappingContext;
/*     */ import com.neusoft.unieap.core.util.DomUtil;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.collections.map.HashedMap;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.Element;
/*     */ import org.springframework.util.AntPathMatcher;
/*     */ import org.springframework.util.PathMatcher;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.web.context.ServletContextAware;
/*     */ import org.springframework.web.context.support.ServletContextResource;
/*     */ 
/*     */ public class CoreActivator extends DCActivator
/*     */   implements ServletContextAware
/*     */ {
/*     */   private ServletContext servletContext;
/*  35 */   private PathMatcher pathMatcher = new AntPathMatcher();
/*     */ 
/*     */   public void shutdown() throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void startup() throws Exception
/*     */   {
/*  43 */     initSqlMappingContext();
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext paramServletContext) {
/*  47 */     this.servletContext = paramServletContext;
/*     */   }
/*     */ 
/*     */   private void initSqlMappingContext() {
/*  51 */     LinkedHashSet localLinkedHashSet = new LinkedHashSet(8);
/*  52 */     doRetrieveMatchingServletContextResources(this.servletContext, 
/*  53 */       "/WEB-INF/conf/**/sdm", "/WEB-INF/conf", localLinkedHashSet);
/*     */ 
/*  55 */     Iterator localIterator = localLinkedHashSet.iterator();
/*  56 */     while (localIterator.hasNext()) {
/*  57 */       ServletContextResource localServletContextResource = 
/*  58 */         (ServletContextResource)localIterator
/*  58 */         .next();
/*     */       try {
/*  60 */         parseDirectory(localServletContextResource.getFile());
/*     */       } catch (IOException localIOException) {
/*  62 */         localIOException.printStackTrace();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void parseDirectory(File paramFile) {
/*  68 */     File[] arrayOfFile = paramFile.listFiles();
/*  69 */     for (int i = 0; i < arrayOfFile.length; i++)
/*  70 */       if (arrayOfFile[i].isDirectory())
/*  71 */         parseDirectory(arrayOfFile[i]);
/*  72 */       else if (arrayOfFile[i].getName().endsWith(".sdm.xml"))
/*  73 */         parseFile(arrayOfFile[i]);
/*     */   }
/*     */ 
/*     */   protected void parseFile(File paramFile)
/*     */   {
/*  79 */     paramFile.exists();
/*     */ 
/*  81 */     Document localDocument = DomUtil.parse(paramFile);
/*  82 */     Element localElement1 = localDocument.getRootElement();
/*  83 */     String str1 = localElement1.attributeValue("class");
/*  84 */     if ((str1 != null) && (str1.length() > 0))
/*     */       try
/*     */       {
/*  87 */         Class localClass = Class.forName(str1);
/*  88 */         Field[] arrayOfField1 = localClass.getDeclaredFields();
/*  89 */         List localList1 = DomUtil.getChildElements(
/*  90 */           localElement1, "sql-mapping");
/*  91 */         if ((localList1 != null) && (localList1.size() > 0))
/*  92 */           for (Element localElement2 : localList1) {
/*  93 */             String str2 = localElement2.attributeValue("name");
/*  94 */             HashedMap localHashedMap1 = null;
/*  95 */             if ((str2 != null) && (str2.length() > 0)) {
/*  96 */               List localList2 = localElement2.content();
/*  97 */               if ((localList2 != null) && (localList2.size() > 0)) {
/*  98 */                 String str3 = "";
/*  99 */                 HashedMap localHashedMap2 = new HashedMap();
/* 100 */                 for (Iterator localIterator2 = localList2.iterator(); localIterator2.hasNext(); ) { Object localObject = localIterator2.next();
/* 101 */                   if ((localObject instanceof Element)) {
/* 102 */                     Element localElement3 = (Element)localObject;
/* 103 */                     String str4 = localElement3.getName();
/* 104 */                     if (str4.equals("mapping")) {
/* 105 */                       String str5 = localElement3
/* 106 */                         .attributeValue("property");
/* 107 */                       String str6 = localElement3
/* 108 */                         .attributeValue("column");
/* 109 */                       String str7 = localElement3
/* 110 */                         .attributeValue("realColumn");
/* 111 */                       if ((str5 != null) && 
/* 112 */                         (str5.length() > 0) && 
/* 113 */                         (str6 != null) && 
/* 114 */                         (str6.length() > 0)) {
/* 115 */                         for (Field localField : arrayOfField1) {
/* 116 */                           if (localField.getName().equals(
/* 117 */                             str5)) {
/* 118 */                             localHashedMap2
/* 119 */                               .put(
/* 120 */                               str6, 
/* 121 */                               new Property(
/* 122 */                               str5, 
/* 123 */                               localField
/* 124 */                               .getType()
/* 125 */                               .getName()));
/* 126 */                             break;
/*     */                           }
/*     */                         }
/*     */                       }
/*     */ 
/* 131 */                       if ((str7 != null) && 
/* 132 */                         (str7.length() > 0)) {
/* 133 */                         if (localHashedMap1 == null) {
/* 134 */                           localHashedMap1 = new HashedMap();
/*     */ 
/* 136 */                           SqlMappingContext.getSqlMappingContext()
/* 137 */                             .getRealColumnsMap()
/* 138 */                             .put(str2, 
/* 139 */                             localHashedMap1);
/*     */                         }
/* 141 */                         localHashedMap1.put(str6, 
/* 142 */                           str7);
/*     */                       }
/* 144 */                     } else if (str4.equals("sql")) {
/* 145 */                       str3 = localElement3.getText();
/*     */                     }
/*     */                   }
/*     */                 }
/* 149 */                 SqlMappingContext.getSqlMappingContext()
/* 150 */                   .getMappingMap().put(
/* 151 */                   str2, 
/* 152 */                   new SqlMapping(str2, str3, 
/* 153 */                   str1, localHashedMap2));
/*     */               }
/*     */             }
/*     */           }
/*     */       }
/*     */       catch (ClassNotFoundException localClassNotFoundException)
/*     */       {
/* 160 */         localClassNotFoundException.printStackTrace();
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void doRetrieveMatchingServletContextResources(ServletContext paramServletContext, String paramString1, String paramString2, Set paramSet)
/*     */   {
/* 177 */     Set localSet = paramServletContext.getResourcePaths(paramString2);
/* 178 */     if (localSet != null) {
/* 179 */       int i = paramString1.indexOf("**") != -1 ? 1 : 0;
/* 180 */       for (Iterator localIterator = localSet.iterator(); localIterator.hasNext(); ) {
/* 181 */         String str = (String)localIterator.next();
/* 182 */         if (!str.startsWith(paramString2)) {
/* 183 */           int j = str.indexOf(paramString2);
/* 184 */           if (j != -1) {
/* 185 */             str = str.substring(j);
/*     */           }
/*     */         }
/* 188 */         if ((str.endsWith("/")) && (
/* 189 */           (i != 0) || 
/* 191 */           (StringUtils.countOccurrencesOf(
/* 190 */           str, "/") <= 
/* 191 */           StringUtils.countOccurrencesOf(paramString1, "/")))) {
/* 192 */           doRetrieveMatchingServletContextResources(paramServletContext, 
/* 193 */             paramString1, str, paramSet);
/*     */         }
/* 195 */         if (this.pathMatcher.match(paramString1, str))
/* 196 */           paramSet.add(new ServletContextResource(paramServletContext, 
/* 197 */             str));
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.bootstrap.CoreActivator
 * JD-Core Version:    0.6.2
 */