package com.neusoft.unieap.core.log;

public class LogConstants
{
  public static final String LOG_TYPE = "eap_monitor_log_type";
  public static final String LOG_EXTEND_CONTENT = "eap_monitor_extend_content";
  public static final String LOG_CLASSNAME = "eap_monitor_classname";
  public static final String LOG_METHODNAME = "eap_monitor_methodname";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.log.LogConstants
 * JD-Core Version:    0.6.2
 */