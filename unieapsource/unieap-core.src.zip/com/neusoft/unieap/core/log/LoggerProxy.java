/*     */ package com.neusoft.unieap.core.log;
/*     */ 
/*     */ import org.apache.log4j.MDC;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class LoggerProxy
/*     */ {
/*     */   private Logger logger;
/*     */ 
/*     */   public LoggerProxy(String paramString)
/*     */   {
/*  15 */     this.logger = LoggerFactory.getLogger(paramString);
/*     */   }
/*     */ 
/*     */   public static LoggerProxy getLogger(String paramString) {
/*  19 */     return new LoggerProxy(paramString);
/*     */   }
/*     */ 
/*     */   public static LoggerProxy getLogger(Class paramClass) {
/*  23 */     return new LoggerProxy(paramClass.getName());
/*     */   }
/*     */ 
/*     */   public void info(String paramString1, Object[] paramArrayOfObject, String paramString2)
/*     */   {
/*  28 */     MDC.put("eap_monitor_log_type", paramString2);
/*  29 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  30 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  31 */     MDC.put("eap_monitor_classname", str1);
/*  32 */     MDC.put("eap_monitor_methodname", str2);
/*  33 */     this.logger.info(paramString1, paramArrayOfObject);
/*  34 */     MDC.remove("eap_monitor_log_type");
/*  35 */     MDC.remove("eap_monitor_classname");
/*  36 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void debug(String paramString1, Object[] paramArrayOfObject, String paramString2) {
/*  40 */     MDC.put("eap_monitor_log_type", paramString2);
/*  41 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  42 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  43 */     MDC.put("eap_monitor_classname", str1);
/*  44 */     MDC.put("eap_monitor_methodname", str2);
/*  45 */     this.logger.debug(paramString1, paramArrayOfObject);
/*  46 */     MDC.remove("eap_monitor_log_type");
/*  47 */     MDC.remove("eap_monitor_classname");
/*  48 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void warn(String paramString1, Object[] paramArrayOfObject, String paramString2) {
/*  52 */     MDC.put("eap_monitor_log_type", paramString2);
/*  53 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  54 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  55 */     MDC.put("eap_monitor_classname", str1);
/*  56 */     MDC.put("eap_monitor_methodname", str2);
/*  57 */     this.logger.warn(paramString1, paramArrayOfObject);
/*  58 */     MDC.remove("eap_monitor_log_type");
/*  59 */     MDC.remove("eap_monitor_classname");
/*  60 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void error(String paramString1, Object[] paramArrayOfObject, String paramString2) {
/*  64 */     MDC.put("eap_monitor_log_type", paramString2);
/*  65 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  66 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  67 */     MDC.put("eap_monitor_classname", str1);
/*  68 */     MDC.put("eap_monitor_methodname", str2);
/*  69 */     this.logger.error(paramString1, paramArrayOfObject);
/*  70 */     MDC.remove("eap_monitor_log_type");
/*  71 */     MDC.remove("eap_monitor_classname");
/*  72 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void info(String paramString1, Object[] paramArrayOfObject, String paramString2, Object paramObject)
/*     */   {
/*  77 */     MDC.put("eap_monitor_log_type", paramString2);
/*  78 */     MDC.put("eap_monitor_extend_content", paramObject);
/*  79 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  80 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  81 */     MDC.put("eap_monitor_classname", str1);
/*  82 */     MDC.put("eap_monitor_methodname", str2);
/*  83 */     this.logger.info(paramString1, paramArrayOfObject);
/*  84 */     MDC.remove("eap_monitor_log_type");
/*  85 */     MDC.remove("eap_monitor_extend_content");
/*  86 */     MDC.remove("eap_monitor_classname");
/*  87 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void debug(String paramString1, Object[] paramArrayOfObject, String paramString2, Object paramObject) {
/*  91 */     MDC.put("eap_monitor_log_type", paramString2);
/*  92 */     MDC.put("eap_monitor_extend_content", paramObject);
/*  93 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/*  94 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/*  95 */     MDC.put("eap_monitor_classname", str1);
/*  96 */     MDC.put("eap_monitor_methodname", str2);
/*  97 */     this.logger.debug(paramString1, paramArrayOfObject);
/*  98 */     MDC.remove("eap_monitor_log_type");
/*  99 */     MDC.remove("eap_monitor_extend_content");
/* 100 */     MDC.remove("eap_monitor_classname");
/* 101 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void warn(String paramString1, Object[] paramArrayOfObject, String paramString2, Object paramObject)
/*     */   {
/* 106 */     MDC.put("eap_monitor_log_type", paramString2);
/* 107 */     MDC.put("eap_monitor_extend_content", paramObject);
/* 108 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/* 109 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/* 110 */     MDC.put("eap_monitor_classname", str1);
/* 111 */     MDC.put("eap_monitor_methodname", str2);
/* 112 */     this.logger.warn(paramString1, paramArrayOfObject);
/* 113 */     MDC.remove("eap_monitor_log_type");
/* 114 */     MDC.remove("eap_monitor_extend_content");
/* 115 */     MDC.remove("eap_monitor_classname");
/* 116 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ 
/*     */   public void error(String paramString1, Object[] paramArrayOfObject, String paramString2, Object paramObject) {
/* 120 */     MDC.put("eap_monitor_log_type", paramString2);
/* 121 */     MDC.put("eap_monitor_extend_content", paramObject);
/* 122 */     String str1 = new java.lang.Exception().getStackTrace()[1].getClassName();
/* 123 */     String str2 = new java.lang.Exception().getStackTrace()[1].getMethodName();
/* 124 */     MDC.put("eap_monitor_classname", str1);
/* 125 */     MDC.put("eap_monitor_methodname", str2);
/* 126 */     this.logger.error(paramString1, paramArrayOfObject);
/* 127 */     MDC.remove("eap_monitor_log_type");
/* 128 */     MDC.remove("eap_monitor_extend_content");
/* 129 */     MDC.remove("eap_monitor_classname");
/* 130 */     MDC.remove("eap_monitor_methodname");
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.log.LoggerProxy
 * JD-Core Version:    0.6.2
 */