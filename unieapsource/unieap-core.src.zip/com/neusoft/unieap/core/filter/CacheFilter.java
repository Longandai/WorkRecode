/*    */ package com.neusoft.unieap.core.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class CacheFilter
/*    */   implements Filter
/*    */ {
/* 16 */   private String cacheControl = "public";
/*    */ 
/* 18 */   private boolean forceCache = false;
/*    */ 
/* 20 */   private long expiresTime = 0L;
/*    */ 
/*    */   public void init(FilterConfig paramFilterConfig) throws ServletException {
/* 23 */     if (paramFilterConfig.getInitParameter("Cache-Control") != null) {
/* 24 */       this.cacheControl = paramFilterConfig.getInitParameter("Cache-Control");
/*    */     }
/* 26 */     if (paramFilterConfig.getInitParameter("Expires") != null) {
/* 27 */       String[] arrayOfString = paramFilterConfig.getInitParameter("Expires").split("x");
/* 28 */       this.expiresTime = 1L;
/* 29 */       for (int i = 0; i < arrayOfString.length; i++) {
/* 30 */         this.expiresTime *= Long.parseLong(arrayOfString[i]);
/*    */       }
/*    */     }
/* 33 */     if (paramFilterConfig.getInitParameter("forceCache") != null)
/* 34 */       this.forceCache = "true".equalsIgnoreCase(paramFilterConfig.getInitParameter("forceCache"));
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
/*    */     throws IOException, ServletException
/*    */   {
/* 42 */     if (this.forceCache) {
/* 43 */       HttpServletResponse localHttpServletResponse = (HttpServletResponse)paramServletResponse;
/* 44 */       localHttpServletResponse.setDateHeader("Expires", System.currentTimeMillis() + this.expiresTime);
/* 45 */       localHttpServletResponse.setHeader("Cache-Control", this.cacheControl);
/*    */     }
/* 47 */     paramFilterChain.doFilter(paramServletRequest, paramServletResponse);
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 51 */     this.cacheControl = "public";
/* 52 */     this.expiresTime = 0L;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.filter.CacheFilter
 * JD-Core Version:    0.6.2
 */