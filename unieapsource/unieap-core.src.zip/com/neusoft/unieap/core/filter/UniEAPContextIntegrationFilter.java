/*     */ package com.neusoft.unieap.core.filter;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.context.impl.UniEAPContextImpl;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.dataSource.DataSourceContextHolder;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.i18n.util.LocaleUtil;
/*     */ import com.neusoft.unieap.core.protection.Protection;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.servlet.Filter;
/*     */ import javax.servlet.FilterChain;
/*     */ import javax.servlet.FilterConfig;
/*     */ import javax.servlet.ServletException;
/*     */ import javax.servlet.ServletRequest;
/*     */ import javax.servlet.ServletResponse;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpSession;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class UniEAPContextIntegrationFilter
/*     */   implements Filter
/*     */ {
/*  41 */   protected static final Log logger = LogFactory.getLog(UniEAPContextIntegrationFilter.class);
/*     */   private static final String FILTER_APPLIED = "_unieap_session_integration_filter_applied";
/*     */ 
/*     */   public void destroy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
/*     */     throws IOException, ServletException
/*     */   {
/*  59 */     if (paramServletRequest == null) {
/*  60 */       return;
/*     */     }
/*     */ 
/*  67 */     String str = Protection.check(paramServletRequest, paramServletResponse);
/*  68 */     if ((str != null) && (!"".equals(str))) {
/*  69 */       paramServletResponse.getWriter().write(str);
/*  70 */       return;
/*     */     }
/*     */ 
/*  77 */     if (paramServletRequest.getAttribute("_unieap_session_integration_filter_applied") != null)
/*     */     {
/*     */       try {
/*  80 */         paramFilterChain.doFilter(paramServletRequest, paramServletResponse);
/*     */       } catch (Exception localException) {
/*  82 */         localException.printStackTrace();
/*     */       } finally {
/*  84 */         DataSourceContextHolder.clearDataSourceType();
/*  85 */         UnieapRequestContextHolder.clearPojoContext();
/*     */       }
/*     */     }
/*     */     else {
/*  89 */       paramServletRequest.setAttribute("_unieap_session_integration_filter_applied", Boolean.TRUE);
/*  90 */       UniEAPContextHolder.setContext(null);
/*     */ 
/*  92 */       HttpSession localHttpSession = null;
/*     */       try
/*     */       {
/*  95 */         localHttpSession = ((HttpServletRequest)paramServletRequest).getSession(false);
/*     */       } catch (IllegalStateException localIllegalStateException1) {
/*  97 */         if (logger.isWarnEnabled()) {
/*  98 */           logger.warn("No HttpSession currently exists");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 103 */       if (GlobalService.isEnabled()) {
/* 104 */         setRequestLocale(paramServletRequest, localHttpSession);
/*     */       }
/*     */ 
/* 107 */       if (localHttpSession != null)
/*     */       {
/* 109 */         Object localObject2 = (UniEAPContext)localHttpSession
/* 110 */           .getAttribute("com.neusoft.unieap.core.context.UniEAPContext");
/*     */ 
/* 112 */         if (localObject2 == null) {
/* 113 */           localObject2 = new UniEAPContextImpl();
/*     */         }
/* 115 */         UniEAPContextHolder.setContext((UniEAPContext)localObject2);
/*     */       }
/*     */ 
/* 119 */       localHttpSession = null;
/*     */       try
/*     */       {
/* 123 */         paramFilterChain.doFilter(paramServletRequest, paramServletResponse);
/*     */       }
/*     */       catch (IOException localIOException) {
/* 126 */         throw localIOException;
/*     */       } catch (ServletException localServletException) {
/* 128 */         throw localServletException;
/*     */       } finally {
/* 130 */         DataSourceContextHolder.clearDataSourceType();
/* 131 */         UnieapRequestContextHolder.clearPojoContext();
/*     */         try {
/* 133 */           localHttpSession = ((HttpServletRequest)paramServletRequest)
/* 134 */             .getSession(false);
/*     */         } catch (IllegalStateException localIllegalStateException2) {
/* 136 */           if (logger.isWarnEnabled()) {
/* 137 */             logger.warn("No HttpSession currently exists");
/*     */           }
/*     */         }
/*     */ 
/* 141 */         if (localHttpSession != null)
/* 142 */           localHttpSession.setAttribute("com.neusoft.unieap.core.context.UniEAPContext", 
/* 143 */             UniEAPContextHolder.getContext());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setRequestLocale(ServletRequest paramServletRequest, HttpSession paramHttpSession)
/*     */   {
/* 160 */     Locale localLocale2 = null;
/*     */ 
/* 162 */     if (paramHttpSession != null) {
/* 163 */       localLocale2 = (Locale)paramHttpSession.getAttribute("WW_TRANS_I18N_LOCALE");
/*     */     }
/*     */ 
/* 166 */     if (localLocale2 == null) {
/* 167 */       localLocale2 = paramServletRequest.getLocale();
/*     */     }
/*     */ 
/* 170 */     if (localLocale2 == null) {
/* 171 */       localLocale2 = GlobalService.getDefaultI18nContext().getLocale();
/*     */     }
/*     */ 
/* 174 */     String str = paramServletRequest.getParameter("request_locale");
/*     */ 
/* 176 */     if ((str != null) && (str.trim().length() > 0)) {
/* 177 */       localLocale1 = 
/* 178 */         LocaleUtil.localeFromString(str.trim(), localLocale2);
/* 179 */       if (paramHttpSession != null)
/* 180 */         paramHttpSession.setAttribute("WW_TRANS_I18N_LOCALE", localLocale1);
/*     */     }
/*     */     else {
/* 183 */       localLocale1 = localLocale2;
/*     */     }
/*     */ 
/* 186 */     Locale localLocale1 = LocaleUtil.selectSupportedLocale(localLocale1);
/* 187 */     I18nContext localI18nContext = new I18nContext();
/* 188 */     localI18nContext.setLocale(localLocale1);
/*     */ 
/* 191 */     UnieapRequestContextHolder.getRequestContext().put("i18nContext", localI18nContext);
/*     */   }
/*     */ 
/*     */   public void init(FilterConfig paramFilterConfig)
/*     */     throws ServletException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.filter.UniEAPContextIntegrationFilter
 * JD-Core Version:    0.6.2
 */