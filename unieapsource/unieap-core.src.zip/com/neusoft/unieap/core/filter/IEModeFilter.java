/*    */ package com.neusoft.unieap.core.filter;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.servlet.Filter;
/*    */ import javax.servlet.FilterChain;
/*    */ import javax.servlet.FilterConfig;
/*    */ import javax.servlet.ServletException;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ import javax.servlet.http.HttpServletResponse;
/*    */ 
/*    */ public class IEModeFilter
/*    */   implements Filter
/*    */ {
/* 25 */   private String mode = "IE=8";
/*    */ 
/*    */   public void destroy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public void doFilter(ServletRequest paramServletRequest, ServletResponse paramServletResponse, FilterChain paramFilterChain)
/*    */     throws IOException, ServletException
/*    */   {
/* 36 */     String str1 = ((HttpServletRequest)paramServletRequest)
/* 37 */       .getHeader("user-agent");
/* 38 */     HttpServletResponse localHttpServletResponse = (HttpServletResponse)paramServletResponse;
/* 39 */     if (str1 != null) {
/* 40 */       if (str1.contains("MSIE")) {
/* 41 */         String str2 = str1.substring(str1.indexOf("MSIE"))
/* 42 */           .split(";")[0];
/* 43 */         if (str2.length() > 0) {
/* 44 */           String[] arrayOfString = str2.split(" ");
/* 45 */           if ((arrayOfString.length == 2) && 
/* 46 */             (arrayOfString[0].equals("MSIE")) && 
/* 47 */             (arrayOfString[1].length() > 0) && 
/* 48 */             (Double.valueOf(arrayOfString[1]).doubleValue() >= 8.0D)) {
/* 49 */             localHttpServletResponse.setHeader("x-ua-compatible", this.mode);
/*    */           }
/*    */ 
/*    */         }
/*    */ 
/*    */       }
/* 55 */       else if (str1
/* 55 */         .contains("WOW64; Trident/7.0; rv:11.0) like Gecko")) {
/* 56 */         localHttpServletResponse.setHeader("x-ua-compatible", this.mode);
/*    */       }
/*    */     }
/* 59 */     paramFilterChain.doFilter(paramServletRequest, localHttpServletResponse);
/*    */   }
/*    */ 
/*    */   public void init(FilterConfig paramFilterConfig) throws ServletException {
/* 63 */     String str = paramFilterConfig.getInitParameter("mode");
/* 64 */     if (str != null)
/* 65 */       this.mode = str;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.filter.IEModeFilter
 * JD-Core Version:    0.6.2
 */