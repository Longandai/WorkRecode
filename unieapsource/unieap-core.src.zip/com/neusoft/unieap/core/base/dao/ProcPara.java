/*     */ package com.neusoft.unieap.core.base.dao;
/*     */ 
/*     */ public class ProcPara
/*     */ {
/*     */   private String _javaType;
/*     */   public static final int IN = 1;
/*     */   public static final int INOUT = 2;
/*     */   public static final int OUT = 4;
/*     */   public static final int UNVALID_DBTYPE = -99999;
/*     */   private int _dbType;
/*     */   protected String _name;
/*     */   protected int _procIndex;
/*     */   protected Object _value;
/*     */   protected int _ioType;
/*     */ 
/*     */   public ProcPara()
/*     */   {
/*  11 */     this._dbType = -99999;
/*     */ 
/*  13 */     this._name = "";
/*     */ 
/*  15 */     this._value = null;
/*     */ 
/*  17 */     this._ioType = -99999;
/*     */   }
/*     */ 
/*     */   public ProcPara(String paramString, int paramInt, Object paramObject)
/*     */   {
/*  25 */     this._dbType = -99999;
/*     */ 
/*  27 */     this._name = "";
/*     */ 
/*  29 */     this._value = null;
/*     */ 
/*  31 */     this._ioType = -99999;
/*     */ 
/*  33 */     this._name = paramString;
/*     */ 
/*  35 */     this._ioType = paramInt;
/*     */ 
/*  37 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public ProcPara(int paramInt1, int paramInt2, Object paramObject)
/*     */   {
/*  45 */     this._dbType = -99999;
/*     */ 
/*  47 */     this._name = "";
/*     */ 
/*  49 */     this._value = null;
/*     */ 
/*  51 */     this._ioType = -99999;
/*     */ 
/*  53 */     this._procIndex = paramInt1;
/*     */ 
/*  55 */     this._ioType = paramInt2;
/*     */ 
/*  57 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public ProcPara(String paramString, int paramInt1, int paramInt2)
/*     */   {
/*  65 */     this._dbType = -99999;
/*     */ 
/*  67 */     this._name = "";
/*     */ 
/*  69 */     this._value = null;
/*     */ 
/*  71 */     this._ioType = -99999;
/*     */ 
/*  73 */     this._name = paramString;
/*     */ 
/*  75 */     this._dbType = paramInt2;
/*     */ 
/*  77 */     this._ioType = paramInt1;
/*     */   }
/*     */ 
/*     */   public ProcPara(int paramInt1, int paramInt2, int paramInt3)
/*     */   {
/*  85 */     this._dbType = -99999;
/*     */ 
/*  87 */     this._name = "";
/*     */ 
/*  89 */     this._value = null;
/*     */ 
/*  91 */     this._ioType = -99999;
/*     */ 
/*  93 */     this._procIndex = paramInt1;
/*     */ 
/*  95 */     this._dbType = paramInt3;
/*     */ 
/*  97 */     this._ioType = paramInt2;
/*     */   }
/*     */ 
/*     */   public ProcPara(String paramString, int paramInt1, Object paramObject, int paramInt2)
/*     */   {
/* 105 */     this(paramString, paramInt1, paramInt2);
/*     */ 
/* 107 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public ProcPara(int paramInt1, int paramInt2, Object paramObject, int paramInt3)
/*     */   {
/* 115 */     this(paramInt1, paramInt2, paramInt3);
/*     */ 
/* 117 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public ProcPara(int paramInt, Object paramObject)
/*     */   {
/* 125 */     this._dbType = -99999;
/*     */ 
/* 127 */     this._name = "";
/*     */ 
/* 129 */     this._value = null;
/*     */ 
/* 131 */     this._ioType = -99999;
/*     */ 
/* 133 */     this._procIndex = paramInt;
/*     */ 
/* 135 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public ProcPara(String paramString, Object paramObject)
/*     */   {
/* 143 */     this._dbType = -99999;
/*     */ 
/* 145 */     this._name = "";
/*     */ 
/* 147 */     this._value = null;
/*     */ 
/* 149 */     this._ioType = -99999;
/*     */ 
/* 151 */     this._name = paramString;
/*     */ 
/* 153 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 161 */     return this._name;
/*     */   }
/*     */ 
/*     */   public void setName(String paramString)
/*     */   {
/* 169 */     this._name = paramString;
/*     */   }
/*     */ 
/*     */   public int getParaIndex()
/*     */   {
/* 177 */     return this._procIndex;
/*     */   }
/*     */ 
/*     */   public void setParaIndex(int paramInt)
/*     */   {
/* 185 */     this._procIndex = paramInt;
/*     */   }
/*     */ 
/*     */   public boolean isInPara()
/*     */   {
/* 193 */     return this._ioType == 1;
/*     */   }
/*     */ 
/*     */   public boolean isOutPara()
/*     */   {
/* 201 */     return this._ioType == 4;
/*     */   }
/*     */ 
/*     */   public boolean isInOutPara()
/*     */   {
/* 209 */     return this._ioType == 2;
/*     */   }
/*     */ 
/*     */   public Object getValue()
/*     */   {
/* 217 */     return this._value;
/*     */   }
/*     */ 
/*     */   public void setValue(Object paramObject)
/*     */   {
/* 225 */     this._value = paramObject;
/*     */   }
/*     */ 
/*     */   public int getDBType()
/*     */   {
/* 233 */     return this._dbType;
/*     */   }
/*     */ 
/*     */   public void setDBType(int paramInt)
/*     */   {
/* 241 */     this._dbType = paramInt;
/*     */   }
/*     */ 
/*     */   public int getIOType()
/*     */   {
/* 249 */     return this._ioType;
/*     */   }
/*     */ 
/*     */   public void setIOType(int paramInt)
/*     */   {
/* 257 */     this._ioType = paramInt;
/*     */   }
/*     */ 
/*     */   public String getJavaType()
/*     */   {
/* 265 */     return this._javaType;
/*     */   }
/*     */ 
/*     */   public void setJavaType(String paramString)
/*     */   {
/* 273 */     this._javaType = paramString;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 281 */     StringBuffer localStringBuffer = new StringBuffer(200);
/*     */ 
/* 283 */     return new StringBuilder(String.valueOf(getName())).append(": index=").append(this._procIndex).append(",value=").append(this._value).append(",is an ").append(getInOutStr()).append(" parameter").toString();
/*     */   }
/*     */ 
/*     */   private String getInOutStr()
/*     */   {
/* 291 */     return isOutPara() ? "OUT" : isInPara() ? "IN" : "INOUT";
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.dao.ProcPara
 * JD-Core Version:    0.6.2
 */