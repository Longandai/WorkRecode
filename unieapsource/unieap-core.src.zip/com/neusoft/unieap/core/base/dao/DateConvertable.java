package com.neusoft.unieap.core.base.dao;

public abstract interface DateConvertable
{
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.dao.DateConvertable
 * JD-Core Version:    0.6.2
 */