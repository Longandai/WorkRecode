/*      */ package com.neusoft.unieap.core.base.dao;
/*      */ 
/*      */ import com.neusoft.unieap.core.CoreVariability;
/*      */ import com.neusoft.unieap.core.base.audit.Auditable;
/*      */ import com.neusoft.unieap.core.base.exception.CoreException;
/*      */ import com.neusoft.unieap.core.base.model.DCRepository;
/*      */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*      */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*      */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*      */ import com.neusoft.unieap.core.context.UniEAPContext;
/*      */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*      */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*      */ import com.neusoft.unieap.core.context.properties.User;
/*      */ import com.neusoft.unieap.core.i18n.GlobalService;
/*      */ import com.neusoft.unieap.core.i18n.GlobalUtil;
/*      */ import com.neusoft.unieap.core.page.Page;
/*      */ import com.neusoft.unieap.core.page.PageContext;
/*      */ import com.neusoft.unieap.core.page.PageResult;
/*      */ import com.neusoft.unieap.core.page.PageUtil;
/*      */ import com.neusoft.unieap.core.page.impl.PageResultImpl;
/*      */ import com.neusoft.unieap.core.sql.AliasToDtoResultTransformer;
/*      */ import com.neusoft.unieap.core.sql.Property;
/*      */ import com.neusoft.unieap.core.sql.SqlMapping;
/*      */ import com.neusoft.unieap.core.sql.SqlMappingContext;
/*      */ import com.neusoft.unieap.core.statement.Statement;
/*      */ import com.neusoft.unieap.core.statement.impl.StatementImpl;
/*      */ import com.neusoft.unieap.core.util.SequenceUtil;
/*      */ import java.io.File;
/*      */ import java.io.Serializable;
/*      */ import java.lang.reflect.Field;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.beanutils.PropertyUtils;
/*      */ import org.hibernate.Query;
/*      */ import org.hibernate.SQLQuery;
/*      */ import org.hibernate.Session;
/*      */ import org.hibernate.SessionFactory;
/*      */ import org.hibernate.dialect.Dialect;
/*      */ import org.hibernate.dialect.SQLServerDialect;
/*      */ import org.hibernate.engine.EntityEntry;
/*      */ import org.hibernate.engine.ForeignKeys;
/*      */ import org.hibernate.engine.PersistenceContext;
/*      */ import org.hibernate.engine.SessionImplementor;
/*      */ import org.hibernate.event.EventSource;
/*      */ import org.hibernate.impl.SessionFactoryImpl;
/*      */ import org.hibernate.transform.Transformers;
/*      */ import org.hibernate.type.TypeFactory;
/*      */ import org.hibernate.util.ReflectHelper;
/*      */ import org.springframework.orm.hibernate3.HibernateCallback;
/*      */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*      */ import org.springframework.orm.hibernate3.SessionFactoryUtils;
/*      */ import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
/*      */ 
/*      */ public class BaseHibernateDAO extends HibernateDaoSupport
/*      */ {
/*      */   public Session getCurrentSession()
/*      */   {
/*   67 */     return getSession();
/*      */   }
/*      */ 
/*      */   public Serializable addObject(Object paramObject)
/*      */     throws CoreException
/*      */   {
/*   87 */     SequenceUtil.saveSequenceInfo(getSession(), paramObject);
/*   88 */     saveAuditInfo(paramObject);
/*   89 */     convertLocaleDateToGMT(paramObject);
/*   90 */     return getHibernateTemplate().save(paramObject);
/*      */   }
/*      */ 
/*      */   public void removeObject(Object paramObject)
/*      */     throws CoreException
/*      */   {
/*  110 */     getHibernateTemplate().delete(paramObject);
/*      */   }
/*      */ 
/*      */   public void updateObject(Object paramObject)
/*      */     throws CoreException
/*      */   {
/*  130 */     updateAuditInfo(paramObject);
/*  131 */     convertLocaleDateToGMT(paramObject);
/*  132 */     getHibernateTemplate().update(paramObject);
/*      */   }
/*      */ 
/*      */   public Object queryObject(String paramString)
/*      */     throws CoreException
/*      */   {
/*  153 */     List localList = getHibernateTemplate().find(paramString);
/*  154 */     Object localObject = localList.isEmpty() ? null : localList.get(0);
/*  155 */     convertGMTToLocaleDate(localObject);
/*      */ 
/*  157 */     return localObject;
/*      */   }
/*      */ 
/*      */   public Object queryObject(String paramString, Object paramObject)
/*      */     throws CoreException
/*      */   {
/*  182 */     List localList = getHibernateTemplate().find(paramString, paramObject);
/*  183 */     Object localObject = localList.isEmpty() ? null : localList.get(0);
/*  184 */     convertGMTToLocaleDate(localObject);
/*      */ 
/*  186 */     return localObject;
/*      */   }
/*      */ 
/*      */   public Object queryObject(String paramString, Object[] paramArrayOfObject)
/*      */     throws CoreException
/*      */   {
/*  211 */     List localList = getHibernateTemplate().find(paramString, paramArrayOfObject);
/*  212 */     Object localObject = localList.isEmpty() ? null : localList.get(0);
/*  213 */     convertGMTToLocaleDate(localObject);
/*      */ 
/*  215 */     return localObject;
/*      */   }
/*      */ 
/*      */   public List queryObjects(String paramString)
/*      */     throws CoreException
/*      */   {
/*  236 */     List localList = getHibernateTemplate().find(paramString);
/*  237 */     convertGMTToLocaleDate(localList);
/*      */ 
/*  239 */     return localList;
/*      */   }
/*      */ 
/*      */   public List queryObjects(String paramString, Object paramObject)
/*      */     throws CoreException
/*      */   {
/*  264 */     List localList = getHibernateTemplate().find(paramString, paramObject);
/*  265 */     convertGMTToLocaleDate(localList);
/*      */ 
/*  267 */     return localList;
/*      */   }
/*      */ 
/*      */   public List queryObjects(String paramString, Object[] paramArrayOfObject)
/*      */     throws CoreException
/*      */   {
/*  292 */     List localList = getHibernateTemplate().find(paramString, paramArrayOfObject);
/*  293 */     convertGMTToLocaleDate(localList);
/*      */ 
/*  295 */     return localList;
/*      */   }
/*      */ 
/*      */   public List queryObjects(final String paramString, final Object[] paramArrayOfObject, final int paramInt1, final int paramInt2)
/*      */     throws CoreException
/*      */   {
/*  329 */     List localList = (List)getHibernateTemplate().execute(
/*  330 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/*  333 */           Query localQuery = paramAnonymousSession.createQuery(paramString);
/*  334 */           if (paramArrayOfObject != null) {
/*  335 */             int i = 0; for (int j = paramArrayOfObject.length; i < j; i++) {
/*  336 */               localQuery.setParameter(i, paramArrayOfObject[i]);
/*      */             }
/*      */           }
/*  339 */           if (paramInt2 > 0) {
/*  340 */             localQuery.setMaxResults(paramInt2);
/*  341 */             localQuery.setFirstResult((paramInt1 - 1) * 
/*  342 */               paramInt2);
/*      */           }
/*  344 */           return localQuery.list();
/*      */         } catch (Exception localException) {
/*  346 */           Object localObject = localException;
/*  347 */           if (localException.getCause() != null) {
/*  348 */             localObject = localException.getCause();
/*      */           }
/*  350 */           throw new CoreException(
/*  351 */             "EAPTECH001100", (Throwable)localObject, 
/*  352 */             new String[] { ((Throwable)localObject).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     });
/*  357 */     convertGMTToLocaleDate(localList);
/*      */ 
/*  359 */     return localList;
/*      */   }
/*      */ 
/*      */   public QueryResult queryObjectsByPage(String paramString, Object[] paramArrayOfObject)
/*      */     throws CoreException
/*      */   {
/*  384 */     boolean bool = false;
/*  385 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/*  386 */     int i = CoreVariability.getMaxPageSize();
/*  387 */     int j = 1;
/*  388 */     if (localQueryResult != null) {
/*  389 */       i = localQueryResult.getPageSize();
/*  390 */       j = localQueryResult.getPageNumber();
/*  391 */       bool = localQueryResult.isAutoCalcCount();
/*      */     }
/*  393 */     localQueryResult = new QueryResult();
/*  394 */     localQueryResult.setPageNumber(j);
/*  395 */     localQueryResult.setPageSize(i);
/*  396 */     int k = i;
/*  397 */     int m = j;
/*  398 */     List localList = queryObjects(paramString, paramArrayOfObject, m, 
/*  399 */       k);
/*  400 */     localQueryResult.setResult(localList);
/*  401 */     if (bool) {
/*  402 */       if ((m == 1) && ((localList == null) || (localList.size() < k))) {
/*  403 */         localQueryResult.setRecordCount(localList == null ? 0 : localList.size());
/*      */       } else {
/*  405 */         int n = getTotalCount(paramString, paramArrayOfObject);
/*  406 */         localQueryResult.setRecordCount(n);
/*      */       }
/*      */     }
/*  409 */     SessionFactory localSessionFactory = getSessionFactory();
/*  410 */     PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/*  411 */       "HQL", paramString, paramArrayOfObject, null, null, 
/*  412 */       SessionFactoryUtils.getDataSource(localSessionFactory), localSessionFactory);
/*  413 */     localQueryResult.setPageContext(localPageContext);
/*  414 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   private void saveAuditInfo(Object paramObject)
/*      */   {
/*  423 */     if ((paramObject instanceof Auditable)) {
/*  424 */       Auditable localAuditable = (Auditable)paramObject;
/*  425 */       Timestamp localTimestamp = new Timestamp(System.currentTimeMillis());
/*  426 */       if (UniEAPContextHolder.getContext().getCurrentUser() != null)
/*      */       {
/*  428 */         localAuditable.setCreatedBy(UniEAPContextHolder.getContext()
/*  429 */           .getCurrentUser().getAccount());
/*  430 */         localAuditable.setModifiedBy(UniEAPContextHolder.getContext()
/*  431 */           .getCurrentUser().getAccount());
/*      */       }
/*  433 */       localAuditable.setCreationTime(localTimestamp);
/*  434 */       localAuditable.setModificationTime(localTimestamp);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void updateAuditInfo(Object paramObject)
/*      */   {
/*  445 */     if ((paramObject instanceof Auditable)) {
/*  446 */       Auditable localAuditable = (Auditable)paramObject;
/*  447 */       Timestamp localTimestamp = new Timestamp(System.currentTimeMillis());
/*  448 */       localAuditable.setModificationTime(localTimestamp);
/*  449 */       if (UniEAPContextHolder.getContext().getCurrentUser() != null)
/*  450 */         localAuditable.setModifiedBy(UniEAPContextHolder.getContext()
/*  451 */           .getCurrentUser().getAccount());
/*      */     }
/*      */   }
/*      */ 
/*      */   public Page getPage()
/*      */   {
/*  461 */     Page localPage = (Page)UniEAPContextHolder.getContext().getCustomProperty(
/*  462 */       "UNIEAP_PAGE");
/*  463 */     return localPage;
/*      */   }
/*      */ 
/*      */   public PageResult getPageResult(String paramString, Page paramPage)
/*      */   {
/*  476 */     if ((paramString == null) || ("".equals(paramString.trim()))) {
/*  477 */       throw new IllegalArgumentException("inPut queryHQL is null");
/*      */     }
/*  479 */     if (paramPage == null) {
/*  480 */       throw new IllegalArgumentException("inPut Page is null");
/*      */     }
/*  482 */     PageResultImpl localPageResultImpl = new PageResultImpl();
/*  483 */     int i = paramPage.getSize();
/*  484 */     long l1 = getTotalCount(paramString, paramPage);
/*  485 */     localPageResultImpl.setTotalCount(l1);
/*  486 */     long l2 = l1 / i;
/*  487 */     if (l1 % i > 0L) {
/*  488 */       l2 += 1L;
/*      */     }
/*  490 */     localPageResultImpl.setTotalPage(l2);
/*  491 */     List localList = getResult(paramString, paramPage);
/*  492 */     localPageResultImpl.setResultSet(localList);
/*  493 */     localPageResultImpl.setPage(paramPage);
/*  494 */     return localPageResultImpl;
/*      */   }
/*      */ 
/*      */   private List getResult(final String paramString, final Page paramPage)
/*      */   {
/*  505 */     List localList = (List)getHibernateTemplate().execute(
/*  506 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/*  509 */           Query localQuery = paramAnonymousSession.createQuery(paramString);
/*  510 */           if (paramString.indexOf("?") > 0) {
/*  511 */             List localList = paramPage
/*  512 */               .getConditionValues();
/*  513 */             if ((localList == null) || 
/*  514 */               (localList.isEmpty())) {
/*  515 */               throw new CoreException(
/*  516 */                 "EAPTECH001110", 
/*  517 */                 new String[] { paramString });
/*      */             }
/*  519 */             for (j = 0; j < localList.size(); j++) {
/*  520 */               localQuery.setParameter(j, localList
/*  521 */                 .get(j));
/*      */             }
/*      */           }
/*  524 */           int i = paramPage.getSize();
/*  525 */           int j = paramPage.getPageNumber();
/*  526 */           if (i > 0) {
/*  527 */             localQuery.setMaxResults(i);
/*  528 */             localQuery.setFirstResult((j - 1) * 
/*  529 */               i);
/*      */           }
/*  531 */           return localQuery.list();
/*      */         } catch (Exception localException) {
/*  533 */           Object localObject = localException;
/*  534 */           if (localException.getCause() != null) {
/*  535 */             localObject = localException.getCause();
/*      */           }
/*  537 */           throw new CoreException(
/*  538 */             "EAPTECH001100", (Throwable)localObject, 
/*  539 */             new String[] { ((Throwable)localObject).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     });
/*  543 */     convertGMTToLocaleDate(localList);
/*  544 */     return localList;
/*      */   }
/*      */ 
/*      */   void convertLocaleDateToGMT(Object paramObject)
/*      */   {
/*  554 */     if ((GlobalService.isEnabled()) && ((paramObject instanceof DateConvertable)))
/*      */       try
/*      */       {
/*  557 */         Map localMap = PropertyUtils.describe(paramObject);
/*      */ 
/*  559 */         Iterator localIterator = localMap.entrySet().iterator();
/*  560 */         while (localIterator.hasNext()) {
/*  561 */           Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  562 */           String str = (String)localEntry.getKey();
/*      */ 
/*  564 */           Object localObject1 = localEntry.getValue();
/*  565 */           if (localObject1 == null) {
/*  566 */             return;
/*      */           }
/*  568 */           Object localObject2 = null;
/*  569 */           if ((localObject1 instanceof Timestamp))
/*  570 */             localObject2 = 
/*  571 */               GlobalUtil.convertToGMT((Timestamp)localObject1);
/*  572 */           else if ((localObject1 instanceof java.sql.Date))
/*  573 */             localObject2 = 
/*  574 */               GlobalUtil.convertToGMT((java.sql.Date)localObject1);
/*  575 */           else if ((localObject1 instanceof Time))
/*  576 */             localObject2 = 
/*  577 */               GlobalUtil.convertToGMT((Time)localObject1);
/*  578 */           else if ((localObject1 instanceof java.util.Date)) {
/*  579 */             localObject2 = 
/*  580 */               GlobalUtil.convertToGMT((java.util.Date)localObject1);
/*      */           }
/*      */ 
/*  583 */           if (localObject2 != null)
/*  584 */             PropertyUtils.setProperty(paramObject, str, 
/*  585 */               localObject2);
/*      */         }
/*      */       }
/*      */       catch (Exception localException) {
/*  589 */         throw new CoreException("EAPTECH001101", localException, 
/*  590 */           new String[0]);
/*      */       }
/*      */   }
/*      */ 
/*      */   void convertGMTToLocaleDate(Object paramObject)
/*      */   {
/*  602 */     if (GlobalService.isEnabled())
/*      */       try {
/*  604 */         convertToLocaleDate(paramObject);
/*      */       } catch (Exception localException) {
/*  606 */         throw new CoreException("EAPTECH001101", localException, 
/*  607 */           new String[0]);
/*      */       }
/*      */   }
/*      */ 
/*      */   void convertGMTToLocaleDate(List paramList)
/*      */   {
/*  619 */     if (GlobalService.isEnabled())
/*      */       try {
/*  621 */         Iterator localIterator = paramList.iterator();
/*  622 */         while (localIterator.hasNext())
/*  623 */           convertToLocaleDate(localIterator.next());
/*      */       }
/*      */       catch (Exception localException) {
/*  626 */         throw new CoreException("EAPTECH001101", localException, 
/*  627 */           new String[0]);
/*      */       }
/*      */   }
/*      */ 
/*      */   private void convertToLocaleDate(Object paramObject) throws Exception
/*      */   {
/*  633 */     if ((paramObject instanceof DateConvertable))
/*      */     {
/*  635 */       Map localMap = PropertyUtils.describe(paramObject);
/*  636 */       Iterator localIterator = localMap.entrySet().iterator();
/*  637 */       while (localIterator.hasNext()) {
/*  638 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/*  639 */         String str = (String)localEntry.getKey();
/*      */ 
/*  641 */         Object localObject1 = localEntry.getValue();
/*  642 */         if (localObject1 == null) {
/*  643 */           return;
/*      */         }
/*  645 */         Object localObject2 = null;
/*  646 */         if ((localObject1 instanceof Timestamp))
/*  647 */           localObject2 = 
/*  648 */             GlobalUtil.convertToLocal((Timestamp)localObject1);
/*  649 */         else if ((localObject1 instanceof java.sql.Date))
/*  650 */           localObject2 = 
/*  651 */             GlobalUtil.convertToLocal((java.sql.Date)localObject1);
/*  652 */         else if ((localObject1 instanceof Time))
/*  653 */           localObject2 = 
/*  654 */             GlobalUtil.convertToLocal((Time)localObject1);
/*  655 */         else if ((localObject1 instanceof java.util.Date)) {
/*  656 */           localObject2 = 
/*  657 */             GlobalUtil.convertToLocal((java.util.Date)localObject1);
/*      */         }
/*      */ 
/*  660 */         if (localObject2 != null)
/*  661 */           PropertyUtils.setProperty(paramObject, str, 
/*  662 */             localObject2);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getTotalCount(String paramString, final Object[] paramArrayOfObject)
/*      */   {
/*  678 */     String str1 = paramString.toLowerCase();
/*  679 */     int i = str1.indexOf("from");
/*  680 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/*  681 */       .getDialect();
/*  682 */     if ((localDialect instanceof SQLServerDialect)) {
/*  683 */       int j = str1.indexOf("order ");
/*  684 */       if (j > 0) {
/*  685 */         paramString = paramString.substring(0, j);
/*      */       }
/*      */     }
/*  688 */     StringBuffer localStringBuffer = new StringBuffer();
/*  689 */     int k = str1.indexOf("select");
/*  690 */     if ((k >= 0) && (k < i)) {
/*  691 */       str1 = paramString.substring(k, i);
/*  692 */       int m = str1.indexOf("distinct");
/*  693 */       if (m >= 0) {
/*  694 */         str1 = str1.replaceAll("\\(", "").replaceAll("\\)", "");
/*      */       }
/*  696 */       localStringBuffer.append("select count(").append(
/*  697 */         str1.substring(k + 6, str1.length())).append(") ");
/*      */     } else {
/*  699 */       localStringBuffer.append("select count(*) ");
/*      */     }
/*  701 */     final String str2 = 
/*  702 */       paramString.substring(i).replaceAll("(?i)fetch", "");
/*      */ 
/*  704 */     List localList = (List)getHibernateTemplate().execute(
/*  705 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*  707 */         Query localQuery = paramAnonymousSession.createQuery(str2);
/*  708 */         if ((str2.indexOf("?") > 0) && 
/*  709 */           (paramArrayOfObject != null)) {
/*  710 */           for (int i = 0; i < paramArrayOfObject.length; i++) {
/*  711 */             localQuery.setParameter(i, paramArrayOfObject[i]);
/*      */           }
/*      */         }
/*  714 */         return localQuery.list();
/*      */       }
/*      */     });
/*  717 */     return ((Long)localList.get(0)).intValue();
/*      */   }
/*      */ 
/*      */   private long getTotalCount(String paramString, final Page paramPage)
/*      */   {
/*  727 */     String str1 = paramString.toLowerCase();
/*  728 */     int i = str1.indexOf("from");
/*  729 */     int j = str1.indexOf("order ");
/*  730 */     if (j > 0) {
/*  731 */       paramString = paramString.substring(0, j);
/*      */     }
/*  733 */     StringBuffer localStringBuffer = new StringBuffer();
/*  734 */     localStringBuffer.append("select count(*) ");
/*  735 */     final String str2 = 
/*  736 */       paramString.substring(i);
/*  737 */     List localList = (List)getHibernateTemplate().execute(
/*  738 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*  740 */         Query localQuery = paramAnonymousSession.createQuery(str2);
/*  741 */         if (str2.indexOf("?") > 0) {
/*  742 */           List localList = paramPage.getConditionValues();
/*  743 */           if ((localList == null) || 
/*  744 */             (localList.isEmpty())) {
/*  745 */             throw new CoreException(
/*  746 */               "EAPTECH001110", 
/*  747 */               new String[] { str2 });
/*      */           }
/*  749 */           for (int i = 0; i < localList.size(); i++) {
/*  750 */             localQuery.setParameter(i, localList.get(i));
/*      */           }
/*      */         }
/*  753 */         return localQuery.list();
/*      */       }
/*      */     });
/*  756 */     return ((Long)localList.get(0)).longValue();
/*      */   }
/*      */ 
/*      */   public QueryResult query(String paramString, Object[] paramArrayOfObject)
/*      */   {
/*  780 */     QueryResult localQueryResult = query(paramString, paramArrayOfObject, null);
/*  781 */     SessionFactory localSessionFactory = getSessionFactory();
/*  782 */     PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/*  783 */       "SQL", paramString, paramArrayOfObject, null, null, 
/*  784 */       SessionFactoryUtils.getDataSource(localSessionFactory), localSessionFactory);
/*  785 */     localQueryResult.setPageContext(localPageContext);
/*  786 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   public QueryResult query(final String paramString1, final Object[] paramArrayOfObject, final String paramString2)
/*      */   {
/*  815 */     boolean bool = false;
/*  816 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/*  817 */     int i = CoreVariability.getMaxPageSize();
/*  818 */     int j = 1;
/*  819 */     if (localQueryResult != null) {
/*  820 */       i = localQueryResult.getPageSize();
/*  821 */       j = localQueryResult.getPageNumber();
/*  822 */       bool = localQueryResult.isAutoCalcCount();
/*      */     }
/*  824 */     localQueryResult = new QueryResult();
/*  825 */     localQueryResult.setPageNumber(j);
/*  826 */     localQueryResult.setPageSize(i);
/*  827 */     final int k = i;
/*  828 */     final int m = j;
/*  829 */     List localList = (List)getHibernateTemplate().execute(
/*  830 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession)
/*      */       {
/*      */         // Byte code:
/*      */         //   0: iconst_0
/*      */         //   1: istore_2
/*      */         //   2: aload_1
/*      */         //   3: aload_0
/*      */         //   4: getfield 22	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$sql	Ljava/lang/String;
/*      */         //   7: invokeinterface 38 2 0
/*      */         //   12: astore_3
/*      */         //   13: aload_0
/*      */         //   14: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$args	[Ljava/lang/Object;
/*      */         //   17: ifnull +41 -> 58
/*      */         //   20: iconst_0
/*      */         //   21: istore 4
/*      */         //   23: goto +25 -> 48
/*      */         //   26: aload_3
/*      */         //   27: iload 4
/*      */         //   29: aload_0
/*      */         //   30: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$args	[Ljava/lang/Object;
/*      */         //   33: iload 4
/*      */         //   35: aaload
/*      */         //   36: invokeinterface 44 3 0
/*      */         //   41: checkcast 45	org/hibernate/SQLQuery
/*      */         //   44: astore_3
/*      */         //   45: iinc 4 1
/*      */         //   48: iload 4
/*      */         //   50: aload_0
/*      */         //   51: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$args	[Ljava/lang/Object;
/*      */         //   54: arraylength
/*      */         //   55: if_icmplt -29 -> 26
/*      */         //   58: aload_0
/*      */         //   59: getfield 26	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pojo	Ljava/lang/String;
/*      */         //   62: ifnonnull +19 -> 81
/*      */         //   65: aload_3
/*      */         //   66: getstatic 50	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   69: invokeinterface 56 2 0
/*      */         //   74: checkcast 45	org/hibernate/SQLQuery
/*      */         //   77: astore_3
/*      */         //   78: goto +206 -> 284
/*      */         //   81: aload_1
/*      */         //   82: invokeinterface 60 1 0
/*      */         //   87: invokeinterface 64 1 0
/*      */         //   92: aload_0
/*      */         //   93: getfield 26	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pojo	Ljava/lang/String;
/*      */         //   96: invokeinterface 70 2 0
/*      */         //   101: ifeq +20 -> 121
/*      */         //   104: aload_3
/*      */         //   105: aload_0
/*      */         //   106: getfield 26	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pojo	Ljava/lang/String;
/*      */         //   109: invokestatic 76	org/hibernate/util/ReflectHelper:classForName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */         //   112: invokeinterface 82 2 0
/*      */         //   117: astore_3
/*      */         //   118: goto +149 -> 267
/*      */         //   121: aload_0
/*      */         //   122: getfield 26	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pojo	Ljava/lang/String;
/*      */         //   125: invokestatic 76	org/hibernate/util/ReflectHelper:classForName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */         //   128: astore 4
/*      */         //   130: aload 4
/*      */         //   132: invokevirtual 86	java/lang/Class:getDeclaredFields	()[Ljava/lang/reflect/Field;
/*      */         //   135: astore 5
/*      */         //   137: iconst_0
/*      */         //   138: istore 6
/*      */         //   140: goto +56 -> 196
/*      */         //   143: aload 4
/*      */         //   145: aload 5
/*      */         //   147: iload 6
/*      */         //   149: aaload
/*      */         //   150: invokevirtual 92	java/lang/reflect/Field:getName	()Ljava/lang/String;
/*      */         //   153: invokestatic 98	org/hibernate/util/ReflectHelper:getGetter	(Ljava/lang/Class;Ljava/lang/String;)Lorg/hibernate/property/Getter;
/*      */         //   156: pop
/*      */         //   157: goto +7 -> 164
/*      */         //   160: pop
/*      */         //   161: goto +32 -> 193
/*      */         //   164: aload_3
/*      */         //   165: aload 5
/*      */         //   167: iload 6
/*      */         //   169: aaload
/*      */         //   170: invokevirtual 92	java/lang/reflect/Field:getName	()Ljava/lang/String;
/*      */         //   173: aload 5
/*      */         //   175: iload 6
/*      */         //   177: aaload
/*      */         //   178: invokevirtual 102	java/lang/reflect/Field:getType	()Ljava/lang/Class;
/*      */         //   181: invokevirtual 106	java/lang/Class:getName	()Ljava/lang/String;
/*      */         //   184: invokestatic 107	org/hibernate/type/TypeFactory:basic	(Ljava/lang/String;)Lorg/hibernate/type/Type;
/*      */         //   187: invokeinterface 113 3 0
/*      */         //   192: pop
/*      */         //   193: iinc 6 1
/*      */         //   196: iload 6
/*      */         //   198: aload 5
/*      */         //   200: arraylength
/*      */         //   201: if_icmplt -58 -> 143
/*      */         //   204: aload_3
/*      */         //   205: aload 4
/*      */         //   207: invokestatic 117	org/hibernate/transform/Transformers:aliasToBean	(Ljava/lang/Class;)Lorg/hibernate/transform/ResultTransformer;
/*      */         //   210: invokeinterface 56 2 0
/*      */         //   215: checkcast 45	org/hibernate/SQLQuery
/*      */         //   218: astore_3
/*      */         //   219: goto +48 -> 267
/*      */         //   222: pop
/*      */         //   223: iconst_1
/*      */         //   224: istore_2
/*      */         //   225: iload_2
/*      */         //   226: ifeq +58 -> 284
/*      */         //   229: aload_3
/*      */         //   230: getstatic 50	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   233: invokeinterface 56 2 0
/*      */         //   238: checkcast 45	org/hibernate/SQLQuery
/*      */         //   241: astore_3
/*      */         //   242: goto +42 -> 284
/*      */         //   245: astore 7
/*      */         //   247: iload_2
/*      */         //   248: ifeq +16 -> 264
/*      */         //   251: aload_3
/*      */         //   252: getstatic 50	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   255: invokeinterface 56 2 0
/*      */         //   260: checkcast 45	org/hibernate/SQLQuery
/*      */         //   263: astore_3
/*      */         //   264: aload 7
/*      */         //   266: athrow
/*      */         //   267: iload_2
/*      */         //   268: ifeq +16 -> 284
/*      */         //   271: aload_3
/*      */         //   272: getstatic 50	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   275: invokeinterface 56 2 0
/*      */         //   280: checkcast 45	org/hibernate/SQLQuery
/*      */         //   283: astore_3
/*      */         //   284: aload_0
/*      */         //   285: getfield 28	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pageSize	I
/*      */         //   288: ifle +32 -> 320
/*      */         //   291: aload_3
/*      */         //   292: aload_0
/*      */         //   293: getfield 28	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pageSize	I
/*      */         //   296: invokeinterface 121 2 0
/*      */         //   301: pop
/*      */         //   302: aload_3
/*      */         //   303: aload_0
/*      */         //   304: getfield 30	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pageNumber	I
/*      */         //   307: iconst_1
/*      */         //   308: isub
/*      */         //   309: aload_0
/*      */         //   310: getfield 28	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$5:val$pageSize	I
/*      */         //   313: imul
/*      */         //   314: invokeinterface 125 2 0
/*      */         //   319: pop
/*      */         //   320: aload_3
/*      */         //   321: invokeinterface 128 1 0
/*      */         //   326: areturn
/*      */         //   327: astore_2
/*      */         //   328: aload_2
/*      */         //   329: astore_3
/*      */         //   330: aload_2
/*      */         //   331: invokevirtual 132	java/lang/Exception:getCause	()Ljava/lang/Throwable;
/*      */         //   334: ifnull +8 -> 342
/*      */         //   337: aload_2
/*      */         //   338: invokevirtual 132	java/lang/Exception:getCause	()Ljava/lang/Throwable;
/*      */         //   341: astore_3
/*      */         //   342: new 138	com/neusoft/unieap/core/base/exception/CoreException
/*      */         //   345: dup
/*      */         //   346: ldc 140
/*      */         //   348: aload_3
/*      */         //   349: iconst_1
/*      */         //   350: anewarray 142	java/lang/String
/*      */         //   353: dup
/*      */         //   354: iconst_0
/*      */         //   355: aload_3
/*      */         //   356: invokevirtual 144	java/lang/Throwable:getLocalizedMessage	()Ljava/lang/String;
/*      */         //   359: aastore
/*      */         //   360: invokespecial 149	com/neusoft/unieap/core/base/exception/CoreException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/String;)V
/*      */         //   363: athrow
/*      */         //
/*      */         // Exception table:
/*      */         //   from	to	target	type
/*      */         //   143	157	160	java/lang/Exception
/*      */         //   81	219	222	java/lang/ClassNotFoundException
/*      */         //   81	225	245	finally
/*      */         //   0	326	327	java/lang/Exception
/*      */       }
/*      */     });
/*  903 */     localQueryResult.setResult(localList);
/*  904 */     SessionFactory localSessionFactory = getSessionFactory();
/*  905 */     PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/*  906 */       "SQL", paramString1, paramArrayOfObject, paramString2, null, 
/*  907 */       SessionFactoryUtils.getDataSource(localSessionFactory), localSessionFactory);
/*  908 */     localQueryResult.setPageContext(localPageContext);
/*  909 */     if (bool) {
/*  910 */       if ((m == 1) && ((localList == null) || (localList.size() < k)))
/*  911 */         localQueryResult.setRecordCount(localList == null ? 0 : localList.size());
/*      */       else {
/*  913 */         localQueryResult.setRecordCount(getRecordCount(paramString1, paramArrayOfObject));
/*      */       }
/*      */     }
/*  916 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   public int getRecordCount(String paramString, final Object[] paramArrayOfObject)
/*      */   {
/*  929 */     String str1 = paramString.toLowerCase();
/*  930 */     Dialect localDialect = ((SessionFactoryImpl)getSessionFactory())
/*  931 */       .getDialect();
/*  932 */     if ((localDialect instanceof SQLServerDialect)) {
/*  933 */       int i = str1.indexOf("order ");
/*  934 */       if (i > 0) {
/*  935 */         paramString = paramString.substring(0, i);
/*      */       }
/*      */     }
/*      */ 
/*  939 */     final String str2 = "select count(1) from (" + paramString + ") t";
/*      */ 
/*  941 */     int j = ((Number)getHibernateTemplate().execute(
/*  942 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/*  945 */           SQLQuery localSQLQuery = paramAnonymousSession
/*  946 */             .createSQLQuery(str2);
/*  947 */           if (paramArrayOfObject != null) {
/*  948 */             for (int i = 0; i < paramArrayOfObject.length; i++) {
/*  949 */               localSQLQuery = (SQLQuery)localSQLQuery.setParameter(i, 
/*  950 */                 paramArrayOfObject[i]);
/*      */             }
/*      */           }
/*  953 */           return localSQLQuery.uniqueResult();
/*      */         } catch (Exception localException) {
/*  955 */           Object localObject = localException;
/*  956 */           if (localException.getCause() != null) {
/*  957 */             localObject = localException.getCause();
/*      */           }
/*  959 */           throw new CoreException(
/*  960 */             "EAPTECH001100", (Throwable)localObject, 
/*  961 */             new String[] { ((Throwable)localObject).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     })).intValue();
/*  965 */     return j;
/*      */   }
/*      */ 
/*      */   public int update(String paramString)
/*      */   {
/*  976 */     return update(paramString, null);
/*      */   }
/*      */ 
/*      */   public int update(final String paramString, final Object[] paramArrayOfObject)
/*      */   {
/*  989 */     int i = ((Integer)getHibernateTemplate().execute(
/*  990 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/*  993 */           SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(paramString);
/*  994 */           if (paramArrayOfObject != null) {
/*  995 */             for (int i = 0; i < paramArrayOfObject.length; i++) {
/*  996 */               localSQLQuery = (SQLQuery)localSQLQuery.setParameter(i, 
/*  997 */                 paramArrayOfObject[i]);
/*      */             }
/*      */           }
/* 1000 */           return Integer.valueOf(localSQLQuery.executeUpdate());
/*      */         } catch (Exception localException) {
/* 1002 */           Object localObject = localException;
/* 1003 */           if (localException.getCause() != null) {
/* 1004 */             localObject = localException.getCause();
/*      */           }
/* 1006 */           throw new CoreException(
/* 1007 */             "EAPTECH001100", (Throwable)localObject, 
/* 1008 */             new String[] { ((Throwable)localObject).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     })).intValue();
/* 1012 */     return i;
/*      */   }
/*      */ 
/*      */   public void addOrUpdateObjects(List paramList)
/*      */   {
/* 1022 */     addOrUpdateObjects(paramList, 100);
/*      */   }
/*      */ 
/*      */   public void addOrUpdateObjects(List paramList, int paramInt)
/*      */   {
/* 1032 */     if ((paramList == null) || (paramList.size() == 0) || (paramInt == 0)) {
/* 1033 */       return;
/*      */     }
/* 1035 */     int i = paramList.size();
/* 1036 */     EntityEntry localEntityEntry = null;
/* 1037 */     for (int j = 0; j < i; j++) {
/* 1038 */       localEntityEntry = ((EventSource)getSession()).getPersistenceContext()
/* 1039 */         .getEntry(paramList.get(j));
/* 1040 */       if ((localEntityEntry != null) || (!ForeignKeys.isNotTransient(null, 
/* 1041 */         paramList.get(j), null, (SessionImplementor)getSession()))) {
/* 1042 */         SequenceUtil.saveSequenceInfo(getSession(), paramList.get(j));
/* 1043 */         saveAuditInfo(paramList.get(j));
/*      */       }
/* 1045 */       convertLocaleDateToGMT(paramList.get(j));
/* 1046 */       getHibernateTemplate().saveOrUpdate(paramList.get(j));
/* 1047 */       if (j % paramInt == 0)
/* 1048 */         getSession().flush();
/*      */     }
/*      */   }
/*      */ 
/*      */   public java.util.Date sysdate()
/*      */   {
/* 1060 */     java.util.Date localDate = (java.util.Date)getHibernateTemplate().execute(
/* 1061 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/* 1064 */           Object localObject1 = paramAnonymousSession.createSQLQuery("select sysdate from dual")
/* 1065 */             .uniqueResult();
/* 1066 */           return (java.util.Date)localObject1;
/*      */         } catch (Exception localException) {
/* 1068 */           Object localObject2 = localException;
/* 1069 */           if (localException.getCause() != null) {
/* 1070 */             localObject2 = localException.getCause();
/*      */           }
/* 1072 */           throw new CoreException(
/* 1073 */             "EAPTECH001100", (Throwable)localObject2, 
/* 1074 */             new String[] { ((Throwable)localObject2).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     });
/* 1078 */     return localDate;
/*      */   }
/*      */ 
/*      */   public Long sequence(String paramString)
/*      */   {
/*      */     final String str;
/* 1090 */     if (paramString.indexOf(":") > -1) {
/* 1091 */       localObject = paramString.split(":");
/* 1092 */       str = "select " + localObject[0] + 
/* 1093 */         ".nextval from dual connect by level <=" + localObject[1];
/*      */     } else {
/* 1095 */       str = "select " + paramString + ".nextval from dual";
/*      */     }
/* 1097 */     Object localObject = (BigDecimal)getHibernateTemplate().execute(
/* 1098 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/*      */         try {
/* 1101 */           Object localObject1 = paramAnonymousSession.createSQLQuery(str)
/* 1102 */             .uniqueResult();
/* 1103 */           return (BigDecimal)localObject1;
/*      */         } catch (Exception localException) {
/* 1105 */           Object localObject2 = localException;
/* 1106 */           if (localException.getCause() != null) {
/* 1107 */             localObject2 = localException.getCause();
/*      */           }
/* 1109 */           throw new CoreException(
/* 1110 */             "EAPTECH001100", (Throwable)localObject2, 
/* 1111 */             new String[] { ((Throwable)localObject2).getLocalizedMessage() });
/*      */         }
/*      */       }
/*      */     });
/* 1115 */     return Long.valueOf(((BigDecimal)localObject).longValue());
/*      */   }
/*      */ 
/*      */   public void callStoredProcedure(final String paramString, final ProcPara[] paramArrayOfProcPara)
/*      */   {
/* 1128 */     getHibernateTemplate().execute(new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/* 1130 */         Connection localConnection = null;
/* 1131 */         CallableStatement localCallableStatement = null;
/*      */         try {
/* 1133 */           String str = "{call " + paramString + "(";
/* 1134 */           for (int i = 0; i < paramArrayOfProcPara.length; i++) {
/* 1135 */             str = str + "?,";
/*      */           }
/* 1137 */           if (paramArrayOfProcPara.length > 0) {
/* 1138 */             str = str.substring(0, 
/* 1139 */               str.length() - 1);
/* 1140 */             str = str + ")}";
/*      */           } else {
/* 1142 */             str = str + ")}";
/*      */           }
/* 1144 */           localConnection = paramAnonymousSession.connection();
/* 1145 */           localCallableStatement = localConnection.prepareCall(str);
/* 1146 */           for (i = 0; i < paramArrayOfProcPara.length; i++) {
/* 1147 */             if ((paramArrayOfProcPara[i].isOutPara()) || (paramArrayOfProcPara[i].isInOutPara())) {
/* 1148 */               localCallableStatement.registerOutParameter(paramArrayOfProcPara[i]
/* 1149 */                 .getParaIndex(), paramArrayOfProcPara[i].getDBType());
/*      */             }
/* 1151 */             if ((paramArrayOfProcPara[i].isInPara()) || (paramArrayOfProcPara[i].isInOutPara())) {
/* 1152 */               if (paramArrayOfProcPara[i].getValue() == null)
/* 1153 */                 localCallableStatement.setNull(paramArrayOfProcPara[i].getParaIndex(), 
/* 1154 */                   paramArrayOfProcPara[i].getDBType());
/*      */               else {
/* 1156 */                 localCallableStatement.setObject(paramArrayOfProcPara[i].getParaIndex(), 
/* 1157 */                   paramArrayOfProcPara[i].getValue());
/*      */               }
/*      */             }
/*      */           }
/* 1161 */           localCallableStatement.execute();
/* 1162 */           for (i = 0; i < paramArrayOfProcPara.length; i++) {
/* 1163 */             if ((paramArrayOfProcPara[i].isOutPara()) || (paramArrayOfProcPara[i].isInOutPara())) {
/* 1164 */               paramArrayOfProcPara[i].setValue(localCallableStatement.getObject(paramArrayOfProcPara[i]
/* 1165 */                 .getParaIndex()));
/*      */             }
/*      */           }
/* 1168 */           return null;
/*      */         } catch (Exception localException) {
/* 1170 */           Object localObject1 = localException;
/* 1171 */           if (localException.getCause() != null) {
/* 1172 */             localObject1 = localException.getCause();
/*      */           }
/* 1174 */           throw new CoreException("EAPTECH001100", (Throwable)localObject1, 
/* 1175 */             new String[] { ((Throwable)localObject1).getLocalizedMessage() });
/*      */         } finally {
/* 1177 */           if (localCallableStatement != null)
/*      */             try {
/* 1179 */               localCallableStatement.close();
/*      */             } catch (SQLException localSQLException2) {
/* 1181 */               localSQLException2.printStackTrace();
/*      */             }
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public List queryBySqlMapping(String paramString, Object[] paramArrayOfObject, int paramInt1, int paramInt2)
/*      */   {
/* 1198 */     SqlMapping localSqlMapping = SqlMappingContext.getSqlMappingContext()
/* 1199 */       .getSqlMappingByName(paramString);
/* 1200 */     return queryBySqlMapping(paramArrayOfObject, localSqlMapping, localSqlMapping.getSql(), 
/* 1201 */       paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public List queryBySqlMapping(String paramString1, String paramString2, Object[] paramArrayOfObject, int paramInt1, int paramInt2)
/*      */   {
/* 1214 */     return queryBySqlMapping(paramArrayOfObject, SqlMappingContext.getSqlMappingContext()
/* 1215 */       .getSqlMappingByName(paramString1), paramString2, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */   public QueryResult queryBySqlMapping(String paramString1, String paramString2, Object[] paramArrayOfObject)
/*      */   {
/* 1227 */     return queryBySqlMapping(paramArrayOfObject, SqlMappingContext.getSqlMappingContext()
/* 1228 */       .getSqlMappingByName(paramString1), paramString2);
/*      */   }
/*      */ 
/*      */   public QueryResult queryBySqlMapping(String paramString, Object[] paramArrayOfObject)
/*      */   {
/* 1239 */     SqlMapping localSqlMapping = SqlMappingContext.getSqlMappingContext()
/* 1240 */       .getSqlMappingByName(paramString);
/* 1241 */     QueryResult localQueryResult = queryBySqlMapping(paramArrayOfObject, localSqlMapping, localSqlMapping
/* 1242 */       .getSql());
/* 1243 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   private QueryResult queryBySqlMapping(Object[] paramArrayOfObject, SqlMapping paramSqlMapping, String paramString)
/*      */   {
/* 1248 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/* 1249 */     boolean bool = false;
/* 1250 */     int i = CoreVariability.getMaxPageSize();
/* 1251 */     int j = 1;
/* 1252 */     if (localQueryResult != null) {
/* 1253 */       if (localQueryResult.getPageSize() != -1) {
/* 1254 */         i = localQueryResult.getPageSize();
/*      */       }
/* 1256 */       j = localQueryResult.getPageNumber();
/* 1257 */       bool = localQueryResult.isAutoCalcCount();
/*      */     }
/* 1259 */     localQueryResult = new QueryResult();
/* 1260 */     localQueryResult.setPageNumber(j);
/* 1261 */     localQueryResult.setPageSize(i);
/* 1262 */     int k = i;
/* 1263 */     int m = j;
/* 1264 */     if (paramSqlMapping != null) {
/* 1265 */       List localList = queryBySqlMapping(paramArrayOfObject, paramSqlMapping, paramString, k, 
/* 1266 */         m);
/* 1267 */       localQueryResult.setResult(localList);
/* 1268 */       SessionFactory localSessionFactory = getSessionFactory();
/* 1269 */       PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/* 1270 */         "SDMQ", paramString, paramArrayOfObject, paramSqlMapping.getName(), null, 
/* 1271 */         SessionFactoryUtils.getDataSource(localSessionFactory), 
/* 1272 */         localSessionFactory);
/* 1273 */       localQueryResult.setPageContext(localPageContext);
/* 1274 */       if (bool) {
/* 1275 */         if ((m == 1) && (
/* 1276 */           (localList == null) || (localList.size() < k)))
/* 1277 */           localQueryResult.setRecordCount(localList == null ? 0 : localList.size());
/*      */         else {
/* 1279 */           localQueryResult.setRecordCount(getRecordCount(paramString, paramArrayOfObject));
/*      */         }
/*      */       }
/*      */     }
/* 1283 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   private List queryBySqlMapping(final Object[] paramArrayOfObject, SqlMapping paramSqlMapping, final String paramString, final int paramInt1, final int paramInt2)
/*      */   {
/* 1289 */     final Map localMap = paramSqlMapping.getMappingMap();
/* 1290 */     final String str = paramSqlMapping.getClazz();
/* 1291 */     List localList = (List)getHibernateTemplate().execute(
/* 1292 */       new HibernateCallback() {
/*      */       public Object doInHibernate(Session paramAnonymousSession) {
/* 1294 */         SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(paramString);
/* 1295 */         if (paramArrayOfObject != null) {
/* 1296 */           int i = 0; for (int j = paramArrayOfObject.length; i < j; i++) {
/* 1297 */             localSQLQuery = (SQLQuery)localSQLQuery.setParameter(i, 
/* 1298 */               paramArrayOfObject[i]);
/*      */           }
/*      */         }
/* 1301 */         Iterator localIterator = localMap.entrySet().iterator();
/* 1302 */         while (localIterator.hasNext()) {
/* 1303 */           Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 1304 */           String str = (String)localEntry.getKey();
/* 1305 */           Property localProperty = (Property)localEntry.getValue();
/* 1306 */           localSQLQuery.addScalar(str, TypeFactory.basic(localProperty
/* 1307 */             .getType()));
/*      */         }
/*      */         try {
/* 1310 */           localSQLQuery
/* 1311 */             .setResultTransformer(new AliasToDtoResultTransformer(
/* 1312 */             Class.forName(str), localMap));
/*      */         } catch (ClassNotFoundException localClassNotFoundException) {
/* 1314 */           localClassNotFoundException.printStackTrace();
/*      */         }
/* 1316 */         if (paramInt1 > 0) {
/* 1317 */           localSQLQuery.setMaxResults(paramInt1);
/* 1318 */           localSQLQuery
/* 1319 */             .setFirstResult((paramInt2 - 1) * paramInt1);
/*      */         }
/* 1321 */         return localSQLQuery.list();
/*      */       }
/*      */     });
/* 1324 */     return localList;
/*      */   }
/*      */ 
/*      */   public QueryResult queryByStatement(String paramString, Map paramMap)
/*      */   {
/* 1338 */     int i = paramString.indexOf(".");
/* 1339 */     String str1 = paramString.substring(0, i);
/* 1340 */     paramString = paramString.substring(i + 1);
/* 1341 */     if (paramString.contains(".")) {
/* 1342 */       paramString = paramString.replace(".", File.separator);
/*      */     }
/* 1344 */     String str2 = "";
/* 1345 */     DevelopmentComponent localDevelopmentComponent = DCRepository.getDevelopmentComponent(str1);
/* 1346 */     if (localDevelopmentComponent == null)
/*      */     {
/* 1348 */       str2 = str1 + File.separator + "statement" + 
/* 1349 */         File.separator + paramString + ".xml";
/*      */     }
/*      */     else {
/* 1352 */       str2 = localDevelopmentComponent.getSoftwareComponent().getId() + File.separator + 
/* 1353 */         str1 + File.separator + "statement" + File.separator + 
/* 1354 */         paramString + ".xml";
/*      */     }
/* 1356 */     StatementImpl localStatementImpl = new StatementImpl(str2, paramMap);
/* 1357 */     final String str3 = localStatementImpl.getStatement();
/* 1358 */     final String str4 = localStatementImpl.getPojo();
/*      */ 
/* 1361 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/* 1362 */     int j = CoreVariability.getMaxPageSize();
/* 1363 */     int k = 1;
/*      */ 
/* 1365 */     if (localStatementImpl.getPageSize() > 0) {
/* 1366 */       j = localStatementImpl.getPageSize();
/*      */     }
/* 1368 */     if (localQueryResult != null) {
/* 1369 */       if (localQueryResult.getPageSize() != -1) {
/* 1370 */         j = localQueryResult.getPageSize();
/*      */       }
/* 1372 */       k = localQueryResult.getPageNumber();
/*      */     }
/* 1374 */     localQueryResult = new QueryResult();
/* 1375 */     localQueryResult.setPageNumber(k);
/* 1376 */     localQueryResult.setPageSize(j);
/* 1377 */     final int m = j;
/* 1378 */     final int n = k;
/*      */ 
/* 1380 */     List localList = (List)getHibernateTemplate().execute(
/* 1381 */       new HibernateCallback()
/*      */     {
/*      */       public Object doInHibernate(Session paramAnonymousSession)
/*      */       {
/*      */         // Byte code:
/*      */         //   0: iconst_0
/*      */         //   1: istore_2
/*      */         //   2: aload_1
/*      */         //   3: aload_0
/*      */         //   4: getfield 20	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$sql	Ljava/lang/String;
/*      */         //   7: invokeinterface 34 2 0
/*      */         //   12: astore_3
/*      */         //   13: aload_0
/*      */         //   14: getfield 22	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pojo	Ljava/lang/String;
/*      */         //   17: ifnonnull +19 -> 36
/*      */         //   20: aload_3
/*      */         //   21: getstatic 40	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   24: invokeinterface 46 2 0
/*      */         //   29: checkcast 47	org/hibernate/SQLQuery
/*      */         //   32: astore_3
/*      */         //   33: goto +206 -> 239
/*      */         //   36: aload_1
/*      */         //   37: invokeinterface 52 1 0
/*      */         //   42: invokeinterface 56 1 0
/*      */         //   47: aload_0
/*      */         //   48: getfield 22	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pojo	Ljava/lang/String;
/*      */         //   51: invokeinterface 62 2 0
/*      */         //   56: ifeq +20 -> 76
/*      */         //   59: aload_3
/*      */         //   60: aload_0
/*      */         //   61: getfield 22	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pojo	Ljava/lang/String;
/*      */         //   64: invokestatic 68	org/hibernate/util/ReflectHelper:classForName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */         //   67: invokeinterface 74 2 0
/*      */         //   72: astore_3
/*      */         //   73: goto +149 -> 222
/*      */         //   76: aload_0
/*      */         //   77: getfield 22	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pojo	Ljava/lang/String;
/*      */         //   80: invokestatic 68	org/hibernate/util/ReflectHelper:classForName	(Ljava/lang/String;)Ljava/lang/Class;
/*      */         //   83: astore 4
/*      */         //   85: aload 4
/*      */         //   87: invokevirtual 78	java/lang/Class:getDeclaredFields	()[Ljava/lang/reflect/Field;
/*      */         //   90: astore 5
/*      */         //   92: iconst_0
/*      */         //   93: istore 6
/*      */         //   95: goto +56 -> 151
/*      */         //   98: aload 4
/*      */         //   100: aload 5
/*      */         //   102: iload 6
/*      */         //   104: aaload
/*      */         //   105: invokevirtual 84	java/lang/reflect/Field:getName	()Ljava/lang/String;
/*      */         //   108: invokestatic 90	org/hibernate/util/ReflectHelper:getGetter	(Ljava/lang/Class;Ljava/lang/String;)Lorg/hibernate/property/Getter;
/*      */         //   111: pop
/*      */         //   112: goto +7 -> 119
/*      */         //   115: pop
/*      */         //   116: goto +32 -> 148
/*      */         //   119: aload_3
/*      */         //   120: aload 5
/*      */         //   122: iload 6
/*      */         //   124: aaload
/*      */         //   125: invokevirtual 84	java/lang/reflect/Field:getName	()Ljava/lang/String;
/*      */         //   128: aload 5
/*      */         //   130: iload 6
/*      */         //   132: aaload
/*      */         //   133: invokevirtual 94	java/lang/reflect/Field:getType	()Ljava/lang/Class;
/*      */         //   136: invokevirtual 98	java/lang/Class:getName	()Ljava/lang/String;
/*      */         //   139: invokestatic 99	org/hibernate/type/TypeFactory:basic	(Ljava/lang/String;)Lorg/hibernate/type/Type;
/*      */         //   142: invokeinterface 105 3 0
/*      */         //   147: pop
/*      */         //   148: iinc 6 1
/*      */         //   151: iload 6
/*      */         //   153: aload 5
/*      */         //   155: arraylength
/*      */         //   156: if_icmplt -58 -> 98
/*      */         //   159: aload_3
/*      */         //   160: aload 4
/*      */         //   162: invokestatic 109	org/hibernate/transform/Transformers:aliasToBean	(Ljava/lang/Class;)Lorg/hibernate/transform/ResultTransformer;
/*      */         //   165: invokeinterface 46 2 0
/*      */         //   170: checkcast 47	org/hibernate/SQLQuery
/*      */         //   173: astore_3
/*      */         //   174: goto +48 -> 222
/*      */         //   177: pop
/*      */         //   178: iconst_1
/*      */         //   179: istore_2
/*      */         //   180: iload_2
/*      */         //   181: ifeq +58 -> 239
/*      */         //   184: aload_3
/*      */         //   185: getstatic 40	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   188: invokeinterface 46 2 0
/*      */         //   193: checkcast 47	org/hibernate/SQLQuery
/*      */         //   196: astore_3
/*      */         //   197: goto +42 -> 239
/*      */         //   200: astore 7
/*      */         //   202: iload_2
/*      */         //   203: ifeq +16 -> 219
/*      */         //   206: aload_3
/*      */         //   207: getstatic 40	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   210: invokeinterface 46 2 0
/*      */         //   215: checkcast 47	org/hibernate/SQLQuery
/*      */         //   218: astore_3
/*      */         //   219: aload 7
/*      */         //   221: athrow
/*      */         //   222: iload_2
/*      */         //   223: ifeq +16 -> 239
/*      */         //   226: aload_3
/*      */         //   227: getstatic 40	org/hibernate/transform/Transformers:ALIAS_TO_ENTITY_MAP	Lorg/hibernate/transform/ResultTransformer;
/*      */         //   230: invokeinterface 46 2 0
/*      */         //   235: checkcast 47	org/hibernate/SQLQuery
/*      */         //   238: astore_3
/*      */         //   239: aload_0
/*      */         //   240: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pageSize	I
/*      */         //   243: ifle +32 -> 275
/*      */         //   246: aload_3
/*      */         //   247: aload_0
/*      */         //   248: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pageSize	I
/*      */         //   251: invokeinterface 113 2 0
/*      */         //   256: pop
/*      */         //   257: aload_3
/*      */         //   258: aload_0
/*      */         //   259: getfield 26	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pageNumber	I
/*      */         //   262: iconst_1
/*      */         //   263: isub
/*      */         //   264: aload_0
/*      */         //   265: getfield 24	com/neusoft/unieap/core/base/dao/BaseHibernateDAO$12:val$pageSize	I
/*      */         //   268: imul
/*      */         //   269: invokeinterface 117 2 0
/*      */         //   274: pop
/*      */         //   275: aload_3
/*      */         //   276: invokeinterface 120 1 0
/*      */         //   281: areturn
/*      */         //   282: astore_2
/*      */         //   283: aload_2
/*      */         //   284: astore_3
/*      */         //   285: aload_2
/*      */         //   286: invokevirtual 124	java/lang/Exception:getCause	()Ljava/lang/Throwable;
/*      */         //   289: ifnull +8 -> 297
/*      */         //   292: aload_2
/*      */         //   293: invokevirtual 124	java/lang/Exception:getCause	()Ljava/lang/Throwable;
/*      */         //   296: astore_3
/*      */         //   297: new 130	com/neusoft/unieap/core/base/exception/CoreException
/*      */         //   300: dup
/*      */         //   301: ldc 132
/*      */         //   303: aload_3
/*      */         //   304: iconst_1
/*      */         //   305: anewarray 134	java/lang/String
/*      */         //   308: dup
/*      */         //   309: iconst_0
/*      */         //   310: aload_3
/*      */         //   311: invokevirtual 136	java/lang/Throwable:getLocalizedMessage	()Ljava/lang/String;
/*      */         //   314: aastore
/*      */         //   315: invokespecial 141	com/neusoft/unieap/core/base/exception/CoreException:<init>	(Ljava/lang/String;Ljava/lang/Throwable;[Ljava/lang/String;)V
/*      */         //   318: athrow
/*      */         //
/*      */         // Exception table:
/*      */         //   from	to	target	type
/*      */         //   98	112	115	java/lang/Exception
/*      */         //   36	174	177	java/lang/ClassNotFoundException
/*      */         //   36	180	200	finally
/*      */         //   0	281	282	java/lang/Exception
/*      */       }
/*      */     });
/* 1448 */     localQueryResult.setResult(localList);
/* 1449 */     SessionFactory localSessionFactory = getSessionFactory();
/* 1450 */     PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/* 1451 */       "Statement", str3, null, str4, localStatementImpl.getDataSourceID(), 
/* 1452 */       SessionFactoryUtils.getDataSource(localSessionFactory), 
/* 1453 */       localSessionFactory);
/* 1454 */     localQueryResult.setPageContext(localPageContext);
/* 1455 */     if ((n == 1) && ((localList == null) || (localList.size() < m))) {
/* 1456 */       localQueryResult.setRecordCount(localList == null ? 0 : localList.size());
/*      */     } else {
/* 1458 */       int i1 = getRecordCount(str3, null);
/* 1459 */       localQueryResult.setRecordCount(i1);
/*      */     }
/* 1461 */     return localQueryResult;
/*      */   }
/*      */ 
/*      */   public QueryResult queryObjectByMultiLanguage(String paramString1, Object[] paramArrayOfObject, String paramString2)
/*      */     throws CoreException
/*      */   {
/* 1478 */     boolean bool = false;
/* 1479 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/* 1480 */     int i = CoreVariability.getMaxPageSize();
/* 1481 */     int j = 1;
/* 1482 */     if (localQueryResult != null) {
/* 1483 */       i = localQueryResult.getPageSize();
/* 1484 */       j = localQueryResult.getPageNumber();
/* 1485 */       bool = localQueryResult.isAutoCalcCount();
/*      */     }
/* 1487 */     localQueryResult = new QueryResult();
/* 1488 */     localQueryResult.setPageNumber(j);
/* 1489 */     localQueryResult.setPageSize(i);
/* 1490 */     int k = i;
/* 1491 */     int m = j;
/* 1492 */     if (paramString2 == null) {
/* 1493 */       paramString2 = "t";
/*      */     }
/* 1495 */     if (paramArrayOfObject == null) {
/* 1496 */       paramArrayOfObject = new Object[0];
/*      */     }
/* 1498 */     if (paramArrayOfObject.length == 0)
/* 1499 */       paramString1 = paramString1 + " where " + paramString2 + ".language = ?";
/*      */     else {
/* 1501 */       paramString1 = paramString1 + " and " + paramString2 + ".language = ?";
/*      */     }
/* 1503 */     Object[] arrayOfObject = new Object[paramArrayOfObject.length + 1];
/* 1504 */     for (int n = 0; n < paramArrayOfObject.length; n++) {
/* 1505 */       arrayOfObject[n] = paramArrayOfObject[n];
/*      */     }
/* 1507 */     arrayOfObject[paramArrayOfObject.length] = GlobalService.getUserI18nContext()
/* 1508 */       .getLocale().toString();
/*      */ 
/* 1510 */     List localList = queryObjects(paramString1, arrayOfObject, m, k);
/* 1511 */     localQueryResult.setResult(localList);
/* 1512 */     if (bool) {
/* 1513 */       if ((m == 1) && ((localList == null) || (localList.size() < k))) {
/* 1514 */         localQueryResult.setRecordCount(localList == null ? 0 : localList.size());
/*      */       } else {
/* 1516 */         int i1 = getTotalCount(paramString1, arrayOfObject);
/* 1517 */         localQueryResult.setRecordCount(i1);
/*      */       }
/*      */     }
/* 1520 */     SessionFactory localSessionFactory = getSessionFactory();
/* 1521 */     PageContext localPageContext = PageUtil.initPageContext(getClass(), 
/* 1522 */       "HQL", paramString1, arrayOfObject, null, null, 
/* 1523 */       SessionFactoryUtils.getDataSource(localSessionFactory), localSessionFactory);
/* 1524 */     localQueryResult.setPageContext(localPageContext);
/* 1525 */     return localQueryResult;
/*      */   }
/*      */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.dao.BaseHibernateDAO
 * JD-Core Version:    0.6.2
 */