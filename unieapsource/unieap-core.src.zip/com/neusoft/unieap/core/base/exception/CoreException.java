/*    */ package com.neusoft.unieap.core.base.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class CoreException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 0L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */ 
/*    */   public CoreException(String paramString, String[] paramArrayOfString)
/*    */   {
/* 18 */     super(paramString, paramArrayOfString);
/*    */   }
/*    */ 
/*    */   public CoreException(String paramString, Throwable paramThrowable, String[] paramArrayOfString)
/*    */   {
/* 28 */     super(paramString, paramThrowable, paramArrayOfString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.exception.CoreException
 * JD-Core Version:    0.6.2
 */