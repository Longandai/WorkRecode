package com.neusoft.unieap.core.base.exception;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class CoreExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "001";
  private static final String _P = "EAPTECH001";
  public static final String ARGUMENT_CONVERT_EXP = "EAPTECH001001";
  public static final String DB_ACESS_EXP = "EAPTECH001100";
  public static final String DATE_CONVERT_EXP = "EAPTECH001101";
  public static final String INPUT_CONDITIONVALUE_EXP = "EAPTECH001110";
  public static final String DC_REGISTER_ERROR = "EAPTECH001111";
  public static final String EXPORT_SCRIPT_DATA = "EAPTECH001112";
  public static final String IMPORT_SCRIPT_DATA = "EAPTECH001113";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.exception.CoreExceptionCode
 * JD-Core Version:    0.6.2
 */