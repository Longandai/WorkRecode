package com.neusoft.unieap.core.base.bo;

import java.util.List;
import java.util.Map;

public abstract interface BaseBO
{
  public abstract List queryPOJOList(String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3, int paramInt1, int paramInt2);

  public abstract Object[] queryPOJOListCount(String paramString1, String paramString2, Object[] paramArrayOfObject, Map paramMap);

  public abstract List addPOJOList(List paramList);

  public abstract void updatePOJOList(List paramList);

  public abstract void removePOJOList(List paramList);

  public abstract List save(List paramList1, List paramList2, List paramList3);

  public abstract List[] save(List[] paramArrayOfList1, List[] paramArrayOfList2, List[] paramArrayOfList3);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.bo.BaseBO
 * JD-Core Version:    0.6.2
 */