/*     */ package com.neusoft.unieap.core.base.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.bo.BaseBO;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.support.TransactionCallback;
/*     */ import org.springframework.transaction.support.TransactionTemplate;
/*     */ 
/*     */ public class BaseBOImpl
/*     */   implements BaseBO
/*     */ {
/*     */   private BaseHibernateDAO dao;
/*     */   private TransactionTemplate transactionTemplate;
/*     */ 
/*     */   public void setDao(BaseHibernateDAO paramBaseHibernateDAO)
/*     */   {
/*  25 */     this.dao = paramBaseHibernateDAO;
/*     */   }
/*     */ 
/*     */   public void setTransactionTemplate(TransactionTemplate paramTransactionTemplate) {
/*  29 */     this.transactionTemplate = paramTransactionTemplate;
/*     */   }
/*     */ 
/*     */   public List queryPOJOList(String paramString1, String paramString2, Object[] paramArrayOfObject, String paramString3, int paramInt1, int paramInt2)
/*     */   {
/*  35 */     StringBuffer localStringBuffer = new StringBuffer();
/*  36 */     localStringBuffer.append(" from " + paramString1);
/*  37 */     if ((paramString2 != null) && (!"".equals(paramString2.trim()))) {
/*  38 */       localStringBuffer.append(" where ").append(paramString2);
/*     */     }
/*  40 */     if ((paramString3 != null) && (!"".equals(paramString3.trim()))) {
/*  41 */       localStringBuffer.append(" order by " + paramString3);
/*     */     }
/*     */ 
/*  44 */     return this.dao.queryObjects(localStringBuffer.toString(), paramArrayOfObject, paramInt1, 
/*  45 */       paramInt2);
/*     */   }
/*     */ 
/*     */   public Object[] queryPOJOListCount(String paramString1, String paramString2, Object[] paramArrayOfObject, Map paramMap)
/*     */   {
/*  51 */     StringBuffer localStringBuffer = new StringBuffer("select count(*) as recordCount ");
/*  52 */     if (paramMap != null)
/*     */     {
/*     */       Iterator localIterator;
/*  53 */       for (localObject = paramMap.entrySet().iterator(); ((Iterator)localObject)
/*  54 */         .hasNext(); 
/*  58 */         localIterator.hasNext())
/*     */       {
/*  55 */         Map.Entry localEntry = (Map.Entry)((Iterator)localObject).next();
/*  56 */         String str1 = (String)localEntry.getKey();
/*  57 */         Set localSet = (Set)localEntry.getValue();
/*  58 */         localIterator = localSet.iterator(); continue;
/*  59 */         String str2 = (String)localIterator.next();
/*  60 */         localStringBuffer.append(",").append(str2).append("(").append(
/*  61 */           str1).append(") ").append(" as ").append(
/*  62 */           str1).append("_").append(str2);
/*     */       }
/*     */     }
/*     */ 
/*  66 */     localStringBuffer.append(" from ").append(paramString1);
/*  67 */     if ((paramString2 != null) && (!"".equals(paramString2.trim()))) {
/*  68 */       localStringBuffer.append(" where ").append(paramString2);
/*     */     }
/*  70 */     Object localObject = this.dao.queryObject(localStringBuffer.toString(), paramArrayOfObject);
/*  71 */     return 
/*  72 */       new Object[] { (localObject instanceof Object[]) ? (Object[])localObject : 
/*  72 */       localObject };
/*     */   }
/*     */ 
/*     */   public List addPOJOList(List paramList) {
/*  76 */     ArrayList localArrayList = new ArrayList();
/*  77 */     int i = 0; for (int j = paramList.size(); i < j; i++) {
/*  78 */       localArrayList.add(this.dao.addObject(paramList.get(i)));
/*     */     }
/*  80 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void updatePOJOList(List paramList) {
/*  84 */     int i = 0; for (int j = paramList.size(); i < j; i++)
/*  85 */       this.dao.updateObject(paramList.get(i));
/*     */   }
/*     */ 
/*     */   public void removePOJOList(List paramList)
/*     */   {
/*  90 */     int i = 0; for (int j = paramList.size(); i < j; i++)
/*  91 */       this.dao.removeObject(paramList.get(i));
/*     */   }
/*     */ 
/*     */   public List save(final List paramList1, final List paramList2, final List paramList3)
/*     */   {
/*  97 */     this.transactionTemplate
/*  98 */       .setPropagationBehavior(3);
/*  99 */     return (List)this.transactionTemplate.execute(new TransactionCallback() {
/*     */       public Object doInTransaction(TransactionStatus paramAnonymousTransactionStatus) {
/* 101 */         BaseBOImpl.this.updatePOJOList(paramList2);
/* 102 */         BaseBOImpl.this.removePOJOList(paramList3);
/* 103 */         return BaseBOImpl.this.addPOJOList(paramList1);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public List[] save(final List[] paramArrayOfList1, final List[] paramArrayOfList2, final List[] paramArrayOfList3)
/*     */   {
/* 110 */     this.transactionTemplate
/* 111 */       .setPropagationBehavior(3);
/* 112 */     return (List[])this.transactionTemplate.execute(new TransactionCallback()
/*     */     {
/*     */       public Object doInTransaction(TransactionStatus paramAnonymousTransactionStatus) {
/* 115 */         for (int i = 0; i < paramArrayOfList2.length; i++) {
/* 116 */           BaseBOImpl.this.updatePOJOList(paramArrayOfList2[i]);
/*     */         }
/*     */ 
/* 119 */         for (i = 0; i < paramArrayOfList3.length; i++) {
/* 120 */           BaseBOImpl.this.removePOJOList(paramArrayOfList3[i]);
/*     */         }
/*     */ 
/* 123 */         List[] arrayOfList = new List[paramArrayOfList1.length];
/* 124 */         for (int j = 0; j < paramArrayOfList1.length; j++) {
/* 125 */           arrayOfList[j] = BaseBOImpl.this.addPOJOList(paramArrayOfList1[j]);
/*     */         }
/* 127 */         return arrayOfList;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.bo.impl.BaseBOImpl
 * JD-Core Version:    0.6.2
 */