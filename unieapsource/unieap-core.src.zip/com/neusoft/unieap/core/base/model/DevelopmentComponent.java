package com.neusoft.unieap.core.base.model;

public abstract interface DevelopmentComponent extends Component
{
  public abstract SoftwareComponent getSoftwareComponent();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.DevelopmentComponent
 * JD-Core Version:    0.6.2
 */