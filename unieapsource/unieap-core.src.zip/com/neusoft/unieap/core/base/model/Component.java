package com.neusoft.unieap.core.base.model;

public abstract interface Component
{
  public abstract String getId();

  public abstract String getTitle();

  public abstract boolean isEnabled();

  public abstract String getVersion();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.Component
 * JD-Core Version:    0.6.2
 */