/*     */ package com.neusoft.unieap.core.base.model;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.exception.CoreException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class PatchRepository
/*     */ {
/*     */   private static final String DEFAULT_DIR = "bootstrap";
/*     */   private static final String DIVIDE_DOT = ".";
/*  19 */   private static final Map allPatchComponents = new HashMap();
/*     */ 
/*  21 */   private static final Map criterionPatchComponents = new HashMap();
/*     */ 
/*     */   public List getAllPatchComponents()
/*     */   {
/*  29 */     ArrayList localArrayList = new ArrayList();
/*  30 */     localArrayList.addAll(allPatchComponents.values());
/*  31 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static List getAvailablePatchComponent()
/*     */   {
/*  40 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  42 */     for (Iterator localIterator = allPatchComponents.values().iterator(); localIterator
/*  43 */       .hasNext(); )
/*     */     {
/*     */       PatchComponent localPatchComponent;
/*  44 */       if ((localPatchComponent = (PatchComponent)localIterator.next()).isEnabled()) {
/*  45 */         localArrayList.add(localPatchComponent);
/*     */       }
/*     */     }
/*  48 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static PatchComponent getPatchComponent(String paramString)
/*     */   {
/*  59 */     return (PatchComponent)allPatchComponents.get(paramString);
/*     */   }
/*     */ 
/*     */   public static void put(String paramString, PatchComponent paramPatchComponent)
/*     */   {
/*  77 */     allPatchComponents.put(paramString, paramPatchComponent);
/*     */   }
/*     */ 
/*     */   public static void remove(String paramString)
/*     */   {
/*  87 */     allPatchComponents.remove(paramString);
/*     */   }
/*     */ 
/*     */   public static PatchComponent getPatchComponent(Class paramClass)
/*     */   {
/* 101 */     PatchComponent localPatchComponent = null;
/* 102 */     if (paramClass != null) {
/* 103 */       String str1 = paramClass.getName();
/* 104 */       Set localSet = allPatchComponents.entrySet();
/* 105 */       Iterator localIterator = localSet.iterator();
/* 106 */       while (localIterator.hasNext()) {
/* 107 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 108 */         String str2 = (String)localEntry.getKey();
/* 109 */         if (str1.indexOf(str2) >= 0) {
/* 110 */           localPatchComponent = (PatchComponent)localEntry.getValue();
/* 111 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 115 */     return localPatchComponent;
/*     */   }
/*     */ 
/*     */   public static void addCriterionPatch(String paramString, PatchComponent paramPatchComponent)
/*     */   {
/* 128 */     validatePatchRootPackage(paramString);
/* 129 */     criterionPatchComponents.put(paramString, paramPatchComponent);
/*     */   }
/*     */ 
/*     */   private static void validatePatchRootPackage(String paramString) {
/* 133 */     Set localSet = criterionPatchComponents.keySet();
/* 134 */     Iterator localIterator = localSet.iterator();
/* 135 */     while (localIterator.hasNext()) {
/* 136 */       String str = (String)localIterator.next();
/* 137 */       if (paramString.length() < str.length()) {
/* 138 */         if (str.indexOf(paramString) > -1)
/* 139 */           throw new CoreException(
/* 140 */             "EAPTECH001111", 
/* 141 */             new String[] { paramString });
/*     */       }
/* 143 */       else if (paramString.indexOf(str) > -1)
/* 144 */         throw new CoreException(
/* 145 */           "EAPTECH001111", 
/* 146 */           new String[] { paramString });
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void removeCriterionPatch(String paramString)
/*     */   {
/* 158 */     criterionPatchComponents.remove(paramString);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.PatchRepository
 * JD-Core Version:    0.6.2
 */