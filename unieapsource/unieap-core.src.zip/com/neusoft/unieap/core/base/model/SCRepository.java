/*    */ package com.neusoft.unieap.core.base.model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class SCRepository
/*    */ {
/* 15 */   private static final transient Map softwareComponents = new HashMap();
/*    */ 
/*    */   public static SoftwareComponent getSoftwareComponent(String paramString)
/*    */   {
/* 22 */     return (SoftwareComponent)softwareComponents.get(paramString);
/*    */   }
/*    */ 
/*    */   public static List getSoftwareComponents()
/*    */   {
/* 29 */     ArrayList localArrayList = new ArrayList();
/* 30 */     localArrayList.addAll(softwareComponents.values());
/* 31 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public static List getAvailableSoftwareComponents()
/*    */   {
/* 38 */     ArrayList localArrayList = new ArrayList();
/*    */ 
/* 40 */     for (Iterator localIterator = softwareComponents.values().iterator(); 
/* 41 */       localIterator.hasNext(); )
/*    */     {
/*    */       SoftwareComponent localSoftwareComponent;
/* 42 */       if ((localSoftwareComponent = (SoftwareComponent)localIterator.next()).isEnabled()) {
/* 43 */         localArrayList.add(localSoftwareComponent);
/*    */       }
/*    */     }
/* 46 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public static List getApplications()
/*    */   {
/* 53 */     ArrayList localArrayList = new ArrayList();
/*    */ 
/* 55 */     for (Iterator localIterator = softwareComponents.values().iterator(); 
/* 56 */       localIterator.hasNext(); )
/*    */     {
/* 57 */       SCActivator localSCActivator = (SCActivator)localIterator.next();
/* 58 */       if (localSCActivator.isApp()) {
/* 59 */         localArrayList.add(localSCActivator.getApplication());
/*    */       }
/*    */     }
/* 62 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public static List getAvailableApplications()
/*    */   {
/* 69 */     ArrayList localArrayList = new ArrayList();
/*    */ 
/* 71 */     for (Iterator localIterator = softwareComponents.values().iterator(); 
/* 72 */       localIterator.hasNext(); )
/*    */     {
/* 73 */       SCActivator localSCActivator = (SCActivator)localIterator.next();
/* 74 */       if ((localSCActivator.isEnabled()) && (localSCActivator.isApp())) {
/* 75 */         localArrayList.add(localSCActivator.getApplication());
/*    */       }
/*    */     }
/* 78 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   static void addSoftwareComponent(SoftwareComponent paramSoftwareComponent)
/*    */   {
/* 85 */     String str = paramSoftwareComponent.getId();
/* 86 */     softwareComponents.put(str, paramSoftwareComponent);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.SCRepository
 * JD-Core Version:    0.6.2
 */