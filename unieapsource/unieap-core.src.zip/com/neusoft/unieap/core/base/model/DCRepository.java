/*     */ package com.neusoft.unieap.core.base.model;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.exception.CoreException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class DCRepository
/*     */ {
/*     */   private static final String DEFAULT_DIR = "bootstrap";
/*     */   private static final String DIVIDE_DOT = ".";
/*  25 */   private static final Map allDevelopmentComponents = new HashMap();
/*     */ 
/*  27 */   private static final Map criterionDevelopmentComponents = new HashMap();
/*     */ 
/*     */   public List getAllDevelopmentComponents()
/*     */   {
/*  35 */     ArrayList localArrayList = new ArrayList();
/*  36 */     localArrayList.addAll(allDevelopmentComponents.values());
/*  37 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static List getAvailableDevelopmentComponent()
/*     */   {
/*  46 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/*  48 */     for (Iterator localIterator = allDevelopmentComponents.values().iterator(); localIterator
/*  49 */       .hasNext(); )
/*     */     {
/*     */       DevelopmentComponent localDevelopmentComponent;
/*  50 */       if ((localDevelopmentComponent = (DevelopmentComponent)localIterator.next()).isEnabled()) {
/*  51 */         localArrayList.add(localDevelopmentComponent);
/*     */       }
/*     */     }
/*  54 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public static DevelopmentComponent getDevelopmentComponent(String paramString)
/*     */   {
/*  65 */     return (DevelopmentComponent)allDevelopmentComponents.get(paramString);
/*     */   }
/*     */ 
/*     */   public static void put(String paramString, DevelopmentComponent paramDevelopmentComponent)
/*     */   {
/*  83 */     allDevelopmentComponents.put(paramString, paramDevelopmentComponent);
/*     */   }
/*     */ 
/*     */   public static void remove(String paramString)
/*     */   {
/*  93 */     allDevelopmentComponents.remove(paramString);
/*     */   }
/*     */ 
/*     */   public static DevelopmentComponent getDevelopmentComponent(Class paramClass)
/*     */   {
/* 105 */     DevelopmentComponent localDevelopmentComponent = null;
/* 106 */     if (paramClass != null) {
/* 107 */       String str1 = paramClass.getName();
/* 108 */       Set localSet = allDevelopmentComponents.entrySet();
/* 109 */       Iterator localIterator = localSet.iterator();
/* 110 */       while (localIterator.hasNext()) {
/* 111 */         Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 112 */         String str2 = (String)localEntry.getKey();
/* 113 */         if (str1.indexOf(str2) >= 0) {
/* 114 */           localDevelopmentComponent = (DevelopmentComponent)localEntry.getValue();
/* 115 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 119 */     return localDevelopmentComponent;
/*     */   }
/*     */ 
/*     */   public static void addCriterionDC(String paramString, DevelopmentComponent paramDevelopmentComponent)
/*     */   {
/* 127 */     validateDCRootPackage(paramString);
/* 128 */     criterionDevelopmentComponents.put(paramString, paramDevelopmentComponent);
/*     */   }
/*     */ 
/*     */   private static void validateDCRootPackage(String paramString) {
/* 132 */     Set localSet = criterionDevelopmentComponents.keySet();
/* 133 */     Iterator localIterator = localSet.iterator();
/* 134 */     while (localIterator.hasNext()) {
/* 135 */       String str = (String)localIterator.next();
/* 136 */       if (paramString.length() < str.length()) {
/* 137 */         if (str.indexOf(paramString) > -1)
/* 138 */           throw new CoreException("EAPTECH001111", new String[] { paramString });
/*     */       }
/* 140 */       else if (paramString.indexOf(str) > -1)
/* 141 */         throw new CoreException("EAPTECH001111", new String[] { paramString });
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void removeCriterionDC(String paramString)
/*     */   {
/* 151 */     criterionDevelopmentComponents.remove(paramString);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.DCRepository
 * JD-Core Version:    0.6.2
 */