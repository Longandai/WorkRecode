package com.neusoft.unieap.core.base.model;

import java.util.List;

public abstract interface SoftwareComponent extends Component
{
  public abstract boolean isApp();

  public abstract DevelopmentComponent getDevelopmentComponent(String paramString);

  public abstract List getDevelopmentComponents();

  public abstract List getAvailableDevelopmentComponents();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.SoftwareComponent
 * JD-Core Version:    0.6.2
 */