/*     */ package com.neusoft.unieap.core.base.model;
/*     */ 
/*     */ import com.neusoft.unieap.core.protection.custom.CustomCheck;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class DCActivator
/*     */   implements DevelopmentComponent, InitializingBean, DisposableBean
/*     */ {
/*     */   private String id;
/*     */   private String title;
/*  21 */   private boolean enabled = true;
/*     */   private SoftwareComponent sc;
/*     */   private String version;
/*     */   private static final String DIVIDE_DOT = ".";
/*     */   private static final String DEFAULT_DIR = "bootstrap";
/*     */ 
/*     */   public String getId()
/*     */   {
/*  32 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String paramString) {
/*  36 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle() {
/*  40 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString) {
/*  44 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/*  48 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String paramString) {
/*  52 */     this.version = paramString;
/*     */   }
/*     */ 
/*     */   public void setEnabled(boolean paramBoolean)
/*     */   {
/*  61 */     this.enabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  70 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public void setSc(SoftwareComponent paramSoftwareComponent)
/*     */   {
/*  79 */     this.sc = paramSoftwareComponent;
/*     */   }
/*     */ 
/*     */   public SoftwareComponent getSoftwareComponent()
/*     */   {
/*  90 */     return this.sc;
/*     */   }
/*     */ 
/*     */   protected void startup()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void shutdown()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public final void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 116 */     CustomCheck.getInstance().check(false);
/* 117 */     if (this.sc != null) {
/* 118 */       SCActivator localSCActivator = (SCActivator)this.sc;
/* 119 */       localSCActivator.addDevelopmentComponent(this);
/* 120 */       if (this.enabled) {
/* 121 */         localSCActivator.setEnabled(true);
/* 122 */         startup();
/* 123 */         registerComponent();
/*     */       }
/*     */     }
/* 126 */     else if (this.enabled) {
/* 127 */       startup();
/* 128 */       registerComponent();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void destroy()
/*     */     throws Exception
/*     */   {
/* 139 */     if (this.enabled) {
/* 140 */       shutdown();
/* 141 */       unregisterComponent();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void registerComponent() {
/* 146 */     DCRepository.put(getId(), this);
/* 147 */     String str = getRootPackage();
/* 148 */     if (str != null)
/* 149 */       DCRepository.addCriterionDC(str, this);
/*     */   }
/*     */ 
/*     */   protected void unregisterComponent() {
/* 153 */     DCRepository.remove(getId());
/* 154 */     String str = getRootPackage();
/* 155 */     if (str != null)
/* 156 */       DCRepository.removeCriterionDC(str);
/*     */   }
/*     */ 
/*     */   protected String getRootPackage()
/*     */   {
/* 170 */     String str1 = getClass().getName();
/* 171 */     String str2 = str1.substring(str1
/* 172 */       .lastIndexOf(".") + 1);
/* 173 */     StringBuffer localStringBuffer = new StringBuffer();
/* 174 */     localStringBuffer.append(".");
/* 175 */     localStringBuffer.append("bootstrap");
/* 176 */     localStringBuffer.append(".");
/* 177 */     localStringBuffer.append(str2);
/* 178 */     int i = str1.indexOf(localStringBuffer.toString());
/* 179 */     String str3 = null;
/* 180 */     if (i > 0)
/* 181 */       str3 = str1.substring(0, i);
/* 182 */     return str3;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.DCActivator
 * JD-Core Version:    0.6.2
 */