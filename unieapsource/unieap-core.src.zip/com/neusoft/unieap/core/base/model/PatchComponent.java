package com.neusoft.unieap.core.base.model;

public abstract interface PatchComponent extends Component
{
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.PatchComponent
 * JD-Core Version:    0.6.2
 */