/*     */ package com.neusoft.unieap.core.base.model;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ 
/*     */ public class Application
/*     */ {
/*     */   private String id;
/*     */   private String title;
/*     */   private String welcome;
/*     */   private String icon;
/*     */   private String bigIcon;
/*     */   private String message;
/*     */ 
/*     */   public String getMessage()
/*     */   {
/*  20 */     if (this.message == null) {
/*  21 */       return "";
/*     */     }
/*  23 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void setMessage(String paramString) {
/*  27 */     this.message = paramString;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/*  36 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  45 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/*  54 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString)
/*     */   {
/*  63 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   public String getWelcome()
/*     */   {
/*  72 */     return this.welcome;
/*     */   }
/*     */ 
/*     */   public void setWelcome(String paramString)
/*     */   {
/*  81 */     if ((paramString == null) || (paramString.equals(""))) {
/*  82 */       return;
/*     */     }
/*  84 */     this.welcome = combineWelcomePage(paramString);
/*     */   }
/*     */ 
/*     */   private String combineWelcomePage(String paramString) {
/*  88 */     StringBuffer localStringBuffer = new StringBuffer();
/*  89 */     localStringBuffer.append(paramString);
/*  90 */     localStringBuffer.append(paramString.lastIndexOf("?") > -1 ? "&" : "?");
/*  91 */     localStringBuffer.append("title=");
/*  92 */     localStringBuffer.append(encode(this.title));
/*  93 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   private String encode(String paramString)
/*     */   {
/* 101 */     if ((paramString == null) || (paramString.equals("")))
/* 102 */       return "";
/* 103 */     String str = paramString;
/*     */     try {
/* 105 */       str = URLEncoder.encode(str, "utf-8");
/* 106 */       if (str.indexOf("+") != -1) {
/* 107 */         str = str.replaceAll("[+]", "%20");
/*     */       }
/*     */ 
/* 110 */       str = URLEncoder.encode(str, "utf-8");
/*     */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 112 */       return str;
/*     */     }
/* 114 */     return str;
/*     */   }
/*     */ 
/*     */   public String getIcon()
/*     */   {
/* 123 */     return this.icon;
/*     */   }
/*     */ 
/*     */   public void setIcon(String paramString)
/*     */   {
/* 132 */     this.icon = paramString;
/*     */   }
/*     */ 
/*     */   public void setBigIcon(String paramString)
/*     */   {
/* 141 */     this.bigIcon = paramString;
/*     */   }
/*     */ 
/*     */   public String getBigIcon()
/*     */   {
/* 150 */     return this.bigIcon;
/*     */   }
/*     */ 
/*     */   public String toJson() {
/* 154 */     StringBuffer localStringBuffer = new StringBuffer("{");
/* 155 */     localStringBuffer.append("id")
/* 156 */       .append(":")
/* 157 */       .append("\"")
/* 158 */       .append(this.id)
/* 159 */       .append("\"")
/* 160 */       .append(",")
/* 161 */       .append("message")
/* 162 */       .append(":")
/* 163 */       .append("\"")
/* 164 */       .append(getMessage())
/* 165 */       .append("\"")
/* 166 */       .append(",")
/* 167 */       .append("title")
/* 168 */       .append(":")
/* 169 */       .append("\"")
/* 170 */       .append(this.title)
/* 171 */       .append("\"")
/* 172 */       .append(",")
/* 173 */       .append("welcome")
/* 174 */       .append(":")
/* 175 */       .append("\"")
/* 176 */       .append(this.welcome)
/* 177 */       .append("\"")
/* 178 */       .append(",")
/* 179 */       .append("icon")
/* 180 */       .append(":")
/* 181 */       .append("\"")
/* 182 */       .append(this.icon)
/* 183 */       .append("\"")
/* 184 */       .append(",")
/* 185 */       .append("bigIcon")
/* 186 */       .append(":")
/* 187 */       .append("\"")
/* 188 */       .append(this.bigIcon)
/* 189 */       .append("\"")
/* 190 */       .append("}");
/* 191 */     return localStringBuffer.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.Application
 * JD-Core Version:    0.6.2
 */