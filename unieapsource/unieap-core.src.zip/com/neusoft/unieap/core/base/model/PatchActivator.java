/*    */ package com.neusoft.unieap.core.base.model;
/*    */ 
/*    */ public class PatchActivator extends DCActivator
/*    */   implements PatchComponent
/*    */ {
/*    */   protected void registerComponent()
/*    */   {
/*  6 */     PatchRepository.put(getId(), this);
/*  7 */     String str = getRootPackage();
/*  8 */     if (str != null)
/*  9 */       PatchRepository.addCriterionPatch(str, this);
/*    */   }
/*    */ 
/*    */   protected void unregisterComponent() {
/* 13 */     PatchRepository.remove(getId());
/* 14 */     String str = getRootPackage();
/* 15 */     if (str != null)
/* 16 */       PatchRepository.removeCriterionPatch(str);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.PatchActivator
 * JD-Core Version:    0.6.2
 */