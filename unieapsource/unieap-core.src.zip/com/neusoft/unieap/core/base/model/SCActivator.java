/*     */ package com.neusoft.unieap.core.base.model;
/*     */ 
/*     */ import com.neusoft.unieap.core.protection.Protection;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class SCActivator
/*     */   implements SoftwareComponent, InitializingBean
/*     */ {
/*     */   private String id;
/*     */   private String title;
/*  27 */   private boolean enabled = false;
/*     */   private String version;
/*     */   private Application application;
/*  33 */   private Map developmentComponents = new HashMap();
/*     */ 
/*     */   public String getId()
/*     */   {
/*  41 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setId(String paramString)
/*     */   {
/*  50 */     this.id = paramString;
/*     */   }
/*     */ 
/*     */   public String getTitle()
/*     */   {
/*  59 */     return this.title;
/*     */   }
/*     */ 
/*     */   public void setTitle(String paramString)
/*     */   {
/*  68 */     this.title = paramString;
/*     */   }
/*     */ 
/*     */   void setEnabled(boolean paramBoolean)
/*     */   {
/*  77 */     this.enabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isEnabled()
/*     */   {
/*  86 */     return this.enabled;
/*     */   }
/*     */ 
/*     */   public String getVersion() {
/*  90 */     return this.version;
/*     */   }
/*     */ 
/*     */   public void setVersion(String paramString) {
/*  94 */     this.version = paramString;
/*     */   }
/*     */ 
/*     */   public Application getApplication()
/*     */   {
/* 103 */     return this.application;
/*     */   }
/*     */ 
/*     */   public void setApplication(Application paramApplication)
/*     */   {
/* 112 */     this.application = paramApplication;
/* 113 */     this.application.setId(this.id);
/* 114 */     if (this.application.getTitle() == null)
/* 115 */       this.application.setTitle(this.title);
/*     */   }
/*     */ 
/*     */   public List getDevelopmentComponents()
/*     */   {
/* 127 */     ArrayList localArrayList = new ArrayList();
/* 128 */     localArrayList.addAll(this.developmentComponents.values());
/* 129 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public final void addDevelopmentComponent(DevelopmentComponent paramDevelopmentComponent)
/*     */   {
/* 139 */     String str = paramDevelopmentComponent.getId();
/* 140 */     this.developmentComponents.put(str, paramDevelopmentComponent);
/*     */   }
/*     */ 
/*     */   public List getAvailableDevelopmentComponents()
/*     */   {
/* 150 */     ArrayList localArrayList = new ArrayList();
/*     */ 
/* 152 */     for (Iterator localIterator = this.developmentComponents.values().iterator(); localIterator
/* 153 */       .hasNext(); )
/*     */     {
/*     */       DevelopmentComponent localDevelopmentComponent;
/* 154 */       if ((localDevelopmentComponent = (DevelopmentComponent)localIterator.next()).isEnabled()) {
/* 155 */         localArrayList.add(localDevelopmentComponent);
/*     */       }
/*     */     }
/* 158 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public DevelopmentComponent getDevelopmentComponent(String paramString)
/*     */   {
/* 169 */     return (DevelopmentComponent)this.developmentComponents.get(paramString);
/*     */   }
/*     */ 
/*     */   public boolean isApp()
/*     */   {
/* 178 */     return getApplication() != null;
/*     */   }
/*     */ 
/*     */   public final void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 188 */     Protection.check(Boolean.valueOf(false));
/* 189 */     SCRepository.addSoftwareComponent(this);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.model.SCActivator
 * JD-Core Version:    0.6.2
 */