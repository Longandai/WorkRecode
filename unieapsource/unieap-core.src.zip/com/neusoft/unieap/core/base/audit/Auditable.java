package com.neusoft.unieap.core.base.audit;

import java.sql.Timestamp;

public abstract interface Auditable
{
  public static final String PROPERTY_CREATED_BY = "createdBy";
  public static final String PROPERTY_CREATION_TIME = "creationTime";
  public static final String PROPERTY_MODIFIED_BY = "modifiedBy";
  public static final String PROPERTY_MODIFICATION_TIME = "modificationTime";

  public abstract String getCreatedBy();

  public abstract void setCreatedBy(String paramString);

  public abstract Timestamp getCreationTime();

  public abstract void setCreationTime(Timestamp paramTimestamp);

  public abstract String getModifiedBy();

  public abstract void setModifiedBy(String paramString);

  public abstract Timestamp getModificationTime();

  public abstract void setModificationTime(Timestamp paramTimestamp);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.base.audit.Auditable
 * JD-Core Version:    0.6.2
 */