package com.neusoft.unieap.core.common.bo;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

public abstract interface CommonBO
{
  public abstract QueryResult findByExample(Object paramObject, int paramInt1, int paramInt2)
    throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, IntrospectionException, InstantiationException;

  public abstract List findByExample(Object paramObject);

  public abstract QueryResult findByNamedQuery(String paramString, Object[] paramArrayOfObject);

  public abstract QueryResult findByStatement(String paramString, Map paramMap);

  public abstract int getRecordCount(Object paramObject);

  public abstract Object save(Object paramObject);

  public abstract Object update(Object paramObject);

  public abstract Object saveOrUpdate(Object paramObject);

  public abstract void delete(Object paramObject);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.bo.CommonBO
 * JD-Core Version:    0.6.2
 */