/*     */ package com.neusoft.unieap.core.common.bo.QueryResult;
/*     */ 
/*     */ import com.neusoft.unieap.core.page.PageContext;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class QueryResult
/*     */ {
/*     */   private List result;
/*     */   private int recordCount;
/*     */   private int pageSize;
/*     */   private int pageNumber;
/*     */   private PageContext pageContext;
/*  23 */   private boolean autoCalcCount = false;
/*     */ 
/*     */   public QueryResult() {
/*  26 */     this.result = new ArrayList();
/*  27 */     this.recordCount = 0;
/*     */   }
/*     */ 
/*     */   public QueryResult(List paramList, int paramInt1, int paramInt2, int paramInt3) {
/*  31 */     this.result = paramList;
/*  32 */     this.recordCount = paramInt1;
/*  33 */     this.pageNumber = paramInt2;
/*  34 */     this.pageSize = paramInt3;
/*     */   }
/*     */ 
/*     */   public void setRecordCount(int paramInt)
/*     */   {
/*  42 */     this.recordCount = paramInt;
/*     */   }
/*     */ 
/*     */   public int getRecordCount()
/*     */   {
/*  50 */     return this.recordCount;
/*     */   }
/*     */ 
/*     */   public void setPageNumber(int paramInt)
/*     */   {
/*  58 */     this.pageNumber = paramInt;
/*     */   }
/*     */ 
/*     */   public int getPageNumber()
/*     */   {
/*  66 */     return this.pageNumber;
/*     */   }
/*     */ 
/*     */   public void setPageSize(int paramInt)
/*     */   {
/*  74 */     this.pageSize = paramInt;
/*     */   }
/*     */ 
/*     */   public int getPageSize()
/*     */   {
/*  82 */     return this.pageSize;
/*     */   }
/*     */ 
/*     */   public List getResult() {
/*  86 */     return this.result;
/*     */   }
/*     */ 
/*     */   public void setResult(List paramList) {
/*  90 */     this.result = paramList;
/*     */   }
/*     */ 
/*     */   public void setPageContext(PageContext paramPageContext) {
/*  94 */     this.pageContext = paramPageContext;
/*     */   }
/*     */ 
/*     */   public PageContext getPageContext() {
/*  98 */     return this.pageContext;
/*     */   }
/*     */ 
/*     */   public void setAutoCalcCount(boolean paramBoolean) {
/* 102 */     this.autoCalcCount = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isAutoCalcCount() {
/* 106 */     return this.autoCalcCount;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.bo.QueryResult.QueryResult
 * JD-Core Version:    0.6.2
 */