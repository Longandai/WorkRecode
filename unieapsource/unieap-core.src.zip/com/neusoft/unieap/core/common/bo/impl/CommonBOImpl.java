/*     */ package com.neusoft.unieap.core.common.bo.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.common.bo.CommonBO;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.common.dao.CommonDAO;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class CommonBOImpl
/*     */   implements CommonBO
/*     */ {
/*     */   private CommonDAO commonDAO;
/*     */ 
/*     */   public void setCommonDAO(CommonDAO paramCommonDAO)
/*     */   {
/*  19 */     this.commonDAO = paramCommonDAO;
/*     */   }
/*     */ 
/*     */   public QueryResult findByExample(Object paramObject, int paramInt1, int paramInt2)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, IntrospectionException, InstantiationException
/*     */   {
/*  38 */     List localList = this.commonDAO.findByExample(paramObject, paramInt1, paramInt2);
/*  39 */     int i = this.commonDAO.getRecordCount(paramObject);
/*     */ 
/*  41 */     QueryResult localQueryResult = new QueryResult(localList, i, paramInt1, paramInt2);
/*  42 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public List findByExample(Object paramObject)
/*     */   {
/*  56 */     return this.commonDAO.findByExample(paramObject);
/*     */   }
/*     */ 
/*     */   public int getRecordCount(Object paramObject)
/*     */   {
/*  70 */     return this.commonDAO.getRecordCount(paramObject);
/*     */   }
/*     */ 
/*     */   public Object save(Object paramObject)
/*     */   {
/*  81 */     return this.commonDAO.save(paramObject);
/*     */   }
/*     */ 
/*     */   public Object update(Object paramObject)
/*     */   {
/*  92 */     return this.commonDAO.update(paramObject);
/*     */   }
/*     */ 
/*     */   public Object saveOrUpdate(Object paramObject)
/*     */   {
/* 102 */     return this.commonDAO.saveOrUpdate(paramObject);
/*     */   }
/*     */ 
/*     */   public void delete(Object paramObject)
/*     */   {
/* 112 */     this.commonDAO.delete(paramObject);
/*     */   }
/*     */ 
/*     */   public QueryResult findByNamedQuery(String paramString, Object[] paramArrayOfObject)
/*     */   {
/* 119 */     return this.commonDAO.findByNamedQuery(paramString, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   public QueryResult findByStatement(String paramString, Map paramMap)
/*     */   {
/* 126 */     return this.commonDAO.findByStatement(paramString, paramMap);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.bo.impl.CommonBOImpl
 * JD-Core Version:    0.6.2
 */