package com.neusoft.unieap.core.common.bo.context;

import com.neusoft.unieap.core.base.exception.CoreException;
import java.util.Map;

public abstract interface BOContext extends Map
{
  public abstract String getString(String paramString)
    throws CoreException;

  public abstract int getInt(String paramString)
    throws CoreException;

  public abstract boolean getBoolean(String paramString)
    throws CoreException;

  public abstract long getLong(String paramString)
    throws CoreException;

  public abstract float getFloat(String paramString)
    throws CoreException;

  public abstract double getDouble(String paramString)
    throws CoreException;
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.bo.context.BOContext
 * JD-Core Version:    0.6.2
 */