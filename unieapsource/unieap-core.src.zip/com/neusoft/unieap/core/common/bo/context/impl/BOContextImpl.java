/*    */ package com.neusoft.unieap.core.common.bo.context.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.exception.CoreException;
/*    */ import com.neusoft.unieap.core.common.bo.context.BOContext;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class BOContextImpl extends HashMap
/*    */   implements BOContext
/*    */ {
/*    */   private static final long serialVersionUID = -3840535540889437828L;
/*    */ 
/*    */   public String getString(String paramString)
/*    */     throws CoreException
/*    */   {
/* 17 */     Object localObject = get(paramString);
/* 18 */     if (localObject == null) {
/* 19 */       return null;
/*    */     }
/* 21 */     if ((localObject instanceof String[])) {
/* 22 */       return ((String[])localObject)[0];
/*    */     }
/* 24 */     return String.valueOf(localObject);
/*    */   }
/*    */ 
/*    */   public boolean getBoolean(String paramString)
/*    */     throws CoreException
/*    */   {
/* 31 */     if (get(paramString) == null) {
/* 32 */       throw new CoreException("EAPTECH001001", new String[] { paramString });
/*    */     }
/* 34 */     return Boolean.getBoolean(getString(paramString));
/*    */   }
/*    */ 
/*    */   public double getDouble(String paramString)
/*    */     throws CoreException
/*    */   {
/* 41 */     if (get(paramString) == null) {
/* 42 */       throw new CoreException("EAPTECH001001", new String[] { paramString });
/*    */     }
/* 44 */     return Double.parseDouble(getString(paramString));
/*    */   }
/*    */ 
/*    */   public float getFloat(String paramString)
/*    */     throws CoreException
/*    */   {
/* 51 */     if (get(paramString) == null) {
/* 52 */       throw new CoreException("EAPTECH001001", new String[] { paramString });
/*    */     }
/* 54 */     return Float.parseFloat(getString(paramString));
/*    */   }
/*    */ 
/*    */   public int getInt(String paramString)
/*    */     throws CoreException
/*    */   {
/* 61 */     if (get(paramString) == null) {
/* 62 */       throw new CoreException("EAPTECH001001", new String[] { paramString });
/*    */     }
/* 64 */     return Integer.parseInt(getString(paramString));
/*    */   }
/*    */ 
/*    */   public long getLong(String paramString)
/*    */     throws CoreException
/*    */   {
/* 71 */     if (get(paramString) == null) {
/* 72 */       throw new CoreException("EAPTECH001001", new String[] { paramString });
/*    */     }
/* 74 */     return Long.parseLong(getString(paramString));
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.bo.context.impl.BOContextImpl
 * JD-Core Version:    0.6.2
 */