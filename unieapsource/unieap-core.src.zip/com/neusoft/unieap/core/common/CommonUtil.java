/*     */ package com.neusoft.unieap.core.common;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.criterion.MatchMode;
/*     */ import org.hibernate.criterion.Restrictions;
/*     */ 
/*     */ public class CommonUtil
/*     */ {
/*     */   public static Criteria getCriteria(Object paramObject, Class paramClass, Criteria paramCriteria)
/*     */     throws IntrospectionException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/*  37 */     Map localMap = initPropertyRegionMap(paramObject, paramClass);
/*     */ 
/*  39 */     Object localObject1 = null;
/*  40 */     BeanInfo localBeanInfo = Introspector.getBeanInfo(paramClass);
/*  41 */     PropertyDescriptor[] arrayOfPropertyDescriptor = localBeanInfo.getPropertyDescriptors();
/*  42 */     for (int i = 0; i < arrayOfPropertyDescriptor.length; i++) {
/*  43 */       PropertyDescriptor localPropertyDescriptor = arrayOfPropertyDescriptor[i];
/*  44 */       String str = localPropertyDescriptor.getName();
/*  45 */       if (str != null) {
/*  46 */         Method localMethod = localPropertyDescriptor.getReadMethod();
/*  47 */         Class localClass = localMethod.getReturnType();
/*  48 */         if ((!str.equals("class")) || 
/*  49 */           (!localPropertyDescriptor.getPropertyType().getName().equals(
/*  50 */           "java.lang.Class")))
/*     */         {
/*  54 */           localObject1 = localMethod.invoke(paramObject, new Object[0]);
/*  55 */           if ((localClass.isPrimitive()) || (localClass == String.class) || 
/*  56 */             (localClass.getName().startsWith("java.")) || 
/*  57 */             (localClass.getName().startsWith("javax."))) {
/*  58 */             if (str.equals("id")) {
/*  59 */               if (localObject1 != null)
/*     */               {
/*  62 */                 paramCriteria.add(Restrictions.eq("id", localObject1));
/*     */               }
/*     */             }
/*     */             else
/*     */             {
/*     */               Object localObject2;
/*  65 */               if (localMap.containsKey(str)) {
/*  66 */                 localObject2 = (List)localMap.get(str);
/*  67 */                 if (((List)localObject2).get(0) != null) {
/*  68 */                   paramCriteria.add(Restrictions.ge(str, ((List)localObject2).get(0)));
/*     */                 }
/*  70 */                 if (((List)localObject2).get(1) != null)
/*  71 */                   paramCriteria.add(Restrictions.le(str, ((List)localObject2).get(1)));
/*     */               }
/*     */               else {
/*  74 */                 if (str.endsWith("From")) {
/*  75 */                   localObject2 = str.substring(0, str.indexOf("From"));
/*  76 */                   if (localMap.containsKey(localObject2))
/*  77 */                     continue;
/*     */                 }
/*  79 */                 else if (str.endsWith("To")) {
/*  80 */                   localObject2 = str.substring(0, str.indexOf("To"));
/*  81 */                   if (localMap.containsKey(localObject2)) {
/*     */                     continue;
/*     */                   }
/*     */                 }
/*  85 */                 if (localObject1 != null)
/*     */                 {
/*  89 */                   if ((!Collections.class.isAssignableFrom(localClass)) || 
/*  90 */                     (!Map.class.isAssignableFrom(localClass)))
/*     */                   {
/*  93 */                     if ((localObject1 instanceof String))
/*     */                     {
/*  95 */                       paramCriteria.add(Restrictions.like(str, localObject1
/*  96 */                         .toString(), MatchMode.ANYWHERE));
/*     */                     }
/*     */                     else
/*  99 */                       paramCriteria.add(
/* 100 */                         Restrictions.like(str, localObject1)); 
/*     */                   }
/*     */                 }
/*     */               }
/*     */             } } else paramCriteria = getCascadeCriteria(localObject1, localClass, paramCriteria, 
/* 105 */               str);
/*     */         }
/*     */       }
/*     */     }
/* 109 */     return paramCriteria;
/*     */   }
/*     */ 
/*     */   private static Map initPropertyRegionMap(Object paramObject, Class paramClass) throws IntrospectionException, IllegalArgumentException, IllegalAccessException, InvocationTargetException {
/* 113 */     HashMap localHashMap = new HashMap();
/* 114 */     BeanInfo localBeanInfo = Introspector.getBeanInfo(paramClass);
/* 115 */     PropertyDescriptor[] arrayOfPropertyDescriptor = localBeanInfo.getPropertyDescriptors();
/* 116 */     if (arrayOfPropertyDescriptor == null) {
/* 117 */       return localHashMap;
/*     */     }
/* 119 */     for (int i = 0; i < arrayOfPropertyDescriptor.length; i++) {
/* 120 */       String str1 = arrayOfPropertyDescriptor[i].getName();
/* 121 */       if (str1.endsWith("From")) {
/* 122 */         String str2 = str1.substring(0, str1.indexOf("From"));
/* 123 */         Object localObject1 = getRegionPropertyEnd(str2, arrayOfPropertyDescriptor, i);
/* 124 */         if (localObject1 != null) {
/* 125 */           ArrayList localArrayList = new ArrayList();
/*     */ 
/* 127 */           Method localMethod = arrayOfPropertyDescriptor[i].getReadMethod();
/* 128 */           Object localObject2 = localMethod.invoke(paramObject, new Object[0]);
/* 129 */           localArrayList.add(localObject2);
/*     */ 
/* 131 */           int j = Integer.parseInt(localObject1.toString());
/* 132 */           localMethod = arrayOfPropertyDescriptor[j].getReadMethod();
/* 133 */           localObject2 = localMethod.invoke(paramObject, new Object[0]);
/* 134 */           localArrayList.add(localObject2);
/* 135 */           localHashMap.put(str2, localArrayList);
/*     */         }
/*     */       }
/*     */     }
/* 139 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private static Object getRegionPropertyEnd(String paramString, PropertyDescriptor[] paramArrayOfPropertyDescriptor, int paramInt)
/*     */   {
/* 151 */     int i = 0;
/* 152 */     int j = 0;
/* 153 */     for (j = paramInt; j >= 0; j--) {
/* 154 */       if (paramString.equals(paramArrayOfPropertyDescriptor[j].getName())) {
/* 155 */         i = 1;
/* 156 */         break;
/*     */       }
/*     */     }
/* 159 */     if (i == 0) {
/* 160 */       for (j = paramInt + 1; j < paramArrayOfPropertyDescriptor.length; j++) {
/* 161 */         if (paramString.equals(paramArrayOfPropertyDescriptor[j].getName())) {
/* 162 */           i = 1;
/* 163 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 167 */     if (i == 0) {
/* 168 */       return null;
/*     */     }
/* 170 */     int k = 0;
/* 171 */     for (j = paramInt + 1; j < paramArrayOfPropertyDescriptor.length; j++) {
/* 172 */       if ((paramArrayOfPropertyDescriptor[j].getName() != null) && (paramArrayOfPropertyDescriptor[j].getName().endsWith("To"))) {
/* 173 */         k = 1;
/* 174 */         break;
/*     */       }
/*     */     }
/* 177 */     if (k == 0) {
/* 178 */       for (j = paramInt; j >= 0; j--) {
/* 179 */         if ((paramArrayOfPropertyDescriptor[j].getName() != null) && (paramArrayOfPropertyDescriptor[j].getName().endsWith("To"))) {
/* 180 */           k = 1;
/* 181 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 185 */     if (k == 0) {
/* 186 */       return null;
/*     */     }
/* 188 */     return Integer.valueOf(j);
/*     */   }
/*     */ 
/*     */   public static Criteria getCascadeCriteria(Object paramObject, Class paramClass, Criteria paramCriteria, String paramString)
/*     */     throws IntrospectionException, IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 207 */     if (paramObject == null) {
/* 208 */       return paramCriteria;
/*     */     }
/* 210 */     BeanInfo localBeanInfo = Introspector.getBeanInfo(paramClass);
/* 211 */     PropertyDescriptor[] arrayOfPropertyDescriptor1 = localBeanInfo.getPropertyDescriptors();
/* 212 */     for (PropertyDescriptor localPropertyDescriptor : arrayOfPropertyDescriptor1) {
/* 213 */       if ("id".equals(localPropertyDescriptor.getName())) {
/* 214 */         Method localMethod = localPropertyDescriptor.getReadMethod();
/* 215 */         Object localObject = localMethod.invoke(paramObject, new Object[0]);
/* 216 */         if (localObject == null) break;
/* 217 */         paramCriteria.add(Restrictions.eq(paramString + "." + "id", 
/* 218 */           localObject));
/*     */ 
/* 220 */         break;
/*     */       }
/*     */     }
/* 223 */     return paramCriteria;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.CommonUtil
 * JD-Core Version:    0.6.2
 */