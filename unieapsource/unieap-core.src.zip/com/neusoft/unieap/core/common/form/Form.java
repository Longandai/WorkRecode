/*    */ package com.neusoft.unieap.core.common.form;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class Form
/*    */ {
/*    */   private Object object;
/*    */   private List files;
/*    */ 
/*    */   public void setObject(Object paramObject)
/*    */   {
/* 18 */     this.object = paramObject;
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 26 */     return this.object;
/*    */   }
/*    */ 
/*    */   public void setFiles(List paramList) {
/* 30 */     this.files = paramList;
/*    */   }
/*    */ 
/*    */   public List getFiles()
/*    */   {
/* 39 */     return this.files;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.form.Form
 * JD-Core Version:    0.6.2
 */