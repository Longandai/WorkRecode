package com.neusoft.unieap.core.common.dao;

import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
import java.beans.IntrospectionException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

public abstract interface CommonDAO
{
  public abstract List findByExample(Object paramObject, int paramInt1, int paramInt2)
    throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, IntrospectionException, InstantiationException;

  public abstract List findByExample(Object paramObject);

  public abstract QueryResult findByNamedQuery(String paramString, Object[] paramArrayOfObject);

  public abstract int getNamedQueryRecordCount(String paramString, Object[] paramArrayOfObject);

  public abstract QueryResult findByStatement(String paramString, Map paramMap);

  public abstract int getRecordCount(Object paramObject);

  public abstract Object save(Object paramObject);

  public abstract List save(List paramList);

  public abstract Object update(Object paramObject);

  public abstract List update(List paramList);

  public abstract Object saveOrUpdate(Object paramObject);

  public abstract List saveOrUpdate(List paramList);

  public abstract void delete(Object paramObject);

  public abstract void delete(List paramList);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.dao.CommonDAO
 * JD-Core Version:    0.6.2
 */