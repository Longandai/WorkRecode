/*     */ package com.neusoft.unieap.core.common.dao.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*     */ import com.neusoft.unieap.core.base.exception.CoreException;
/*     */ import com.neusoft.unieap.core.common.CommonUtil;
/*     */ import com.neusoft.unieap.core.common.bo.QueryResult.QueryResult;
/*     */ import com.neusoft.unieap.core.common.dao.CommonDAO;
/*     */ import com.neusoft.unieap.core.page.PageUtil;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.hibernate.Criteria;
/*     */ import org.hibernate.HibernateException;
/*     */ import org.hibernate.Query;
/*     */ import org.hibernate.Session;
/*     */ import org.hibernate.criterion.Projections;
/*     */ import org.springframework.orm.hibernate3.HibernateCallback;
/*     */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*     */ 
/*     */ public class CommonDAOImpl extends BaseHibernateDAO
/*     */   implements CommonDAO
/*     */ {
/*     */   public List findByExample(final Object paramObject, final int paramInt1, final int paramInt2)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException, IntrospectionException, InstantiationException
/*     */   {
/*  53 */     List localList = (List)getHibernateTemplate().execute(
/*  54 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/*  58 */         Class localClass = paramObject.getClass();
/*  59 */         Criteria localCriteria = paramAnonymousSession.createCriteria(localClass);
/*     */         try {
/*  61 */           localCriteria = CommonUtil.getCriteria(paramObject, localClass, 
/*  62 */             localCriteria);
/*     */         } catch (IntrospectionException localIntrospectionException) {
/*  64 */           localIntrospectionException.printStackTrace();
/*     */         } catch (IllegalAccessException localIllegalAccessException) {
/*  66 */           localIllegalAccessException.printStackTrace();
/*     */         } catch (InvocationTargetException localInvocationTargetException) {
/*  68 */           localInvocationTargetException.printStackTrace();
/*     */         } catch (InstantiationException localInstantiationException) {
/*  70 */           localInstantiationException.printStackTrace();
/*     */         }
/*  72 */         localCriteria.setMaxResults(paramInt2);
/*  73 */         localCriteria.setFirstResult((paramInt1 - 1) * paramInt2);
/*  74 */         return localCriteria.list();
/*     */       }
/*     */     });
/*  77 */     return localList;
/*     */   }
/*     */ 
/*     */   public int getRecordCount(final Object paramObject)
/*     */   {
/*  88 */     Integer localInteger = (Integer)getHibernateTemplate().execute(
/*  89 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/*  93 */         Class localClass = paramObject.getClass();
/*  94 */         Criteria localCriteria = paramAnonymousSession.createCriteria(localClass);
/*     */         try {
/*  96 */           localCriteria = CommonUtil.getCriteria(paramObject, localClass, 
/*  97 */             localCriteria);
/*     */         } catch (IntrospectionException localIntrospectionException) {
/*  99 */           localIntrospectionException.printStackTrace();
/*     */         } catch (IllegalAccessException localIllegalAccessException) {
/* 101 */           localIllegalAccessException.printStackTrace();
/*     */         } catch (InvocationTargetException localInvocationTargetException) {
/* 103 */           localInvocationTargetException.printStackTrace();
/*     */         } catch (InstantiationException localInstantiationException) {
/* 105 */           localInstantiationException.printStackTrace();
/*     */         }
/* 107 */         return localCriteria.setProjection(Projections.rowCount())
/* 108 */           .uniqueResult();
/*     */       }
/*     */     });
/* 111 */     if (localInteger == null) {
/* 112 */       return 0;
/*     */     }
/* 114 */     return localInteger.intValue();
/*     */   }
/*     */ 
/*     */   public List findByExample(final Object paramObject)
/*     */   {
/* 124 */     List localList = (List)getHibernateTemplate().execute(
/* 125 */       new HibernateCallback()
/*     */     {
/*     */       public Object doInHibernate(Session paramAnonymousSession) throws HibernateException, SQLException
/*     */       {
/* 129 */         Class localClass = paramObject.getClass();
/* 130 */         Criteria localCriteria = paramAnonymousSession.createCriteria(localClass);
/*     */         try {
/* 132 */           localCriteria = CommonUtil.getCriteria(paramObject, localClass, 
/* 133 */             localCriteria);
/*     */         } catch (IntrospectionException localIntrospectionException) {
/* 135 */           localIntrospectionException.printStackTrace();
/*     */         } catch (IllegalAccessException localIllegalAccessException) {
/* 137 */           localIllegalAccessException.printStackTrace();
/*     */         } catch (InvocationTargetException localInvocationTargetException) {
/* 139 */           localInvocationTargetException.printStackTrace();
/*     */         } catch (InstantiationException localInstantiationException) {
/* 141 */           localInstantiationException.printStackTrace();
/*     */         }
/* 143 */         return localCriteria.list();
/*     */       }
/*     */     });
/* 146 */     return localList;
/*     */   }
/*     */ 
/*     */   public Object save(Object paramObject) {
/* 150 */     getHibernateTemplate().save(paramObject);
/* 151 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public List save(List paramList) {
/* 155 */     ArrayList localArrayList = new ArrayList();
/* 156 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) {
/* 157 */       Object localObject = localIterator.next();
/* 158 */       getHibernateTemplate().save(localObject);
/* 159 */       localArrayList.add(localObject);
/*     */     }
/* 161 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public Object update(Object paramObject) {
/* 165 */     getHibernateTemplate().update(paramObject);
/* 166 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public List update(List paramList) {
/* 170 */     ArrayList localArrayList = new ArrayList();
/* 171 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) {
/* 172 */       Object localObject = localIterator.next();
/* 173 */       getHibernateTemplate().update(localObject);
/* 174 */       localArrayList.add(localObject);
/*     */     }
/* 176 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public void delete(Object paramObject) {
/* 180 */     getHibernateTemplate().delete(paramObject);
/*     */   }
/*     */ 
/*     */   public void delete(List paramList) {
/* 184 */     getHibernateTemplate().deleteAll(paramList);
/*     */   }
/*     */ 
/*     */   public Object saveOrUpdate(Object paramObject) {
/* 188 */     getHibernateTemplate().saveOrUpdate(paramObject);
/* 189 */     return paramObject;
/*     */   }
/*     */ 
/*     */   public List saveOrUpdate(List paramList) {
/* 193 */     ArrayList localArrayList = new ArrayList();
/* 194 */     for (Iterator localIterator = paramList.iterator(); localIterator.hasNext(); ) {
/* 195 */       Object localObject = localIterator.next();
/* 196 */       getHibernateTemplate().saveOrUpdate(localObject);
/* 197 */       localArrayList.add(localObject);
/*     */     }
/* 199 */     return localArrayList;
/*     */   }
/*     */ 
/*     */   public QueryResult findByNamedQuery(final String paramString, final Object[] paramArrayOfObject)
/*     */   {
/* 204 */     boolean bool = false;
/* 205 */     QueryResult localQueryResult = PageUtil.getQueryResult();
/* 206 */     int i = CoreVariability.getMaxPageSize();
/* 207 */     int j = 1;
/* 208 */     if (localQueryResult != null) {
/* 209 */       i = localQueryResult.getPageSize();
/* 210 */       j = localQueryResult.getPageNumber();
/* 211 */       bool = localQueryResult.isAutoCalcCount();
/*     */     } else {
/* 213 */       localQueryResult = new QueryResult();
/* 214 */       localQueryResult.setPageNumber(j);
/* 215 */       localQueryResult.setPageSize(i);
/*     */     }
/* 217 */     final int k = i;
/* 218 */     final int m = j;
/* 219 */     List localList = (List)getHibernateTemplate().execute(
/* 220 */       new HibernateCallback() {
/*     */       public Object doInHibernate(Session paramAnonymousSession) {
/*     */         try {
/* 223 */           Query localQuery = paramAnonymousSession.getNamedQuery(paramString);
/* 224 */           if (paramArrayOfObject != null) {
/* 225 */             int i = 0; for (int j = paramArrayOfObject.length; i < j; i++) {
/* 226 */               localQuery.setParameter(i, paramArrayOfObject[i]);
/*     */             }
/*     */           }
/* 229 */           if (k > 0) {
/* 230 */             localQuery.setMaxResults(k);
/* 231 */             localQuery.setFirstResult((m - 1) * 
/* 232 */               k);
/*     */           }
/* 234 */           return localQuery.list();
/*     */         } catch (Exception localException) {
/* 236 */           throw new CoreException(
/* 237 */             "EAPTECH001100", localException
/* 238 */             .getCause(), new String[] { localException
/* 239 */             .getCause().getLocalizedMessage() });
/*     */         }
/*     */       }
/*     */     });
/* 243 */     localQueryResult.setResult(localList);
/* 244 */     if (bool) {
/* 245 */       localQueryResult.setRecordCount(getNamedQueryRecordCount(paramString, 
/* 246 */         paramArrayOfObject));
/*     */     }
/* 248 */     return localQueryResult;
/*     */   }
/*     */ 
/*     */   public int getNamedQueryRecordCount(String paramString, Object[] paramArrayOfObject) {
/* 252 */     Query localQuery = getSession().getNamedQuery(paramString);
/* 253 */     String str1 = localQuery.getQueryString();
/* 254 */     String str2 = "select count(*) " + 
/* 255 */       str1.replaceAll("(?i)fetch", "");
/* 256 */     return ((Long)getHibernateTemplate().find(str2, paramArrayOfObject).get(
/* 257 */       0)).intValue();
/*     */   }
/*     */ 
/*     */   public QueryResult findByStatement(String paramString, Map paramMap) {
/* 261 */     return super.queryByStatement(paramString, paramMap);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.common.dao.impl.CommonDAOImpl
 * JD-Core Version:    0.6.2
 */