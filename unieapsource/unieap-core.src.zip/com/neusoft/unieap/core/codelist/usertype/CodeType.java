package com.neusoft.unieap.core.codelist.usertype;

public abstract interface CodeType
{
  public abstract String getCode();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.codelist.usertype.CodeType
 * JD-Core Version:    0.6.2
 */