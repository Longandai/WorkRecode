/*    */ package com.neusoft.unieap.core.listener;
/*    */ 
/*    */ import com.neusoft.unieap.core.protection.Protection;
/*    */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*    */ import com.neusoft.unieap.platform.protection.ProtectionCheck;
/*    */ import java.io.File;
/*    */ import javax.servlet.ServletContext;
/*    */ import org.springframework.web.context.ConfigurableWebApplicationContext;
/*    */ 
/*    */ public class ContextLoader extends org.springframework.web.context.ContextLoader
/*    */ {
/*    */   protected void customizeContext(ServletContext paramServletContext, ConfigurableWebApplicationContext paramConfigurableWebApplicationContext)
/*    */   {
/* 20 */     String str = File.separator + "WEB-INF" + File.separator + 
/* 21 */       "conf" + File.separator + "unieap" + File.separator + 
/* 22 */       "license";
/* 23 */     I18nGlobalContext.getInstance().setServletContext(paramServletContext);
/*    */ 
/* 25 */     ProtectionCheck.getInstance().init(paramServletContext.getRealPath(str));
/*    */ 
/* 33 */     Protection.startCheckThread();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.listener.ContextLoader
 * JD-Core Version:    0.6.2
 */