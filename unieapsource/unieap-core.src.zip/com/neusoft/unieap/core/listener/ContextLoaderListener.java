/*    */ package com.neusoft.unieap.core.listener;
/*    */ 
/*    */ import com.neusoft.unieap.platform.protection.CheckThread;
/*    */ import com.neusoft.unieap.platform.protection.ProtectionCheck;
/*    */ import javax.servlet.ServletContextEvent;
/*    */ 
/*    */ public class ContextLoaderListener extends org.springframework.web.context.ContextLoaderListener
/*    */ {
/*    */   protected ContextLoader createContextLoader()
/*    */   {
/* 13 */     return new ContextLoader();
/*    */   }
/*    */ 
/*    */   public void contextDestroyed(ServletContextEvent paramServletContextEvent)
/*    */   {
/* 19 */     super.contextDestroyed(paramServletContextEvent);
/* 20 */     CheckThread localCheckThread = ProtectionCheck.getInstance().getCheckThread();
/* 21 */     if (localCheckThread != null)
/* 22 */       localCheckThread.cancel();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.listener.ContextLoaderListener
 * JD-Core Version:    0.6.2
 */