/*    */ package com.neusoft.unieap.core.statement;
/*    */ 
/*    */ import com.neusoft.unieap.core.statement.impl.StatementDescriptorManagerImpl;
/*    */ 
/*    */ public final class StatementDescriptorManagerFactory
/*    */ {
/*  9 */   private static StatementDescriptorManager statementDescriptorManager = new StatementDescriptorManagerImpl();
/*    */ 
/*    */   public static StatementDescriptorManager getStatementDescriptorManager()
/*    */   {
/* 16 */     return statementDescriptorManager;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.StatementDescriptorManagerFactory
 * JD-Core Version:    0.6.2
 */