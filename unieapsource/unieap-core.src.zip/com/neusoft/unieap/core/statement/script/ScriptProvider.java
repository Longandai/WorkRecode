package com.neusoft.unieap.core.statement.script;

import java.util.Map;

public abstract interface ScriptProvider
{
  public abstract String execute(String paramString, Map paramMap)
    throws Throwable;

  public abstract void release();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.script.ScriptProvider
 * JD-Core Version:    0.6.2
 */