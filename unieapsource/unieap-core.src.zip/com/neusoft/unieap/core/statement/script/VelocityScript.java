/*    */ package com.neusoft.unieap.core.statement.script;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.VelocityUtil;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import org.apache.velocity.VelocityContext;
/*    */ 
/*    */ public class VelocityScript
/*    */   implements ScriptProvider
/*    */ {
/*    */   public String execute(String paramString, Map paramMap)
/*    */     throws Throwable
/*    */   {
/* 15 */     VelocityContext localVelocityContext = VelocityUtil.getContext();
/* 16 */     Iterator localIterator = paramMap.entrySet().iterator();
/* 17 */     while (localIterator.hasNext()) {
/* 18 */       Map.Entry localEntry = (Map.Entry)localIterator.next();
/* 19 */       Object localObject1 = localEntry.getKey();
/* 20 */       Object localObject2 = localEntry.getValue();
/* 21 */       localVelocityContext.put((String)localObject1, localObject2);
/*    */     }
/* 23 */     return VelocityUtil.evaluateString(VelocityUtil.getEngine(), localVelocityContext, 
/* 24 */       paramString);
/*    */   }
/*    */ 
/*    */   public void release()
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.script.VelocityScript
 * JD-Core Version:    0.6.2
 */