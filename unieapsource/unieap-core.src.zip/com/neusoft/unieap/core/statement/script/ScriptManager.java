/*    */ package com.neusoft.unieap.core.statement.script;
/*    */ 
/*    */ import com.neusoft.unieap.core.statement.StatementConfig;
/*    */ import com.neusoft.unieap.core.statement.util.StringUtil;
/*    */ import java.util.Collection;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ 
/*    */ public final class ScriptManager
/*    */ {
/* 11 */   private static Map scripts = new HashMap();
/*    */   public static final String SCRIPT_VELOCITY = "velocity";
/*    */ 
/*    */   static
/*    */   {
/* 14 */     scripts.put("velocity", new VelocityScript());
/*    */   }
/*    */ 
/*    */   public static String execute(String paramString1, String paramString2, Map paramMap)
/*    */   {
/* 22 */     ScriptProvider localScriptProvider = (ScriptProvider)scripts.get(
/* 23 */       StringUtil.getString(paramString1, StatementConfig.defaultScript));
/* 24 */     String str = "";
/*    */     try {
/* 26 */       str = localScriptProvider.execute(paramString2, paramMap);
/*    */     } catch (Throwable localThrowable) {
/* 28 */       localThrowable.printStackTrace();
/*    */     }
/* 30 */     return str;
/*    */   }
/*    */ 
/*    */   public static void release() {
/* 34 */     Iterator localIterator = scripts.values().iterator();
/* 35 */     while (localIterator.hasNext())
/* 36 */       ((ScriptProvider)localIterator.next()).release();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.script.ScriptManager
 * JD-Core Version:    0.6.2
 */