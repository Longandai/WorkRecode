/*    */ package com.neusoft.unieap.core.statement.util;
/*    */ 
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public final class DateUtil
/*    */ {
/*    */   public static final String DEFAULT_FORMAT_DATE = "yyyy-MM-dd";
/*    */   public static final String DEFAULT_FORMAT_TIME = "HH:mm:ss.SSS";
/*    */   public static final String DEFAULT_FORMAT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS";
/*    */   public static final String DEFAULT_FORMAT = "yyyy-MM-dd HH:mm:ss";
/*    */ 
/*    */   public static String formatDate(long paramLong)
/*    */   {
/* 20 */     return formatDate(paramLong, "yyyy-MM-dd HH:mm:ss");
/*    */   }
/*    */ 
/*    */   public static Date parseDate(String paramString) {
/* 24 */     return parseDate(paramString, "yyyy-MM-dd HH:mm:ss");
/*    */   }
/*    */ 
/*    */   public static Date parseDate(String paramString1, String paramString2) {
/* 28 */     if (paramString2 == null) {
/* 29 */       paramString2 = "yyyy-MM-dd HH:mm:ss";
/*    */     }
/* 31 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString2, Locale.US);
/*    */     try {
/* 33 */       return localSimpleDateFormat.parse(paramString1);
/*    */     } catch (Exception localException) {
/* 35 */       throw new RuntimeException(localException);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static String formatDate(long paramLong, String paramString) {
/* 40 */     Date localDate = new Date(paramLong);
/* 41 */     if (paramString == null) {
/* 42 */       paramString = "yyyy-MM-dd HH:mm:ss";
/*    */     }
/* 44 */     SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat(paramString, Locale.US);
/* 45 */     return localSimpleDateFormat.format(localDate);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.util.DateUtil
 * JD-Core Version:    0.6.2
 */