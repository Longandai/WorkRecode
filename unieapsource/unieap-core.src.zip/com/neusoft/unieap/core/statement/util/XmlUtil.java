/*     */ package com.neusoft.unieap.core.statement.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.dom4j.Branch;
/*     */ import org.dom4j.Document;
/*     */ import org.dom4j.DocumentException;
/*     */ import org.dom4j.DocumentHelper;
/*     */ import org.dom4j.Element;
/*     */ import org.dom4j.io.OutputFormat;
/*     */ import org.dom4j.io.SAXReader;
/*     */ import org.dom4j.io.XMLWriter;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public final class XmlUtil
/*     */ {
/*     */   private static final String ENCODING = "UTF-8";
/*     */ 
/*     */   public static Document createDocument()
/*     */   {
/*  37 */     return DocumentHelper.createDocument();
/*     */   }
/*     */ 
/*     */   public static Document createDocument(String paramString) throws DocumentException {
/*  41 */     return createDocument(new StringReader(paramString));
/*     */   }
/*     */ 
/*     */   public static Document createDocument(Reader paramReader) throws DocumentException
/*     */   {
/*  46 */     return createDocument(paramReader, false, null);
/*     */   }
/*     */ 
/*     */   public static Document createDocument(Reader paramReader, boolean paramBoolean, String paramString) throws DocumentException
/*     */   {
/*  51 */     SAXReader localSAXReader = new SAXReader(paramBoolean);
/*  52 */     return localSAXReader.read(paramReader, paramString);
/*     */   }
/*     */ 
/*     */   public static Document createDocument(InputStream paramInputStream, boolean paramBoolean, String paramString) throws DocumentException
/*     */   {
/*  57 */     SAXReader localSAXReader = new SAXReader(paramBoolean);
/*  58 */     return localSAXReader.read(paramInputStream, paramString);
/*     */   }
/*     */ 
/*     */   public static Document createDocument(URL paramURL, boolean paramBoolean) throws DocumentException
/*     */   {
/*  63 */     SAXReader localSAXReader = new SAXReader(paramBoolean);
/*  64 */     return localSAXReader.read(paramURL);
/*     */   }
/*     */ 
/*     */   public static Document createDocument(InputSource paramInputSource, boolean paramBoolean) throws DocumentException
/*     */   {
/*  69 */     SAXReader localSAXReader = new SAXReader(paramBoolean);
/*  70 */     return localSAXReader.read(paramInputSource);
/*     */   }
/*     */ 
/*     */   public static Document createDocument(File paramFile, boolean paramBoolean) throws DocumentException
/*     */   {
/*  75 */     SAXReader localSAXReader = new SAXReader(paramBoolean);
/*  76 */     return localSAXReader.read(paramFile);
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, Object paramObject)
/*     */   {
/*  83 */     if (paramObject != null)
/*  84 */       addAttribute(paramElement, paramString, paramObject.toString());
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, Date paramDate)
/*     */   {
/*  89 */     if (paramDate != null)
/*  90 */       addAttribute(paramElement, paramString, DateUtil.formatDate(paramDate
/*  91 */         .getTime()));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, int paramInt)
/*     */   {
/*  96 */     addAttribute(paramElement, paramString, String.valueOf(paramInt));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, boolean paramBoolean) {
/* 100 */     addAttribute(paramElement, paramString, String.valueOf(paramBoolean));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 105 */     if (paramBoolean2 != paramBoolean1)
/* 106 */       addAttribute(paramElement, paramString, String.valueOf(paramBoolean1));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, double paramDouble)
/*     */   {
/* 111 */     addAttribute(paramElement, paramString, String.valueOf(paramDouble));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString, long paramLong) {
/* 115 */     addAttribute(paramElement, paramString, String.valueOf(paramLong));
/*     */   }
/*     */ 
/*     */   public static void addAttribute(Element paramElement, String paramString1, String paramString2) {
/* 119 */     if ((paramElement != null) && (paramString1 != null) && (paramString2 != null))
/* 120 */       paramElement.addAttribute(paramString1, paramString2);
/*     */   }
/*     */ 
/*     */   public static int getAttribute(Element paramElement, String paramString, int paramInt)
/*     */   {
/* 126 */     return 
/* 127 */       StringUtil.getInteger(paramElement.attributeValue(paramString), paramInt);
/*     */   }
/*     */ 
/*     */   public static long getAttribute(Element paramElement, String paramString, long paramLong)
/*     */   {
/* 132 */     return StringUtil.getLong(paramElement.attributeValue(paramString), paramLong);
/*     */   }
/*     */ 
/*     */   public static String getAttribute(Element paramElement, String paramString1, String paramString2)
/*     */   {
/* 137 */     return StringUtil.getString(paramElement.attributeValue(paramString1), paramString2);
/*     */   }
/*     */ 
/*     */   public static double getAttribute(Element paramElement, String paramString, double paramDouble)
/*     */   {
/* 142 */     return StringUtil.getDouble(paramElement.attributeValue(paramString), paramDouble);
/*     */   }
/*     */ 
/*     */   public static boolean getAttribute(Element paramElement, String paramString, boolean paramBoolean)
/*     */   {
/* 147 */     return 
/* 148 */       StringUtil.getBoolean(paramElement.attributeValue(paramString), paramBoolean);
/*     */   }
/*     */ 
/*     */   public static Element addElement(Branch paramBranch, String paramString)
/*     */   {
/* 155 */     return paramBranch.addElement(paramString);
/*     */   }
/*     */ 
/*     */   public static Element addElement(Branch paramBranch, String paramString, Object paramObject) {
/* 159 */     return addElement(paramBranch, paramString, paramObject == null ? "" : paramObject.toString());
/*     */   }
/*     */ 
/*     */   public static Element addElement(Branch paramBranch, String paramString1, String paramString2) {
/* 163 */     if ((paramString1 != null) && (!paramString1.equals("")) && (paramString2 != null)) {
/* 164 */       Element localElement = paramBranch.addElement(paramString1);
/* 165 */       localElement.setText(paramString2);
/* 166 */       return localElement;
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public static void setText(Branch paramBranch, String paramString)
/*     */   {
/* 173 */     if (paramString != null)
/* 174 */       paramBranch.setText(paramString);
/*     */   }
/*     */ 
/*     */   public static void setCDATA(Element paramElement, Object paramObject)
/*     */   {
/* 179 */     if (paramObject != null)
/* 180 */       paramElement.addCDATA(paramObject.toString());
/*     */   }
/*     */ 
/*     */   public static void setCDATA(Element paramElement, byte[] paramArrayOfByte)
/*     */   {
/* 185 */     if (paramArrayOfByte != null)
/* 186 */       paramElement.addCDATA(new String(paramArrayOfByte));
/*     */   }
/*     */ 
/*     */   public static void setCDATA(Element paramElement, String paramString)
/*     */   {
/* 191 */     if (paramString != null)
/* 192 */       paramElement.addCDATA(paramString);
/*     */   }
/*     */ 
/*     */   public static void setCDATA(Branch paramBranch, String paramString1, String paramString2)
/*     */   {
/* 197 */     if (paramString2 != null) {
/* 198 */       Element localElement = paramBranch.addElement(paramString1);
/* 199 */       localElement.addCDATA(paramString2);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addObject(Branch paramBranch, String paramString, Object paramObject) throws Exception
/*     */   {
/* 205 */     if (paramObject != null) {
/* 206 */       Element localElement = paramBranch.addElement(paramString);
/* 207 */       addObject(localElement, paramObject);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void addObject(Branch paramBranch, Object paramObject) throws Exception {
/* 212 */     if (paramObject != null)
/*     */     {
/*     */       Object localObject1;
/*     */       int i;
/*     */       Object localObject2;
/* 213 */       if ((paramObject instanceof List)) {
/* 214 */         localObject1 = (List)paramObject;
/* 215 */         for (i = 0; i < ((List)localObject1).size(); i++) {
/* 216 */           localObject2 = ((List)localObject1).get(i);
/* 217 */           addElement(paramBranch, "list-item", localObject2);
/*     */         }
/* 219 */       } else if ((paramObject instanceof Object[])) {
/* 220 */         localObject1 = (Object[])paramObject;
/* 221 */         for (i = 0; i < localObject1.length; i++) {
/* 222 */           localObject2 = localObject1[i];
/* 223 */           addElement(paramBranch, "array-item", localObject2);
/*     */         }
/* 225 */       } else if ((paramObject instanceof Map)) {
/* 226 */         localObject1 = (Map)paramObject;
/*     */ 
/* 228 */         Iterator localIterator = ((Map)localObject1).entrySet().iterator();
/* 229 */         while (localIterator.hasNext()) {
/* 230 */           localObject2 = (Map.Entry)localIterator.next();
/* 231 */           Object localObject3 = ((Map.Entry)localObject2).getKey();
/* 232 */           Object localObject4 = ((Map.Entry)localObject2).getValue();
/* 233 */           Element localElement = addElement(paramBranch, "map-item", localObject4);
/* 234 */           addAttribute(localElement, "name", localObject3);
/*     */         }
/*     */       }
/* 237 */       setCDATA((Element)paramBranch, paramObject.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String print(Document paramDocument)
/*     */     throws IOException
/*     */   {
/* 247 */     return print(paramDocument, "UTF-8", true);
/*     */   }
/*     */ 
/*     */   public static String print(Document paramDocument, String paramString, boolean paramBoolean) throws IOException
/*     */   {
/* 252 */     StringWriter localStringWriter = new StringWriter();
/*     */     try
/*     */     {
/* 255 */       print(paramDocument, localStringWriter, paramString, paramBoolean);
/* 256 */       return localStringWriter.toString();
/*     */     } finally {
/* 258 */       localStringWriter.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void print(Document paramDocument, Writer paramWriter) throws IOException {
/* 263 */     print(paramDocument, paramWriter, "UTF-8", true);
/*     */   }
/*     */ 
/*     */   public static void print(Document paramDocument, Writer paramWriter, String paramString, boolean paramBoolean) throws IOException
/*     */   {
/* 268 */     OutputFormat localOutputFormat = OutputFormat.createPrettyPrint();
/* 269 */     localOutputFormat.setEncoding(paramString);
/* 270 */     localOutputFormat.setIndent("\t");
/* 271 */     localOutputFormat.setSuppressDeclaration(paramBoolean);
/* 272 */     print(paramDocument, paramWriter, localOutputFormat);
/*     */   }
/*     */ 
/*     */   public static void print(Document paramDocument, Writer paramWriter, OutputFormat paramOutputFormat) throws IOException
/*     */   {
/* 277 */     XMLWriter localXMLWriter = new XMLWriter(paramWriter, paramOutputFormat);
/* 278 */     localXMLWriter.write(paramDocument);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.util.XmlUtil
 * JD-Core Version:    0.6.2
 */