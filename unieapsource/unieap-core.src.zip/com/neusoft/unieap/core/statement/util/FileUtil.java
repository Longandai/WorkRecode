/*    */ package com.neusoft.unieap.core.statement.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*    */ import java.io.File;
/*    */ import javax.servlet.ServletContext;
/*    */ 
/*    */ public final class FileUtil
/*    */ {
/*    */   public static File getFile(String paramString1, String paramString2, String paramString3)
/*    */   {
/* 21 */     String str = I18nGlobalContext.getInstance().getServletContext()
/* 22 */       .getRealPath(File.separator);
/* 23 */     File localFile = new File((str.endsWith(File.separator) ? str : 
/* 24 */       new StringBuilder(String.valueOf(str)).append(File.separator).toString()) + 
/* 25 */       "WEB-INF" + 
/* 26 */       File.separator + 
/* 27 */       "conf" + 
/* 28 */       File.separator + 
/* 29 */       paramString1 + 
/* 30 */       File.separator + 
/* 31 */       paramString2 + 
/* 32 */       File.separator + 
/* 33 */       "statement" + 
/* 34 */       File.separator + paramString3 + ".xml");
/* 35 */     if (!localFile.exists()) {
/* 36 */       String[] arrayOfString = paramString3.split(File.separatorChar == '\\' ? "\\\\" : 
/* 37 */         File.separator);
/* 38 */       throw new UniEAPBusinessException("EAPTECH002020", 
/* 39 */         new Object[] { arrayOfString[(arrayOfString.length - 1)] + ".xml" });
/*    */     }
/* 41 */     return localFile;
/*    */   }
/*    */ 
/*    */   public static File getFile(String paramString)
/*    */   {
/* 51 */     String str = I18nGlobalContext.getInstance().getServletContext()
/* 52 */       .getRealPath(File.separator);
/* 53 */     File localFile = new File((str.endsWith(File.separator) ? str : 
/* 54 */       new StringBuilder(String.valueOf(str)).append(File.separator).toString()) + 
/* 55 */       "WEB-INF" + 
/* 56 */       File.separator + 
/* 57 */       "conf" + 
/* 58 */       File.separator + 
/* 59 */       paramString.replace("/", File.separator));
/* 60 */     if (!localFile.exists()) {
/* 61 */       String[] arrayOfString = paramString.split(File.separatorChar == '\\' ? "\\\\" : 
/* 62 */         File.separator);
/* 63 */       throw new UniEAPBusinessException("EAPTECH002020", 
/* 64 */         new Object[] { arrayOfString[(arrayOfString.length - 1)] });
/*    */     }
/* 66 */     return localFile;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.util.FileUtil
 * JD-Core Version:    0.6.2
 */