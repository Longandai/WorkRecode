/*     */ package com.neusoft.unieap.core.statement.util;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import org.apache.commons.lang.StringUtils;
/*     */ 
/*     */ public final class StringUtil extends StringUtils
/*     */ {
/*     */   public static String printException(Throwable paramThrowable)
/*     */   {
/*  11 */     StringWriter localStringWriter = new StringWriter();
/*  12 */     PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
/*     */     try
/*     */     {
/*  15 */       paramThrowable.printStackTrace(localPrintWriter);
/*  16 */       return localStringWriter.getBuffer().toString();
/*     */     } finally {
/*  18 */       localPrintWriter.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String escapeSqlLike(String paramString1, String paramString2) {
/*  23 */     if ((paramString2 != null) && (paramString1 != null)) {
/*  24 */       paramString1 = replace(paramString1, "_", "/_");
/*  25 */       paramString1 = replace(paramString1, "%", "/%");
/*  26 */       paramString1 = replace(paramString1, "?", "_");
/*  27 */       paramString1 = replace(paramString1, "*", "%");
/*     */     }
/*     */ 
/*  30 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public static String escapeSqlWhere(String paramString1, String paramString2) {
/*  34 */     if (paramString2 != null) {
/*  35 */       return paramString1 + " escape '" + paramString2 + "'";
/*     */     }
/*  37 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public static String[] getStringArray(String paramString, String[] paramArrayOfString)
/*     */   {
/*  45 */     if ((paramString == null) || (paramString.equals(""))) {
/*  46 */       return paramArrayOfString;
/*     */     }
/*     */ 
/*  50 */     return paramArrayOfString;
/*     */   }
/*     */ 
/*     */   public static String getString(String paramString1, String paramString2)
/*     */   {
/*  55 */     if ((paramString1 == null) || (paramString1.equals(""))) {
/*  56 */       return paramString2;
/*     */     }
/*  58 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public static int getInteger(String paramString, int paramInt)
/*     */   {
/*  63 */     if ((paramString == null) || (paramString.equals(""))) {
/*  64 */       return paramInt;
/*     */     }
/*  66 */     return Integer.parseInt(paramString);
/*     */   }
/*     */ 
/*     */   public static long getLong(String paramString, long paramLong)
/*     */   {
/*  71 */     if ((paramString == null) || (paramString.equals(""))) {
/*  72 */       return paramLong;
/*     */     }
/*  74 */     return Long.parseLong(paramString);
/*     */   }
/*     */ 
/*     */   public static double getDouble(String paramString, double paramDouble)
/*     */   {
/*  79 */     if ((paramString == null) || (paramString.equals(""))) {
/*  80 */       return paramDouble;
/*     */     }
/*  82 */     return Double.parseDouble(paramString);
/*     */   }
/*     */ 
/*     */   public static boolean getBoolean(String paramString, boolean paramBoolean)
/*     */   {
/*  87 */     if ((paramString == null) || (paramString.equals(""))) {
/*  88 */       return paramBoolean;
/*     */     }
/*  90 */     return paramString.equalsIgnoreCase(Boolean.TRUE.toString());
/*     */   }
/*     */ 
/*     */   public static boolean hasText(String paramString)
/*     */   {
/*     */     int i;
/*  96 */     if ((paramString == null) || ((i = paramString.length()) == 0)) {
/*  97 */       return false;
/*     */     }
/*  99 */     for (int j = 0; j < i; j++) {
/* 100 */       if (!Character.isWhitespace(paramString.charAt(j))) {
/* 101 */         return true;
/*     */       }
/*     */     }
/* 104 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean hasLength(String paramString) {
/* 108 */     return (paramString != null) && (paramString.length() > 0);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.util.StringUtil
 * JD-Core Version:    0.6.2
 */