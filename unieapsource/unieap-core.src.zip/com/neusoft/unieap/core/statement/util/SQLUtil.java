/*    */ package com.neusoft.unieap.core.statement.util;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public final class SQLUtil
/*    */ {
/*    */   public static final String SQL_KEYWORD_SELECT = "select";
/*    */   public static final String SQL_KEYWORD_DISTINCT = "distinct";
/*    */   public static final String SQL_KEYWORD_FROM = "from";
/*    */   public static final String SQL_KEYWORD_WHERE = "where";
/*    */   public static final String SQL_KEYWORD_ORDERBY = "order by";
/*    */   public static final String SQL_KEYWORD_GROUPBY = "group by";
/*    */   public static final String SQL_KEYWORD_HAVING = "having";
/*    */   public static final String SQL_KEYWORD_AND = "and";
/*    */   public static final String SQL_KEYWORD_OR = "or";
/*    */   public static final String SQL_KEYWORD_UPDATE = "update";
/*    */   public static final String SQL_KEYWORD_INSERT = "insert into";
/*    */   public static final String SQL_KEYWORD_DELETE = "delete from";
/*    */   public static final String SQL_KEYWORD_SET = "set";
/*    */   public static final String SQL_KEYWORD_VALUES = "values";
/*    */   public static final String SQL_KEYWORD_TRUNCATE = "truncate";
/*    */   public static final int TYPE_UNKNOWN = 0;
/*    */   public static final int TYPE_SELECT = 1;
/*    */   public static final int TYPE_INSERT = 2;
/*    */   public static final int TYPE_UPDATE = 3;
/*    */   public static final int TYPE_DELETE = 4;
/*    */   public static final int TYPE_LOB = 5;
/*    */   public static final int TYPE_PROCEDURE = 6;
/*    */   public static final int TYPE_TRUNCATE = 7;
/*    */ 
/*    */   public static String join(List paramList)
/*    */   {
/* 53 */     if (paramList.size() == 1) {
/* 54 */       return (String)paramList.get(0);
/*    */     }
/* 56 */     StringBuffer localStringBuffer = new StringBuffer();
/* 57 */     int i = 0; for (int j = paramList.size(); i < j; i++) {
/* 58 */       if (i > 0) {
/* 59 */         localStringBuffer.append(", ");
/*    */       }
/* 61 */       localStringBuffer.append(paramList.get(i));
/*    */     }
/*    */ 
/* 64 */     return localStringBuffer.toString();
/*    */   }
/*    */ 
/*    */   public static int getType(String paramString)
/*    */   {
/* 69 */     String str = paramString.toLowerCase();
/*    */ 
/* 71 */     if (str.startsWith("delete from"))
/* 72 */       return 4;
/* 73 */     if (str.startsWith("insert into"))
/* 74 */       return 2;
/* 75 */     if ((str.startsWith("update")) && 
/* 76 */       (str.indexOf("set") > 0))
/* 77 */       return 3;
/* 78 */     if ((str.startsWith("select")) && 
/* 79 */       (str.indexOf("from") > 0))
/* 80 */       return 1;
/* 81 */     if (str.startsWith("truncate")) {
/* 82 */       return 7;
/*    */     }
/* 84 */     return 6;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.util.SQLUtil
 * JD-Core Version:    0.6.2
 */