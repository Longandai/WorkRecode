/*    */ package com.neusoft.unieap.core.statement.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.statement.StatementConfig;
/*    */ import com.neusoft.unieap.core.statement.StatementDescriptor;
/*    */ import com.neusoft.unieap.core.statement.StatementDescriptorManager;
/*    */ import com.neusoft.unieap.core.statement.script.ScriptManager;
/*    */ import com.neusoft.unieap.core.statement.util.FileUtil;
/*    */ import java.io.File;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.collections.map.LRUMap;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class StatementDescriptorManagerImpl
/*    */   implements StatementDescriptorManager
/*    */ {
/*    */   private static LRUMap descriptors;
/* 20 */   private boolean checkReload = true;
/*    */ 
/* 22 */   private static final Log logger = LogFactory.getLog(StatementDescriptorManagerImpl.class);
/*    */ 
/*    */   public StatementDescriptorManagerImpl() {
/* 25 */     descriptors = new LRUMap(StatementConfig.cacheSize);
/* 26 */     this.checkReload = StatementConfig.checkReload;
/*    */   }
/*    */ 
/*    */   public String getStatement(StatementDescriptor paramStatementDescriptor, Map paramMap) {
/* 30 */     return ScriptManager.execute(paramStatementDescriptor.getScript(), 
/* 31 */       paramStatementDescriptor.getValue(), paramMap);
/*    */   }
/*    */ 
/*    */   public StatementDescriptor getStatementDescriptor(String paramString)
/*    */   {
/* 42 */     File localFile = FileUtil.getFile(paramString);
/* 43 */     StatementDescriptorImpl localStatementDescriptorImpl = (StatementDescriptorImpl)descriptors
/* 44 */       .get(paramString);
/* 45 */     if ((localStatementDescriptorImpl == null) || (
/* 46 */       (this.checkReload) && (localStatementDescriptorImpl.isModified(localFile
/* 47 */       .lastModified())))) {
/* 48 */       synchronized (descriptors) {
/* 49 */         ScriptManager.release();
/*    */         try {
/* 51 */           localStatementDescriptorImpl = loadFromFile(localFile);
/*    */         } catch (Exception localException) {
/* 53 */           localException.printStackTrace();
/*    */         }
/* 55 */         localStatementDescriptorImpl.setName(paramString);
/* 56 */         descriptors.put(localStatementDescriptorImpl.getName(), localStatementDescriptorImpl);
/*    */       }
/*    */     }
/* 59 */     return localStatementDescriptorImpl;
/*    */   }
/*    */ 
/*    */   private StatementDescriptorImpl loadFromFile(File paramFile)
/*    */     throws Exception
/*    */   {
/* 71 */     Digester localDigester = new Digester();
/* 72 */     localDigester.setUseContextClassLoader(true);
/* 73 */     localDigester.addObjectCreate("statement", StatementDescriptorImpl.class);
/* 74 */     localDigester.addSetProperties("statement");
/* 75 */     localDigester.addCallMethod("statement", "setValue", 1);
/* 76 */     localDigester.addCallParam("statement", 0);
/*    */     try {
/* 78 */       StatementDescriptorImpl localStatementDescriptorImpl = (StatementDescriptorImpl)localDigester
/* 79 */         .parse(paramFile);
/* 80 */       localStatementDescriptorImpl.setLastModified(paramFile.lastModified());
/* 81 */       logger.info("load file " + paramFile.getPath());
/* 82 */       return localStatementDescriptorImpl;
/*    */     } catch (Exception localException) {
/* 84 */       throw localException;
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.impl.StatementDescriptorManagerImpl
 * JD-Core Version:    0.6.2
 */