/*    */ package com.neusoft.unieap.core.statement.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.statement.StatementDescriptor;
/*    */ 
/*    */ public class StatementDescriptorImpl
/*    */   implements StatementDescriptor
/*    */ {
/*    */   private String name;
/*    */   private String script;
/*    */   private String value;
/*    */   private int pageSize;
/*    */   private long lastModified;
/*    */   private String pojo;
/*    */   private String dataSourceID;
/*    */ 
/*    */   public String getName()
/*    */   {
/* 18 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String paramString) {
/* 22 */     this.name = paramString;
/*    */   }
/*    */ 
/*    */   public String getScript() {
/* 26 */     return this.script;
/*    */   }
/*    */ 
/*    */   public void setScript(String paramString) {
/* 30 */     this.script = paramString;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 34 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String paramString) {
/* 38 */     this.value = paramString;
/*    */   }
/*    */ 
/*    */   public long getLastModified() {
/* 42 */     return this.lastModified;
/*    */   }
/*    */ 
/*    */   public boolean isModified(long paramLong) {
/* 46 */     return this.lastModified < paramLong;
/*    */   }
/*    */ 
/*    */   public void setLastModified(long paramLong) {
/* 50 */     this.lastModified = paramLong;
/*    */   }
/*    */ 
/*    */   public int getPageSize() {
/* 54 */     return this.pageSize;
/*    */   }
/*    */ 
/*    */   public void setPageSize(int paramInt) {
/* 58 */     this.pageSize = paramInt;
/*    */   }
/*    */ 
/*    */   public String getPojo() {
/* 62 */     return this.pojo;
/*    */   }
/*    */ 
/*    */   public void setPojo(String paramString) {
/* 66 */     this.pojo = paramString;
/*    */   }
/*    */ 
/*    */   public String getDataSourceID()
/*    */   {
/* 71 */     return this.dataSourceID;
/*    */   }
/*    */ 
/*    */   public void setDataSourceID(String paramString) {
/* 75 */     this.dataSourceID = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.impl.StatementDescriptorImpl
 * JD-Core Version:    0.6.2
 */