/*     */ package com.neusoft.unieap.core.statement.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.statement.Statement;
/*     */ import com.neusoft.unieap.core.statement.StatementConfig;
/*     */ import com.neusoft.unieap.core.statement.StatementDescriptor;
/*     */ import com.neusoft.unieap.core.statement.StatementDescriptorManager;
/*     */ import com.neusoft.unieap.core.statement.StatementDescriptorManagerFactory;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class StatementImpl
/*     */   implements Statement
/*     */ {
/*     */   private String path;
/*     */   private String statement;
/*     */   private String countStatement;
/*  19 */   private Map attributes = new HashMap();
/*  20 */   private StatementDescriptor stmDescriptor = null;
/*  21 */   private static final Log logger = LogFactory.getLog(StatementImpl.class);
/*     */ 
/*     */   public StatementImpl(String paramString) {
/*  24 */     this(paramString, null);
/*     */   }
/*     */ 
/*     */   public StatementImpl(String paramString, Map paramMap) {
/*  28 */     if (paramMap != null)
/*  29 */       this.attributes = paramMap;
/*  30 */     this.path = paramString;
/*     */   }
/*     */ 
/*     */   public String getStatement() {
/*  34 */     if (this.statement == null) {
/*  35 */       this.statement = buildStatement(this.path);
/*     */     }
/*  37 */     return this.statement;
/*     */   }
/*     */ 
/*     */   public String getCountStatement() {
/*  41 */     if (this.statement == null) {
/*  42 */       this.statement = buildStatement(this.path);
/*     */     }
/*  44 */     StringBuffer localStringBuffer = new StringBuffer();
/*  45 */     localStringBuffer.append("select").append(" count(1) ");
/*  46 */     localStringBuffer.append("from").append("(").append(this.statement)
/*  47 */       .append(")");
/*  48 */     this.countStatement = localStringBuffer.toString();
/*  49 */     if (StatementConfig.isDebug)
/*  50 */       logger.info(this.countStatement);
/*  51 */     return this.countStatement;
/*     */   }
/*     */ 
/*     */   public String getPath() {
/*  55 */     return this.path;
/*     */   }
/*     */ 
/*     */   public Map getAttributes() {
/*  59 */     return this.attributes;
/*     */   }
/*     */ 
/*     */   private String buildStatement(String paramString) {
/*  63 */     if ((paramString == null) || ("".equals(paramString.trim())))
/*  64 */       return paramString;
/*  65 */     if ((paramString.startsWith("{")) && (paramString.endsWith("}"))) {
/*  66 */       return paramString.substring(1, paramString.length() - 1);
/*     */     }
/*  68 */     if (this.stmDescriptor == null)
/*  69 */       this.stmDescriptor = 
/*  70 */         StatementDescriptorManagerFactory.getStatementDescriptorManager().getStatementDescriptor(
/*  71 */         paramString);
/*  72 */     String str = 
/*  73 */       StatementDescriptorManagerFactory.getStatementDescriptorManager().getStatement(this.stmDescriptor, 
/*  74 */       this.attributes);
/*  75 */     if (StatementConfig.isDebug)
/*  76 */       logger.info(str);
/*  77 */     return str;
/*     */   }
/*     */ 
/*     */   public void clearAttributes() {
/*  81 */     this.attributes.clear();
/*     */   }
/*     */ 
/*     */   public void addAttributes(Map paramMap)
/*     */   {
/*  86 */     if ((paramMap != null) && (!paramMap.isEmpty()))
/*  87 */       this.attributes.putAll(paramMap);
/*     */   }
/*     */ 
/*     */   public void addAttribute(String paramString, Object paramObject)
/*     */   {
/*  92 */     this.attributes.put(paramString, paramObject);
/*     */   }
/*     */ 
/*     */   public int getPageSize()
/*     */   {
/*  97 */     if (this.stmDescriptor == null)
/*  98 */       this.stmDescriptor = 
/*  99 */         StatementDescriptorManagerFactory.getStatementDescriptorManager().getStatementDescriptor(
/* 100 */         this.path);
/* 101 */     return this.stmDescriptor.getPageSize();
/*     */   }
/*     */ 
/*     */   public String getPojo() {
/* 105 */     if (this.stmDescriptor == null)
/* 106 */       this.stmDescriptor = 
/* 107 */         StatementDescriptorManagerFactory.getStatementDescriptorManager().getStatementDescriptor(
/* 108 */         this.path);
/* 109 */     return this.stmDescriptor.getPojo();
/*     */   }
/*     */ 
/*     */   public String getDataSourceID() {
/* 113 */     if (this.stmDescriptor == null)
/* 114 */       this.stmDescriptor = 
/* 115 */         StatementDescriptorManagerFactory.getStatementDescriptorManager().getStatementDescriptor(
/* 116 */         this.path);
/* 117 */     return this.stmDescriptor.getDataSourceID();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.impl.StatementImpl
 * JD-Core Version:    0.6.2
 */