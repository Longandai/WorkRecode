package com.neusoft.unieap.core.statement;

import java.util.Map;

public abstract interface StatementDescriptorManager
{
  public abstract StatementDescriptor getStatementDescriptor(String paramString);

  public abstract String getStatement(StatementDescriptor paramStatementDescriptor, Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.StatementDescriptorManager
 * JD-Core Version:    0.6.2
 */