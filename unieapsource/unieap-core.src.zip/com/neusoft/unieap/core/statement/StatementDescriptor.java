package com.neusoft.unieap.core.statement;

public abstract interface StatementDescriptor
{
  public abstract String getName();

  public abstract String getScript();

  public abstract int getPageSize();

  public abstract String getValue();

  public abstract String getPojo();

  public abstract String getDataSourceID();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.StatementDescriptor
 * JD-Core Version:    0.6.2
 */