package com.neusoft.unieap.core.statement;

import java.util.Map;

public abstract interface Statement
{
  public static final String SQL_PREFIX = "{";
  public static final String SQL_POSTFIX = "}";

  public abstract String getPath();

  public abstract Map getAttributes();

  public abstract String getStatement();

  public abstract String getCountStatement();

  public abstract void clearAttributes();

  public abstract void addAttributes(Map paramMap);

  public abstract void addAttribute(String paramString, Object paramObject);

  public abstract int getPageSize();

  public abstract String getPojo();

  public abstract String getDataSourceID();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.Statement
 * JD-Core Version:    0.6.2
 */