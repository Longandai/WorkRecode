/*    */ package com.neusoft.unieap.core.statement;
/*    */ 
/*    */ public class StatementConfig
/*    */ {
/*  8 */   public static int cacheSize = 100;
/*  9 */   public static boolean checkReload = true;
/* 10 */   public static String defaultScript = "velocity";
/* 11 */   public static boolean isDebug = false;
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.statement.StatementConfig
 * JD-Core Version:    0.6.2
 */