/*    */ package com.neusoft.unieap.core.variability;
/*    */ 
/*    */ import com.neusoft.unieap.core.variability.context.VarManagerImpl;
/*    */ 
/*    */ public class VarManagerFactory
/*    */ {
/*    */   public static VarManager getVarManager(Class paramClass)
/*    */   {
/* 18 */     return new VarManagerImpl(paramClass);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.VarManagerFactory
 * JD-Core Version:    0.6.2
 */