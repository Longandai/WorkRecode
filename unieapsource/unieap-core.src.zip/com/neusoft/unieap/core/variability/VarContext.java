/*    */ package com.neusoft.unieap.core.variability;
/*    */ 
/*    */ import com.neusoft.unieap.core.variability.context.VarContextSingleton;
/*    */ 
/*    */ public abstract interface VarContext
/*    */ {
/*    */   public static final String SEPERATER = "\\,";
/* 16 */   public static final String VARCONTEXT_SINGLETON_CLASS_PATH = VarContextSingleton.class.getName();
/*    */ 
/*    */   public abstract String getValue(String paramString1, String paramString2, String paramString3, String paramString4);
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.VarContext
 * JD-Core Version:    0.6.2
 */