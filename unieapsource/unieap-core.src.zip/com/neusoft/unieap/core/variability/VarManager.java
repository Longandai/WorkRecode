package com.neusoft.unieap.core.variability;

public abstract interface VarManager
{
  public abstract String getValue(String paramString);

  public abstract void setValue(String paramString1, String paramString2);

  public abstract String getValue(String paramString1, String paramString2);

  public abstract void setValue(String paramString1, String paramString2, String paramString3);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.VarManager
 * JD-Core Version:    0.6.2
 */