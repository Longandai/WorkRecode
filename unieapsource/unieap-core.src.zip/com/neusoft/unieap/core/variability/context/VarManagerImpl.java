/*    */ package com.neusoft.unieap.core.variability.context;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.model.DCRepository;
/*    */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*    */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ import com.neusoft.unieap.core.variability.VarContext;
/*    */ import com.neusoft.unieap.core.variability.VarManager;
/*    */ 
/*    */ public class VarManagerImpl
/*    */   implements VarManager
/*    */ {
/* 17 */   private Class clz = null;
/*    */ 
/*    */   public VarManagerImpl(Class paramClass) {
/* 20 */     this.clz = paramClass;
/*    */   }
/*    */ 
/*    */   public String getValue(String paramString1, String paramString2) {
/* 24 */     DevelopmentComponent localDevelopmentComponent = 
/* 25 */       DCRepository.getDevelopmentComponent(this.clz);
/* 26 */     if (localDevelopmentComponent == null) {
/* 27 */       throw new UniEAPBusinessException(
/* 28 */         "EAPTECH002019", 
/* 29 */         new Object[] { this.clz == null ? null : this.clz });
/*    */     }
/* 31 */     String str1 = localDevelopmentComponent.getSoftwareComponent().getId();
/* 32 */     String str2 = localDevelopmentComponent.getId();
/* 33 */     String str3 = VarContextSingleton.getInstance().getVarContext()
/* 34 */       .getValue(str1, str2, paramString1, paramString2);
/* 35 */     if (str3 == null)
/*    */     {
/* 37 */       str3 = VarContextSingleton.getInstance().getVarContext().getValue(
/* 38 */         str1, "", paramString1, paramString2);
/* 39 */       return str3;
/*    */     }
/* 41 */     return str3;
/*    */   }
/*    */ 
/*    */   public String getValue(String paramString)
/*    */   {
/* 46 */     return null;
/*    */   }
/*    */ 
/*    */   public void setValue(String paramString1, String paramString2)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setValue(String paramString1, String paramString2, String paramString3)
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.context.VarManagerImpl
 * JD-Core Version:    0.6.2
 */