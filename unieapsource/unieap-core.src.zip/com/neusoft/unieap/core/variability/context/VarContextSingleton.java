/*    */ package com.neusoft.unieap.core.variability.context;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPException;
/*    */ import com.neusoft.unieap.core.variability.VarContext;
/*    */ 
/*    */ public final class VarContextSingleton
/*    */ {
/* 17 */   private static VarContextSingleton instance = null;
/*    */ 
/* 19 */   private VarContext varContext = null;
/*    */ 
/*    */   public static synchronized VarContextSingleton getInstance() {
/* 22 */     if (instance == null)
/* 23 */       instance = new VarContextSingleton();
/* 24 */     return instance;
/*    */   }
/*    */ 
/*    */   public VarContext getVarContext() {
/* 28 */     if (this.varContext == null)
/* 29 */       throw new UniEAPException("EAPTECH002008", null);
/* 30 */     return this.varContext;
/*    */   }
/*    */ 
/*    */   public void initVarContext(VarContext paramVarContext)
/*    */   {
/* 37 */     this.varContext = paramVarContext;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.context.VarContextSingleton
 * JD-Core Version:    0.6.2
 */