/*     */ package com.neusoft.unieap.core.variability.context;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import java.io.File;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class CoreVariabilityEntity
/*     */ {
/*  17 */   private int gridPageSize = 18;
/*     */ 
/*  19 */   private boolean validationEnabled = true;
/*     */ 
/*  21 */   private boolean showStack = true;
/*     */ 
/*  23 */   private File uploadFilepath = null;
/*     */ 
/*  25 */   private boolean readTimeFromDB = true;
/*     */ 
/*  27 */   private int defaultTimeStyle = 2;
/*     */ 
/*  29 */   private int defaultDateStyle = 2;
/*     */ 
/*  31 */   private String defaultTimeZone = null;
/*     */ 
/*  33 */   private String defaultLocaleLanguage = null;
/*     */ 
/*  35 */   private boolean globalEnabled = true;
/*     */ 
/*  37 */   private Locale defaultLocale = null;
/*     */ 
/*  39 */   private boolean precheckForInteraction = false;
/*     */ 
/*  41 */   private int maxPageSize = -1;
/*     */   private String supportLocaleLanguage;
/*  45 */   private boolean urlPasswordEncrypt = false;
/*     */   private String databaseCharset;
/*  49 */   private boolean readSkinFromCookie = true;
/*     */ 
/*     */   public String getDatabaseCharset() {
/*  52 */     return this.databaseCharset;
/*     */   }
/*     */ 
/*     */   public void setDatabaseCharset(String paramString) {
/*  56 */     if (paramString == null) {
/*  57 */       paramString = "UTF-8";
/*     */     }
/*  59 */     this.databaseCharset = paramString;
/*     */   }
/*     */ 
/*     */   public boolean isUrlPasswordEncrypt() {
/*  63 */     return this.urlPasswordEncrypt;
/*     */   }
/*     */ 
/*     */   public void setUrlPasswordEncrypt(boolean paramBoolean) {
/*  67 */     this.urlPasswordEncrypt = paramBoolean;
/*     */   }
/*     */ 
/*     */   public String getSupportLocaleLanguage() {
/*  71 */     return this.supportLocaleLanguage;
/*     */   }
/*     */ 
/*     */   public void setSupportLocaleLanguage(String paramString) {
/*  75 */     this.supportLocaleLanguage = paramString;
/*     */   }
/*     */ 
/*     */   public CoreVariabilityEntity() {
/*  79 */     CoreVariability.initVariabilityEntity(this);
/*     */   }
/*     */ 
/*     */   public int getGridPageSize() {
/*  83 */     return this.gridPageSize;
/*     */   }
/*     */ 
/*     */   public void setGridPageSize(int paramInt) {
/*  87 */     this.gridPageSize = paramInt;
/*     */   }
/*     */ 
/*     */   public boolean isValidationEnabled() {
/*  91 */     return this.validationEnabled;
/*     */   }
/*     */ 
/*     */   public void setValidationEnabled(boolean paramBoolean) {
/*  95 */     this.validationEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isShowStack() {
/*  99 */     return this.showStack;
/*     */   }
/*     */ 
/*     */   public void setShowStack(boolean paramBoolean) {
/* 103 */     this.showStack = paramBoolean;
/*     */   }
/*     */ 
/*     */   public File getUploadFilepath() {
/* 107 */     return this.uploadFilepath;
/*     */   }
/*     */ 
/*     */   public void setUploadFilepath(File paramFile) {
/* 111 */     this.uploadFilepath = paramFile;
/*     */   }
/*     */ 
/*     */   public boolean isReadTimeFromDB() {
/* 115 */     return this.readTimeFromDB;
/*     */   }
/*     */ 
/*     */   public void setReadTimeFromDB(boolean paramBoolean) {
/* 119 */     this.readTimeFromDB = paramBoolean;
/*     */   }
/*     */ 
/*     */   public int getDefaultTimeStyle() {
/* 123 */     return this.defaultTimeStyle;
/*     */   }
/*     */ 
/*     */   public void setDefaultTimeStyle(int paramInt) {
/* 127 */     this.defaultTimeStyle = paramInt;
/*     */   }
/*     */ 
/*     */   public int getDefaultDateStyle() {
/* 131 */     return this.defaultDateStyle;
/*     */   }
/*     */ 
/*     */   public void setDefaultDateStyle(int paramInt) {
/* 135 */     this.defaultDateStyle = paramInt;
/*     */   }
/*     */ 
/*     */   public String getDefaultTimeZone() {
/* 139 */     return this.defaultTimeZone;
/*     */   }
/*     */ 
/*     */   public void setDefaultTimeZone(String paramString) {
/* 143 */     this.defaultTimeZone = paramString;
/*     */   }
/*     */ 
/*     */   public String getDefaultLocaleLanguage() {
/* 147 */     return this.defaultLocaleLanguage;
/*     */   }
/*     */ 
/*     */   public void setDefaultLocaleLanguage(String paramString) {
/* 151 */     this.defaultLocaleLanguage = paramString;
/*     */   }
/*     */ 
/*     */   public boolean isGlobalEnabled() {
/* 155 */     return this.globalEnabled;
/*     */   }
/*     */ 
/*     */   public void setGlobalEnabled(boolean paramBoolean) {
/* 159 */     this.globalEnabled = paramBoolean;
/*     */   }
/*     */ 
/*     */   public Locale getDefaultLocale() {
/* 163 */     return this.defaultLocale;
/*     */   }
/*     */ 
/*     */   public void setDefaultLocale(Locale paramLocale) {
/* 167 */     this.defaultLocale = paramLocale;
/*     */   }
/*     */ 
/*     */   public void setLicensePath(File paramFile) {
/* 171 */     com.neusoft.unieap.core.protection.ProtectionConfig.filePath = paramFile.getAbsolutePath();
/*     */   }
/*     */ 
/*     */   public int getMaxPageSize() {
/* 175 */     return this.maxPageSize;
/*     */   }
/*     */ 
/*     */   public void setMaxPageSize(int paramInt) {
/* 179 */     this.maxPageSize = paramInt;
/*     */   }
/*     */ 
/*     */   public void setPrecheckForInteraction(boolean paramBoolean) {
/* 183 */     this.precheckForInteraction = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isPrecheckForInteraction() {
/* 187 */     return this.precheckForInteraction;
/*     */   }
/*     */ 
/*     */   public void setReadSkinFromCookie(boolean paramBoolean) {
/* 191 */     this.readSkinFromCookie = paramBoolean;
/*     */   }
/*     */ 
/*     */   public boolean isReadSkinFromCookie() {
/* 195 */     return this.readSkinFromCookie;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.variability.context.CoreVariabilityEntity
 * JD-Core Version:    0.6.2
 */