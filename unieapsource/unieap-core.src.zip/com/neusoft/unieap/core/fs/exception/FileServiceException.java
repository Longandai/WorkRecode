/*    */ package com.neusoft.unieap.core.fs.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class FileServiceException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public FileServiceException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 10 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public FileServiceException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject) {
/* 14 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public FileServiceException(String paramString) {
/* 18 */     super(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fs.exception.FileServiceException
 * JD-Core Version:    0.6.2
 */