package com.neusoft.unieap.core.fs;

public abstract interface EAPEncryptor
{
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fs.EAPEncryptor
 * JD-Core Version:    0.6.2
 */