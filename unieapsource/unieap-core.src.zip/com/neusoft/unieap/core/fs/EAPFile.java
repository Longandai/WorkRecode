package com.neusoft.unieap.core.fs;

import java.io.Serializable;

public abstract interface EAPFile extends Serializable
{
  public abstract String getName();

  public abstract String getParent();

  public abstract String getPath();

  public abstract boolean isDirectory();

  public abstract boolean isFile();

  public abstract long getLength();

  public abstract long getLastModifiedTime();

  public abstract Object getExtProperty(String paramString);

  public abstract void addExtProperty(String paramString, Object paramObject);

  public abstract Object removeExtProperty(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fs.EAPFile
 * JD-Core Version:    0.6.2
 */