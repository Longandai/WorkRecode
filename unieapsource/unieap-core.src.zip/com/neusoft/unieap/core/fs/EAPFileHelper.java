package com.neusoft.unieap.core.fs;

import java.io.InputStream;

public abstract interface EAPFileHelper
{
  public abstract EAPFileManager getEAPFileManager();

  public abstract void writeFile(InputStream paramInputStream, String paramString, boolean paramBoolean);

  public abstract String encryptPath(String paramString);

  public abstract String decryptPath(String paramString);

  public abstract String getKeyword();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fs.EAPFileHelper
 * JD-Core Version:    0.6.2
 */