package com.neusoft.unieap.core.fs;

import com.neusoft.unieap.core.fs.exception.FileServiceException;
import java.io.InputStream;
import java.io.OutputStream;

public abstract interface EAPFileManager
{
  public abstract OutputStream createFile(String paramString)
    throws FileServiceException;

  public abstract OutputStream createFile(String paramString, boolean paramBoolean)
    throws FileServiceException;

  public abstract boolean createDirectory(String paramString);

  public abstract boolean isFileExists(String paramString);

  public abstract boolean isDirectoryExists(String paramString);

  public abstract boolean deleteFile(String paramString);

  public abstract boolean deleteDirectory(String paramString, boolean paramBoolean);

  public abstract EAPFile[] listFiles(String paramString)
    throws FileServiceException;

  public abstract EAPFile[] listFiles(String paramString, EAPFileFilter paramEAPFileFilter)
    throws FileServiceException;

  public abstract boolean renameFile(String paramString1, String paramString2);

  public abstract boolean renameDirectory(String paramString1, String paramString2);

  public abstract InputStream openFile(String paramString)
    throws FileServiceException;

  public abstract EAPFile getEAPFile(String paramString)
    throws FileServiceException;

  public abstract String getFilename(String paramString);

  public abstract EAPFileHelper getEAPFileHelper();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.fs.EAPFileManager
 * JD-Core Version:    0.6.2
 */