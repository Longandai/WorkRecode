/*    */ package com.neusoft.unieap.core.transaction;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class DateContext
/*    */ {
/*    */   private static final String Transaction_Date = "unieap_request_transaction_date";
/*    */   public static final String Transaction_Date_Generated_Insert = "insert";
/*    */   public static final String Transaction_Date_Generated_Update = "update";
/*    */   public static final String Transaction_Date_Generated_Always = "always";
/*    */   private IDateGenerator generator;
/*    */ 
/*    */   public IDateGenerator getGenerator()
/*    */   {
/* 17 */     return this.generator;
/*    */   }
/*    */ 
/*    */   public void setGenerator(IDateGenerator paramIDateGenerator) {
/* 21 */     this.generator = paramIDateGenerator;
/*    */   }
/*    */ 
/*    */   public long getDate() {
/* 25 */     Long localLong = (Long)UnieapRequestContextHolder.getRequestContext().get(
/* 26 */       "unieap_request_transaction_date");
/* 27 */     if (localLong == null) {
/* 28 */       localLong = Long.valueOf(this.generator.getDate());
/* 29 */       UnieapRequestContextHolder.getRequestContext().put(
/* 30 */         "unieap_request_transaction_date", localLong);
/*    */     }
/* 32 */     return localLong.longValue();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.transaction.DateContext
 * JD-Core Version:    0.6.2
 */