/*    */ package com.neusoft.unieap.core.transaction;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.TransactionDate;
/*    */ import com.neusoft.unieap.core.util.BeanUtil;
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.sql.Time;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.apache.commons.beanutils.PropertyUtils;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ 
/*    */ public class TransactionDateUtil
/*    */ {
/*    */   public static List<PropertyDescriptor> getTransactionDateProperties(Object paramObject, String paramString)
/*    */   {
/* 19 */     ArrayList localArrayList = null;
/* 20 */     PropertyDescriptor[] arrayOfPropertyDescriptor1 = 
/* 21 */       PropertyUtils.getPropertyDescriptors(paramObject);
/* 22 */     if ((arrayOfPropertyDescriptor1 != null) && (arrayOfPropertyDescriptor1.length > 0)) {
/* 23 */       for (PropertyDescriptor localPropertyDescriptor : arrayOfPropertyDescriptor1) {
/* 24 */         Method localMethod = localPropertyDescriptor.getWriteMethod();
/* 25 */         if (localMethod != null) {
/* 26 */           TransactionDate localTransactionDate = 
/* 27 */             (TransactionDate)AnnotationUtils.findAnnotation(localMethod, TransactionDate.class);
/* 28 */           if (localTransactionDate != null) {
/* 29 */             String str = localTransactionDate.generated();
/*    */ 
/* 31 */             if ((str
/* 31 */               .equals("always")) || 
/* 32 */               (str.equals(paramString))) {
/* 33 */               if (localArrayList == null) {
/* 34 */                 localArrayList = new ArrayList();
/*    */               }
/* 36 */               localArrayList.add(localPropertyDescriptor);
/*    */             }
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 42 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public static void setTransactionDate(Object paramObject, List<PropertyDescriptor> paramList)
/*    */   {
/* 47 */     long l = ((DateContext)BeanUtil.getBean("dateContext")).getDate();
/* 48 */     for (PropertyDescriptor localPropertyDescriptor : paramList)
/* 49 */       setTransactionDate(paramObject, l, localPropertyDescriptor);
/*    */   }
/*    */ 
/*    */   public static void setTransactionDate(Object paramObject, PropertyDescriptor paramPropertyDescriptor)
/*    */   {
/* 54 */     setTransactionDate(paramObject, ((DateContext)
/* 55 */       BeanUtil.getBean("dateContext")).getDate(), paramPropertyDescriptor);
/*    */   }
/*    */ 
/*    */   public static long getTransactionDate() {
/* 59 */     return ((DateContext)BeanUtil.getBean("dateContext")).getDate();
/*    */   }
/*    */ 
/*    */   private static void setTransactionDate(Object paramObject, long paramLong, PropertyDescriptor paramPropertyDescriptor)
/*    */   {
/* 64 */     Method localMethod = paramPropertyDescriptor.getWriteMethod();
/* 65 */     Class localClass = localMethod.getParameterTypes()[0];
/* 66 */     Object localObject = null;
/* 67 */     if (localClass == java.util.Date.class)
/* 68 */       localObject = new java.util.Date(paramLong);
/* 69 */     else if (localClass == java.sql.Date.class)
/* 70 */       localObject = new java.sql.Date(paramLong);
/* 71 */     else if (localClass == Timestamp.class)
/* 72 */       localObject = new Timestamp(paramLong);
/* 73 */     else if (localClass == Time.class)
/* 74 */       localObject = new Time(paramLong);
/*    */     try
/*    */     {
/* 77 */       localMethod.invoke(paramObject, new Object[] { localObject });
/*    */     } catch (IllegalArgumentException localIllegalArgumentException) {
/* 79 */       localIllegalArgumentException.printStackTrace();
/*    */     } catch (IllegalAccessException localIllegalAccessException) {
/* 81 */       localIllegalAccessException.printStackTrace();
/*    */     } catch (InvocationTargetException localInvocationTargetException) {
/* 83 */       localInvocationTargetException.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.transaction.TransactionDateUtil
 * JD-Core Version:    0.6.2
 */