/*    */ package com.neusoft.unieap.core.transaction;
/*    */ 
/*    */ import java.util.Date;
/*    */ 
/*    */ public class DateGenerator
/*    */   implements IDateGenerator
/*    */ {
/*    */   public long getDate()
/*    */   {
/* 14 */     return new Date().getTime();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.transaction.DateGenerator
 * JD-Core Version:    0.6.2
 */