package com.neusoft.unieap.core.transaction;

public abstract interface IDateGenerator
{
  public abstract long getDate();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.transaction.IDateGenerator
 * JD-Core Version:    0.6.2
 */