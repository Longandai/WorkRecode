package com.neusoft.unieap.core.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Inherited;

@Inherited
public @interface Inject
{
  public abstract boolean required();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.annotation.Inject
 * JD-Core Version:    0.6.2
 */