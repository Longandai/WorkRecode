package com.neusoft.unieap.core.annotation;

import java.lang.annotation.Annotation;

public @interface Label
{
  public abstract String value();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.annotation.Label
 * JD-Core Version:    0.6.2
 */