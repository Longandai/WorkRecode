package com.neusoft.unieap.core.mail;

import org.springframework.mail.MailSender;

public abstract interface MailBO
{
  public abstract void sendMail(Mail paramMail);

  public abstract void sendMail(Mail paramMail, boolean paramBoolean);

  public abstract void sendMail(MailSender paramMailSender, Mail paramMail);

  public abstract void sendMail(MailSender paramMailSender, Mail paramMail, boolean paramBoolean);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.mail.MailBO
 * JD-Core Version:    0.6.2
 */