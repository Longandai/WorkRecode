/*     */ package com.neusoft.unieap.core.mail;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ public class Mail
/*     */ {
/*     */   private String from;
/*     */   private String replyTo;
/*     */   private String[] to;
/*     */   private String[] cc;
/*     */   private String[] bcc;
/*     */   private Date sentDate;
/*     */   private String subject;
/*  46 */   private boolean isHTML = false;
/*     */   private String text;
/*  56 */   private int priority = 0;
/*     */   private List<String> contentIds;
/*     */   private List<File> inlineFiles;
/*     */   private List<String> attachNames;
/*     */   private List<File> attachFiles;
/*     */ 
/*     */   public void setFrom(String paramString)
/*     */   {
/*  79 */     this.from = paramString;
/*     */   }
/*     */ 
/*     */   public String getFrom() {
/*  83 */     return this.from;
/*     */   }
/*     */ 
/*     */   public void setReplyTo(String paramString) {
/*  87 */     this.replyTo = paramString;
/*     */   }
/*     */ 
/*     */   public String getReplyTo() {
/*  91 */     return this.replyTo;
/*     */   }
/*     */ 
/*     */   public void setTo(String paramString) {
/*  95 */     this.to = new String[] { paramString };
/*     */   }
/*     */ 
/*     */   public void setTo(String[] paramArrayOfString) {
/*  99 */     this.to = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   public String[] getTo() {
/* 103 */     return this.to;
/*     */   }
/*     */ 
/*     */   public void setCc(String paramString) {
/* 107 */     this.cc = new String[] { paramString };
/*     */   }
/*     */ 
/*     */   public void setCc(String[] paramArrayOfString) {
/* 111 */     this.cc = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   public String[] getCc() {
/* 115 */     return this.cc;
/*     */   }
/*     */ 
/*     */   public void setBcc(String paramString) {
/* 119 */     this.bcc = new String[] { paramString };
/*     */   }
/*     */ 
/*     */   public void setBcc(String[] paramArrayOfString) {
/* 123 */     this.bcc = paramArrayOfString;
/*     */   }
/*     */ 
/*     */   public String[] getBcc() {
/* 127 */     return this.bcc;
/*     */   }
/*     */ 
/*     */   public void setSentDate(Date paramDate) {
/* 131 */     this.sentDate = paramDate;
/*     */   }
/*     */ 
/*     */   public Date getSentDate() {
/* 135 */     return this.sentDate;
/*     */   }
/*     */ 
/*     */   public void setSubject(String paramString) {
/* 139 */     this.subject = paramString;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 143 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public boolean isHTML() {
/* 147 */     return this.isHTML;
/*     */   }
/*     */ 
/*     */   public void setHTML(boolean paramBoolean) {
/* 151 */     this.isHTML = paramBoolean;
/*     */   }
/*     */ 
/*     */   public String getText() {
/* 155 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void setText(String paramString) {
/* 159 */     this.text = paramString;
/*     */   }
/*     */ 
/*     */   public int getPriority() {
/* 163 */     return this.priority;
/*     */   }
/*     */ 
/*     */   public void setPriority(int paramInt) {
/* 167 */     this.priority = paramInt;
/*     */   }
/*     */ 
/*     */   public void addInline(String paramString, File paramFile)
/*     */   {
/* 177 */     if (getContentIds() == null) {
/* 178 */       this.contentIds = new ArrayList();
/*     */     }
/* 180 */     if (getInlineFiles() == null) {
/* 181 */       this.inlineFiles = new ArrayList();
/*     */     }
/* 183 */     getContentIds().add(paramString);
/* 184 */     getInlineFiles().add(paramFile);
/*     */   }
/*     */ 
/*     */   public void addAttachMent(String paramString, File paramFile)
/*     */   {
/* 194 */     if (getAttachNames() == null) {
/* 195 */       this.attachNames = new ArrayList();
/*     */     }
/* 197 */     if (getAttachFiles() == null) {
/* 198 */       this.attachFiles = new ArrayList();
/*     */     }
/* 200 */     getAttachNames().add(paramString);
/* 201 */     getAttachFiles().add(paramFile);
/*     */   }
/*     */ 
/*     */   public List<String> getContentIds() {
/* 205 */     return this.contentIds;
/*     */   }
/*     */ 
/*     */   public List<File> getInlineFiles() {
/* 209 */     return this.inlineFiles;
/*     */   }
/*     */ 
/*     */   public List<String> getAttachNames() {
/* 213 */     return this.attachNames;
/*     */   }
/*     */ 
/*     */   public List<File> getAttachFiles() {
/* 217 */     return this.attachFiles;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.mail.Mail
 * JD-Core Version:    0.6.2
 */