/*     */ package com.neusoft.unieap.core.validation.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.validation.Valid;
/*     */ import javax.validation.constraints.DecimalMax;
/*     */ import javax.validation.constraints.DecimalMin;
/*     */ import javax.validation.constraints.Digits;
/*     */ import javax.validation.constraints.Future;
/*     */ import javax.validation.constraints.Max;
/*     */ import javax.validation.constraints.Min;
/*     */ import javax.validation.constraints.NotNull;
/*     */ import javax.validation.constraints.Past;
/*     */ import javax.validation.constraints.Pattern;
/*     */ import org.hibernate.validator.constraints.Email;
/*     */ import org.hibernate.validator.constraints.Length;
/*     */ import org.hibernate.validator.constraints.Range;
/*     */ 
/*     */ public class AnnotationParser
/*     */ {
/*     */   public Map<String, Map<String, Map<String, Object>>> getMetadata(String paramString)
/*     */     throws SecurityException, ClassNotFoundException
/*     */   {
/*  37 */     HashMap localHashMap = new HashMap();
/*  38 */     Method[] arrayOfMethod1 = Class.forName(paramString).getDeclaredMethods();
/*  39 */     for (Method localMethod : arrayOfMethod1) {
/*  40 */       Map localMap = constructMethod(localMethod);
/*  41 */       if (!localMap.isEmpty())
/*     */       {
/*  43 */         localHashMap.put(localMethod.getName(), localMap);
/*     */       }
/*     */     }
/*  45 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Map<String, Object>> constructMethod(Method paramMethod)
/*     */   {
/*  55 */     HashMap localHashMap = new HashMap();
/*  56 */     boolean bool = paramMethod.isAnnotationPresent(NotNull.class);
/*     */     Object localObject;
/*  57 */     if (bool) {
/*  58 */       localObject = (NotNull)paramMethod.getAnnotation(NotNull.class);
/*  59 */       localHashMap.put("notNull", 
/*  60 */         constructNotNull((NotNull)localObject));
/*     */     }
/*  62 */     bool = paramMethod.isAnnotationPresent(Length.class);
/*  63 */     if (bool) {
/*  64 */       localObject = (Length)paramMethod.getAnnotation(Length.class);
/*  65 */       localHashMap.put("length", constructLength((Length)localObject));
/*     */     }
/*  67 */     bool = paramMethod.isAnnotationPresent(Max.class);
/*  68 */     if (bool) {
/*  69 */       localObject = (Max)paramMethod.getAnnotation(Max.class);
/*  70 */       localHashMap.put("max", constructMax((Max)localObject));
/*     */     }
/*  72 */     bool = paramMethod.isAnnotationPresent(Min.class);
/*  73 */     if (bool) {
/*  74 */       localObject = (Min)paramMethod.getAnnotation(Min.class);
/*  75 */       localHashMap.put("min", constructMin((Min)localObject));
/*     */     }
/*  77 */     bool = paramMethod.isAnnotationPresent(DecimalMax.class);
/*  78 */     if (bool) {
/*  79 */       localObject = (DecimalMax)paramMethod.getAnnotation(DecimalMax.class);
/*  80 */       localHashMap.put("decimalMax", 
/*  81 */         constructDecimalMax((DecimalMax)localObject));
/*     */     }
/*  83 */     bool = paramMethod.isAnnotationPresent(DecimalMin.class);
/*  84 */     if (bool) {
/*  85 */       localObject = (DecimalMin)paramMethod.getAnnotation(DecimalMin.class);
/*  86 */       localHashMap.put("decimalMin", 
/*  87 */         constructDecimalMin((DecimalMin)localObject));
/*     */     }
/*  89 */     bool = paramMethod.isAnnotationPresent(Past.class);
/*  90 */     if (bool) {
/*  91 */       localObject = (Past)paramMethod.getAnnotation(Past.class);
/*  92 */       localHashMap.put("past", constructPast((Past)localObject));
/*     */     }
/*  94 */     bool = paramMethod.isAnnotationPresent(Future.class);
/*  95 */     if (bool) {
/*  96 */       localObject = (Future)paramMethod.getAnnotation(Future.class);
/*  97 */       localHashMap.put("future", constructFuture((Future)localObject));
/*     */     }
/*  99 */     bool = paramMethod.isAnnotationPresent(Email.class);
/* 100 */     if (bool) {
/* 101 */       localObject = (Email)paramMethod.getAnnotation(Email.class);
/* 102 */       localHashMap.put("email", constructEmail((Email)localObject));
/*     */     }
/* 104 */     bool = paramMethod.isAnnotationPresent(Valid.class);
/* 105 */     if (bool) {
/* 106 */       localObject = (Valid)paramMethod.getAnnotation(Valid.class);
/* 107 */       localHashMap.put("valid", constructValid((Valid)localObject));
/*     */     }
/* 109 */     bool = paramMethod.isAnnotationPresent(Pattern.class);
/* 110 */     if (bool) {
/* 111 */       localObject = (Pattern)paramMethod.getAnnotation(Pattern.class);
/* 112 */       localHashMap.put("pattern", 
/* 113 */         constructPattern((Pattern)localObject));
/*     */     }
/* 115 */     bool = paramMethod.isAnnotationPresent(Range.class);
/* 116 */     if (bool) {
/* 117 */       localObject = (Range)paramMethod.getAnnotation(Range.class);
/* 118 */       localHashMap.put("range", constructRange((Range)localObject));
/*     */     }
/* 120 */     bool = paramMethod.isAnnotationPresent(Digits.class);
/* 121 */     if (bool) {
/* 122 */       localObject = (Digits)paramMethod.getAnnotation(Digits.class);
/* 123 */       localHashMap.put("digits", constructDigits((Digits)localObject));
/*     */     }
/* 125 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructNotNull(NotNull paramNotNull)
/*     */   {
/* 133 */     HashMap localHashMap = new HashMap();
/* 134 */     localHashMap.put("prompts", Messages.getString(paramNotNull.message(), null, null));
/* 135 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructLength(Length paramLength)
/*     */   {
/* 143 */     HashMap localHashMap = new HashMap();
/* 144 */     localHashMap.put("max", Integer.valueOf(paramLength.max()));
/* 145 */     localHashMap.put("min", Integer.valueOf(paramLength.min()));
/* 146 */     localHashMap.put("prompts", Messages.getString(paramLength.message(), paramLength.min(), paramLength.max()));
/* 147 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructMax(Max paramMax)
/*     */   {
/* 155 */     HashMap localHashMap = new HashMap();
/* 156 */     localHashMap.put("value", Long.valueOf(paramMax.value()));
/* 157 */     localHashMap.put("prompts", Messages.getString(paramMax.message(), paramMax.value(), null));
/* 158 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructMin(Min paramMin)
/*     */   {
/* 166 */     HashMap localHashMap = new HashMap();
/* 167 */     localHashMap.put("value", Long.valueOf(paramMin.value()));
/* 168 */     localHashMap.put("prompts", Messages.getString(paramMin.message(), paramMin.value(), null));
/* 169 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructDecimalMax(DecimalMax paramDecimalMax)
/*     */   {
/* 177 */     HashMap localHashMap = new HashMap();
/* 178 */     localHashMap.put("value", paramDecimalMax.value());
/* 179 */     localHashMap.put("prompts", Messages.getString(paramDecimalMax.message(), paramDecimalMax.value(), null));
/* 180 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructDecimalMin(DecimalMin paramDecimalMin)
/*     */   {
/* 188 */     HashMap localHashMap = new HashMap();
/* 189 */     localHashMap.put("value", paramDecimalMin.value());
/* 190 */     localHashMap.put("prompts", Messages.getString(paramDecimalMin.message(), paramDecimalMin.value(), null));
/* 191 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructPast(Past paramPast)
/*     */   {
/* 199 */     HashMap localHashMap = new HashMap();
/* 200 */     localHashMap.put("prompts", Messages.getString(paramPast.message(), null, null));
/* 201 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructFuture(Future paramFuture)
/*     */   {
/* 209 */     HashMap localHashMap = new HashMap();
/* 210 */     localHashMap.put("prompts", Messages.getString(paramFuture.message(), null, null));
/* 211 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructEmail(Email paramEmail)
/*     */   {
/* 219 */     HashMap localHashMap = new HashMap();
/* 220 */     localHashMap.put("prompts", Messages.getString(paramEmail.message(), null, null));
/* 221 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructValid(Valid paramValid)
/*     */   {
/* 229 */     HashMap localHashMap = new HashMap();
/*     */ 
/* 231 */     localHashMap.put("valid", "valid");
/* 232 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructPattern(Pattern paramPattern)
/*     */   {
/* 240 */     HashMap localHashMap = new HashMap();
/* 241 */     localHashMap.put("regesp", paramPattern.regexp());
/* 242 */     localHashMap.put("prompts", Messages.getString(paramPattern.message(), paramPattern.regexp(), null));
/* 243 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructRange(Range paramRange)
/*     */   {
/* 251 */     HashMap localHashMap = new HashMap();
/* 252 */     localHashMap.put("max", Long.valueOf(paramRange.max()));
/* 253 */     localHashMap.put("min", Long.valueOf(paramRange.min()));
/* 254 */     localHashMap.put("prompts", Messages.getString(paramRange.message(), paramRange.min(), paramRange.max()));
/* 255 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private Map<String, Object> constructDigits(Digits paramDigits)
/*     */   {
/* 263 */     HashMap localHashMap = new HashMap();
/* 264 */     localHashMap.put("integer", 
/* 265 */       Integer.valueOf(paramDigits.integer()));
/* 266 */     localHashMap.put("fraction", Integer.valueOf(paramDigits.fraction()));
/* 267 */     localHashMap.put("prompts", Messages.getString(paramDigits.message(), paramDigits.integer(), paramDigits.fraction()));
/* 268 */     return localHashMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.annotation.AnnotationParser
 * JD-Core Version:    0.6.2
 */