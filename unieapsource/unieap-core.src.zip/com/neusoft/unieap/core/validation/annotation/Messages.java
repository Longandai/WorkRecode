/*     */ package com.neusoft.unieap.core.validation.annotation;
/*     */ 
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Map;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.hibernate.validator.engine.ConstraintViolationImpl;
/*     */ 
/*     */ public class Messages
/*     */ {
/*     */   public static String getString(String paramString1, String paramString2, String paramString3)
/*     */   {
/*  19 */     if ("{javax.validation.constraints.DecimalMax.message}".equals(paramString1)) {
/*  20 */       return "最大值应小于或等于" + paramString2;
/*     */     }
/*  22 */     if ("{javax.validation.constraints.DecimalMin.message}"
/*  22 */       .equals(paramString1))
/*  23 */       return "最小值应大于或等于" + paramString2;
/*  24 */     if ("{javax.validation.constraints.Digits.message}".equals(paramString1))
/*  25 */       return "数字整数部分不超过" + paramString2 + "位，小数部分不超过" + paramString3 + "位";
/*  26 */     if ("{javax.validation.constraints.Future.message}".equals(paramString1))
/*  27 */       return "日期不符合将来时段";
/*  28 */     if ("{javax.validation.constraints.Max.message}".equals(paramString1))
/*  29 */       return "最大值应小于或等于" + paramString2;
/*  30 */     if ("{javax.validation.constraints.Min.message}".equals(paramString1))
/*  31 */       return "最小值应大于或等于" + paramString2;
/*  32 */     if ("{javax.validation.constraints.NotNull.message}".equals(paramString1))
/*  33 */       return "值不允许为空";
/*  34 */     if ("{javax.validation.constraints.Past.message}".equals(paramString1))
/*  35 */       return "日期不符合过去时段";
/*  36 */     if ("{javax.validation.constraints.Pattern.message}".equals(paramString1)) {
/*  37 */       return "不符合正则表达式:" + paramString2;
/*     */     }
/*  39 */     if ("{org.hibernate.validator.constraints.Email.message}"
/*  39 */       .equals(paramString1)) {
/*  40 */       return "不符合emial地址格式";
/*     */     }
/*  42 */     if ("{org.hibernate.validator.constraints.Length.message}"
/*  42 */       .equals(paramString1)) {
/*  43 */       return "值长度在" + paramString2 + "与" + paramString3 + "之间";
/*     */     }
/*  45 */     if ("{org.hibernate.validator.constraints.Range.message}"
/*  45 */       .equals(paramString1)) {
/*  46 */       return "值大小应在" + paramString2 + "与" + paramString3 + "之间";
/*     */     }
/*  48 */     I18nGlobalContext localI18nGlobalContext = I18nGlobalContext.getInstance();
/*  49 */     if ((localI18nGlobalContext != null) && (localI18nGlobalContext.isI18nKey(paramString1))) {
/*  50 */       return localI18nGlobalContext.getValue(paramString1);
/*     */     }
/*  52 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public static String getExceptionMessage(ConstraintViolationImpl paramConstraintViolationImpl) {
/*  56 */     String str = paramConstraintViolationImpl.getConstraintDescriptor().getAnnotation()
/*  57 */       .annotationType().getCanonicalName();
/*     */ 
/*  59 */     if (str
/*  59 */       .equalsIgnoreCase("javax.validation.constraints.DecimalMax")) {
/*  60 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  61 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  63 */     if (str
/*  63 */       .equalsIgnoreCase("javax.validation.constraints.DecimalMin")) {
/*  64 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  65 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  67 */     if (str
/*  67 */       .equalsIgnoreCase("javax.validation.constraints.Digits")) {
/*  68 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  69 */         .getAttributes().get("integer").toString(), paramConstraintViolationImpl
/*  70 */         .getConstraintDescriptor().getAttributes().get("fraction")
/*  71 */         .toString());
/*     */     }
/*  73 */     if (str
/*  73 */       .equalsIgnoreCase("javax.validation.constraints.Future")) {
/*  74 */       return getString(paramConstraintViolationImpl.getMessage(), null, null);
/*     */     }
/*  76 */     if (str
/*  76 */       .equalsIgnoreCase("javax.validation.constraints.Max")) {
/*  77 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  78 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  80 */     if (str
/*  80 */       .equalsIgnoreCase("javax.validation.constraints.Min")) {
/*  81 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  82 */         .getAttributes().get("value").toString(), null);
/*     */     }
/*  84 */     if (str
/*  84 */       .equalsIgnoreCase("javax.validation.constraints.NotNull")) {
/*  85 */       return getString(paramConstraintViolationImpl.getMessage(), null, null);
/*     */     }
/*  87 */     if (str
/*  87 */       .equalsIgnoreCase("javax.validation.constraints.Past")) {
/*  88 */       return getString(paramConstraintViolationImpl.getMessage(), null, null);
/*     */     }
/*  90 */     if (str
/*  90 */       .equalsIgnoreCase("javax.validation.constraints.Pattern")) {
/*  91 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  92 */         .getAttributes().get("regexp").toString(), null);
/*     */     }
/*  94 */     if (str
/*  94 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Email")) {
/*  95 */       return getString(paramConstraintViolationImpl.getMessage(), null, null);
/*     */     }
/*  97 */     if (str
/*  97 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Length")) {
/*  98 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/*  99 */         .getAttributes().get("min").toString(), paramConstraintViolationImpl
/* 100 */         .getConstraintDescriptor().getAttributes().get("max")
/* 101 */         .toString());
/*     */     }
/* 103 */     if (str
/* 103 */       .equalsIgnoreCase("org.hibernate.validator.constraints.Range")) {
/* 104 */       return getString(paramConstraintViolationImpl.getMessage(), paramConstraintViolationImpl.getConstraintDescriptor()
/* 105 */         .getAttributes().get("min").toString(), paramConstraintViolationImpl
/* 106 */         .getConstraintDescriptor().getAttributes().get("max")
/* 107 */         .toString());
/*     */     }
/* 109 */     return "需要校验的对象不符合校验规则！";
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.annotation.Messages
 * JD-Core Version:    0.6.2
 */