/*     */ package com.neusoft.unieap.core.validation.i18n;
/*     */ 
/*     */ import com.neusoft.unieap.core.base.model.DCRepository;
/*     */ import com.neusoft.unieap.core.base.model.DevelopmentComponent;
/*     */ import com.neusoft.unieap.core.base.model.SoftwareComponent;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ 
/*     */ public class I18nGlobalContext
/*     */ {
/*     */   private static I18nGlobalContext instance;
/*     */   private static ServletContext servletContext;
/*     */   private static Locale locale;
/*  26 */   private static Map<String, String> i18nMap = new ConcurrentHashMap();
/*     */ 
/*     */   public static synchronized I18nGlobalContext getInstance() {
/*  29 */     if (instance == null)
/*  30 */       instance = new I18nGlobalContext();
/*  31 */     return instance;
/*     */   }
/*     */ 
/*     */   public void setServletContext(ServletContext paramServletContext) {
/*  35 */     servletContext = paramServletContext;
/*     */   }
/*     */ 
/*     */   public ServletContext getServletContext() {
/*  39 */     return servletContext;
/*     */   }
/*     */ 
/*     */   public void clearI18nMap() {
/*  43 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/*     */ 
/*  45 */     if (((localLocale == null) && (locale != null)) || (
/*  46 */       (localLocale != null) && (!localLocale.equals(locale)))) {
/*  47 */       i18nMap.clear();
/*     */     }
/*  49 */     locale = localLocale;
/*     */   }
/*     */ 
/*     */   public Locale getLocale() {
/*  53 */     return locale;
/*     */   }
/*     */ 
/*     */   public String getValue(String paramString)
/*     */   {
/*  63 */     return getValue(paramString, new Object[0], null);
/*     */   }
/*     */ 
/*     */   public String getValue(String paramString, Object[] paramArrayOfObject)
/*     */   {
/*  73 */     return getValue(paramString, paramArrayOfObject, null);
/*     */   }
/*     */ 
/*     */   public String getValue(String paramString1, String paramString2)
/*     */   {
/*  83 */     return getValue(paramString1, new Object[0], paramString2);
/*     */   }
/*     */ 
/*     */   public String getValue(String paramString1, Object[] paramArrayOfObject, String paramString2)
/*     */   {
/*  95 */     if (servletContext != null) {
/*  96 */       clearI18nMap();
/*  97 */       String str1 = "";
/*  98 */       if (i18nMap.containsKey(paramString1)) {
/*  99 */         str1 = (String)i18nMap.get(paramString1);
/*     */       } else {
/* 101 */         localObject = new Properties();
/* 102 */         FileInputStream localFileInputStream = null;
/* 103 */         String str2 = servletContext.getRealPath(File.separator);
/*     */ 
/* 115 */         if (!new File((str2.endsWith(File.separator) ? str2 : 
/* 106 */           new StringBuilder(String.valueOf(str2)).append(File.separator).toString()) + 
/* 107 */           "WEB-INF" + 
/* 108 */           File.separator + 
/* 109 */           "classes" + 
/* 110 */           File.separator + 
/* 111 */           getPackageString(paramString1, paramString2).replace(".", 
/* 112 */           File.separator) + 
/* 113 */           File.separator + 
/* 114 */           "package_" + 
/* 115 */           locale + ".properties").exists())
/*     */         {
/* 128 */           if (!new File(
/* 117 */             (str2.endsWith(File.separator) ? str2 : 
/* 118 */             new StringBuilder(String.valueOf(str2)).append(File.separator).toString()) + 
/* 119 */             "WEB-INF" + 
/* 120 */             File.separator + 
/* 121 */             "classes" + 
/* 122 */             File.separator + 
/* 123 */             getPackageString(paramString1, paramString2).replace(
/* 124 */             ".", File.separator) + 
/* 125 */             File.separator + 
/* 126 */             "package_" + 
/* 127 */             locale.getLanguage() + ".properties")
/* 128 */             .exists())
/*     */             try {
/* 130 */               localFileInputStream = 
/* 131 */                 FileUtils.openInputStream(new File(
/* 132 */                 (str2.endsWith(File.separator) ? str2 : 
/* 133 */                 new StringBuilder(String.valueOf(str2)).append(File.separator).toString()) + 
/* 134 */                 "WEB-INF" + 
/* 135 */                 File.separator + 
/* 136 */                 "classes" + 
/* 137 */                 File.separator + 
/* 138 */                 getPackageString(paramString1, 
/* 139 */                 paramString2)
/* 140 */                 .replace(
/* 141 */                 ".", 
/* 142 */                 File.separator) + 
/* 143 */                 File.separator + 
/* 144 */                 "package.properties"));
/*     */             } catch (IOException localIOException1) {
/* 146 */               localFileInputStream = null;
/*     */             }
/*     */           else
/*     */             try {
/* 150 */               localFileInputStream = 
/* 151 */                 FileUtils.openInputStream(new File(
/* 152 */                 (str2.endsWith(File.separator) ? str2 : 
/* 153 */                 new StringBuilder(String.valueOf(str2)).append(File.separator).toString()) + 
/* 154 */                 "WEB-INF" + 
/* 155 */                 File.separator + 
/* 156 */                 "classes" + 
/* 157 */                 File.separator + 
/* 158 */                 getPackageString(paramString1, 
/* 159 */                 paramString2)
/* 160 */                 .replace(
/* 161 */                 ".", 
/* 162 */                 File.separator) + 
/* 163 */                 File.separator + 
/* 164 */                 "package_" + 
/* 165 */                 locale.getLanguage() + 
/* 166 */                 ".properties"));
/*     */             } catch (IOException localIOException2) {
/* 168 */               localFileInputStream = null;
/*     */             }
/*     */         }
/*     */         else {
/*     */           try {
/* 173 */             localFileInputStream = FileUtils.openInputStream(new File(
/* 174 */               (str2.endsWith(File.separator) ? str2 : 
/* 175 */               new StringBuilder(String.valueOf(str2)).append(File.separator).toString()) + 
/* 176 */               "WEB-INF" + 
/* 177 */               File.separator + 
/* 178 */               "classes" + 
/* 179 */               File.separator + 
/* 180 */               getPackageString(paramString1, paramString2)
/* 181 */               .replace(".", File.separator) + 
/* 182 */               File.separator + 
/* 183 */               "package_" + 
/* 184 */               locale + 
/* 185 */               ".properties"));
/*     */           } catch (IOException localIOException3) {
/* 187 */             localFileInputStream = null;
/*     */           }
/*     */         }
/* 190 */         if (localFileInputStream == null) {
/* 191 */           return paramString1;
/*     */         }
/* 193 */         String str3 = getI18nKey(paramString1);
/*     */         try {
/* 195 */           ((Properties)localObject).load(localFileInputStream);
/*     */         } catch (IOException localIOException4) {
/* 197 */           return paramString1;
/*     */         }
/* 199 */         if (((Properties)localObject).containsKey(str3)) {
/* 200 */           str1 = ((Properties)localObject).getProperty(str3);
/* 201 */           i18nMap.put(paramString1, str1);
/*     */         } else {
/* 203 */           return paramString1;
/*     */         }
/*     */       }
/* 205 */       Object localObject = LocalizedTextUtil.buildMessageFormat(str1, 
/* 206 */         locale);
/* 207 */       return ((MessageFormat)localObject).format(paramArrayOfObject);
/*     */     }
/* 209 */     return paramString1;
/*     */   }
/*     */ 
/*     */   public boolean isI18nKey(String paramString) {
/* 213 */     if ((paramString == null) || ("".equals(paramString))) {
/* 214 */       return false;
/*     */     }
/*     */ 
/* 217 */     return (paramString.startsWith("${")) && (paramString.endsWith("}")) && 
/* 217 */       (paramString.indexOf("/") != -1);
/*     */   }
/*     */ 
/*     */   private String getI18nKey(String paramString) {
/* 221 */     if (paramString.indexOf("${") != -1) {
/* 222 */       paramString = paramString
/* 223 */         .substring(paramString.indexOf("${") + 2);
/*     */     }
/* 225 */     if (paramString.indexOf("}") != -1) {
/* 226 */       paramString = paramString.substring(0, paramString
/* 227 */         .indexOf("}"));
/*     */     }
/* 229 */     return paramString.substring(paramString.indexOf("/") + 1);
/*     */   }
/*     */ 
/*     */   private String getPackageString(String paramString1, String paramString2) {
/* 233 */     if ((paramString1.indexOf("/") == -1) || 
/* 234 */       (paramString1.indexOf("${") == -1)) {
/* 235 */       if ((paramString2 != null) && (!"".equals(paramString2))) {
/* 236 */         DevelopmentComponent localDevelopmentComponent = DCRepository.getDevelopmentComponent(paramString2);
/* 237 */         if (localDevelopmentComponent == null) {
/* 238 */           return paramString2.toLowerCase();
/*     */         }
/* 240 */         SoftwareComponent localSoftwareComponent = localDevelopmentComponent.getSoftwareComponent();
/* 241 */         if (localSoftwareComponent != null) {
/* 242 */           return (localSoftwareComponent.getId() + File.separator + paramString2)
/* 243 */             .toLowerCase();
/*     */         }
/* 245 */         return paramString2.toLowerCase();
/*     */       }
/*     */ 
/* 278 */       return "";
/*     */     }
/* 280 */     return paramString1.substring(2, paramString1.indexOf("/"))
/* 281 */       .toLowerCase();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.i18n.I18nGlobalContext
 * JD-Core Version:    0.6.2
 */