/*    */ package com.neusoft.unieap.core.validation;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.readfile.ReadFileUtil;
/*    */ import com.neusoft.unieap.core.validation.exception.ValidationException;
/*    */ 
/*    */ public final class BeanValidatorFactory
/*    */ {
/*  9 */   private static BeanValidator unieapValidator = null;
/*    */   private static final String BEANVALIDATOR_FILENAME = "ValidatorConfig.properties";
/*    */   private static final String BEANVALIDATOR_PROPERTY = "validatorUtilClassPath";
/*    */ 
/*    */   public static BeanValidator getBeanValidator()
/*    */   {
/* 26 */     if (unieapValidator == null) {
/* 27 */       createBeanValidator();
/*    */     }
/* 29 */     return unieapValidator;
/*    */   }
/*    */ 
/*    */   private static synchronized void createBeanValidator() {
/* 33 */     String str = null;
/*    */     try {
/* 35 */       str = ReadFileUtil.readFile(
/* 36 */         "ValidatorConfig.properties", "validatorUtilClassPath", 
/* 37 */         BeanValidatorFactory.class);
/* 38 */       if ((str != null) && 
/* 39 */         (str.length() > 0))
/* 40 */         unieapValidator = 
/* 41 */           (BeanValidator)Class.forName(
/* 41 */           str).newInstance();
/*    */     }
/*    */     catch (ClassNotFoundException localClassNotFoundException) {
/* 44 */       throw new ValidationException(
/* 45 */         "EAPTECH006002", localClassNotFoundException, 
/* 46 */         new String[] { str });
/*    */     } catch (InstantiationException localInstantiationException) {
/* 48 */       throw new ValidationException(
/* 49 */         "EAPTECH006003", 
/* 50 */         localInstantiationException, new String[] { str });
/*    */     } catch (IllegalAccessException localIllegalAccessException) {
/* 52 */       throw new ValidationException(
/* 53 */         "EAPTECH006003", 
/* 54 */         localIllegalAccessException, new String[] { str });
/*    */     } catch (ClassCastException localClassCastException) {
/* 56 */       throw new ValidationException(
/* 57 */         "EAPTECH006004", localClassCastException, 
/* 58 */         new String[] { str });
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.BeanValidatorFactory
 * JD-Core Version:    0.6.2
 */