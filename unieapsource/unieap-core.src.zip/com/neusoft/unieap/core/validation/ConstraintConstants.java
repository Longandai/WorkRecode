package com.neusoft.unieap.core.validation;

public class ConstraintConstants
{
  public static final String NOTNULL = "notNull";
  public static final String PROMPTS = "prompts";
  public static final String MIN = "min";
  public static final String MAX = "max";
  public static final String VALUE = "value";
  public static final String LENGTH = "length";
  public static final String DECIMALMAX = "decimalMax";
  public static final String DECIMALMIN = "decimalMin";
  public static final String PAST = "past";
  public static final String FUTURE = "future";
  public static final String EMAIL = "email";
  public static final String VALID = "valid";
  public static final String PATTERN = "pattern";
  public static final String REGESP = "regesp";
  public static final String RANGE = "range";
  public static final String DIGITS = "digits";
  public static final String INTEGER = "integer";
  public static final String FRACTION = "fraction";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.ConstraintConstants
 * JD-Core Version:    0.6.2
 */