/*     */ package com.neusoft.unieap.core.validation.message;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.MessageInterpolator.Context;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ 
/*     */ public class ValidationMessageInterpolator
/*     */   implements MessageInterpolator
/*     */ {
/*     */   private static final String USER_VALIDATION_MESSAGES = "ValidationMessages";
/*  16 */   private static final Pattern messageParameterPattern = Pattern.compile("(\\{[^\\}]+?\\})");
/*  17 */   private static final Hashtable bundlesMap = new Hashtable();
/*  18 */   private static ClassLoader delegatedClassLoader = null;
/*  19 */   private static final ResourceBundle EMPTY_BUNDLE = new EmptyResourceBundle(null);
/*  20 */   private final Map<LocalisedMessage, String> resolvedMessages = new WeakHashMap();
/*     */ 
/*     */   public String interpolate(String paramString, MessageInterpolator.Context paramContext) {
/*  23 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/*  24 */     return interpolate(paramString, paramContext, localLocale);
/*     */   }
/*     */ 
/*     */   public String interpolate(String paramString, MessageInterpolator.Context paramContext, Locale paramLocale) {
/*  28 */     Object localObject = paramContext.getValidatedValue();
/*  29 */     Class localClass = localObject.getClass();
/*  30 */     String str1 = null;
/*  31 */     String str2 = null;
/*  32 */     if ((localClass != null) && (!localClass.equals(Object.class)))
/*     */     {
/*  34 */       str1 = localClass.getName();
/*  35 */       while (str1.lastIndexOf('.') != -1) {
/*  36 */         str1 = str1.substring(0, str1.lastIndexOf('.'));
/*  37 */         String str3 = str1 + "." + "ValidationMessages";
/*  38 */         str2 = interpolateMessage(paramString, paramContext.getConstraintDescriptor().getAttributes(), paramLocale, str3);
/*  39 */         if (str2 != null) {
/*  40 */           return str2;
/*     */         }
/*     */       }
/*     */     }
/*  44 */     return str2;
/*     */   }
/*     */   private String interpolateMessage(String paramString1, Map<String, Object> paramMap, Locale paramLocale, String paramString2) {
/*  47 */     LocalisedMessage localLocalisedMessage = new LocalisedMessage(paramString1, paramLocale);
/*  48 */     String str1 = (String)this.resolvedMessages.get(localLocalisedMessage);
/*  49 */     if (str1 == null) {
/*  50 */       ResourceBundle localResourceBundle1 = findResourceBundle(paramString2, paramLocale);
/*  51 */       if ((localResourceBundle1 == null) && (paramString2.split("\\.").length > 2))
/*     */       {
/*  53 */         return null;
/*     */       }
/*  55 */       ResourceBundle localResourceBundle2 = localResourceBundle1;
/*     */ 
/*  57 */       str1 = paramString1;
/*  58 */       int i = 0;
/*     */       while (true)
/*     */       {
/*  61 */         String str2 = replaceVariables(
/*  62 */           str1, localResourceBundle1, paramLocale, true);
/*     */ 
/*  64 */         if ((i != 0) && 
/*  65 */           (!hasReplacementTakenPlace(str2, str1)))
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/*  70 */         str1 = replaceVariables(str2, localResourceBundle2, paramLocale, false);
/*  71 */         i = 1;
/*  72 */         this.resolvedMessages.put(localLocalisedMessage, str1);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  77 */     str1 = replaceAnnotationAttributes(str1, paramMap);
/*     */ 
/*  80 */     str1 = str1.replace("\\{", "{");
/*  81 */     str1 = str1.replace("\\}", "}");
/*  82 */     str1 = str1.replace("\\\\", "\\");
/*  83 */     return str1;
/*     */   }
/*     */ 
/*     */   private boolean hasReplacementTakenPlace(String paramString1, String paramString2) {
/*  87 */     return !paramString1.equals(paramString2);
/*     */   }
/*     */ 
/*     */   private String replaceVariables(String paramString, ResourceBundle paramResourceBundle, Locale paramLocale, boolean paramBoolean)
/*     */   {
/*  92 */     Matcher localMatcher = messageParameterPattern.matcher(paramString);
/*  93 */     StringBuffer localStringBuffer = new StringBuffer();
/*     */ 
/*  95 */     while (localMatcher.find()) {
/*  96 */       String str2 = localMatcher.group(1);
/*  97 */       String str1 = resolveParameter(
/*  98 */         str2, paramResourceBundle, paramLocale, paramBoolean);
/*     */ 
/* 101 */       localMatcher.appendReplacement(localStringBuffer, escapeMetaCharacters(str1));
/*     */     }
/* 103 */     localMatcher.appendTail(localStringBuffer);
/* 104 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   private String replaceAnnotationAttributes(String paramString, Map<String, Object> paramMap) {
/* 108 */     Matcher localMatcher = messageParameterPattern.matcher(paramString);
/* 109 */     StringBuffer localStringBuffer = new StringBuffer();
/* 110 */     while (localMatcher.find())
/*     */     {
/* 112 */       String str2 = localMatcher.group(1);
/* 113 */       Object localObject = paramMap.get(removeCurlyBrace(str2));
/*     */       String str1;
/* 114 */       if (localObject != null) {
/* 115 */         str1 = escapeMetaCharacters(localObject.toString());
/*     */       }
/*     */       else {
/* 118 */         str1 = str2;
/*     */       }
/* 120 */       localMatcher.appendReplacement(localStringBuffer, str1);
/*     */     }
/* 122 */     localMatcher.appendTail(localStringBuffer);
/* 123 */     return localStringBuffer.toString();
/*     */   }
/*     */ 
/*     */   private String resolveParameter(String paramString, ResourceBundle paramResourceBundle, Locale paramLocale, boolean paramBoolean) {
/*     */     String str;
/*     */     try {
/* 129 */       if (paramResourceBundle != null) {
/* 130 */         str = paramResourceBundle.getString(removeCurlyBrace(paramString));
/* 131 */         if (paramBoolean)
/* 132 */           str = replaceVariables(str, paramResourceBundle, paramLocale, paramBoolean);
/*     */       }
/*     */       else
/*     */       {
/* 136 */         str = paramString;
/*     */       }
/*     */     }
/*     */     catch (MissingResourceException localMissingResourceException) {
/* 140 */       str = paramString;
/*     */     }
/* 142 */     return str;
/*     */   }
/*     */ 
/*     */   private String removeCurlyBrace(String paramString) {
/* 146 */     return paramString.substring(1, paramString.length() - 1);
/*     */   }
/*     */ 
/*     */   private String escapeMetaCharacters(String paramString)
/*     */   {
/* 154 */     String str = paramString.replace("\\", "\\\\");
/* 155 */     str = str.replace("$", "\\$");
/* 156 */     return str;
/*     */   }
/*     */ 
/*     */   private static ResourceBundle findResourceBundle(String paramString, Locale paramLocale)
/*     */   {
/* 206 */     String str = createMissesKey(paramString, paramLocale);
/*     */     ResourceBundle localResourceBundle;
/*     */     try
/*     */     {
/* 211 */       if (!bundlesMap.containsKey(str)) {
/* 212 */         localResourceBundle = ResourceBundle.getBundle(paramString, paramLocale, 
/* 213 */           Thread.currentThread().getContextClassLoader());
/* 214 */         bundlesMap.put(str, localResourceBundle);
/*     */       }
/*     */ 
/* 217 */       localResourceBundle = (ResourceBundle)bundlesMap.get(str);
/*     */     } catch (MissingResourceException localMissingResourceException1) {
/* 219 */       if (delegatedClassLoader != null) {
/*     */         try {
/* 221 */           if (!bundlesMap.containsKey(str)) {
/* 222 */             localResourceBundle = ResourceBundle.getBundle(paramString, paramLocale, 
/* 223 */               delegatedClassLoader);
/* 224 */             bundlesMap.put(str, localResourceBundle);
/*     */           }
/*     */ 
/* 227 */           localResourceBundle = (ResourceBundle)bundlesMap.get(str);
/*     */         }
/*     */         catch (MissingResourceException localMissingResourceException2) {
/* 230 */           localResourceBundle = EMPTY_BUNDLE;
/* 231 */           bundlesMap.put(str, localResourceBundle);
/*     */         }
/*     */       } else {
/* 234 */         localResourceBundle = EMPTY_BUNDLE;
/* 235 */         bundlesMap.put(str, localResourceBundle);
/*     */       }
/*     */     }
/* 238 */     return localResourceBundle == EMPTY_BUNDLE ? null : localResourceBundle;
/*     */   }
/*     */ 
/*     */   private static String createMissesKey(String paramString, Locale paramLocale)
/*     */   {
/* 250 */     return paramString + "_" + paramLocale.toString();
/*     */   }
/*     */ 
/*     */   private static class EmptyResourceBundle extends ResourceBundle
/*     */   {
/*     */     public Enumeration getKeys()
/*     */     {
/* 258 */       return null;
/*     */     }
/*     */ 
/*     */     protected Object handleGetObject(String paramString) {
/* 262 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LocalisedMessage
/*     */   {
/*     */     private final String message;
/*     */     private final Locale locale;
/*     */ 
/*     */     LocalisedMessage(String paramString, Locale paramLocale)
/*     */     {
/* 164 */       this.message = paramString;
/* 165 */       this.locale = paramLocale;
/*     */     }
/*     */ 
/*     */     public String getMessage() {
/* 169 */       return this.message;
/*     */     }
/*     */ 
/*     */     public Locale getLocale() {
/* 173 */       return this.locale;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object paramObject)
/*     */     {
/* 178 */       if (this == paramObject) {
/* 179 */         return true;
/*     */       }
/* 181 */       if ((paramObject == null) || (getClass() != paramObject.getClass())) {
/* 182 */         return false;
/*     */       }
/*     */ 
/* 185 */       LocalisedMessage localLocalisedMessage = (LocalisedMessage)paramObject;
/*     */ 
/* 187 */       if (this.locale != null ? !this.locale.equals(localLocalisedMessage.locale) : localLocalisedMessage.locale != null) {
/* 188 */         return false;
/*     */       }
/* 190 */       if (this.message != null ? !this.message.equals(localLocalisedMessage.message) : localLocalisedMessage.message != null) {
/* 191 */         return false;
/*     */       }
/*     */ 
/* 194 */       return true;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 199 */       int i = this.message != null ? this.message.hashCode() : 0;
/* 200 */       i = 31 * i + (this.locale != null ? this.locale.hashCode() : 0);
/* 201 */       return i;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.message.ValidationMessageInterpolator
 * JD-Core Version:    0.6.2
 */