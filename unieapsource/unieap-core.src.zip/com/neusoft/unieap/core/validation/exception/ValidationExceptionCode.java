package com.neusoft.unieap.core.validation.exception;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class ValidationExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "006";
  private static final String P = "EAPTECH006";
  public static final String VALIDATE_FAILURE = "EAPTECH006001";
  public static final String BEANVALIDATOR_NONEXISTENCE = "EAPTECH006002";
  public static final String BEANVALIDATOR_INSTANTIATION_FAILURE = "EAPTECH006003";
  public static final String BEANVALIDATOR_CLASSTYPE_FAILURE = "EAPTECH006004";
  public static final String BEANVALIDATOR_READFILE_FAILURE = "EAPTECH006005";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.exception.ValidationExceptionCode
 * JD-Core Version:    0.6.2
 */