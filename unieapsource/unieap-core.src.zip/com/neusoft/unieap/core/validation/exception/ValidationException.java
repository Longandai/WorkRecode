/*    */ package com.neusoft.unieap.core.validation.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class ValidationException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 7189417661042236897L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 18 */     return true;
/*    */   }
/*    */ 
/*    */   public ValidationException(String paramString, Exception paramException) {
/* 22 */     super(paramString, paramException, null);
/*    */   }
/*    */ 
/*    */   public ValidationException(String paramString, Exception paramException, String[] paramArrayOfString) {
/* 26 */     super(paramString, paramException, paramArrayOfString);
/*    */   }
/*    */ 
/*    */   public ValidationException(String paramString, Exception paramException, String[] paramArrayOfString, Set paramSet)
/*    */   {
/* 31 */     super(paramString, paramException, paramArrayOfString);
/* 32 */     super.putAttribute("validation", paramSet);
/*    */   }
/*    */ 
/*    */   public ValidationException(String paramString, Exception paramException, String[] paramArrayOfString, Set paramSet, boolean paramBoolean)
/*    */   {
/* 37 */     super(paramString, paramException, paramArrayOfString, paramBoolean);
/* 38 */     super.putAttribute("validation", paramSet);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.exception.ValidationException
 * JD-Core Version:    0.6.2
 */