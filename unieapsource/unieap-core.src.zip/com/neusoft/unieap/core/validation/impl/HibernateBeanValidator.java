/*    */ package com.neusoft.unieap.core.validation.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.CoreVariability;
/*    */ import com.neusoft.unieap.core.validation.BeanValidator;
/*    */ import com.neusoft.unieap.core.validation.annotation.AnnotationParser;
/*    */ import com.neusoft.unieap.core.validation.annotation.Messages;
/*    */ import com.neusoft.unieap.core.validation.exception.ValidationException;
/*    */ import com.neusoft.unieap.core.validation.message.ValidationMessageInterpolator;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import javax.validation.Validation;
/*    */ import javax.validation.Validator;
/*    */ import javax.validation.ValidatorFactory;
/*    */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*    */ import org.hibernate.validator.HibernateValidator;
/*    */ import org.hibernate.validator.HibernateValidatorConfiguration;
/*    */ import org.hibernate.validator.engine.ConstraintViolationImpl;
/*    */ 
/*    */ public class HibernateBeanValidator
/*    */   implements BeanValidator
/*    */ {
/* 25 */   private static HibernateValidatorConfiguration configuration = (HibernateValidatorConfiguration)Validation.byProvider(HibernateValidator.class).configure();
/*    */ 
/* 27 */   private static Validator hibernateValidator = configuration
/* 27 */     .buildValidatorFactory().getValidator();
/* 28 */   private static boolean isValid = CoreVariability.isValidationEnabled();
/* 29 */   private static Map constraints = null;
/*    */ 
/*    */   static {
/* 32 */     constraints = new HashMap();
/* 33 */     ValidationMessageInterpolator localValidationMessageInterpolator = new ValidationMessageInterpolator();
/* 34 */     configuration.messageInterpolator(localValidationMessageInterpolator);
/*    */   }
/*    */ 
/*    */   public Validator getValidator() {
/* 38 */     return hibernateValidator;
/*    */   }
/*    */ 
/*    */   public void validate(Object paramObject) {
/* 42 */     validate(paramObject, null, null, false);
/*    */   }
/*    */ 
/*    */   public void validate(Object paramObject, boolean paramBoolean) {
/* 46 */     validate(paramObject, null, null, paramBoolean);
/*    */   }
/*    */ 
/*    */   public void validate(Object paramObject, String paramString, String[] paramArrayOfString) {
/* 50 */     validate(paramObject, paramString, paramArrayOfString, false);
/*    */   }
/*    */ 
/*    */   public void validate(Object paramObject, String paramString, String[] paramArrayOfString, boolean paramBoolean)
/*    */   {
/* 55 */     if (isValid) {
/* 56 */       Set localSet = hibernateValidator.validate(paramObject, new Class[0]);
/* 57 */       if (localSet.size() > 0) {
/* 58 */         ConstraintViolationImpl[] arrayOfConstraintViolationImpl = 
/* 59 */           (ConstraintViolationImpl[])localSet
/* 59 */           .toArray(new ConstraintViolationImpl[localSet.size()]);
/* 60 */         if (paramString == null) {
/* 61 */           paramString = "EAPCORE000001";
/* 62 */           localValidationException = new ValidationException(paramString, 
/* 63 */             null, paramArrayOfString, localSet, paramBoolean);
/* 64 */           localValidationException.setExceptionMessage(
/* 65 */             Messages.getExceptionMessage(arrayOfConstraintViolationImpl[0]));
/* 66 */           throw localValidationException;
/*    */         }
/* 68 */         ValidationException localValidationException = new ValidationException(paramString, 
/* 69 */           null, paramArrayOfString, localSet, paramBoolean);
/* 70 */         throw localValidationException;
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public Map getConstraints(String paramString)
/*    */   {
/* 77 */     if (constraints.containsKey(paramString)) {
/* 78 */       return (Map)constraints.get(paramString);
/*    */     }
/* 80 */     String str = AnnotationParser.class.getName();
/*    */     try {
/* 82 */       Class localClass = Class.forName(str);
/* 83 */       Object localObject = localClass.newInstance();
/* 84 */       Map localMap = (Map)localClass.getMethod("getMetadata", 
/* 85 */         new Class[] { String.class }).invoke(localObject, 
/* 86 */         new Object[] { paramString });
/* 87 */       constraints.put(paramString, localMap);
/* 88 */       return localMap;
/*    */     } catch (Exception localException) {
/*    */     }
/* 91 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.impl.HibernateBeanValidator
 * JD-Core Version:    0.6.2
 */