package com.neusoft.unieap.core.validation;

import java.util.Map;
import javax.validation.Validator;

public abstract interface BeanValidator
{
  public abstract Validator getValidator();

  public abstract void validate(Object paramObject);

  public abstract void validate(Object paramObject, boolean paramBoolean);

  public abstract void validate(Object paramObject, String paramString, String[] paramArrayOfString);

  public abstract void validate(Object paramObject, String paramString, String[] paramArrayOfString, boolean paramBoolean);

  public abstract Map getConstraints(String paramString);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.validation.BeanValidator
 * JD-Core Version:    0.6.2
 */