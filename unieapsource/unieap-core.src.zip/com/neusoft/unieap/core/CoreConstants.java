package com.neusoft.unieap.core;

public class CoreConstants
{
  public static final String EAP_NON_JSON_RETURN_TYPE = "eap_non_Json_Return_Type";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.CoreConstants
 * JD-Core Version:    0.6.2
 */