/*     */ package com.neusoft.unieap.core.autoproxy;
/*     */ 
/*     */ import org.springframework.aop.Advisor;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.framework.autoproxy.BeanNameAutoProxyCreator;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class UniEAPAutoProxyCreator extends BeanNameAutoProxyCreator
/*     */   implements ApplicationContextAware
/*     */ {
/*     */   private static final long serialVersionUID = 2603171842141291353L;
/*     */   private static final String INCLUDETXINTERCEPTOR = "includeTxInterceptor";
/*     */   private static final String BASETXADVISOR = "baseTxAdvisor";
/*     */   private ApplicationContext context;
/*     */   private String beanName;
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext paramApplicationContext)
/*     */     throws BeansException
/*     */   {
/*  29 */     this.context = paramApplicationContext;
/*     */   }
/*     */ 
/*     */   protected void customizeProxyFactory(ProxyFactory paramProxyFactory)
/*     */   {
/*     */     try
/*     */     {
/*  37 */       if (AopUtils.isCglibProxy(paramProxyFactory.getTargetSource()
/*  38 */         .getTarget()))
/*  39 */         paramProxyFactory.setProxyTargetClass(true);
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*     */     }
/*  44 */     DefaultListableBeanFactory localDefaultListableBeanFactory = (DefaultListableBeanFactory)this.context
/*  45 */       .getAutowireCapableBeanFactory();
/*     */ 
/*  48 */     BeanDefinition localBeanDefinition = localDefaultListableBeanFactory
/*  49 */       .getBeanDefinition(this.beanName);
/*     */     Object localObject1;
/*     */     Object localObject2;
/*  51 */     if ((localBeanDefinition.attributeNames() == null) || 
/*  52 */       (localBeanDefinition.attributeNames().length == 0))
/*     */     {
/*  54 */       if (paramProxyFactory.getAdvisors().length == 1) {
/*  55 */         return;
/*     */       }
/*  57 */       localObject1 = localDefaultListableBeanFactory.getBean("baseTxAdvisor");
/*     */ 
/*  59 */       for (localObject2 : paramProxyFactory.getAdvisors()) {
/*  60 */         if (isExcudeTxInterceptor((Advisor)localObject2, localDefaultListableBeanFactory, localObject1)) {
/*  61 */           paramProxyFactory.removeAdvisor((Advisor)localObject2);
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/*  67 */       localObject1 = (String)localBeanDefinition
/*  68 */         .getAttribute("includeTxInterceptor");
/*     */       Advisor localAdvisor;
/*  69 */       if (localObject1 != null)
/*     */       {
/*  71 */         localObject2 = localDefaultListableBeanFactory.getBean((String)localObject1);
/*  72 */         for (localAdvisor : paramProxyFactory.getAdvisors())
/*  73 */           if (isExcudeTxInterceptor(localAdvisor, localDefaultListableBeanFactory, localObject2))
/*  74 */             paramProxyFactory.removeAdvisor(localAdvisor);
/*     */       }
/*     */       else
/*     */       {
/*  78 */         localObject2 = localDefaultListableBeanFactory.getBean("baseTxAdvisor");
/*     */ 
/*  80 */         for (localAdvisor : paramProxyFactory.getAdvisors())
/*  81 */           if (isExcudeTxInterceptor(localAdvisor, localDefaultListableBeanFactory, localObject2))
/*  82 */             paramProxyFactory.removeAdvisor(localAdvisor);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isExcudeTxInterceptor(Advisor paramAdvisor, DefaultListableBeanFactory paramDefaultListableBeanFactory, Object paramObject)
/*     */   {
/*  99 */     if (paramObject == null) {
/* 100 */       return false;
/*     */     }
/* 102 */     if ((!paramAdvisor.equals(paramObject)) && 
/* 103 */       (paramAdvisor.getAdvice().getClass().getCanonicalName().equals(
/* 104 */       ((Advisor)paramObject).getAdvice().getClass()
/* 105 */       .getCanonicalName()))) {
/* 106 */       return true;
/*     */     }
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   protected Object[] getAdvicesAndAdvisorsForBean(Class paramClass, String paramString, TargetSource paramTargetSource)
/*     */     throws BeansException
/*     */   {
/* 116 */     this.beanName = paramString;
/* 117 */     return super.getAdvicesAndAdvisorsForBean(paramClass, paramString, 
/* 118 */       paramTargetSource);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.autoproxy.UniEAPAutoProxyCreator
 * JD-Core Version:    0.6.2
 */