/*    */ package com.neusoft.unieap.core.exception.dao.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.core.exception.dao.TraceMessageDAO;
/*    */ import com.neusoft.unieap.core.exception.entity.TraceMessage;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.Session;
/*    */ 
/*    */ public class TraceMessageHibernateDAOImpl extends BaseHibernateDAO
/*    */   implements TraceMessageDAO
/*    */ {
/*    */   private static final long serialVersionUID = -2027596392273386557L;
/*    */ 
/*    */   public void deleteTraceMessages(List paramList)
/*    */   {
/* 18 */     if ((paramList == null) || (paramList.isEmpty()))
/* 19 */       return;
/* 20 */     StringBuffer localStringBuffer = new StringBuffer();
/* 21 */     localStringBuffer.append("DELETE from TraceMessage tm ");
/* 22 */     localStringBuffer.append("WHERE tm.id IN (:ids)");
/* 23 */     Query localQuery = super.getSession().createQuery(localStringBuffer.toString());
/* 24 */     localQuery.setParameterList("ids", paramList);
/* 25 */     localQuery.executeUpdate();
/*    */   }
/*    */ 
/*    */   public TraceMessage getTraceMessageById(String paramString) {
/* 29 */     StringBuffer localStringBuffer = new StringBuffer();
/* 30 */     localStringBuffer.append("FROM TraceMessage tm ");
/* 31 */     localStringBuffer.append("WHERE tm.id = ?");
/* 32 */     return (TraceMessage)super.queryObject(localStringBuffer.toString(), paramString);
/*    */   }
/*    */ 
/*    */   public Serializable saveTraceMessage(TraceMessage paramTraceMessage) {
/* 36 */     return super.addObject(paramTraceMessage);
/*    */   }
/*    */ 
/*    */   public int clearTraceMessages()
/*    */   {
/* 41 */     String str = "DELETE from TraceMessage";
/* 42 */     Query localQuery = super.getSession().createQuery(str);
/* 43 */     return localQuery.executeUpdate();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.dao.impl.TraceMessageHibernateDAOImpl
 * JD-Core Version:    0.6.2
 */