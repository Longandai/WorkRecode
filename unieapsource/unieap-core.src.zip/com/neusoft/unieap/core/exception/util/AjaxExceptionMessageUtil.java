/*    */ package com.neusoft.unieap.core.exception.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPExceptionHolder;
/*    */ import net.sf.json.JSONObject;
/*    */ 
/*    */ public class AjaxExceptionMessageUtil
/*    */ {
/*    */   public static String generateExceptionResult(UniEAPExceptionHolder paramUniEAPExceptionHolder)
/*    */   {
/* 21 */     String str = "{header:{\"code\": -1,\"message\":{\"title\": \"\",\"detail\": \"\"}},body: {parameters:{},dataStores:{}}}";
/*    */ 
/* 23 */     JSONObject localJSONObject1 = JSONObject.fromObject(str);
/* 24 */     JSONObject localJSONObject2 = localJSONObject1.getJSONObject("header").getJSONObject("message");
/* 25 */     localJSONObject2.put("title", paramUniEAPExceptionHolder.getExceptionMessage());
/*    */ 
/* 27 */     localJSONObject2.put("detail", paramUniEAPExceptionHolder.getExceptionStack());
/* 28 */     JSONObject localJSONObject3 = localJSONObject1.getJSONObject("body").getJSONObject("parameters");
/* 29 */     localJSONObject3.put("result", "error");
/*    */ 
/* 32 */     return localJSONObject1.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.util.AjaxExceptionMessageUtil
 * JD-Core Version:    0.6.2
 */