/*    */ package com.neusoft.unieap.core.exception.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPException;
/*    */ import java.text.MessageFormat;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class ExceptionI18nUtil
/*    */ {
/*    */   public static String getI18nInfo(UniEAPException paramUniEAPException, Locale paramLocale)
/*    */   {
/* 24 */     if (paramUniEAPException == null)
/*    */     {
/* 26 */       throw new IllegalArgumentException("inpute uniEAPException is null at getI18nInfo method of " + ExceptionI18nUtil.class.getName());
/*    */     }
/* 28 */     if (paramLocale == null)
/*    */     {
/* 30 */       paramLocale = Locale.getDefault();
/*    */     }
/* 32 */     String str1 = getProPertyResource(paramUniEAPException.getClass().getName());
/* 33 */     ResourceBundle localResourceBundle = ResourceBundle.getBundle(str1, paramLocale);
/* 34 */     String str2 = localResourceBundle.getString(paramUniEAPException.getCode());
/* 35 */     int i = getParameterCount(str2);
/* 36 */     if ((i > 0) && ((paramUniEAPException.getArgs() == null) || (paramUniEAPException.getArgs().length < i)))
/*    */     {
/* 39 */       throw new IllegalArgumentException(str2 + " need " + i + " parameters Exception args don't map");
/*    */     }
/*    */ 
/* 43 */     str2 = MessageFormat.format(str2, paramUniEAPException.getArgs());
/*    */ 
/* 45 */     return str2;
/*    */   }
/*    */ 
/*    */   private static String getProPertyResource(String paramString)
/*    */   {
/* 55 */     String str = null;
/* 56 */     int i = paramString.lastIndexOf(".");
/* 57 */     paramString = paramString.substring(0, i);
/* 58 */     str = paramString + ".i18n.exi18n";
/* 59 */     return str;
/*    */   }
/*    */ 
/*    */   private static int getParameterCount(String paramString)
/*    */   {
/* 69 */     int i = 0;
/* 70 */     String str = "\\{[0-9]+\\}";
/* 71 */     Pattern localPattern = Pattern.compile(str);
/* 72 */     Matcher localMatcher = localPattern.matcher(paramString);
/* 73 */     while (localMatcher.find())
/*    */     {
/* 75 */       i++;
/*    */     }
/* 77 */     return i;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.util.ExceptionI18nUtil
 * JD-Core Version:    0.6.2
 */