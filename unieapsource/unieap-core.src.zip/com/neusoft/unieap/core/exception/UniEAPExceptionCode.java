package com.neusoft.unieap.core.exception;

public class UniEAPExceptionCode
{
  protected static final String _EXCEPATION_CODE_PREFIX = "EAP";
  protected static final String _TECHCOMP_CODE = "TECH";
  protected static final String _BIZCOMP_CODE = "BIZ";
  protected static final String _ORGANIZATION_CODE = "ORG";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPExceptionCode
 * JD-Core Version:    0.6.2
 */