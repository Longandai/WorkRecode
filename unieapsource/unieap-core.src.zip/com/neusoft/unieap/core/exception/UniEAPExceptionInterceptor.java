/*     */ package com.neusoft.unieap.core.exception;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.UniEAPContext;
/*     */ import com.neusoft.unieap.core.context.UniEAPContextHolder;
/*     */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*     */ import com.neusoft.unieap.core.context.properties.User;
/*     */ import com.neusoft.unieap.core.exception.bo.TraceMessageBO;
/*     */ import com.neusoft.unieap.core.exception.bo.TraceMessageBOFactory;
/*     */ import com.neusoft.unieap.core.exception.entity.TraceMessage;
/*     */ import com.neusoft.unieap.core.validation.exception.ValidationException;
/*     */ import com.opensymphony.xwork2.ActionInvocation;
/*     */ import com.opensymphony.xwork2.ActionProxy;
/*     */ import com.opensymphony.xwork2.config.entities.ActionConfig;
/*     */ import com.opensymphony.xwork2.config.entities.ExceptionMappingConfig;
/*     */ import com.opensymphony.xwork2.interceptor.ExceptionMappingInterceptor;
/*     */ import com.opensymphony.xwork2.util.ValueStack;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.Serializable;
/*     */ import java.io.Writer;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.servlet.http.HttpServletRequest;
/*     */ import javax.servlet.http.HttpServletResponse;
/*     */ import javax.validation.ConstraintViolation;
/*     */ import net.sf.json.JSONObject;
/*     */ import org.apache.struts2.ServletActionContext;
/*     */ import org.apache.struts2.dispatcher.multipart.MultiPartRequestWrapper;
/*     */ 
/*     */ public class UniEAPExceptionInterceptor extends ExceptionMappingInterceptor
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private static final String globalExceptionResult = "uniEAPExceptionError";
/*     */   private static final String callBackFlag = "exceptionHandler";
/*  49 */   private boolean persistence = false;
/*     */ 
/*     */   public UniEAPExceptionInterceptor() {
/*  52 */     this.persistence = false;
/*     */   }
/*     */ 
/*     */   public boolean isPersistence() {
/*  56 */     return this.persistence;
/*     */   }
/*     */ 
/*     */   public void setPersistence(boolean paramBoolean) {
/*  60 */     this.persistence = paramBoolean;
/*     */   }
/*     */ 
/*     */   public String intercept(ActionInvocation paramActionInvocation)
/*     */     throws Exception
/*     */   {
/*  69 */     String str1 = null;
/*     */     try {
/*  71 */       str1 = paramActionInvocation.invoke();
/*     */     }
/*     */     catch (Exception localException1) {
/*     */       try {
/*  75 */         UniEAPExceptionHolder localUniEAPExceptionHolder = new UniEAPExceptionHolder(
/*  76 */           localException1);
/*     */ 
/*  81 */         if (isPersistence()) {
/*  82 */           doPersistence(localUniEAPExceptionHolder);
/*     */         }
/*     */ 
/*  87 */         if ((localException1 instanceof IOException))
/*     */         {
/*  91 */           if (localException1
/*  89 */             .getClass()
/*  90 */             .getCanonicalName()
/*  91 */             .equals(
/*  92 */             "org.apache.catalina.connector.ClientAbortException"))
/*     */           {
/*  94 */             if ("true"
/*  94 */               .equals(
/*  95 */               ServletActionContext.getRequest()
/*  96 */               .getAttribute(
/*  97 */               "eap_non_Json_Return_Type"))) {
/*  98 */               localException1.printStackTrace();
/*  99 */               return null;
/*     */             }
/*     */           }
/*     */         }
/* 101 */         if (isAjaxRequest())
/* 102 */           writeAjaxRequesException(localException1);
/*     */         else {
/* 104 */           return dealNoAjaxRequest(paramActionInvocation, 
/* 105 */             localUniEAPExceptionHolder);
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (Exception localException2)
/*     */       {
/* 114 */         String str2 = localException1.getClass().getName();
/* 115 */         String[] arrayOfString = { str2 };
/* 116 */         UniEAPException localUniEAPException = new UniEAPException(
/* 117 */           "EAPTECH002001", localException2, arrayOfString);
/* 118 */         if (isAjaxRequest()) {
/* 119 */           writeAjaxRequesException(localUniEAPException);
/*     */         } else {
/* 121 */           publishException(paramActionInvocation, new UniEAPExceptionHolder(
/* 122 */             localUniEAPException));
/* 123 */           return "uniEAPExceptionError";
/*     */         }
/*     */       }
/*     */     }
/* 127 */     return str1;
/*     */   }
/*     */ 
/*     */   private void uniEAPExceptionCallBack(List paramList, Exception paramException)
/*     */     throws UniEAPException
/*     */   {
/* 140 */     ExceptionMappingConfig localExceptionMappingConfig = getExceptionConfigMap(
/* 141 */       paramList, paramException);
/* 142 */     if (localExceptionMappingConfig != null) {
/* 143 */       Map localMap = localExceptionMappingConfig.getParams();
/* 144 */       String str1 = 
/* 145 */         (String)localMap
/* 145 */         .get("exceptionHandler");
/*     */ 
/* 147 */       if ((str1 != null) && (!"".equals(str1)))
/*     */         try {
/* 149 */           UniEAPExceptionHandler localUniEAPExceptionHandler = 
/* 150 */             (UniEAPExceptionHandler)Class.forName(str1).newInstance();
/* 151 */           localUniEAPExceptionHandler.handle(paramException, 
/* 152 */             localMap);
/*     */         }
/*     */         catch (Exception localException) {
/* 155 */           String str2 = localException.getClass().getName();
/* 156 */           String[] arrayOfString = { str2, str1 };
/* 157 */           throw new UniEAPSystemException(
/* 158 */             "EAPTECH002002", localException, arrayOfString);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private ExceptionMappingConfig getExceptionConfigMap(List paramList, Throwable paramThrowable)
/*     */   {
/* 173 */     Object localObject = null;
/* 174 */     if (paramList != null) {
/* 175 */       int i = 2147483647;
/*     */ 
/* 177 */       for (int j = 0; j < paramList.size(); j++) {
/* 178 */         ExceptionMappingConfig localExceptionMappingConfig = 
/* 179 */           (ExceptionMappingConfig)paramList
/* 179 */           .get(j);
/*     */ 
/* 181 */         int k = getDepth(localExceptionMappingConfig
/* 182 */           .getExceptionClassName(), paramThrowable);
/* 183 */         if ((k >= 0) && (k < i)) {
/* 184 */           i = k;
/* 185 */           localObject = localExceptionMappingConfig;
/*     */         }
/*     */       }
/*     */ 
/* 189 */       if (i != 0) {
/* 190 */         localObject = null;
/*     */       }
/*     */     }
/* 193 */     return localObject;
/*     */   }
/*     */ 
/*     */   protected void publishException(ActionInvocation paramActionInvocation, UniEAPExceptionHolder paramUniEAPExceptionHolder)
/*     */   {
/* 204 */     paramActionInvocation.getStack().push(paramUniEAPExceptionHolder);
/*     */   }
/*     */ 
/*     */   private boolean isAjaxRequest()
/*     */     throws Exception
/*     */   {
/* 213 */     HttpServletRequest localHttpServletRequest = ServletActionContext.getRequest();
/*     */ 
/* 215 */     return ("true".equalsIgnoreCase(localHttpServletRequest.getHeader("ajaxRequest"))) || 
/* 215 */       ("true".equalsIgnoreCase(localHttpServletRequest.getParameter("ajaxRequest")));
/*     */   }
/*     */ 
/*     */   private void writeAjaxRequesException(Exception paramException)
/*     */     throws Exception
/*     */   {
/* 225 */     UniEAPExceptionHolder localUniEAPExceptionHolder = new UniEAPExceptionHolder(paramException);
/* 226 */     String str = generateExceptionResult(localUniEAPExceptionHolder);
/* 227 */     HttpServletRequest localHttpServletRequest = 
/* 228 */       ServletActionContext.getRequest();
/* 229 */     HttpServletResponse localHttpServletResponse = ServletActionContext.getResponse();
/* 230 */     if ((localHttpServletRequest instanceof MultiPartRequestWrapper)) {
/* 231 */       localObject1 = new StringBuffer();
/* 232 */       ((StringBuffer)localObject1).append("<textarea>");
/* 233 */       ((StringBuffer)localObject1).append(str);
/* 234 */       ((StringBuffer)localObject1).append("</textarea>");
/* 235 */       str = ((StringBuffer)localObject1).toString();
/*     */     }
/* 237 */     Object localObject1 = null;
/*     */     try
/*     */     {
/* 240 */       localObject1 = new BufferedWriter(new OutputStreamWriter(localHttpServletResponse
/* 241 */         .getOutputStream(), "UTF-8"), 4194304);
/* 242 */       ((Writer)localObject1).write(str);
/* 243 */       ((Writer)localObject1).flush();
/*     */     } catch (Exception localException) {
/* 245 */       throw new UniEAPSystemException("EAPTECH002003", 
/* 246 */         localException, null);
/*     */     } finally {
/* 248 */       if (localObject1 != null)
/* 249 */         ((Writer)localObject1).close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private String generateExceptionResult(UniEAPExceptionHolder paramUniEAPExceptionHolder)
/*     */   {
/* 262 */     String str = "{header:{\"code\": -1,\"message\":{\"title\": \"\",\"detail\": \"\"}},body: {parameters:{},dataStores:{}}}";
/*     */ 
/* 264 */     JSONObject localJSONObject1 = JSONObject.fromObject(str);
/*     */ 
/* 266 */     if (UnieapRequestContextHolder.getRequestContext().containsKey(
/* 267 */       "_testMethodId")) {
/* 268 */       localJSONObject2 = localJSONObject1.getJSONObject("body")
/* 269 */         .getJSONObject("parameters");
/* 270 */       localJSONObject2.put("_methodId", 
/* 271 */         UnieapRequestContextHolder.getRequestContext().get("_testMethodId"));
/* 272 */       localJSONObject2.put("_sessionVarString", 
/* 273 */         UnieapRequestContextHolder.getRequestContext().get("_sessionVarString"));
/* 274 */       localJSONObject2.put("_requestVarString", 
/* 275 */         UnieapRequestContextHolder.getRequestContext().get("_requestVarString"));
/*     */     }
/* 277 */     JSONObject localJSONObject2 = localJSONObject1.getJSONObject("header").getJSONObject(
/* 278 */       "message");
/* 279 */     localJSONObject2.put("title", paramUniEAPExceptionHolder.getExceptionMessage());
/* 280 */     localJSONObject2.put("detail", paramUniEAPExceptionHolder.getExceptionStack());
/* 281 */     JSONObject localJSONObject3 = localJSONObject1.getJSONObject("header");
/* 282 */     Exception localException = paramUniEAPExceptionHolder.getException();
/* 283 */     Object localObject1 = localException;
/* 284 */     if (localException.getCause() != null) {
/* 285 */       localObject1 = localException.getCause();
/*     */     }
/* 287 */     if ((localObject1 instanceof UniEAPException))
/*     */     {
/*     */       Object localObject2;
/*     */       Object localObject3;
/*     */       Object localObject4;
/* 288 */       if ((localObject1 instanceof ValidationException)) {
/* 289 */         if ((((ValidationException)localObject1).isLogEnabled()) && 
/* 290 */           (isLogEnabled())) {
/* 291 */           handleLogging(localException);
/*     */         }
/* 293 */         localObject2 = (ValidationException)localObject1;
/* 294 */         localJSONObject3.put("code", "-2");
/* 295 */         localObject3 = ((ValidationException)localObject2).getAttributes();
/* 296 */         if (!((Map)localObject3).isEmpty())
/*     */         {
/* 298 */           localObject4 = ((Map)localObject3).entrySet().iterator();
/* 299 */           HashMap localHashMap = new HashMap();
/* 300 */           while (((Iterator)localObject4).hasNext()) {
/* 301 */             Map.Entry localEntry = (Map.Entry)((Iterator)localObject4).next();
/* 302 */             Set localSet = (Set)localEntry.getValue();
/* 303 */             Iterator localIterator = localSet.iterator();
/* 304 */             while (localIterator.hasNext()) {
/* 305 */               ConstraintViolation localConstraintViolation = 
/* 306 */                 (ConstraintViolation)localIterator
/* 306 */                 .next();
/* 307 */               localHashMap.put(localConstraintViolation
/* 308 */                 .getPropertyPath().toString(), 
/* 309 */                 localConstraintViolation.getMessage());
/*     */             }
/* 311 */             localJSONObject3.put(localEntry.getKey(), localHashMap);
/*     */           }
/*     */         }
/*     */       } else {
/* 315 */         if ((localObject1 instanceof UniEAPBusinessException)) {
/* 316 */           if ((((UniEAPBusinessException)localObject1).isLogEnabled()) && 
/* 317 */             (isLogEnabled()))
/*     */           {
/* 319 */             handleLogging(localException);
/*     */           }
/* 321 */           localJSONObject3.put("code", "-2");
/* 322 */         } else if (isLogEnabled()) {
/* 323 */           handleLogging(localException);
/*     */         }
/* 325 */         localObject2 = ((UniEAPException)localObject1).getAttributes();
/* 326 */         if (!((Map)localObject2).isEmpty()) {
/* 327 */           localObject3 = ((Map)localObject2).entrySet().iterator();
/* 328 */           while (((Iterator)localObject3).hasNext()) {
/* 329 */             localObject4 = (Map.Entry)((Iterator)localObject3).next();
/* 330 */             localJSONObject3.put(((Map.Entry)localObject4).getKey(), ((Map.Entry)localObject4).getValue());
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 335 */     else if (isLogEnabled()) {
/* 336 */       handleLogging(localException);
/*     */     }
/*     */ 
/* 339 */     return localJSONObject1.toString();
/*     */   }
/*     */ 
/*     */   private Serializable doPersistence(UniEAPExceptionHolder paramUniEAPExceptionHolder)
/*     */     throws Exception
/*     */   {
/* 350 */     Exception localException = paramUniEAPExceptionHolder.getException();
/* 351 */     TraceMessage localTraceMessage = new TraceMessage();
/* 352 */     if ((localException instanceof UniEAPException)) {
/* 353 */       localTraceMessage.setCode(((UniEAPException)localException).getCode());
/*     */     }
/* 355 */     String str1 = paramUniEAPExceptionHolder.getExceptionMessage();
/* 356 */     if ((str1 != null) && (str1.getBytes().length > 500)) {
/* 357 */       str1 = splitChineseInUtf8Code(str1, 500);
/*     */     }
/* 359 */     localTraceMessage.setMessage(str1);
/* 360 */     String str2 = paramUniEAPExceptionHolder.getExceptionStack();
/* 361 */     if ((str2 != null) && (str2.getBytes().length > 2000)) {
/* 362 */       str2 = splitChineseInUtf8Code(str2, 2000);
/*     */     }
/* 364 */     localTraceMessage.setStackMessage(str2);
/* 365 */     User localUser = UniEAPContextHolder.getContext().getCurrentUser();
/* 366 */     if (localUser != null) {
/* 367 */       localTraceMessage.setCreatorId(localUser.getAccount());
/* 368 */       localObject = localUser.getName();
/* 369 */       localTraceMessage.setCreatorName(localObject == null ? localUser
/* 370 */         .getAccount() : (String)localObject);
/*     */     }
/* 372 */     Object localObject = new Timestamp(System.currentTimeMillis());
/* 373 */     localTraceMessage.setCreatedTime((Timestamp)localObject);
/* 374 */     TraceMessageBO localTraceMessageBO = 
/* 375 */       TraceMessageBOFactory.getTraceMessageBo();
/* 376 */     return localTraceMessageBO.saveTraceMessage(localTraceMessage);
/*     */   }
/*     */ 
/*     */   private String dealNoAjaxRequest(ActionInvocation paramActionInvocation, UniEAPExceptionHolder paramUniEAPExceptionHolder)
/*     */   {
/* 388 */     String str = null;
/* 389 */     publishException(paramActionInvocation, paramUniEAPExceptionHolder);
/* 390 */     Exception localException = paramUniEAPExceptionHolder.getException();
/* 391 */     ActionProxy localActionProxy = paramActionInvocation.getProxy();
/* 392 */     ActionConfig localActionConfig = localActionProxy.getConfig();
/* 393 */     List localList = localActionConfig.getExceptionMappings();
/* 394 */     ExceptionMappingConfig localExceptionMappingConfig = getExceptionConfigMap(
/* 395 */       localList, localException);
/* 396 */     uniEAPExceptionCallBack(localList, localException);
/*     */     UniEAPException localUniEAPException;
/* 397 */     if (localExceptionMappingConfig == null)
/*     */     {
/* 399 */       if ((localException instanceof UniEAPException)) {
/* 400 */         localUniEAPException = (UniEAPException)localException;
/*     */ 
/* 402 */         if (((localUniEAPException instanceof UniEAPBusinessException)) && 
/* 403 */           (((UniEAPBusinessException)localUniEAPException).isLogEnabled()) && 
/* 404 */           (isLogEnabled()))
/* 405 */           handleLogging(localUniEAPException);
/* 406 */         str = "input";
/*     */       } else {
/* 408 */         str = "uniEAPExceptionError";
/*     */       }
/* 410 */       return str;
/*     */     }
/* 412 */     if ((localException instanceof UniEAPException)) {
/* 413 */       localUniEAPException = (UniEAPException)localException;
/*     */ 
/* 415 */       if (((localUniEAPException instanceof UniEAPBusinessException)) && 
/* 416 */         (((UniEAPBusinessException)localUniEAPException).isLogEnabled()) && 
/* 417 */         (isLogEnabled()))
/* 418 */         handleLogging(localUniEAPException);
/* 419 */       Map localMap = localExceptionMappingConfig.getParams();
/* 420 */       if (localMap.get(localUniEAPException.getCode()) != null)
/* 421 */         str = (String)localMap.get(localUniEAPException.getCode());
/*     */       else
/* 423 */         str = localExceptionMappingConfig.getResult();
/*     */     }
/*     */     else {
/* 426 */       if (isLogEnabled()) {
/* 427 */         handleLogging(localException);
/*     */       }
/* 429 */       str = localExceptionMappingConfig.getResult();
/*     */     }
/* 431 */     return str;
/*     */   }
/*     */ 
/*     */   private String splitChineseInUtf8Code(String paramString, int paramInt)
/*     */     throws Exception
/*     */   {
/* 441 */     int i = paramInt - 1;
/* 442 */     if ((paramString == null) || ("".equals(paramString.trim()))) {
/* 443 */       return paramString;
/*     */     }
/* 445 */     if (i <= 0) {
/* 446 */       return paramString;
/*     */     }
/* 448 */     byte[] arrayOfByte = paramString.getBytes("UTF-8");
/* 449 */     if (arrayOfByte == null) {
/* 450 */       return paramString;
/*     */     }
/* 452 */     if (i > arrayOfByte.length - 1) {
/* 453 */       i = arrayOfByte.length - 1;
/*     */     }
/*     */ 
/* 456 */     if (arrayOfByte[i] < 0) {
/* 457 */       int j = 0;
/* 458 */       int k = i;
/* 459 */       while (k >= 0) {
/* 460 */         if (arrayOfByte[k] >= 0) break;
/* 461 */         j++;
/*     */ 
/* 465 */         k--;
/*     */       }
/* 467 */       int m = 0;
/*     */ 
/* 469 */       m = j % 3;
/* 470 */       i -= m;
/*     */ 
/* 472 */       String str2 = null;
/* 473 */       str2 = new String(arrayOfByte, 0, i + 1, "UTF-8");
/* 474 */       return str2;
/*     */     }
/*     */ 
/* 477 */     String str1 = null;
/* 478 */     str1 = new String(arrayOfByte, 0, i + 1, "UTF-8");
/* 479 */     return str1;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPExceptionInterceptor
 * JD-Core Version:    0.6.2
 */