package com.neusoft.unieap.core.exception;

public class ExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "002";
  private static final String _P = "EAPTECH002";
  public static final String HANDLER_ERROR = "EAPTECH002001";
  public static final String CALLBACK_ERROR = "EAPTECH002002";
  public static final String WRITE_AJAXEx_ERROR = "EAPTECH002003";
  public static final String INPUT_UNIEAPEX_ERROR = "EAPTECH002004";
  public static final String EX_I18NPARAMETERS_ERROR = "EAPTECH002005";
  public static final String EX_I18NRESOURCE_ERROR = "EAPTECH002006";
  public static final String VARIABILITY_UNDEFINED = "EAPTECH002007";
  public static final String UNLOAD_VARIABILITY = "EAPTECH002008";
  public static final String VARIABILITY_UNABLETRANS2INT = "EAPTECH002009";
  public static final String VARIABILITY_UNABLETRANS2BOOLEAN = "EAPTECH002010";
  public static final String VARIABILITY_UNABLETRANS2DOUBLE = "EAPTECH002011";
  public static final String VARIABILITY_UNABLETRANS2FLOAT = "EAPTECH002012";
  public static final String VARIABILITY_UNABLETRANS2LONG = "EAPTECH002013";
  public static final String VARIABILITY_UNABLETRANS2SHORT = "EAPTECH002014";
  public static final String VARIABILITY_UNABLETRANS2DATE = "EAPTECH002015";
  public static final String VARIABILITY_ILLEGALARGUMENT = "EAPTECH002016";
  public static final String EXCEPTION_SWICH_IS_CLOSE = "EAPTECH002017";
  public static final String FOUND_DC_FAILURE = "EAPTECH002018";
  public static final String NOT_FOUND_CLASS_FROM_DC = "EAPTECH002019";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.ExceptionCode
 * JD-Core Version:    0.6.2
 */