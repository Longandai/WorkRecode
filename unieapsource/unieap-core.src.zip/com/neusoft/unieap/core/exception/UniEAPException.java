/*     */ package com.neusoft.unieap.core.exception;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.GlobalService;
/*     */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*     */ import java.io.File;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class UniEAPException extends RuntimeException
/*     */ {
/*     */   private static final long serialVersionUID = -1674748351212410327L;
/*  28 */   public String WEB_INFO = "WEB-INF" + File.separator;
/*     */ 
/*  32 */   public String BUSSINESS_EXCEPTION_FOLDER = "conf" + File.separator + 
/*  31 */     "platform" + File.separator + "core" + File.separator + 
/*  32 */     "exception" + File.separator;
/*     */ 
/*  34 */   public String BUSSINESS_EXCEPTION_FILE_NAME = "Exception";
/*  35 */   protected static final Properties exceptionLocale4CountryProperties = new Properties();
/*  36 */   protected static final Properties exceptionLocale4LanguageProperties = new Properties();
/*  37 */   protected static final Properties exceptionLocaleProperties = new Properties();
/*     */ 
/*  39 */   protected static final Logger logger = LoggerFactory.getLogger(UniEAPException.class);
/*     */   private String code;
/*     */   private Object[] args;
/*     */   private String message;
/*  56 */   private Map attributeMap = new HashMap();
/*     */ 
/*     */   public UniEAPException(String paramString, Object[] paramArrayOfObject)
/*     */   {
/*  68 */     this.code = paramString;
/*  69 */     this.args = paramArrayOfObject;
/*     */   }
/*     */ 
/*     */   public UniEAPException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*     */   {
/*  83 */     super(paramThrowable);
/*  84 */     this.code = paramString;
/*  85 */     this.args = paramArrayOfObject;
/*     */   }
/*     */ 
/*     */   public String getCode()
/*     */   {
/*  94 */     return this.code;
/*     */   }
/*     */ 
/*     */   public Object[] getArgs()
/*     */   {
/* 103 */     return this.args;
/*     */   }
/*     */ 
/*     */   public String getExceptionMessage()
/*     */   {
/* 110 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void setExceptionMessage(String paramString)
/*     */   {
/* 119 */     this.message = paramString;
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 129 */     if (getExceptionMessage() != null) {
/* 130 */       return getCode() + ":" + getExceptionMessage();
/*     */     }
/* 132 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/* 133 */     return getCode() + ":" + getI18nInfo(this, localLocale);
/*     */   }
/*     */ 
/*     */   public String getLocalizedMessage()
/*     */   {
/* 142 */     String str = getCode();
/* 143 */     str = str + ":";
/* 144 */     if (getExceptionMessage() != null)
/* 145 */       return str + getExceptionMessage();
/* 146 */     Locale localLocale = GlobalService.getUserI18nContext().getLocale();
/*     */ 
/* 156 */     return str + getI18nInfo(this, localLocale);
/*     */   }
/*     */ 
/*     */   protected String getI18nInfo(UniEAPException paramUniEAPException, Locale paramLocale) {
/* 160 */     LocalizedTextUtil localLocalizedTextUtil = 
/* 161 */       LocalizedTextUtil.getLocalizedTextUtil(paramUniEAPException.getClass());
/* 162 */     if (paramUniEAPException.getArgs() == null) {
/* 163 */       return localLocalizedTextUtil
/* 164 */         .findText(paramUniEAPException.getCode(), paramLocale);
/*     */     }
/* 166 */     return localLocalizedTextUtil.findText(paramUniEAPException.getCode(), 
/* 167 */       paramUniEAPException.getArgs(), paramLocale);
/*     */   }
/*     */ 
/*     */   public void putAttribute(Object paramObject1, Object paramObject2)
/*     */   {
/* 179 */     this.attributeMap.put(paramObject1, paramObject2);
/*     */   }
/*     */ 
/*     */   public Object getAttribute(Object paramObject)
/*     */   {
/* 190 */     return this.attributeMap.get(paramObject);
/*     */   }
/*     */ 
/*     */   public Map getAttributes()
/*     */   {
/* 199 */     return this.attributeMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPException
 * JD-Core Version:    0.6.2
 */