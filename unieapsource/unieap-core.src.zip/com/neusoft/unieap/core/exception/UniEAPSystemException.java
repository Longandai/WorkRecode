/*    */ package com.neusoft.unieap.core.exception;
/*    */ 
/*    */ public class UniEAPSystemException extends UniEAPException
/*    */ {
/*    */   private static final long serialVersionUID = 3025244890081728349L;
/*    */ 
/*    */   public UniEAPSystemException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 17 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public UniEAPSystemException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 26 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPSystemException
 * JD-Core Version:    0.6.2
 */