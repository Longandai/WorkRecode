package com.neusoft.unieap.core.exception.bo;

import com.neusoft.unieap.core.exception.entity.TraceMessage;
import java.io.Serializable;
import java.util.List;

public abstract interface TraceMessageBO extends Serializable
{
  public abstract TraceMessage getTraceMessageById(String paramString);

  public abstract Serializable saveTraceMessage(TraceMessage paramTraceMessage);

  public abstract void deleteTraceMessages(List paramList);

  public abstract int clearTraceMessages();
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.bo.TraceMessageBO
 * JD-Core Version:    0.6.2
 */