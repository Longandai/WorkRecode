/*    */ package com.neusoft.unieap.core.exception.bo;
/*    */ 
/*    */ public class TraceMessageBOFactory
/*    */ {
/*  7 */   private static TraceMessageBO traceMessageBo = null;
/*    */ 
/*    */   public static TraceMessageBO getTraceMessageBo() {
/* 10 */     return traceMessageBo;
/*    */   }
/*    */ 
/*    */   public void setTraceMessageBo(TraceMessageBO paramTraceMessageBO) {
/* 14 */     traceMessageBo = paramTraceMessageBO;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.bo.TraceMessageBOFactory
 * JD-Core Version:    0.6.2
 */