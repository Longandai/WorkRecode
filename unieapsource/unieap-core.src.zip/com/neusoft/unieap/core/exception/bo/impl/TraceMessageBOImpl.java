/*    */ package com.neusoft.unieap.core.exception.bo.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.CoreVariability;
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ import com.neusoft.unieap.core.exception.bo.TraceMessageBO;
/*    */ import com.neusoft.unieap.core.exception.dao.TraceMessageDAO;
/*    */ import com.neusoft.unieap.core.exception.entity.TraceMessage;
/*    */ import java.io.Serializable;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TraceMessageBOImpl
/*    */   implements TraceMessageBO
/*    */ {
/*    */   private static final long serialVersionUID = -3259304986606638698L;
/* 17 */   private TraceMessageDAO traceMessageDAO = null;
/*    */ 
/*    */   public void setTraceMessageDAO(TraceMessageDAO paramTraceMessageDAO) {
/* 20 */     this.traceMessageDAO = paramTraceMessageDAO;
/*    */   }
/*    */ 
/*    */   public void deleteTraceMessages(List paramList) {
/* 24 */     this.traceMessageDAO.deleteTraceMessages(paramList);
/*    */   }
/*    */ 
/*    */   public TraceMessage getTraceMessageById(String paramString) {
/* 28 */     if (!CoreVariability.isShowStack()) {
/* 29 */       throw new UniEAPBusinessException("EAPTECH002017", null);
/*    */     }
/* 31 */     return this.traceMessageDAO.getTraceMessageById(paramString);
/*    */   }
/*    */ 
/*    */   public Serializable saveTraceMessage(TraceMessage paramTraceMessage) {
/* 35 */     return this.traceMessageDAO.saveTraceMessage(paramTraceMessage);
/*    */   }
/*    */ 
/*    */   public int clearTraceMessages()
/*    */   {
/* 43 */     return this.traceMessageDAO.clearTraceMessages();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.bo.impl.TraceMessageBOImpl
 * JD-Core Version:    0.6.2
 */