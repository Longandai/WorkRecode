package com.neusoft.unieap.core.exception;

import java.util.Map;

public abstract interface UniEAPExceptionHandler
{
  public abstract void handle(Exception paramException, Map paramMap);
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPExceptionHandler
 * JD-Core Version:    0.6.2
 */