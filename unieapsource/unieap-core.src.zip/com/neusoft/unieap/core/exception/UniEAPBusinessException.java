/*     */ package com.neusoft.unieap.core.exception;
/*     */ 
/*     */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*     */ import com.neusoft.unieap.core.validation.i18n.I18nGlobalContext;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import javax.servlet.ServletContext;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.slf4j.Logger;
/*     */ 
/*     */ public class UniEAPBusinessException extends UniEAPException
/*     */ {
/*     */   private static final long serialVersionUID = -5342881450881056176L;
/*  36 */   private boolean isLogEnabled = false;
/*     */ 
/*     */   public UniEAPBusinessException(String code, Object[] args)
/*     */   {
/*  47 */     super(code, args);
/*     */   }
/*     */ 
/*     */   public UniEAPBusinessException(String code, Object[] args, boolean isLogEnabled)
/*     */   {
/*  62 */     super(code, args);
/*  63 */     this.isLogEnabled = isLogEnabled;
/*     */   }
/*     */ 
/*     */   public UniEAPBusinessException(String code)
/*     */   {
/*  73 */     super(code, null);
/*     */   }
/*     */ 
/*     */   public UniEAPBusinessException(String code, boolean isLogEnabled)
/*     */   {
/*  85 */     super(code, null);
/*  86 */     this.isLogEnabled = isLogEnabled;
/*     */   }
/*     */ 
/*     */   public UniEAPBusinessException(String code, Throwable cause, Object[] args)
/*     */   {
/* 100 */     super(code, cause, args);
/*     */   }
/*     */ 
/*     */   public UniEAPBusinessException(String code, Throwable cause, Object[] args, boolean isLogEnabled)
/*     */   {
/* 117 */     super(code, cause, args);
/* 118 */     this.isLogEnabled = isLogEnabled;
/*     */   }
/*     */ 
/*     */   public boolean isLogEnabled()
/*     */   {
/* 127 */     return this.isLogEnabled;
/*     */   }
/*     */ 
/*     */   protected String getI18nInfo(UniEAPException uniEAPException, Locale locale)
/*     */   {
/* 132 */     ServletContext servletContext = I18nGlobalContext.getInstance()
/* 133 */       .getServletContext();
/*     */ 
/* 138 */     String exceptionFolderPath = "";
/*     */ 
/* 140 */     Object[] args = uniEAPException.getArgs();
/* 141 */     if (args == null) {
/* 142 */       args = new Object[0];
/*     */     }
/*     */     try
/*     */     {
/* 146 */       if (exceptionLocale4CountryProperties != null)
/*     */       {
/* 148 */         if (exceptionLocale4CountryProperties
/* 148 */           .containsKey(uniEAPException.getCode()))
/* 149 */           return buildMessageFormat(exceptionLocale4CountryProperties
/* 150 */             .getProperty(uniEAPException.getCode()), args, locale); 
/*     */       }
/* 151 */       if (exceptionLocale4LanguageProperties != null)
/*     */       {
/* 153 */         if (exceptionLocale4LanguageProperties
/* 153 */           .containsKey(uniEAPException.getCode()))
/* 154 */           return buildMessageFormat(exceptionLocale4LanguageProperties
/* 155 */             .getProperty(uniEAPException.getCode()), args, locale); 
/*     */       }
/* 156 */       if ((exceptionLocaleProperties != null) && 
/* 157 */         (exceptionLocaleProperties.containsKey(uniEAPException
/* 158 */         .getCode()))) {
/* 159 */         return buildMessageFormat(exceptionLocaleProperties
/* 160 */           .getProperty(uniEAPException.getCode()), args, locale);
/*     */       }
/* 162 */       exceptionFolderPath = this.WEB_INFO + this.BUSSINESS_EXCEPTION_FOLDER;
/* 163 */       String realPath = servletContext.getRealPath(File.separator);
/*     */ 
/* 166 */       InputStream exceptionIn = servletContext
/* 167 */         .getResourceAsStream(exceptionFolderPath + 
/* 168 */         this.BUSSINESS_EXCEPTION_FILE_NAME + "_" + 
/* 169 */         locale.toString() + ".properties");
/*     */ 
/* 172 */       File exceptionFile = null;
/* 173 */       if (exceptionIn == null) {
/* 174 */         exceptionFile = new File(
/* 175 */           (realPath.endsWith(File.separator) ? realPath : 
/* 176 */           new StringBuilder(String.valueOf(realPath)).append(File.separator).toString()) + 
/* 177 */           exceptionFolderPath + 
/* 178 */           this.BUSSINESS_EXCEPTION_FILE_NAME + 
/* 179 */           "_" + 
/* 180 */           locale.toString() + ".properties");
/* 181 */         if (exceptionFile.exists()) {
/* 182 */           exceptionIn = FileUtils.openInputStream(exceptionFile);
/*     */         }
/*     */       }
/*     */ 
/* 186 */       String message = null;
/*     */ 
/* 188 */       if (exceptionIn != null) {
/* 189 */         message = loadExceptionProperties(
/* 190 */           exceptionLocale4CountryProperties, exceptionIn, 
/* 191 */           uniEAPException.getCode(), args, locale);
/*     */       }
/*     */ 
/* 194 */       if (message == null) {
/* 195 */         exceptionIn = servletContext
/* 196 */           .getResourceAsStream(exceptionFolderPath + 
/* 197 */           this.BUSSINESS_EXCEPTION_FILE_NAME + "_" + 
/* 198 */           locale.getLanguage() + ".properties");
/* 199 */         if (exceptionIn == null) {
/* 200 */           exceptionFile = new File(
/* 201 */             (realPath.endsWith(File.separator) ? realPath : 
/* 202 */             new StringBuilder(String.valueOf(realPath)).append(File.separator).toString()) + 
/* 203 */             exceptionFolderPath + 
/* 204 */             this.BUSSINESS_EXCEPTION_FILE_NAME + 
/* 205 */             "_" + 
/* 206 */             locale.getLanguage() + ".properties");
/* 207 */           if (exceptionFile.exists()) {
/* 208 */             exceptionIn = FileUtils.openInputStream(exceptionFile);
/*     */           }
/*     */         }
/* 211 */         if (exceptionIn != null) {
/* 212 */           message = loadExceptionProperties(
/* 213 */             exceptionLocale4LanguageProperties, exceptionIn, 
/* 214 */             uniEAPException.getCode(), args, locale);
/*     */         }
/*     */       }
/*     */ 
/* 218 */       if (message == null) {
/* 219 */         exceptionIn = servletContext
/* 220 */           .getResourceAsStream(exceptionFolderPath + 
/* 221 */           this.BUSSINESS_EXCEPTION_FILE_NAME + ".properties");
/* 222 */         if (exceptionIn == null) {
/* 223 */           exceptionFile = new File(
/* 224 */             (realPath.endsWith(File.separator) ? realPath : 
/* 225 */             new StringBuilder(String.valueOf(realPath)).append(File.separator).toString()) + 
/* 226 */             exceptionFolderPath + 
/* 227 */             this.BUSSINESS_EXCEPTION_FILE_NAME + 
/* 228 */             ".properties");
/* 229 */           if (exceptionFile.exists()) {
/* 230 */             exceptionIn = FileUtils.openInputStream(exceptionFile);
/*     */           }
/*     */         }
/* 233 */         if (exceptionIn != null) {
/* 234 */           message = loadExceptionProperties(
/* 235 */             exceptionLocaleProperties, exceptionIn, 
/* 236 */             uniEAPException.getCode(), args, locale);
/*     */         }
/*     */       }
/* 239 */       if (message != null)
/* 240 */         return message;
/*     */     }
/*     */     catch (Exception e) {
/* 243 */       if (uniEAPException.getCode() == null)
/* 244 */         logger
/* 245 */           .error(
/* 246 */           "UnieapBusinessException异常码为null，请检查抛出该异常的构造函数是否正确。", 
/* 247 */           e);
/*     */       else {
/* 249 */         logger.error("UnieapBusinessException初始化失败。", e);
/*     */       }
/*     */     }
/*     */ 
/* 253 */     return super.getI18nInfo(uniEAPException, locale);
/*     */   }
/*     */ 
/*     */   private String loadExceptionProperties(Properties properties, InputStream in, String exceptionCode, Object[] args, Locale locale)
/*     */   {
/* 269 */     if (properties == null)
/* 270 */       return null;
/*     */     try
/*     */     {
/* 273 */       properties.load(in);
/*     */     } catch (FileNotFoundException e) {
/* 275 */       return null;
/*     */     } catch (IOException e) {
/* 277 */       return null;
/*     */     }
/* 279 */     if ((properties != null) && (properties.containsKey(exceptionCode))) {
/* 280 */       return buildMessageFormat(properties.getProperty(exceptionCode), 
/* 281 */         args, locale);
/*     */     }
/* 283 */     return null;
/*     */   }
/*     */ 
/*     */   private String buildMessageFormat(String exceptionMessage, Object[] args, Locale locale)
/*     */   {
/* 296 */     MessageFormat mf = LocalizedTextUtil.buildMessageFormat(
/* 297 */       exceptionMessage, locale);
/* 298 */     if (args == null) {
/* 299 */       args = new Object[0];
/*     */     }
/* 301 */     for (int i = 0; i < args.length; i++) {
/* 302 */       if ((args[i] != null) && ((args[i] instanceof Long))) {
/* 303 */         args[i] = String.valueOf(args[i]);
/*     */       }
/*     */     }
/*     */ 
/* 307 */     return mf.format(args);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPBusinessException
 * JD-Core Version:    0.6.2
 */