/*    */ package com.neusoft.unieap.core.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.CoreVariability;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ public class UniEAPExceptionHolder
/*    */ {
/*    */   private Exception exception;
/*    */ 
/*    */   public UniEAPExceptionHolder(Exception paramException)
/*    */   {
/* 13 */     this.exception = paramException;
/*    */   }
/*    */ 
/*    */   public Exception getException() {
/* 17 */     return this.exception;
/*    */   }
/*    */ 
/*    */   public String getExceptionStack()
/*    */   {
/* 26 */     String str = null;
/* 27 */     if ((CoreVariability.isShowStack()) && (getException() != null)) {
/* 28 */       StringWriter localStringWriter = new StringWriter();
/* 29 */       PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
/*    */       try {
/* 31 */         getException().printStackTrace(localPrintWriter);
/* 32 */         str = localStringWriter.toString();
/*    */       } finally {
/*    */         try {
/* 35 */           localStringWriter.close();
/* 36 */           localPrintWriter.close();
/*    */         } catch (IOException localIOException1) {
/* 38 */           localIOException1.printStackTrace();
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 43 */     return str;
/*    */   }
/*    */ 
/*    */   public String getExceptionMessage()
/*    */   {
/* 52 */     return this.exception.getLocalizedMessage();
/*    */   }
/*    */ 
/*    */   public String getHtmlExceptionStack()
/*    */   {
/* 61 */     String str1 = "";
/* 62 */     String str2 = getExceptionStack();
/* 63 */     if (str2 != null) {
/* 64 */       str1 = str2.replaceAll("\\r\\n", "<br/>&nbsp&nbsp");
/*    */     }
/* 66 */     return str1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.UniEAPExceptionHolder
 * JD-Core Version:    0.6.2
 */