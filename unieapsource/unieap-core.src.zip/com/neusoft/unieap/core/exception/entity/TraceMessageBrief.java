/*    */ package com.neusoft.unieap.core.exception.entity;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.sql.Timestamp;
/*    */ 
/*    */ public class TraceMessageBrief
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String id;
/*    */   private String creatorId;
/*    */   private String creatorName;
/*    */   private Timestamp createdTime;
/*    */   private String code;
/*    */   private String message;
/*    */ 
/*    */   public String getCode()
/*    */   {
/* 35 */     return this.code;
/*    */   }
/*    */ 
/*    */   public void setCode(String paramString) {
/* 39 */     this.code = paramString;
/*    */   }
/*    */ 
/*    */   public String getMessage() {
/* 43 */     return this.message;
/*    */   }
/*    */ 
/*    */   public void setMessage(String paramString) {
/* 47 */     this.message = paramString;
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 51 */     return this.id;
/*    */   }
/*    */ 
/*    */   public void setId(String paramString) {
/* 55 */     this.id = paramString;
/*    */   }
/*    */ 
/*    */   public String getCreatorId() {
/* 59 */     return this.creatorId;
/*    */   }
/*    */ 
/*    */   public void setCreatorId(String paramString) {
/* 63 */     this.creatorId = paramString;
/*    */   }
/*    */ 
/*    */   public String getCreatorName() {
/* 67 */     return this.creatorName;
/*    */   }
/*    */ 
/*    */   public void setCreatorName(String paramString) {
/* 71 */     this.creatorName = paramString;
/*    */   }
/*    */ 
/*    */   public Timestamp getCreatedTime() {
/* 75 */     return this.createdTime;
/*    */   }
/*    */ 
/*    */   public void setCreatedTime(Timestamp paramTimestamp) {
/* 79 */     this.createdTime = paramTimestamp;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.entity.TraceMessageBrief
 * JD-Core Version:    0.6.2
 */