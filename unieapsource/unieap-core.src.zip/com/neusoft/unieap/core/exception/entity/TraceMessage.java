/*    */ package com.neusoft.unieap.core.exception.entity;
/*    */ 
/*    */ public class TraceMessage extends TraceMessageBrief
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String stackMessage;
/*    */ 
/*    */   public String getStackMessage()
/*    */   {
/* 13 */     return this.stackMessage;
/*    */   }
/*    */ 
/*    */   public void setStackMessage(String paramString) {
/* 17 */     this.stackMessage = paramString;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.exception.entity.TraceMessage
 * JD-Core Version:    0.6.2
 */