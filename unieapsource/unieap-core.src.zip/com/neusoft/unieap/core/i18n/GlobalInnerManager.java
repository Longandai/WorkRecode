/*     */ package com.neusoft.unieap.core.i18n;
/*     */ 
/*     */ import com.neusoft.unieap.core.CoreVariability;
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.i18n.dao.GlobalDAO;
/*     */ import com.neusoft.unieap.core.i18n.util.LocaleUtil;
/*     */ import com.neusoft.unieap.core.util.LocalizedTextUtil;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class GlobalInnerManager
/*     */ {
/*  18 */   private static final Logger logger = LoggerFactory.getLogger(GlobalService.class);
/*     */ 
/*  20 */   private static final LocalizedTextUtil localizedTextUtil = LocalizedTextUtil.getLocalizedTextUtil(GlobalService.class);
/*     */ 
/*  22 */   private static long offset_time = 0L;
/*  23 */   private static boolean isCheckedOffsetTime = false;
/*     */   private static I18nContext i18nDefaultContext;
/*  27 */   private static GlobalDAO globalDAO = null;
/*     */ 
/*  29 */   private static Locale defaultLocale = null;
/*     */ 
/*     */   public static GlobalDAO getGlobalDAO() {
/*  32 */     return globalDAO;
/*     */   }
/*     */   public void setGlobalDAO(GlobalDAO paramGlobalDAO) {
/*  35 */     globalDAO = paramGlobalDAO;
/*     */   }
/*     */ 
/*     */   public static long getOffsetTime() {
/*  39 */     if (!isCheckedOffsetTime) {
/*  40 */       boolean bool = true;
/*     */       try {
/*  42 */         bool = CoreVariability.isReadTimeFromDB();
/*     */       } catch (Exception localException) {
/*  44 */         logger.warn(localizedTextUtil.findText("core.GlobalInnerManager.getTimeFromDBNotConfigured.warn", new String[] { "GET_TIME_FORM_DB" }));
/*     */       }
/*  46 */       if (bool)
/*     */       {
/*  48 */         Date localDate = getGlobalDAO().getDBDate();
/*  49 */         offset_time = System.currentTimeMillis() - localDate.getTime();
/*     */       }
/*     */ 
/*  52 */       isCheckedOffsetTime = true;
/*     */     }
/*     */ 
/*  55 */     return offset_time;
/*     */   }
/*     */ 
/*     */   public static boolean isEnabled()
/*     */   {
/*  62 */     return CoreVariability.isGlobalEnabled();
/*     */   }
/*     */ 
/*     */   public static Locale getDefaultLocale() {
/*  66 */     return defaultLocale == null ? Locale.getDefault() : defaultLocale;
/*     */   }
/*     */ 
/*     */   public static void initialize()
/*     */   {
/*  73 */     i18nDefaultContext = new I18nContext();
/*     */ 
/*  76 */     Locale localLocale = null;
/*  77 */     String str1 = "";
/*     */     try {
/*  79 */       str1 = CoreVariability.getDefaultLocaleLanguage();
/*  80 */       if (str1 == null) {
/*  81 */         logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.locale", new String[] { "DEFAULT_LOCALE" }));
/*     */       }
/*  83 */       localLocale = LocaleUtil.localeFromString(str1, getDefaultLocale());
/*     */     } catch (Exception localException1) {
/*  85 */       logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.locale", new String[] { "DEFAULT_LOCALE" }));
/*  86 */       localLocale = getDefaultLocale();
/*     */     }
/*  88 */     i18nDefaultContext.setLocale(localLocale);
/*     */ 
/*  91 */     TimeZone localTimeZone = null;
/*  92 */     String str2 = null;
/*     */     try {
/*  94 */       str2 = CoreVariability.getDefaultTimeZone();
/*  95 */       if (str2 != null) {
/*  96 */         localTimeZone = TimeZone.getTimeZone(str2);
/*     */       } else {
/*  98 */         logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.timezone", new String[] { "DEFAULT_LOCALE" }));
/*  99 */         localTimeZone = TimeZone.getDefault();
/*     */       }
/*     */     } catch (Exception localException2) {
/* 102 */       logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.timezone", new String[] { "DEFAULT_LOCALE" }));
/* 103 */       localTimeZone = TimeZone.getDefault();
/*     */     }
/* 105 */     i18nDefaultContext.setTimeZone(localTimeZone);
/*     */ 
/* 107 */     int i = 2;
/*     */     try {
/* 109 */       i = CoreVariability.getDefaultDateStyle();
/*     */     } catch (Exception localException3) {
/* 111 */       i = 2;
/* 112 */       logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.datestyle", new String[] { "DEFAULT_DATESTYLE" }));
/*     */     }
/* 114 */     i18nDefaultContext.setDateStyle(i);
/*     */ 
/* 116 */     int j = 2;
/*     */     try {
/* 118 */       j = CoreVariability.getDefaultTimeStyle();
/*     */     } catch (Exception localException4) {
/* 120 */       logger.warn(localizedTextUtil.findText("techcomp.core.i18n.init.error.timestyle", new String[] { "DEFAULT_TIMESTYLE" }));
/* 121 */       j = 2;
/*     */     }
/* 123 */     i18nDefaultContext.setTimeStyle(j);
/*     */   }
/*     */ 
/*     */   public static I18nContext getDefaultI18nContext()
/*     */   {
/* 131 */     if (i18nDefaultContext == null) {
/* 132 */       initialize();
/*     */     }
/* 134 */     return i18nDefaultContext;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.GlobalInnerManager
 * JD-Core Version:    0.6.2
 */