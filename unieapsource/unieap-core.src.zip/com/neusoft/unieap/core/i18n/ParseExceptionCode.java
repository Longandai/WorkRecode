package com.neusoft.unieap.core.i18n;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class ParseExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "004";
  private static final String _P = "EAPTECH004";
  public static final String PARSE_DATESTR_TO_DATEANDTIME = "EAPTECH004500";
  public static final String PARSE_STRING_TO_NUMBER = "EAPTECH004501";
  public static final String PARSE_CURRENCY_STRING_TO_NUMBER = "EAPTECH004502";
  public static final String PARSE_PERCENT_STRING_TO_NUMBER = "EAPTECH004503";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.ParseExceptionCode
 * JD-Core Version:    0.6.2
 */