/*     */ package com.neusoft.unieap.core.i18n;
/*     */ 
/*     */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*     */ import com.neusoft.unieap.core.util.ConvertDateUtil;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.text.DateFormat;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class GlobalUtil
/*     */ {
/*     */   public static java.util.Date convertToGMT(java.util.Date paramDate)
/*     */   {
/*  37 */     if (paramDate == null) {
/*  38 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/*  40 */     if (!GlobalService.isEnabled()) {
/*  41 */       return paramDate;
/*     */     }
/*  43 */     I18nContext localI18nContext = GlobalService.getUserI18nContext();
/*  44 */     TimeZone localTimeZone = localI18nContext.getTimeZone();
/*  45 */     if (localTimeZone == null) {
/*  46 */       localTimeZone = GlobalService.getDefaultI18nContext().getTimeZone();
/*     */     }
/*  48 */     java.util.Date localDate = ConvertDateUtil.convertToGMT(paramDate, localTimeZone);
/*  49 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.util.Date convertToLocal(java.util.Date paramDate)
/*     */   {
/*  61 */     if (paramDate == null) {
/*  62 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/*  64 */     if (!GlobalService.isEnabled()) {
/*  65 */       return paramDate;
/*     */     }
/*  67 */     java.util.Date localDate = ConvertDateUtil.convertToLocal(paramDate, getTimeZone());
/*  68 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static Timestamp convertToGMT(Timestamp paramTimestamp)
/*     */   {
/*  79 */     if (paramTimestamp == null) {
/*  80 */       throw new IllegalArgumentException("input timestamp is null");
/*     */     }
/*  82 */     if (!GlobalService.isEnabled()) {
/*  83 */       return paramTimestamp;
/*     */     }
/*  85 */     Timestamp localTimestamp = ConvertDateUtil.convertToGMT(paramTimestamp, 
/*  86 */       getTimeZone());
/*  87 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public static Timestamp convertToLocal(Timestamp paramTimestamp)
/*     */   {
/*  98 */     if (paramTimestamp == null) {
/*  99 */       throw new IllegalArgumentException("input timestamp is null");
/*     */     }
/* 101 */     if (!GlobalService.isEnabled()) {
/* 102 */       return paramTimestamp;
/*     */     }
/* 104 */     Timestamp localTimestamp = ConvertDateUtil.convertToLocal(paramTimestamp, 
/* 105 */       getTimeZone());
/* 106 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public static Time convertToGMT(Time paramTime)
/*     */   {
/* 117 */     if (paramTime == null) {
/* 118 */       throw new IllegalArgumentException("input time is null");
/*     */     }
/* 120 */     if (!GlobalService.isEnabled()) {
/* 121 */       return paramTime;
/*     */     }
/* 123 */     Time localTime = ConvertDateUtil.convertToGMT(paramTime, getTimeZone());
/* 124 */     return localTime;
/*     */   }
/*     */ 
/*     */   private static TimeZone getTimeZone() {
/* 128 */     I18nContext localI18nContext = GlobalService.getUserI18nContext();
/* 129 */     TimeZone localTimeZone = localI18nContext.getTimeZone();
/* 130 */     if (localTimeZone == null) {
/* 131 */       localTimeZone = GlobalService.getDefaultI18nContext().getTimeZone();
/*     */     }
/* 133 */     return localTimeZone;
/*     */   }
/*     */ 
/*     */   public static Time convertToLocal(Time paramTime)
/*     */   {
/* 144 */     if (paramTime == null) {
/* 145 */       throw new IllegalArgumentException("input time is null");
/*     */     }
/* 147 */     if (!GlobalService.isEnabled()) {
/* 148 */       return paramTime;
/*     */     }
/* 150 */     Time localTime = ConvertDateUtil.convertToLocal(paramTime, getTimeZone());
/* 151 */     return localTime;
/*     */   }
/*     */ 
/*     */   public static java.sql.Date convertToGMT(java.sql.Date paramDate)
/*     */   {
/* 162 */     if (paramDate == null) {
/* 163 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/* 165 */     if (!GlobalService.isEnabled()) {
/* 166 */       return paramDate;
/*     */     }
/* 168 */     java.sql.Date localDate = ConvertDateUtil.convertToGMT(paramDate, 
/* 169 */       getTimeZone());
/* 170 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.sql.Date convertToLocal(java.sql.Date paramDate)
/*     */   {
/* 181 */     if (paramDate == null) {
/* 182 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/* 184 */     if (!GlobalService.isEnabled()) {
/* 185 */       return paramDate;
/*     */     }
/* 187 */     java.sql.Date localDate = ConvertDateUtil.convertToLocal(paramDate, 
/* 188 */       getTimeZone());
/* 189 */     return localDate;
/*     */   }
/*     */ 
/*     */   private static DateFormat getDateFormat() {
/* 193 */     DateFormat localDateFormat = null;
/* 194 */     if (!GlobalService.isEnabled()) {
/* 195 */       localDateFormat = DateFormat.getDateTimeInstance();
/*     */     }
/*     */     else {
/* 198 */       I18nContext localI18nContext = GlobalService.getUserI18nContext();
/* 199 */       int i = localI18nContext.getDateStyle();
/* 200 */       int j = localI18nContext.getTimeStyle();
/* 201 */       Locale localLocale = localI18nContext.getLocale();
/* 202 */       if (localLocale == null) {
/* 203 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 205 */       localDateFormat = DateFormat.getDateTimeInstance(i, j, 
/* 206 */         localLocale);
/*     */     }
/* 208 */     return localDateFormat;
/*     */   }
/*     */ 
/*     */   public static java.util.Date toDateTime(String paramString)
/*     */   {
/* 221 */     if ((paramString == null) || (paramString.equals(""))) {
/* 222 */       throw new IllegalArgumentException("input dateStr is null");
/*     */     }
/* 224 */     DateFormat localDateFormat = getDateFormat();
/* 225 */     java.util.Date localDate1 = null;
/*     */     try {
/* 227 */       localDate1 = getDateFormat().parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 229 */       localParseException.printStackTrace();
/* 230 */       java.util.Date localDate2 = getOriDate();
/* 231 */       String str = localDateFormat.format(localDate2);
/* 232 */       String[] arrayOfString = { paramString, str };
/* 233 */       throw new ParseException(
/* 234 */         "EAPTECH004500", localParseException, arrayOfString);
/*     */     }
/* 236 */     return localDate1;
/*     */   }
/*     */ 
/*     */   public static java.util.Date toDate(String paramString)
/*     */   {
/* 249 */     if ((paramString == null) || ("".equals(paramString))) {
/* 250 */       throw new IllegalArgumentException("input dateStr is null");
/*     */     }
/* 252 */     DateFormat localDateFormat = null;
/*     */     Object localObject2;
/* 253 */     if (!GlobalService.isEnabled()) {
/* 254 */       localDateFormat = DateFormat.getDateInstance();
/*     */     } else {
/* 256 */       localObject1 = GlobalService.getUserI18nContext();
/* 257 */       int i = ((I18nContext)localObject1).getDateStyle();
/* 258 */       localObject2 = ((I18nContext)localObject1).getLocale();
/* 259 */       if (localObject2 == null) {
/* 260 */         localObject2 = GlobalService.getDefaultI18nContext().getLocale();
/*     */       }
/* 262 */       localDateFormat = DateFormat.getDateInstance(i, (Locale)localObject2);
/*     */     }
/* 264 */     Object localObject1 = null;
/*     */     try {
/* 266 */       localObject1 = localDateFormat.parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 268 */       localParseException.printStackTrace();
/* 269 */       localObject2 = getOriDate();
/* 270 */       String str = localDateFormat.format((java.util.Date)localObject2);
/* 271 */       String[] arrayOfString = { paramString, str };
/* 272 */       throw new ParseException(
/* 273 */         "EAPTECH004500", localParseException, arrayOfString);
/*     */     }
/* 275 */     return localObject1;
/*     */   }
/*     */ 
/*     */   public static java.util.Date toTime(String paramString)
/*     */   {
/* 288 */     if ((paramString == null) || ("".equals(paramString))) {
/* 289 */       throw new IllegalArgumentException("input timeStr is null");
/*     */     }
/* 291 */     DateFormat localDateFormat = null;
/*     */     Object localObject2;
/* 292 */     if (!GlobalService.isEnabled()) {
/* 293 */       localDateFormat = DateFormat.getTimeInstance();
/*     */     } else {
/* 295 */       localObject1 = GlobalService.getUserI18nContext();
/* 296 */       int i = ((I18nContext)localObject1).getTimeStyle();
/* 297 */       localObject2 = ((I18nContext)localObject1).getLocale();
/* 298 */       if (localObject2 == null) {
/* 299 */         localObject2 = GlobalService.getDefaultI18nContext().getLocale();
/*     */       }
/* 301 */       localDateFormat = DateFormat.getTimeInstance(i, (Locale)localObject2);
/*     */     }
/* 303 */     Object localObject1 = null;
/*     */     try {
/* 305 */       localObject1 = localDateFormat.parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 307 */       localParseException.printStackTrace();
/* 308 */       localObject2 = getOriDate();
/* 309 */       String str = localDateFormat.format((java.util.Date)localObject2);
/* 310 */       String[] arrayOfString = { paramString, str };
/* 311 */       throw new ParseException(
/* 312 */         "EAPTECH004500", localParseException, arrayOfString);
/*     */     }
/* 314 */     return localObject1;
/*     */   }
/*     */ 
/*     */   public static String formatDateTime(java.util.Date paramDate)
/*     */   {
/* 325 */     if (paramDate == null) {
/* 326 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/* 328 */     DateFormat localDateFormat = getDateFormat();
/* 329 */     return localDateFormat.format(paramDate);
/*     */   }
/*     */ 
/*     */   public static String formatDate(java.util.Date paramDate)
/*     */   {
/* 340 */     if (paramDate == null) {
/* 341 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/* 343 */     DateFormat localDateFormat = null;
/* 344 */     if (!GlobalService.isEnabled()) {
/* 345 */       localDateFormat = DateFormat.getDateInstance();
/*     */     } else {
/* 347 */       I18nContext localI18nContext = GlobalService.getUserI18nContext();
/* 348 */       int i = localI18nContext.getDateStyle();
/* 349 */       Locale localLocale = localI18nContext.getLocale();
/* 350 */       if (localLocale == null) {
/* 351 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 353 */       localDateFormat = DateFormat.getDateInstance(i, localLocale);
/*     */     }
/* 355 */     return localDateFormat.format(paramDate);
/*     */   }
/*     */ 
/*     */   public static String formatTime(java.util.Date paramDate)
/*     */   {
/* 366 */     if (paramDate == null) {
/* 367 */       throw new IllegalArgumentException("input date is null");
/*     */     }
/* 369 */     DateFormat localDateFormat = null;
/* 370 */     if (!GlobalService.isEnabled()) {
/* 371 */       localDateFormat = DateFormat.getDateInstance();
/*     */     } else {
/* 373 */       I18nContext localI18nContext = GlobalService.getUserI18nContext();
/* 374 */       int i = localI18nContext.getTimeStyle();
/* 375 */       Locale localLocale = localI18nContext.getLocale();
/* 376 */       if (localLocale == null) {
/* 377 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 379 */       localDateFormat = DateFormat.getTimeInstance(i, localLocale);
/*     */     }
/* 381 */     return localDateFormat.format(paramDate);
/*     */   }
/*     */ 
/*     */   public static String formatNumber(Number paramNumber)
/*     */   {
/* 392 */     NumberFormat localNumberFormat = null;
/* 393 */     if (!GlobalService.isEnabled()) {
/* 394 */       localNumberFormat = NumberFormat.getInstance();
/*     */     } else {
/* 396 */       localObject = GlobalService.getUserI18nContext();
/* 397 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 398 */       if (localLocale == null) {
/* 399 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 401 */       localNumberFormat = NumberFormat.getInstance(localLocale);
/*     */     }
/* 403 */     Object localObject = paramNumber.toString();
/* 404 */     if (((String)localObject).indexOf(".") > 0) {
/* 405 */       int i = ((String)localObject).length() - ((String)localObject).indexOf(".") - 1;
/* 406 */       localNumberFormat.setMaximumFractionDigits(i);
/*     */     }
/* 408 */     return localNumberFormat.format(paramNumber);
/*     */   }
/*     */ 
/*     */   private static Number toNumber(String paramString, boolean paramBoolean)
/*     */   {
/* 422 */     if ((paramString == null) || ("".equals(paramString))) {
/* 423 */       throw new IllegalArgumentException("input source is null");
/*     */     }
/* 425 */     NumberFormat localNumberFormat = null;
/* 426 */     if (!GlobalService.isEnabled()) {
/* 427 */       localNumberFormat = NumberFormat.getInstance();
/*     */     } else {
/* 429 */       localObject = GlobalService.getUserI18nContext();
/* 430 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 431 */       if (localLocale == null) {
/* 432 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 434 */       localNumberFormat = NumberFormat.getInstance(localLocale);
/*     */     }
/* 436 */     Object localObject = null;
/*     */     try {
/* 438 */       if ((paramBoolean) && ((localNumberFormat instanceof DecimalFormat))) {
/* 439 */         ((DecimalFormat)localNumberFormat).setParseBigDecimal(true);
/*     */       }
/* 441 */       localObject = localNumberFormat.parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 443 */       localParseException.printStackTrace();
/* 444 */       localObject = new Double(10000.0D);
/* 445 */       String str = localNumberFormat.format(localObject);
/* 446 */       String[] arrayOfString = { paramString, str };
/* 447 */       throw new ParseException(
/* 448 */         "EAPTECH004501", localParseException, arrayOfString);
/*     */     }
/* 450 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static BigDecimal toBigDecimal(String paramString)
/*     */   {
/* 463 */     Number localNumber = toNumber(paramString, true);
/* 464 */     BigDecimal localBigDecimal = new BigDecimal(localNumber.toString());
/* 465 */     return localBigDecimal;
/*     */   }
/*     */ 
/*     */   public static BigInteger toBigInteger(String paramString)
/*     */   {
/* 478 */     BigDecimal localBigDecimal = toBigDecimal(paramString);
/* 479 */     return localBigDecimal.toBigInteger();
/*     */   }
/*     */ 
/*     */   public static Double toDouble(String paramString)
/*     */   {
/* 492 */     Number localNumber = toNumber(paramString, false);
/* 493 */     return new Double(localNumber.doubleValue());
/*     */   }
/*     */ 
/*     */   public static Float toFloat(String paramString)
/*     */   {
/* 506 */     Number localNumber = toNumber(paramString, false);
/* 507 */     return new Float(localNumber.floatValue());
/*     */   }
/*     */ 
/*     */   public static Long toLong(String paramString)
/*     */   {
/* 520 */     Number localNumber = toNumber(paramString, false);
/* 521 */     return Long.valueOf(localNumber.longValue());
/*     */   }
/*     */ 
/*     */   public static Integer toInteger(String paramString)
/*     */   {
/* 534 */     Number localNumber = toNumber(paramString, false);
/* 535 */     return Integer.valueOf(localNumber.intValue());
/*     */   }
/*     */ 
/*     */   public static Short toShort(String paramString)
/*     */   {
/* 548 */     Number localNumber = toNumber(paramString, false);
/* 549 */     return Short.valueOf(localNumber.shortValue());
/*     */   }
/*     */ 
/*     */   public static Byte toByte(String paramString)
/*     */   {
/* 562 */     Number localNumber = toNumber(paramString, false);
/* 563 */     return Byte.valueOf(localNumber.byteValue());
/*     */   }
/*     */ 
/*     */   public static String formatCurrency(Number paramNumber)
/*     */   {
/* 574 */     NumberFormat localNumberFormat = null;
/* 575 */     if (!GlobalService.isEnabled()) {
/* 576 */       localNumberFormat = NumberFormat.getInstance();
/*     */     } else {
/* 578 */       localObject = GlobalService.getUserI18nContext();
/* 579 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 580 */       if (localLocale == null) {
/* 581 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 583 */       localNumberFormat = NumberFormat.getCurrencyInstance(localLocale);
/*     */     }
/* 585 */     Object localObject = paramNumber.toString();
/* 586 */     if (((String)localObject).indexOf(".") > 0) {
/* 587 */       int i = ((String)localObject).length() - ((String)localObject).indexOf(".") - 1;
/* 588 */       localNumberFormat.setMaximumFractionDigits(i);
/*     */     }
/* 590 */     return localNumberFormat.format(paramNumber);
/*     */   }
/*     */ 
/*     */   private static Number toCurrency(String paramString, boolean paramBoolean)
/*     */   {
/* 603 */     if ((paramString == null) || ("".equals(paramString))) {
/* 604 */       throw new IllegalArgumentException("input currency is null");
/*     */     }
/* 606 */     NumberFormat localNumberFormat = null;
/* 607 */     if (!GlobalService.isEnabled()) {
/* 608 */       localNumberFormat = NumberFormat.getCurrencyInstance();
/*     */     } else {
/* 610 */       localObject = GlobalService.getUserI18nContext();
/* 611 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 612 */       if (localLocale == null) {
/* 613 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 615 */       localNumberFormat = NumberFormat.getCurrencyInstance(localLocale);
/*     */     }
/* 617 */     Object localObject = null;
/*     */     try {
/* 619 */       if ((paramBoolean) && ((localNumberFormat instanceof DecimalFormat))) {
/* 620 */         ((DecimalFormat)localNumberFormat).setParseBigDecimal(true);
/*     */       }
/* 622 */       localObject = localNumberFormat.parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 624 */       localParseException.printStackTrace();
/* 625 */       localObject = new Double(10000.0D);
/* 626 */       String str = localNumberFormat.format(localObject);
/* 627 */       String[] arrayOfString = { paramString, str };
/* 628 */       throw new ParseException(
/* 629 */         "EAPTECH004502", localParseException, arrayOfString);
/*     */     }
/* 631 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static BigDecimal currencyToBigDecimal(String paramString)
/*     */   {
/* 644 */     Number localNumber = toCurrency(paramString, true);
/* 645 */     BigDecimal localBigDecimal = new BigDecimal(localNumber.toString());
/* 646 */     return localBigDecimal;
/*     */   }
/*     */ 
/*     */   public static String formatPercentage(Number paramNumber)
/*     */   {
/* 657 */     NumberFormat localNumberFormat = null;
/* 658 */     if (!GlobalService.isEnabled()) {
/* 659 */       localNumberFormat = NumberFormat.getInstance();
/*     */     } else {
/* 661 */       localObject = GlobalService.getUserI18nContext();
/* 662 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 663 */       if (localLocale == null) {
/* 664 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 666 */       localNumberFormat = NumberFormat.getPercentInstance(localLocale);
/*     */     }
/* 668 */     Object localObject = paramNumber.toString();
/* 669 */     if (((String)localObject).indexOf(".") > 0) {
/* 670 */       int i = ((String)localObject).length() - ((String)localObject).indexOf(".") - 1;
/* 671 */       localNumberFormat.setMaximumFractionDigits(i);
/*     */     }
/* 673 */     if ((paramNumber instanceof Float)) {
/* 674 */       paramNumber = new Double(paramNumber.toString());
/*     */     }
/* 676 */     return localNumberFormat.format(paramNumber);
/*     */   }
/*     */ 
/*     */   private static Number toPercentage(String paramString, boolean paramBoolean)
/*     */   {
/* 690 */     if ((paramString == null) || ("".equals(paramString))) {
/* 691 */       throw new IllegalArgumentException("input percentage is null");
/*     */     }
/* 693 */     NumberFormat localNumberFormat = null;
/* 694 */     if (!GlobalService.isEnabled()) {
/* 695 */       localNumberFormat = NumberFormat.getInstance();
/*     */     } else {
/* 697 */       localObject = GlobalService.getUserI18nContext();
/* 698 */       Locale localLocale = ((I18nContext)localObject).getLocale();
/* 699 */       if (localLocale == null) {
/* 700 */         localLocale = GlobalInnerManager.getDefaultI18nContext().getLocale();
/*     */       }
/* 702 */       localNumberFormat = NumberFormat.getPercentInstance(localLocale);
/*     */     }
/* 704 */     Object localObject = null;
/*     */     try {
/* 706 */       if ((paramBoolean) && ((localNumberFormat instanceof DecimalFormat))) {
/* 707 */         ((DecimalFormat)localNumberFormat).setParseBigDecimal(true);
/*     */       }
/* 709 */       localObject = localNumberFormat.parse(paramString);
/*     */     } catch (java.text.ParseException localParseException) {
/* 711 */       localParseException.printStackTrace();
/* 712 */       localObject = new Double(0.105D);
/* 713 */       String str = localNumberFormat.format(localObject);
/* 714 */       String[] arrayOfString = { paramString, str };
/* 715 */       throw new ParseException(
/* 716 */         "EAPTECH004503", localParseException, arrayOfString);
/*     */     }
/* 718 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static BigDecimal percentageToBigDecimal(String paramString)
/*     */   {
/* 731 */     Number localNumber = toPercentage(paramString, true);
/* 732 */     BigDecimal localBigDecimal = new BigDecimal(localNumber.toString());
/* 733 */     return localBigDecimal;
/*     */   }
/*     */ 
/*     */   public static BigInteger percentageToBigInteger(String paramString)
/*     */   {
/* 746 */     Number localNumber = toPercentage(paramString, true);
/* 747 */     BigDecimal localBigDecimal = new BigDecimal(localNumber.toString());
/* 748 */     return localBigDecimal.toBigInteger();
/*     */   }
/*     */ 
/*     */   public static Long percentageToLong(String paramString)
/*     */   {
/* 761 */     Number localNumber = toPercentage(paramString, false);
/* 762 */     return Long.valueOf(localNumber.longValue());
/*     */   }
/*     */ 
/*     */   public static Integer percentageToInteger(String paramString)
/*     */   {
/* 775 */     Number localNumber = toPercentage(paramString, false);
/* 776 */     return Integer.valueOf(localNumber.intValue());
/*     */   }
/*     */ 
/*     */   public static Double percentageToDouble(String paramString)
/*     */   {
/* 789 */     Number localNumber = toPercentage(paramString, false);
/* 790 */     return new Double(localNumber.doubleValue());
/*     */   }
/*     */ 
/*     */   public static Float percentageToFloat(String paramString)
/*     */   {
/* 803 */     Number localNumber = toPercentage(paramString, false);
/* 804 */     return new Float(localNumber.floatValue());
/*     */   }
/*     */ 
/*     */   public static Short percentageToShort(String paramString)
/*     */   {
/* 817 */     Number localNumber = toPercentage(paramString, false);
/* 818 */     return Short.valueOf(localNumber.shortValue());
/*     */   }
/*     */ 
/*     */   public static Byte percentageToByte(String paramString)
/*     */   {
/* 831 */     Number localNumber = toPercentage(paramString, false);
/* 832 */     return Byte.valueOf(localNumber.byteValue());
/*     */   }
/*     */ 
/*     */   private static java.util.Date getOriDate() {
/* 836 */     GregorianCalendar localGregorianCalendar = new GregorianCalendar();
/* 837 */     localGregorianCalendar.set(1900, 0, 1, 0, 0, 0);
/* 838 */     return localGregorianCalendar.getTime();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.GlobalUtil
 * JD-Core Version:    0.6.2
 */