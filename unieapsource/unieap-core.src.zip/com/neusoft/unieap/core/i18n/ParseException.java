/*    */ package com.neusoft.unieap.core.i18n;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class ParseException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = -5112038076211192498L;
/*    */ 
/*    */   public ParseException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/*  8 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public boolean isLogEnabled() {
/* 12 */     return true;
/*    */   }
/*    */ 
/*    */   public ParseException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject)
/*    */   {
/* 17 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.ParseException
 * JD-Core Version:    0.6.2
 */