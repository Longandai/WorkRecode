/*    */ package com.neusoft.unieap.core.i18n.dao;
/*    */ 
/*    */ import com.neusoft.unieap.core.base.dao.BaseHibernateDAO;
/*    */ import com.neusoft.unieap.core.i18n.util.DBUtil;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Date;
/*    */ import org.hibernate.Query;
/*    */ import org.hibernate.SQLQuery;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.impl.SessionImpl;
/*    */ import org.springframework.orm.hibernate3.HibernateCallback;
/*    */ import org.springframework.orm.hibernate3.HibernateTemplate;
/*    */ 
/*    */ public class GlobalDAO extends BaseHibernateDAO
/*    */ {
/*    */   public Date getDBDate()
/*    */   {
/* 18 */     Date localDate = (Date)getHibernateTemplate().execute(new HibernateCallback() {
/*    */       public Object doInHibernate(Session paramAnonymousSession) {
/*    */         try {
/* 21 */           SessionImpl localSessionImpl = (SessionImpl)GlobalDAO.this.getSession();
/* 22 */           Dialect localDialect = localSessionImpl.getFactory().getDialect();
/* 23 */           String str1 = DBUtil.dbTimeSql(localDialect.toString());
/* 24 */           SQLQuery localSQLQuery = paramAnonymousSession.createSQLQuery(str1);
/* 25 */           Date localDate = null;
/* 26 */           SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
/* 27 */           if (DBUtil.getDbType(localDialect.toString()) == 1) {
/* 28 */             String str2 = (String)localSQLQuery.uniqueResult();
/* 29 */             localDate = localSimpleDateFormat.parse(str2);
/*    */           }
/* 31 */           return (Date)localSQLQuery.uniqueResult();
/*    */         }
/*    */         catch (Exception localException) {
/*    */         }
/* 35 */         return null;
/*    */       }
/*    */     });
/* 39 */     return localDate;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.dao.GlobalDAO
 * JD-Core Version:    0.6.2
 */