/*    */ package com.neusoft.unieap.core.i18n.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.CoreVariability;
/*    */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*    */ import com.neusoft.unieap.core.i18n.GlobalService;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class LocaleUtil
/*    */ {
/*    */   public static Locale localeFromString(String paramString, Locale paramLocale)
/*    */   {
/* 13 */     if ((paramString == null) || (paramString.trim().length() == 0) || 
/* 14 */       ("_".equals(paramString))) {
/* 15 */       if (paramLocale != null) {
/* 16 */         return paramLocale;
/*    */       }
/* 18 */       return Locale.getDefault();
/*    */     }
/*    */ 
/* 21 */     int i = paramString.indexOf('_');
/* 22 */     if (i < 0) {
/* 23 */       return new Locale(paramString);
/*    */     }
/*    */ 
/* 26 */     String str1 = paramString.substring(0, i);
/* 27 */     if (i == paramString.length()) {
/* 28 */       return new Locale(str1);
/*    */     }
/*    */ 
/* 31 */     paramString = paramString.substring(i + 1);
/* 32 */     i = paramString.indexOf('_');
/* 33 */     if (i < 0) {
/* 34 */       return new Locale(str1, paramString);
/*    */     }
/*    */ 
/* 37 */     String str2 = paramString.substring(0, i);
/* 38 */     if (i == paramString.length()) {
/* 39 */       return new Locale(str1, str2);
/*    */     }
/*    */ 
/* 42 */     paramString = paramString.substring(i + 1);
/* 43 */     return new Locale(str1, str2, paramString);
/*    */   }
/*    */ 
/*    */   public static Locale selectSupportedLocale(Locale paramLocale)
/*    */   {
/* 57 */     Object localObject1 = null;
/* 58 */     Locale localLocale1 = GlobalService.getDefaultI18nContext().getLocale();
/* 59 */     if (paramLocale.equals(localLocale1)) {
/* 60 */       return localLocale1;
/*    */     }
/* 62 */     String str1 = CoreVariability.getSupportLocaleLanguage();
/* 63 */     ArrayList localArrayList = new ArrayList();
/* 64 */     if ((str1 != null) && 
/* 65 */       (str1.trim().length() > 0)) {
/* 66 */       localObject2 = str1.split(",");
/* 67 */       for (int i = localObject2.length - 1; i >= 0; i--) {
/* 68 */         if ((localObject2[i] != null) || 
/* 69 */           (localObject2[i].trim().length() == 0) || 
/* 70 */           ("_".equals(localObject2[i]))) {
/* 71 */           localArrayList.add(
/* 72 */             localeFromString(localObject2[i], localLocale1));
/*    */         }
/*    */       }
/*    */     }
/* 76 */     Object localObject2 = paramLocale.getLanguage();
/* 77 */     String str2 = paramLocale.getCountry();
/*    */ 
/* 82 */     for (Locale localLocale2 : localArrayList) {
/* 83 */       if ((localObject2 != null) && 
/* 84 */         (((String)localObject2).equals(localLocale2.getLanguage()))) {
/* 85 */         localObject1 = localLocale2;
/* 86 */         if ((str2 != null) && 
/* 87 */           (str2.equals(localLocale2.getCountry()))) {
/*    */           break;
/*    */         }
/*    */       }
/*    */     }
/* 92 */     if (localObject1 == null) {
/* 93 */       localObject1 = localLocale1;
/*    */     }
/* 95 */     return localObject1;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.util.LocaleUtil
 * JD-Core Version:    0.6.2
 */