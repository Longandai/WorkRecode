/*    */ package com.neusoft.unieap.core.i18n.util;
/*    */ 
/*    */ public class DBUtil
/*    */ {
/*    */   public static final int DBTYPE_MSSQL = 0;
/*    */   public static final int DBTYPE_ORACLE = 1;
/*    */   public static final int DBTYPE_SYBASE = 2;
/*    */   public static final int DBTYPE_DB2 = 3;
/*    */   public static final int DBTYPE_MYSQL = 4;
/*    */   public static final int DBTYPE_HSQLDB = 5;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_MSDB;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_ORACLEDB;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_DB2;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_MYSQL;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_INGRESII;
/*    */   public static final String SQL_SYSTEM_TIME_FOR_SYBASE;
/* 53 */   public static final String SQL_SYSTEM_TIME_FOR_HSQLDB = localStringBuffer.toString();
/*    */ 
/*    */   static
/*    */   {
/* 32 */     StringBuffer localStringBuffer = new StringBuffer(1024);
/* 33 */     localStringBuffer.setLength(0);
/* 34 */     localStringBuffer.append("SELECT GETDATE() AS SYSDATE");
/* 35 */     SQL_SYSTEM_TIME_FOR_MSDB = localStringBuffer.toString();
/* 36 */     localStringBuffer.setLength(0);
/* 37 */     localStringBuffer.append("SELECT To_Char(SYSDATE,'YYYY-MM-DD HH24:MI:SS') \"now\"  FROM DUAL");
/* 38 */     SQL_SYSTEM_TIME_FOR_ORACLEDB = localStringBuffer.toString();
/* 39 */     localStringBuffer.setLength(0);
/* 40 */     localStringBuffer.append("values(current timestamp)");
/* 41 */     SQL_SYSTEM_TIME_FOR_DB2 = localStringBuffer.toString();
/* 42 */     localStringBuffer.setLength(0);
/* 43 */     localStringBuffer.append("SELECT NOW() AS SYSDATE");
/* 44 */     SQL_SYSTEM_TIME_FOR_MYSQL = localStringBuffer.toString();
/* 45 */     localStringBuffer.setLength(0);
/* 46 */     localStringBuffer.append("select date('now') SYSDATE");
/* 47 */     SQL_SYSTEM_TIME_FOR_INGRESII = localStringBuffer.toString();
/* 48 */     localStringBuffer.setLength(0);
/* 49 */     localStringBuffer.append("SELECT  GETDATE() AS SYSDATE");
/* 50 */     SQL_SYSTEM_TIME_FOR_SYBASE = localStringBuffer.toString();
/* 51 */     localStringBuffer.setLength(0);
/* 52 */     localStringBuffer.append("CALL CURDATE()");
/*    */   }
/*    */ 
/*    */   public static int getDbType(String paramString)
/*    */   {
/* 57 */     String str = paramString.toLowerCase();
/* 58 */     int i = -1;
/* 59 */     if (str.indexOf("sqlserver") > -1)
/* 60 */       i = 0;
/* 61 */     else if (str.indexOf("oracle") > -1)
/* 62 */       i = 1;
/* 63 */     else if (str.indexOf("sybase") > -1)
/* 64 */       i = 2;
/* 65 */     else if (str.indexOf("db2") > -1)
/* 66 */       i = 3;
/* 67 */     else if (str.indexOf("mysql") > -1)
/* 68 */       i = 4;
/* 69 */     else if (str.indexOf("hsql") > -1)
/* 70 */       i = 5;
/* 71 */     return i;
/*    */   }
/*    */   public static String dbTimeSql(String paramString) {
/* 74 */     String str1 = paramString.toLowerCase();
/* 75 */     String str2 = "";
/* 76 */     if (str1.indexOf("sqlserver") > -1)
/* 77 */       str2 = SQL_SYSTEM_TIME_FOR_MSDB;
/* 78 */     else if (str1.indexOf("oracle") > -1)
/* 79 */       str2 = SQL_SYSTEM_TIME_FOR_ORACLEDB;
/* 80 */     else if (str1.indexOf("sybase") > -1)
/* 81 */       str2 = SQL_SYSTEM_TIME_FOR_SYBASE;
/* 82 */     else if (str1.indexOf("db2") > -1)
/* 83 */       str2 = SQL_SYSTEM_TIME_FOR_DB2;
/* 84 */     else if (str1.indexOf("mysql") > -1)
/* 85 */       str2 = SQL_SYSTEM_TIME_FOR_MSDB;
/* 86 */     else if (str1.indexOf("hsql") > -1)
/* 87 */       str2 = SQL_SYSTEM_TIME_FOR_HSQLDB;
/* 88 */     return str2;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.util.DBUtil
 * JD-Core Version:    0.6.2
 */