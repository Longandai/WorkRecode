/*    */ package com.neusoft.unieap.core.i18n;
/*    */ 
/*    */ import com.neusoft.unieap.core.context.UnieapRequestContextHolder;
/*    */ import com.neusoft.unieap.core.context.properties.I18nContext;
/*    */ import com.neusoft.unieap.core.util.ConvertDateUtil;
/*    */ import java.sql.Timestamp;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class GlobalService
/*    */ {
/*    */   public static boolean isEnabled()
/*    */   {
/* 22 */     return GlobalInnerManager.isEnabled();
/*    */   }
/*    */ 
/*    */   public static I18nContext getDefaultI18nContext()
/*    */   {
/* 29 */     return GlobalInnerManager.getDefaultI18nContext();
/*    */   }
/*    */ 
/*    */   public static I18nContext getUserI18nContext()
/*    */   {
/* 36 */     I18nContext localI18nContext = null;
/* 37 */     if (!isEnabled())
/*    */     {
/* 39 */       localI18nContext = getDefaultI18nContext();
/* 40 */       return localI18nContext;
/*    */     }
/* 42 */     Map localMap = UnieapRequestContextHolder.getRequestContext();
/* 43 */     if (localMap != null) {
/* 44 */       localI18nContext = (I18nContext)localMap.get("i18nContext");
/*    */     }
/*    */ 
/* 47 */     if (localI18nContext == null) {
/* 48 */       localI18nContext = getDefaultI18nContext();
/*    */     }
/* 50 */     return localI18nContext;
/*    */   }
/*    */ 
/*    */   public static java.util.Date getDate()
/*    */   {
/* 58 */     long l = System.currentTimeMillis();
/* 59 */     l += GlobalInnerManager.getOffsetTime();
/* 60 */     if (!isEnabled()) {
/* 61 */       return new java.util.Date(l);
/*    */     }
/* 63 */     I18nContext localI18nContext = getUserI18nContext();
/* 64 */     return ConvertDateUtil.getDateByMillisecond(l, localI18nContext.getTimeZone());
/*    */   }
/*    */ 
/*    */   public static Timestamp getTimestamp()
/*    */   {
/* 72 */     long l = System.currentTimeMillis();
/* 73 */     l += GlobalInnerManager.getOffsetTime();
/* 74 */     if (!isEnabled()) {
/* 75 */       return new Timestamp(l);
/*    */     }
/* 77 */     I18nContext localI18nContext = getUserI18nContext();
/* 78 */     return ConvertDateUtil.getTimestampByMillisecond(l, localI18nContext.getTimeZone());
/*    */   }
/*    */ 
/*    */   public static java.sql.Date getSqlDate()
/*    */   {
/* 86 */     long l = System.currentTimeMillis();
/* 87 */     l += GlobalInnerManager.getOffsetTime();
/* 88 */     if (!isEnabled()) {
/* 89 */       return new java.sql.Date(l);
/*    */     }
/* 91 */     I18nContext localI18nContext = getUserI18nContext();
/* 92 */     return ConvertDateUtil.getSQLDateByMillisecond(l, localI18nContext.getTimeZone());
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.i18n.GlobalService
 * JD-Core Version:    0.6.2
 */