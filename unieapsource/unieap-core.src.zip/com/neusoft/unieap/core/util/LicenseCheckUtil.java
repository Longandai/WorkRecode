/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.protection.Encipher;
/*    */ import com.neusoft.unieap.core.protection.ProtectionConfig;
/*    */ import com.neusoft.unieap.core.protection.custom.CustomCheck;
/*    */ import java.util.HashSet;
/*    */ import javax.servlet.ServletRequest;
/*    */ import javax.servlet.ServletResponse;
/*    */ 
/*    */ public class LicenseCheckUtil
/*    */ {
/*    */   public static String licenseCheck(ServletRequest paramServletRequest, ServletResponse paramServletResponse)
/*    */   {
/* 14 */     String str1 = CustomCheck.getInstance().getProperty("common.type", 
/* 15 */       "development");
/* 16 */     if (str1.equalsIgnoreCase("development")) {
/* 17 */       String str2 = CustomCheck.getInstance().getProperty(
/* 18 */         "platform.access_ip_count", "2");
/* 19 */       String str3 = paramServletRequest.getRemoteHost();
/* 20 */       ProtectionConfig.accessIPs.add(str3);
/* 21 */       CustomCheck.getInstance().check(false);
/* 22 */       if ((ProtectionConfig.accessIPs.size() > Integer.parseInt(str2)) && 
/* 23 */         (!ProtectionConfig.accessIPs.contains(str3))) {
/* 24 */         return Encipher.decodePasswd(ProtectionConfig.rejectInfo);
/*    */       }
/*    */     }
/*    */ 
/* 28 */     if (ProtectionConfig.errMsg != null) {
/* 29 */       return ProtectionConfig.errMsg;
/*    */     }
/* 31 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.LicenseCheckUtil
 * JD-Core Version:    0.6.2
 */