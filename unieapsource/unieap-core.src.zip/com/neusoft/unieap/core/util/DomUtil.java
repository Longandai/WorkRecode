/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import org.dom4j.Document;
/*    */ import org.dom4j.DocumentException;
/*    */ import org.dom4j.Element;
/*    */ import org.dom4j.io.OutputFormat;
/*    */ import org.dom4j.io.SAXReader;
/*    */ import org.dom4j.io.XMLWriter;
/*    */ import org.xml.sax.SAXException;
/*    */ 
/*    */ public class DomUtil
/*    */ {
/*    */   public static Document parse(String paramString)
/*    */   {
/* 23 */     SAXReader localSAXReader = new SAXReader();
/*    */     try {
/* 25 */       localSAXReader
/* 26 */         .setFeature(
/* 27 */         "http://apache.org/xml/features/nonvalidating/load-external-dtd", 
/* 28 */         false);
/* 29 */       return localSAXReader.read(new ByteArrayInputStream(paramString
/* 30 */         .getBytes("UTF-8")));
/*    */     } catch (SAXException localSAXException) {
/* 32 */       localSAXException.printStackTrace();
/*    */     } catch (UnsupportedEncodingException localUnsupportedEncodingException) {
/* 34 */       localUnsupportedEncodingException.printStackTrace();
/*    */     } catch (DocumentException localDocumentException) {
/* 36 */       localDocumentException.printStackTrace();
/*    */     }
/* 38 */     return null;
/*    */   }
/*    */ 
/*    */   public static Document parse(File paramFile) {
/* 42 */     SAXReader localSAXReader = new SAXReader();
/*    */     try {
/* 44 */       localSAXReader
/* 45 */         .setFeature(
/* 46 */         "http://apache.org/xml/features/nonvalidating/load-external-dtd", 
/* 47 */         false);
/* 48 */       return localSAXReader.read(new FileInputStream(paramFile));
/*    */     } catch (SAXException localSAXException) {
/* 50 */       localSAXException.printStackTrace();
/*    */     } catch (DocumentException localDocumentException) {
/* 52 */       localDocumentException.printStackTrace();
/*    */     } catch (FileNotFoundException localFileNotFoundException) {
/* 54 */       localFileNotFoundException.printStackTrace();
/*    */     }
/* 56 */     return null;
/*    */   }
/*    */ 
/*    */   public static List<Element> getElementListByXPath(String paramString, Document paramDocument)
/*    */   {
/* 61 */     return paramDocument.selectNodes(paramString);
/*    */   }
/*    */ 
/*    */   public static Element getElementByXPath(String paramString, Document paramDocument) {
/* 65 */     return (Element)paramDocument.selectSingleNode(paramString);
/*    */   }
/*    */ 
/*    */   public static List<Element> getChildElements(Element paramElement, String paramString) {
/* 69 */     ArrayList localArrayList = new ArrayList();
/* 70 */     List localList = paramElement.content();
/* 71 */     if ((localList != null) && (localList.size() > 0)) {
/* 72 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 73 */         if ((localObject instanceof Element)) {
/* 74 */           Element localElement = (Element)localObject;
/* 75 */           if (localElement.getName().equals(paramString)) {
/* 76 */             localArrayList.add(localElement);
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 81 */     return localArrayList;
/*    */   }
/*    */ 
/*    */   public static String toString(Document paramDocument) {
/* 85 */     OutputFormat.createPrettyPrint();
/* 86 */     StringWriter localStringWriter = new StringWriter();
/* 87 */     XMLWriter localXMLWriter = new XMLWriter(localStringWriter);
/*    */     try {
/* 89 */       localXMLWriter.write(paramDocument);
/*    */     } catch (IOException localIOException1) {
/* 91 */       localIOException1.printStackTrace();
/*    */       try
/*    */       {
/* 94 */         localXMLWriter.close();
/*    */       } catch (IOException localIOException2) {
/* 96 */         localIOException2.printStackTrace();
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 94 */         localXMLWriter.close();
/*    */       } catch (IOException localIOException3) {
/* 96 */         localIOException3.printStackTrace();
/*    */       }
/*    */     }
/* 99 */     return localStringWriter.toString();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.DomUtil
 * JD-Core Version:    0.6.2
 */