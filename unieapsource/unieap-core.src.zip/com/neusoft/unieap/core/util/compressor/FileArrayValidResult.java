/*     */ package com.neusoft.unieap.core.util.compressor;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ class FileArrayValidResult
/*     */ {
/* 412 */   private boolean succ = false;
/* 413 */   private File invalidFile = null;
/*     */ 
/*     */   public boolean isSucc() {
/* 416 */     return this.succ;
/*     */   }
/*     */ 
/*     */   public FileArrayValidResult setSucc(boolean paramBoolean) {
/* 420 */     this.succ = paramBoolean;
/* 421 */     return this;
/*     */   }
/*     */ 
/*     */   public File getInvalidFile() {
/* 425 */     return this.invalidFile;
/*     */   }
/*     */ 
/*     */   public FileArrayValidResult setInvalidFile(File paramFile) {
/* 429 */     this.invalidFile = paramFile;
/* 430 */     return this;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.FileArrayValidResult
 * JD-Core Version:    0.6.2
 */