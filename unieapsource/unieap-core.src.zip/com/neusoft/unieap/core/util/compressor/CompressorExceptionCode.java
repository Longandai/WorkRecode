package com.neusoft.unieap.core.util.compressor;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class CompressorExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "005";
  private static final String _P = "EAPTECH005";
  public static final String ZIP_OUTPUTFILE_NOT_FOUND = "EAPTECH005600";
  public static final String ZIP_FILE_HAS_FINISHED = "EAPTECH005610";
  public static final String ILLEGAL_FILE_ADD_TO_ZIP = "EAPTECH005621";
  public static final String ILLEGAL_FOLDER_ADD_TO_ZIP = "EAPTECH005622";
  public static final String IOEXCEPTION_OCCURED_WHILE_OPERATING_ZIP = "EAPTECH005650";
  public static final String INVALID_ZIP_FILE_FOLDER_PATH = "EAPTECH005631";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.CompressorExceptionCode
 * JD-Core Version:    0.6.2
 */