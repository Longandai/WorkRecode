/*     */ package com.neusoft.unieap.core.util.compressor;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ class FileFilter
/*     */   implements java.io.FileFilter
/*     */ {
/*     */   public boolean accept(File paramFile)
/*     */   {
/* 361 */     return paramFile.isFile();
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.FileFilter
 * JD-Core Version:    0.6.2
 */