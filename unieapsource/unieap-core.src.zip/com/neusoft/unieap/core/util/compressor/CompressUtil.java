/*     */ package com.neusoft.unieap.core.util.compressor;
/*     */ 
/*     */ import java.io.File;
/*     */ 
/*     */ public class CompressUtil
/*     */ {
/*     */   private static boolean isFileValid(File paramFile)
/*     */   {
/*  15 */     return (paramFile != null) && (paramFile.exists()) && (paramFile.isFile());
/*     */   }
/*     */ 
/*     */   private static FileArrayValidResult isFileArrayValid(File[] paramArrayOfFile) {
/*  19 */     if (paramArrayOfFile == null) {
/*  20 */       return new FileArrayValidResult();
/*     */     }
/*  22 */     for (int i = 0; i < paramArrayOfFile.length; i++) {
/*  23 */       if (!isFileValid(paramArrayOfFile[i])) {
/*  24 */         return new FileArrayValidResult().setInvalidFile(paramArrayOfFile[i]);
/*     */       }
/*     */     }
/*  27 */     return new FileArrayValidResult().setSucc(true);
/*     */   }
/*     */ 
/*     */   private static FileArrayValidResult isFolderArrayValid(File[] paramArrayOfFile) {
/*  31 */     if (paramArrayOfFile == null) {
/*  32 */       return new FileArrayValidResult();
/*     */     }
/*  34 */     for (int i = 0; i < paramArrayOfFile.length; i++) {
/*  35 */       if (!isFolderValid(paramArrayOfFile[i])) {
/*  36 */         return new FileArrayValidResult().setInvalidFile(paramArrayOfFile[i]);
/*     */       }
/*     */     }
/*  39 */     return new FileArrayValidResult().setSucc(true);
/*     */   }
/*     */ 
/*     */   private static boolean isFolderValid(File paramFile) {
/*  43 */     if (paramFile == null)
/*  44 */       return false;
/*  45 */     if (!paramFile.isDirectory())
/*  46 */       return false;
/*  47 */     return true;
/*     */   }
/*     */ 
/*     */   private static File getFileObject(String paramString) {
/*  51 */     if (paramString == null)
/*  52 */       return null;
/*  53 */     return new File(paramString);
/*     */   }
/*     */ 
/*     */   private static File zipAFile(String paramString, File paramFile) {
/*  57 */     File localFile = new File(paramString);
/*  58 */     ZipFile localZipFile = new ZipFile(localFile);
/*     */     try {
/*  60 */       localZipFile.addFile(paramFile, null);
/*     */     } catch (RuntimeException localRuntimeException) {
/*  62 */       localZipFile.closeZipOutputStream();
/*  63 */       throw localRuntimeException;
/*     */     }
/*  65 */     localZipFile.finish();
/*  66 */     return localFile;
/*     */   }
/*     */ 
/*     */   public static File compress(File paramFile, String paramString)
/*     */   {
/*  79 */     if (!isFileValid(paramFile))
/*  80 */       throw new IllegalArgumentException("Invalid file to compress.");
/*  81 */     if ((paramString == null) || (paramString.length() == 0)) {
/*  82 */       throw new IllegalArgumentException(
/*  83 */         "Invalid zip file path and name.");
/*     */     }
/*  85 */     return zipAFile(paramString, paramFile);
/*     */   }
/*     */ 
/*     */   public static File compress(String paramString1, String paramString2)
/*     */   {
/*  99 */     File localFile = getFileObject(paramString1);
/*     */ 
/* 101 */     return compress(localFile, paramString2);
/*     */   }
/*     */ 
/*     */   private static File zipFiles(String paramString, File[] paramArrayOfFile) {
/* 105 */     File localFile = new File(paramString);
/* 106 */     ZipFile localZipFile = new ZipFile(localFile);
/* 107 */     for (int i = 0; i < paramArrayOfFile.length; i++) {
/*     */       try {
/* 109 */         localZipFile.addFile(paramArrayOfFile[i], null);
/*     */       } catch (RuntimeException localRuntimeException) {
/* 111 */         localZipFile.closeZipOutputStream();
/* 112 */         throw localRuntimeException;
/*     */       }
/*     */     }
/* 115 */     localZipFile.finish();
/* 116 */     return localFile;
/*     */   }
/*     */ 
/*     */   public static File compress(File[] paramArrayOfFile, String paramString)
/*     */   {
/* 130 */     FileArrayValidResult localFileArrayValidResult = isFileArrayValid(paramArrayOfFile);
/* 131 */     if (!localFileArrayValidResult.isSucc()) {
/* 132 */       if (localFileArrayValidResult.getInvalidFile() == null) {
/* 133 */         throw new IllegalArgumentException(
/* 134 */           "Invalid file array to compress. File array is null.");
/*     */       }
/* 136 */       throw new IllegalArgumentException(
/* 137 */         "Invalid file in array to compress. Invalid file name is " + 
/* 138 */         localFileArrayValidResult.getInvalidFile().getName());
/*     */     }
/*     */ 
/* 141 */     if ((paramString == null) || (paramString.length() == 0)) {
/* 142 */       throw new IllegalArgumentException(
/* 143 */         "Invalid zip file path and name.");
/*     */     }
/* 145 */     return zipFiles(paramString, paramArrayOfFile);
/*     */   }
/*     */ 
/*     */   private static boolean checkAndMakeFolder(String paramString) {
/* 149 */     if (paramString == null)
/* 150 */       return false;
/* 151 */     File localFile = new File(paramString);
/* 152 */     if ((localFile.exists()) && (localFile.isDirectory()))
/* 153 */       return true;
/* 154 */     return localFile.mkdirs();
/*     */   }
/*     */ 
/*     */   private static String buildZipFilePathAndName(String paramString1, String paramString2) {
/* 158 */     if (!paramString1.endsWith(File.separator)) {
/* 159 */       return paramString1 + File.separator + paramString2;
/*     */     }
/* 161 */     return paramString1 + paramString2;
/*     */   }
/*     */ 
/*     */   public static File compress(File paramFile, String paramString1, String paramString2)
/*     */   {
/* 177 */     if (!isFileValid(paramFile)) {
/* 178 */       throw new IllegalArgumentException("Invalid file to compress.");
/*     */     }
/*     */ 
/* 182 */     if (!checkAndMakeFolder(paramString1))
/* 183 */       throw new CompressorException(
/* 184 */         "EAPTECH005631", null);
/* 185 */     if ((paramString2 == null) || (paramString2.length() == 0)) {
/* 186 */       throw new IllegalArgumentException("Invalid zip file name.");
/*     */     }
/* 188 */     return zipAFile(buildZipFilePathAndName(paramString1, paramString2), 
/* 189 */       paramFile);
/*     */   }
/*     */ 
/*     */   public static File compress(String paramString1, String paramString2, String paramString3)
/*     */   {
/* 205 */     File localFile = getFileObject(paramString1);
/* 206 */     return compress(localFile, paramString2, paramString3);
/*     */   }
/*     */ 
/*     */   public static File compress(File[] paramArrayOfFile, String paramString1, String paramString2)
/*     */   {
/* 222 */     if (paramString1 == null)
/* 223 */       throw new IllegalArgumentException(
/* 224 */         "Invalid zip file path. Zip file path is null.");
/* 225 */     FileArrayValidResult localFileArrayValidResult = isFileArrayValid(paramArrayOfFile);
/* 226 */     if (!localFileArrayValidResult.isSucc()) {
/* 227 */       if (localFileArrayValidResult.getInvalidFile() == null) {
/* 228 */         throw new IllegalArgumentException(
/* 229 */           "Invalid file array to compress. File array is null.");
/*     */       }
/* 231 */       throw new IllegalArgumentException(
/* 232 */         "Invalid file in array to compress. Invalid file name is " + 
/* 233 */         localFileArrayValidResult.getInvalidFile().getName());
/*     */     }
/*     */ 
/* 238 */     if (!checkAndMakeFolder(paramString1)) {
/* 239 */       throw new CompressorException(
/* 240 */         "EAPTECH005631", null);
/*     */     }
/* 242 */     if ((paramString2 == null) || (paramString2.length() == 0))
/* 243 */       throw new IllegalArgumentException("Invalid zip file name.");
/* 244 */     return zipFiles(buildZipFilePathAndName(paramString1, paramString2), 
/* 245 */       paramArrayOfFile);
/*     */   }
/*     */ 
/*     */   private static File zipAFolder(File paramFile, String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 251 */     File localFile = new File(paramString);
/* 252 */     ZipFile localZipFile = new ZipFile(localFile);
/*     */     try {
/* 254 */       localZipFile.addFolder(paramFile, paramBoolean1, paramBoolean2);
/*     */     } catch (RuntimeException localRuntimeException) {
/* 256 */       localZipFile.closeZipOutputStream();
/* 257 */       throw localRuntimeException;
/*     */     }
/* 259 */     localZipFile.finish();
/* 260 */     return localFile;
/*     */   }
/*     */ 
/*     */   private static File zipFolders(File[] paramArrayOfFile, String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 265 */     File localFile = new File(paramString);
/* 266 */     ZipFile localZipFile = new ZipFile(localFile);
/* 267 */     for (int i = 0; i < paramArrayOfFile.length; i++) {
/*     */       try {
/* 269 */         localZipFile.addFolder(paramArrayOfFile[i], paramBoolean1, paramBoolean2);
/*     */       } catch (RuntimeException localRuntimeException) {
/* 271 */         localZipFile.closeZipOutputStream();
/* 272 */         throw localRuntimeException;
/*     */       }
/*     */     }
/* 275 */     localZipFile.finish();
/* 276 */     return localFile;
/*     */   }
/*     */ 
/*     */   public static File compress(File paramFile, String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 294 */     if (!isFolderValid(paramFile))
/* 295 */       throw new IllegalArgumentException("Invalid folder to compress.");
/* 296 */     if ((paramString == null) || (paramString.length() == 0)) {
/* 297 */       throw new IllegalArgumentException(
/* 298 */         "Invalid zip file path and name.");
/*     */     }
/* 300 */     return zipAFolder(paramFile, paramString, paramBoolean1, 
/* 301 */       paramBoolean2);
/*     */   }
/*     */ 
/*     */   public static File compress(File paramFile, String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 321 */     if (!isFolderValid(paramFile)) {
/* 322 */       throw new IllegalArgumentException("Invalid folder to compress.");
/*     */     }
/*     */ 
/* 326 */     if (!checkAndMakeFolder(paramString1))
/* 327 */       throw new CompressorException(
/* 328 */         "EAPTECH005631", null);
/* 329 */     if ((paramString2 == null) || ("".equals(paramString2)))
/* 330 */       throw new IllegalArgumentException("zipFileName can not be null.");
/* 331 */     return zipAFolder(paramFile, buildZipFilePathAndName(
/* 332 */       paramString1, paramString2), paramBoolean1, paramBoolean2);
/*     */   }
/*     */ 
/*     */   public static File compress(String paramString1, String paramString2, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 350 */     File localFile = getFileObject(paramString1);
/* 351 */     return compress(localFile, paramString2, paramBoolean1, 
/* 352 */       paramBoolean2);
/*     */   }
/*     */ 
/*     */   public static File compress(String paramString1, String paramString2, String paramString3, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 373 */     File localFile = new File(paramString1);
/* 374 */     return compress(localFile, paramString2, paramString3, 
/* 375 */       paramBoolean1, paramBoolean2);
/*     */   }
/*     */ 
/*     */   public static void compress(File[] paramArrayOfFile, String paramString, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 392 */     FileArrayValidResult localFileArrayValidResult = isFolderArrayValid(paramArrayOfFile);
/* 393 */     if (!localFileArrayValidResult.isSucc()) {
/* 394 */       if (localFileArrayValidResult.getInvalidFile() == null) {
/* 395 */         throw new IllegalArgumentException(
/* 396 */           "Invalid folder array to compress. Folder array is null.");
/*     */       }
/* 398 */       throw new IllegalArgumentException(
/* 399 */         "Invalid folder in array to compress. Invalid folder name is " + 
/* 400 */         localFileArrayValidResult.getInvalidFile().getName());
/*     */     }
/* 402 */     if ((paramString == null) || (paramString.length() == 0)) {
/* 403 */       throw new IllegalArgumentException(
/* 404 */         "Invalid zip file path and name.");
/*     */     }
/* 406 */     zipFolders(paramArrayOfFile, paramString, paramBoolean1, 
/* 407 */       paramBoolean2);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.CompressUtil
 * JD-Core Version:    0.6.2
 */