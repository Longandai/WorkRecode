/*     */ package com.neusoft.unieap.core.util.compressor;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import org.apache.commons.compress.archivers.ArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
/*     */ import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
/*     */ 
/*     */ public class ZipFile
/*     */ {
/*     */   public static final String MIME_TYPE = "application/zip";
/*     */   public static final int DEFAULT_COMPRESS_LEVEL = 3;
/*  38 */   private static final String PATH_SEPRATOR = File.separator;
/*     */   private static final int BUFFER_SIZE = 10240;
/*  42 */   private static FileFilter ff = new FileFilter();
/*     */   private ZipArchiveOutputStream zipOutputStream;
/*  45 */   private boolean closeOutputStream = false;
/*  46 */   private boolean fileFinished = false;
/*     */ 
/*     */   public ZipFile(OutputStream paramOutputStream)
/*     */   {
/*  55 */     if (paramOutputStream == null)
/*  56 */       throw new IllegalArgumentException("outputstream is null.");
/*  57 */     this.zipOutputStream = new ZipArchiveOutputStream(paramOutputStream);
/*  58 */     this.zipOutputStream.setLevel(3);
/*  59 */     this.zipOutputStream.setEncoding(System.getProperty("file.encoding"));
/*     */   }
/*     */ 
/*     */   public ZipFile(File paramFile)
/*     */   {
/*  69 */     if (paramFile == null)
/*  70 */       throw new IllegalArgumentException("outputFile is null.");
/*     */     try
/*     */     {
/*  73 */       this.zipOutputStream = new ZipArchiveOutputStream(
/*  74 */         new BufferedOutputStream(new FileOutputStream(paramFile), 
/*  75 */         10240));
/*  76 */       this.zipOutputStream.setLevel(3);
/*  77 */       this.zipOutputStream.setEncoding(System.getProperty("file.encoding"));
/*  78 */       this.closeOutputStream = true;
/*     */     } catch (FileNotFoundException localFileNotFoundException) {
/*  80 */       throw new CompressorException(
/*  81 */         "EAPTECH005600", localFileNotFoundException, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setLevel(int paramInt)
/*     */   {
/*  92 */     this.zipOutputStream.setLevel(paramInt);
/*     */   }
/*     */ 
/*     */   private String processFilePathInZip(String paramString) {
/*  96 */     if (paramString == null) {
/*  97 */       paramString = "";
/*     */     } else {
/*  99 */       if (paramString.startsWith(PATH_SEPRATOR))
/* 100 */         paramString = paramString.substring(1);
/* 101 */       if (!paramString.endsWith(PATH_SEPRATOR))
/* 102 */         paramString = paramString + PATH_SEPRATOR;
/*     */     }
/* 104 */     return paramString;
/*     */   }
/*     */ 
/*     */   public void addFile(File paramFile, String paramString)
/*     */   {
/* 116 */     if (this.fileFinished) {
/* 117 */       throw new CompressorException(
/* 118 */         "EAPTECH005610", null);
/*     */     }
/* 120 */     if ((!paramFile.exists()) || (!paramFile.canRead()) || (!paramFile.isFile()))
/* 121 */       throw new CompressorException(
/* 122 */         "EAPTECH005621", null);
/* 123 */     paramString = processFilePathInZip(paramString);
/*     */ 
/* 125 */     ZipArchiveEntry localZipArchiveEntry = new ZipArchiveEntry(paramString + paramFile.getName());
/*     */ 
/* 127 */     BufferedInputStream localBufferedInputStream = null;
/*     */     try {
/* 129 */       this.zipOutputStream.putArchiveEntry(localZipArchiveEntry);
/*     */ 
/* 131 */       localBufferedInputStream = new BufferedInputStream(new FileInputStream(paramFile), 10240);
/*     */       int i;
/* 133 */       while ((i = localBufferedInputStream.read()) != -1) {
/* 134 */         this.zipOutputStream.write(i);
/*     */       }
/* 136 */       this.zipOutputStream.flush();
/*     */ 
/* 138 */       this.zipOutputStream.closeArchiveEntry();
/*     */     }
/*     */     catch (FileNotFoundException localFileNotFoundException) {
/* 141 */       throw new CompressorException(
/* 142 */         "EAPTECH005621", localFileNotFoundException, null);
/*     */     } catch (IOException localIOException1) {
/* 144 */       throw new CompressorException(
/* 145 */         "EAPTECH005650", 
/* 146 */         localIOException1, null);
/*     */     } finally {
/* 148 */       if (localBufferedInputStream != null)
/*     */         try {
/* 150 */           localBufferedInputStream.close();
/*     */         } catch (IOException localIOException2) {
/* 152 */           localIOException2.printStackTrace();
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void zip(File paramFile, ZipArchiveOutputStream paramZipArchiveOutputStream, String paramString, boolean paramBoolean)
/*     */     throws IOException
/*     */   {
/*     */     Object localObject;
/* 159 */     if (paramFile.isDirectory()) {
/* 160 */       localObject = (File[])null;
/* 161 */       if (paramBoolean)
/* 162 */         localObject = paramFile.listFiles();
/*     */       else {
/* 164 */         localObject = paramFile.listFiles(ff);
/*     */       }
/* 166 */       if (paramString.length() > 0) {
/* 167 */         paramString = paramString + PATH_SEPRATOR;
/* 168 */         ZipArchiveEntry localZipArchiveEntry = new ZipArchiveEntry(paramString);
/* 169 */         paramZipArchiveOutputStream.putArchiveEntry(localZipArchiveEntry);
/* 170 */         paramZipArchiveOutputStream.closeArchiveEntry();
/*     */       }
/*     */ 
/* 173 */       for (int i = 0; i < localObject.length; i++)
/* 174 */         zip(localObject[i], paramZipArchiveOutputStream, paramString + localObject[i].getName(), paramBoolean);
/*     */     }
/*     */     else {
/* 177 */       localObject = new ZipArchiveEntry(paramString);
/* 178 */       paramZipArchiveOutputStream.putArchiveEntry((ArchiveEntry)localObject);
/* 179 */       byte[] arrayOfByte = new byte[10240];
/* 180 */       BufferedInputStream localBufferedInputStream = new BufferedInputStream(
/* 181 */         new FileInputStream(paramFile), 10240);
/*     */       int j;
/* 184 */       while ((j = localBufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length)) != -1) {
/* 185 */         paramZipArchiveOutputStream.write(arrayOfByte, 0, j);
/*     */       }
/* 187 */       paramZipArchiveOutputStream.flush();
/* 188 */       localBufferedInputStream.close();
/* 189 */       paramZipArchiveOutputStream.closeArchiveEntry();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addFolder(File paramFile, boolean paramBoolean1, boolean paramBoolean2)
/*     */   {
/* 204 */     if (this.fileFinished) {
/* 205 */       throw new CompressorException(
/* 206 */         "EAPTECH005610", null);
/*     */     }
/* 208 */     if ((!paramFile.exists()) || (!paramFile.canRead()) || (!paramFile.isDirectory())) {
/* 209 */       throw new CompressorException(
/* 210 */         "EAPTECH005622", null);
/*     */     }
/* 212 */     String str = "";
/* 213 */     if (paramBoolean1) {
/* 214 */       ZipArchiveEntry localZipArchiveEntry = new ZipArchiveEntry(paramFile.getName() + 
/* 215 */         PATH_SEPRATOR);
/*     */       try {
/* 217 */         this.zipOutputStream.putArchiveEntry(localZipArchiveEntry);
/* 218 */         this.zipOutputStream.closeArchiveEntry();
/*     */       } catch (IOException localIOException2) {
/* 220 */         throw new CompressorException(
/* 221 */           "EAPTECH005650", 
/* 222 */           localIOException2, null);
/*     */       }
/* 224 */       str = paramFile.getName();
/*     */     }
/*     */     try
/*     */     {
/* 228 */       zip(paramFile, this.zipOutputStream, str, paramBoolean2);
/*     */     } catch (IOException localIOException1) {
/* 230 */       throw new CompressorException(
/* 231 */         "EAPTECH005650", 
/* 232 */         localIOException1, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addFile(InputStream paramInputStream, String paramString, boolean paramBoolean)
/*     */   {
/* 249 */     if (this.fileFinished) {
/* 250 */       throw new CompressorException(
/* 251 */         "EAPTECH005610", null);
/*     */     }
/* 253 */     if (paramInputStream == null)
/* 254 */       throw new IllegalArgumentException("inputStream is null.");
/* 255 */     if (paramString == null) {
/* 256 */       throw new IllegalArgumentException("filePathAndNameInZip is null.");
/*     */     }
/* 258 */     ZipArchiveEntry localZipArchiveEntry = new ZipArchiveEntry(paramString);
/*     */ 
/* 260 */     BufferedInputStream localBufferedInputStream = null;
/*     */     try {
/* 262 */       this.zipOutputStream.putArchiveEntry(localZipArchiveEntry);
/*     */ 
/* 264 */       localBufferedInputStream = new BufferedInputStream(paramInputStream, 10240);
/*     */       int i;
/* 266 */       while ((i = localBufferedInputStream.read()) != -1) {
/* 267 */         this.zipOutputStream.write(i);
/*     */       }
/* 269 */       this.zipOutputStream.flush();
/* 270 */       this.zipOutputStream.closeArchiveEntry();
/*     */     }
/*     */     catch (IOException localIOException1) {
/* 273 */       if (localBufferedInputStream != null)
/*     */         try {
/* 275 */           localBufferedInputStream.close();
/*     */         } catch (IOException localIOException2) {
/* 277 */           localIOException2.printStackTrace();
/*     */         }
/* 279 */       throw new CompressorException(
/* 280 */         "EAPTECH005650", 
/* 281 */         localIOException1, null);
/*     */     } finally {
/* 283 */       if ((paramBoolean) && (localBufferedInputStream != null))
/*     */         try {
/* 285 */           localBufferedInputStream.close();
/*     */         } catch (IOException localIOException3) {
/* 287 */           localIOException3.printStackTrace();
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void finish()
/*     */   {
/* 297 */     if (!this.fileFinished)
/*     */       try {
/* 299 */         this.zipOutputStream.finish();
/* 300 */         if (this.closeOutputStream) {
/* 301 */           this.zipOutputStream.close();
/*     */         }
/* 303 */         this.fileFinished = true;
/*     */       } catch (IOException localIOException) {
/* 305 */         throw new CompressorException(
/* 306 */           "EAPTECH005650", 
/* 307 */           localIOException, null);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void setComment(String paramString)
/*     */   {
/* 318 */     if (this.fileFinished)
/* 319 */       throw new CompressorException(
/* 320 */         "EAPTECH005610", null);
/* 321 */     this.zipOutputStream.setComment(paramString);
/*     */   }
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 330 */     return this.zipOutputStream.getEncoding();
/*     */   }
/*     */ 
/*     */   public void setEncoding(String paramString)
/*     */   {
/* 340 */     if (this.fileFinished)
/* 341 */       throw new CompressorException(
/* 342 */         "EAPTECH005610", null);
/* 343 */     this.zipOutputStream.setEncoding(paramString);
/*     */   }
/*     */ 
/*     */   void closeZipOutputStream()
/*     */   {
/*     */     try
/*     */     {
/* 351 */       if (this.closeOutputStream)
/* 352 */         this.zipOutputStream.close();
/*     */     } catch (IOException localIOException) {
/* 354 */       localIOException.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.ZipFile
 * JD-Core Version:    0.6.2
 */