/*    */ package com.neusoft.unieap.core.util.compressor;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPException;
/*    */ 
/*    */ public class CompressorException extends UniEAPException
/*    */ {
/*    */   private static final long serialVersionUID = -295021195274861303L;
/*    */ 
/*    */   public CompressorException(String paramString, Object[] paramArrayOfObject)
/*    */   {
/* 10 */     super(paramString, paramArrayOfObject);
/*    */   }
/*    */ 
/*    */   public CompressorException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject) {
/* 14 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.compressor.CompressorException
 * JD-Core Version:    0.6.2
 */