/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import org.bouncycastle.util.encoders.UrlBase64;
/*    */ 
/*    */ public class UrlBase64Util
/*    */ {
/*    */   public static String encode(String paramString)
/*    */   {
/* 17 */     byte[] arrayOfByte = UrlBase64.encode(paramString.getBytes());
/* 18 */     return new String(arrayOfByte);
/*    */   }
/*    */ 
/*    */   public static String decode(String paramString)
/*    */   {
/* 27 */     byte[] arrayOfByte = UrlBase64.decode(paramString.getBytes());
/* 28 */     return new String(arrayOfByte);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.UrlBase64Util
 * JD-Core Version:    0.6.2
 */