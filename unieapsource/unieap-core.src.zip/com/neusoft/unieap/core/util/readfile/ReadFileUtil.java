/*    */ package com.neusoft.unieap.core.util.readfile;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.CommonException;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class ReadFileUtil
/*    */ {
/*    */   public static String readFile(String paramString1, String paramString2, Class paramClass)
/*    */   {
/* 14 */     String str = null;
/* 15 */     Properties localProperties = new Properties();
/* 16 */     InputStream localInputStream = paramClass.getResourceAsStream(paramString1);
/*    */     try
/*    */     {
/* 19 */       localProperties.load(localInputStream);
/* 20 */       str = localProperties.getProperty(paramString2);
/*    */     } catch (RuntimeException localRuntimeException) {
/* 22 */       throw new CommonException("EAPTECH012001", localRuntimeException, 
/* 23 */         new String[] { paramString1 });
/*    */     } catch (IOException localIOException1) {
/* 25 */       throw new CommonException("EAPTECH012001", localIOException1, 
/* 26 */         new String[] { paramString1 });
/*    */     } finally {
/* 28 */       if (localInputStream != null) {
/*    */         try {
/* 30 */           localInputStream.close();
/*    */         } catch (IOException localIOException2) {
/* 32 */           throw new CommonException(
/* 33 */             "EAPTECH012001", localIOException2, 
/* 34 */             new String[] { paramString1 });
/*    */         }
/*    */       }
/*    */     }
/*    */ 
/* 39 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.readfile.ReadFileUtil
 * JD-Core Version:    0.6.2
 */