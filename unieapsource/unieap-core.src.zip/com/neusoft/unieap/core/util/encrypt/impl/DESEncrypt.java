/*     */ package com.neusoft.unieap.core.util.encrypt.impl;
/*     */ 
/*     */ import com.neusoft.unieap.core.util.encrypt.AbstractEncrypt;
/*     */ import com.neusoft.unieap.core.util.encrypt.exception.EncryptException;
/*     */ import java.security.SecureRandom;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.DESKeySpec;
/*     */ 
/*     */ public class DESEncrypt extends AbstractEncrypt
/*     */ {
/*  24 */   private String cryptKey = "fghjkl;'qwertyuiop[]\\1234567890-=` ZXCVBNM<>?:LKJHGFDSAQWERTYUI";
/*     */ 
/*  28 */   private String algorithm = "DES";
/*     */ 
/*     */   public String decrypt(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  37 */       return new String(decrypt(hex2byte(paramString.getBytes()), this.cryptKey.getBytes()));
/*     */     } catch (Exception localException) {
/*  39 */       throw new EncryptException("EAPTECH019002", localException, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String encrypt(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  50 */       return byte2hex(encrypt(paramString.getBytes(), this.cryptKey
/*  51 */         .getBytes()));
/*     */     } catch (Exception localException) {
/*  53 */       throw new EncryptException("EAPTECH019001", localException, null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private byte[] encrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */     throws Exception
/*     */   {
/*  68 */     SecureRandom localSecureRandom = new SecureRandom();
/*     */ 
/*  70 */     DESKeySpec localDESKeySpec = new DESKeySpec(paramArrayOfByte2);
/*     */ 
/*  73 */     SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(this.algorithm);
/*  74 */     SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localDESKeySpec);
/*     */ 
/*  76 */     Cipher localCipher = Cipher.getInstance(this.algorithm);
/*     */ 
/*  78 */     localCipher.init(1, localSecretKey, localSecureRandom);
/*     */ 
/*  81 */     return localCipher.doFinal(paramArrayOfByte1);
/*     */   }
/*     */ 
/*     */   private byte[] decrypt(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2)
/*     */     throws Exception
/*     */   {
/*  97 */     SecureRandom localSecureRandom = new SecureRandom();
/*     */ 
/*  99 */     DESKeySpec localDESKeySpec = new DESKeySpec(paramArrayOfByte2);
/*     */ 
/* 102 */     SecretKeyFactory localSecretKeyFactory = SecretKeyFactory.getInstance(this.algorithm);
/* 103 */     SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localDESKeySpec);
/*     */ 
/* 105 */     Cipher localCipher = Cipher.getInstance(this.algorithm);
/*     */ 
/* 107 */     localCipher.init(2, localSecretKey, localSecureRandom);
/*     */ 
/* 110 */     return localCipher.doFinal(paramArrayOfByte1);
/*     */   }
/*     */ 
/*     */   private String byte2hex(byte[] paramArrayOfByte)
/*     */   {
/* 119 */     StringBuffer localStringBuffer = new StringBuffer("");
/* 120 */     String str = "";
/* 121 */     for (int i = 0; i < paramArrayOfByte.length; i++) {
/* 122 */       str = Integer.toHexString(paramArrayOfByte[i] & 0xFF);
/* 123 */       if (str.length() == 1)
/* 124 */         localStringBuffer.append("0").append(str);
/*     */       else
/* 126 */         localStringBuffer.append(str);
/*     */     }
/* 128 */     return localStringBuffer.toString().toUpperCase();
/*     */   }
/*     */ 
/*     */   private byte[] hex2byte(byte[] paramArrayOfByte) {
/* 132 */     if (paramArrayOfByte.length % 2 != 0)
/* 133 */       throw new IllegalArgumentException("the length of input is not even number! ");
/* 134 */     byte[] arrayOfByte = new byte[paramArrayOfByte.length / 2];
/* 135 */     for (int i = 0; i < paramArrayOfByte.length; i += 2) {
/* 136 */       String str = new String(paramArrayOfByte, i, 2);
/* 137 */       arrayOfByte[(i / 2)] = ((byte)Integer.parseInt(str, 16));
/*     */     }
/* 139 */     return arrayOfByte;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.impl.DESEncrypt
 * JD-Core Version:    0.6.2
 */