/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.KeyAgreement;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.interfaces.DHPrivateKey;
/*     */ import javax.crypto.interfaces.DHPublicKey;
/*     */ import javax.crypto.spec.DHParameterSpec;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DHCoderUtil
/*     */ {
/*     */   private static final String PUBLIC_KEY = "DHPublicKey";
/*     */   private static final String PRIVATE_KEY = "DHPrivateKey";
/*  39 */   private static final Log LOG = LogFactory.getLog(DHCoderUtil.class);
/*     */   public static final int KEY_SIZE = 1024;
/*     */ 
/*     */   public static Map<String, Object> createSecretKey()
/*     */   {
/*     */     try
/*     */     {
/*  59 */       KeyPairGenerator localKeyPairGenerator = 
/*  60 */         KeyPairGenerator.getInstance("DH");
/*     */ 
/*  62 */       localKeyPairGenerator.initialize(1024);
/*     */ 
/*  64 */       KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
/*     */ 
/*  66 */       DHPublicKey localDHPublicKey = (DHPublicKey)localKeyPair.getPublic();
/*     */ 
/*  68 */       DHPrivateKey localDHPrivateKey = (DHPrivateKey)localKeyPair.getPrivate();
/*     */ 
/*  70 */       HashMap localHashMap = new HashMap(2);
/*  71 */       localHashMap.put("DHPublicKey", localDHPublicKey);
/*  72 */       localHashMap.put("DHPrivateKey", localDHPrivateKey);
/*  73 */       return localHashMap;
/*     */     }
/*     */     catch (Exception localException) {
/*  76 */       LOG.error("创建DH密钥出错!");
/*  77 */       localException.printStackTrace();
/*     */     }
/*  79 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> createSecretKey(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  93 */       if (StringUtils.isNotBlank(paramString))
/*     */       {
/*  95 */         byte[] arrayOfByte = BASECoderUtil.decryptBASE64(paramString);
/*     */ 
/*  97 */         X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(
/*  98 */           arrayOfByte);
/*     */ 
/* 100 */         KeyFactory localKeyFactory = 
/* 101 */           KeyFactory.getInstance("DH");
/*     */ 
/* 103 */         PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
/*     */ 
/* 105 */         DHParameterSpec localDHParameterSpec = ((DHPublicKey)localPublicKey)
/* 106 */           .getParams();
/*     */ 
/* 108 */         KeyPairGenerator localKeyPairGenerator = 
/* 109 */           KeyPairGenerator.getInstance(localKeyFactory.getAlgorithm());
/*     */ 
/* 111 */         localKeyPairGenerator.initialize(localDHParameterSpec);
/*     */ 
/* 113 */         KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
/*     */ 
/* 115 */         DHPublicKey localDHPublicKey = (DHPublicKey)localKeyPair.getPublic();
/*     */ 
/* 117 */         DHPrivateKey localDHPrivateKey = (DHPrivateKey)localKeyPair.getPrivate();
/*     */ 
/* 119 */         HashMap localHashMap = new HashMap(2);
/* 120 */         localHashMap.put("DHPublicKey", localDHPublicKey);
/* 121 */         localHashMap.put("DHPrivateKey", localDHPrivateKey);
/* 122 */         return localHashMap;
/*     */       }
/*     */ 
/* 125 */       LOG.error("根据DH公钥创建DH密钥中公钥不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 128 */       LOG.error("根据DH公钥创建DH密钥出错!");
/* 129 */       localException.printStackTrace();
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encrypt(byte[] paramArrayOfByte, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 148 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 149 */         (StringUtils.isNotBlank(paramString1)) && 
/* 150 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 152 */         SecretKey localSecretKey = getSecretKey(paramString1, paramString2);
/*     */ 
/* 154 */         Cipher localCipher = Cipher.getInstance(localSecretKey.getAlgorithm());
/*     */ 
/* 156 */         localCipher.init(1, localSecretKey);
/*     */ 
/* 158 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/* 160 */       LOG.error("DH加密中待加密数据、公钥 、私钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 164 */       LOG.error("DH加密出错!");
/* 165 */       localException.printStackTrace();
/*     */     }
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decrypt(byte[] paramArrayOfByte, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 186 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 187 */         (StringUtils.isNotBlank(paramString1)) && 
/* 188 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 190 */         SecretKey localSecretKey = getSecretKey(paramString1, paramString2);
/*     */ 
/* 192 */         Cipher localCipher = Cipher.getInstance(localSecretKey.getAlgorithm());
/*     */ 
/* 194 */         localCipher.init(2, localSecretKey);
/*     */ 
/* 196 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/*     */ 
/* 199 */       LOG.error("DH解密中待解密数据 、公钥、私钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 203 */       LOG.error("DH解密出错!");
/* 204 */       localException.printStackTrace();
/*     */     }
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */   private static SecretKey getSecretKey(String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 222 */       if ((StringUtils.isNotBlank(paramString1)) && 
/* 223 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 226 */         KeyFactory localKeyFactory = 
/* 227 */           KeyFactory.getInstance("DH");
/*     */ 
/* 230 */         byte[] arrayOfByte1 = BASECoderUtil.decryptBASE64(paramString1);
/*     */ 
/* 232 */         X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(
/* 233 */           arrayOfByte1);
/*     */ 
/* 235 */         PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
/*     */ 
/* 238 */         byte[] arrayOfByte2 = BASECoderUtil.decryptBASE64(paramString2);
/*     */ 
/* 240 */         PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(
/* 241 */           arrayOfByte2);
/*     */ 
/* 243 */         PrivateKey localPrivateKey = localKeyFactory.generatePrivate(localPKCS8EncodedKeySpec);
/*     */ 
/* 246 */         KeyAgreement localKeyAgreement = KeyAgreement.getInstance(localKeyFactory
/* 247 */           .getAlgorithm());
/* 248 */         localKeyAgreement.init(localPrivateKey);
/* 249 */         localKeyAgreement.doPhase(localPublicKey, true);
/*     */ 
/* 252 */         return localKeyAgreement
/* 253 */           .generateSecret("DES");
/*     */       }
/*     */ 
/* 258 */       LOG.equals("根据DH公钥,DH私钥构建密钥中公钥、私钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 262 */       LOG.error("根据DH公钥,DH私钥构建密钥出错!");
/* 263 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 266 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getPriKey(Map<String, Object> paramMap)
/*     */   {
/*     */     try
/*     */     {
/* 280 */       if (!paramMap.isEmpty()) {
/* 281 */         Key localKey = (Key)paramMap.get("DHPrivateKey");
/* 282 */         return BASECoderUtil.encryptBASE64(localKey.getEncoded());
/*     */       }
/* 284 */       LOG.error("从DH密钥中获取私钥中DH密钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 288 */       LOG.error("从DH密钥中获取私钥出错!");
/* 289 */       localException.printStackTrace();
/*     */     }
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getPubKey(Map<String, Object> paramMap)
/*     */   {
/*     */     try
/*     */     {
/* 305 */       if (!paramMap.isEmpty()) {
/* 306 */         Key localKey = (Key)paramMap.get("DHPublicKey");
/* 307 */         return BASECoderUtil.encryptBASE64(localKey.getEncoded());
/*     */       }
/* 309 */       LOG.error("从DH密钥中获取公钥中DH密钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 313 */       LOG.error("从DH密钥中获取公钥出错!");
/* 314 */       localException.printStackTrace();
/*     */     }
/* 316 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.DHCoderUtil
 * JD-Core Version:    0.6.2
 */