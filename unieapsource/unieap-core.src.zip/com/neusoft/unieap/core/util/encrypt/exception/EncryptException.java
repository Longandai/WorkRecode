/*    */ package com.neusoft.unieap.core.util.encrypt.exception;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class EncryptException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 153839560774277184L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 15 */     return true;
/*    */   }
/*    */ 
/*    */   public EncryptException(String paramString, Throwable paramThrowable, Object[] paramArrayOfObject) {
/* 19 */     super(paramString, paramThrowable, paramArrayOfObject);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.exception.EncryptException
 * JD-Core Version:    0.6.2
 */