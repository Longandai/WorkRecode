/*    */ package com.neusoft.unieap.core.util.encrypt;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.encrypt.impl.EncryptManager;
/*    */ 
/*    */ public class EncryptUtil
/*    */ {
/*    */   public static String encrypt(String paramString)
/*    */   {
/* 19 */     if ((paramString == null) || (paramString.equalsIgnoreCase("")))
/* 20 */       return paramString;
/* 21 */     AbstractEncrypt localAbstractEncrypt = EncryptManager.getEncrypt();
/* 22 */     return localAbstractEncrypt.encrypt(paramString);
/*    */   }
/*    */ 
/*    */   public static String decrypt(String paramString)
/*    */   {
/* 31 */     if ((paramString == null) || (paramString.equalsIgnoreCase("")))
/* 32 */       return paramString;
/* 33 */     AbstractEncrypt localAbstractEncrypt = EncryptManager.getEncrypt();
/* 34 */     return localAbstractEncrypt.decrypt(paramString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.EncryptUtil
 * JD-Core Version:    0.6.2
 */