/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import sun.misc.BASE64Decoder;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public class BASECoderUtil
/*     */ {
/*  25 */   private static final Log LOG = LogFactory.getLog(BASECoderUtil.class);
/*     */ 
/*     */   public static String encryptBASE64(byte[] paramArrayOfByte)
/*     */   {
/*     */     try
/*     */     {
/*  37 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0)) {
/*  38 */         return new BASE64Encoder().encodeBuffer(paramArrayOfByte);
/*     */       }
/*  40 */       LOG.error("BASE64加密中待加密数据不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/*  43 */       LOG.error("BASE64加密出错!");
/*  44 */       localException.printStackTrace();
/*     */     }
/*  46 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decryptBASE64(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  59 */       if (StringUtils.isNotBlank(paramString)) {
/*  60 */         return new BASE64Decoder().decodeBuffer(paramString);
/*     */       }
/*  62 */       LOG.error("BASE64解密中待解密数据不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/*  65 */       LOG.error("BASE64解密出错!");
/*  66 */       localException.printStackTrace();
/*     */     }
/*  68 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encryptMD5(byte[] paramArrayOfByte)
/*     */   {
/*     */     try
/*     */     {
/*  81 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0))
/*     */       {
/*  83 */         MessageDigest localMessageDigest = 
/*  84 */           MessageDigest.getInstance("MD5");
/*     */ 
/*  86 */         localMessageDigest.update(paramArrayOfByte);
/*     */ 
/*  88 */         return localMessageDigest.digest();
/*     */       }
/*  90 */       LOG.error("MD5加密中待加密数据不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  94 */       LOG.error("MD5加密出错!");
/*  95 */       localException.printStackTrace();
/*     */     }
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encryptSHA(byte[] paramArrayOfByte)
/*     */   {
/*     */     try
/*     */     {
/* 110 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0)) {
/* 111 */         MessageDigest localMessageDigest = 
/* 112 */           MessageDigest.getInstance("SHA");
/* 113 */         localMessageDigest.update(paramArrayOfByte);
/* 114 */         return localMessageDigest.digest();
/*     */       }
/* 116 */       LOG.error("SHA加密中待加密数据不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 119 */       LOG.error("SHA加密出错!");
/* 120 */       localException.printStackTrace();
/*     */     }
/* 122 */     return null;
/*     */   }
/*     */ 
/*     */   public static String createHMacSecretKey()
/*     */   {
/*     */     try
/*     */     {
/* 135 */       KeyGenerator localKeyGenerator = 
/* 136 */         KeyGenerator.getInstance("HmacMD5");
/*     */ 
/* 138 */       SecretKey localSecretKey = localKeyGenerator.generateKey();
/*     */ 
/* 140 */       return encryptBASE64(localSecretKey.getEncoded());
/*     */     }
/*     */     catch (Exception localException) {
/* 143 */       LOG.error("创建HMAC密钥出错!");
/* 144 */       localException.printStackTrace();
/*     */     }
/* 146 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encryptHMAC(byte[] paramArrayOfByte, String paramString)
/*     */   {
/*     */     try
/*     */     {
/* 162 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)))
/*     */       {
/* 164 */         SecretKeySpec localSecretKeySpec = new SecretKeySpec(decryptBASE64(paramString), 
/* 165 */           "HmacMD5");
/*     */ 
/* 167 */         Mac localMac = Mac.getInstance(localSecretKeySpec.getAlgorithm());
/*     */ 
/* 169 */         localMac.init(localSecretKeySpec);
/*     */ 
/* 171 */         return localMac.doFinal(paramArrayOfByte);
/*     */       }
/* 173 */       LOG.error("HMAC加密中待加密数据,密钥不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 176 */       LOG.error("HMAC加密出错!");
/* 177 */       localException.printStackTrace();
/*     */     }
/* 179 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.BASECoderUtil
 * JD-Core Version:    0.6.2
 */