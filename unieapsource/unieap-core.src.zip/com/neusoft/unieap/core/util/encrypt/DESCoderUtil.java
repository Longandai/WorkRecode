/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import java.security.SecureRandom;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.DESKeySpec;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DESCoderUtil
/*     */ {
/*  26 */   private static final Log LOG = LogFactory.getLog(DESCoderUtil.class);
/*     */ 
/*     */   public static String createSecureKeyBySeed(String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  38 */       if (StringUtils.isNotBlank(paramString))
/*     */       {
/*  40 */         SecureRandom localSecureRandom = null;
/*  41 */         if (paramString != null)
/*  42 */           localSecureRandom = new SecureRandom(
/*  43 */             BASECoderUtil.decryptBASE64(paramString));
/*     */         else {
/*  45 */           localSecureRandom = new SecureRandom();
/*     */         }
/*     */ 
/*  48 */         KeyGenerator localKeyGenerator = 
/*  49 */           KeyGenerator.getInstance("DES");
/*     */ 
/*  51 */         localKeyGenerator.init(localSecureRandom);
/*     */ 
/*  53 */         SecretKey localSecretKey = localKeyGenerator.generateKey();
/*     */ 
/*  55 */         return BASECoderUtil.encryptBASE64(localSecretKey.getEncoded());
/*     */       }
/*  57 */       LOG.error("DES加密根据种子生成密钥中种子不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/*  60 */       localException.printStackTrace();
/*  61 */       LOG.error("DES加密根据种子生成密钥出错!");
/*     */     }
/*  63 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decrypt(byte[] paramArrayOfByte, String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  79 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)))
/*     */       {
/*  81 */         byte[] arrayOfByte = BASECoderUtil.decryptBASE64(paramString);
/*     */ 
/*  83 */         DESKeySpec localDESKeySpec = new DESKeySpec(arrayOfByte);
/*     */ 
/*  85 */         SecretKeyFactory localSecretKeyFactory = 
/*  86 */           SecretKeyFactory.getInstance("DES");
/*     */ 
/*  88 */         SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localDESKeySpec);
/*     */ 
/*  94 */         Cipher localCipher = Cipher.getInstance(localSecretKeyFactory.getAlgorithm());
/*     */ 
/*  96 */         localCipher.init(2, localSecretKey);
/*     */ 
/*  98 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/* 100 */       LOG.error("DES解密中待解密数据,密钥不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 103 */       localException.printStackTrace();
/* 104 */       LOG.error("DES解密出错!");
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encrypt(byte[] paramArrayOfByte, String paramString)
/*     */   {
/*     */     try
/*     */     {
/* 122 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)))
/*     */       {
/* 125 */         byte[] arrayOfByte = BASECoderUtil.decryptBASE64(paramString);
/*     */ 
/* 127 */         DESKeySpec localDESKeySpec = new DESKeySpec(arrayOfByte);
/*     */ 
/* 129 */         SecretKeyFactory localSecretKeyFactory = 
/* 130 */           SecretKeyFactory.getInstance("DES");
/*     */ 
/* 132 */         SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localDESKeySpec);
/*     */ 
/* 137 */         Cipher localCipher = Cipher.getInstance(localSecretKeyFactory.getAlgorithm());
/* 138 */         localCipher.init(1, localSecretKey);
/* 139 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/*     */ 
/* 142 */       LOG.error("DES加密中待加密数据、密钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 146 */       LOG.error("DES加密出错!");
/* 147 */       localException.printStackTrace();
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.DESCoderUtil
 * JD-Core Version:    0.6.2
 */