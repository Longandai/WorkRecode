/*    */ package com.neusoft.unieap.core.util.encrypt.impl;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.encrypt.AbstractEncrypt;
/*    */ import com.neusoft.unieap.core.util.encrypt.exception.EncryptException;
/*    */ 
/*    */ public class EncryptManager
/*    */ {
/*    */   private static AbstractEncrypt encrypt;
/* 20 */   private static boolean isInit = false;
/*    */ 
/*    */   public static AbstractEncrypt getEncrypt()
/*    */   {
/* 28 */     if (!isInit)
/* 29 */       throw new EncryptException("EAPTECH019003", null, null);
/* 30 */     return encrypt;
/*    */   }
/*    */ 
/*    */   public static void registerEncrypt(AbstractEncrypt paramAbstractEncrypt)
/*    */   {
/* 38 */     encrypt = paramAbstractEncrypt;
/* 39 */     isInit = true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.impl.EncryptManager
 * JD-Core Version:    0.6.2
 */