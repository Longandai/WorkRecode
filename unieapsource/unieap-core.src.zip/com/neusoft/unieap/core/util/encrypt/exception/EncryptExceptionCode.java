package com.neusoft.unieap.core.util.encrypt.exception;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class EncryptExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "019";
  private static final String _P = "EAPTECH019";
  public static final String ENCRYPT_FAILURE = "EAPTECH019001";
  public static final String DECRYPT_FAILURE = "EAPTECH019002";
  public static final String ENCRYPT_NOT_FOUND = "EAPTECH019003";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.exception.EncryptExceptionCode
 * JD-Core Version:    0.6.2
 */