/*   */ package com.neusoft.unieap.core.util.encrypt.conf;
/*   */ 
/*   */ public enum KeyType
/*   */ {
/* 5 */   PUBLIC_KEY, 
/* 6 */   PRIVATE_KEY;
/*   */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.conf.KeyType
 * JD-Core Version:    0.6.2
 */