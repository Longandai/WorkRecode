/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import com.neusoft.unieap.core.util.encrypt.conf.KeyType;
/*     */ import java.security.Key;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPair;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.interfaces.RSAPrivateKey;
/*     */ import java.security.interfaces.RSAPublicKey;
/*     */ import java.security.spec.KeySpec;
/*     */ import java.security.spec.PKCS8EncodedKeySpec;
/*     */ import java.security.spec.X509EncodedKeySpec;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.crypto.Cipher;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class RSACoderUtil
/*     */ {
/*     */   private static final String PUBLIC_KEY = "RSAPublicKey";
/*     */   private static final String PRIVATE_KEY = "RSAPrivateKey";
/*  38 */   private static final Log LOG = LogFactory.getLog(RSACoderUtil.class);
/*     */ 
/*     */   public static String sign(byte[] paramArrayOfByte, String paramString)
/*     */   {
/*     */     try
/*     */     {
/*  53 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/*  54 */         (StringUtils.isNotBlank(paramString)))
/*     */       {
/*  56 */         byte[] arrayOfByte = BASECoderUtil.decryptBASE64(paramString);
/*     */ 
/*  58 */         PKCS8EncodedKeySpec localPKCS8EncodedKeySpec = new PKCS8EncodedKeySpec(
/*  59 */           arrayOfByte);
/*     */ 
/*  61 */         KeyFactory localKeyFactory = 
/*  62 */           KeyFactory.getInstance("RSA");
/*     */ 
/*  64 */         PrivateKey localPrivateKey = localKeyFactory
/*  65 */           .generatePrivate(localPKCS8EncodedKeySpec);
/*     */ 
/*  67 */         Signature localSignature = 
/*  68 */           Signature.getInstance("MD5withRSA");
/*     */ 
/*  70 */         localSignature.initSign(localPrivateKey);
/*     */ 
/*  72 */         localSignature.update(paramArrayOfByte);
/*  73 */         return BASECoderUtil.encryptBASE64(localSignature.sign());
/*     */       }
/*  75 */       LOG.error("通过RSA私钥对信息生成数字签名中加密数据 、私钥不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  79 */       LOG.error("通过RSA私钥对信息生成数字签名出错!");
/*  80 */       localException.printStackTrace();
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean verify(byte[] paramArrayOfByte, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 100 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 101 */         (StringUtils.isNotBlank(paramString1)) && 
/* 102 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 105 */         byte[] arrayOfByte = BASECoderUtil.decryptBASE64(paramString1);
/*     */ 
/* 107 */         X509EncodedKeySpec localX509EncodedKeySpec = new X509EncodedKeySpec(arrayOfByte);
/*     */ 
/* 109 */         KeyFactory localKeyFactory = 
/* 110 */           KeyFactory.getInstance("RSA");
/*     */ 
/* 112 */         PublicKey localPublicKey = localKeyFactory.generatePublic(localX509EncodedKeySpec);
/*     */ 
/* 114 */         Signature localSignature = 
/* 115 */           Signature.getInstance("MD5withRSA");
/*     */ 
/* 117 */         localSignature.initVerify(localPublicKey);
/*     */ 
/* 119 */         localSignature.update(paramArrayOfByte);
/*     */ 
/* 121 */         return localSignature.verify(BASECoderUtil.decryptBASE64(paramString2));
/*     */       }
/*     */ 
/* 124 */       LOG.error("校验数字签名中加密数据、公钥 、数字签名不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 128 */       LOG.error("校验数字签名出错!");
/* 129 */       localException.printStackTrace();
/*     */     }
/* 131 */     return false;
/*     */   }
/*     */ 
/*     */   public static byte[] encrypt(byte[] paramArrayOfByte, String paramString, KeyType paramKeyType)
/*     */   {
/*     */     try
/*     */     {
/* 147 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)))
/*     */       {
/* 149 */         if (KeyType.PUBLIC_KEY.equals(paramKeyType))
/* 150 */           return encryptOrDecryptByKey(paramArrayOfByte, paramString, 
/* 151 */             1, KeyType.PUBLIC_KEY);
/* 152 */         if (KeyType.PRIVATE_KEY.equals(paramKeyType))
/* 153 */           return encryptOrDecryptByKey(paramArrayOfByte, paramString, 
/* 154 */             1, KeyType.PRIVATE_KEY);
/*     */       }
/*     */       else {
/* 157 */         LOG.error("RSA加密中待加密数据、密钥、密钥类型不能为空!");
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {
/* 161 */       LOG.error("RSA加密出错!");
/* 162 */       localException.printStackTrace();
/*     */     }
/* 164 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decrypt(byte[] paramArrayOfByte, String paramString, KeyType paramKeyType)
/*     */   {
/*     */     try
/*     */     {
/* 180 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)))
/*     */       {
/* 182 */         if (KeyType.PUBLIC_KEY.equals(paramKeyType))
/* 183 */           return encryptOrDecryptByKey(paramArrayOfByte, paramString, 
/* 184 */             2, KeyType.PUBLIC_KEY);
/* 185 */         if (KeyType.PRIVATE_KEY.equals(paramKeyType))
/* 186 */           return encryptOrDecryptByKey(paramArrayOfByte, paramString, 
/* 187 */             2, KeyType.PRIVATE_KEY);
/*     */       }
/*     */       else {
/* 190 */         LOG.error("RSA解密中待解密数据、密钥、密钥类型不能为空!");
/*     */       }
/*     */     } catch (Exception localException) {
/* 193 */       LOG.error("RSA解密出错!");
/* 194 */       localException.printStackTrace();
/*     */     }
/* 196 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getPriKey(Map<String, Object> paramMap)
/*     */   {
/*     */     try
/*     */     {
/* 209 */       if (!paramMap.isEmpty()) {
/* 210 */         Key localKey = (Key)paramMap.get("RSAPrivateKey");
/* 211 */         return BASECoderUtil.encryptBASE64(localKey.getEncoded());
/*     */       }
/* 213 */       LOG.error("RSA密钥中获取私钥中密钥对儿不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 216 */       LOG.error("RSA密钥中获取私钥失败!");
/*     */     }
/* 218 */     return null;
/*     */   }
/*     */ 
/*     */   public static String getPubKey(Map<String, Object> paramMap)
/*     */   {
/*     */     try
/*     */     {
/* 232 */       if (!paramMap.isEmpty()) {
/* 233 */         Key localKey = (Key)paramMap.get("RSAPublicKey");
/* 234 */         return BASECoderUtil.encryptBASE64(localKey.getEncoded());
/*     */       }
/* 236 */       LOG.error("RSA密钥中获取公钥中密钥对儿不能为空!");
/*     */     }
/*     */     catch (Exception localException) {
/* 239 */       LOG.error("RSA密钥中获取公钥失败!");
/*     */     }
/*     */ 
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   public static Map<String, Object> createSecureKey()
/*     */   {
/*     */     try
/*     */     {
/* 255 */       KeyPairGenerator localKeyPairGenerator = 
/* 256 */         KeyPairGenerator.getInstance("RSA");
/*     */ 
/* 258 */       localKeyPairGenerator.initialize(1024);
/*     */ 
/* 260 */       KeyPair localKeyPair = localKeyPairGenerator.generateKeyPair();
/*     */ 
/* 262 */       RSAPublicKey localRSAPublicKey = (RSAPublicKey)localKeyPair.getPublic();
/*     */ 
/* 264 */       RSAPrivateKey localRSAPrivateKey = (RSAPrivateKey)localKeyPair.getPrivate();
/*     */ 
/* 266 */       HashMap localHashMap = new HashMap(2);
/* 267 */       localHashMap.put("RSAPublicKey", localRSAPublicKey);
/* 268 */       localHashMap.put("RSAPrivateKey", localRSAPrivateKey);
/* 269 */       return localHashMap;
/*     */     }
/*     */     catch (Exception localException) {
/* 272 */       LOG.error("创建RSA密钥出错!");
/* 273 */       localException.printStackTrace();
/*     */     }
/* 275 */     return null;
/*     */   }
/*     */ 
/*     */   private static byte[] encryptOrDecryptByKey(byte[] paramArrayOfByte, String paramString, int paramInt, KeyType paramKeyType)
/*     */     throws Exception
/*     */   {
/* 295 */     Object localObject1 = null;
/*     */ 
/* 298 */     KeyFactory localKeyFactory = 
/* 299 */       KeyFactory.getInstance("RSA");
/* 300 */     if (KeyType.PUBLIC_KEY.equals(paramKeyType))
/*     */     {
/* 302 */       localObject2 = new X509EncodedKeySpec(
/* 303 */         BASECoderUtil.decryptBASE64(paramString));
/* 304 */       localObject1 = localKeyFactory.generatePublic((KeySpec)localObject2);
/* 305 */     } else if (KeyType.PRIVATE_KEY.equals(paramKeyType))
/*     */     {
/* 307 */       localObject2 = new PKCS8EncodedKeySpec(
/* 308 */         BASECoderUtil.decryptBASE64(paramString));
/* 309 */       localObject1 = localKeyFactory.generatePrivate((KeySpec)localObject2);
/*     */     }
/*     */ 
/* 312 */     Object localObject2 = Cipher.getInstance(localKeyFactory.getAlgorithm());
/*     */ 
/* 314 */     ((Cipher)localObject2).init(paramInt, (Key)localObject1);
/*     */ 
/* 316 */     return ((Cipher)localObject2).doFinal(paramArrayOfByte);
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.RSACoderUtil
 * JD-Core Version:    0.6.2
 */