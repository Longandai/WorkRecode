/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import java.util.Random;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.SecretKeyFactory;
/*     */ import javax.crypto.spec.PBEKeySpec;
/*     */ import javax.crypto.spec.PBEParameterSpec;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class PBECoderUtil
/*     */ {
/*  26 */   private static final Log LOG = LogFactory.getLog(PBECoderUtil.class);
/*     */ 
/*     */   public static byte[] createSalt()
/*     */   {
/*  34 */     byte[] arrayOfByte = new byte[8];
/*  35 */     Random localRandom = new Random();
/*  36 */     localRandom.nextBytes(arrayOfByte);
/*  37 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   public static byte[] encrypt(byte[] paramArrayOfByte1, String paramString, byte[] paramArrayOfByte2)
/*     */   {
/*     */     try
/*     */     {
/*  55 */       if ((paramArrayOfByte1 != null) && (paramArrayOfByte1.length > 0) && (StringUtils.isNotBlank(paramString)) && 
/*  56 */         (paramArrayOfByte2 != null) && (paramArrayOfByte2.length > 0))
/*     */       {
/*  58 */         PBEKeySpec localPBEKeySpec = new PBEKeySpec(paramString.toCharArray());
/*     */ 
/*  60 */         SecretKeyFactory localSecretKeyFactory = 
/*  61 */           SecretKeyFactory.getInstance("PBEWITHMD5andDES");
/*     */ 
/*  63 */         SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localPBEKeySpec);
/*     */ 
/*  65 */         PBEParameterSpec localPBEParameterSpec = new PBEParameterSpec(paramArrayOfByte2, 100);
/*  66 */         Cipher localCipher = Cipher.getInstance(localSecretKeyFactory.getAlgorithm());
/*  67 */         localCipher.init(1, localSecretKey, localPBEParameterSpec);
/*  68 */         return localCipher.doFinal(paramArrayOfByte1);
/*     */       }
/*     */ 
/*  71 */       LOG.error("PBE加密中待加密数据、密码、盐不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  75 */       LOG.error("PBE加密出错!");
/*  76 */       localException.printStackTrace();
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decrypt(byte[] paramArrayOfByte1, String paramString, byte[] paramArrayOfByte2)
/*     */   {
/*     */     try
/*     */     {
/*  96 */       if ((paramArrayOfByte1 != null) && (paramArrayOfByte1.length > 0) && (StringUtils.isNotBlank(paramString)) && 
/*  97 */         (paramArrayOfByte2 != null) && (paramArrayOfByte2.length > 0))
/*     */       {
/*  99 */         PBEKeySpec localPBEKeySpec = new PBEKeySpec(paramString.toCharArray());
/*     */ 
/* 101 */         SecretKeyFactory localSecretKeyFactory = 
/* 102 */           SecretKeyFactory.getInstance("PBEWITHMD5andDES");
/*     */ 
/* 104 */         SecretKey localSecretKey = localSecretKeyFactory.generateSecret(localPBEKeySpec);
/*     */ 
/* 106 */         PBEParameterSpec localPBEParameterSpec = new PBEParameterSpec(paramArrayOfByte2, 100);
/* 107 */         Cipher localCipher = Cipher.getInstance(localSecretKeyFactory.getAlgorithm());
/* 108 */         localCipher.init(2, localSecretKey, localPBEParameterSpec);
/* 109 */         return localCipher.doFinal(paramArrayOfByte1);
/*     */       }
/* 111 */       LOG.error("PBE解密中待解密数据、密码、盐不能为空!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 115 */       LOG.error("PBE解密出错!");
/* 116 */       localException.printStackTrace();
/*     */     }
/* 118 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.PBECoderUtil
 * JD-Core Version:    0.6.2
 */