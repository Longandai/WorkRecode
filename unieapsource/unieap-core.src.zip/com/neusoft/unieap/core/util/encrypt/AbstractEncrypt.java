/*    */ package com.neusoft.unieap.core.util.encrypt;
/*    */ 
/*    */ import com.neusoft.unieap.core.util.encrypt.impl.EncryptManager;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public abstract class AbstractEncrypt
/*    */   implements InitializingBean
/*    */ {
/*    */   public final void afterPropertiesSet()
/*    */     throws Exception
/*    */   {
/* 19 */     EncryptManager.registerEncrypt(this);
/*    */   }
/*    */ 
/*    */   public abstract String encrypt(String paramString);
/*    */ 
/*    */   public abstract String decrypt(String paramString);
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.AbstractEncrypt
 * JD-Core Version:    0.6.2
 */