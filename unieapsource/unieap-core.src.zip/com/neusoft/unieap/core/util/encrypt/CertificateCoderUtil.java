/*     */ package com.neusoft.unieap.core.util.encrypt;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.security.KeyStore;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateFactory;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Date;
/*     */ import javax.crypto.Cipher;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class CertificateCoderUtil
/*     */ {
/*     */   public static final String KEY_STORE = "JKS";
/*     */   public static final String X509 = "X.509";
/*     */   public static final String EXT_KEYSTORE = "keystore";
/*     */   public static final String EXT_CER = "cer";
/*  43 */   private static final Log LOG = LogFactory.getLog(CertificateCoderUtil.class);
/*     */ 
/*     */   private static PrivateKey getPrivateKey(File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/*  61 */       if ((validateFile(paramFile, "keystore")) && 
/*  62 */         (StringUtils.isNotBlank(paramString1)) && 
/*  63 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/*  65 */         KeyStore localKeyStore = getKeyStore(paramFile, paramString2);
/*  66 */         return (PrivateKey)localKeyStore.getKey(paramString1, paramString2
/*  67 */           .toCharArray());
/*     */       }
/*     */ 
/*  71 */       LOG.error("密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/*  75 */       LOG.error("从密钥库文件中获得私钥出错!");
/*  76 */       localException.printStackTrace();
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */   private static PublicKey getPublicKey(File paramFile)
/*     */   {
/*     */     try
/*     */     {
/*  92 */       if (validateFile(paramFile, "cer"))
/*     */       {
/*  94 */         Certificate localCertificate = getCertificate(paramFile);
/*  95 */         return localCertificate.getPublicKey();
/*     */       }
/*     */ 
/*  99 */       LOG.error("数字证书、公钥不能为空,且数字证书为.cer文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 103 */       LOG.error("通过数字证书获得公钥公钥出错!");
/* 104 */       localException.printStackTrace();
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   private static Certificate getCertificate(File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 120 */       if (validateFile(paramFile, "cer")) {
/* 121 */         CertificateFactory localCertificateFactory = 
/* 122 */           CertificateFactory.getInstance("X.509");
/* 123 */         FileInputStream localFileInputStream = new FileInputStream(paramFile);
/* 124 */         Certificate localCertificate = localCertificateFactory
/* 125 */           .generateCertificate(localFileInputStream);
/* 126 */         localFileInputStream.close();
/* 127 */         return localCertificate;
/*     */       }
/* 129 */       LOG.error("数字证书文件不能为空且数字证书为.cer文件!");
/*     */     }
/*     */     catch (Exception localException) {
/* 132 */       LOG.error("获得数字证书出错!");
/* 133 */       localException.printStackTrace();
/*     */     }
/* 135 */     return null;
/*     */   }
/*     */ 
/*     */   private static Certificate getCertificate(File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       if ((validateFile(paramFile, "keystore")) && 
/* 155 */         (StringUtils.isNotBlank(paramString1)) && 
/* 156 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 158 */         KeyStore localKeyStore = getKeyStore(paramFile, paramString2);
/* 159 */         return localKeyStore.getCertificate(paramString1);
/*     */       }
/*     */ 
/* 163 */       LOG.error("密钥库文件、别名、密码不能为空,且密钥库文件为.keystore!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 167 */       LOG.error("通过密钥库文件,别名，密码获得数字证书出错!");
/* 168 */       localException.printStackTrace();
/*     */     }
/* 170 */     return null;
/*     */   }
/*     */ 
/*     */   private static KeyStore getKeyStore(File paramFile, String paramString)
/*     */   {
/*     */     try
/*     */     {
/* 186 */       if ((validateFile(paramFile, "keystore")) && 
/* 187 */         (StringUtils.isNotBlank(paramString))) {
/* 188 */         FileInputStream localFileInputStream = new FileInputStream(paramFile);
/* 189 */         KeyStore localKeyStore = KeyStore.getInstance("JKS");
/* 190 */         localKeyStore.load(localFileInputStream, paramString.toCharArray());
/* 191 */         localFileInputStream.close();
/* 192 */         return localKeyStore;
/*     */       }
/* 194 */       LOG.error("密钥库文件、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException) {
/* 197 */       LOG.error("获得密钥库文件出错!");
/* 198 */       localException.printStackTrace();
/*     */     }
/* 200 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encryptByPrivateKey(byte[] paramArrayOfByte, File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 221 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 222 */         (validateFile(paramFile, "keystore")) && 
/* 223 */         (StringUtils.isNotBlank(paramString1)) && 
/* 224 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 227 */         PrivateKey localPrivateKey = getPrivateKey(paramFile, paramString1, 
/* 228 */           paramString2);
/*     */ 
/* 230 */         Cipher localCipher = Cipher.getInstance(localPrivateKey.getAlgorithm());
/* 231 */         localCipher.init(1, localPrivateKey);
/* 232 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/*     */ 
/* 235 */       LOG.error("待加密数据、密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 239 */       LOG.error("私钥加密出错!");
/* 240 */       localException.printStackTrace();
/*     */     }
/* 242 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decryptByPrivateKey(byte[] paramArrayOfByte, File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 263 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 264 */         (validateFile(paramFile, "keystore")) && 
/* 265 */         (StringUtils.isNotBlank(paramString1)) && 
/* 266 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 268 */         PrivateKey localPrivateKey = getPrivateKey(paramFile, paramString1, 
/* 269 */           paramString2);
/*     */ 
/* 271 */         Cipher localCipher = Cipher.getInstance(localPrivateKey.getAlgorithm());
/* 272 */         localCipher.init(2, localPrivateKey);
/* 273 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/*     */ 
/* 276 */       LOG.error("待解密数据、密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 280 */       LOG.error("私钥解密出错!");
/* 281 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 284 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] encryptByPublicKey(byte[] paramArrayOfByte, File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 300 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 301 */         (validateFile(paramFile, "cer")))
/*     */       {
/* 303 */         PublicKey localPublicKey = getPublicKey(paramFile);
/*     */ 
/* 305 */         Cipher localCipher = Cipher.getInstance(localPublicKey.getAlgorithm());
/* 306 */         localCipher.init(1, localPublicKey);
/* 307 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/* 309 */       LOG.error("待加密数据、数字证书不能为空,且数字证书为.cer!文件");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 313 */       LOG.error("公钥加密出错!");
/* 314 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 317 */     return null;
/*     */   }
/*     */ 
/*     */   public static byte[] decryptByPublicKey(byte[] paramArrayOfByte, File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 333 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 334 */         (validateFile(paramFile, "cer")))
/*     */       {
/* 336 */         PublicKey localPublicKey = getPublicKey(paramFile);
/*     */ 
/* 339 */         Cipher localCipher = Cipher.getInstance(localPublicKey.getAlgorithm());
/* 340 */         localCipher.init(2, localPublicKey);
/*     */ 
/* 342 */         return localCipher.doFinal(paramArrayOfByte);
/*     */       }
/*     */ 
/* 345 */       LOG.error("待解密数据、数字证书不能为空,且数字证书为.cer文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 349 */       LOG.error("公钥解密出错!");
/* 350 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 353 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean verifyCertificate(File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 367 */       if (validateFile(paramFile, "cer")) {
/* 368 */         return verifyCertificate(new Date(), paramFile);
/*     */       }
/* 370 */       LOG.error("数字证书不能为空,且数字证书为.cer文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 374 */       LOG.error("验证数字证书 出错!");
/* 375 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 378 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean verifyCertificate(Date paramDate, File paramFile)
/*     */   {
/* 390 */     boolean bool = false;
/*     */     try
/*     */     {
/* 393 */       if (validateFile(paramFile, "cer"))
/*     */       {
/* 395 */         Certificate localCertificate = getCertificate(paramFile);
/*     */ 
/* 397 */         bool = verifyCertificate(paramDate, localCertificate);
/*     */       } else {
/* 399 */         LOG.error("数字证书不能为空,且数字证书为.cer!");
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {
/* 403 */       LOG.error("验证数字证书是否过期或无效出错!");
/* 404 */       localException.printStackTrace();
/*     */     }
/* 406 */     return bool;
/*     */   }
/*     */ 
/*     */   private static boolean verifyCertificate(Date paramDate, Certificate paramCertificate)
/*     */   {
/* 419 */     boolean bool = true;
/*     */     try {
/* 421 */       if ((paramDate != null) && (paramCertificate != null)) {
/* 422 */         X509Certificate localX509Certificate = (X509Certificate)paramCertificate;
/* 423 */         localX509Certificate.checkValidity(paramDate);
/*     */       } else {
/* 425 */         LOG.error("时间、数字证书不能为空!");
/*     */       }
/*     */     }
/*     */     catch (Exception localException) {
/* 429 */       bool = false;
/* 430 */       LOG.error("验证证书是否过期或无效出错!");
/* 431 */       localException.printStackTrace();
/*     */     }
/* 433 */     return bool;
/*     */   }
/*     */ 
/*     */   public static String sign(byte[] paramArrayOfByte, File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 454 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && 
/* 455 */         (validateFile(paramFile, "keystore")) && 
/* 456 */         (StringUtils.isNotBlank(paramString1)) && 
/* 457 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 460 */         X509Certificate localX509Certificate = (X509Certificate)getCertificate(
/* 461 */           paramFile, paramString1, paramString2);
/*     */ 
/* 463 */         KeyStore localKeyStore = getKeyStore(paramFile, paramString2);
/*     */ 
/* 465 */         PrivateKey localPrivateKey = (PrivateKey)localKeyStore.getKey(paramString1, paramString2
/* 466 */           .toCharArray());
/*     */ 
/* 468 */         Signature localSignature = Signature.getInstance(localX509Certificate
/* 469 */           .getSigAlgName());
/* 470 */         localSignature.initSign(localPrivateKey);
/* 471 */         localSignature.update(paramArrayOfByte);
/* 472 */         return BASECoderUtil.encryptBASE64(localSignature.sign());
/*     */       }
/*     */ 
/* 475 */       LOG.error("签名、密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 479 */       LOG.error("数字签名失败!");
/* 480 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 483 */     return null;
/*     */   }
/*     */ 
/*     */   public static boolean verify(byte[] paramArrayOfByte, String paramString, File paramFile)
/*     */   {
/*     */     try
/*     */     {
/* 501 */       if ((paramArrayOfByte != null) && (paramArrayOfByte.length > 0) && (StringUtils.isNotBlank(paramString)) && 
/* 502 */         (validateFile(paramFile, "cer")))
/*     */       {
/* 504 */         X509Certificate localX509Certificate = (X509Certificate)getCertificate(paramFile);
/*     */ 
/* 506 */         PublicKey localPublicKey = localX509Certificate.getPublicKey();
/*     */ 
/* 508 */         Signature localSignature = Signature.getInstance(localX509Certificate
/* 509 */           .getSigAlgName());
/* 510 */         localSignature.initVerify(localPublicKey);
/* 511 */         localSignature.update(paramArrayOfByte);
/*     */ 
/* 513 */         return localSignature.verify(BASECoderUtil.decryptBASE64(paramString));
/*     */       }
/* 515 */       LOG.error("待验证数据、签名、数字证书不能为空,且数字证书为.cer文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 519 */       LOG.error("验证签名出错!");
/* 520 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 523 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean verifyCertificate(Date paramDate, File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 544 */       if ((paramDate != null) && (validateFile(paramFile, "keystore")) && 
/* 545 */         (StringUtils.isNotBlank(paramString1)) && 
/* 546 */         (StringUtils.isNotBlank(paramString2))) {
/* 547 */         Certificate localCertificate = getCertificate(paramFile, paramString1, 
/* 548 */           paramString2);
/* 549 */         return verifyCertificate(paramDate, localCertificate);
/*     */       }
/* 551 */       LOG.error("日期、密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException) {
/* 554 */       LOG.error("验证数字证书出错!");
/* 555 */       localException.printStackTrace();
/*     */     }
/* 557 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean verifyCertificate(File paramFile, String paramString1, String paramString2)
/*     */   {
/*     */     try
/*     */     {
/* 576 */       if ((validateFile(paramFile, "keystore")) && 
/* 577 */         (StringUtils.isNotBlank(paramString1)) && 
/* 578 */         (StringUtils.isNotBlank(paramString2)))
/*     */       {
/* 580 */         return verifyCertificate(new Date(), paramFile, paramString1, 
/* 581 */           paramString2);
/*     */       }
/* 583 */       LOG.error("密钥库文件、别名、密码不能为空,且密钥库文件为.keystore文件!");
/*     */     }
/*     */     catch (Exception localException)
/*     */     {
/* 587 */       LOG.error("验证Certificate出错!");
/* 588 */       localException.printStackTrace();
/*     */     }
/*     */ 
/* 591 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean validateFile(File paramFile, String paramString)
/*     */   {
/* 602 */     if (paramFile == null)
/* 603 */       return false;
/* 604 */     if (StringUtils.isBlank(getFileExtension(paramFile)))
/* 605 */       return false;
/* 606 */     if (!StringUtils.equals(getFileExtension(paramFile), paramString))
/* 607 */       return false;
/* 608 */     return true;
/*     */   }
/*     */ 
/*     */   private static String getFileExtension(File paramFile)
/*     */   {
/* 618 */     String str = paramFile.getName();
/* 619 */     if ((str.lastIndexOf(".") != -1) && (str.lastIndexOf(".") != 0)) {
/* 620 */       return str.substring(str.lastIndexOf(".") + 1);
/*     */     }
/* 622 */     return "";
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.CertificateCoderUtil
 * JD-Core Version:    0.6.2
 */