package com.neusoft.unieap.core.util.encrypt.conf;

public class ConstantAlgorithm
{
  public static final String ALGORITHM_SHA = "SHA";
  public static final String ALGORITHM_MD5 = "MD5";
  public static final String ALGORITHM_MAC = "HmacMD5";
  public static final String ALGORITHM_DES = "DES";
  public static final String ALGORITHM_PEB = "PBEWITHMD5andDES";
  public static final String ALGORITHM_DH = "DH";
  public static final String SECRET_ALGORITHM = "DES";
  public static final String ALGORITHM_RSA = "RSA";
  public static final String SIGNATURE_ALGORITHM = "MD5withRSA";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.encrypt.conf.ConstantAlgorithm
 * JD-Core Version:    0.6.2
 */