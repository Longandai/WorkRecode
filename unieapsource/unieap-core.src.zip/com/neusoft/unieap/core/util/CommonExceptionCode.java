package com.neusoft.unieap.core.util;

import com.neusoft.unieap.core.exception.UniEAPExceptionCode;

public class CommonExceptionCode extends UniEAPExceptionCode
{
  private static final String _MODULE_CODE = "012";
  private static final String P = "EAPTECH012";
  public static final String READFILE_FAILURE = "EAPTECH012001";
}

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.CommonExceptionCode
 * JD-Core Version:    0.6.2
 */