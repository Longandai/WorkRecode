/*     */ package com.neusoft.unieap.core.util;
/*     */ 
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class ConvertDateUtil
/*     */ {
/*     */   private static final String gmt = "GMT";
/*     */ 
/*     */   public static java.util.Date convertToGMT(java.util.Date paramDate, TimeZone paramTimeZone)
/*     */   {
/*  19 */     java.util.Date localDate = convertToGMTData(paramDate, paramTimeZone);
/*  20 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.util.Date convertToLocal(java.util.Date paramDate, TimeZone paramTimeZone)
/*     */   {
/*  30 */     java.util.Date localDate = convertToLocalData(paramDate, paramTimeZone);
/*  31 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.util.Date getDateByMillisecond(long paramLong, TimeZone paramTimeZone) {
/*  35 */     paramLong += paramTimeZone.getRawOffset() - TimeZone.getDefault().getRawOffset();
/*  36 */     java.util.Date localDate = new java.util.Date(paramLong);
/*  37 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static Timestamp convertToGMT(Timestamp paramTimestamp, TimeZone paramTimeZone) {
/*  41 */     Timestamp localTimestamp = (Timestamp)convertToGMTData(paramTimestamp, paramTimeZone);
/*  42 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public static Timestamp convertToLocal(Timestamp paramTimestamp, TimeZone paramTimeZone) {
/*  46 */     Timestamp localTimestamp = (Timestamp)convertToLocalData(paramTimestamp, paramTimeZone);
/*  47 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public static Timestamp getTimestampByMillisecond(long paramLong, TimeZone paramTimeZone) {
/*  51 */     paramLong += paramTimeZone.getRawOffset() - TimeZone.getDefault().getRawOffset();
/*  52 */     Timestamp localTimestamp = new Timestamp(paramLong);
/*  53 */     return localTimestamp;
/*     */   }
/*     */ 
/*     */   public static Time convertToGMT(Time paramTime, TimeZone paramTimeZone)
/*     */   {
/*  58 */     Time localTime = (Time)convertToGMTData(paramTime, paramTimeZone);
/*  59 */     return localTime;
/*     */   }
/*     */ 
/*     */   public static Time convertToLocal(Time paramTime, TimeZone paramTimeZone) {
/*  63 */     Time localTime = (Time)convertToLocalData(paramTime, paramTimeZone);
/*  64 */     return localTime;
/*     */   }
/*     */ 
/*     */   public static java.sql.Date convertToGMT(java.sql.Date paramDate, TimeZone paramTimeZone)
/*     */   {
/*  69 */     java.sql.Date localDate = (java.sql.Date)convertToGMTData(paramDate, paramTimeZone);
/*  70 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.sql.Date convertToLocal(java.sql.Date paramDate, TimeZone paramTimeZone) {
/*  74 */     java.sql.Date localDate = (java.sql.Date)convertToLocalData(paramDate, paramTimeZone);
/*  75 */     return localDate;
/*     */   }
/*     */ 
/*     */   public static java.sql.Date getSQLDateByMillisecond(long paramLong, TimeZone paramTimeZone) {
/*  79 */     paramLong += paramTimeZone.getRawOffset() - TimeZone.getDefault().getRawOffset();
/*  80 */     java.sql.Date localDate = new java.sql.Date(paramLong);
/*  81 */     return localDate;
/*     */   }
/*     */ 
/*     */   private static java.util.Date convertToGMTData(java.util.Date paramDate, TimeZone paramTimeZone) {
/*  85 */     Calendar localCalendar1 = Calendar.getInstance(paramTimeZone);
/*  86 */     localCalendar1.setTimeInMillis(paramDate.getTime());
/*  87 */     Calendar localCalendar2 = (Calendar)localCalendar1.clone();
/*  88 */     localCalendar1.setTimeZone(TimeZone.getTimeZone("GMT"));
/*  89 */     localCalendar2.set(1, localCalendar1.get(1));
/*  90 */     localCalendar2.set(2, localCalendar1.get(2));
/*  91 */     localCalendar2.set(5, localCalendar1.get(5));
/*  92 */     localCalendar2.set(11, localCalendar1.get(11));
/*  93 */     localCalendar2.set(12, localCalendar1.get(12));
/*  94 */     localCalendar2.set(13, localCalendar1.get(13));
/*  95 */     localCalendar2.set(14, localCalendar1.get(14));
/*  96 */     Object localObject = null;
/*  97 */     if ((paramDate instanceof Timestamp))
/*     */     {
/*  99 */       localObject = new Timestamp(localCalendar2.getTimeInMillis());
/* 100 */     } else if ((paramDate instanceof Time))
/*     */     {
/* 102 */       localObject = new Time(localCalendar2.getTimeInMillis());
/* 103 */     } else if ((paramDate instanceof java.sql.Date))
/*     */     {
/* 105 */       localObject = new java.sql.Date(localCalendar2.getTimeInMillis());
/*     */     }
/*     */     else
/*     */     {
/* 109 */       localObject = new java.util.Date(localCalendar2.getTimeInMillis());
/*     */     }
/*     */ 
/* 112 */     return localObject;
/*     */   }
/*     */ 
/*     */   private static java.util.Date convertToLocalData(java.util.Date paramDate, TimeZone paramTimeZone) {
/* 116 */     Calendar localCalendar1 = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/* 117 */     localCalendar1.setTimeInMillis(paramDate.getTime());
/* 118 */     Calendar localCalendar2 = (Calendar)localCalendar1.clone();
/* 119 */     localCalendar1.setTimeZone(paramTimeZone);
/* 120 */     localCalendar2.set(1, localCalendar1.get(1));
/* 121 */     localCalendar2.set(2, localCalendar1.get(2));
/* 122 */     localCalendar2.set(5, localCalendar1.get(5));
/* 123 */     localCalendar2.set(11, localCalendar1.get(11));
/* 124 */     localCalendar2.set(12, localCalendar1.get(12));
/* 125 */     localCalendar2.set(13, localCalendar1.get(13));
/* 126 */     localCalendar2.set(14, localCalendar1.get(14));
/* 127 */     Object localObject = null;
/* 128 */     if ((paramDate instanceof Timestamp))
/*     */     {
/* 130 */       localObject = new Timestamp(localCalendar2.getTimeInMillis());
/* 131 */     } else if ((paramDate instanceof Time))
/*     */     {
/* 133 */       localObject = new Time(localCalendar2.getTimeInMillis());
/* 134 */     } else if ((paramDate instanceof java.sql.Date))
/*     */     {
/* 136 */       localObject = new java.sql.Date(localCalendar2.getTimeInMillis());
/*     */     }
/*     */     else
/*     */     {
/* 140 */       localObject = new java.util.Date(localCalendar2.getTimeInMillis());
/*     */     }
/* 142 */     return localObject;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.ConvertDateUtil
 * JD-Core Version:    0.6.2
 */