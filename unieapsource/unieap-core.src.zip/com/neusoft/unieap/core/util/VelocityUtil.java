/*     */ package com.neusoft.unieap.core.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.io.FileUtils;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.tools.ToolContext;
/*     */ import org.apache.velocity.tools.ToolManager;
/*     */ 
/*     */ public class VelocityUtil
/*     */ {
/*     */   private static final String DEFAULT_ENCODING = "UTF-8";
/*     */   private static VelocityEngine engine;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  26 */       engine = initEngine();
/*     */     } catch (Exception localException) {
/*  28 */       localException.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static VelocityEngine getEngine()
/*     */   {
/*  21 */     return engine;
/*     */   }
/*     */ 
/*     */   private static VelocityEngine initEngine()
/*     */   {
/*  43 */     Properties localProperties = new Properties();
/*     */ 
/*  45 */     localProperties.setProperty("input.encoding", "UTF-8");
/*  46 */     localProperties
/*  47 */       .setProperty("output.encoding", "UTF-8");
/*  48 */     return initEngine(localProperties);
/*     */   }
/*     */ 
/*     */   private static VelocityEngine initEngine(Properties paramProperties)
/*     */   {
/*  60 */     VelocityEngine localVelocityEngine = new VelocityEngine();
/*  61 */     localVelocityEngine.init(paramProperties);
/*  62 */     return localVelocityEngine;
/*     */   }
/*     */ 
/*     */   public static VelocityContext getContext()
/*     */   {
/*  71 */     return getContext(null, null, null);
/*     */   }
/*     */ 
/*     */   public static VelocityContext getContext(Map<?, ?> paramMap)
/*     */   {
/*  82 */     return getContext(paramMap, null, null);
/*     */   }
/*     */ 
/*     */   public static VelocityContext getContext(Map<?, ?> paramMap, String paramString, VelocityEngine paramVelocityEngine)
/*     */   {
/*  99 */     ToolContext localToolContext = null;
/* 100 */     if ((paramString != null) && 
/* 101 */       (paramString.length() > 0)) {
/* 102 */       localObject = new ToolManager();
/* 103 */       ((ToolManager)localObject).configure(paramString);
/* 104 */       ((ToolManager)localObject).setVelocityEngine(paramVelocityEngine);
/* 105 */       localToolContext = ((ToolManager)localObject).createContext();
/*     */     }
/*     */ 
/* 108 */     if ((paramMap == null) && (localToolContext == null))
/* 109 */       return new VelocityContext();
/* 110 */     if ((paramMap != null) && (localToolContext == null))
/* 111 */       return new VelocityContext(paramMap);
/* 112 */     if ((paramMap == null) && (localToolContext != null)) {
/* 113 */       return new VelocityContext(localToolContext);
/*     */     }
/* 115 */     Object localObject = new VelocityContext(paramMap, localToolContext);
/* 116 */     if (localToolContext != null) {
/* 117 */       localToolContext.putToolProperty("velocityContext", localObject);
/*     */     }
/* 119 */     return localObject;
/*     */   }
/*     */ 
/*     */   public static String evaluateString(VelocityEngine paramVelocityEngine, VelocityContext paramVelocityContext, String paramString)
/*     */   {
/* 135 */     StringWriter localStringWriter = new StringWriter();
/* 136 */     paramVelocityEngine.evaluate(paramVelocityContext, localStringWriter, "", paramString);
/* 137 */     return localStringWriter.toString();
/*     */   }
/*     */ 
/*     */   public static String evaluateFile(VelocityEngine paramVelocityEngine, VelocityContext paramVelocityContext, File paramFile, String paramString)
/*     */     throws IOException
/*     */   {
/* 158 */     String str = FileUtils.readFileToString(paramFile, 
/* 159 */       paramString);
/* 160 */     return evaluateString(paramVelocityEngine, paramVelocityContext, str);
/*     */   }
/*     */ 
/*     */   public static String merge(String paramString, Map paramMap)
/*     */   {
/* 165 */     VelocityContext localVelocityContext = getContext(paramMap);
/* 166 */     String str = "";
/*     */     try {
/* 168 */       str = evaluateString(engine, localVelocityContext, paramString);
/*     */     } catch (Exception localException) {
/* 170 */       localException.printStackTrace();
/*     */     }
/* 172 */     return str;
/*     */   }
/*     */ 
/*     */   public static String evaluateFile(VelocityEngine paramVelocityEngine, VelocityContext paramVelocityContext, File paramFile)
/*     */     throws IOException
/*     */   {
/* 192 */     return evaluateFile(paramVelocityEngine, paramVelocityContext, paramFile, "UTF-8");
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.VelocityUtil
 * JD-Core Version:    0.6.2
 */