/*     */ package com.neusoft.unieap.core.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.annotation.Sequence;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ class EntityAnnotationParser
/*     */ {
/* 139 */   public static String SEQUENCE = "sequence";
/*     */ 
/*     */   public static Map<String, Map<String, Object>> getAnnotationInfo(Class paramClass) {
/* 142 */     HashMap localHashMap = new HashMap();
/* 143 */     Method[] arrayOfMethod1 = paramClass.getDeclaredMethods();
/* 144 */     for (Method localMethod : arrayOfMethod1) {
/* 145 */       Map localMap = constructMethod(localMethod);
/* 146 */       if (!localMap.isEmpty())
/*     */       {
/* 148 */         localHashMap.put(localMethod.getName(), localMap);
/*     */       }
/*     */     }
/* 150 */     return localHashMap;
/*     */   }
/*     */ 
/*     */   private static Map<String, Object> constructMethod(Method paramMethod)
/*     */   {
/* 161 */     HashMap localHashMap = new HashMap();
/* 162 */     boolean bool = paramMethod.isAnnotationPresent(Sequence.class);
/* 163 */     if (bool) {
/* 164 */       Sequence localSequence = (Sequence)paramMethod.getAnnotation(Sequence.class);
/* 165 */       localHashMap.put(SEQUENCE, localSequence.value());
/*     */     }
/*     */ 
/* 168 */     return localHashMap;
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.EntityAnnotationParser
 * JD-Core Version:    0.6.2
 */