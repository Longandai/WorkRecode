/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import org.springframework.web.context.ContextLoader;
/*    */ import org.springframework.web.context.WebApplicationContext;
/*    */ 
/*    */ public class BeanUtil
/*    */ {
/*    */   public static Object getBean(String paramString)
/*    */   {
/* 16 */     if (isEmpty(paramString)) {
/* 17 */       return null;
/*    */     }
/* 19 */     WebApplicationContext localWebApplicationContext = ContextLoader.getCurrentWebApplicationContext();
/* 20 */     return localWebApplicationContext.getBean(paramString);
/*    */   }
/*    */ 
/*    */   private static boolean isEmpty(String paramString) {
/* 24 */     return (paramString == null) || (paramString.trim().equals(""));
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.BeanUtil
 * JD-Core Version:    0.6.2
 */