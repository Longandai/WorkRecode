/*     */ package com.neusoft.unieap.core.util;
/*     */ 
/*     */ public abstract class Assert
/*     */ {
/*     */   public static void isTrue(boolean paramBoolean, String paramString)
/*     */   {
/*  38 */     if (!paramBoolean)
/*  39 */       throw new IllegalArgumentException(paramString);
/*     */   }
/*     */ 
/*     */   public static void isTrue(boolean paramBoolean)
/*     */   {
/*  51 */     isTrue(paramBoolean, "[Assertion failed] - this expression must be true");
/*     */   }
/*     */ 
/*     */   public static void isNull(Object paramObject, String paramString)
/*     */   {
/*  62 */     if (paramObject != null)
/*  63 */       throw new IllegalArgumentException(paramString);
/*     */   }
/*     */ 
/*     */   public static void isNull(Object paramObject)
/*     */   {
/*  74 */     isNull(paramObject, "[Assertion failed] - the object argument must be null");
/*     */   }
/*     */ 
/*     */   public static void notNull(Object paramObject, String paramString)
/*     */   {
/*  85 */     if (paramObject == null)
/*  86 */       throw new IllegalArgumentException(paramString);
/*     */   }
/*     */ 
/*     */   public static void notNull(Object paramObject)
/*     */   {
/*  97 */     notNull(paramObject, "[Assertion failed] - this argument is required; it must not be null");
/*     */   }
/*     */ 
/*     */   public static void isInstanceOf(Class paramClass, Object paramObject, String paramString)
/*     */   {
/* 114 */     notNull(paramClass, "Type to check against must not be null");
/* 115 */     if (!paramClass.isInstance(paramObject))
/* 116 */       throw new IllegalArgumentException(paramString + 
/* 117 */         "Object of class [" + (paramObject != null ? paramObject.getClass().getName() : "null") + 
/* 118 */         "] must be an instance of " + paramClass);
/*     */   }
/*     */ 
/*     */   public static void isAssignable(Class paramClass1, Class paramClass2)
/*     */   {
/* 130 */     isAssignable(paramClass1, paramClass2, "");
/*     */   }
/*     */ 
/*     */   public static void isAssignable(Class paramClass1, Class paramClass2, String paramString)
/*     */   {
/* 145 */     notNull(paramClass1, "Type to check against must not be null");
/* 146 */     if ((paramClass2 == null) || (!paramClass1.isAssignableFrom(paramClass2)))
/* 147 */       throw new IllegalArgumentException(paramString + paramClass2 + " is not assignable to " + paramClass1);
/*     */   }
/*     */ 
/*     */   public static void state(boolean paramBoolean, String paramString)
/*     */   {
/* 162 */     if (!paramBoolean)
/* 163 */       throw new IllegalStateException(paramString);
/*     */   }
/*     */ 
/*     */   public static void state(boolean paramBoolean)
/*     */   {
/* 177 */     state(paramBoolean, "[Assertion failed] - this state invariant must be true");
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.Assert
 * JD-Core Version:    0.6.2
 */