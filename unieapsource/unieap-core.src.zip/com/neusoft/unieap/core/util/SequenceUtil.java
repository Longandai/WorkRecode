/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ import org.hibernate.HibernateException;
/*    */ import org.hibernate.Session;
/*    */ import org.hibernate.dialect.Dialect;
/*    */ import org.hibernate.dialect.DialectFactory;
/*    */ import org.hibernate.engine.SessionFactoryImplementor;
/*    */ import org.hibernate.engine.SessionImplementor;
/*    */ import org.hibernate.exception.JDBCExceptionHelper;
/*    */ import org.hibernate.jdbc.Batcher;
/*    */ 
/*    */ public class SequenceUtil
/*    */ {
/* 26 */   public static String ORACLE_DIALECT = "org.hibernate.dialect.OracleDialect";
/*    */ 
/*    */   public static Dialect getOracleDialect() {
/* 29 */     return DialectFactory.buildDialect(ORACLE_DIALECT);
/*    */   }
/*    */ 
/*    */   public static String getSequenceNextVAL(Session paramSession, String paramString) {
/* 33 */     String str = getOracleDialect().getSequenceNextValString(paramString);
/* 34 */     SessionImplementor localSessionImplementor = (SessionImplementor)paramSession;
/* 35 */     return generate(localSessionImplementor, str);
/*    */   }
/*    */ 
/*    */   public static String generate(SessionImplementor paramSessionImplementor, String paramString) throws HibernateException
/*    */   {
/*    */     try
/*    */     {
/* 42 */       PreparedStatement localPreparedStatement = paramSessionImplementor.getBatcher().prepareSelectStatement(
/* 43 */         paramString);
/*    */       try {
/* 45 */         ResultSet localResultSet = localPreparedStatement.executeQuery();
/*    */         try {
/* 47 */           localResultSet.next();
/* 48 */           String str1 = localResultSet.getString(1);
/* 49 */           String str2 = str1;
/*    */ 
/* 51 */           localResultSet.close();
/*    */ 
/* 49 */           return str2;
/*    */         } finally {
/* 51 */           localResultSet.close();
/*    */         }
/*    */       } finally {
/* 54 */         paramSessionImplementor.getBatcher().closeStatement(localPreparedStatement);
/*    */       }
/*    */     }
/*    */     catch (SQLException localSQLException) {
/* 58 */       throw JDBCExceptionHelper.convert(paramSessionImplementor.getFactory()
/* 59 */         .getSQLExceptionConverter(), localSQLException, 
/* 60 */         "could not get next sequence value", paramString);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void saveSequenceInfo(Session paramSession, Object paramObject)
/*    */   {
/* 66 */     if ((paramObject instanceof List)) {
/* 67 */       List localList = (List)paramObject;
/* 68 */       for (Iterator localIterator = localList.iterator(); localIterator.hasNext(); ) { Object localObject = localIterator.next();
/* 69 */         saveSingleObjectSequenceInfo(paramSession, localObject); }
/*    */     }
/*    */     else {
/* 72 */       saveSingleObjectSequenceInfo(paramSession, paramObject);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static void saveSingleObjectSequenceInfo(Session paramSession, Object paramObject)
/*    */   {
/* 78 */     Class localClass = paramObject.getClass();
/* 79 */     Map localMap1 = 
/* 80 */       EntityAnnotationParser.getAnnotationInfo(localClass);
/* 81 */     if ((localMap1 != null) && (localMap1.size() > 0)) {
/* 82 */       Set localSet = localMap1.keySet();
/* 83 */       for (String str1 : localSet) {
/* 84 */         Map localMap2 = (Map)localMap1.get(str1);
/* 85 */         Object localObject1 = localMap2.get(EntityAnnotationParser.SEQUENCE);
/* 86 */         if (localObject1 != null) {
/* 87 */           String str2 = getSequenceNextVAL(paramSession, 
/* 88 */             (String)localObject1);
/* 89 */           if (str2 != null)
/*    */             try {
/* 91 */               Method[] arrayOfMethod1 = localClass.getDeclaredMethods();
/* 92 */               Object localObject2 = null;
/* 93 */               for (localObject3 : arrayOfMethod1) {
/* 94 */                 if ((((Method)localObject3).getName().equals(str1)) && 
/* 95 */                   (((Method)localObject3).getParameterTypes().length == 1)) {
/* 96 */                   localObject2 = localObject3;
/*    */                 }
/*    */               }
/* 99 */               Object localObject3 = new ArrayList();
/* 100 */               Class[] arrayOfClass = localObject2.getParameterTypes();
/* 101 */               if (arrayOfClass.length == 1) {
/* 102 */                 if (arrayOfClass[0].getName().equals(
/* 103 */                   String.class.getName())) {
/* 104 */                   ((List)localObject3).add(str2);
/*    */                 }
/* 106 */                 if (arrayOfClass[0].getName().equals(
/* 107 */                   Long.class.getName())) {
/* 108 */                   ((List)localObject3).add(Long.valueOf(str2));
/*    */                 }
/* 110 */                 if (arrayOfClass[0].getName().equals(
/* 111 */                   Integer.class.getName())) {
/* 112 */                   ((List)localObject3).add(Integer.valueOf(str2));
/*    */                 }
/* 114 */                 if (arrayOfClass[0].getName().equals(
/* 115 */                   Short.class.getName())) {
/* 116 */                   ((List)localObject3).add(Short.valueOf(str2));
/*    */                 }
/*    */               }
/* 119 */               localObject2.invoke(paramObject, ((List)localObject3).toArray());
/*    */             }
/*    */             catch (SecurityException localSecurityException) {
/* 122 */               localSecurityException.printStackTrace();
/*    */             } catch (IllegalArgumentException localIllegalArgumentException) {
/* 124 */               localIllegalArgumentException.printStackTrace();
/*    */             } catch (IllegalAccessException localIllegalAccessException) {
/* 126 */               localIllegalAccessException.printStackTrace();
/*    */             } catch (InvocationTargetException localInvocationTargetException) {
/* 128 */               localInvocationTargetException.printStackTrace();
/*    */             }
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.SequenceUtil
 * JD-Core Version:    0.6.2
 */