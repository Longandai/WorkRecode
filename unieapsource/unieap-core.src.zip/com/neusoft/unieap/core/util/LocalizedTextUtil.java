/*     */ package com.neusoft.unieap.core.util;
/*     */ 
/*     */ import com.neusoft.unieap.core.i18n.GlobalInnerManager;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.ResourceBundle;
/*     */ import org.slf4j.Logger;
/*     */ import org.slf4j.LoggerFactory;
/*     */ 
/*     */ public class LocalizedTextUtil
/*     */ {
/*     */   private static final String bundleName = "LocalStrings";
/*  65 */   private static final Logger LOG = LoggerFactory.getLogger(LocalizedTextUtil.class);
/*     */ 
/*  67 */   private static final ResourceBundle EMPTY_BUNDLE = new EmptyResourceBundle(null);
/*     */ 
/*  71 */   private static final Hashtable bundlesMap = new Hashtable();
/*     */ 
/*  76 */   private static final Map messageFormats = new HashMap();
/*     */   private static ClassLoader delegatedClassLoader;
/*     */   private Class clazz;
/*  82 */   private static Map cache = new Hashtable();
/*     */ 
/*     */   private LocalizedTextUtil(Class paramClass) {
/*  85 */     this.clazz = paramClass;
/*     */   }
/*     */ 
/*     */   public static LocalizedTextUtil getLocalizedTextUtil(Class paramClass)
/*     */   {
/*  96 */     LocalizedTextUtil localLocalizedTextUtil = (LocalizedTextUtil)cache.get(paramClass);
/*  97 */     if (localLocalizedTextUtil == null) {
/*  98 */       localLocalizedTextUtil = new LocalizedTextUtil(paramClass);
/*  99 */       cache.put(paramClass, localLocalizedTextUtil);
/*     */     }
/*     */ 
/* 102 */     return localLocalizedTextUtil;
/*     */   }
/*     */ 
/*     */   private static ResourceBundle findResourceBundle(String paramString, Locale paramLocale)
/*     */   {
/* 116 */     String str = createMissesKey(paramString, paramLocale);
/*     */     ResourceBundle localResourceBundle;
/*     */     try
/*     */     {
/* 121 */       if (!bundlesMap.containsKey(str)) {
/* 122 */         localResourceBundle = ResourceBundle.getBundle(paramString, paramLocale, 
/* 123 */           Thread.currentThread().getContextClassLoader());
/* 124 */         bundlesMap.put(str, localResourceBundle);
/*     */       }
/*     */ 
/* 127 */       localResourceBundle = (ResourceBundle)bundlesMap.get(str);
/*     */     } catch (MissingResourceException localMissingResourceException1) {
/* 129 */       if (delegatedClassLoader != null) {
/*     */         try {
/* 131 */           if (!bundlesMap.containsKey(str)) {
/* 132 */             localResourceBundle = ResourceBundle.getBundle(paramString, paramLocale, 
/* 133 */               delegatedClassLoader);
/* 134 */             bundlesMap.put(str, localResourceBundle);
/*     */           }
/*     */ 
/* 137 */           localResourceBundle = (ResourceBundle)bundlesMap.get(str);
/*     */         }
/*     */         catch (MissingResourceException localMissingResourceException2) {
/* 140 */           localResourceBundle = EMPTY_BUNDLE;
/* 141 */           bundlesMap.put(str, localResourceBundle);
/*     */         }
/*     */       } else {
/* 144 */         localResourceBundle = EMPTY_BUNDLE;
/* 145 */         bundlesMap.put(str, localResourceBundle);
/*     */       }
/*     */     }
/* 148 */     return localResourceBundle == EMPTY_BUNDLE ? null : localResourceBundle;
/*     */   }
/*     */ 
/*     */   private static String createMissesKey(String paramString, Locale paramLocale)
/*     */   {
/* 161 */     return paramString + "_" + paramLocale.toString();
/*     */   }
/*     */ 
/*     */   public String findText(String paramString)
/*     */   {
/* 172 */     return findText(this.clazz, paramString, getLocale());
/*     */   }
/*     */ 
/*     */   public String findText(String paramString, Locale paramLocale)
/*     */   {
/* 183 */     return findText(this.clazz, paramString, paramLocale);
/*     */   }
/*     */ 
/*     */   public String findText(String paramString, Object[] paramArrayOfObject)
/*     */   {
/* 196 */     return findText(this.clazz, paramString, getLocale(), paramString, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   public String findText(String paramString, Object[] paramArrayOfObject, Locale paramLocale)
/*     */   {
/* 209 */     return findText(this.clazz, paramString, paramLocale, paramString, paramArrayOfObject);
/*     */   }
/*     */ 
/*     */   private Locale getLocale() {
/* 213 */     return GlobalInnerManager.getDefaultLocale();
/*     */   }
/*     */ 
/*     */   private static String findText(Class paramClass, String paramString, Locale paramLocale)
/*     */   {
/* 223 */     return findText(paramClass, paramString, paramLocale, paramString, new Object[0]);
/*     */   }
/*     */ 
/*     */   private static String findText(Class paramClass, String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject)
/*     */   {
/* 242 */     if (paramString1 == null) {
/* 243 */       LOG.warn("Trying to find text with null key!");
/* 244 */       paramString1 = "";
/*     */     }
/*     */ 
/* 247 */     String str1 = null;
/* 248 */     Class localClass = paramClass;
/*     */     String str2;
/* 249 */     if ((localClass != null) && (!localClass.equals(Object.class)))
/*     */     {
/* 251 */       str2 = localClass.getName();
/* 252 */       while (str2.lastIndexOf('.') != -1) {
/* 253 */         str2 = str2.substring(0, str2
/* 254 */           .lastIndexOf('.'));
/* 255 */         String str3 = str2 + "." + "LocalStrings";
/* 256 */         str1 = getMessage(str3, paramLocale, paramString1, paramArrayOfObject);
/*     */ 
/* 258 */         if (str1 != null) {
/* 259 */           return str1;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 264 */     if (paramString2 == null) {
/* 265 */       str2 = "Unable to find text for key '" + paramString1 + "' ";
/* 266 */       str2 = str2 + "in class '" + paramClass.getName() + "' and locale '" + paramLocale + 
/* 267 */         "'";
/* 268 */       LOG.debug(str2);
/*     */     }
/*     */ 
/* 271 */     return paramString2;
/*     */   }
/*     */ 
/*     */   private static String getMessage(String paramString1, Locale paramLocale, String paramString2, Object[] paramArrayOfObject)
/*     */   {
/* 279 */     ResourceBundle localResourceBundle = findResourceBundle(paramString1, paramLocale);
/* 280 */     if (localResourceBundle == null)
/* 281 */       return null;
/*     */     try
/*     */     {
/* 284 */       String str = localResourceBundle.getString(paramString2);
/* 285 */       MessageFormat localMessageFormat = buildMessageFormat(str, paramLocale);
/* 286 */       return localMessageFormat.format(paramArrayOfObject); } catch (MissingResourceException localMissingResourceException) {
/*     */     }
/* 288 */     return null;
/*     */   }
/*     */ 
/*     */   public static MessageFormat buildMessageFormat(String paramString, Locale paramLocale)
/*     */   {
/* 294 */     MessageFormatKey localMessageFormatKey = new MessageFormatKey(paramString, paramLocale);
/* 295 */     MessageFormat localMessageFormat = null;
/* 296 */     synchronized (messageFormats) {
/* 297 */       localMessageFormat = (MessageFormat)messageFormats.get(localMessageFormatKey);
/* 298 */       if (localMessageFormat == null) {
/* 299 */         localMessageFormat = new MessageFormat(paramString);
/* 300 */         localMessageFormat.setLocale(paramLocale);
/* 301 */         localMessageFormat.applyPattern(paramString);
/* 302 */         messageFormats.put(localMessageFormatKey, localMessageFormat);
/*     */       }
/*     */     }
/*     */ 
/* 306 */     return localMessageFormat;
/*     */   }
/*     */ 
/*     */   private static class EmptyResourceBundle extends ResourceBundle
/*     */   {
/*     */     public Enumeration getKeys()
/*     */     {
/* 347 */       return null;
/*     */     }
/*     */ 
/*     */     protected Object handleGetObject(String paramString) {
/* 351 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class MessageFormatKey
/*     */   {
/*     */     String pattern;
/*     */     Locale locale;
/*     */ 
/*     */     MessageFormatKey(String paramString, Locale paramLocale)
/*     */     {
/* 314 */       this.pattern = paramString;
/* 315 */       this.locale = paramLocale;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object paramObject) {
/* 319 */       if (this == paramObject)
/* 320 */         return true;
/* 321 */       if (!(paramObject instanceof MessageFormatKey)) {
/* 322 */         return false;
/*     */       }
/* 324 */       MessageFormatKey localMessageFormatKey = (MessageFormatKey)paramObject;
/*     */ 
/* 326 */       if (this.locale != null ? !this.locale.equals(localMessageFormatKey.locale) : 
/* 327 */         localMessageFormatKey.locale != null)
/* 328 */         return false;
/* 329 */       if (this.pattern != null ? !this.pattern.equals(localMessageFormatKey.pattern) : 
/* 330 */         localMessageFormatKey.pattern != null) {
/* 331 */         return false;
/*     */       }
/* 333 */       return true;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 338 */       int i = this.pattern != null ? this.pattern.hashCode() : 0;
/* 339 */       i = 29 * i + (this.locale != null ? this.locale.hashCode() : 0);
/* 340 */       return i;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.LocalizedTextUtil
 * JD-Core Version:    0.6.2
 */