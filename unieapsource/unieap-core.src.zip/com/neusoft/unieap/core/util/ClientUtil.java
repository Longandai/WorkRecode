/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import javax.servlet.http.HttpServletRequest;
/*    */ 
/*    */ public class ClientUtil
/*    */ {
/*    */   public static String getClientIp(HttpServletRequest paramHttpServletRequest)
/*    */   {
/* 12 */     String str = paramHttpServletRequest.getHeader("x-forwarded-for");
/* 13 */     if ((str == null) || (str.length() == 0) || ("unknown".equalsIgnoreCase(str)))
/* 14 */       str = paramHttpServletRequest.getHeader("Proxy-Client-IP");
/* 15 */     if ((str == null) || (str.length() == 0) || ("unknown".equalsIgnoreCase(str)))
/* 16 */       str = paramHttpServletRequest.getHeader("WL-Proxy-Client-IP");
/* 17 */     if ((str == null) || (str.length() == 0) || ("unknown".equalsIgnoreCase(str)))
/* 18 */       str = paramHttpServletRequest.getRemoteAddr();
/* 19 */     return str;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.ClientUtil
 * JD-Core Version:    0.6.2
 */