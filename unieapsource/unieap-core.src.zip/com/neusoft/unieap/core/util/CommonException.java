/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.exception.UniEAPBusinessException;
/*    */ 
/*    */ public class CommonException extends UniEAPBusinessException
/*    */ {
/*    */   private static final long serialVersionUID = 7670064452786431675L;
/*    */ 
/*    */   public boolean isLogEnabled()
/*    */   {
/* 10 */     return true;
/*    */   }
/*    */ 
/*    */   public CommonException(String paramString, Exception paramException) {
/* 14 */     super(paramString, paramException, null);
/*    */   }
/*    */ 
/*    */   public CommonException(String paramString, Exception paramException, String[] paramArrayOfString) {
/* 18 */     super(paramString, paramException, paramArrayOfString);
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.CommonException
 * JD-Core Version:    0.6.2
 */