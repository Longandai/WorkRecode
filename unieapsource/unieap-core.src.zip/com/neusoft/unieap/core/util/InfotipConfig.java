/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Properties;
/*    */ import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
/*    */ 
/*    */ public class InfotipConfig extends PropertyPlaceholderConfigurer
/*    */ {
/* 10 */   static Properties prop = new Properties();
/*    */ 
/*    */   public static String getValue(String paramString)
/*    */   {
/* 14 */     return (prop != null) && (paramString != null) && (prop.containsKey(paramString)) ? prop
/* 15 */       .getProperty(paramString) : null;
/*    */   }
/*    */ 
/*    */   protected void loadProperties(Properties paramProperties) throws IOException
/*    */   {
/* 20 */     super.loadProperties(paramProperties);
/* 21 */     prop = (Properties)paramProperties.clone();
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.InfotipConfig
 * JD-Core Version:    0.6.2
 */