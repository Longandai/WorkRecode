/*    */ package com.neusoft.unieap.core.util;
/*    */ 
/*    */ import com.neusoft.unieap.core.annotation.Interaction;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.TargetSource;
/*    */ import org.springframework.aop.framework.AdvisedSupport;
/*    */ import org.springframework.aop.framework.AopProxy;
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ 
/*    */ public class InteractionUtil
/*    */ {
/*    */   public static String getInteractionValue(Object paramObject, Method paramMethod)
/*    */     throws Exception
/*    */   {
/* 15 */     Object localObject = getTarget(paramObject);
/* 16 */     if (localObject != null) {
/* 17 */       Class localClass = localObject.getClass();
/* 18 */       Method localMethod = localClass.getMethod(paramMethod.getName(), paramMethod.getParameterTypes());
/* 19 */       boolean bool = localMethod.isAnnotationPresent(Interaction.class);
/* 20 */       if (bool) {
/* 21 */         Interaction localInteraction = (Interaction)localMethod.getAnnotation(Interaction.class);
/* 22 */         return localInteraction.value();
/*    */       }
/*    */     }
/* 25 */     return null;
/*    */   }
/*    */ 
/*    */   private static Object getTarget(Object paramObject)
/*    */     throws Exception
/*    */   {
/* 36 */     if (!AopUtils.isAopProxy(paramObject))
/* 37 */       return paramObject;
/* 38 */     if (AopUtils.isJdkDynamicProxy(paramObject)) {
/* 39 */       localObject = getJdkDynamicProxyTargetObject(paramObject);
/* 40 */       return getTarget(localObject);
/*    */     }
/*    */ 
/* 43 */     Object localObject = getCglibProxyTargetObject(paramObject);
/* 44 */     return getTarget(localObject);
/*    */   }
/*    */ 
/*    */   private static Object getCglibProxyTargetObject(Object paramObject) throws Exception
/*    */   {
/* 49 */     Field localField1 = paramObject.getClass().getDeclaredField("CGLIB$CALLBACK_0");
/* 50 */     localField1.setAccessible(true);
/* 51 */     Object localObject1 = localField1.get(paramObject);
/* 52 */     Field localField2 = localObject1.getClass().getDeclaredField("advised");
/* 53 */     localField2.setAccessible(true);
/* 54 */     Object localObject2 = ((AdvisedSupport)localField2.get(localObject1)).getTargetSource().getTarget();
/* 55 */     return localObject2;
/*    */   }
/*    */ 
/*    */   private static Object getJdkDynamicProxyTargetObject(Object paramObject) throws Exception
/*    */   {
/* 60 */     Field localField1 = paramObject.getClass().getSuperclass().getDeclaredField("h");
/* 61 */     localField1.setAccessible(true);
/* 62 */     AopProxy localAopProxy = (AopProxy)localField1.get(paramObject);
/* 63 */     Field localField2 = localAopProxy.getClass().getDeclaredField("advised");
/* 64 */     localField2.setAccessible(true);
/* 65 */     Object localObject = ((AdvisedSupport)localField2.get(localAopProxy)).getTargetSource().getTarget();
/* 66 */     return localObject;
/*    */   }
/*    */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.util.InteractionUtil
 * JD-Core Version:    0.6.2
 */