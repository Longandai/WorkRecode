/*     */ package com.neusoft.unieap.core.lob;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.lob.AbstractLobHandler;
/*     */ import org.springframework.jdbc.support.lob.LobCreator;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class UniEAPLobHandler extends AbstractLobHandler
/*     */ {
/*     */   private static final String BLOB_CLASS_NAME = "oracle.sql.BLOB";
/*     */   private static final String CLOB_CLASS_NAME = "oracle.sql.CLOB";
/*     */   private static final String DURATION_SESSION_FIELD_NAME = "DURATION_SESSION";
/*     */   private static final String MODE_READWRITE_FIELD_NAME = "MODE_READWRITE";
/*  92 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*  96 */   private Boolean cache = Boolean.TRUE;
/*     */   private Class blobClass;
/*     */   private Class clobClass;
/* 102 */   private final Map durationSessionConstants = new HashMap(2);
/*     */ 
/* 104 */   private final Map modeReadWriteConstants = new HashMap(2);
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor paramNativeJdbcExtractor)
/*     */   {
/* 124 */     this.nativeJdbcExtractor = paramNativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public void setCache(boolean paramBoolean)
/*     */   {
/* 134 */     this.cache = new Boolean(paramBoolean);
/*     */   }
/*     */ 
/*     */   protected synchronized void initOracleDriverClasses(Connection paramConnection)
/*     */   {
/* 150 */     if (this.blobClass == null)
/*     */       try
/*     */       {
/* 153 */         this.blobClass = paramConnection.getClass().getClassLoader().loadClass("oracle.sql.BLOB");
/* 154 */         this.durationSessionConstants.put(
/* 155 */           this.blobClass, new Integer(this.blobClass.getField("DURATION_SESSION").getInt(null)));
/* 156 */         this.modeReadWriteConstants.put(
/* 157 */           this.blobClass, new Integer(this.blobClass.getField("MODE_READWRITE").getInt(null)));
/*     */ 
/* 160 */         this.clobClass = paramConnection.getClass().getClassLoader().loadClass("oracle.sql.CLOB");
/* 161 */         this.durationSessionConstants.put(
/* 162 */           this.clobClass, new Integer(this.clobClass.getField("DURATION_SESSION").getInt(null)));
/* 163 */         this.modeReadWriteConstants.put(
/* 164 */           this.clobClass, new Integer(this.clobClass.getField("MODE_READWRITE").getInt(null)));
/*     */       }
/*     */       catch (Exception localException) {
/* 167 */         throw new InvalidDataAccessApiUsageException(
/* 168 */           "Couldn't initialize OracleLobHandler because Oracle driver classes are not available. Note that OracleLobHandler requires Oracle JDBC driver 9i or higher!", 
/* 169 */           localException);
/*     */       }
/*     */   }
/*     */ 
/*     */   public byte[] getBlobAsBytes(ResultSet paramResultSet, int paramInt)
/*     */     throws SQLException
/*     */   {
/* 176 */     this.logger.debug("Returning Oracle BLOB as bytes");
/* 177 */     Blob localBlob = paramResultSet.getBlob(paramInt);
/* 178 */     return localBlob != null ? localBlob.getBytes(1L, (int)localBlob.length()) : null;
/*     */   }
/*     */ 
/*     */   public InputStream getBlobAsBinaryStream(ResultSet paramResultSet, int paramInt) throws SQLException {
/* 182 */     this.logger.debug("Returning Oracle BLOB as binary stream");
/* 183 */     Blob localBlob = paramResultSet.getBlob(paramInt);
/* 184 */     return localBlob != null ? localBlob.getBinaryStream() : null;
/*     */   }
/*     */ 
/*     */   public String getClobAsString(ResultSet paramResultSet, int paramInt) throws SQLException {
/* 188 */     this.logger.debug("Returning Oracle CLOB as string");
/* 189 */     Clob localClob = paramResultSet.getClob(paramInt);
/* 190 */     return localClob != null ? localClob.getSubString(1L, (int)localClob.length()) : null;
/*     */   }
/*     */ 
/*     */   public InputStream getClobAsAsciiStream(ResultSet paramResultSet, int paramInt) throws SQLException {
/* 194 */     this.logger.debug("Returning Oracle CLOB as ASCII stream");
/* 195 */     Clob localClob = paramResultSet.getClob(paramInt);
/* 196 */     return localClob != null ? localClob.getAsciiStream() : null;
/*     */   }
/*     */ 
/*     */   public Reader getClobAsCharacterStream(ResultSet paramResultSet, int paramInt) throws SQLException {
/* 200 */     this.logger.debug("Returning Oracle CLOB as character stream");
/* 201 */     Clob localClob = paramResultSet.getClob(paramInt);
/* 202 */     return localClob != null ? localClob.getCharacterStream() : null;
/*     */   }
/*     */ 
/*     */   public LobCreator getLobCreator() {
/* 206 */     return new OracleLobCreator();
/*     */   }
/*     */ 
/*     */   protected static abstract interface LobCallback
/*     */   {
/*     */     public abstract void populateLob(Object paramObject)
/*     */       throws Exception;
/*     */   }
/*     */ 
/*     */   protected class OracleLobCreator implements LobCreator
/*     */   {
/* 217 */     private final List createdLobs = new LinkedList();
/*     */ 
/*     */     protected OracleLobCreator() {
/*     */     }
/*     */     public void setBlobAsBytes(PreparedStatement paramPreparedStatement, int paramInt, final byte[] paramArrayOfByte) throws SQLException {
/* 222 */       if (paramArrayOfByte != null) {
/* 223 */         Blob localBlob = (Blob)createLob(paramPreparedStatement, false, new UniEAPLobHandler.LobCallback() {
/*     */           public void populateLob(Object paramAnonymousObject) throws Exception {
/* 225 */             Method localMethod = paramAnonymousObject.getClass().getMethod("getBinaryOutputStream", new Class[0]);
/* 226 */             OutputStream localOutputStream = (OutputStream)localMethod.invoke(paramAnonymousObject, null);
/* 227 */             FileCopyUtils.copy(paramArrayOfByte, localOutputStream);
/*     */           }
/*     */         });
/* 230 */         paramPreparedStatement.setBlob(paramInt, localBlob);
/* 231 */         if (UniEAPLobHandler.this.logger.isDebugEnabled())
/* 232 */           UniEAPLobHandler.this.logger.debug("Set bytes for Oracle BLOB with length " + localBlob.length());
/*     */       }
/*     */       else
/*     */       {
/* 236 */         paramPreparedStatement.setBlob(paramInt, null);
/* 237 */         UniEAPLobHandler.this.logger.debug("Set Oracle BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setBlobAsBinaryStream(PreparedStatement paramPreparedStatement, int paramInt1, final InputStream paramInputStream, int paramInt2)
/*     */       throws SQLException
/*     */     {
/* 245 */       if (paramInputStream != null) {
/* 246 */         Blob localBlob = (Blob)createLob(paramPreparedStatement, false, new UniEAPLobHandler.LobCallback() {
/*     */           public void populateLob(Object paramAnonymousObject) throws Exception {
/* 248 */             Method localMethod = paramAnonymousObject.getClass().getMethod("getBinaryOutputStream", null);
/* 249 */             OutputStream localOutputStream = (OutputStream)localMethod.invoke(paramAnonymousObject, null);
/* 250 */             FileCopyUtils.copy(paramInputStream, localOutputStream);
/*     */           }
/*     */         });
/* 253 */         paramPreparedStatement.setBlob(paramInt1, localBlob);
/* 254 */         if (UniEAPLobHandler.this.logger.isDebugEnabled())
/* 255 */           UniEAPLobHandler.this.logger.debug("Set binary stream for Oracle BLOB with length " + localBlob.length());
/*     */       }
/*     */       else
/*     */       {
/* 259 */         paramPreparedStatement.setBlob(paramInt1, null);
/* 260 */         UniEAPLobHandler.this.logger.debug("Set Oracle BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsString(PreparedStatement paramPreparedStatement, int paramInt, final String paramString)
/*     */       throws SQLException
/*     */     {
/* 267 */       if (paramString != null) {
/* 268 */         Clob localClob = (Clob)createLob(paramPreparedStatement, true, new UniEAPLobHandler.LobCallback() {
/*     */           public void populateLob(Object paramAnonymousObject) throws Exception {
/* 270 */             Method localMethod = paramAnonymousObject.getClass().getMethod("getCharacterOutputStream", null);
/* 271 */             Writer localWriter = (Writer)localMethod.invoke(paramAnonymousObject, null);
/* 272 */             FileCopyUtils.copy(paramString, localWriter);
/*     */           }
/*     */         });
/* 275 */         paramPreparedStatement.setClob(paramInt, localClob);
/* 276 */         if (UniEAPLobHandler.this.logger.isDebugEnabled())
/* 277 */           UniEAPLobHandler.this.logger.debug("Set string for Oracle CLOB with length " + localClob.length());
/*     */       }
/*     */       else
/*     */       {
/* 281 */         paramPreparedStatement.setClob(paramInt, null);
/* 282 */         UniEAPLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsAsciiStream(PreparedStatement paramPreparedStatement, int paramInt1, final InputStream paramInputStream, int paramInt2)
/*     */       throws SQLException
/*     */     {
/* 290 */       if (paramInputStream != null) {
/* 291 */         Clob localClob = (Clob)createLob(paramPreparedStatement, true, new UniEAPLobHandler.LobCallback() {
/*     */           public void populateLob(Object paramAnonymousObject) throws Exception {
/* 293 */             Method localMethod = paramAnonymousObject.getClass().getMethod("getAsciiOutputStream", null);
/* 294 */             OutputStream localOutputStream = (OutputStream)localMethod.invoke(paramAnonymousObject, null);
/* 295 */             FileCopyUtils.copy(paramInputStream, localOutputStream);
/*     */           }
/*     */         });
/* 298 */         paramPreparedStatement.setClob(paramInt1, localClob);
/* 299 */         if (UniEAPLobHandler.this.logger.isDebugEnabled())
/* 300 */           UniEAPLobHandler.this.logger.debug("Set ASCII stream for Oracle CLOB with length " + localClob.length());
/*     */       }
/*     */       else
/*     */       {
/* 304 */         paramPreparedStatement.setClob(paramInt1, null);
/* 305 */         UniEAPLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsCharacterStream(PreparedStatement paramPreparedStatement, int paramInt1, final Reader paramReader, int paramInt2)
/*     */       throws SQLException
/*     */     {
/* 313 */       if (paramReader != null) {
/* 314 */         Clob localClob = (Clob)createLob(paramPreparedStatement, true, new UniEAPLobHandler.LobCallback() {
/*     */           public void populateLob(Object paramAnonymousObject) throws Exception {
/* 316 */             Method localMethod = paramAnonymousObject.getClass().getMethod("getCharacterOutputStream", null);
/* 317 */             Writer localWriter = (Writer)localMethod.invoke(paramAnonymousObject, null);
/* 318 */             FileCopyUtils.copy(paramReader, localWriter);
/*     */           }
/*     */         });
/* 321 */         paramPreparedStatement.setClob(paramInt1, localClob);
/* 322 */         if (UniEAPLobHandler.this.logger.isDebugEnabled())
/* 323 */           UniEAPLobHandler.this.logger.debug("Set character stream for Oracle CLOB with length " + localClob.length());
/*     */       }
/*     */       else
/*     */       {
/* 327 */         paramPreparedStatement.setClob(paramInt1, null);
/* 328 */         UniEAPLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Object createLob(PreparedStatement paramPreparedStatement, boolean paramBoolean, UniEAPLobHandler.LobCallback paramLobCallback)
/*     */       throws SQLException
/*     */     {
/* 339 */       Connection localConnection = null;
/*     */       try {
/* 341 */         localConnection = getOracleConnection(paramPreparedStatement);
/* 342 */         UniEAPLobHandler.this.initOracleDriverClasses(localConnection);
/* 343 */         Object localObject = prepareLob(localConnection, paramBoolean ? UniEAPLobHandler.this.clobClass : UniEAPLobHandler.this.blobClass);
/* 344 */         paramLobCallback.populateLob(localObject);
/* 345 */         localObject.getClass().getMethod("close", null).invoke(localObject, null);
/* 346 */         this.createdLobs.add(localObject);
/* 347 */         if (UniEAPLobHandler.this.logger.isDebugEnabled()) {
/* 348 */           UniEAPLobHandler.this.logger.debug("Created new Oracle " + (paramBoolean ? "CLOB" : "BLOB"));
/*     */         }
/* 350 */         return localObject;
/*     */       }
/*     */       catch (SQLException localSQLException) {
/* 353 */         throw localSQLException;
/*     */       }
/*     */       catch (InvocationTargetException localInvocationTargetException) {
/* 356 */         if ((localInvocationTargetException.getTargetException() instanceof SQLException)) {
/* 357 */           throw ((SQLException)localInvocationTargetException.getTargetException());
/*     */         }
/* 359 */         if ((localConnection != null) && ((localInvocationTargetException.getTargetException() instanceof ClassCastException))) {
/* 360 */           throw new InvalidDataAccessApiUsageException(
/* 361 */             "OracleLobCreator needs to work on [oracle.jdbc.OracleConnection], not on [" + 
/* 362 */             localConnection.getClass().getName() + "]: specify a corresponding NativeJdbcExtractor", 
/* 363 */             localInvocationTargetException.getTargetException());
/*     */         }
/*     */ 
/* 366 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", 
/* 367 */           localInvocationTargetException.getTargetException());
/*     */       }
/*     */       catch (Exception localException)
/*     */       {
/* 371 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", localException);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Connection getOracleConnection(PreparedStatement paramPreparedStatement)
/*     */       throws SQLException, ClassNotFoundException
/*     */     {
/* 381 */       return UniEAPLobHandler.this.nativeJdbcExtractor != null ? 
/* 382 */         UniEAPLobHandler.this.nativeJdbcExtractor.getNativeConnectionFromStatement(paramPreparedStatement) : paramPreparedStatement.getConnection();
/*     */     }
/*     */ 
/*     */     protected Object prepareLob(Connection paramConnection, Class paramClass)
/*     */       throws Exception
/*     */     {
/* 394 */       Method localMethod1 = paramClass.getMethod(
/* 395 */         "createTemporary", new Class[] { Connection.class, Boolean.TYPE, Integer.TYPE });
/* 396 */       if (!paramConnection.getClass().getName().startsWith("oracle.jdbc.driver"))
/*     */       {
/* 398 */         localObject = Class.forName("com.neusoft.unieap.monitor.jdbc.monitor4jdbc.ConnectionSpy").getMethod("getRealConnection", null);
/* 399 */         paramConnection = (Connection)((Method)localObject).invoke(paramConnection, null);
/*     */       }
/* 401 */       Object localObject = localMethod1.invoke(
/* 402 */         null, new Object[] { paramConnection, UniEAPLobHandler.this.cache, UniEAPLobHandler.this.durationSessionConstants.get(paramClass) });
/* 403 */       Method localMethod2 = paramClass.getMethod("open", new Class[] { Integer.TYPE });
/* 404 */       localMethod2.invoke(localObject, new Object[] { UniEAPLobHandler.this.modeReadWriteConstants.get(paramClass) });
/* 405 */       return localObject;
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */       try
/*     */       {
/* 413 */         for (Iterator localIterator = this.createdLobs.iterator(); localIterator.hasNext(); )
/*     */         {
/* 418 */           Object localObject = localIterator.next();
/* 419 */           Method localMethod = localObject.getClass().getMethod("freeTemporary", new Class[0]);
/* 420 */           localMethod.invoke(localObject, new Object[0]);
/* 421 */           localIterator.remove();
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException localInvocationTargetException) {
/* 425 */         UniEAPLobHandler.this.logger.error("Could not free Oracle LOB", localInvocationTargetException.getTargetException());
/*     */       }
/*     */       catch (Exception localException) {
/* 428 */         throw new DataAccessResourceFailureException("Could not free Oracle LOB", localException);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Long\Desktop\unieap-core.jar
 * Qualified Name:     com.neusoft.unieap.core.lob.UniEAPLobHandler
 * JD-Core Version:    0.6.2
 */